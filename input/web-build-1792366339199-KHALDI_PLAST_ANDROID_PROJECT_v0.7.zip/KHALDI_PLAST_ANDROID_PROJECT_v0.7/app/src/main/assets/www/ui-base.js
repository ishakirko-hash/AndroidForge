/* KHALDI PLAST - UI base: state, storage (with safe migration), text, forms and reusable components. */
(function () {
  'use strict';
  var K = window.KP, I = window.I18N, V = window.KPV;
  var U = window.KPU = { K: K, V: V, LANGS: ['ar', 'fr', 'en'], S: { ym: K.today().slice(0, 7), week: K.startOfWeek(K.today()), txKind: 'all', txPeriod: 'all', txQ: '', invQ: '', showAll: {} } };
  var AND = window.KPAndroid || null;
  U.AND = AND;
  function $(s) { return document.querySelector(s); }
  U.$ = $;
  var esc = U.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };

  /* ---------- text ---------- */
  U.li = function () { var l = U.D && U.D.settings ? U.D.settings.lang : 'ar'; var i = U.LANGS.indexOf(l); return i < 0 ? 0 : i; };
  U.lang = function () { return U.LANGS[U.li()]; };
  var t = U.t = function (key, vars) {
    var e = I[key], s = e ? (e[U.li()] || e[0]) : key;
    if (vars) Object.keys(vars).forEach(function (k) { s = s.split('{' + k + '}').join(vars[k]); });
    return s;
  };
  U.act = function (list, keepId) { return list.filter(function (x) { return !x.archived || (keepId && x.id === keepId); }); };
  U.mode = function () { return U.D.settings.inputMode === 'centimes' ? 'centimes' : 'dzd'; };
  U.money = function (c) { return '<bdi class="num" dir="ltr">' + K.fmtMoney(c) + '</bdi> <span class="u">' + t('dzd') + '</span>'; };
  U.moneyTxt = function (c) { return K.fmtMoney(c) + ' ' + t('dzd'); };
  U.qty = function (q) { return '<bdi class="num" dir="ltr">' + K.fmtQty(q) + '</bdi>'; };
  U.dt = function (s) { return '<bdi class="num">' + esc(K.fmtDate(s)) + '</bdi>'; };
  U.invNo = function (n) { return '#' + ('00000' + n).slice(-5); };
  U.forInput = function (c) {
    if (!c) return '';
    if (U.mode() === 'centimes') return String(c);
    var dz = Math.floor(c / 100), ct = c % 100; return String(dz) + (ct ? '.' + (ct < 10 ? '0' : '') + ct : '');
  };
  U.longDate = function (s) {
    var p = s.split('-').map(Number);
    try { return new Intl.DateTimeFormat({ ar: 'ar-u-nu-latn', fr: 'fr-FR', en: 'en-GB' }[U.lang()], { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(p[0], p[1] - 1, p[2])); }
    catch (e) { return K.fmtDate(s); }
  };
  U.monthLabel = function (ym) {
    var y = Number(ym.slice(0, 4)), m = Number(ym.slice(5, 7));
    try { return new Intl.DateTimeFormat({ ar: 'ar-u-nu-latn', fr: 'fr-FR', en: 'en-GB' }[U.lang()], { month: 'long', year: 'numeric' }).format(new Date(y, m - 1, 1)); }
    catch (e) { return ym; }
  };
  U.dayName = function (s, short) {
    var p = s.split('-').map(Number);
    try { return new Intl.DateTimeFormat({ ar: 'ar-u-nu-latn', fr: 'fr-FR', en: 'en-GB' }[U.lang()], { weekday: short ? 'short' : 'long' }).format(new Date(p[0], p[1] - 1, p[2])); } catch (e) { return ''; }
  };
  U.methodLabel = function (m) { return t('m_' + (m || 'cash')); };
  U.methodOptions = function () { return ['cash', 'transfer', 'cheque', 'other'].map(function (m) { return { v: m, l: t('m_' + m) }; }); };
  U.custName = function (id) { var c = id ? K.byId(U.D.customers, id) : null; return c ? c.name : t('walkin'); };
  U.supName = function (id) { var c = K.byId(U.D.suppliers, id); return c ? c.name : '?'; };
  U.prodName = function (id) { var p = K.byId(U.D.products, id); return p ? p.name : '?'; };
  U.matName = function (id) { var p = K.byId(U.D.materials, id); return p ? p.name : '?'; };
  U.catName = function (id) { var c = K.byId(U.D.expenseCats, id); return c ? (c.key ? t('cat_' + c.key) : c.name) : '?'; };
  U.workerName = function (id) { var w = K.byId(U.D.workers, id); return w ? w.name : '?'; };
  U.newest = function (arr) { return arr.slice().sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : ((a.ts || '') < (b.ts || '') ? 1 : -1); }); };

  /* ---------- storage ---------- */
  U.loadWarning = null; U.locked = false; U.migratedNow = false; U.rawDamaged = '';
  function rd(which) {
    try { if (AND) return which === 'prev' ? AND.loadPrevData() : AND.loadData(); return localStorage.getItem(which === 'prev' ? 'kp_data_prev' : 'kp_data') || ''; } catch (e) { return ''; }
  }
  function tryParse(s) {
    if (!s) return null; var obj;
    try { obj = JSON.parse(s); } catch (e) { return null; }
    if (!obj || typeof obj !== 'object') return null;
    var v = K.validateBackup({ app: 'KHALDI_PLAST_BACKUP', schema: obj.schema, data: obj });
    return v.ok ? { data: v.data, migrated: v.migrated } : null;
  }
  U.sideSave = function (name, content) { try { if (AND) return AND.saveSideFile(name, content); localStorage.setItem('kp_side_' + name, content); return true; } catch (e) { return false; } };
  U.sideLoad = function (name) { try { return AND ? AND.loadSideFile(name) : (localStorage.getItem('kp_side_' + name) || ''); } catch (e) { return ''; } };
  U.loadData = function () {
    var main = rd('main'), r = tryParse(main);
    if (!r && main) {
      var prev = rd('prev'); r = tryParse(prev);
      if (r) { U.loadWarning = 'restored_prev'; }
      else { U.loadWarning = 'data_damaged'; U.locked = true; U.rawDamaged = main; return K.emptyData(); }  // never overwrite unreadable data
    }
    if (!r) return K.emptyData();
    if (r.migrated) {
      // Versioned migration: keep the untouched original file first (this is the way back), then write the new format.
      U.sideSave('premigration_v1.json', main);
      try { U.persist(r.data); U.migratedNow = true; } catch (e) { U.loadWarning = 'data_damaged'; U.locked = true; }
    }
    return r.data;
  };
  U.persist = function (data) {
    var s = JSON.stringify(data);
    if (AND) { if (!AND.saveData(s)) throw K.E('save_failed'); return; }
    try { var old = localStorage.getItem('kp_data'); if (old) localStorage.setItem('kp_data_prev', old); localStorage.setItem('kp_data', s); } catch (e) { throw K.E('save_failed'); }
  };
  // Runs fn on a COPY; replaces the real data only after it succeeded AND was written to disk.
  U.commit = function (fn) {
    if (U.locked) throw K.E('data_locked');
    var nd = K.tx(U.D, fn); U.persist(nd); U.D = nd;
  };

  /* ---------- feedback ---------- */
  U.toast = function (msg, kind) {
    var el = $('#toast'); el.textContent = msg; el.className = kind || ''; clearTimeout(U.toast.h);
    U.toast.h = setTimeout(function () { el.className = 'hidden'; }, 2800);
  };
  U.errMsg = function (e) {
    if (e && e.code && I['err_' + e.code]) return t('err_' + e.code, e.params || {});
    return t('err_unknown') + ' (' + (e && e.message ? e.message : '?') + ')';
  };
  U.run = function (fn) { try { fn(); } catch (e) { U.toast(U.errMsg(e), 'bad'); } };

  /* ---------- parsing user input ---------- */
  U.parseM = function (s, req) { s = String(s || '').trim(); if (!s) { if (req) throw K.E('bad_amount'); return 0; } var r = K.parseMoney(s, U.mode()); if (!r.ok) throw K.E('bad_amount'); return r.c; };
  U.parseQ = function (s, dec, req) { s = String(s || '').trim(); if (!s) { if (req) throw K.E('bad_qty'); return 0; } var r = K.parseQty(s, dec); if (!r.ok) throw K.E('bad_qty'); return r.q; };
  U.parseG = function (s) { s = String(s || '').trim(); if (!s) return 0; var r = K.parseQty(s, false); if (!r.ok) throw K.E('bad_grams'); return r.q; };
  U.moneyHint = function (s) {
    var r = K.parseMoney(s, U.mode());
    if (!r.ok) return { bad: true, text: t('hint_invalid_' + U.mode()) };
    return { bad: false, text: t('hint_money', { dzd: K.fmtMoney(r.c), c: K.groupInt(r.c) }) };
  };

  /* ---------- modal sheet ---------- */
  U.modalOpen = false;
  U.showModal = function (html) { $('#sheet').innerHTML = html; $('#modal').classList.remove('hidden'); U.modalOpen = true; $('#sheet').scrollTop = 0; };
  U.closeModal = function () { $('#modal').classList.add('hidden'); $('#sheet').innerHTML = ''; U.modalOpen = false; };

  /* ---------- reusable components (HTML builders) ---------- */
  U.stat = function (label, valueHtml, cls, extra) { return '<div class="stat ' + (cls || '') + '"><div class="l">' + esc(label) + '</div><div class="v">' + valueHtml + '</div>' + (extra || '') + '</div>'; };
  U.sec = function (title, link) { return '<div class="sec"><h3>' + esc(title) + '</h3>' + (link || '') + '</div>'; };
  U.empty = function (text, icon) { return '<div class="empty">' + V.icon(icon || 'note', 38) + '<div>' + esc(text) + '</div></div>'; };
  U.badge = function (text, cls) { return '<span class="badge ' + (cls || '') + '">' + esc(text) + '</span>'; };
  U.kv = function (icon, label, valueHtml) { return '<div class="kv"><div class="k">' + V.icon(icon, 18) + esc(label) + '</div><div class="v">' + valueHtml + '</div></div>'; };
  U.seg = function (items, active, act) {
    return '<div class="seg">' + items.map(function (x) { return '<button class="' + (x[0] === active ? 'on' : '') + '" data-act="' + act + '" data-id="' + x[0] + '">' + esc(x[1]) + '</button>'; }).join('') + '</div>';
  };
  U.chips = function (items, active, act) {
    return '<div class="chips">' + items.map(function (x) { return '<button class="chip ' + (x[0] === active ? 'on' : '') + '" data-act="' + act + '" data-id="' + x[0] + '">' + esc(x[1]) + '</button>'; }).join('') + '</div>';
  };
  U.monthbar = function () {
    return '<div class="monthbar"><button class="arrow" data-act="month_prev" aria-label="prev">' + V.icon(U.lang() === 'ar' ? 'chevR' : 'chevL', 20) + '</button><div class="pill">' + V.icon('calendar', 18) + '<span>' + esc(U.monthLabel(U.S.ym)) + '</span></div>' +
      '<button class="arrow" data-act="month_next" aria-label="next">' + V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 20) + '</button></div>';
  };
  U.searchbox = function (id, value, ph) { return '<div class="searchbox">' + V.icon('search', 20) + '<input id="' + id + '" type="search" value="' + esc(value) + '" placeholder="' + esc(ph) + '"></div>'; };
  U.moreBtn = function (key, shown, total) { return (U.S.showAll[key] || total <= shown) ? '' : '<button class="btn ghost block" data-act="showall" data-id="' + key + '">' + t('show_all') + ' (' + total + ')</button>'; };
  U.limit = function (arr, key, n) { return U.S.showAll[key] ? arr : arr.slice(0, n); };
  U.delta = function (pct, inverse) {
    if (pct == null) return '';
    var good = inverse ? pct <= 0 : pct >= 0;
    return '<div class="d ' + (good ? 'up' : 'down') + '"><bdi class="num">' + (pct > 0 ? '+' : '') + pct + '%</bdi> ' + (pct >= 0 ? '▲' : '▼') + '</div>';
  };

  /* ---------- form engine (bottom sheet) ---------- */
  function fieldHtml(f) {
    if (f.type === 'html') return f.html;
    if (f.type === 'items') return itemsHtml(f);
    var h = '', label = f.label + (f.type === 'money' ? ' (' + t(U.mode() === 'centimes' ? 'unit_centimes' : 'unit_dzd') + ')' : '');
    if (f.type === 'check') return '<label class="chk"><input type="checkbox" name="' + f.name + '"' + (f.value ? ' checked' : '') + '> ' + esc(f.label) + '</label>';
    h += '<label for="f_' + f.name + '">' + esc(label) + (f.optional ? ' <span class="muted">(' + t('optional') + ')</span>' : '') + '</label>';
    var val = f.value == null ? '' : f.value;
    if (f.type === 'select') {
      h += '<select id="f_' + f.name + '" name="' + f.name + '">';
      (f.options || []).forEach(function (o) { h += '<option value="' + esc(o.v) + '"' + (String(o.v) === String(val) ? ' selected' : '') + '>' + esc(o.l) + '</option>'; });
      if (f.allowNew) h += '<option value="__new__">+ ' + esc(f.newLabel) + '</option>';
      h += '</select>';
      if (f.allowNew) h += '<div class="newbox hidden" id="nb_' + f.name + '"><input name="' + f.name + '_new" placeholder="' + esc(f.newLabel) + '"></div>';
    } else if (f.type === 'textarea') {
      h += '<textarea id="f_' + f.name + '" name="' + f.name + '">' + esc(val) + '</textarea>';
    } else {
      var it = f.type === 'date' ? 'date' : 'text', im = (f.type === 'money' || f.type === 'qtyd') ? 'decimal' : (f.type === 'qty' || f.type === 'grams') ? 'numeric' : 'text';
      h += '<input id="f_' + f.name + '" name="' + f.name + '" type="' + it + '" inputmode="' + im + '" value="' + esc(val) + '"' + (f.ph ? ' placeholder="' + esc(f.ph) + '"' : '') + '>';
    }
    if (f.type === 'money') h += '<div class="hint" id="hint_' + f.name + '"></div>';
    return h;
  }
  function itemRow(i, row, f, canDel) {
    return '<div class="card itrow" data-i="' + i + '" style="box-shadow:none;border:1px solid var(--line);margin-top:10px"><label style="margin-top:0">' + esc(t('product')) + '</label>' +
      '<select data-k="product">' + f.products.map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === row.product ? ' selected' : '') + '>' + esc(p.name) + ' (' + t('in_stock') + ' ' + K.fmtQty(p.stock) + ')</option>'; }).join('') + '</select>' +
      '<div class="two"><div><label>' + esc(t('quantity')) + '</label><input data-k="qty" inputmode="numeric" value="' + esc(row.qty) + '" placeholder="0"></div>' +
      '<div><label>' + esc(t('unit_price')) + ' (' + t(U.mode() === 'centimes' ? 'unit_centimes' : 'unit_dzd') + ')</label><input data-k="price" inputmode="decimal" value="' + esc(row.price) + '"></div></div>' +
      '<div class="hint" data-k="phint"></div>' +
      '<div class="two"><div><label>' + esc(t('weight_per_crate')) + ' (' + t('gram') + ')</label><input data-k="weight" inputmode="numeric" value="' + esc(row.weight) + '" placeholder="0"></div>' +
      '<div style="display:flex;align-items:flex-end">' + (canDel ? '<button type="button" class="btn soft-danger sm" style="width:100%" data-delitem="' + i + '">' + V.icon('trash', 16) + ' ' + t('remove') + '</button>' : '') + '</div></div></div>';
  }
  function itemsHtml(f) {
    return '<label>' + esc(f.label) + '</label><div id="items">' + f.rows.map(function (r, i) { return itemRow(i, r, f, f.rows.length > 1); }).join('') + '</div>' +
      '<button type="button" class="btn sm block" data-additem>+ ' + esc(t('add_line')) + '</button>';
  }
  function readItems(form) {
    return [].slice.call(form.querySelectorAll('.itrow')).map(function (el) {
      function g(k) { return el.querySelector('[data-k="' + k + '"]').value; }
      return { product: g('product'), qty: g('qty'), price: g('price'), weight: g('weight'), touched: el.querySelector('[data-k="price"]').getAttribute('data-touched') === '1' };
    });
  }

  U.openForm = function (cfg) {
    var h = '<form id="f" autocomplete="off" novalidate><h3>' + esc(cfg.title) + '</h3>';
    if (cfg.intro) h += '<div class="muted" style="margin-bottom:6px">' + cfg.intro + '</div>';
    cfg.fields.forEach(function (f) { h += fieldHtml(f); });
    h += '<div id="calc" class="calc"></div><div id="ferr" class="ferr"></div>';
    if (cfg.extra) { h += '<div class="btns">'; cfg.extra.forEach(function (x, i) { h += '<button type="button" class="btn sm" data-extra="' + i + '">' + esc(x.label) + '</button>'; }); h += '</div>'; }
    if (cfg.onDelete) h += '<div class="btns"><button type="button" class="btn danger-o" data-del="1">' + V.icon('trash', 18) + ' ' + t('delete') + '</button></div>';
    h += '<div class="btns"><button type="button" class="btn ghost" data-act="close">' + t('cancel') + '</button><button type="submit" class="btn ' + (cfg.danger ? 'danger' : 'primary') + '">' + esc(cfg.submit || t('save')) + '</button></div></form>';
    U.showModal(h);
    var form = $('#f'), itemsField = null;
    cfg.fields.forEach(function (f) { if (f.type === 'items') itemsField = f; });
    function vals() {
      var v = {};
      cfg.fields.forEach(function (f) {
        if (f.type === 'html') return;
        if (f.type === 'items') { v[f.name] = readItems(form); return; }
        var el = form.elements[f.name]; if (!el) return;
        v[f.name] = f.type === 'check' ? el.checked : el.value;
        if (f.allowNew) v[f.name + '_new'] = form.elements[f.name + '_new'].value;
      });
      return v;
    }
    function update(ev) {
      cfg.fields.forEach(function (f) {
        if (f.type === 'money') {
          var s = form.elements[f.name].value, hEl = $('#hint_' + f.name);
          if (!s.trim()) { hEl.textContent = ''; hEl.className = 'hint'; } else { var m = U.moneyHint(s); hEl.textContent = m.text; hEl.className = 'hint' + (m.bad ? ' bad' : ''); }
        }
        if (f.allowNew) $('#nb_' + f.name).classList.toggle('hidden', form.elements[f.name].value !== '__new__');
      });
      if (itemsField) {
        [].slice.call(form.querySelectorAll('.itrow')).forEach(function (el) {
          var p = el.querySelector('[data-k="price"]').value, hEl = el.querySelector('[data-k="phint"]');
          if (!p.trim()) { hEl.textContent = ''; hEl.className = 'hint'; } else { var m = U.moneyHint(p); hEl.textContent = m.text; hEl.className = 'hint' + (m.bad ? ' bad' : ''); }
        });
      }
      if (cfg.onChange && ev && ev.target) cfg.onChange(form, ev.target.name || ev.target.getAttribute('data-k'), ev);
      $('#calc').innerHTML = cfg.calc ? cfg.calc(vals()) : '';
    }
    function redrawItems(rows) { $('#items').innerHTML = rows.map(function (r, i) { return itemRow(i, r, itemsField, rows.length > 1); }).join(''); update({ target: form }); }
    form.addEventListener('input', function (e) { if (e.target.getAttribute && e.target.getAttribute('data-k') === 'price') e.target.setAttribute('data-touched', '1'); update(e); });
    form.addEventListener('change', function (e) {
      if (itemsField && e.target.getAttribute && e.target.getAttribute('data-k') === 'product') {   // new product -> suggest its default price unless the user typed one
        var row = e.target.closest('.itrow'), p = K.byId(U.D.products, e.target.value), pr = row.querySelector('[data-k="price"]');
        if (p && pr.getAttribute('data-touched') !== '1') pr.value = U.forInput(p.price);
        var wg = row.querySelector('[data-k="weight"]'); if (p && !wg.value.trim() && p.weightG) wg.value = p.weightG;
      }
      update(e);
    });
    form.addEventListener('click', function (e) {
      if (cfg.onDelete && e.target.closest('[data-del]')) { cfg.onDelete(); return; }
      var b = e.target.closest('[data-extra]');
      if (b) { cfg.extra[Number(b.getAttribute('data-extra'))].run(form); update({ target: form.elements[0] }); return; }
      if (!itemsField) return;
      if (e.target.closest('[data-additem]')) {
        var rows = readItems(form), p0 = itemsField.products[0];
        rows.push({ product: p0.id, qty: '', price: U.forInput(p0.price), weight: p0.weightG || '' }); redrawItems(rows); return;
      }
      var del = e.target.closest('[data-delitem]');
      if (del) { var r2 = readItems(form); r2.splice(Number(del.getAttribute('data-delitem')), 1); redrawItems(r2); }
    });
    update();
    form.addEventListener('submit', function (e) { e.preventDefault(); try { cfg.onSubmit(vals()); } catch (err) { $('#ferr').textContent = U.errMsg(err); } });
    return form;
  };
  U.confirmBox = function (title, message, submitLabel, onYes, danger) {
    U.openForm({ title: title, intro: message, fields: [], submit: submitLabel, danger: danger, onSubmit: function () { onYes(); U.closeModal(); } });
  };

  /* ---------- files ---------- */
  U.saveFile = function (name, mime, content) {
    if (AND) { AND.exportFile(name, mime, content); return; }
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type: mime })); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); window.KPExportDone(true, false);
  };
  U.csvEscape = function (s) { s = String(s == null ? '' : s); return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
})();
