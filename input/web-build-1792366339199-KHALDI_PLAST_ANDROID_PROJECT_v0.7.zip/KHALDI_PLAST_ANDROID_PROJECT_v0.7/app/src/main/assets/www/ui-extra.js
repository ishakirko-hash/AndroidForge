/* KHALDI PLAST - v0.7 screens: glass home/sales/stock/production, production-by-days table, shifts overview, workers,
   customers, suppliers, order notes, offline assistant, customisation. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, F = U.forms, S = U.S, X = U.extraActions = {};
  var PAL = ['#00B0F0', '#0077C8', '#1F2D49', '#34A853', '#F59E2C', '#7B4FD0', '#E5493A', '#12907F'];
  S.workTab = S.workTab || 'today'; S.salesP = S.salesP || 'month'; S.salesF = S.salesF || 'all'; S.stockF = S.stockF || 'all'; S.ptAll = S.ptAll || '0';
  S.custF = 'all'; S.suppF = 'all'; S.noteF = 'all'; S.noteSort = 'added'; S.chat = [];
  function B(n) { return '<bdi class="num">' + n + '</bdi>'; }
  function kpi(cls, icon, label, val, note, delta, inv) {
    var dl = delta == null ? '' : '<span class="dl ' + ((inv ? delta <= 0 : delta >= 0) ? 'up' : 'dn') + '">' + (delta >= 0 ? '▲' : '▼') + ' <bdi class="num" dir="ltr">' + Math.abs(delta) + '%</bdi></span>';
    return '<div class="kpi bg-' + cls + '"><div class="kt"><span class="ki">' + V.icon(icon, 22) + '</span><span class="kl">' + esc(label) + '</span></div><div class="kv2">' + val + '</div><div class="kn">' + dl + (note ? '<span>' + note + '</span>' : '') + '</div><i class="sp">' + V.icon('bars', 16) + '</i></div>';
  }
  function pct(cur, prev) { if (cur == null || prev == null || prev === 0) return null; return Math.round((cur - prev) * 1000 / Math.abs(prev)) / 10; }
  function panel(icon, title, body, link) { return '<div class="panel"><div class="ph2"><span class="pi2">' + V.icon(icon, 19) + '</span><h3>' + esc(title) + '</h3>' + (link || '') + '</div>' + body + '</div>'; }
  function lnk(act, id, label) { return '<button class="lnk" data-act="' + act + '"' + (id ? ' data-id="' + id + '"' : '') + '>' + esc(label) + '</button>'; }
  function pcs(n) { return B(K.groupInt(n)) + ' <small>' + t('pcs') + '</small>'; }
  function csv(name, rows) { U.saveFile(name, 'text/csv', '﻿' + rows.map(function (r) { return r.map(U.csvEscape).join(','); }).join('\r\n')); }
  function printNow(name) { if (U.AND && U.AND.printPage) U.AND.printPage(name); else window.print(); }
  function money0(c) { return K.fmtMoney(c); }
  function legend(parts) { return '<div class="legend">' + parts.map(function (p) { return '<div class="li"><span class="sw" style="background:' + p.color + '"></span><span class="nm">' + esc(p.name) + '</span><b>' + p.val + '</b></div>'; }).join('') + '</div>'; }
  function noData() { return '<div class="muted" style="text-align:center;padding:14px 0">' + t('no_records') + '</div>'; }

  /* ================= customisation (layout) ================= */
  var CAT = ['production', 'purchases', 'sales', 'expenses', 'debts', 'stock', 'invoices', 'reports', 'workers', 'customers', 'suppliers', 'notes', 'prodtable', 'assistant', 'transactions', 'shifts', 'backup', 'settings', 'customize'];
  var DEF_HOME = ['sales', 'invoices', 'production', 'prodtable', 'stock', 'purchases', 'expenses', 'debts', 'customers', 'suppliers', 'workers', 'assistant'];
  var LBL = { production: 'tile_production', purchases: 'tile_purchases', sales: 'tile_sales', expenses: 'tile_expenses', debts: 'tile_debts', stock: 'tile_stock', invoices: 'tile_invoices', reports: 'tile_reports', workers: 'tile_workers',
    customers: 'tile_customers', suppliers: 'tile_suppliers', notes: 'v_notes', prodtable: 'tile_prodtable', assistant: 'tile_assistant', transactions: 'v_transactions', shifts: 'tile_shifts', backup: 'v_backup', settings: 'v_settings', customize: 'tile_customize' };
  var SEC = ['kpis', 'alerts', 'chart', 'products', 'shortcuts', 'recent'];
  var SECL = { kpis: 'sec_kpis', alerts: 'sec_alerts', chart: 'sec_chart', products: 'sec_products', shortcuts: 'sec_shortcuts', recent: 'sec_recent' };
  function L() { var l = U.D.settings.layout || {}; return { v: l.v, order: l.order || [], hidden: l.hidden || [], icons: l.icons || {}, secOrder: l.secOrder || [], secHidden: l.secHidden || [] }; }
  function order(list, saved) { var o = []; saved.forEach(function (x) { if (list.indexOf(x) >= 0 && o.indexOf(x) < 0) o.push(x); }); list.forEach(function (x) { if (o.indexOf(x) < 0) o.push(x); }); return o; }
  function scOrdered() { return order(CAT, L().order); }
  function scHidden(id) { var l = L(); return l.v ? l.hidden.indexOf(id) >= 0 : DEF_HOME.indexOf(id) < 0; }
  function secOrdered() { return order(SEC, L().secOrder); }
  function secHidden(id) { return L().secHidden.indexOf(id) >= 0; }
  function iconOf(id) { var ic = L().icons[id], names = V.tileNames(); return names.indexOf(ic) >= 0 ? ic : id; }
  function saveLayout(fn) {
    var o = scOrdered(), hid = CAT.filter(scHidden), so = secOrdered();
    U.commit(function (d) {
      var l = d.settings.layout = Object.assign({ hidden: [], order: [], icons: {}, secOrder: [], secHidden: [] }, d.settings.layout);
      if (!l.v) { l.order = o; l.hidden = hid; l.secOrder = so; l.secHidden = []; l.v = 1; }
      if (!l.icons) l.icons = {}; if (!l.secOrder.length) l.secOrder = so; if (!l.secHidden) l.secHidden = [];
      fn(l);
    });
    U.render(true);
  }
  function move(arr, id, dir) { var i = arr.indexOf(id), j = i + dir; if (i < 0 || j < 0 || j >= arr.length) return; var x = arr[i]; arr[i] = arr[j]; arr[j] = x; }
  function toggle(arr, id) { var i = arr.indexOf(id); if (i >= 0) arr.splice(i, 1); else arr.push(id); }
  function openSC(id) {
    if (id === 'sales' || id === 'stock' || id === 'production') { U.stack = []; U.route = id; U.arg = null; U.render(); U.$('#main').scrollTop = 0; return; }
    if (id === 'shifts') { S.workTab = 'today'; id = 'workers'; } else if (id === 'workers') S.workTab = 'list';
    U.go(id);
  }
  function tileBtn(id) { var ic = iconOf(id), c = V.tileColor(ic); return '<button class="tilebtn" data-act="sc" data-id="' + id + '"><span class="tic" style="background:linear-gradient(135deg,' + c + '33,' + c + '14)">' + V.tile(ic, 34) + '</span><span>' + esc(t(LBL[id])) + '</span></button>'; }
  X.sc = function (el) { openSC(el.dataset.id); };

  /* ================= home ================= */
  function todayByProduct() {
    var D = U.D, day = K.today(), m = {};
    K.live(D.production).filter(function (r) { return r.date === day; }).forEach(function (r) { m[r.productId] = (m[r.productId] || 0) + r.good; });
    return U.act(D.products).map(function (p) { return { p: p, q: m[p.id] || 0 }; });
  }
  var HOME = {
    kpis: function (d) {
      var D = U.D, ym = K.today().slice(0, 7), cur = K.monthlyReport(D, ym), prev = K.monthlyReport(D, K.addMonths(ym, -1)), c = K.compareMonths(cur, prev);
      return '<div class="kpis">' + kpi('green', 'wallet', t('month_sales'), U.money(cur.sales), '', c.sales) + kpi('blue', 'machine', t('month_production'), pcs(cur.good), '', c.good) +
        kpi('amber', 'box', t('finished_stock'), pcs(d.finishedStock), t('raw_stock') + ': ' + B(K.fmtQty(d.rawStock)) + ' ' + t('kg')) + kpi('red', 'wallet', t('month_expenses'), U.money(cur.expenses), '', c.expenses, true) + '</div>';
    },
    alerts: function () {
      var a = U.alerts(); if (!a.length) return '';
      return panel('alert', t('alerts'), a.slice(0, 5).map(function (x) { return '<div class="row"><div class="ibox ' + x.cls + '">' + V.icon(x.icon, 20) + '</div><div class="main"><div class="t" style="font-weight:600">' + esc(x.text) + '</div></div></div>'; }).join(''));
    },
    chart: function () {
      var ser = K.monthSeries(U.D, K.today().slice(0, 7), 6);
      return panel('bars', t('monthly_sales'), V.area([{ values: ser.map(function (x) { return x.sales / 100; }), color: '#0077C8' }], ser.map(function (x) { return U.monthLabel(x.ym).split(' ')[0]; }), 160), '<span class="badge">' + t('sales_6m') + '</span>');
    },
    products: function () {
      var l = todayByProduct(); if (!l.length) return '';
      var tot = K.sum(l, function (x) { return x.q; });
      return '<div class="pcards">' + l.slice(0, 6).map(function (x) {
        var pc = tot ? Math.round(x.q * 100 / tot) : 0;
        return '<div class="pcard"><div class="pbody"><div class="pn">' + esc(x.p.name) + '</div><div class="pu">' + t('today_production') + '</div><div class="pq">' + B(K.groupInt(x.q)) + ' <small class="pu">' + t('pcs') + '</small></div></div><div><div class="thumb" style="width:54px;height:40px">' + V.crate(x.p.color, 50) + '</div></div><span class="pring" style="background:conic-gradient(#0077C8 ' + pc + '%,rgba(11,26,46,.1) 0)"><b>' + pc + '%</b></span></div>';
      }).join('') + '</div>';
    },
    shortcuts: function () {
      var ids = scOrdered().filter(function (id) { return !scHidden(id); });
      return '<div class="sec"><h3>' + t('quick_access') + '</h3>' + lnk('goto', 'customize', t('tile_customize')) + '</div>' + (ids.length ? '<div class="tiles">' + ids.map(tileBtn).join('') + '</div>' : '<div class="card muted">' + t('no_shortcuts') + '</div>');
    },
    recent: function () {
      var r = K.feed(U.D).slice(0, 5);
      return panel('list', t('recent_tx'), r.length ? r.map(function (f) { return U.txRow(f); }).join('') : noData(), lnk('goto', 'transactions', t('show_all')));
    }
  };
  W.home = function () {
    var D = U.D, day = K.today(), d = K.dashboard(D, day), h = '', hr = new Date().getHours();
    if (U.loadWarning) h += '<div class="alert red">' + t('warn_' + U.loadWarning) + '</div>';
    if (U.migratedNow) h += '<div class="alert blue">' + t('migrated_note') + '</div>';
    h += '<div class="greet"><div class="gi">' + V.icon('bars', 24) + '</div><div class="gt"><b>' + t(hr < 12 ? 'greet_morning' : hr < 18 ? 'greet_afternoon' : 'greet_evening') + '</b><span>' + t('today_sales') + ': ' + U.moneyTxt(d.todaySales) + '</span></div><div class="gd">' + V.icon('calendar', 18) + '<br>' + esc(U.longDate(day)) + '</div></div>';
    secOrdered().forEach(function (id) { if (!secHidden(id)) h += HOME[id](d); });
    return h;
  };

  /* ================= sales ================= */
  function range(p) {
    var td = K.today();
    if (p === 'today') return { from: td, to: td }; if (p === 'week') return { from: K.addDays(td, -6), to: td };
    if (p === 'year') return { from: td.slice(0, 4) + '-01-01', to: td.slice(0, 4) + '-12-31' };
    return K.monthRange(S.ym);
  }
  function salesIn(r) { return K.live(U.D.sales).filter(function (s) { return s.date >= r.from && s.date <= r.to; }); }
  function prevRange(p, r) {
    if (p === 'today') { var y = K.addDays(r.from, -1); return { from: y, to: y }; }
    if (p === 'week') return { from: K.addDays(r.from, -7), to: K.addDays(r.to, -7) };
    if (p === 'year') { var yy = String(Number(r.from.slice(0, 4)) - 1); return { from: yy + '-01-01', to: yy + '-12-31' }; }
    return K.monthRange(K.addMonths(S.ym, -1));
  }
  W.sales = function () {
    var D = U.D, p = S.salesP, r = range(p), rep = K.periodReport(D, r.from, r.to), pr = prevRange(p, r), prep = K.periodReport(D, pr.from, pr.to), list = salesIn(r), h = '';
    h += U.seg([['today', t('p_today')], ['week', t('p_week')], ['month', t('p_month')], ['year', t('p_year')]], p, 'salesp');
    if (p === 'month') h += U.monthbar();
    h += '<div class="kpis3">' + kpi('green', 'wallet', t('total_sales'), U.money(rep.sales), '', pct(rep.sales, prep.sales)) + kpi('blue', 'note', t('invoice_count'), B(rep.salesCount), '', pct(rep.salesCount, prep.salesCount)) + kpi('purple', 'box', t('crates_sold'), B(K.groupInt(rep.cratesSold)), '', pct(rep.cratesSold, prep.cratesSold)) + '</div>';
    var vals = [], labs = [];
    if (p === 'year') { for (var m = 1; m <= 12; m++) { var ym = r.from.slice(0, 4) + '-' + K.pad2(m), mr = K.monthRange(ym); vals.push(K.sum(salesIn(mr), function (x) { return x.total; }) / 100); labs.push(String(m)); } }
    else { var dd = r.from; while (dd <= r.to) { vals.push(K.sum(list.filter(function (x) { return x.date === dd; }), function (x) { return x.total; }) / 100); labs.push(dd.slice(8)); dd = K.addDays(dd, 1); } }
    h += panel('bars', t('sales_analysis'), V.area([{ values: vals, color: '#00A6E8' }], labs, 170), '<span class="badge green">' + t('amount_collected') + ': ' + U.moneyTxt(rep.collected) + '</span>');
    var byP = {}; list.forEach(function (x) { x.items.forEach(function (i) { var o = byP[i.productId] || (byP[i.productId] = { q: 0, v: 0 }); o.q += i.qty; o.v += i.qty * i.unitPrice; }); });
    var pk = Object.keys(byP).sort(function (a, b) { return byP[b].v - byP[a].v; }), tot = K.sum(pk, function (k) { return byP[k].v; });
    var pparts = pk.map(function (k, i) { var pp = K.byId(D.products, k); return { value: byP[k].v, color: PAL[i % PAL.length], name: pp ? pp.name : '?', val: B(Math.round(byP[k].v * 100 / (tot || 1)) + '%') }; });
    var pm = {}; K.live(D.payments).filter(function (x) { return x.date >= r.from && x.date <= r.to; }).forEach(function (x) { pm[x.method || 'cash'] = (pm[x.method || 'cash'] || 0) + x.amount; });
    var mk = Object.keys(pm), mtot = K.sum(mk, function (k) { return pm[k]; }), mparts = mk.map(function (k, i) { return { value: pm[k], color: PAL[(i + 3) % PAL.length], name: U.methodLabel(k), val: B(Math.round(pm[k] * 100 / (mtot || 1)) + '%') }; });
    function dn(parts, center, sub) { return parts.length ? '<div class="donutrow">' + V.donut(parts, center, sub) + legend(parts) + '</div>' : noData(); }
    h += '<div class="twocol">' + panel('box', t('by_product'), dn(pparts, B(compactM(tot)), t('dzd'))) + panel('wallet', t('by_method'), dn(mparts, B(compactM(mtot)), t('dzd'))) + '</div>';
    var q = (S.salesQ || '').trim().toLowerCase();
    var inv = U.newest(D.sales.filter(function (x) { return x.date >= r.from && x.date <= r.to; })).filter(function (x) {
      var out = K.saleOutstanding(D, x.id);
      if (S.salesF === 'paid' && (x.voided || out > 0)) return false; if (S.salesF === 'unpaid' && (x.voided || out <= 0)) return false;
      return !q || (U.invNo(x.no) + ' ' + U.invFull(x) + ' ' + U.custName(x.customerId) + ' ' + K.fmtDate(x.date)).toLowerCase().indexOf(q) >= 0;
    });
    h += '<div class="filterrow">' + U.searchbox('salesq', S.salesQ || '', t('search_invoice')).replace('id="salesq"', 'id="salesq" data-bind="salesQ"') + '</div>';
    h += U.chips([['all', t('all')], ['paid', t('paid')], ['unpaid', t('unpaid')]], S.salesF, 'salesf');
    var rows = U.limit(inv, 'sal', 8);
    h += panel('note', t('latest_invoices'), rows.length ? '<div style="overflow-x:auto"><table class="itable"><thead><tr><th>' + t('invoice_no') + '</th><th class="l">' + t('customer') + '</th><th>' + t('date') + '</th><th>' + t('quantity') + '</th><th>' + t('total') + '</th><th>' + t('inv_status') + '</th></tr></thead><tbody>' + rows.map(function (x) {
      var out = K.saleOutstanding(D, x.id), st = x.voided ? ['bad', 'inv_st_void'] : out <= 0 ? ['green', 'inv_st_paid'] : K.salePaid(D, x.id) > 0 ? ['amber', 'inv_st_partial'] : ['amber', 'inv_st_unpaid'];
      return '<tr class="tap" data-act="tx" data-kind="sale" data-id="' + x.id + '"><td>' + B(('00000' + x.no).slice(-5)) + '</td><td class="l">' + esc(U.custName(x.customerId)) + '</td><td>' + B(K.fmtDate(x.date).slice(0, 5)) + '</td><td>' + B(K.fmtQty(K.sum(x.items, function (i) { return i.qty; }))) + '</td><td>' + B(K.fmtMoney(x.total)) + '</td><td>' + U.badge(t(st[1]), st[0] === 'bad' ? 'red' : st[0]) + '</td></tr>';
    }).join('') + '</tbody></table></div>' + U.moreBtn('sal', 8, inv.length) : '<div class="muted" style="text-align:center;padding:12px">' + t('no_results') + '</div>', lnk('goto', 'invoices', t('show_all')));
    h += '<div class="btns"><button class="btn" data-act="export_sales">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_sales">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_sale">+ ' + t('new_invoice') + '</button></div>';
  };
  function compactM(c) { var v = c / 100; return v >= 1e6 ? (Math.round(v / 1e5) / 10) + 'M' : v >= 1e3 ? (Math.round(v / 100) / 10) + 'K' : String(Math.round(v)); }
  X.salesp = function (el) { S.salesP = el.dataset.id; S.showAll.sal = false; U.render(true); };
  X.salesf = function (el) { S.salesF = el.dataset.id; U.render(true); };
  X.export_sales = function () {
    var r = range(S.salesP), rows = [[t('invoice_no'), t('date'), t('customer'), t('total'), t('paid'), t('remaining')]];
    U.newest(U.D.sales.filter(function (s) { return !s.voided && s.date >= r.from && s.date <= r.to; })).forEach(function (s) { rows.push([U.invFull(s), s.date, U.custName(s.customerId), money0(s.total), money0(K.salePaid(U.D, s.id)), money0(s.total - K.salePaid(U.D, s.id))]); });
    csv('khaldi_sales_' + r.from + '_' + r.to + '.csv', rows);
  };
  X.print_sales = function () { printNow('KHALDI_PLAST_sales'); };

  /* ================= stock ================= */
  W.stock = function () {
    var D = U.D, tab = S.stockTab || 'finished', h = '', fin = K.sum(D.products, function (p) { return p.stock; }), raw = K.round3(K.sum(D.materials, function (p) { return p.stock; }));
    var low = D.products.concat(D.materials).filter(function (x) { return !x.archived && x.minStock > 0 && x.stock <= x.minStock; });
    var types = U.act(D.products).length + U.act(D.materials).length, isP = tab !== 'raw';
    h += '<div class="kpis4">' + kpi('blue', 'box', t('items_count'), B(types)) + kpi('green', 'box', t('finished_stock'), B(K.groupInt(fin))) + kpi('amber', 'scale', t('raw_stock'), B(K.fmtQty(raw))) + kpi(low.length ? 'red' : 'purple', 'alert', t('low_stock'), B(low.length)) + '</div>';
    var td = K.today(), labs = [], inn = [], out = [], i;
    for (i = 13; i >= 0; i--) { var dd = K.addDays(td, -i), ms = D.movements.filter(function (m) { return m.kind === (isP ? 'product' : 'material') && m.date === dd; }); labs.push(dd.slice(8)); inn.push(K.sum(ms.filter(function (m) { return m.qty > 0; }), function (m) { return m.qty; })); out.push(K.sum(ms.filter(function (m) { return m.qty < 0; }), function (m) { return -m.qty; })); }
    var items = U.act(isP ? D.products : D.materials);
    var parts = items.filter(function (x) { return x.stock > 0; }).map(function (x, k) { return { value: x.stock, color: PAL[k % PAL.length], name: x.name, val: B(Math.round(x.stock * 100 / ((isP ? fin : raw) || 1)) + '%') }; });
    h += '<div class="twocol">' + panel('bars', t('movement_chart'), V.area([{ values: inn, color: '#12804A' }, { values: out, color: '#E5493A' }], labs, 150) + '<div class="legend"><div class="li"><span class="sw" style="background:#12804A"></span><span class="nm">' + t('stock_in') + '</span></div><div class="li"><span class="sw" style="background:#E5493A"></span><span class="nm">' + t('stock_out') + '</span></div></div>') +
      panel('box', t('distribution'), parts.length ? '<div class="donutrow">' + V.donut(parts, B(K.fmtQty(isP ? fin : raw)), t(isP ? 'pcs' : 'kg')) + legend(parts) + '</div>' : noData()) + '</div>';
    h += U.seg([['finished', t('tab_products')], ['raw', t('tab_materials')], ['moves', t('tab_movements')]], tab, 'stocktab');
    if (tab !== 'moves') {
      var q = (S.stockQ || '').trim().toLowerCase();
      h += '<div class="filterrow">' + U.searchbox('stockq', S.stockQ || '', t('search')).replace('id="stockq"', 'id="stockq" data-bind="stockQ"') + '</div>';
      h += U.chips([['all', t('all')], ['low', t('low_stock')], ['ok', t('stock_ok')]], S.stockF, 'stockf');
      items = items.filter(function (x) { var lw = x.minStock > 0 && x.stock <= x.minStock; return (S.stockF === 'all' || (S.stockF === 'low' ? lw : !lw)) && (!q || x.name.toLowerCase().indexOf(q) >= 0); });
      h += items.length ? '<div class="card">' + items.map(function (x) {
        var lw = x.minStock > 0 && x.stock <= x.minStock, avg = isP ? null : K.avgMaterialCost(D, x.id), kind = isP ? 'product' : 'material';
        return '<div class="row"><div class="' + (isP ? 'thumb' : 'ibox amber') + '">' + (isP ? V.crate(x.color, 48) : V.icon('scale', 22)) + '</div><div class="main"><div class="t">' + esc(x.name) + '</div><div class="s">' + (x.code ? esc(x.code) + ' · ' : '') + (isP ? (x.price ? U.moneyTxt(x.price) : '-') + (x.weightG ? ' · ' + B(x.weightG) + ' ' + t('gram') : '') : t('avg_cost') + ': ' + (avg == null ? '-' : U.moneyTxt(Math.round(avg)) + ' / ' + t('kg'))) + '</div>' + (lw ? '<div>' + U.badge(t('low_stock'), 'red') + '</div>' : '') + '</div>' +
          '<div class="r"><small class="muted">' + t('available_qty') + '</small><br>' + U.qty(x.stock) + ' <span class="u muted">' + t(isP ? 'pcs' : 'kg') + '</span></div><div style="display:flex;flex-direction:column;gap:6px"><button class="iconbtn" data-act="adjust" data-kind="' + kind + '" data-id="' + x.id + '" aria-label="' + t('adjust') + '">' + V.icon('bars', 18) + '</button><button class="iconbtn" data-act="edit_item" data-kind="' + kind + '" data-id="' + x.id + '" aria-label="' + t('edit') + '">' + V.icon('edit', 18) + '</button></div></div>';
      }).join('') + '</div>' : '<div class="card">' + U.empty(t('no_results'), 'search') + '</div>';
      h += '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_item" data-kind="' + (isP ? 'product' : 'material') + '">+ ' + t(isP ? 'new_product' : 'new_material') + '</button></div>';
    } else {
      var list = D.movements.slice().reverse();
      h += list.length ? '<div class="card">' + U.limit(list, 'mv', 50).map(function (m) {
        return '<div class="row"><div class="main"><div class="t">' + esc(m.kind === 'product' ? U.prodName(m.itemId) : U.matName(m.itemId)) + '</div><div class="s">' + U.dt(m.date) + ' · ' + t('mv_' + m.type) + (m.note ? ' · ' + esc(m.note) : '') + '</div></div><div class="r ' + (m.qty >= 0 ? 'up' : 'down') + '">' + (m.qty > 0 ? '+' : '') + B(K.fmtQty(m.qty)) + '</div></div>';
      }).join('') + '</div>' + U.moreBtn('mv', 50, list.length) : '<div class="card">' + U.empty(t('no_records')) + '</div>';
    }
    return h;
  };
  X.stockf = function (el) { S.stockF = el.dataset.id; U.render(true); };

  /* ================= production ================= */
  function pendingOrders() { return U.D.notes.filter(function (n) { return n.isOrder && n.productId && (n.status === 'pending' || n.status === 'confirmed'); }).sort(function (a, b) { return (a.expectedDate || '9999') < (b.expectedDate || '9999') ? -1 : 1; }); }
  W.production = function () {
    var D = U.D, ym = S.ym, r = K.monthRange(ym), m = K.periodReport(D, r.from, r.to), tb = K.productionTable(D, r.from, r.to), total = m.good + m.defective, h = U.monthbar();
    var pmr = K.monthRange(K.addMonths(ym, -1)), pm0 = K.periodReport(D, pmr.from, pmr.to), dGood = pct(m.good, pm0.good), dTot = pct(total, pm0.good + pm0.defective);
    var pc = total ? Math.round(m.defective * 1000 / total) / 10 : 0, ord = pendingOrders();
    h += '<div class="kpis">' + kpi('blue', 'machine', t('production_total'), pcs(total), '', dTot) + kpi('green', 'check', t('good_crates'), pcs(m.good), '', dGood) + kpi('red', 'alert', t('defective_crates'), pcs(m.defective), t('defect_rate') + ': ' + B(pc + '%')) + kpi('amber', 'note', t('pending_orders'), B(ord.length)) + '</div>';
    h += '<div class="kpis">' + kpi('purple', 'scale', t('materials_consumed'), B(K.fmtQty(tb.totalKg)) + ' <small>' + t('kg') + '</small>') + kpi('blue', 'wallet', t('est_cost'), m.materialsCost == null ? '—' : U.money(m.materialsCost), m.materialsCost == null ? t('profit_unavailable') : t('estimate')) + '</div>';
    var td = K.today(), labs = [], vals = [], i; for (i = 6; i >= 0; i--) { var dd = K.addDays(td, -i); labs.push(dd.slice(8)); vals.push(K.sum(K.live(D.production).filter(function (x) { return x.date === dd; }), function (x) { return x.good; })); }
    h += panel('bars', t('last7'), V.area([{ values: vals, color: '#0077C8' }], labs, 150), lnk('goto', 'prodtable', t('tile_prodtable')));
    var byProd = {}; K.live(D.production).filter(function (x) { return x.date >= r.from && x.date <= r.to; }).forEach(function (x) { byProd[x.productId] = (byProd[x.productId] || 0) + x.good; });
    var ks = Object.keys(byProd), parts = ks.map(function (k, j) { var p = K.byId(D.products, k); return { value: byProd[k], color: PAL[j % PAL.length], name: p ? p.name : '?', val: B(K.groupInt(byProd[k])) }; });
    h += panel('box', t('crate_types'), parts.length ? '<div class="donutrow">' + V.donut(parts, B(K.groupInt(m.good)), t('good_crates')) + legend(parts) + '</div>' : noData());
    if (ord.length) h += panel('note', t('pending_orders'), ord.slice(0, 3).map(function (n) { return '<div class="row tap" data-act="edit_note" data-id="' + n.id + '"><div class="ibox amber">' + V.icon('note', 20) + '</div><div class="main"><div class="t">' + esc(n.customerName || n.title || U.prodName(n.productId)) + '</div><div class="s">' + esc(U.prodName(n.productId)) + ' × ' + B(n.qty) + (n.expectedDate ? ' · ' + U.dt(n.expectedDate) : '') + '</div></div></div>'; }).join(''), lnk('goto', 'notes', t('show_all')));
    var list = U.newest(D.production.filter(function (x) { return x.date >= r.from && x.date <= r.to; }));
    h += U.sec(t('production_log'));
    h += list.length ? '<div class="card">' + U.limit(list, 'prd', 8).map(function (x) { return U.txRow({ kind: 'production', id: x.id, date: x.date, rec: x, voided: x.voided }); }).join('') + '</div>' + U.moreBtn('prd', 8, list.length) : '<div class="card">' + U.empty(t('no_records')) + '</div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_production">+ ' + t('new_production') + '</button></div>';
  };

  /* ================= production by days (smart table) ================= */
  W.prodtable = function () {
    var D = U.D, r = K.monthRange(S.ym), tb = K.productionTable(D, r.from, r.to), h = U.monthbar();
    var ids = {}; tb.rows.forEach(function (x) { Object.keys(x.byProduct).forEach(function (k) { ids[k] = 1; }); });
    var prods = D.products.filter(function (p) { return ids[p.id] || (!p.archived); }).filter(function (p) { return ids[p.id] || tb.rows.length === 0 || true; });
    var all = S.ptAll === '1', byDate = {}; tb.rows.forEach(function (x) { byDate[x.date] = x; });
    var days = []; if (all) { for (var i = 1; i <= Number(r.to.slice(8)); i++) days.push(S.ym + '-' + K.pad2(i)); } else days = tb.rows.map(function (x) { return x.date; });
    var tot = tb.totalGood + tb.totalDefective, avg = tb.rows.length ? Math.round(tb.totalGood / tb.rows.length) : 0;
    h += '<div class="kpis">' + kpi('green', 'check', t('good_crates'), pcs(tb.totalGood)) + kpi('red', 'alert', t('defective_crates'), pcs(tb.totalDefective), t('defect_rate') + ': ' + B((tot ? Math.round(tb.totalDefective * 1000 / tot) / 10 : 0) + '%')) + kpi('blue', 'calendar', t('prod_days'), B(tb.rows.length), t('daily_avg') + ': ' + B(K.groupInt(avg))) + kpi('amber', 'scale', t('materials_consumed'), B(K.fmtQty(tb.totalKg)) + ' <small>' + t('kg') + '</small>') + '</div>';
    h += U.seg([['0', t('only_prod_days')], ['1', t('all_days')]], S.ptAll, 'ptall');
    if (!tb.rows.length && !all) return h + '<div class="card">' + U.empty(t('no_records'), 'box') + '</div><div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_production">+ ' + t('new_production') + '</button></div>';
    var th = '<tr><th>' + t('date') + '</th>' + prods.map(function (p) { return '<th>' + esc(p.name) + '</th>'; }).join('') + '<th>' + t('good_crates') + '</th><th>' + t('defective_crates') + '</th>' + K.SHIFTS.map(function (s) { return '<th>' + t('shift') + ' ' + s.n + '</th>'; }).join('') + '<th>' + t('shift_unspecified_short') + '</th><th>' + t('kg') + '</th></tr>';
    var body = days.map(function (dd) {
      var x = byDate[dd];
      if (!x) return '<tr class="zero"><td>' + esc(U.dayName(dd, true)) + ' ' + B(dd.slice(8) + '/' + dd.slice(5, 7)) + '</td>' + prods.map(function () { return '<td>·</td>'; }).join('') + '<td>·</td><td>·</td><td>·</td><td>·</td><td>·</td><td>·</td><td>·</td></tr>';
      return '<tr class="tap" data-act="pt_day" data-date="' + dd + '"><td>' + esc(U.dayName(dd, true)) + ' ' + B(dd.slice(8) + '/' + dd.slice(5, 7)) + '</td>' + prods.map(function (p) { var b = x.byProduct[p.id]; return '<td>' + (b ? B(K.groupInt(b.good)) + (b.defective ? ' <small class="muted">(' + b.defective + ')</small>' : '') : '·') + '</td>'; }).join('') +
        '<td><b>' + B(K.groupInt(x.good)) + '</b></td><td class="' + (x.defective ? 'bad' : '') + '">' + B(x.defective) + '</td>' + [1, 2, 3, 0].map(function (n) { return '<td>' + (x.shifts[n] ? B(K.groupInt(x.shifts[n])) : '·') + '</td>'; }).join('') + '<td>' + (x.kg ? B(K.fmtQty(x.kg)) : '·') + '</td></tr>';
    }).join('');
    var sh = { 0: 0, 1: 0, 2: 0, 3: 0 }, pt = {}; tb.rows.forEach(function (x) { [0, 1, 2, 3].forEach(function (n) { sh[n] += x.shifts[n]; }); Object.keys(x.byProduct).forEach(function (k) { pt[k] = (pt[k] || 0) + x.byProduct[k].good; }); });
    var foot = '<tr><td>' + t('total') + '</td>' + prods.map(function (p) { return '<td>' + B(K.groupInt(pt[p.id] || 0)) + '</td>'; }).join('') + '<td>' + B(K.groupInt(tb.totalGood)) + '</td><td>' + B(K.groupInt(tb.totalDefective)) + '</td>' + [1, 2, 3, 0].map(function (n) { return '<td>' + B(K.groupInt(sh[n])) + '</td>'; }).join('') + '<td>' + B(K.fmtQty(tb.totalKg)) + '</td></tr>';
    h += '<div class="ptable-wrap"><table class="ptable"><thead>' + th + '</thead><tbody>' + body + '</tbody><tfoot>' + foot + '</tfoot></table></div><div class="muted" style="margin-bottom:10px">' + t('ptable_note') + '</div>';
    h += '<div class="btns"><button class="btn" data-act="export_ptable">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_sales">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_production">+ ' + t('new_production') + '</button></div>';
  };
  X.ptall = function (el) { S.ptAll = el.dataset.id; U.render(true); };
  X.pt_day = function (el) {
    var day = el.dataset.date, recs = U.newest(U.D.production.filter(function (x) { return x.date === day; }));
    U.showModal('<h3>' + esc(U.longDate(day)) + '</h3><div class="card" style="box-shadow:none">' + recs.map(function (x) { return U.txRow({ kind: 'production', id: x.id, date: x.date, rec: x, voided: x.voided }).replace('data-act="tx"', 'data-act="pt_rec"'); }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
  };
  X.pt_rec = function (el) { U.closeModal(); U.go('tx', { kind: el.dataset.kind, id: el.dataset.id }); };
  X.export_ptable = function () {
    var r = K.monthRange(S.ym), tb = K.productionTable(U.D, r.from, r.to), ps = U.D.products;
    var rows = [[t('date')].concat(ps.map(function (p) { return p.name; }), [t('good_crates'), t('defective_crates'), t('shift') + ' 1', t('shift') + ' 2', t('shift') + ' 3', t('shift_unspecified_short'), t('kg')])];
    tb.rows.forEach(function (x) { rows.push([x.date].concat(ps.map(function (p) { return x.byProduct[p.id] ? x.byProduct[p.id].good : 0; }), [x.good, x.defective, x.shifts[1], x.shifts[2], x.shifts[3], x.shifts[0], x.kg])); });
    csv('khaldi_production_' + S.ym + '.csv', rows);
  };

  /* ================= workers: today overview, weekly grid, directory ================= */
  function shiftState(n) {
    var h = new Date().getHours(), sh = K.SHIFTS[n - 1], s = parseInt(sh.start, 10), e = parseInt(sh.end, 10) || 24;
    return h >= s && h < e ? 'current' : h < s ? 'upcoming' : 'ended';
  }
  function wstat(w) { return w.status || (w.active === false ? 'stopped' : 'active'); }
  function wbadge(w) { var s = wstat(w); return U.badge(t('ws_' + s), s === 'active' ? 'green' : s === 'leave' ? 'amber' : 'gray'); }
  function tenure(w) {
    if (!w.hireDate) return t('hire_date_none');
    var a = new Date(w.hireDate + 'T00:00:00'), b = new Date((w.endDate || K.today()) + 'T00:00:00'), days = Math.max(0, Math.round((b - a) / 86400000)), y = Math.floor(days / 365), m = Math.floor((days % 365) / 30);
    return (y ? y + ' ' + t('years') + ' ' : '') + (m || !y ? m + ' ' + t('months') : '') + ' (' + days + ' ' + t('days') + ')';
  }
  function todayView() {
    var D = U.D, day = K.today(), active = D.workers.filter(function (w) { return !w.archived && wstat(w) === 'active'; }).length, h = '';
    var workedToday = {}; D.attendance.forEach(function (a) { if (a.date === day && a.worked) workedToday[a.workerId] = 1; });
    h += '<div class="kpis4">' + kpi('blue', 'users', t('workers'), B(U.act(D.workers).length)) + kpi('green', 'check', t('worked_today'), B(Object.keys(workedToday).length)) + kpi('amber', 'clock', t('ws_leave'), B(D.workers.filter(function (w) { return !w.archived && wstat(w) === 'leave'; }).length)) + kpi('red', 'x', t('ws_stopped'), B(D.workers.filter(function (w) { return !w.archived && wstat(w) === 'stopped'; }).length)) + '</div>';
    var recs = K.live(D.production).filter(function (r) { return r.date === day; });
    var info = K.SHIFTS.map(function (s) {
      var worked = K.rosterFor(D, day, s.n).filter(function (a) { return a.worked; }), rr = recs.filter(function (r) { return r.shift === s.n; });
      return { s: s, st: shiftState(s.n), worked: worked, good: K.sum(rr, function (r) { return r.good; }), bad: K.sum(rr, function (r) { return r.defective; }), n: rr.length };
    });
    h += '<div class="shcards">' + info.map(function (x) {
      var pct = active ? Math.min(100, Math.round(x.worked.length * 100 / active)) : 0, col = x.st === 'current' ? '#12804A' : x.st === 'upcoming' ? '#F59E2C' : '#8A94A6';
      return '<div class="shc"><div class="sn">' + t('shift') + ' ' + x.s.n + '</div><div class="st"><bdi dir="ltr">' + x.s.start + ' - ' + x.s.end + '</bdi></div><div class="ring" style="background:conic-gradient(' + col + ' ' + pct + '%,rgba(11,26,46,.1) 0)"><b>' + x.worked.length + '</b></div>' + U.badge(t('st_' + x.st), x.st === 'current' ? 'green' : x.st === 'upcoming' ? 'amber' : 'gray') + '</div>';
    }).join('') + '</div>';
    info.forEach(function (x) {
      h += '<div class="shrow"><div class="shh"><span class="ci2">' + V.icon('clock', 20) + '</span><b>' + t('shift') + ' ' + x.s.n + ' · <bdi dir="ltr">' + x.s.start + ' - ' + x.s.end + '</bdi></b><button class="btn sm" data-act="roster" data-date="' + day + '" data-shift="' + x.s.n + '">' + t('edit') + '</button></div>' +
        '<div class="mini"><div><small>' + t('workers') + '</small><b>' + x.worked.length + '</b></div><div><small>' + t('good_crates') + '</small><b>' + K.groupInt(x.good) + '</b></div><div><small>' + t('defective_crates') + '</small><b>' + K.groupInt(x.bad) + '</b></div><div><small>' + t('production') + '</small><b>' + x.n + '</b></div></div>' +
        '<div style="margin-top:8px">' + (x.worked.length ? x.worked.map(function (a) { return '<span class="chipbtn" data-act="open_worker" data-id="' + a.workerId + '">' + esc(U.workerName(a.workerId)) + '</span>'; }).join(' ') : '<span class="muted">' + t('no_workers_shift') + '</span>') + '</div></div>';
    });
    var un = recs.filter(function (r) { return !r.shift; });
    if (un.length) h += '<div class="alert blue">' + t('unassigned_prod') + ': <b>' + K.groupInt(K.sum(un, function (r) { return r.good; })) + '</b> ' + t('pcs') + '</div>';
    return h + '<div class="muted" style="text-align:center;margin:6px 0 10px">' + t('shifts_fixed_note').replace(/(\d\d:\d\d)-(\d\d:\d\d)/g, '<bdi dir="ltr">$1 - $2</bdi>') + '</div>';
  }
  function weekView() {
    var D = U.D, mon = S.week, days = K.weekDates(mon), cur = K.startOfWeek(K.today()) === mon, ar = U.lang() === 'ar', h = '';
    h += '<div class="shiftwrap"><div class="weekhead"><button class="arrow" data-act="week_prev">' + V.icon(ar ? 'chevR' : 'chevL', 20) + '</button><div class="mid">' + (cur ? t('current_week') : t('week')) + '<div class="muted">' + t('from') + ' <bdi class="num">' + K.fmtDate(days[0]) + '</bdi> ' + t('to') + ' <bdi class="num">' + K.fmtDate(days[6]) + '</bdi></div></div><button class="arrow" data-act="week_next">' + V.icon(ar ? 'chevL' : 'chevR', 20) + '</button></div>';
    h += '<div class="sg"><div class="h">' + t('workers_col') + '</div>' + K.SHIFTS.map(function (s) { return '<div class="h">' + t('shift') + ' ' + s.n + '<small><bdi dir="ltr">' + s.start + ' - ' + s.end + '</bdi></small></div>'; }).join('');
    days.forEach(function (day) {
      h += '<div class="day">' + esc(U.dayName(day)) + '<small><bdi class="num">' + day.slice(8) + '/' + day.slice(5, 7) + '</bdi></small></div>';
      K.SHIFTS.forEach(function (s) {
        var r = K.rosterFor(D, day, s.n), inner = r.length ? r.map(function (a) { return '<span class="wc ' + (a.worked ? 'w' : 'n') + '">' + (a.worked ? '✓ ' : '✗ ') + esc(U.workerName(a.workerId)) + '</span>'; }).join('') : '<span class="wc e">+</span>';
        h += '<button class="cell ' + (r.some(function (a) { return a.worked; }) ? 'w' : (r.length ? 'n' : 'e')) + '" data-act="roster" data-date="' + day + '" data-shift="' + s.n + '">' + inner + '</button>';
      });
    });
    h += '</div><div class="keyline"><span><i style="background:#CFEBD8"></i>' + t('worked') + '</span><span><i style="background:#F9D3CF"></i>' + t('did_not_work') + '</span></div></div>';
    var st = K.workerStats(D, days[0], days[6]).filter(function (x) { return wstat(x.worker) === 'active' || x.shifts; });
    h += st.length ? U.sec(t('week_summary')) + '<div class="card">' + st.map(function (x) { return '<div class="row tap" data-act="open_worker" data-id="' + x.worker.id + '"><div class="ibox">' + V.icon('user', 20) + '</div><div class="main"><div class="t">' + esc(x.worker.name) + '</div></div><div class="r">' + B(x.shifts) + ' ' + t('shifts') + ' · ' + B(x.hours) + ' ' + t('hours') + '</div></div>'; }).join('') + '</div>' : '<div class="alert blue">' + t('add_workers_first') + '</div>';
    return h;
  }
  function listView() {
    var D = U.D, q = (S.workQ || '').trim().toLowerCase(), r = K.monthRange(K.today().slice(0, 7)), h = '';
    var all = U.act(D.workers), act = all.filter(function (w) { return wstat(w) === 'active'; }).length;
    var owed = K.sum(all, function (w) { return Math.max(0, K.workerLedger(D, w.id).balance); });
    h += '<div class="kpis">' + kpi('blue', 'users', t('workers'), B(all.length), B(act) + ' ' + t('ws_active')) + kpi('amber', 'wallet', t('workers_owed'), U.money(owed)) + '</div>';
    h += U.searchbox('workq', S.workQ || '', t('search')).replace('id="workq"', 'id="workq" data-bind="workQ"');
    var list = all.filter(function (w) { return !q || (w.name + ' ' + (w.role || '') + ' ' + (w.phone || '')).toLowerCase().indexOf(q) >= 0; });
    h += '<div class="card">' + (list.length ? list.map(function (w) {
      var m = K.workerLedger(D, w.id, r.from, r.to), a = K.workerLedger(D, w.id);
      return '<div class="row tap" data-act="open_worker" data-id="' + w.id + '"><div class="ibox ' + (wstat(w) === 'active' ? '' : 'red') + '">' + V.icon('user', 22) + '</div><div class="main"><div class="t">' + esc(w.name) + '</div><div class="s">' + (w.role ? esc(w.role) + ' · ' : '') + B(m.shifts) + ' ' + t('shifts') + ' / ' + B(m.hours) + ' ' + t('hours') + ' (' + t('this_month') + ')</div><div class="s">' + t('balance') + ': <b class="' + (a.balance > 0 ? 'down' : '') + '">' + U.moneyTxt(a.balance) + '</b></div></div>' + wbadge(w) + '</div>';
    }).join('') : U.empty(t('no_records'), 'users')) + '</div>';
    h += U.sec(t('machines')) + '<div class="card">' + (U.act(D.machines).length ? U.act(D.machines).map(function (m) { return '<div class="row tap" data-act="edit_machine" data-id="' + m.id + '"><div class="ibox amber">' + V.icon('machine', 22) + '</div><div class="main"><div class="t">' + esc(m.name) + '</div></div>' + V.icon('edit', 18) + '</div>'; }).join('') : '<div class="muted">' + t('no_machines') + '</div>') + '<button class="btn sm block" data-act="new_machine">+ ' + t('new_machine') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_worker">+ ' + t('new_worker') + '</button></div>';
  }
  W.workers = function () {
    var tab = S.workTab, h = U.seg([['today', t('tab_today')], ['week', t('tab_week')], ['list', t('tab_workers')]], tab, 'worktab');
    return h + (tab === 'today' ? todayView() : tab === 'week' ? weekView() : listView());
  };
  X.open_worker = function (el) { U.closeModal(); U.go('worker', el.dataset.id); };

  W.worker = function (id) {
    var D = U.D, w = K.byId(D.workers, id); if (!w) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    var r = K.monthRange(S.ym), m = K.workerLedger(D, id, r.from, r.to), a = K.workerLedger(D, id), h = '';
    h += '<div class="wk-head"><div class="ibox ' + (wstat(w) === 'active' ? '' : 'red') + '">' + V.icon('user', 28) + '</div><div style="flex:1;min-width:0"><div class="big">' + esc(w.name) + '</div><div class="muted">' + esc(w.role || t('noinfo')) + '</div><div style="margin-top:4px">' + wbadge(w) + '</div></div><button class="btn sm ghost" data-act="edit_worker" data-id="' + id + '">' + t('edit') + '</button></div>';
    h += '<div class="card">' + U.kv('calendar', t('hire_date'), w.hireDate ? U.dt(w.hireDate) : '<span class="muted">' + t('hire_date_none') + '</span>') + U.kv('clock', t('tenure'), esc(tenure(w))) + (w.endDate ? U.kv('calendar', t('end_date'), U.dt(w.endDate)) : '') +
      U.kv('phone', t('phone'), w.phone ? B(esc(w.phone)) : '—') + U.kv('pin', t('place_address'), esc(w.address || '—')) + U.kv('wallet', t('rate_per_shift'), w.rate ? U.money(w.rate) : '—') + (w.notes ? U.kv('note', t('notes'), esc(w.notes)) : '') + '</div>';
    h += panel('wallet', t('worker_account'), '<div class="statgrid"><div><small>' + t('earned') + '</small><b>' + U.money(a.earned) + '</b></div><div><small>' + t('paid') + '</small><b>' + U.money(a.paid) + '</b></div><div><small>' + t('balance') + '</small><b class="' + (a.balance > 0 ? 'down' : 'up') + '">' + U.money(a.balance) + '</b></div></div><div class="muted">' + t('worker_balance_note') + '</div>' +
      '<div class="statgrid" style="margin-top:8px"><div><small>' + t('shifts') + ' (' + t('all_time') + ')</small><b>' + a.shifts + '</b></div><div><small>' + t('hours') + '</small><b>' + a.hours + '</b></div><div><small>' + t('absences') + '</small><b>' + a.absent + '</b></div></div>' + '<button class="btn primary block" data-act="pay_worker" data-id="' + id + '">' + V.icon('wallet', 18) + ' ' + t('pay_worker') + '</button>');
    h += U.monthbar() + '<div class="statgrid"><div><small>' + t('shifts') + '</small><b>' + m.shifts + '</b></div><div><small>' + t('hours') + '</small><b>' + m.hours + '</b></div><div><small>' + t('absences') + '</small><b>' + m.absent + '</b></div><div><small>' + t('earned') + '</small><b>' + U.money(m.earned) + '</b></div><div><small>' + t('paid') + '</small><b>' + U.money(m.paid) + '</b></div><div><small>' + t('last_worked') + '</small><b>' + (a.lastWorked ? U.dt(a.lastWorked) : '—') + '</b></div></div>';
    var att = D.attendance.filter(function (x) { return x.workerId === id && x.date >= r.from && x.date <= r.to; }).sort(function (x, y) { return x.date < y.date ? 1 : -1; });
    h += U.sec(t('attendance_log')) + '<div class="card">' + (att.length ? att.map(function (x) { var mc = x.machineId ? K.byId(D.machines, x.machineId) : null; return '<div class="row"><div class="ibox ' + (x.worked ? 'green' : 'red') + '">' + V.icon(x.worked ? 'check' : 'x', 20) + '</div><div class="main"><div class="t">' + U.dt(x.date) + ' · ' + t('shift') + ' ' + x.shift + '</div><div class="s">' + (x.worked ? t('worked') : t('did_not_work')) + (mc ? ' · ' + esc(mc.name) : '') + '</div></div></div>'; }).join('') : '<div class="muted">' + t('no_records') + '</div>') + '</div>';
    var pays = a.payments.slice().sort(function (x, y) { return x.date < y.date ? 1 : -1; });
    h += U.sec(t('worker_payments')) + '<div class="card">' + (pays.length ? pays.map(function (p) { return '<div class="row tap" data-act="edit_wpay" data-id="' + p.id + '"><div class="ibox amber">' + V.icon('upload', 20) + '</div><div class="main"><div class="t">' + t('wpay_' + p.kind) + '</div><div class="s">' + U.dt(p.date) + ' · ' + U.methodLabel(p.method) + '</div></div><div class="r">' + U.money(p.amount) + '</div>' + V.icon('edit', 18) + '</div>'; }).join('') : '<div class="muted">' + t('none') + '</div>') + '</div>';
    return h;
  };
  X.pay_worker = function (el) { F.wpay(el.dataset.id); };
  X.edit_wpay = function (el) { F.wpay(null, el.dataset.id); };
  X.new_worker = function () { F.worker(); };

  /* ================= customers & suppliers ================= */
  function directory(kind) {
    var D = U.D, isC = kind === 'customer', qk = isC ? 'custQ' : 'suppQ', fk = isC ? 'custF' : 'suppF', q = (S[qk] || '').trim().toLowerCase(), h = '';
    var all = U.act(isC ? D.customers : D.suppliers).map(function (p) { return { p: p, b: isC ? K.customerBalance(D, p.id) : K.supplierBalance(D, p.id) }; });
    var debt = K.sum(all, function (x) { return x.b > 0 ? x.b : 0; });
    h += '<div class="kpis">' + kpi(isC ? 'blue' : 'amber', 'users', t(isC ? 'customers' : 'suppliers'), B(all.length)) + kpi('red', 'wallet', t(isC ? 'customer_debts' : 'supplier_debts'), U.money(debt), B(all.filter(function (x) { return x.b > 0; }).length) + ' ' + t('with_balance')) + '</div>';
    h += U.searchbox(qk, S[qk] || '', t('search')).replace('id="' + qk + '"', 'id="' + qk + '" data-bind="' + qk + '"');
    h += U.chips([['all', t('all')], ['debt', t('with_balance')], ['clear', t('no_balance')]], S[fk], 'partyf' + (isC ? 'c' : 's'));
    var list = all.filter(function (x) {
      if (S[fk] === 'debt' && x.b <= 0) return false; if (S[fk] === 'clear' && x.b > 0) return false;
      return !q || (x.p.name + ' ' + (x.p.phone || '') + ' ' + (x.p.address || '') + ' ' + (x.p.activity || '') + ' ' + (x.p.email || '')).toLowerCase().indexOf(q) >= 0;
    }).sort(function (a, b) { return b.b - a.b; });
    h += list.length ? '<div class="card">' + list.map(function (x) {
      return '<div class="row tap" data-act="party" data-kind="' + kind + '" data-id="' + x.p.id + '"><div class="ibox ' + (x.b > 0 ? 'red' : 'green') + '">' + V.icon(isC ? 'user' : 'truck', 22) + '</div><div class="main"><div class="t">' + esc(x.p.name) + '</div>' + (x.p.phone ? '<div class="s">' + V.icon('phone', 13) + ' ' + B(esc(x.p.phone)) + '</div>' : '') + (x.p.address ? '<div class="s">' + V.icon('pin', 13) + ' ' + esc(x.p.address) + '</div>' : '') + (x.p.activity ? '<div class="s">' + esc(x.p.activity) + '</div>' : '') + '</div><div class="r ' + (x.b > 0 ? 'down' : 'up') + '">' + U.money(x.b) + '</div></div>';
    }).join('') + '</div>' : '<div class="card">' + U.empty(t('no_results'), 'search') + '</div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_party" data-kind="' + kind + '">+ ' + t(isC ? 'new_customer' : 'new_supplier') + '</button></div>';
  }
  W.customers = function () { return directory('customer'); };
  W.suppliers = function () { return directory('supplier'); };
  X.partyfc = function (el) { S.custF = el.dataset.id; U.render(true); };
  X.partyfs = function (el) { S.suppF = el.dataset.id; U.render(true); };
  W.party = function (arg) {
    var D = U.D, isC = arg.kind === 'customer', p = K.byId(isC ? D.customers : D.suppliers, arg.id); if (!p) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    var P = K.partyProfile(D, arg.kind, p.id), h = '';
    h += '<div class="wk-head"><div class="ibox ' + (P.balance > 0 ? 'red' : 'green') + '">' + V.icon(isC ? 'user' : 'truck', 28) + '</div><div style="flex:1;min-width:0"><div class="big">' + esc(p.name) + '</div><div class="muted">' + esc(p.activity || t(isC ? 'customer' : 'supplier')) + '</div></div><button class="btn sm ghost" data-act="edit_party" data-kind="' + arg.kind + '" data-id="' + p.id + '">' + t('edit') + '</button></div>';
    h += '<div class="card">' + U.kv('phone', t('phone'), p.phone ? B(esc(p.phone)) : '—') + U.kv('pin', t('place_address'), esc(p.address || '—')) + U.kv('mail', t('email'), p.email ? '<bdi>' + esc(p.email) + '</bdi>' : '—') + (p.notes ? U.kv('note', t('notes'), esc(p.notes)) : '') +
      U.kv('calendar', t('first_deal'), P.first ? U.dt(P.first) : '—') + U.kv('calendar', t('last_deal'), P.last ? U.dt(P.last) : '—') + '</div>';
    h += '<div class="statgrid"><div><small>' + t(isC ? 'invoice_count' : 'purchase_count') + '</small><b>' + B(P.count) + '</b></div><div><small>' + t('total') + '</small><b>' + U.money(P.total) + '</b></div><div><small>' + t('paid') + '</small><b>' + U.money(P.paid) + '</b></div><div><small>' + t('balance') + '</small><b class="' + (P.balance > 0 ? 'down' : 'up') + '">' + U.money(P.balance) + '</b></div><div><small>' + t(isC ? 'crates_sold' : 'kg') + '</small><b>' + B(K.fmtQty(P.qty)) + '</b></div><div><small>' + t('avg_invoice') + '</small><b>' + U.money(P.avg) + '</b></div></div>';
    h += '<div class="btns"><button class="btn primary" data-act="pay_party" data-kind="' + arg.kind + '" data-id="' + p.id + '">' + t(isC ? 'receive_payment' : 'pay_supplier') + '</button>' + (isC ? '<button class="btn" data-act="new_sale_for" data-id="' + p.id + '">+ ' + t('new_invoice') + '</button>' : '<button class="btn" data-act="new_purchase">+ ' + t('new_purchase') + '</button>') + '</div>';
    var docs = U.newest(isC ? D.sales.filter(function (s) { return s.customerId === p.id; }) : D.purchases.filter(function (x) { return x.supplierId === p.id; }));
    h += U.sec(t(isC ? 'sales' : 'purchases')) + (docs.length ? '<div class="card">' + docs.slice(0, 20).map(function (x) { return U.txRow({ kind: isC ? 'sale' : 'purchase', id: x.id, date: x.date, rec: x, voided: x.voided }); }).join('') + '</div>' : '<div class="card">' + U.empty(t('no_records')) + '</div>');
    var pays = U.newest(isC ? D.payments.filter(function (x) { return x.customerId === p.id; }) : D.supplierPayments.filter(function (x) { return x.supplierId === p.id; }));
    return h + U.sec(t('payments')) + (pays.length ? '<div class="card">' + pays.slice(0, 30).map(function (x) { return U.payRow(arg.kind, x); }).join('') + '</div>' : '<div class="card">' + U.empty(t('none')) + '</div>');
  };
  X.new_sale_for = function (el) { F.sale(null, { customerId: el.dataset.id }); };

  /* ================= notes / upcoming orders ================= */
  function nbadge(n) { var c = { pending: 'amber', confirmed: '', completed: 'green', cancelled: 'gray' }[n.status]; return U.badge(t('ns_' + n.status), c); }
  W.notes = function () {
    var D = U.D, td = K.today(), q = (S.noteQ || '').trim().toLowerCase(), h = '';
    var orders = D.notes.filter(function (n) { return n.isOrder; });
    var over = orders.filter(function (n) { return (n.status === 'pending' || n.status === 'confirmed') && n.expectedDate && n.expectedDate < td; }).length;
    var thisM = D.notes.filter(function (n) { return n.date.slice(0, 7) === td.slice(0, 7); }).length;
    h += '<div class="kpis4">' + kpi('blue', 'note', t('total_orders'), B(orders.length)) + kpi('amber', 'clock', t('ns_pending'), B(orders.filter(function (n) { return n.status === 'pending'; }).length)) + kpi('green', 'check', t('ns_confirmed'), B(orders.filter(function (n) { return n.status === 'confirmed'; }).length)) + kpi(over ? 'red' : 'purple', 'calendar', over ? t('overdue') : t('this_month'), B(over || thisM)) + '</div>';
    h += '<div class="filterrow">' + U.searchbox('noteq', S.noteQ || '', t('search')).replace('id="noteq"', 'id="noteq" data-bind="noteQ"') + '</div>';
    h += U.chips([['all', t('all')], ['pending', t('ns_pending')], ['confirmed', t('ns_confirmed')], ['completed', t('ns_completed')], ['cancelled', t('ns_cancelled')], ['plain', t('plain_notes')]], S.noteF, 'notef');
    h += U.seg([['added', t('sort_added')], ['expected', t('sort_expected')]], S.noteSort, 'notesort');
    var list = D.notes.filter(function (n) { return S.noteF === 'all' || (S.noteF === 'plain' ? !n.isOrder : n.status === S.noteF && n.isOrder); }).filter(function (n) {
      return !q || ((n.title || '') + ' ' + (n.text || '') + ' ' + (n.customerName || '') + ' ' + (n.phone || '') + ' ' + (n.productId ? U.prodName(n.productId) : '')).toLowerCase().indexOf(q) >= 0;
    });
    list = S.noteSort === 'expected' ? list.slice().sort(function (a, b) { return (a.expectedDate || '9999') < (b.expectedDate || '9999') ? -1 : 1; }) : U.newest(list);
    h += list.length ? list.map(function (n) {
      var late = n.isOrder && (n.status === 'pending' || n.status === 'confirmed') && n.expectedDate && n.expectedDate < td, sale = n.saleId ? K.byId(D.sales, n.saleId) : null, pr = n.productId ? K.byId(D.products, n.productId) : null;
      var acts = '<div class="nact"><button class="iconbtn" data-act="edit_note" data-id="' + n.id + '" aria-label="' + t('edit') + '">' + V.icon('edit', 18) + '</button><button class="iconbtn dg" data-act="del_note" data-id="' + n.id + '" aria-label="' + t('delete') + '">' + V.icon('trash', 18) + '</button></div>';
      if (!n.isOrder) return '<div class="ncard"><div class="nth"><span class="ibox amber">' + V.icon('note', 22) + '</span></div><div class="nb2"><div class="t">' + esc(n.title || (n.text || '').slice(0, 40)) + '</div><div class="s" style="white-space:pre-wrap">' + esc((n.text || '').length > 200 ? n.text.slice(0, 200) + '…' : n.text) + '</div><div class="s">' + U.dt(n.date) + '</div></div>' + acts + '</div>';
      return '<div class="ncard"><div class="nth">' + (pr ? '<div class="thumb" style="width:64px;height:50px">' + V.crate(pr.color, 56) + '</div><span class="muted">' + esc(pr.code || '') + '</span>' : '<span class="ibox amber">' + V.icon('truck', 22) + '</span>') + '</div><div class="nb2"><div class="t">' + esc(n.customerName || n.title || U.prodName(n.productId)) + '</div><div class="s">' + (n.phone ? V.icon('phone', 12) + ' ' + B(esc(n.phone)) + ' · ' : '') + (pr ? esc(pr.name) + ' × ' + B(K.groupInt(n.qty)) : '') + '</div>' +
        (n.expectedDate ? '<div class="s">' + V.icon('calendar', 12) + ' ' + t('expected_date') + ': ' + U.dt(n.expectedDate) + '</div>' : '') + (n.text ? '<div class="s">' + esc(n.text) + '</div>' : '') +
        '<div style="margin-top:5px">' + nbadge(n) + (late ? ' ' + U.badge(t('overdue'), 'red') : '') + (sale ? ' ' + U.badge(t('invoiced') + ' ' + U.invNo(sale.no), 'green') : '') + '</div>' +
        (n.productId && n.qty && !n.saleId && n.status !== 'cancelled' ? '<button class="btn sm" style="margin-top:6px" data-act="note_invoice" data-id="' + n.id + '">' + t('convert_to_invoice') + '</button>' : sale ? '<button class="btn sm ghost" style="margin-top:6px" data-act="note_view_invoice" data-id="' + sale.id + '">' + t('view_invoice') + '</button>' : '') + '</div>' + acts + '</div>';
    }).join('') : '<div class="card">' + U.empty(t('no_notes'), 'note') + '</div>';
    h += '<div class="btns"><button class="btn" data-act="export_notes">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_sales">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_note">+ ' + t('new_note') + '</button></div>';
  };
  X.del_note = function (el) { var n = K.byId(U.D.notes, el.dataset.id); F.remove('note', el.dataset.id, n ? (n.title || n.customerName || n.date) : '', function () { U.render(true); }); };
  X.export_notes = function () {
    var D = U.D, rows = [[t('date'), t('order_customer'), t('phone'), t('product'), t('quantity'), t('expected_date'), t('order_status'), t('note_text')]];
    D.notes.forEach(function (n) { rows.push([n.date, n.customerName || n.title || '', n.phone || '', n.productId ? U.prodName(n.productId) : '', n.qty || '', n.expectedDate || '', n.isOrder ? t('ns_' + n.status) : '', n.text || '']); });
    csv('khaldi_notes_' + K.today() + '.csv', rows);
  };
  X.notef = function (el) { S.noteF = el.dataset.id; U.render(true); };
  X.notesort = function (el) { S.noteSort = el.dataset.id; U.render(true); };
  X.note_invoice = function (el) { F.noteToInvoice(el.dataset.id); };
  X.note_view_invoice = function (el) { U.go('invoice', el.dataset.id); };

  /* ================= assistant (offline, rule-based, real data only) ================= */
  function actx() { return { K: K, lang: U.lang(), money: U.moneyTxt, qty: K.fmtQty, date: K.fmtDate, catName: function (c) { return U.catName(c.id); } }; }
  function bubbleA(m) {
    return '<div class="chatbubble a">' + m.blocks.map(function (b) {
      return (b.h ? '<h4>' + esc(b.h) + '</h4>' : '') + b.rows.map(function (r) { return '<div class="cr"><span>' + esc(r[0]) + '</span><b><bdi dir="auto">' + esc(r[1]) + '</bdi></b></div>'; }).join('') + (b.text ? '<div class="' + (b.h || b.rows.length ? 'muted' : '') + '" style="margin-top:4px">' + esc(b.text) + '</div>' : '');
    }).join('') + '</div>';
  }
  W.assistant = function () {
    var A = window.KPAssistant, h = '<div class="chat">';
    h += '<div class="chatbubble a">' + esc(A.hello(U.lang())) + '</div>';
    S.chat.forEach(function (m) { h += m.role === 'u' ? '<div class="chatbubble u">' + esc(m.text) + '</div>' : bubbleA(m); });
    h += '</div><div class="chips">' + A.suggestions(U.lang()).map(function (q) { return '<button class="chip" data-act="chat_chip" data-q="' + esc(q) + '">' + esc(q) + '</button>'; }).join('') + '</div>';
    if (S.chat.length) h += '<button class="btn sm ghost block" data-act="chat_clear">' + t('chat_clear') + '</button>';
    h += '<div class="chatbar"><input id="chatq" type="text" autocomplete="off" placeholder="' + esc(t('chat_ph')) + '"><button data-act="chat_send" aria-label="' + esc(t('send')) + '">' + V.icon('send', 22) + '</button></div><div class="muted" style="text-align:center;margin-top:8px">' + t('chat_note') + '</div>';
    return h;
  };
  function ask(q) {
    q = String(q || '').trim(); if (!q) return;
    var r; try { r = window.KPAssistant.ask(U.D, q, actx()); } catch (e) { r = { blocks: [{ h: '', rows: [], text: t('chat_error') }] }; }
    S.chat.push({ role: 'u', text: q }); S.chat.push({ role: 'a', blocks: r.blocks }); S.chatScroll = true; U.render();
  }
  X.chat_send = function () { var el = U.$('#chatq'); if (el) ask(el.value); };
  X.chat_chip = function (el) { ask(el.dataset.q); };
  X.chat_clear = function () { S.chat = []; U.render(true); };
  U.afterRender = function (R) {
    if (R !== 'assistant') return;
    var el = U.$('#chatq'); if (el) el.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); X.chat_send(); } };
    if (S.chatScroll) { S.chatScroll = false; var m = U.$('#main'); m.scrollTop = m.scrollHeight; }
  };

  /* ================= customise: shortcuts, icons, window (section) order ================= */
  W.customize = function () {
    var h = '<div class="alert blue">' + t('customize_help') + '</div>';
    h += U.sec(t('home_sections'));
    var so = secOrdered();
    h += so.map(function (id, i) {
      var off = secHidden(id);
      return '<div class="cz-row' + (off ? ' off' : '') + '"><button class="tl" data-act="cz_sec_toggle" data-id="' + id + '" aria-label="' + t('show_hide') + '">' + V.icon(off ? 'eyeoff' : 'eye', 20) + '</button><div class="nm">' + esc(t(SECL[id])) + '</div><button class="mb" data-act="cz_sec_up" data-id="' + id + '"' + (i === 0 ? ' disabled' : '') + '>' + V.icon('up', 20) + '</button><button class="mb" data-act="cz_sec_down" data-id="' + id + '"' + (i === so.length - 1 ? ' disabled' : '') + '>' + V.icon('down', 20) + '</button></div>';
    }).join('');
    h += U.sec(t('shortcuts_title')) + '<div class="muted" style="margin:0 2px 8px">' + t('shortcuts_help') + '</div>';
    var o = scOrdered();
    h += o.map(function (id, i) {
      var off = scHidden(id);
      return '<div class="cz-row' + (off ? ' off' : '') + '"><button class="tl" data-act="cz_toggle" data-id="' + id + '" aria-label="' + t('show_hide') + '">' + V.icon(off ? 'eyeoff' : 'eye', 20) + '</button><button class="tl" data-act="cz_icon" data-id="' + id + '" aria-label="' + t('change_icon') + '">' + V.tile(iconOf(id), 30) + '</button><div class="nm">' + esc(t(LBL[id])) + '</div><button class="mb" data-act="cz_up" data-id="' + id + '"' + (i === 0 ? ' disabled' : '') + '>' + V.icon('up', 20) + '</button><button class="mb" data-act="cz_down" data-id="' + id + '"' + (i === o.length - 1 ? ' disabled' : '') + '>' + V.icon('down', 20) + '</button></div>';
    }).join('');
    return h + '<button class="btn danger-o block" data-act="cz_reset">' + V.icon('undo', 18) + ' ' + t('reset_layout') + '</button>';
  };
  X.cz_up = function (el) { saveLayout(function (l) { move(l.order, el.dataset.id, -1); }); };
  X.cz_down = function (el) { saveLayout(function (l) { move(l.order, el.dataset.id, 1); }); };
  X.cz_toggle = function (el) { saveLayout(function (l) { toggle(l.hidden, el.dataset.id); }); };
  X.cz_sec_up = function (el) { saveLayout(function (l) { move(l.secOrder, el.dataset.id, -1); }); };
  X.cz_sec_down = function (el) { saveLayout(function (l) { move(l.secOrder, el.dataset.id, 1); }); };
  X.cz_sec_toggle = function (el) { saveLayout(function (l) { toggle(l.secHidden, el.dataset.id); }); };
  X.cz_icon = function (el) {
    var id = el.dataset.id, cur = iconOf(id);
    U.showModal('<h3>' + t('change_icon') + ': ' + esc(t(LBL[id])) + '</h3><div class="iconpick">' + V.tileNames().map(function (n) { return '<button class="' + (n === cur ? 'on' : '') + '" data-act="cz_seticon" data-id="' + id + '" data-icon="' + n + '">' + V.tile(n, 34) + '<span>' + esc(LBL[n] ? t(LBL[n]) : n) + '</span></button>'; }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
  };
  X.cz_seticon = function (el) { var id = el.dataset.id, ic = el.dataset.icon; U.closeModal(); saveLayout(function (l) { if (ic === id) delete l.icons[id]; else l.icons[id] = ic; }); };
  X.cz_reset = function () { U.confirmBox(t('reset_layout'), t('reset_layout_q'), t('reset'), function () { U.commit(function (d) { d.settings.layout = { hidden: [], order: [], icons: {}, secOrder: [], secHidden: [] }; }); U.render(true); U.toast(t('saved_ok'), 'ok'); }, true); };

  /* ================= more: every section, in the user's order ================= */
  W.more = function () {
    var h = '<div class="tiles">' + scOrdered().map(tileBtn).join('') + '</div>';
    return h + '<div class="card" style="margin-top:14px"><div class="row tap" data-act="goto" data-id="settings"><div class="ibox">' + V.icon('settings', 22) + '</div><div class="main"><div class="t">' + t('v_settings') + '</div></div>' + V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 20) + '</div></div>';
  };
})();
