/* KHALDI PLAST - visual helpers: icons, crate illustrations, invoice watermark, SVG charts.
 * Pure string builders (no DOM), colours come from the CSS design system variables. */
(function () {
  'use strict';
  var V = window.KPV = {};

  /* ---------- UI icons (stroke, inherit currentColor) ---------- */
  var S = 'fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"';
  var UI = {
    home: '<path d="M3.5 11 12 4l8.5 7"/><path d="M5.5 9.8V20h13V9.8"/><path d="M10 20v-5.5h4V20"/>',
    list: '<rect x="4" y="4.5" width="16" height="4.6" rx="1.4"/><rect x="4" y="10.2" width="16" height="4.6" rx="1.4"/><rect x="4" y="15.9" width="16" height="4.1" rx="1.4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    bars: '<path d="M6 20V11M12 20V5M18 20v-6"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    chevL: '<path d="M14.5 6l-6 6 6 6"/>',
    chevR: '<path d="M9.5 6l6 6-6 6"/>',
    chevD: '<path d="M6 9.5l6 6 6-6"/>',
    bell: '<path d="M6.5 16.5V11a5.5 5.5 0 0 1 11 0v5.5l1.5 2h-14z"/><path d="M10 20.5a2.1 2.1 0 0 0 4 0"/>',
    calendar: '<rect x="4" y="5.5" width="16" height="14.5" rx="3"/><path d="M4 10h16M8.5 3.8v3.4M15.5 3.8v3.4"/>',
    print: '<path d="M7 9V4h10v5"/><rect x="4" y="9" width="16" height="8" rx="2"/><rect x="7" y="14" width="10" height="6" rx="1"/>',
    share: '<circle cx="6.5" cy="12" r="2.4"/><circle cx="17.5" cy="6.5" r="2.4"/><circle cx="17.5" cy="17.5" r="2.4"/><path d="M8.6 10.8l6.8-3.1M8.6 13.2l6.8 3.1"/>',
    edit: '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17z"/><path d="M13.5 8l3 3"/>',
    trash: '<path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l.9 12.2h9.2L17.5 7M10 10.5v5.5M14 10.5v5.5"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4L18 18M18 6l-1.6 1.6M7.6 16.4L6 18"/>',
    save: '<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>',
    truck: '<path d="M3 6.5h11v9H3zM14 10h4l3 3v2.5h-7"/><circle cx="7.5" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
    user: '<circle cx="12" cy="8.5" r="3.6"/><path d="M5 20c.6-3.7 3.4-5.6 7-5.6s6.4 1.9 7 5.6"/>',
    users: '<circle cx="9" cy="8.5" r="3.2"/><path d="M3 19.5c.5-3.3 2.9-5 6-5s5.5 1.7 6 5"/><circle cx="17" cy="9.5" r="2.5"/><path d="M16.5 14.6c2.4.1 4.1 1.5 4.5 4"/>',
    phone: '<path d="M7 4h3l1.5 4-2 1.3a10 10 0 0 0 5.2 5.2l1.3-2 4 1.5v3a2 2 0 0 1-2.2 2A15.5 15.5 0 0 1 5 6.2 2 2 0 0 1 7 4z"/>',
    wallet: '<rect x="3.5" y="6" width="17" height="13" rx="3"/><path d="M3.5 10h17M16 14.5h1.6"/>',
    tag: '<path d="M4 12.5V5h7.5L20 13.5 13.5 20z"/><circle cx="8.5" cy="9" r="1.2"/>',
    note: '<path d="M6 4h9l3 3v13H6z"/><path d="M9 10h6M9 14h6"/>',
    box: '<path d="M12 3.5l8 4v9l-8 4-8-4v-9z"/><path d="M4 7.5l8 4 8-4M12 11.5v9"/>',
    scale: '<path d="M12 4v16M6 20h12M5 8h14"/><path d="M5 8l-2.5 6a2.8 2.8 0 0 0 5 0zM19 8l-2.5 6a2.8 2.8 0 0 0 5 0z"/>',
    lock: '<rect x="5.5" y="10.5" width="13" height="9.5" rx="2.4"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    upload: '<path d="M12 16V5M7.5 9.5L12 5l4.5 4.5M5 19h14"/>',
    download: '<path d="M12 4v11M7.5 10.5L12 15l4.5-4.5M5 19h14"/>',
    globe: '<circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4c2.5 2.3 3.5 5 3.5 8s-1 5.7-3.5 8c-2.5-2.3-3.5-5-3.5-8s1-5.7 3.5-8z"/>',
    alert: '<path d="M12 4l9 15.5H3z"/><path d="M12 10v4.5M12 17.2v.2"/>',
    clock: '<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>',
    undo: '<path d="M9 7L4.5 11.5 9 16"/><path d="M5 11.5h8.5a5 5 0 0 1 0 10"/>',
    machine: '<rect x="3.5" y="9" width="12" height="9" rx="1.5"/><path d="M15.5 12h3l2 2.5V18h-5M7 9V5.5h5V9"/>',
    chat: '<path d="M4.5 5.5h15v10h-7l-4.5 3.5v-3.5h-3.5z"/><path d="M8.5 9.5h7M8.5 12.2h4"/>',
    table: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.4"/><path d="M3.5 9.5h17M3.5 14.5h17M9.5 9.5v10M15 9.5v10"/>',
    sliders: '<path d="M5 7h9M18 7h1M5 17h1M10 17h9"/><circle cx="16" cy="7" r="2.2"/><circle cx="8" cy="17" r="2.2"/>',
    pin: '<path d="M12 21s6.5-5.6 6.5-11a6.5 6.5 0 0 0-13 0c0 5.4 6.5 11 6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
    send: '<path d="M4 12l16-7-6 15-2.6-6.2z"/><path d="M11.4 13.8L20 5"/>',
    up: '<path d="M6 14.5l6-6 6 6"/>',
    down: '<path d="M6 9.5l6 6 6-6"/>',
    mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2.4"/><path d="M4 7l8 6 8-6"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    eyeoff: '<path d="M3 3l18 18M9.9 5.8A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a16 16 0 0 1-3 3.8M6.3 7.6A15.7 15.7 0 0 0 2.5 12S6 18.5 12 18.5c1.4 0 2.7-.3 3.8-.8"/>'
  };
  V.icon = function (name, size, cls) {
    return '<svg class="ic ' + (cls || '') + '" width="' + (size || 22) + '" height="' + (size || 22) + '" viewBox="0 0 24 24" ' + S + ' aria-hidden="true">' + (UI[name] || '') + '</svg>';
  };

  /* ---------- coloured tiles for the home grid (filled, two-tone like the reference) ---------- */
  var TILE = {
    production: ['#34A853', '<path d="M3.5 20.5V10l5 2.8V10l5 2.8V6.5h3v14z" fill="currentColor"/><path d="M16.5 3.5v3M19.5 5l-3 1.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M6 17.5h2M11 17.5h2M16 17.5h1.6" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/>'],
    purchases: ['#F59E2C', '<path d="M3 4.5h2.6l1.2 10h10.2l1.6-7.2H7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="19" r="1.8" fill="currentColor"/><circle cx="17" cy="19" r="1.8" fill="currentColor"/><path d="M8 9.3h10.4l-.9 3.6H8.7z" fill="currentColor" opacity=".35"/>'],
    sales: ['#3B8BF0', '<path d="M7 3.5h7.5L19 8v12a1.5 1.5 0 0 1-1.5 1.5h-10A1.5 1.5 0 0 1 6 20V5A1.5 1.5 0 0 1 7 3.5z" fill="currentColor"/><path d="M14.5 3.5V8H19" fill="#fff" opacity=".45"/><path d="M9 12h7M9 15.3h7M9 18.4h4.5" stroke="#fff" stroke-width="1.7" stroke-linecap="round"/>'],
    expenses: ['#E5493A', '<path d="M6 8h12l1 11.5a1.5 1.5 0 0 1-1.5 1.6h-11A1.5 1.5 0 0 1 5 19.5z" fill="currentColor"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="14.2" r="2.7" fill="none" stroke="#fff" stroke-width="1.7"/>'],
    debts: ['#3B7BE8', '<rect x="3.5" y="3.5" width="17" height="17" rx="4.5" fill="currentColor"/><path d="M14.6 9c-.5-1-1.5-1.5-2.7-1.5-1.5 0-2.6.8-2.6 2 0 3 5.4 1.4 5.4 4.2 0 1.2-1.1 2-2.7 2-1.3 0-2.4-.6-2.9-1.7M12 6v1.5M12 16.5V18" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>'],
    stock: ['#12907F', '<path d="M12 2.8l8.2 4.4v9.6L12 21.2l-8.2-4.4V7.2z" fill="currentColor"/><path d="M3.8 7.2L12 11.6l8.2-4.4" fill="none" stroke="#fff" stroke-width="1.5" opacity=".75"/><path d="M12 11.6v9.6" stroke="#fff" stroke-width="1.5" opacity=".75"/>'],
    invoices: ['#7B4FD0', '<path d="M6.5 3h8l4 4v13a1.5 1.5 0 0 1-1.5 1.5H6.5A1.5 1.5 0 0 1 5 20V4.5A1.5 1.5 0 0 1 6.5 3z" fill="currentColor"/><path d="M14.5 3v4h4" fill="#fff" opacity=".4"/><path d="M8.5 11.5h7M8.5 15h7M8.5 18h4" stroke="#fff" stroke-width="1.7" stroke-linecap="round"/>'],
    reports: ['#34A853', '<rect x="4" y="12" width="4.2" height="8.5" rx="1" fill="currentColor"/><rect x="9.9" y="7" width="4.2" height="13.5" rx="1" fill="currentColor"/><rect x="15.8" y="3.5" width="4.2" height="17" rx="1" fill="currentColor"/>'],
    customers: ['#0E9AD7', '<circle cx="12" cy="7.6" r="3.9" fill="currentColor"/><path d="M4 20.5c.5-4 3.5-6.3 8-6.3s7.5 2.3 8 6.3z" fill="currentColor"/>'],
    suppliers: ['#E58A1F', '<path d="M2.8 6.5h11.2v9.5H2.8z" fill="currentColor"/><path d="M14 9.8h4.2l3 3.2v3H14z" fill="currentColor" opacity=".75"/><circle cx="7.2" cy="17.8" r="2" fill="currentColor" stroke="#fff" stroke-width="1"/><circle cx="17.2" cy="17.8" r="2" fill="currentColor" stroke="#fff" stroke-width="1"/>'],
    notes: ['#D9A400', '<path d="M5.5 3.5h13a1.5 1.5 0 0 1 1.5 1.5v14a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19V5a1.5 1.5 0 0 1 1.5-1.5z" fill="currentColor"/><path d="M8 8.5h8M8 12h8M8 15.5h5" stroke="#fff" stroke-width="1.7" stroke-linecap="round"/>'],
    prodtable: ['#1E88C8', '<rect x="3.5" y="4" width="17" height="16" rx="2.6" fill="currentColor"/><path d="M3.5 9.4h17M3.5 14.7h17M9.2 9.4V20M14.8 9.4V20" stroke="#fff" stroke-width="1.4"/>'],
    assistant: ['#7B4FD0', '<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v9a1.5 1.5 0 0 1-1.5 1.5H11l-4.5 4v-4h-1A1.5 1.5 0 0 1 4 14.5z" fill="currentColor"/><circle cx="9" cy="10" r="1.2" fill="#fff"/><circle cx="12.5" cy="10" r="1.2" fill="#fff"/><circle cx="16" cy="10" r="1.2" fill="#fff"/>'],
    transactions: ['#4B6A9B', '<rect x="4" y="4" width="16" height="4.6" rx="1.6" fill="currentColor"/><rect x="4" y="9.7" width="16" height="4.6" rx="1.6" fill="currentColor" opacity=".8"/><rect x="4" y="15.4" width="16" height="4.6" rx="1.6" fill="currentColor" opacity=".6"/>'],
    backup: ['#0C6FB8', '<path d="M5 3.5h11l3.5 3.5v12.5A1.5 1.5 0 0 1 18 21H6a1.5 1.5 0 0 1-1.5-1.5V5A1.5 1.5 0 0 1 5 3.5z" fill="currentColor"/><path d="M8 3.5v5h7v-5M8 21v-6.5h8V21" fill="#fff" opacity=".85"/>'],
    settings: ['#5B6B84', '<circle cx="12" cy="12" r="3.2" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>'],
    customize: ['#E0457B', '<path d="M5 7h9M18 7h1M5 17h1M10 17h9" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="16" cy="7" r="2.6" fill="currentColor"/><circle cx="8" cy="17" r="2.6" fill="currentColor"/>'],
    shifts: ['#12907F', '<circle cx="12" cy="12" r="8.4" fill="currentColor"/><path d="M12 7v5.2l3.3 2" stroke="#fff" stroke-width="1.9" stroke-linecap="round" fill="none"/>'],
    workers: ['#2F80ED', '<circle cx="9" cy="7.8" r="3.6" fill="currentColor"/><path d="M2.5 20c.4-3.6 3-5.8 6.5-5.8s6.1 2.2 6.5 5.8z" fill="currentColor"/><circle cx="17" cy="9" r="2.8" fill="currentColor" opacity=".75"/><path d="M16.2 14.2c2.6 0 4.8 1.6 5.3 4.8h-4" fill="currentColor" opacity=".75"/>']
  };
  V.tile = function (name, size) {
    var t = TILE[name]; if (!t) return '';
    return '<svg class="tile-ic" width="' + (size || 40) + '" height="' + (size || 40) + '" viewBox="0 0 24 24" style="color:' + t[0] + '" aria-hidden="true">' + t[1] + '</svg>';
  };
  V.tileColor = function (name) { return TILE[name] ? TILE[name][0] : '#2F80ED'; };

  /* ---------- crate illustration (product thumbnails, watermark) ---------- */
  var CRATE = { blue: ['#2F6FDB', '#1B4DAA', '#4F8EF0'], green: ['#34A853', '#217A3A', '#59C575'], red: ['#E5493A', '#B02A1D', '#F26D5F'], black: ['#3A3F4B', '#1E222B', '#555C6B'], gray: ['#8A94A6', '#5F6B80', '#A8B1C2'] };
  V.crate = function (color, size) {
    var c = CRATE[color] || CRATE.gray, w = size || 56, h = Math.round(w * 0.78), id = 'cr' + Math.random().toString(36).slice(2, 7);
    var slots = '';
    for (var i = 0; i < 6; i++) slots += '<rect x="' + (9 + i * 8.6) + '" y="21" width="5.4" height="11" rx="1.6" fill="' + c[1] + '"/>';
    return '<svg class="crate" width="' + w + '" height="' + h + '" viewBox="0 0 64 50" aria-hidden="true"><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + c[2] + '"/><stop offset="1" stop-color="' + c[0] + '"/></linearGradient></defs>' +
      '<path d="M3 15 8 7h48l5 8v26a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4z" fill="url(#' + id + ')"/>' +
      '<path d="M3 15h58" stroke="' + c[1] + '" stroke-width="2.4" opacity=".55"/><rect x="3" y="15" width="58" height="5" fill="' + c[2] + '" opacity=".55"/>' + slots +
      '<rect x="14" y="8.4" width="36" height="3.6" rx="1.8" fill="' + c[1] + '" opacity=".6"/><rect x="3" y="35" width="58" height="3.2" fill="' + c[1] + '" opacity=".28"/></svg>';
  };
  // Outline crate used as a very pale background watermark on invoices (never darker than the text).
  V.watermark = function () {
    function one(x, y, s, r) {
      return '<g transform="translate(' + x + ' ' + y + ') rotate(' + r + ') scale(' + s + ')" fill="none" stroke="#9db4d6" stroke-width="1.6" stroke-linejoin="round">' +
        '<path d="M6 30 16 12h96l10 18v62a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8z"/><path d="M6 30h116M6 70h116M16 12l-4 18M112 12l4 18"/>' +
        '<path d="M30 40v22M48 40v22M66 40v22M84 40v22M102 40v22M30 80v22M48 80v22M66 80v22M84 80v22M102 80v22"/><rect x="36" y="16" width="56" height="7" rx="3.5"/></g>';
    }
    return '<svg class="wm" viewBox="0 0 600 800" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' + one(10, 120, 1.9, -4) + one(70, 270, 1.5, 3) + one(300, 560, 2.3, -3) + one(420, 460, 1.5, 4) + '</svg>';
  };

  /* ---------- charts (SVG). Always laid out left-to-right: time flows left to right in every language. ---------- */
  var PAL = ['#2F6FDB', '#E5493A', '#F5A524', '#34A853', '#8B5CF6', '#14B8A6', '#6B7A99'];
  V.palette = PAL; V.tileNames = function () { return Object.keys(TILE); };
  function compact(n) {
    var a = Math.abs(n); if (a >= 1e6) return (Math.round(n / 1e5) / 10) + 'M'; if (a >= 1e3) return Math.round(n / 1e3) + 'K'; return String(Math.round(n));
  }
  V.compact = compact;
  function niceMax(v) {
    if (v <= 0) return 1; var p = Math.pow(10, Math.floor(Math.log(v) / Math.LN10)), f = v / p;
    var n = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10; return n * p;
  }
  V.bars = function (vals, labels, color, h) {
    var W = 320, H = h || 150, L = 34, B = 20, T = 8, n = vals.length, mx = niceMax(Math.max.apply(null, vals.concat([0])) ), iw = W - L - 4, ih = H - B - T;
    var g = '', i;
    for (i = 0; i <= 3; i++) { var y = T + ih - ih * i / 3; g += '<line x1="' + L + '" x2="' + W + '" y1="' + y + '" y2="' + y + '" class="grid"/><text x="' + (L - 4) + '" y="' + (y + 3) + '" class="axis" text-anchor="end">' + compact(mx * i / 3) + '</text>'; }
    var bw = iw / n, out = '';
    for (i = 0; i < n; i++) {
      var bh = mx ? vals[i] / mx * ih : 0, x = L + i * bw + bw * 0.18;
      if (vals[i] > 0) out += '<rect x="' + x.toFixed(1) + '" y="' + (T + ih - bh).toFixed(1) + '" width="' + (bw * 0.64).toFixed(1) + '" height="' + Math.max(bh, 1.5).toFixed(1) + '" rx="2" fill="' + color + '"/>';
      if (labels && (n <= 12 || i % Math.ceil(n / 12) === 0 || i === n - 1)) out += '<text x="' + (x + bw * 0.32).toFixed(1) + '" y="' + (H - 5) + '" class="axis" text-anchor="middle">' + labels[i] + '</text>';
    }
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img">' + g + out + '</svg>';
  };
  V.lines = function (series, labels, h) {
    var W = 320, H = h || 170, L = 34, B = 20, T = 8, ih = H - B - T, iw = W - L - 8, n = labels.length, all = [], i;
    series.forEach(function (s) { s.values.forEach(function (v) { if (v != null) all.push(v); }); });
    var mx = niceMax(Math.max.apply(null, all.concat([0]))), mn = Math.min.apply(null, all.concat([0])), lo = mn < 0 ? -niceMax(-mn) : 0, span = (mx - lo) || 1;
    var g = '';
    for (i = 0; i <= 3; i++) { var y = T + ih - ih * i / 3; g += '<line x1="' + L + '" x2="' + W + '" y1="' + y + '" y2="' + y + '" class="grid"/><text x="' + (L - 4) + '" y="' + (y + 3) + '" class="axis" text-anchor="end">' + compact(lo + span * i / 3) + '</text>'; }
    var out = '';
    series.forEach(function (s) {
      var pts = [], d = '';
      s.values.forEach(function (v, k) { if (v == null) return; var x = L + (n > 1 ? iw * k / (n - 1) : iw / 2), y2 = T + ih - (v - lo) / span * ih; pts.push([x, y2]); });
      pts.forEach(function (p, k) { d += (k ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); });
      if (d) out += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>';
      pts.forEach(function (p) { out += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="2.8" fill="#fff" stroke="' + s.color + '" stroke-width="1.8"/>'; });
    });
    labels.forEach(function (lb, k) { var x = L + (n > 1 ? iw * k / (n - 1) : iw / 2); out += '<text x="' + x.toFixed(1) + '" y="' + (H - 5) + '" class="axis" text-anchor="middle">' + lb + '</text>'; });
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img">' + g + out + '</svg>';
  };

  /* smooth area/line chart with gradient fill (one or more series) */
  var areaN = 0;
  V.area = function (series, labels, h) {
    var W = 320, H = h || 170, L = 34, B = 20, T = 10, ih = H - B - T, iw = W - L - 8, n = labels.length, all = [], i, id = 'ag' + (++areaN);
    series.forEach(function (s) { s.values.forEach(function (v) { if (v != null) all.push(v); }); });
    var mx = niceMax(Math.max.apply(null, all.concat([0]))) || 1, g = '', defs = '', out = '';
    for (i = 0; i <= 3; i++) { var y = T + ih - ih * i / 3; g += '<line x1="' + L + '" x2="' + W + '" y1="' + y + '" y2="' + y + '" class="grid"/><text x="' + (L - 4) + '" y="' + (y + 3) + '" class="axis" text-anchor="end">' + compact(mx * i / 3) + '</text>'; }
    series.forEach(function (s, k) {
      defs += '<linearGradient id="' + id + k + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + s.color + '" stop-opacity=".38"/><stop offset="1" stop-color="' + s.color + '" stop-opacity=".02"/></linearGradient>';
      var pts = s.values.map(function (v, j) { return [L + (n > 1 ? iw * j / (n - 1) : iw / 2), T + ih - (v || 0) / mx * ih]; });
      if (!pts.length) return;
      var d = 'M' + pts[0][0].toFixed(1) + ' ' + pts[0][1].toFixed(1);
      for (var j = 0; j < pts.length - 1; j++) {
        var p0 = pts[j - 1] || pts[j], p1 = pts[j], p2 = pts[j + 1], p3 = pts[j + 2] || p2, t = 0.18;
        d += 'C' + (p1[0] + (p2[0] - p0[0]) * t).toFixed(1) + ' ' + Math.min(T + ih, Math.max(T, p1[1] + (p2[1] - p0[1]) * t)).toFixed(1) + ',' + (p2[0] - (p3[0] - p1[0]) * t).toFixed(1) + ' ' + Math.min(T + ih, Math.max(T, p2[1] - (p3[1] - p1[1]) * t)).toFixed(1) + ',' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1);
      }
      out += '<path d="' + d + 'L' + pts[pts.length - 1][0].toFixed(1) + ' ' + (T + ih) + 'L' + pts[0][0].toFixed(1) + ' ' + (T + ih) + 'Z" fill="url(#' + id + k + ')"/><path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="2.4" stroke-linecap="round"/>';
      var last = pts[pts.length - 1]; out += '<circle cx="' + last[0].toFixed(1) + '" cy="' + last[1].toFixed(1) + '" r="4" fill="#fff" stroke="' + s.color + '" stroke-width="2.2"/>';
    });
    labels.forEach(function (lb, j) { if (n <= 8 || j % Math.ceil(n / 8) === 0 || j === n - 1) { var x = L + (n > 1 ? iw * j / (n - 1) : iw / 2); out += '<text x="' + x.toFixed(1) + '" y="' + (H - 5) + '" class="axis" text-anchor="middle">' + lb + '</text>'; } });
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img"><defs>' + defs + '</defs>' + g + out + '</svg>';
  };
  V.donut = function (parts, center, sub) {
    var total = parts.reduce(function (a, p) { return a + p.value; }, 0), R = 46, C = 2 * Math.PI * R, off = 0, out = '';
    if (total <= 0) out = '<circle cx="60" cy="60" r="' + R + '" fill="none" stroke="#E6ECF5" stroke-width="15"/>';
    else parts.forEach(function (p) {
      var len = p.value / total * C; if (len <= 0) return;
      out += '<circle cx="60" cy="60" r="' + R + '" fill="none" stroke="' + p.color + '" stroke-width="15" stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 60 60)"/>';
      off += len;
    });
    return '<svg class="donut" viewBox="0 0 120 120" role="img">' + out + '<text x="60" y="' + (sub ? 59 : 66) + '" text-anchor="middle" class="d-main">' + center + '</text>' + (sub ? '<text x="60" y="74" text-anchor="middle" class="d-sub">' + sub + '</text>' : '') + '</svg>';
  };
})();
