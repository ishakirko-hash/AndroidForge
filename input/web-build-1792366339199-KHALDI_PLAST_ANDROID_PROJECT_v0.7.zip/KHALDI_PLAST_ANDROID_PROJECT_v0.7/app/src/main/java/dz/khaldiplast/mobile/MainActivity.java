package dz.khaldiplast.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

/**
 * KHALDI PLAST - hosts the local web app (assets/www) in a locked-down WebView.
 *
 * Business data is stored in a private file (files/khaldi_data.json) with an
 * atomic write (temp file + rename) and one previous copy (khaldi_data.prev.json).
 * The JavaScript bridge exposes only the methods the app really needs.
 */
public class MainActivity extends Activity {

    private static final String APP_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final int REQ_CREATE_DOCUMENT = 1001;
    private static final int REQ_FILE_CHOOSER = 1002;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingExportContent;
    private final Object fileLock = new Object();
    private static final Pattern SIDE_NAME = Pattern.compile("^(premigration_v[0-9]+|before_import)\\.json$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#F4F6FA"));
        setContentView(webView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);          // required: the app is a local web app
        s.setDomStorageEnabled(true);          // used only as a fallback store
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setGeolocationEnabled(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Never navigate away from the bundled app.
                return !APP_HOST.equals(request.getUrl().getHost());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new Bridge(), "KPAndroid");

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Ask the web app first; it returns true if it handled "back" itself.
        webView.evaluateJavascript("(window.KPBack ? window.KPBack() : false)", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) {
                    MainActivity.super.onBackPressed();
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.evaluateJavascript("(window.KPFlush ? window.KPFlush() : 0)", null);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (fileCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
            return;
        }

        if (requestCode == REQ_CREATE_DOCUMENT) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null
                    && pendingExportContent != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (os != null) {
                        os.write(pendingExportContent.getBytes(StandardCharsets.UTF_8));
                        os.flush();
                        ok = true;
                    }
                } catch (Exception e) {
                    ok = false;
                }
            }
            boolean cancelled = (resultCode != RESULT_OK);
            pendingExportContent = null;
            webView.evaluateJavascript(
                    "(window.KPExportDone && window.KPExportDone(" + ok + "," + cancelled + "))", null);
        }
    }

    // ---------------------------------------------------------------------
    // JavaScript bridge: only what the app needs.
    // ---------------------------------------------------------------------
    private class Bridge {

        private File dataFile() { return new File(getFilesDir(), "khaldi_data.json"); }
        private File tmpFile()  { return new File(getFilesDir(), "khaldi_data.json.tmp"); }
        private File prevFile() { return new File(getFilesDir(), "khaldi_data.prev.json"); }

        @JavascriptInterface
        public String loadData() {
            synchronized (fileLock) { return readFile(dataFile()); }
        }

        @JavascriptInterface
        public String loadPrevData() {
            synchronized (fileLock) { return readFile(prevFile()); }
        }

        @JavascriptInterface
        public boolean saveData(String json) {
            if (json == null || json.length() < 2) return false;
            synchronized (fileLock) {
                try {
                    File tmp = tmpFile();
                    FileOutputStream fos = new FileOutputStream(tmp);
                    try {
                        fos.write(json.getBytes(StandardCharsets.UTF_8));
                        fos.flush();
                        fos.getFD().sync();
                    } finally {
                        fos.close();
                    }
                    File data = dataFile();
                    File prev = prevFile();
                    if (data.exists()) {
                        if (prev.exists()) prev.delete();
                        data.renameTo(prev);
                    }
                    if (!tmp.renameTo(data)) {
                        // Fallback: restore previous copy so nothing is lost.
                        if (!data.exists() && prev.exists()) prev.renameTo(data);
                        return false;
                    }
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        }


        /** Opens Android's print dialog (A4) for the page currently shown; the user can choose "Save as PDF". */
        @JavascriptInterface
        public void printPage(final String jobName) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                        String name = (jobName == null || jobName.isEmpty()) ? "KHALDI PLAST" : jobName;
                        PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(name);
                        pm.print(name, adapter, new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Print is not available", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        /** Shares plain text (e.g. an invoice summary) through the Android share sheet. */
        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                        startActivity(Intent.createChooser(i, "KHALDI PLAST"));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Cannot share", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        /** Safety copies (pre-migration original, pre-restore copy). Only allow-listed names. */
        @JavascriptInterface
        public boolean saveSideFile(String name, String content) {
            if (name == null || content == null || !SIDE_NAME.matcher(name).matches()) return false;
            synchronized (fileLock) {
                try {
                    File tmp = new File(getFilesDir(), name + ".tmp");
                    FileOutputStream fos = new FileOutputStream(tmp);
                    try {
                        fos.write(content.getBytes(StandardCharsets.UTF_8));
                        fos.flush();
                        fos.getFD().sync();
                    } finally {
                        fos.close();
                    }
                    File dst = new File(getFilesDir(), name);
                    if (dst.exists()) dst.delete();
                    return tmp.renameTo(dst);
                } catch (Exception e) {
                    return false;
                }
            }
        }

        @JavascriptInterface
        public String loadSideFile(String name) {
            if (name == null || !SIDE_NAME.matcher(name).matches()) return "";
            synchronized (fileLock) { return readFile(new File(getFilesDir(), name)); }
        }

        @JavascriptInterface
        public void exportFile(final String fileName, final String mime, final String content) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        pendingExportContent = content;
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                        i.putExtra(Intent.EXTRA_TITLE, fileName);
                        startActivityForResult(i, REQ_CREATE_DOCUMENT);
                    } catch (Exception e) {
                        pendingExportContent = null;
                        Toast.makeText(MainActivity.this, "Cannot open file picker", Toast.LENGTH_LONG).show();
                        webView.evaluateJavascript(
                                "(window.KPExportDone && window.KPExportDone(false,false))", null);
                    }
                }
            });
        }
    }

    private static String readFile(File f) {
        if (!f.exists()) return "";
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }
}
