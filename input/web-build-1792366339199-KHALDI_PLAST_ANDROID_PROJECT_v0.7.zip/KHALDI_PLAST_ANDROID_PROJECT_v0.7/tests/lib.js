const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const mime={js:'text/javascript',css:'text/css',html:'text/html',png:'image/png',jpg:'image/jpeg'};
exports.start = async function(root, vw){
  const srv = http.createServer((req, res) => { const u=req.url.split('?')[0]; const f = path.join(root, u === '/' ? 'index.html' : u);
    fs.readFile(f, (e, b) => { if (e) { res.writeHead(404); res.end(); } else { res.writeHead(200, { 'Content-Type': mime[f.split('.').pop()]||'application/octet-stream' }); res.end(b); } }); }).listen(0);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: vw||390, height: 800 } });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE ' + m.text()); });
  await page.goto('http://localhost:' + srv.address().port + '/');
  return { page, browser, srv, errors, close: async()=>{ await browser.close(); srv.close(); } };
};
