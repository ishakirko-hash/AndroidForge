// Run with:  node tests/test_core.js
const fs = require('fs'), path = require('path');
const K = require('../app/src/main/assets/www/core.js');
let pass = 0, fail = 0;
function ok(cond, name) { if (cond) pass++; else { fail++; console.log('FAIL:', name); } }
function eq(a, b, name) { if (JSON.stringify(a) === JSON.stringify(b)) pass++; else { fail++; console.log('FAIL:', name, '\n   got     ', JSON.stringify(a), '\n   expected', JSON.stringify(b)); } }
function throws(fn, code, name) { try { fn(); fail++; console.log('FAIL (no error):', name); } catch (e) { if (e.code === code) pass++; else { fail++; console.log('FAIL (wrong error ' + e.code + '):', name); } } }
const sale = (d, o) => K.tx(d, x => K.recordSale(x, Object.assign({ method: 'cash' }, o)));

/* ---------- money & dates ---------- */
eq(K.parseMoney('1250.50', 'dzd').c, 125050, 'dzd decimal');
eq(K.parseMoney('1250', 'centimes').c, 1250, 'centimes mode');
ok(K.parseMoney('12.5', 'centimes').ok === false, 'centimes rejects decimals');
eq(K.parseMoney('١٢٥٠', 'dzd').c, 125000, 'arabic digits');
ok(K.parseMoney('-5', 'dzd').ok === false && K.parseMoney('1.234', 'dzd').ok === false && K.parseMoney('abc', 'dzd').ok === false, 'bad money rejected');
eq(K.fmtMoney(125050), '1,250.50', 'fmt with centimes');
eq(K.fmtMoney(75000000), '750,000', 'fmt whole');
eq(K.fmtDate('2026-10-14'), '14/10/2026', 'fmtDate');
eq(K.startOfWeek('2026-10-14'), '2026-10-12', 'week starts Monday');
eq(K.weekDates('2026-10-12')[6], '2026-10-18', 'week ends Sunday');
eq(K.monthRange('2026-02'), { from: '2026-02-01', to: '2026-02-28' }, 'month range');
eq(K.addMonths('2026-01', -1), '2025-12', 'addMonths');

/* ---------- fixed shifts ---------- */
eq(K.SHIFTS.map(s => s.start + '-' + s.end), ['08:00-16:00', '16:00-00:00', '00:00-08:00'], 'three fixed shifts');
function hrs(a, b) { const m = x => +x.slice(0, 2) * 60 + +x.slice(3); let d = m(b) - m(a); if (d <= 0) d += 1440; return d / 60; }
ok(K.SHIFTS.every(s => hrs(s.start, s.end) === 8 && s.hours === 8), 'every shift is 8 hours');
ok(K.SHIFTS.reduce((a, s) => a + s.hours, 0) === 24, 'shifts cover 24 hours');

/* ---------- purchases & production (good / defective, grams -> kg) ---------- */
let d = K.emptyData();
d = K.tx(d, x => { K.addSupplier(x, { name: 'Sup A' }); K.addCustomer(x, { name: 'Ahmed' }); K.addCustomer(x, { name: 'Ahmed' }); });
const sup = d.suppliers[0].id, [c1, c2] = d.customers.map(c => c.id);
ok(c1 !== c2, 'same names get unique ids');
d = K.tx(d, x => K.recordPurchase(x, { date: '2026-10-01', supplierId: sup, materialId: 'mat_granule', qty: 1000, unitCost: 15000, paid: 5000000 }));
d = K.tx(d, x => K.recordPurchase(x, { date: '2026-10-01', supplierId: sup, materialId: 'mat_broye', qty: 500, unitCost: 6000, paid: 0 }));
eq(d.purchases[0].total, 15000000, 'purchase total = qty x unit price');
eq(K.supplierBalance(d, sup), 15000000 - 5000000 + 3000000, 'supplier balance');
throws(() => K.tx(d, x => K.recordPurchase(x, { date: '2026-10-01', supplierId: sup, materialId: 'mat_granule', qty: 1, unitCost: 100, paid: 200 })), 'paid_exceeds_total', 'paid > total');

d = K.tx(d, x => K.recordProduction(x, { date: '2026-10-02', productId: 'prod_large', good: 100, defective: 10, grams: { mat_granule: 800, mat_broye: 200 } }));
eq(d.materials[0].stock, 1000 - 88, 'granule consumed for good AND defective crates (110 x 800 g = 88 kg)');
eq(d.materials[1].stock, 500 - 22, 'broye consumed (110 x 200 g = 22 kg)');
eq(d.products[0].stock, 100, 'only GOOD crates enter finished stock');
eq(d.production[0].consumption, [{ materialId: 'mat_granule', qty: 88 }, { materialId: 'mat_broye', qty: 22 }], 'grams converted to kg');
const pc = K.productionCost(d, d.production[0]);
eq(pc.total, 88 * 15000 + 22 * 6000, 'production cost uses average purchase price per kg');
eq(pc.defectCost, Math.round(pc.total * 10 / 110), 'defective share of cost');
eq(pc.perGood, Math.round(pc.total / 100), 'cost per good crate');
throws(() => K.tx(d, x => K.recordProduction(x, { date: '2026-10-02', productId: 'prod_large', good: 1, defective: 0, grams: { mat_granule: 1.5 } })), 'bad_grams', 'grams must be whole');
throws(() => K.tx(d, x => K.recordProduction(x, { date: '2026-10-02', productId: 'prod_large', good: 0, defective: 0, grams: {} })), 'bad_qty', 'nothing produced');
throws(() => K.tx(d, x => K.recordProduction(x, { date: '2026-10-02', productId: 'prod_large', good: 100000, defective: 0, grams: { mat_granule: 800 } })), 'insufficient_stock', 'not enough material');
const snap = JSON.stringify(d);
try { K.tx(d, x => K.recordProduction(x, { date: '2026-10-02', productId: 'prod_large', good: 100000, defective: 0, grams: { mat_granule: 800 } })); } catch (e) {}
eq(JSON.stringify(d), snap, 'failed operation leaves data untouched');
d = K.tx(d, x => K.recordProduction(x, { date: '2026-10-03', productId: 'prod_veg', good: 5, defective: 0, grams: {} }));
ok(K.productionCost(d, d.production[1]).noConsumption === true, 'no grams -> cost unknown, never invented');
d = K.tx(d, x => K.voidProduction(x, d.production[1].id, 'test'));

/* ---------- sales: multi-line invoice, discount, numbering ---------- */
d = sale(d, { date: '2026-10-14', customerId: c1, items: [{ productId: 'prod_large', qty: 40, unitPrice: 250000, weightG: 1500 }], discount: 100000, paid: 4000000 });
const s1 = d.sales[0];
eq([s1.no, s1.subtotal, s1.discount, s1.total], [1, 10000000, 100000, 9900000], 'invoice #1 totals');
eq(K.salePaid(d, s1.id), 4000000, 'paid');
eq(K.saleOutstanding(d, s1.id), 5900000, 'remaining');
eq(d.products[0].stock, 60, 'sale deducts finished stock');
throws(() => sale(d, { date: '2026-10-14', customerId: c1, items: [{ productId: 'prod_large', qty: 1, unitPrice: 100 }], discount: 200 }), 'discount_exceeds', 'discount > subtotal');
throws(() => sale(d, { date: '2026-10-14', items: [{ productId: 'prod_large', qty: 1, unitPrice: 1000 }], paid: 0 }), 'customer_required_for_credit', 'credit needs a customer');
throws(() => sale(d, { date: '2026-10-14', customerId: c1, items: [{ productId: 'prod_large', qty: 9999, unitPrice: 100 }], paid: 0 }), 'insufficient_stock', 'oversell blocked');
throws(() => sale(d, { date: '2026-10-14', customerId: c1, items: [] }), 'items_required', 'no items');
d = sale(d, { date: '2026-10-15', customerId: c2, items: [{ productId: 'prod_large', qty: 10, unitPrice: 200000 }], paid: 2000000 });
eq(d.sales[1].no, 2, 'invoice numbers are sequential');
eq(K.customerBalance(d, c2), 0, 'cash sale leaves no debt');
eq(K.customerBalance(d, c1), 5900000, 'other customer unaffected');

/* ---------- payments: individual transactions, editing, balances ---------- */
d = K.tx(d, x => K.recordCustomerPayment(x, { date: '2026-10-16', customerId: c1, saleId: s1.id, amount: 2000000 }));
d = K.tx(d, x => K.recordCustomerPayment(x, { date: '2026-10-17', customerId: c1, saleId: s1.id, amount: 1000000 }));
eq(d.payments.length, 4, 'each payment is its own record (2 initial + 2)');
eq(K.customerBalance(d, c1), 2900000, 'balance after payments');
throws(() => K.tx(d, x => K.recordCustomerPayment(x, { date: '2026-10-17', customerId: c1, saleId: s1.id, amount: 2900001 })), 'payment_exceeds_balance', 'overpayment blocked');
const payId = d.payments.find(p => p.saleId === s1.id && p.amount === 2000000).id;
const cntBefore = d.payments.length, salesBefore = JSON.stringify(d.sales), stockBefore = JSON.stringify(d.products.map(p => p.stock));
d = K.tx(d, x => K.editPayment(x, payId, { date: '2026-10-18', amount: 2500000, method: 'transfer', notes: 'corrected' }));
eq(d.payments.length, cntBefore, 'editing does not duplicate the payment');
eq(K.customerBalance(d, c1), 2400000, 'customer balance recalculated after payment edit');
eq(K.saleOutstanding(d, s1.id), 2400000, 'invoice remaining recalculated');
eq(K.totalCustomerDebt(d), 2400000, 'total customer debt recalculated');
eq(JSON.stringify(d.sales), salesBefore, 'editing a payment does not touch the invoice');
eq(JSON.stringify(d.products.map(p => p.stock)), stockBefore, 'editing a payment does not touch stock');
const ep = K.byId(d.payments, payId);
eq([ep.amount, ep.date, ep.method, ep.notes], [2500000, '2026-10-18', 'transfer', 'corrected'], 'new values stored');
eq(ep.history.length, 1, 'previous version kept in history');
eq(ep.history[0].before.amount, 2000000, 'history holds the original amount');
throws(() => K.tx(d, x => K.editPayment(x, payId, { date: '2026-10-18', amount: 99000000, method: 'cash' })), 'payment_exceeds_balance', 'edited payment cannot exceed invoice');
throws(() => K.tx(d, x => K.editPayment(x, payId, { date: '2026-10-18', amount: 0, method: 'cash' })), 'bad_amount', 'zero payment');
ok(K.monthlyReport(d, '2026-10').collected === 4000000 + 2000000 + 2500000 + 1000000, 'monthly collected follows the edited payment');
// payment attribution to the month it is dated in
d = K.tx(d, x => K.editPayment(x, payId, { date: '2026-11-02', amount: 2500000, method: 'cash' }));
eq(K.monthlyReport(d, '2026-11').collected, 2500000, 'edited payment moves to its new month');
d = K.tx(d, x => K.editPayment(x, payId, { date: '2026-10-18', amount: 2500000, method: 'cash' }));

/* ---------- editing a sale ---------- */
d = K.tx(d, x => K.editSale(x, s1.id, { date: '2026-10-14', customerId: c1, items: [{ productId: 'prod_large', qty: 45, unitPrice: 250000, weightG: 1500 }], discount: 100000, notes: 'edit' }));
eq(K.byId(d.products, 'prod_large').stock, 100 - 45 - 10, 'sale edit moves only the net stock difference');
eq(K.byId(d.sales, s1.id).total, 11250000 - 100000, 'sale total recalculated');
eq(K.byId(d.sales, s1.id).history.length, 1, 'sale history kept');
eq(K.byId(d.sales, s1.id).no, 1, 'invoice number preserved on edit');
throws(() => K.tx(d, x => K.editSale(x, s1.id, { date: '2026-10-14', customerId: c1, items: [{ productId: 'prod_large', qty: 1, unitPrice: 100 }], discount: 0 })), 'total_below_paid', 'cannot shrink invoice below what was paid');
throws(() => K.tx(d, x => K.editSale(x, s1.id, { date: '2026-10-14', customerId: c1, items: [{ productId: 'prod_large', qty: 999, unitPrice: 250000 }], discount: 0 })), 'insufficient_stock', 'sale edit respects stock');
eq(d.movements.filter(m => m.type === 'edit').length, 1, 'edit logged as a stock movement');

/* ---------- void keeps history ---------- */
const saleIdLast = d.sales[1].id, stBefore = K.byId(d.products, 'prod_large').stock;
d = K.tx(d, x => K.voidSale(x, saleIdLast, 'mistake'));
eq(K.byId(d.products, 'prod_large').stock, stBefore + 10, 'void sale restores stock');
ok(d.sales.length === 2 && d.sales[1].voided === true && d.payments.filter(p => p.saleId === saleIdLast).every(p => p.voided), 'voided sale and its payments kept in history');
eq(d.counters.invoice, 2, 'invoice counter never reused');

/* ---------- editing production / purchase / expense ---------- */
const prId = d.production[0].id, gStock = K.byId(d.materials, 'mat_granule').stock;
d = K.tx(d, x => K.editProduction(x, prId, { date: '2026-10-02', productId: 'prod_large', good: 90, defective: 10, grams: { mat_granule: 800, mat_broye: 200 } }));
eq(K.byId(d.products, 'prod_large').stock, stBefore + 10 - 10, 'production edit adjusts finished stock by the net change');
eq(K.byId(d.materials, 'mat_granule').stock, gStock + 8, 'fewer crates (100 instead of 110) -> 8 kg of granule returned');
d = K.tx(d, x => K.editProduction(x, prId, { date: '2026-10-02', productId: 'prod_large', good: 90, defective: 20, grams: { mat_granule: 800, mat_broye: 200 } }));
eq(K.byId(d.materials, 'mat_granule').stock, gStock, 'back to 110 crates (more defective) -> consumption back to 88 kg');
d = K.tx(d, x => K.addMachine(x, { name: 'M1' }));
const purId = d.purchases[0].id;
d = K.tx(d, x => K.editPurchase(x, purId, { date: '2026-10-01', supplierId: sup, materialId: 'mat_granule', qty: 1100, unitCost: 15000, notes: '' }));
eq(K.byId(d.materials, 'mat_granule').stock, gStock + 100, 'purchase edit moves net stock');
eq(K.byId(d.purchases, purId).total, 16500000, 'purchase total recalculated');
d = K.tx(d, x => K.recordExpense(x, { date: '2026-10-10', categoryId: 'cat_electricity', description: 'bill', amount: 500000 }));
d = K.tx(d, x => K.editExpense(x, d.expenses[0].id, { date: '2026-10-10', categoryId: 'cat_transport', description: 'bill', amount: 450000 }));
eq(K.expensesByCategory(d, '2026-10-01', '2026-10-31'), [{ categoryId: 'cat_transport', amount: 450000 }], 'expense edit moves category total (no double counting)');
throws(() => K.tx(d, x => K.recordExpense(x, { date: '2026-10-10', categoryId: 'nope', amount: 1 })), 'category_required', 'bad category');

/* ---------- monthly report ---------- */
d = K.tx(d, x => K.recordExpense(x, { date: '2026-10-20', categoryId: 'cat_salaries', amount: 1000000 }));
const m = K.monthlyReport(d, '2026-10');
const cost = K.productionCost(d, K.byId(d.production, prId));
eq(m.sales, K.byId(d.sales, s1.id).total, 'report: sales excludes the voided invoice');
eq(m.purchases, 16500000 + 3000000, 'report: purchases');
eq(m.expenses, 1450000, 'report: expenses');
eq([m.good, m.defective], [90, 20], 'report: good and defective crates');
eq(m.cratesSold, 45, 'report: crates sold');
eq(m.materialsCost, cost.total, 'report: materials CONSUMED (not purchased)');
ok(m.materialsCost !== m.purchases, 'purchases and consumption are different numbers');
eq(m.grossMargin, m.sales - cost.total, 'report: gross margin = sales - consumed materials');
eq(m.operatingProfit, m.sales - cost.total - m.expenses, 'report: operating profit = margin - expenses');
eq(m.customerDebt, K.customerBalance(d, c1) + K.customerBalance(d, c2), 'report: customer debt as of month end');
eq(m.supplierDebt, K.supplierBalance(d, sup), 'report: supplier debt as of month end');
const seriesLast = K.monthSeries(d, '2026-10', 3);
eq(seriesLast.map(s => s.ym), ['2026-08', '2026-09', '2026-10'], 'series months');
eq(seriesLast[2].sales, m.sales, 'series uses the same data as the report');
const sep = K.monthlyReport(d, '2026-09');
eq([sep.sales, sep.expenses, sep.good], [0, 0, 0], 'previous month empty');
eq(K.compareMonths(m, sep).sales, null, 'no % change against an empty month');
d = sale(d, { date: '2026-09-10', customerId: c1, items: [{ productId: 'prod_large', qty: 1, unitPrice: 5000000 }], paid: 5000000 });
const cmp = K.compareMonths(K.monthlyReport(d, '2026-10'), K.monthlyReport(d, '2026-09'));
ok(cmp.sales > 100, 'percent change vs previous month');
let noCost = K.emptyData();
noCost = K.tx(noCost, x => K.adjustStock(x, { date: '2026-10-01', kind: 'product', itemId: 'prod_large', newStock: 10 }));
noCost = K.tx(noCost, x => K.recordSale(x, { date: '2026-10-02', items: [{ productId: 'prod_large', qty: 1, unitPrice: 5000 }], paid: 5000 }));
const mn = K.monthlyReport(noCost, '2026-10');
ok(mn.operatingProfit === null && mn.warnings.includes('no_production'), 'no production recorded -> profit not claimed + warning');
let noPrice = K.emptyData();
noPrice = K.tx(noPrice, x => K.recordProduction(x, { date: '2026-10-01', productId: 'prod_large', good: 1, defective: 0, grams: {} }));
ok(K.monthlyReport(noPrice, '2026-10').warnings.includes('no_grams') && K.monthlyReport(noPrice, '2026-10').operatingProfit === null, 'production without grams -> estimate unavailable');

/* ---------- dashboard & feed ---------- */
const dash = K.dashboard(d, '2026-10-14');
eq(dash.todaySales, K.byId(d.sales, s1.id).total, 'dashboard today sales');
eq(dash.finishedStock, d.products.reduce((a, p) => a + p.stock, 0), 'dashboard finished stock');
const fd = K.feed(d);
ok(fd.length > 5 && fd[0].date >= fd[fd.length - 1].date, 'feed sorted newest first');
ok(!fd.some(x => x.kind === 'payment' && x.rec.initial), 'initial payments are part of their invoice, not separate rows');

/* ---------- workers & attendance ---------- */
d = K.tx(d, x => { K.addWorker(x, { name: 'Ahmed' }); K.addWorker(x, { name: 'Khaled' }); });
const [w1, w2] = d.workers.map(w => w.id), mch = d.machines[0].id;
d = K.tx(d, x => K.setShiftRoster(x, { date: '2026-10-13', shift: 1, entries: [{ workerId: w1, worked: true, machineId: mch }, { workerId: w2, worked: false }] }));
eq(K.rosterFor(d, '2026-10-13', 1).length, 2, 'roster saved');
throws(() => K.tx(d, x => K.setShiftRoster(x, { date: '2026-10-13', shift: 2, entries: [{ workerId: w1, worked: true }] })), 'worker_double_shift', 'same worker cannot work two shifts the same day');
d = K.tx(d, x => K.setShiftRoster(x, { date: '2026-10-13', shift: 2, entries: [{ workerId: w1, worked: false }, { workerId: w2, worked: true }] }));
throws(() => K.tx(d, x => K.setShiftRoster(x, { date: '2026-10-13', shift: 3, entries: [{ workerId: w1, worked: true }, { workerId: w1, worked: true }] })), 'duplicate_worker', 'duplicate worker in a cell');
throws(() => K.tx(d, x => K.setShiftRoster(x, { date: '2026-10-13', shift: 4, entries: [] })), 'bad_shift', 'only three shifts exist');
d = K.tx(d, x => K.setShiftRoster(x, { date: '2026-10-13', shift: 1, entries: [{ workerId: w1, worked: true }] }));
eq(K.rosterFor(d, '2026-10-13', 1).length, 1, 'saving a cell replaces its roster');
eq(K.workerStats(d, '2026-10-12', '2026-10-18').map(s => [s.shifts, s.hours]), [[1, 8], [1, 8]], 'worker hours = shifts x 8');

/* ---------- migration & backup ---------- */
const v1 = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/backup_v1.json'), 'utf8'));
const v1copy = JSON.stringify(v1);
const mig = K.validateBackup(v1);
ok(mig.ok && mig.migrated, 'schema-1 backup is accepted and migrated');
eq(JSON.stringify(v1), v1copy, 'migration never modifies the original');
const md = mig.data, od = v1.data;
eq(md.schema, 2, 'migrated to schema 2');
eq(md.sales.map(s => s.no), [2, 1].map(x => x), 'invoice numbers follow date order (older sale = #1)');
eq(md.sales.map(s => s.total), od.sales.map(s => s.total), 'sale totals preserved');
eq(md.customers.map(c => K.customerBalance(md, c.id)), od.customers.map(c => K.customerBalance(Object.assign({}, od), c.id) ), 'customer balances preserved (new formula)');
eq(md.products.map(p => p.stock), od.products.map(p => p.stock), 'finished stock preserved');
eq(md.materials.map(p => p.stock), od.materials.map(p => p.stock), 'raw stock preserved');
eq(md.movements.length, od.movements.length, 'stock movements preserved');
eq(md.production[0].good, 100, 'old production quantity became good crates');
eq(md.production[0].defective, 0, 'old production has no defects recorded');
eq(md.payments.length, od.payments.length, 'payments preserved');
ok(md.workers.length === 0 && md.counters.invoice === 2, 'new collections and counter created');
const again = K.validateBackup(K.makeBackup(md));
ok(again.ok && !again.migrated, 'migrated data round-trips as schema 2');
const bk = K.makeBackup(d), good = K.validateBackup(JSON.parse(JSON.stringify(bk)));
ok(good.ok === true, 'valid v2 backup accepted');
eq(JSON.stringify(good.data), JSON.stringify(d), 'restore gives back exactly the same data');
function broken(fn, name) { const b = JSON.parse(JSON.stringify(bk)); fn(b.data); ok(K.validateBackup(b).ok === false, name); }
ok(K.validateBackup({ hello: 1 }).ok === false && K.validateBackup(null).ok === false, 'random json rejected');
broken(x => { x.sales[0].items[0].productId = 'ghost'; }, 'broken reference rejected');
broken(x => { x.products[0].stock += 5; }, 'stock/movement mismatch rejected');
broken(x => { x.payments[0].amount = 1.5; }, 'non-integer money rejected');
broken(x => { delete x.expenses; }, 'missing array rejected');
broken(x => { x.customers.push({ id: x.customers[0].id, name: 'dup' }); }, 'duplicate id rejected');
broken(x => { x.sales[0].total += 1; }, 'sale total mismatch rejected');
broken(x => { x.payments.find(p => p.saleId === x.sales[0].id).amount = 999999999; }, 'overpaid invoice rejected');
broken(x => { x.attendance[0].shift = 7; }, 'bad shift rejected');
broken(x => { delete x.counters; }, 'missing counters rejected');


/* ---------- v0.6: notes, hire date, rename, delete / archive ---------- */
{
  let x = K.emptyData();
  const n = K.tx(x, c => K.addNote(c, { date: '2026-10-18', title: 'T', text: 'hello' })); x = n;
  eq(x.notes.length, 1, 'note added');
  throws(() => K.tx(x, c => K.addNote(c, { date: '2026-10-18', text: '  ' })), 'text_required', 'empty note rejected');
  x = K.tx(x, c => K.updateNote(c, c.notes[0].id, { date: '2026-10-19', title: 'T2', text: 'edited' }));
  eq(x.notes[0].text, 'edited', 'note edited');
  x = K.tx(x, c => K.removeEntity(c, 'note', c.notes[0].id)); eq(x.notes.length, 0, 'note deleted');
  x = K.tx(x, c => K.addWorker(c, { name: 'Omar', hireDate: '2026-03-01' })); eq(x.workers[0].hireDate, '2026-03-01', 'hire date saved');
  throws(() => K.tx(x, c => K.addWorker(c, { name: 'Bad', hireDate: '2026-13-45' })), 'bad_date', 'bad hire date rejected');
  x = K.tx(x, c => K.updateWorker(c, c.workers[0].id, { name: 'Omar B', hireDate: '', active: true })); eq([x.workers[0].name, x.workers[0].hireDate], ['Omar B', ''], 'worker edited, hire date cleared');
  x = K.tx(x, c => K.addMachine(c, { name: 'M1' })); x = K.tx(x, c => K.updateMachine(c, c.machines[0].id, { name: 'Injection 1' })); eq(x.machines[0].name, 'Injection 1', 'machine renamed');
  // unused machine -> really deleted; used machine -> archived
  x = K.tx(x, c => K.addMachine(c, { name: 'M2' }));
  const wid = x.workers[0].id, m1 = x.machines[0].id, m2 = x.machines[1].id;
  x = K.tx(x, c => K.setShiftRoster(c, { date: '2026-10-12', shift: 1, entries: [{ workerId: wid, worked: true, machineId: m1 }] }));
  let res; x = K.tx(x, c => { res = K.removeEntity(c, 'machine', m2); }); eq([res, x.machines.length], ['deleted', 2 - 1], 'unused machine deleted');
  x = K.tx(x, c => { res = K.removeEntity(c, 'machine', m1); }); eq(res, 'archived', 'used machine archived'); ok(x.machines[0].archived === true, 'archived flag kept (history intact)');
  x = K.tx(x, c => { res = K.removeEntity(c, 'worker', wid); }); eq(res, 'archived', 'worker with attendance archived');
  ok(K.validateBackup(K.makeBackup(x)).ok, 'backup with archived items validates');
  // products / materials / customers rules
  let y = K.emptyData(), mid;
  y = K.tx(y, c => { mid = K.addMaterial(c, { name: 'Mat', openingStock: 10 }).id; });
  throws(() => K.tx(y, c => K.removeEntity(c, 'material', mid)), 'stock_not_zero', 'material with stock cannot be deleted');
  y = K.tx(y, c => K.adjustStock(c, { date: '2026-10-18', kind: 'material', itemId: mid, newStock: 0, note: '' }));
  y = K.tx(y, c => { res = K.removeEntity(c, 'material', mid); }); eq(res, 'archived', 'material with movements archived');
  let pid; y = K.tx(y, c => { pid = K.addProduct(c, { name: 'P' }).id; }); y = K.tx(y, c => { res = K.removeEntity(c, 'product', pid); }); eq(res, 'deleted', 'never-used product deleted');
  let cid; y = K.tx(y, c => { cid = K.addCustomer(c, { name: 'C' }).id; });
  y = K.tx(y, c => { res = K.removeEntity(c, 'customer', cid); }); eq(res, 'deleted', 'customer without records deleted');
  // customer with an unpaid balance cannot be deleted
  let z = K.emptyData(), cid2;
  z = K.tx(z, c => { cid2 = K.addCustomer(c, { name: 'D' }).id; K.adjustStock(c, { date: '2026-10-01', kind: 'product', itemId: c.products[0].id, newStock: 50, note: '' }); });
  z = K.tx(z, c => K.recordSale(c, { date: '2026-10-18', customerId: cid2, items: [{ productId: c.products[0].id, qty: 1, unitPrice: 1000 }], paid: 0, method: 'cash' }));
  throws(() => K.tx(z, c => K.removeEntity(c, 'customer', cid2)), 'balance_not_zero', 'customer with debt cannot be deleted');
  // categories
  let cat; z = K.tx(z, c => { cat = K.addExpenseCat(c, { name: 'Tea' }).id; }); z = K.tx(z, c => K.updateExpenseCat(c, cat, { name: 'Coffee' })); eq(K.byId(z.expenseCats, cat).name, 'Coffee', 'category renamed');
  z = K.tx(z, c => { res = K.removeEntity(c, 'expenseCat', cat); }); eq(res, 'deleted', 'unused category deleted');
  // old v0.5 backup without "notes" still loads
  const old = K.makeBackup(K.emptyData()); delete old.data.notes; const vv = K.validateBackup(old); ok(vv.ok && Array.isArray(vv.data.notes), 'backup without notes loads (notes added empty)');
}

/* ---------- v0.7: customer/supplier profile, worker ledger + payments, orders, production table ---------- */
{
  let x = K.emptyData(), cid, wid, pid = x.products[0].id;
  x = K.tx(x, c => { cid = K.addCustomer(c, { name: 'Ahmed', phone: '055', address: 'Alger', email: 'a@b.dz', activity: 'Grossiste' }).id; });
  eq([x.customers[0].address, x.customers[0].activity], ['Alger', 'Grossiste'], 'customer extra info saved');
  x = K.tx(x, c => K.updateParty(c, 'customer', cid, { name: 'Ahmed B', phone: '056', address: 'Oran', email: '', activity: '', notes: 'n' })); eq(x.customers[0].address, 'Oran', 'customer info edited');
  x = K.tx(x, c => K.adjustStock(c, { date: '2026-10-01', kind: 'product', itemId: pid, newStock: 100, note: '' }));
  x = K.tx(x, c => K.recordSale(c, { date: '2026-10-10', customerId: cid, items: [{ productId: pid, qty: 10, unitPrice: 20000 }], paid: 50000, method: 'cash' }));
  x = K.tx(x, c => K.recordSale(c, { date: '2026-10-12', customerId: cid, items: [{ productId: pid, qty: 5, unitPrice: 20000 }], paid: 0, method: 'cash' }));
  const pp = K.partyProfile(x, 'customer', cid);
  eq([pp.count, pp.total, pp.paid, pp.balance, pp.qty, pp.first, pp.last], [2, 300000, 50000, 250000, 15, '2026-10-10', '2026-10-12'], 'customer profile numbers');
  // worker ledger
  x = K.tx(x, c => { wid = K.addWorker(c, { name: 'Omar', role: 'Opérateur', rate: 150000, hireDate: '2026-09-01', phone: '07' }).id; });
  x = K.tx(x, c => K.setShiftRoster(c, { date: '2026-10-12', shift: 1, entries: [{ workerId: wid, worked: true }] }));
  x = K.tx(x, c => K.setShiftRoster(c, { date: '2026-10-13', shift: 2, entries: [{ workerId: wid, worked: true }] }));
  x = K.tx(x, c => K.setShiftRoster(c, { date: '2026-10-14', shift: 1, entries: [{ workerId: wid, worked: false }] }));
  let L = K.workerLedger(x, wid);
  eq([L.shifts, L.hours, L.absent, L.earned, L.paid, L.balance, L.lastWorked], [2, 16, 1, 300000, 0, 300000, '2026-10-13'], 'worker ledger: shifts/hours/absent/earned');
  let wp; x = K.tx(x, c => { wp = K.recordWorkerPayment(c, { date: '2026-10-15', workerId: wid, amount: 100000, kind: 'advance', method: 'cash' }).id; });
  L = K.workerLedger(x, wid); eq([L.paid, L.balance], [100000, 200000], 'advance reduces balance');
  eq(x.expenses.filter(e => !e.voided).length, 1, 'payment recorded once as an expense (no double counting)');
  eq(K.monthlyReport(x, '2026-10').expenses, 100000, 'report counts the payment exactly once');
  x = K.tx(x, c => K.editWorkerPayment(c, wp, { date: '2026-10-16', amount: 120000, kind: 'salary', method: 'cash' }));
  L = K.workerLedger(x, wid); eq([L.paid, x.expenses.length, x.expenses[0].amount], [120000, 1, 120000], 'edited payment updates the same expense (no duplicate)');
  x = K.tx(x, c => K.voidWorkerPayment(c, wp, 'x')); L = K.workerLedger(x, wid); eq([L.paid, K.monthlyReport(x, '2026-10').expenses], [0, 0], 'voided payment removed from balance and reports');
  ok(K.validateBackup(K.makeBackup(x)).ok, 'backup with worker payments validates');
  x = K.tx(x, c => K.updateWorker(c, wid, { name: 'Omar', status: 'leave', rate: 150000 })); eq([x.workers[0].status, x.workers[0].active], ['leave', false], 'worker status leave => not active');
  throws(() => K.tx(x, c => K.updateWorker(c, wid, { name: 'Omar', status: 'bogus' })), 'bad_status', 'bad status rejected');
  // orders
  let nid; x = K.tx(x, c => { nid = K.addNote(c, { date: '2026-10-18', customerName: 'Client X', phone: '05', productId: pid, qty: 500, expectedDate: '2026-11-01', text: 'urgent' }).id; });
  eq([x.notes[0].isOrder, x.notes[0].status], [true, 'pending'], 'order note created pending');
  throws(() => K.tx(x, c => K.addNote(c, { date: '2026-10-18', productId: 'ghost', qty: 1, text: 'x' })), 'no_product', 'order with unknown product rejected');
  x = K.tx(x, c => K.updateNote(c, nid, { date: '2026-10-18', customerName: 'Client X', productId: pid, qty: 500, expectedDate: '2026-11-01', text: 'urgent', status: 'confirmed' })); eq(x.notes[0].status, 'confirmed', 'order confirmed');
  let sid; x = K.tx(x, c => { sid = K.recordSale(c, { date: '2026-10-18', customerId: cid, items: [{ productId: pid, qty: 5, unitPrice: 20000 }], paid: 0, method: 'cash' }).id; K.linkNoteToSale(c, nid, sid); });
  eq([x.notes[0].status, x.notes[0].saleId === sid], ['completed', true], 'note linked to invoice and completed');
  throws(() => K.tx(x, c => K.linkNoteToSale(c, nid, sid)), 'note_already_invoiced', 'cannot invoice the same note twice');
  // production table + shift
  let y = K.emptyData(); const p1 = y.products[0].id, p2 = y.products[1].id, m0 = y.materials[0].id;
  y = K.tx(y, c => K.addPurchase ? 0 : 0);
  y = K.tx(y, c => { K.recordPurchase(c, { date: '2026-10-01', supplier: null, supplierId: K.addSupplier(c, { name: 'S' }).id, materialId: m0, qty: 500, unitCost: 10000, paid: 5000000, method: 'cash' }); });
  y = K.tx(y, c => K.recordProduction(c, { date: '2026-10-05', productId: p1, shift: 1, good: 100, defective: 5, grams: { [m0]: 300 } }));
  y = K.tx(y, c => K.recordProduction(c, { date: '2026-10-05', productId: p2, shift: 2, good: 50, defective: 0, grams: { [m0]: 200 } }));
  y = K.tx(y, c => K.recordProduction(c, { date: '2026-10-07', productId: p1, good: 20, defective: 1, grams: { [m0]: 300 } }));
  const T = K.productionTable(y, '2026-10-01', '2026-10-31');
  eq([T.rows.length, T.totalGood, T.totalDefective, T.rows[0].shifts[1], T.rows[0].shifts[2], T.rows[1].shifts[0]], [2, 170, 6, 100, 50, 20], 'production table per day and shift');
  eq(T.rows[0].byProduct[p1], { good: 100, defective: 5 }, 'production table per product');
  throws(() => K.tx(y, c => K.recordProduction(c, { date: '2026-10-08', productId: p1, shift: 4, good: 1, defective: 0, grams: {} })), 'bad_shift', 'bad production shift rejected');
}

console.log(fail === 0 ? 'ALL OK' : 'FAILURES', '- passed:', pass, 'failed:', fail);
process.exit(fail ? 1 : 0);
