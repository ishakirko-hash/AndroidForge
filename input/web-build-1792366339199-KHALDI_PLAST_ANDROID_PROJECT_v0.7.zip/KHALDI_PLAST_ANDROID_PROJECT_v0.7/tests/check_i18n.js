// Run with:  node tests/check_i18n.js
// Checks that every text key used by ui.js exists in all three languages.
const fs = require('fs'), path = require('path');
const www = path.join(__dirname, '../app/src/main/assets/www');
global.window = {};
eval(fs.readFileSync(path.join(www, 'i18n.js'), 'utf8'));
const I = window.I18N;
const ui = ['ui-base','ui-forms','ui-views','ui-extra','ui-main','visual'].map(f => fs.readFileSync(path.join(www, f + '.js'), 'utf8')).join('\n');
const core = fs.readFileSync(path.join(www, 'core.js'), 'utf8');

const used = new Set();
for (const m of ui.matchAll(/\bt\('([A-Za-z0-9_]+)'/g)) used.add(m[1]);
// keys chosen with a ternary, e.g. t(isC ? 'sales' : 'purchases')
for (const m of ui.matchAll(/\bt\([^)]*\?\s*'([A-Za-z0-9_]+)'\s*:\s*'([A-Za-z0-9_]+)'/g)) { used.add(m[1]); used.add(m[2]); }
for (const m of ui.matchAll(/t\(\s*'([a-z_]+)'\s*\+/g)) used.delete(m[1]); // prefixes handled below

const dyn = [];
['pending','confirmed','completed','cancelled'].forEach(x => dyn.push('ns_' + x));
['active','leave','stopped'].forEach(x => dyn.push('ws_' + x));
['current','ended','upcoming'].forEach(x => dyn.push('st_' + x));
['advance','salary'].forEach(x => dyn.push('wpay_' + x));
['paid','partial','unpaid','void'].forEach(x => dyn.push('inv_st_' + x));
['kpis','alerts','chart','products','shortcuts','recent'].forEach(x => dyn.push('sec_' + x));
['customers','suppliers','prodtable','assistant','shifts','customize'].forEach(x => dyn.push('tile_' + x));
['sales','invoices','stock','production','workers','notes','purchases','expenses','debts','reports','transactions','more','settings','backup','customers','suppliers','worker','prodtable','assistant','customize'].forEach(x => dyn.push('sub_' + x));
['start_failed','retry','back','share'].forEach(x => dyn.push(x));
['cash', 'transfer', 'cheque', 'other'].forEach(x => dyn.push('m_' + x));
['production','purchases','sales','expenses','debts','stock','invoices','reports','workers'].forEach(x => dyn.push('tile_' + x));
['electricity','transport','salaries','maintenance','other'].forEach(x => dyn.push('cat_' + x));
['blue','green','red','black','gray'].forEach(x => dyn.push('col_' + x));
dyn.push('mv_edit');
['opening', 'purchase', 'void_purchase', 'production', 'production_use', 'void_production', 'sale', 'void_sale', 'adjust'].forEach(x => dyn.push('mv_' + x));
['home','transactions','more','settings','backup'].forEach(x => dyn.push('v_' + x));
['today', 'week', 'month', 'all'].forEach(x => dyn.push('p_' + x));
['dzd', 'centimes'].forEach(x => dyn.push('hint_invalid_' + x));
['restored_prev', 'data_damaged'].forEach(x => dyn.push('warn_' + x));
['unit_dzd', 'unit_centimes', 'month', 'current_stock', 'est_cost'].forEach(x => dyn.push(x));
// every error code thrown by core.js, plus UI-level ones
const codes = new Set(['unknown', 'save_failed', 'import_not_confirmed']);
for (const m of core.matchAll(/E\('([a-z_]+)'/g)) codes.add(m[1]);
codes.forEach(c => dyn.push('err_' + c));
dyn.forEach(k => used.add(k));

let bad = 0;
used.forEach(k => {
  if (!I[k]) { console.log('MISSING key:', k); bad++; return; }
  if (I[k].length !== 3 || I[k].some(s => typeof s !== 'string' || !s.trim())) { console.log('INCOMPLETE:', k); bad++; }
});
// placeholders must match across languages
Object.keys(I).forEach(k => {
  const sets = I[k].map(s => (s.match(/\{[a-z]+\}/g) || []).sort().join(','));
  if (new Set(sets).size > 1) { console.log('PLACEHOLDER MISMATCH:', k); bad++; }
});
const unusedCount = Object.keys(I).filter(k => !used.has(k)).length;
console.log(bad === 0 ? 'I18N OK' : 'I18N PROBLEMS', '- keys used:', used.size, 'defined:', Object.keys(I).length, 'unused:', unusedCount);
process.exit(bad ? 1 : 0);
