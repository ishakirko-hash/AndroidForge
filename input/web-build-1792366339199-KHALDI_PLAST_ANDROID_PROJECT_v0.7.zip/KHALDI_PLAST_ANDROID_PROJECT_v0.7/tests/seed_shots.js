// Seeds realistic test data through the real core API, then screenshots the data-heavy screens.
const L=require('./lib.js'), fs=require('fs');
(async()=>{ const vw=+process.argv[3]||390, out=process.argv[4]||'/tmp/shots'; fs.mkdirSync(out,{recursive:true});
 const s=await L.start(process.argv[2],vw), p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const ids=await p.evaluate(()=>{ const U=window.KPU,K=U.K; let r={};
  U.commit(d=>{ const td=K.today(); const m0=d.materials[0],m1=d.materials[1];
   const sup=K.addSupplier(d,{name:'مورد البلاستيك',phone:'0661 11 22 33',address:'وهران - المنطقة الصناعية',activity:'بيع مواد أولية'});
   K.recordPurchase(d,{date:K.addDays(td,-10),supplierId:sup.id,materialId:m0.id,qty:2000,unitCost:20000,paid:1000000,method:'cash'});
   K.recordPurchase(d,{date:K.addDays(td,-10),supplierId:sup.id,materialId:m1.id,qty:500,unitCost:15000,paid:0,method:'cash'});
   const c=K.addCustomer(d,{name:'محل الخضر و الفواكه',phone:'0550 12 34 56',address:'الجزائر - باب الزوار',activity:'محل خضر وفواكه'});
   const w1=K.addWorker(d,{name:'يوسف',role:'مشغّل آلة',rate:200000,hireDate:'2025-03-01',phone:'0770 00 00 01'}), w2=K.addWorker(d,{name:'كريم',role:'عامل تعبئة',rate:150000,hireDate:'2026-01-10'}), w3=K.addWorker(d,{name:'سمير',role:'سائق',rate:180000,hireDate:'2025-11-05',status:'leave'});
   const g={}; g[m0.id]=400; g[m1.id]=100;
   for(let i=6;i>=0;i--){ const day=K.addDays(td,-i); d.products.slice(0,3).forEach((p,k)=>{ K.recordProduction(d,{date:day,shift:(i+k)%3+1,productId:p.id,good:80+i*10+k*20,defective:3+k,grams:g}); });
     if(i<5){ K.setShiftRoster(d,{date:day,shift:1,entries:[{workerId:w1.id,worked:true},{workerId:w2.id,worked:i%2===0}]}); K.setShiftRoster(d,{date:day,shift:2,entries:[{workerId:w3.id,worked:false}]}); } }
   K.recordWorkerPayment(d,{date:td,workerId:w1.id,amount:500000,kind:'advance',method:'cash'});
   const items=[{productId:d.products[0].id,qty:40,unitPrice:32000,weightG:0},{productId:d.products[1].id,qty:30,unitPrice:22000,weightG:0}];
   const sale=K.recordSale(d,{date:td,customerId:c.id,items,discount:0,paid:100000,method:'cash',notes:'شكرا على ثقتكم'}); r.sale=sale.id; r.cust=c.id; r.w=w1.id;
   K.addNote(d,{date:td,customerName:'سمير التاجر',phone:'0555 55 55 55',productId:d.products[0].id,qty:50,expectedDate:K.addDays(td,3),status:'confirmed',text:'تسليم صباحا'});
   K.addNote(d,{date:td,title:'تذكير',text:'صيانة الآلة الأسبوع القادم'});
  }); U.render(); return r; });
 const go=async(r,arg)=>{ await p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.route=r;window.KPU.arg=a;window.KPU.render();},[r,arg||null]); await p.waitForTimeout(120); };
 for(const r of ['home','sales','stock','production','prodtable','notes','customers','suppliers']){ await go(r); await p.screenshot({path:out+'/d_'+r+'_'+vw+'.png',fullPage:false}); }
 await go('invoice',ids.sale); await p.locator('.paper').screenshot({path:out+'/d_invoice_'+vw+'.png'}); await p.emulateMedia({media:'print'}); await p.setViewportSize({width:794,height:1123}); await p.waitForTimeout(150); await p.screenshot({path:out+'/d_invoice_print.png',fullPage:true}); await p.emulateMedia({media:'screen'}); await p.setViewportSize({width:vw,height:800});
 await go('party',{kind:'customer',id:ids.cust}); await p.screenshot({path:out+'/d_party_'+vw+'.png',fullPage:true});
 await go('worker',ids.w); await p.screenshot({path:out+'/d_worker_'+vw+'.png',fullPage:true});
 await p.evaluate(()=>{window.KPU.S.workTab='today';}); await go('workers'); await p.screenshot({path:out+'/d_shifts_'+vw+'.png',fullPage:true});
 await go('assistant'); await p.fill('#chatq','ملخص شامل'); await p.press('#chatq','Enter'); await p.waitForTimeout(150); await p.fill('#chatq','يوسف'); await p.click('[data-act="chat_send"]'); await p.waitForTimeout(150); await p.screenshot({path:out+'/d_assistant_'+vw+'.png'});
 await go('customize'); await p.screenshot({path:out+'/d_customize_'+vw+'.png',fullPage:true});
 console.log('errors:',s.errors.length?s.errors:'none'); await s.close(); })();
