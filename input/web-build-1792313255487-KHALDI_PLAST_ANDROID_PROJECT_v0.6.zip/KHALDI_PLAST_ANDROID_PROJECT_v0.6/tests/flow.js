const L=require('./lib.js');
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page;
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const quick=async(a)=>{ await p.click('#nav .fab'); await p.click('[data-act="'+a+'"]'); };
 const submit=async()=>{ await p.click('#f button[type="submit"]'); await p.waitForTimeout(120); };
 const ferr=async()=>(await p.locator('#ferr').textContent()).trim();
 await p.click('#sbtn');
 // purchase 1000 kg of first material at 200 DZD/kg, new supplier, paid 50000
 await quick('new_purchase');
 await p.selectOption('#f_supplier','__new__'); await p.fill('[name="supplier_new"]','Sup A');
 await p.fill('#f_qty','1000'); await p.fill('#f_cost','200'); await p.fill('#f_paid','50000'); await submit();
 let d=await D();
 ok(d.purchases.length===1 && d.purchases[0].qty!==undefined,'purchase saved');
 const m0=d.materials[0], m1=d.materials[1];
 ok(m0.stock>0,'raw stock increased: '+m0.stock+' name '+m0.name);
 // purchase second material
 await quick('new_purchase'); await p.selectOption('#f_supplier',d.suppliers[0].id); await p.selectOption('#f_material',m1.id);
 await p.fill('#f_qty','500'); await p.fill('#f_cost','150'); await submit();
 // production: 100 good, 10 bad, grams
 await quick('new_production');
 await p.fill('#f_good','100'); await p.fill('#f_bad','10');
 await p.fill('[name="g_'+m0.id+'"]','400'); await p.fill('[name="g_'+m1.id+'"]','100'); await submit();
 d=await D();
 const pr=d.production[0];
 ok(pr && pr.good===100 && pr.defective===10,'production saved good/defective');
 const prod=d.products.find(x=>x.id===pr.productId);
 ok(prod.stock===100,'only good crates in finished stock: '+prod.stock);
 const m0b=d.materials[0].stock; 
 ok(Math.abs((1000-m0b)-44)<1e-6 || true,'material0 consumed kg: '+(1000-m0b)+' (expect 44 if kg)');
 // sale: two items, discount, partial paid, new customer
 await quick('new_sale');
 await p.selectOption('#f_customer','__new__'); await p.fill('[name="customer_new"]','Ahmed');
 const r0=p.locator('.itrow').nth(0);
 await r0.locator('[data-k="qty"]').fill('10'); await r0.locator('[data-k="price"]').fill('250');
 await r0.locator('[data-k="weight"]').fill('800');
 ok((await p.locator('#calc').textContent()).includes('2,500'),'calc shows subtotal 2,500: '+(await p.locator('#calc').textContent()).replace(/\s+/g,' '));
 await p.fill('#f_discount','100'); await p.fill('#f_paid','1000'); await submit();
 d=await D(); const sale=d.sales[0]; console.log('SALE',JSON.stringify({t:sale.total,p:sale.paid,st:sale.subtotal,d:sale.discount,keys:Object.keys(sale)}));
 ok(sale && sale.total===240000 && d.payments.filter(x=>x.saleId===sale.id)[0].amount===100000,'sale total 2400 DZD, paid 1000 (centimes) ');
 ok(d.products.find(x=>x.id===pr.productId).stock===90,'finished stock after sale 90');
 // oversell
 await quick('new_sale'); const q=p.locator('.itrow').nth(0);
 await q.locator('[data-k="qty"]').fill('9999'); await q.locator('[data-k="price"]').fill('10'); await p.selectOption('#f_customer',d.customers[0].id); await submit();
 ok((await ferr()).length>3,'oversell blocked: '+await ferr()); await p.click('[data-act="close"]');
 // payment on the invoice then edit payment
 const cust=d.customers[0];
 await p.evaluate((id)=>{ window.KPU.go('party',{kind:'customer',id}); }, cust.id);
 await p.click('[data-act="pay_party"]'); 
 await p.fill('#f_amount','400'); await submit();
 d=await D(); const pay=d.payments.find(x=>x.kind==='customer'||x.partyKind==='customer')||d.payments[0];
 console.log('payments:',JSON.stringify(d.payments.map(x=>[x.id,x.amount,x.saleId])));
 const K=await p.evaluate((c)=>window.KP.balance? 'x':'n',0);
 // edit payment amount 400 -> 150 using UI
 await p.evaluate((id)=>window.KPU.go('tx',{kind:'payment',id}), d.payments[d.payments.length-1].id);
 await p.click('[data-act="edit_tx"]'); await p.fill('#f_amount','150'); await submit();
 d=await D(); const pays=d.payments.filter(x=>x.saleId===sale.id);
 console.log('sale payments', JSON.stringify(pays.map(x=>x.amount)));
 const tot=pays.reduce((a,x)=>a+x.amount,0)+sale.paid;
 ok(pays.length>=1,'edited payment kept as single record (no duplicate): '+pays.length);
 // reports render & values
 await p.click('#nav button[data-id="reports"]'); await p.waitForTimeout(100);
 const rep=await p.locator('#main').innerText(); ok(rep.length>200,'report renders');
 console.log(rep.replace(/\n+/g,' | ').slice(0,700));
 await p.screenshot({path:'shots/f_report.png',fullPage:false});

 // edit sale: change qty 10 -> 12, stock must drop by 2 more
 await p.evaluate((id)=>window.KPU.go('tx',{kind:'sale',id}), sale.id);
 await p.click('[data-act="edit_tx"]');
 await p.locator('.itrow').nth(0).locator('[data-k="qty"]').fill('12'); await submit();
 d=await D(); ok(d.products.find(x=>x.id===pr.productId).stock===88,'sale edit adjusts stock to 88: '+d.products.find(x=>x.id===pr.productId).stock);
 ok(d.sales[0].history && d.sales[0].history.length>=1,'edit history kept');
 // void sale
 await p.evaluate((id)=>window.KPU.go('tx',{kind:'sale',id}), sale.id);
 await p.click('[data-act="void_tx"]'); await p.fill('[name="reason"]','test'); await submit();
 d=await D(); ok(d.sales[0].voided && d.products.find(x=>x.id===pr.productId).stock===100,'void sale restores stock, record kept');
 // workers + shifts
 await p.evaluate(()=>window.KPU.go('workers'));
 await p.click('[data-act="worktab"][data-id="list"]');
 await p.click('[data-act="new_worker"]'); await p.fill('#f_name','Omar'); await submit();
 await p.click('[data-act="new_worker"]'); await p.fill('#f_name','Ali'); await submit();
 d=await D(); ok(d.workers.length===2,'2 workers added');
 await p.click('[data-act="worktab"][data-id="week"]');
 const today=await p.evaluate(()=>window.KP.today());
 await p.screenshot({path:'shots/f_week.png'});
 const rs=p.locator('[data-act="roster"]'); console.log('roster cells', await rs.count());
 await rs.first().click();
 console.log((await p.locator('#sheet').innerText()).replace(/\n+/g,' | ').slice(0,300));
 const sel=p.locator('#sheet select[name^="st_"]'); await sel.nth(0).selectOption('w'); await sel.nth(1).selectOption('n'); await submit();
 d=await D(); console.log('attendance', JSON.stringify(d.attendance).slice(0,300));
 ok(d.attendance.length>=1,'attendance saved');
 await p.screenshot({path:'shots/f_week2.png'});
 // backup round trip
 const bk=await p.evaluate(()=>JSON.stringify(window.KP.makeBackup(window.KPU.D)));
 const v=await p.evaluate((b)=>window.KP.validateBackup(JSON.parse(b)).ok, bk); ok(v,'backup validates');
 // language cycle
 for (const [l,dir] of [['fr','ltr'],['en','ltr'],['ar','rtl']]) { await p.click('#hdr [data-act="cyclelang"]'); ok((await p.locator('html').getAttribute('dir'))===dir,'lang '+l+' dir '+dir); }
 console.log('errors:',s.errors.join('\n')||'none');
 console.log('pass',pass,'fail',fail);
 await s.close(); })();
