const L=require('./lib.js'); const fs=require('fs');
let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
(async()=>{
 const root=process.argv[2]; const fx=fs.readFileSync('/home/claude/KHALDI_PLAST_ANDROID_PROJECT_v0.5/tests/fixtures/backup_v1.json','utf8');
 for (const vw of [360,390,412]) {
  const s=await L.start(root,vw); const p=s.page;
  // seed v1 data directly into the storage the app reads, then reload
  const raw=JSON.stringify(JSON.parse(fx).data||JSON.parse(fx));
  await p.evaluate((r)=>localStorage.setItem('kp_data',r), raw); await p.reload(); await p.click('#sbtn');
  const d=await p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
  ok(d.schema===2,'['+vw+'] migrated to schema 2');
  ok(await p.evaluate(()=>window.KPU.migratedNow===true),'['+vw+'] migration flagged');
  const side=await p.evaluate(()=>window.KPU.sideLoad?window.KPU.sideLoad('premigration_v1.json'):'');
  ok(side && side.length>10,'['+vw+'] original v1 kept as side file');
  const routes=['sales','invoices','reports','workers','stock','debts'];
  let bad=[];
  for(const r of routes){ await p.evaluate((r)=>{window.KPU.stack=[];window.KPU.go(r)},r); await p.waitForTimeout(60);
    if(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth)) bad.push(r); }
  ok(bad.length===0,'['+vw+'] no horizontal overflow '+bad);
  if(vw===390 && d.sales.length){ await p.evaluate((id)=>{window.KPU.stack=[];window.KPU.go('invoice',id)}, d.sales[0].id); await p.screenshot({path:'shots/inv.png'});
    await p.emulateMedia({media:'print'}); await p.pdf({path:'shots/inv.pdf',format:'A4'}); await p.emulateMedia({media:'screen'}); ok(fs.statSync('shots/inv.pdf').size>3000,'invoice A4 PDF produced'); }
  ok(s.errors.length===0,'['+vw+'] no JS errors '+s.errors.join(';'));
  await s.close();
 }
 console.log('pass',pass,'fail',fail);
})();
