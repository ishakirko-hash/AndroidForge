const L=require('./lib.js');
let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page;
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const go=(r,a)=>p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.go(r,a)},[r,a]);
 const submit=async()=>{ await p.click('#f button[type="submit"]'); await p.waitForTimeout(100); };
 await p.waitForTimeout(300); await p.screenshot({path:'shots/n_splash.png'});
 await p.click('#sbtn');
 // notes
 await go('notes'); await p.click('[data-act="new_note"]'); await p.fill('#f_title','Machine 2'); await p.fill('#f_text','Oil change needed next week'); await submit();
 let d=await D(); ok(d.notes.length===1,'note created');
 await p.click('[data-act="edit_note"]'); await p.fill('#f_text','Oil change done'); await submit();
 d=await D(); ok(d.notes[0].text==='Oil change done','note edited');
 await p.fill('#noteq','done'); await p.waitForTimeout(100); ok((await p.locator('[data-act="edit_note"]').count())===1,'note search finds');
 await p.screenshot({path:'shots/n_notes.png'});
 await p.fill('#noteq',''); await p.click('[data-act="edit_note"]'); await p.click('[data-del]'); await submit(); d=await D(); ok(d.notes.length===0,'note deleted');
 // workers with hire date + many workers
 await go('workers'); await p.click('[data-act="worktab"][data-id="list"]');
 const names=['Omar','Ali','Karim','Yacine','Sofiane','Mourad','Nadir','Hamza'];
 for(let i=0;i<names.length;i++){ await p.click('[data-act="new_worker"]'); await p.fill('#f_name',names[i]); await p.fill('#f_hireDate','2026-0'+(1+i%9)+'-15'); await submit(); }
 d=await D(); ok(d.workers.length===8 && d.workers[0].hireDate==='2026-01-15','8 workers with hire dates');
 ok((await p.locator('#main').innerText()).includes('15/01/2026'),'hire date shown under worker name');
 await p.screenshot({path:'shots/n_workers.png'});
 // machines
 await p.click('[data-act="new_machine"]'); await p.fill('#f_name','Machine A'); await submit();
 await p.click('[data-act="edit_machine"]'); await p.fill('#f_name','Machine A2'); await submit(); d=await D(); ok(d.machines[0].name==='Machine A2','machine renamed');
 // roster: put all workers in shift 1 monday, machine for first
 await p.click('[data-act="worktab"][data-id="week"]'); await p.locator('[data-act="roster"]').first().click();
 const sel=p.locator('#sheet select[name^="st_"]'); const n=await sel.count();
 for(let i=0;i<n;i++) await sel.nth(i).selectOption(i%3===2?'n':'w');
 await submit(); d=await D(); ok(d.attendance.length===8,'8 attendance rows saved');
 await p.screenshot({path:'shots/n_week.png',fullPage:false});
 const cellTxt=await p.locator('[data-act="roster"]').first().innerText(); ok(names.every(x=>cellTxt.includes(x)),'cell shows ALL 8 workers: '+cellTxt.replace(/\n/g,' '));
 // machine used -> archived, disappears from list
 await go('workers'); await p.click('[data-act="worktab"][data-id="list"]');
 // assign machine to attendance directly so that machine is "used"
 await p.evaluate(()=>{ const U=window.KPU; U.commit(d=>{ d.attendance[0].machineId=d.machines[0].id; }); });
 await p.click('[data-act="edit_machine"]'); await p.click('[data-del]'); 
 ok((await p.locator('#sheet').innerText()).includes('1'),'delete dialog warns about use');
 await submit(); d=await D(); ok(d.machines[0].archived===true,'used machine archived');
 ok((await p.locator('[data-act="edit_machine"]').count())===0,'archived machine hidden from list');
 // worker delete (has attendance -> archived)
 await p.locator('[data-act="edit_worker"]').first().click(); await p.click('[data-del]'); await submit(); d=await D(); ok(d.workers[0].archived===true,'worker archived');
 // product: rename + delete (never used -> deleted)
 await go('stock'); await p.click('[data-act="new_item"][data-kind="product"]'); await p.fill('#f_name','Crate X'); await submit();
 d=await D(); const px=d.products.find(x=>x.name==='Crate X'); ok(!!px,'product created');
 await p.locator('[data-act="edit_item"]').last().click(); await p.fill('#f_name','Crate XL'); await submit(); d=await D(); ok(d.products.some(x=>x.name==='Crate XL'),'product renamed');
 await p.locator('[data-act="edit_item"]').last().click(); await p.click('[data-del]'); await submit(); d=await D(); ok(!d.products.some(x=>x.name==='Crate XL'),'unused product deleted for good');
 // product with stock cannot be deleted
 await p.locator('[data-act="adjust"][data-kind="product"]').first().click(); await p.fill('#f_newStock','5'); await submit();
 await p.locator('[data-act="edit_item"]').first().click(); await p.click('[data-del]'); await submit();
 ok((await p.locator('#ferr').textContent()).length>3,'product with stock: delete refused -> '+await p.locator('#ferr').textContent()); await p.click('[data-act="close"]');
 // customer delete from detail
 await go('debts'); await p.click('[data-act="new_party"]'); await p.fill('#f_name','Temp Client'); await submit();
 await p.click('[data-act="party"]'); await p.click('[data-act="edit_party"]'); await p.click('[data-del]'); await submit(); d=await D(); ok(!d.customers.some(c=>c.name==='Temp Client'),'customer deleted from detail page');
 ok((await p.locator('#hdr').innerText()).includes('الديون'),'returned to debts screen after delete');
 // category rename + delete
 await go('settings'); await p.click('[data-act="new_category"]'); await p.fill('#f_name','Tea'); await submit();
 await p.locator('[data-act="edit_category"]').last().click(); await p.fill('#f_name','Coffee'); await submit(); d=await D(); ok(d.expenseCats.some(c=>c.name==='Coffee'),'category renamed');
 await p.locator('[data-act="edit_category"]').last().click(); await p.click('[data-del]'); await submit(); d=await D(); ok(!d.expenseCats.some(c=>c.name==='Coffee'),'category deleted');
 // archived stuff survives backup validation + reload
 ok(await p.evaluate(()=>window.KP.validateBackup(window.KP.makeBackup(window.KPU.D)).ok),'backup valid after deletes');
 await p.reload(); await p.click('#sbtn'); d=await D(); ok(d.machines[0].archived===true && d.workers.length===8,'data persisted after reload');
 console.log('errors:',s.errors.join('\n')||'none'); console.log('pass',pass,'fail',fail); await s.close(); })();
