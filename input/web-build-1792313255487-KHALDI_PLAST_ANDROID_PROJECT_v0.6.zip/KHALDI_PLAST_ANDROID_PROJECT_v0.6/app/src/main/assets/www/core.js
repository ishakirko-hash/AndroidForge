/* KHALDI PLAST - business logic, schema 2 (no DOM here, so it can be tested with Node).
 *
 * MONEY      : every amount is an INTEGER number of centimes (1 DZD = 100 centimes). Never floats.
 * QUANTITIES : crates are whole numbers; raw materials are kilograms with up to 3 decimals.
 *              Consumption is entered in GRAMS PER CRATE (whole grams) and converted to kg.
 * SAFETY     : every operation runs on a copy (tx). The real data is replaced only if the whole
 *              operation succeeded. Nothing is deleted: wrong records are voided (stock reversed) or
 *              edited with the previous version kept in record.history.
 * DERIVED    : balances, debts and reports are always computed from the records, never stored,
 *              so editing a payment automatically corrects every balance and report.
 */
(function (root) {
  'use strict';

  var BACKUP_ID = 'KHALDI_PLAST_BACKUP';
  var SCHEMA = 2;
  // Exactly three fixed shifts, eight hours each. Times are defined here, never typed by the user.
  var SHIFTS = [
    { n: 1, start: '08:00', end: '16:00', hours: 8 },
    { n: 2, start: '16:00', end: '00:00', hours: 8 },
    { n: 3, start: '00:00', end: '08:00', hours: 8 }
  ];

  function E(code, params) { var e = new Error(code); e.code = code; e.params = params || {}; return e; }
  var seq = 0;
  function uid(p) { seq++; return p + '_' + Date.now().toString(36) + seq.toString(36) + Math.random().toString(36).slice(2, 6); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function byId(arr, id) { for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return arr[i]; return null; }
  function round3(x) { return Math.round(x * 1000) / 1000; }
  function sum(arr, f) { var s = 0; for (var i = 0; i < arr.length; i++) s += f(arr[i]); return s; }
  function live(a) { return a.filter(function (x) { return !x.voided; }); }
  function str(s) { return String(s == null ? '' : s).trim(); }
  function stamp() { return new Date().toISOString(); }

  /* ---------- numbers, money, dates ---------- */
  function normNum(s) {
    return String(s == null ? '' : s).trim()
      .replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 1632); })
      .replace(/[۰-۹]/g, function (d) { return String(d.charCodeAt(0) - 1776); })
      .replace(/[٫,]/g, '.')
      .replace(/[\s  ٬]/g, '');
  }
  // mode 'dzd': "1250.50" = 1250.50 DZD = 125050 centimes.   mode 'centimes': "1250" = 1250 centimes (whole only)
  function parseMoney(s, mode) {
    s = normNum(s);
    if (!/^\d+(\.\d{1,2})?$/.test(s)) return { ok: false };
    var c;
    if (mode === 'centimes') { if (s.indexOf('.') >= 0) return { ok: false }; c = parseInt(s, 10); }
    else { var p = s.split('.'); c = parseInt(p[0], 10) * 100 + parseInt(((p[1] || '') + '00').slice(0, 2), 10); }
    if (!isFinite(c) || c > 9e12) return { ok: false };
    return { ok: true, c: c };
  }
  function parseQty(s, decimals) {
    s = normNum(s);
    if (!(decimals ? /^\d+(\.\d{1,3})?$/ : /^\d+$/).test(s)) return { ok: false };
    var q = Number(s); if (!isFinite(q) || q > 1e9) return { ok: false };
    return { ok: true, q: q };
  }
  function groupInt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function fmtMoney(c) {
    var neg = c < 0; c = Math.abs(c);
    var dz = Math.floor(c / 100), ct = c % 100;
    return (neg ? '-' : '') + groupInt(dz) + (ct ? '.' + (ct < 10 ? '0' : '') + ct : '');
  }
  function fmtQty(q) { var p = String(round3(q)).split('.'); return groupInt(p[0]) + (p[1] ? '.' + p[1] : ''); }
  function pad2(n) { return ('0' + n).slice(-2); }
  function dstr(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function today() { return dstr(new Date()); }
  function parseDate(s) { var p = s.split('-').map(Number); return new Date(p[0], p[1] - 1, p[2]); }
  function addDays(s, n) { var d = parseDate(s); d.setDate(d.getDate() + n); return dstr(d); }
  function validDate(s) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s))) return false;
    var p = s.split('-').map(Number), d = new Date(p[0], p[1] - 1, p[2]);
    return d.getFullYear() === p[0] && d.getMonth() === p[1] - 1 && d.getDate() === p[2];
  }
  function needDate(s) { if (!validDate(s)) throw E('bad_date'); return s; }
  function inRange(date, from, to) { return (!from || date >= from) && (!to || date <= to); }
  function fmtDate(s) { return validDate(s) ? s.slice(8, 10) + '/' + s.slice(5, 7) + '/' + s.slice(0, 4) : s; }
  function needInt(n, code) { if (typeof n !== 'number' || !isFinite(n) || Math.floor(n) !== n || n < 0) throw E(code || 'bad_amount'); return n; }
  function monthRange(ym) {
    var y = Number(ym.slice(0, 4)), m = Number(ym.slice(5, 7));
    return { from: ym + '-01', to: ym + '-' + pad2(new Date(y, m, 0).getDate()) };
  }
  function addMonths(ym, n) { var y = Number(ym.slice(0, 4)), m = Number(ym.slice(5, 7)) - 1 + n; var d = new Date(y, m, 1); return d.getFullYear() + '-' + pad2(d.getMonth() + 1); }
  function startOfWeek(s) { var d = parseDate(s), dow = (d.getDay() + 6) % 7; d.setDate(d.getDate() - dow); return dstr(d); } // Monday
  function weekDates(monday) { var a = []; for (var i = 0; i < 7; i++) a.push(addDays(monday, i)); return a; }
  function weekdayIndex(s) { return (parseDate(s).getDay() + 6) % 7; } // 0 = Monday

  /* ---------- data ---------- */
  function emptyData() {
    return {
      app: 'KHALDI_PLAST', schema: SCHEMA,
      settings: { lang: 'ar', inputMode: 'dzd', company: 'KHALDI PLAST', address: 'مركز بن خليل', phone: '0798587564', email: 'khaldiplast@gmail.com' },
      counters: { invoice: 0 },
      customers: [], suppliers: [],
      products: [
        { id: 'prod_large', code: 'FL', name: 'صندوق فواكه كبير', category: 'crate', color: 'blue', stock: 0, minStock: 0, price: 0, weightG: 0, recipe: {} },
        { id: 'prod_medium', code: 'FM', name: 'صندوق فواكه متوسط', category: 'crate', color: 'green', stock: 0, minStock: 0, price: 0, weightG: 0, recipe: {} },
        { id: 'prod_small', code: 'FS', name: 'صندوق فواكه صغير', category: 'crate', color: 'red', stock: 0, minStock: 0, price: 0, weightG: 0, recipe: {} },
        { id: 'prod_veg', code: 'VG', name: 'صندوق خضار', category: 'crate', color: 'black', stock: 0, minStock: 0, price: 0, weightG: 0, recipe: {} }
      ],
      materials: [
        { id: 'mat_granule', name: 'Granulé', unit: 'kg', stock: 0, minStock: 0 },
        { id: 'mat_broye', name: 'Broyé', unit: 'kg', stock: 0, minStock: 0 }
      ],
      expenseCats: [
        { id: 'cat_electricity', key: 'electricity', name: 'Électricité' },
        { id: 'cat_transport', key: 'transport', name: 'Transport' },
        { id: 'cat_salaries', key: 'salaries', name: 'Salaires' },
        { id: 'cat_maintenance', key: 'maintenance', name: 'Maintenance' },
        { id: 'cat_other', key: 'other', name: 'Autres' }
      ],
      workers: [], machines: [], attendance: [], notes: [],
      production: [], sales: [], payments: [], purchases: [], supplierPayments: [], expenses: [], movements: []
    };
  }
  function tx(d, fn) { var c = clone(d); fn(c); return c; }

  /* ---------- stock ---------- */
  function move(d, o) {
    d.movements.push({ id: uid('mv'), ts: stamp(), date: o.date, kind: o.kind, itemId: o.itemId, qty: o.qty, type: o.type, ref: o.ref || null, note: o.note || '' });
  }
  function changeStock(d, kind, itemId, delta, o) {
    var item = byId(kind === 'product' ? d.products : d.materials, itemId);
    if (!item) throw E('no_item');
    var ns = round3(item.stock + delta);
    if (ns < 0) throw E('insufficient_stock', { name: item.name, have: item.stock });
    item.stock = ns;
    move(d, { date: o.date, kind: kind, itemId: itemId, qty: round3(delta), type: o.type, ref: o.ref, note: o.note });
  }
  // Apply only the NET difference between the old and the new effects of an edited record.
  function applyNet(d, olds, news, o) {
    var map = {};
    function add(list, sign) { list.forEach(function (e) { var k = e.kind + '|' + e.itemId; map[k] = map[k] || { kind: e.kind, itemId: e.itemId, d: 0 }; map[k].d += sign * e.qty; }); }
    add(olds, -1); add(news, 1);
    Object.keys(map).forEach(function (k) { var m = map[k], delta = round3(m.d); if (delta !== 0) changeStock(d, m.kind, m.itemId, delta, { date: o.date, type: 'edit', ref: o.ref, note: o.note || '' }); });
  }
  function history(rec) {
    var snap = clone(rec); delete snap.history;
    rec.history = rec.history || []; rec.history.push({ ts: stamp(), before: snap }); rec.editedOn = today();
  }

  /* ---------- master data ---------- */
  function addCustomer(d, o) { var name = str(o.name); if (!name) throw E('name_required'); var c = { id: uid('cus'), name: name, phone: str(o.phone), notes: str(o.notes), created: today() }; d.customers.push(c); return c; }
  function addSupplier(d, o) { var name = str(o.name); if (!name) throw E('name_required'); var s = { id: uid('sup'), name: name, phone: str(o.phone), notes: str(o.notes), created: today() }; d.suppliers.push(s); return s; }
  function updateParty(d, kind, id, o) {
    var p = byId(kind === 'customer' ? d.customers : d.suppliers, id); if (!p) throw E('no_item');
    var name = str(o.name); if (!name) throw E('name_required');
    p.name = name; p.phone = str(o.phone); p.notes = str(o.notes);
  }
  function checkRecipe(r) {
    var out = {};
    Object.keys(r || {}).forEach(function (k) { var g = r[k]; if (g) { if (typeof g !== 'number' || g < 0 || Math.floor(g) !== g) throw E('bad_grams'); out[k] = g; } });
    return out;
  }
  function addProduct(d, o) {
    var name = str(o.name); if (!name) throw E('name_required');
    var p = { id: uid('prod'), code: str(o.code), name: name, category: str(o.category) || 'crate', color: o.color || 'gray', stock: 0, minStock: o.minStock || 0, price: o.price || 0, weightG: o.weightG || 0, recipe: checkRecipe(o.recipe) };
    d.products.push(p);
    if (o.openingStock > 0) changeStock(d, 'product', p.id, o.openingStock, { date: today(), type: 'opening', note: '' });
    return p;
  }
  function updateProduct(d, id, o) {
    var p = byId(d.products, id); if (!p) throw E('no_item');
    var name = str(o.name); if (!name) throw E('name_required');
    p.name = name; p.code = str(o.code); p.minStock = o.minStock || 0; p.price = o.price || 0; p.weightG = o.weightG || 0;
    if (o.color) p.color = o.color;
    if (o.recipe) p.recipe = checkRecipe(o.recipe);
  }
  function addMaterial(d, o) {
    var name = str(o.name); if (!name) throw E('name_required');
    var m = { id: uid('mat'), name: name, unit: 'kg', stock: 0, minStock: o.minStock || 0 };
    d.materials.push(m);
    if (o.openingStock > 0) changeStock(d, 'material', m.id, o.openingStock, { date: today(), type: 'opening', note: '' });
    return m;
  }
  function updateMaterial(d, id, o) {
    var m = byId(d.materials, id); if (!m) throw E('no_item');
    var name = str(o.name); if (!name) throw E('name_required');
    m.name = name; m.minStock = o.minStock || 0;
  }
  function addExpenseCat(d, o) { var name = str(o.name); if (!name) throw E('name_required'); var c = { id: uid('cat'), name: name }; d.expenseCats.push(c); return c; }
  function adjustStock(d, o) {
    needDate(o.date);
    var item = byId(o.kind === 'product' ? d.products : d.materials, o.itemId); if (!item) throw E('no_item');
    var ns = round3(o.newStock); if (!(ns >= 0)) throw E('bad_qty');
    var delta = round3(ns - item.stock); if (delta === 0) throw E('no_change');
    changeStock(d, o.kind, o.itemId, delta, { date: o.date, type: 'adjust', note: str(o.note) });
  }

  /* ---------- purchases ---------- */
  function purchaseOutstanding(d, id) {
    var p = byId(d.purchases, id); if (!p || p.voided) return 0;
    return p.total - sum(d.supplierPayments.filter(function (x) { return x.purchaseId === id && !x.voided; }), function (x) { return x.amount; });
  }
  function recordPurchase(d, o) {
    needDate(o.date);
    var mat = byId(d.materials, o.materialId); if (!mat) throw E('no_material');
    var sup = byId(d.suppliers, o.supplierId); if (!sup) throw E('supplier_required');
    if (!(o.qty > 0)) throw E('bad_qty');
    needInt(o.unitCost); if (o.unitCost <= 0) throw E('bad_amount');
    var total = Math.round(o.qty * o.unitCost), paid = needInt(o.paid || 0, 'bad_paid');
    if (paid > total) throw E('paid_exceeds_total');
    var p = { id: uid('pur'), ts: stamp(), date: o.date, supplierId: sup.id, materialId: mat.id, qty: round3(o.qty), unitCost: o.unitCost, total: total, notes: str(o.notes), voided: false };
    d.purchases.push(p);
    if (paid > 0) d.supplierPayments.push({ id: uid('spay'), ts: stamp(), date: o.date, supplierId: sup.id, purchaseId: p.id, amount: paid, method: o.method || 'cash', notes: '', voided: false, initial: true });
    changeStock(d, 'material', mat.id, p.qty, { date: o.date, type: 'purchase', ref: p.id });
    return p;
  }
  function editPurchase(d, id, o) {
    var p = byId(d.purchases, id); if (!p || p.voided) throw E('no_item');
    needDate(o.date);
    var mat = byId(d.materials, o.materialId); if (!mat) throw E('no_material');
    var sup = byId(d.suppliers, o.supplierId); if (!sup) throw E('supplier_required');
    if (!(o.qty > 0)) throw E('bad_qty');
    needInt(o.unitCost); if (o.unitCost <= 0) throw E('bad_amount');
    var total = Math.round(o.qty * o.unitCost);
    var paidNow = sum(d.supplierPayments.filter(function (x) { return x.purchaseId === id && !x.voided; }), function (x) { return x.amount; });
    if (paidNow > total) throw E('total_below_paid');
    applyNet(d, [{ kind: 'material', itemId: p.materialId, qty: p.qty }], [{ kind: 'material', itemId: mat.id, qty: round3(o.qty) }], { date: o.date, ref: id });
    history(p);
    p.date = o.date; p.supplierId = sup.id; p.materialId = mat.id; p.qty = round3(o.qty); p.unitCost = o.unitCost; p.total = total; p.notes = str(o.notes);
    d.supplierPayments.forEach(function (x) { if (x.purchaseId === id) x.supplierId = sup.id; });
  }
  function recordSupplierPayment(d, o) {
    needDate(o.date);
    var sup = byId(d.suppliers, o.supplierId); if (!sup) throw E('supplier_required');
    var amount = needInt(o.amount); if (amount <= 0) throw E('bad_amount');
    function push(pid, a) { d.supplierPayments.push({ id: uid('spay'), ts: stamp(), date: o.date, supplierId: sup.id, purchaseId: pid, amount: a, method: o.method || 'cash', notes: str(o.notes), voided: false }); }
    if (o.purchaseId) {
      var pu = byId(d.purchases, o.purchaseId);
      if (!pu || pu.voided || pu.supplierId !== sup.id) throw E('no_item');
      if (amount > purchaseOutstanding(d, pu.id)) throw E('payment_exceeds_balance');
      push(pu.id, amount); return;
    }
    var open = d.purchases.filter(function (p) { return p.supplierId === sup.id && !p.voided && purchaseOutstanding(d, p.id) > 0; })
      .sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
    if (amount > sum(open, function (p) { return purchaseOutstanding(d, p.id); })) throw E('payment_exceeds_balance');
    var left = amount;
    for (var i = 0; i < open.length && left > 0; i++) { var part = Math.min(left, purchaseOutstanding(d, open[i].id)); push(open[i].id, part); left -= part; }
  }
  function voidPurchase(d, id, reason) {
    var p = byId(d.purchases, id); if (!p || p.voided) throw E('no_item');
    changeStock(d, 'material', p.materialId, -p.qty, { date: today(), type: 'void_purchase', ref: p.id, note: str(reason) });
    p.voided = true; p.voidReason = str(reason); p.voidedOn = today();
    d.supplierPayments.forEach(function (x) { if (x.purchaseId === id && !x.voided) { x.voided = true; x.voidReason = 'purchase voided'; } });
  }
  function voidSupplierPayment(d, id, reason) {
    var x = byId(d.supplierPayments, id); if (!x || x.voided) throw E('no_item');
    x.voided = true; x.voidReason = str(reason); x.voidedOn = today();
  }
  function editSupplierPayment(d, id, o) {
    var x = byId(d.supplierPayments, id); if (!x || x.voided) throw E('no_item');
    needDate(o.date);
    var amount = needInt(o.amount); if (amount <= 0) throw E('bad_amount');
    var pu = byId(d.purchases, x.purchaseId);
    var others = sum(d.supplierPayments.filter(function (y) { return y.purchaseId === x.purchaseId && !y.voided && y.id !== id; }), function (y) { return y.amount; });
    if (amount > pu.total - others) throw E('payment_exceeds_balance');
    history(x); x.date = o.date; x.amount = amount; x.method = o.method || x.method; x.notes = str(o.notes);
  }

  /* ---------- sales & invoices ---------- */
  function saleOutstanding(d, id) {
    var s = byId(d.sales, id); if (!s || s.voided) return 0;
    return s.total - sum(d.payments.filter(function (x) { return x.saleId === id && !x.voided; }), function (x) { return x.amount; });
  }
  function salePaid(d, id) { return sum(d.payments.filter(function (x) { return x.saleId === id && !x.voided; }), function (x) { return x.amount; }); }
  function customerBalance(d, cid) {
    return sum(d.sales.filter(function (s) { return s.customerId === cid && !s.voided; }), function (s) { return s.total; }) -
      sum(d.payments.filter(function (p) { return p.customerId === cid && !p.voided; }), function (p) { return p.amount; });
  }
  function supplierBalance(d, sid) {
    return sum(d.purchases.filter(function (p) { return p.supplierId === sid && !p.voided; }), function (p) { return p.total; }) -
      sum(d.supplierPayments.filter(function (p) { return p.supplierId === sid && !p.voided; }), function (p) { return p.amount; });
  }
  function cleanItems(d, items) {
    if (!Array.isArray(items) || !items.length) throw E('items_required');
    return items.map(function (it) {
      if (!byId(d.products, it.productId)) throw E('no_product');
      if (!(it.qty > 0) || Math.floor(it.qty) !== it.qty) throw E('bad_qty');
      needInt(it.unitPrice); if (it.unitPrice <= 0) throw E('bad_amount');
      var w = it.weightG || 0; needInt(w, 'bad_grams');
      return { productId: it.productId, qty: it.qty, unitPrice: it.unitPrice, weightG: w };
    });
  }
  function totals(items, discount) {
    var subtotal = sum(items, function (it) { return it.qty * it.unitPrice; });
    var disc = needInt(discount || 0, 'bad_discount');
    if (disc > subtotal) throw E('discount_exceeds');
    return { subtotal: subtotal, discount: disc, total: subtotal - disc };
  }
  function saleEffects(items) { return items.map(function (it) { return { kind: 'product', itemId: it.productId, qty: -it.qty }; }); }
  function recordSale(d, o) {
    needDate(o.date);
    var items = cleanItems(d, o.items), t = totals(items, o.discount);
    var paid = needInt(o.paid || 0, 'bad_paid'); if (paid > t.total) throw E('paid_exceeds_total');
    var cust = o.customerId ? byId(d.customers, o.customerId) : null;
    if (o.customerId && !cust) throw E('no_customer');
    if (paid < t.total && !cust) throw E('customer_required_for_credit');
    d.counters = d.counters || { invoice: 0 };
    d.counters.invoice += 1;
    var s = { id: uid('sale'), ts: stamp(), no: d.counters.invoice, date: o.date, customerId: cust ? cust.id : null, items: items,
      subtotal: t.subtotal, discount: t.discount, total: t.total, notes: str(o.notes), voided: false };
    d.sales.push(s);
    if (paid > 0) d.payments.push({ id: uid('pay'), ts: stamp(), date: o.date, customerId: cust ? cust.id : null, saleId: s.id, amount: paid, method: o.method || 'cash', notes: '', voided: false, initial: true });
    items.forEach(function (it) { changeStock(d, 'product', it.productId, -it.qty, { date: o.date, type: 'sale', ref: s.id }); });
    return s;
  }
  function editSale(d, id, o) {
    var s = byId(d.sales, id); if (!s || s.voided) throw E('no_item');
    needDate(o.date);
    var items = cleanItems(d, o.items), t = totals(items, o.discount);
    var cust = o.customerId ? byId(d.customers, o.customerId) : null;
    if (o.customerId && !cust) throw E('no_customer');
    var paid = salePaid(d, id);
    if (paid > t.total) throw E('total_below_paid');
    if (paid < t.total && !cust) throw E('customer_required_for_credit');
    applyNet(d, saleEffects(s.items), saleEffects(items), { date: o.date, ref: id });
    history(s);
    s.date = o.date; s.customerId = cust ? cust.id : null; s.items = items; s.subtotal = t.subtotal; s.discount = t.discount; s.total = t.total; s.notes = str(o.notes);
    d.payments.forEach(function (p) { if (p.saleId === id) p.customerId = s.customerId; });
  }
  function recordCustomerPayment(d, o) {
    needDate(o.date);
    var cust = byId(d.customers, o.customerId); if (!cust) throw E('no_customer');
    var amount = needInt(o.amount); if (amount <= 0) throw E('bad_amount');
    function push(sid, a) { d.payments.push({ id: uid('pay'), ts: stamp(), date: o.date, customerId: cust.id, saleId: sid, amount: a, method: o.method || 'cash', notes: str(o.notes), voided: false }); }
    if (o.saleId) {
      var s = byId(d.sales, o.saleId);
      if (!s || s.voided || s.customerId !== cust.id) throw E('no_item');
      if (amount > saleOutstanding(d, s.id)) throw E('payment_exceeds_balance');
      push(s.id, amount); return;
    }
    var open = d.sales.filter(function (s) { return s.customerId === cust.id && !s.voided && saleOutstanding(d, s.id) > 0; })
      .sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.no || 0) - (b.no || 0); });
    if (amount > sum(open, function (s) { return saleOutstanding(d, s.id); })) throw E('payment_exceeds_balance');
    var left = amount;
    for (var i = 0; i < open.length && left > 0; i++) { var part = Math.min(left, saleOutstanding(d, open[i].id)); push(open[i].id, part); left -= part; }
  }
  // Editing a saved payment: validates against the invoice, keeps the old version in history.
  // Balances, debts and reports are derived, so every dependent number is corrected automatically.
  function editPayment(d, id, o) {
    var x = byId(d.payments, id); if (!x || x.voided) throw E('no_item');
    needDate(o.date);
    var amount = needInt(o.amount); if (amount <= 0) throw E('bad_amount');
    var s = byId(d.sales, x.saleId); if (!s || s.voided) throw E('no_item');
    var others = sum(d.payments.filter(function (y) { return y.saleId === x.saleId && !y.voided && y.id !== id; }), function (y) { return y.amount; });
    if (amount > s.total - others) throw E('payment_exceeds_balance');
    history(x); x.date = o.date; x.amount = amount; x.method = o.method || x.method; x.notes = str(o.notes);
  }
  function voidSale(d, id, reason) {
    var s = byId(d.sales, id); if (!s || s.voided) throw E('no_item');
    s.items.forEach(function (it) { changeStock(d, 'product', it.productId, it.qty, { date: today(), type: 'void_sale', ref: s.id, note: str(reason) }); });
    s.voided = true; s.voidReason = str(reason); s.voidedOn = today();
    d.payments.forEach(function (x) { if (x.saleId === id && !x.voided) { x.voided = true; x.voidReason = 'sale voided'; } });
  }
  function voidPayment(d, id, reason) {
    var x = byId(d.payments, id); if (!x || x.voided) throw E('no_item');
    x.voided = true; x.voidReason = str(reason); x.voidedOn = today();
  }
  function saleMethod(d, id) {
    var ps = d.payments.filter(function (p) { return p.saleId === id && !p.voided; });
    return ps.length ? ps[0].method : null;
  }

  /* ---------- production (good + defective, grams per crate) ---------- */
  function consumptionFor(d, qtyTotal, grams) {
    var lines = [];
    Object.keys(grams).forEach(function (mid) {
      var g = grams[mid]; if (!g) return;
      if (!byId(d.materials, mid)) throw E('no_material');
      var totalG = qtyTotal * g; // whole grams
      lines.push({ materialId: mid, qty: round3(totalG / 1000) });
    });
    return lines;
  }
  function prodEffects(r) {
    var e = [{ kind: 'product', itemId: r.productId, qty: r.good }];
    r.consumption.forEach(function (l) { e.push({ kind: 'material', itemId: l.materialId, qty: -l.qty }); });
    return e;
  }
  function cleanProduction(d, o) {
    needDate(o.date);
    if (!byId(d.products, o.productId)) throw E('no_product');
    var good = o.good || 0, bad = o.defective || 0;
    if (good < 0 || bad < 0 || Math.floor(good) !== good || Math.floor(bad) !== bad) throw E('bad_qty');
    if (good + bad <= 0) throw E('bad_qty');
    var grams = checkRecipe(o.grams);
    return { good: good, defective: bad, grams: grams, consumption: consumptionFor(d, good + bad, grams) };
  }
  function recordProduction(d, o) {
    var c = cleanProduction(d, o);
    var r = { id: uid('prd'), ts: stamp(), date: o.date, productId: o.productId, good: c.good, defective: c.defective, grams: c.grams, consumption: c.consumption, notes: str(o.notes), voided: false };
    d.production.push(r);
    c.consumption.forEach(function (l) { changeStock(d, 'material', l.materialId, -l.qty, { date: o.date, type: 'production_use', ref: r.id }); });
    if (c.good > 0) changeStock(d, 'product', r.productId, c.good, { date: o.date, type: 'production', ref: r.id });
    return r;
  }
  function editProduction(d, id, o) {
    var r = byId(d.production, id); if (!r || r.voided) throw E('no_item');
    var c = cleanProduction(d, o);
    var nr = { productId: o.productId, good: c.good, consumption: c.consumption };
    applyNet(d, prodEffects(r), prodEffects(nr), { date: o.date, ref: id });
    history(r);
    r.date = o.date; r.productId = o.productId; r.good = c.good; r.defective = c.defective; r.grams = c.grams; r.consumption = c.consumption; r.notes = str(o.notes);
  }
  function voidProduction(d, id, reason) {
    var r = byId(d.production, id); if (!r || r.voided) throw E('no_item');
    if (r.good > 0) changeStock(d, 'product', r.productId, -r.good, { date: today(), type: 'void_production', ref: r.id, note: str(reason) });
    r.consumption.forEach(function (l) { changeStock(d, 'material', l.materialId, l.qty, { date: today(), type: 'void_production', ref: r.id, note: str(reason) }); });
    r.voided = true; r.voidReason = str(reason); r.voidedOn = today();
  }
  // Weighted-average purchase price per kg from confirmed purchases (optionally up to a date). null = unknown.
  function avgMaterialCost(d, matId, asOf) {
    var pur = d.purchases.filter(function (p) { return p.materialId === matId && !p.voided && (!asOf || p.date <= asOf); });
    var q = sum(pur, function (p) { return p.qty; });
    return q > 0 ? sum(pur, function (p) { return p.total; }) / q : null;
  }
  // Raw-material cost of one production record (good AND defective crates). Never invents numbers.
  function productionCost(d, r, asOf) {
    var missing = [], total = 0;
    if (!r.consumption.length) return { complete: false, total: 0, missing: [], noConsumption: true, perGood: null, defectCost: 0 };
    r.consumption.forEach(function (l) {
      var avg = avgMaterialCost(d, l.materialId, asOf);
      if (avg === null) missing.push(byId(d.materials, l.materialId).name); else total += Math.round(avg * l.qty);
    });
    var all = r.good + r.defective, complete = missing.length === 0;
    return { complete: complete, total: total, missing: missing, noConsumption: false,
      perGood: complete && r.good > 0 ? Math.round(total / r.good) : null,
      defectCost: complete && all > 0 ? Math.round(total * r.defective / all) : 0 };
  }

  /* ---------- expenses ---------- */
  function recordExpense(d, o) {
    needDate(o.date);
    if (!byId(d.expenseCats, o.categoryId)) throw E('category_required');
    var amount = needInt(o.amount); if (amount <= 0) throw E('bad_amount');
    var e = { id: uid('exp'), ts: stamp(), date: o.date, categoryId: o.categoryId, description: str(o.description), amount: amount, method: o.method || 'cash', notes: str(o.notes), voided: false };
    d.expenses.push(e); return e;
  }
  function editExpense(d, id, o) {
    var e = byId(d.expenses, id); if (!e || e.voided) throw E('no_item');
    needDate(o.date);
    if (!byId(d.expenseCats, o.categoryId)) throw E('category_required');
    var amount = needInt(o.amount); if (amount <= 0) throw E('bad_amount');
    history(e); e.date = o.date; e.categoryId = o.categoryId; e.description = str(o.description); e.amount = amount; e.method = o.method || e.method; e.notes = str(o.notes);
  }
  function voidExpense(d, id, reason) {
    var e = byId(d.expenses, id); if (!e || e.voided) throw E('no_item');
    e.voided = true; e.voidReason = str(reason); e.voidedOn = today();
  }

  /* ---------- workers, machines, weekly attendance ---------- */
  function addWorker(d, o) { var name = str(o.name); if (!name) throw E('name_required'); var w = { id: uid('wrk'), name: name, phone: str(o.phone), active: true, hireDate: hire(o.hireDate), created: today() }; d.workers.push(w); return w; }
  function updateWorker(d, id, o) {
    var w = byId(d.workers, id); if (!w) throw E('no_item');
    var name = str(o.name); if (!name) throw E('name_required');
    w.name = name; w.phone = str(o.phone); w.hireDate = hire(o.hireDate); if (typeof o.active === 'boolean') w.active = o.active;
  }
  function addMachine(d, o) { var name = str(o.name); if (!name) throw E('name_required'); var m = { id: uid('mch'), name: name }; d.machines.push(m); return m; }

  function hire(x) { x = str(x); if (!x) return ''; if (!validDate(x)) throw E('bad_date'); return x; }
  function updateMachine(d, id, o) { var m = byId(d.machines, id); if (!m) throw E('no_item'); var name = str(o.name); if (!name) throw E('name_required'); m.name = name; }
  function updateExpenseCat(d, id, o) { var c = byId(d.expenseCats, id); if (!c) throw E('no_item'); var name = str(o.name); if (!name) throw E('name_required'); c.name = name; delete c.key; }

  /* ---------- notes log ---------- */
  function addNote(d, o) { var text = str(o.text); if (!text) throw E('text_required'); if (!validDate(o.date)) throw E('bad_date'); var n = { id: uid('note'), date: o.date, title: str(o.title), text: text, ts: stamp() }; d.notes.push(n); return n; }
  function updateNote(d, id, o) { var n = byId(d.notes, id); if (!n) throw E('no_item'); var text = str(o.text); if (!text) throw E('text_required'); if (!validDate(o.date)) throw E('bad_date'); n.date = o.date; n.title = str(o.title); n.text = text; n.editedOn = today(); }

  /* ---------- delete anything: really removed when never used, otherwise archived (hidden, history kept) ---------- */
  var KIND = { customer: 'customers', supplier: 'suppliers', product: 'products', material: 'materials', expenseCat: 'expenseCats', worker: 'workers', machine: 'machines', note: 'notes' };
  function usedBy(d, kind, id) {
    var n = 0;
    function cnt(arr, f) { arr.forEach(function (r) { if (f(r)) n++; }); }
    if (kind === 'customer') { cnt(d.sales, function (r) { return r.customerId === id; }); cnt(d.payments, function (r) { return r.customerId === id; }); }
    else if (kind === 'supplier') { cnt(d.purchases, function (r) { return r.supplierId === id; }); cnt(d.supplierPayments, function (r) { return r.supplierId === id; }); }
    else if (kind === 'product') { cnt(d.sales, function (r) { return r.items.some(function (i) { return i.productId === id; }); }); cnt(d.production, function (r) { return r.productId === id; }); cnt(d.movements, function (r) { return r.kind === 'product' && r.itemId === id; }); }
    else if (kind === 'material') { cnt(d.purchases, function (r) { return r.materialId === id; }); cnt(d.production, function (r) { return (r.consumption || []).some(function (l) { return l.materialId === id; }); }); cnt(d.movements, function (r) { return r.kind === 'material' && r.itemId === id; }); }
    else if (kind === 'expenseCat') cnt(d.expenses, function (r) { return r.categoryId === id; });
    else if (kind === 'worker') cnt(d.attendance, function (r) { return r.workerId === id; });
    else if (kind === 'machine') cnt(d.attendance, function (r) { return r.machineId === id; });
    return n;
  }
  // returns 'deleted' | 'archived'
  function removeEntity(d, kind, id) {
    var key = KIND[kind]; if (!key) throw E('no_item');
    var it = byId(d[key], id); if (!it) throw E('no_item');
    if ((kind === 'product' || kind === 'material') && round3(it.stock) !== 0) throw E('stock_not_zero');
    if (kind === 'customer' && customerBalance(d, id) !== 0) throw E('balance_not_zero');
    if (kind === 'supplier' && supplierBalance(d, id) !== 0) throw E('balance_not_zero');
    if (kind === 'expenseCat' && d.expenseCats.filter(function (c) { return !c.archived; }).length <= 1) throw E('last_category');
    if (usedBy(d, kind, id) > 0) { it.archived = true; return 'archived'; }
    d[key] = d[key].filter(function (x) { return x.id !== id; });
    return 'deleted';
  }
  function activeOnly(list) { return list.filter(function (x) { return !x.archived; }); }
  // Replaces the roster of ONE (date, shift) cell. entries: [{workerId, worked, machineId}]
  // Rules: a worker can WORK at most one shift per day (no simultaneous / back-to-back double shifts).
  function setShiftRoster(d, o) {
    needDate(o.date);
    var sh = SHIFTS.filter(function (s) { return s.n === o.shift; })[0]; if (!sh) throw E('bad_shift');
    var seen = {}, clean = [];
    (o.entries || []).forEach(function (en) {
      var w0 = byId(d.workers, en.workerId); if (!w0) throw E('no_item');
      if (seen[w0.id]) throw E('duplicate_worker', { name: w0.name }); seen[w0.id] = 1;
    });
    (o.entries || []).forEach(function (en) {
      var w = byId(d.workers, en.workerId);
      if (en.machineId && !byId(d.machines, en.machineId)) throw E('no_item');
      if (en.worked) {
        var clash = d.attendance.filter(function (a) { return a.date === o.date && a.workerId === w.id && a.worked && a.shift !== o.shift; })[0];
        if (clash) throw E('worker_double_shift', { name: w.name, shift: clash.shift });
      }
      clean.push({ id: uid('att'), date: o.date, shift: o.shift, workerId: w.id, worked: !!en.worked, machineId: en.machineId || null });
    });
    d.attendance = d.attendance.filter(function (a) { return !(a.date === o.date && a.shift === o.shift); }).concat(clean);
  }
  function rosterFor(d, date, shift) { return d.attendance.filter(function (a) { return a.date === date && a.shift === shift; }); }
  function workerStats(d, from, to) {
    return d.workers.map(function (w) {
      var n = d.attendance.filter(function (a) { return a.workerId === w.id && a.worked && inRange(a.date, from, to); }).length;
      return { worker: w, shifts: n, hours: n * 8 };
    });
  }

  /* ---------- debts as of a date, reports, dashboard ---------- */
  function debtAsOf(d, kind, end) {
    var docs = kind === 'customer' ? d.sales : d.purchases, pays = kind === 'customer' ? d.payments : d.supplierPayments;
    return sum(live(docs).filter(function (x) { return x.date <= end; }), function (x) { return x.total; }) -
      sum(live(pays).filter(function (x) { return x.date <= end; }), function (x) { return x.amount; });
  }
  function totalCustomerDebt(d) { return sum(d.customers, function (c) { var b = customerBalance(d, c.id); return b > 0 ? b : 0; }); }
  function totalSupplierDebt(d) { return sum(d.suppliers, function (s) { var b = supplierBalance(d, s.id); return b > 0 ? b : 0; }); }

  function costOfProduction(d, from, to) {
    var recs = live(d.production).filter(function (r) { return inRange(r.date, from, to); });
    var total = 0, missing = [], noGrams = 0, good = 0, bad = 0, defectCost = 0;
    recs.forEach(function (r) {
      good += r.good; bad += r.defective;
      var c = productionCost(d, r, to || undefined);
      if (c.noConsumption) noGrams++;
      else if (!c.complete) c.missing.forEach(function (m) { if (missing.indexOf(m) < 0) missing.push(m); });
      else { total += c.total; defectCost += c.defectCost; }
    });
    return { total: total, missing: missing, noGrams: noGrams, good: good, defective: bad, defectCost: defectCost, records: recs.length, complete: missing.length === 0 && noGrams === 0 };
  }
  function expensesByCategory(d, from, to) {
    var m = {};
    live(d.expenses).filter(function (e) { return inRange(e.date, from, to); }).forEach(function (e) { m[e.categoryId] = (m[e.categoryId] || 0) + e.amount; });
    return Object.keys(m).map(function (k) { return { categoryId: k, amount: m[k] }; }).sort(function (a, b) { return b.amount - a.amount; });
  }
  // Monthly report. Operating profit is an ESTIMATE:
  //   sales  -  raw materials actually CONSUMED in production (good + defective, at average purchase cost)  -  recorded cash expenses
  // Purchases are shown separately: buying material is NOT the same as consuming it.
  function monthlyReport(d, ym) { var r = monthRange(ym), x = periodReport(d, r.from, r.to); x.ym = ym; return x; }
  // Same calculation for any date range (custom report).
  function periodReport(d, f, t) {
    var sales = live(d.sales).filter(function (s) { return inRange(s.date, f, t); });
    var revenue = sum(sales, function (s) { return s.total; });
    var crates = sum(sales, function (s) { return sum(s.items, function (i) { return i.qty; }); });
    var purchases = sum(live(d.purchases).filter(function (p) { return inRange(p.date, f, t); }), function (p) { return p.total; });
    var byCat = expensesByCategory(d, f, t), expenses = sum(byCat, function (c) { return c.amount; });
    var collected = sum(live(d.payments).filter(function (p) { return inRange(p.date, f, t); }), function (p) { return p.amount; });
    var cons = costOfProduction(d, f, t), warnings = [];
    if (cons.missing.length) warnings.push('missing_cost');
    if (cons.noGrams) warnings.push('no_grams');
    if (!cons.records && revenue > 0) warnings.push('no_production');
    var complete = cons.complete && warnings.indexOf('no_production') < 0; // sales but no recorded consumption -> no honest estimate
    var gross = complete ? revenue - cons.total : null;
    return { from: f, to: t, sales: revenue, salesCount: sales.length, cratesSold: crates, purchases: purchases, expenses: expenses, expensesByCat: byCat,
      collected: collected, good: cons.good, defective: cons.defective, defectCost: cons.defectCost, materialsCost: complete ? cons.total : null,
      missing: cons.missing, noGrams: cons.noGrams, warnings: warnings, grossMargin: gross, operatingProfit: complete ? gross - expenses : null,
      customerDebt: debtAsOf(d, 'customer', t || '9999-12-31'), supplierDebt: debtAsOf(d, 'supplier', t || '9999-12-31') };
  }
  function pctChange(cur, prev) { if (cur == null || prev == null || prev === 0) return null; return Math.round((cur - prev) * 1000 / Math.abs(prev)) / 10; }
  function compareMonths(cur, prev) {
    return { sales: pctChange(cur.sales, prev.sales), purchases: pctChange(cur.purchases, prev.purchases), expenses: pctChange(cur.expenses, prev.expenses),
      profit: pctChange(cur.operatingProfit, prev.operatingProfit), good: pctChange(cur.good, prev.good), collected: pctChange(cur.collected, prev.collected) };
  }
  function monthSeries(d, endYm, n) {
    var out = [];
    for (var i = n - 1; i >= 0; i--) { var ym = addMonths(endYm, -i), m = monthlyReport(d, ym); out.push({ ym: ym, sales: m.sales, purchases: m.purchases, expenses: m.expenses, profit: m.operatingProfit }); }
    return out;
  }
  function dailySales(d, ym) {
    var r = monthRange(ym), n = Number(r.to.slice(8)), a = [];
    for (var i = 1; i <= n; i++) a.push({ day: i, date: ym + '-' + pad2(i), total: 0 });
    live(d.sales).filter(function (s) { return inRange(s.date, r.from, r.to); }).forEach(function (s) { a[Number(s.date.slice(8)) - 1].total += s.total; });
    return a;
  }
  function dailyProduction(d, ym) {
    var r = monthRange(ym), n = Number(r.to.slice(8)), a = [];
    for (var i = 1; i <= n; i++) a.push({ day: i, date: ym + '-' + pad2(i), total: 0 });
    live(d.production).filter(function (x) { return inRange(x.date, r.from, r.to); }).forEach(function (x) { a[Number(x.date.slice(8)) - 1].total += x.good; });
    return a;
  }
  // One merged, newest-first feed of every transaction (used by the transactions screen and the dashboard).
  function feed(d) {
    var a = [];
    function add(kind, arr) { arr.forEach(function (x, i) { a.push({ kind: kind, id: x.id, date: x.date, ts: x.ts || '', idx: i, rec: x, voided: !!x.voided }); }); }
    add('sale', d.sales); add('purchase', d.purchases); add('expense', d.expenses); add('payment', d.payments.filter(function (p) { return !p.initial; }));
    add('spayment', d.supplierPayments.filter(function (p) { return !p.initial; })); add('production', d.production);
    a.sort(function (x, y) { return x.date < y.date ? 1 : x.date > y.date ? -1 : (x.ts < y.ts ? 1 : x.ts > y.ts ? -1 : y.idx - x.idx); });
    return a;
  }
  function dashboard(d, day) {
    var ym = day.slice(0, 7), mr = monthRange(ym), ts = live(d.sales).filter(function (s) { return s.date === day; });
    var m = monthlyReport(d, ym);
    return {
      todaySales: sum(ts, function (s) { return s.total; }), todaySalesCount: ts.length,
      todayCollected: sum(live(d.payments).filter(function (p) { return p.date === day; }), function (p) { return p.amount; }),
      todayProduction: sum(live(d.production).filter(function (r) { return r.date === day; }), function (r) { return r.good; }),
      monthSales: m.sales, monthPurchases: m.purchases, monthExpenses: m.expenses, monthProfit: m.operatingProfit, monthReport: m,
      customerDebt: totalCustomerDebt(d), supplierDebt: totalSupplierDebt(d),
      finishedStock: sum(d.products, function (p) { return p.stock; }), rawStock: round3(sum(d.materials, function (x) { return x.stock; })),
      lowProducts: d.products.filter(function (p) { return p.minStock > 0 && p.stock <= p.minStock; }),
      lowMaterials: d.materials.filter(function (x) { return x.minStock > 0 && x.stock <= x.minStock; })
    };
  }

  /* ---------- migration (schema 1 -> 2) and backup ---------- */
  var CAT_KEYS = { cat_electricity: 'electricity', cat_salaries: 'salaries', cat_transport: 'transport', cat_maintenance: 'maintenance', cat_other: 'other' };
  // Pure function: never touches its input. The caller keeps the original file as a safety copy.
  function migrate(obj) {
    var d = clone(obj);
    if (d.schema === SCHEMA) return d;
    if (d.schema !== 1) throw E('bad_schema');
    var base = emptyData();
    d.settings = Object.assign({}, base.settings, d.settings || {});
    d.products.forEach(function (p) {
      if (p.weightG == null) p.weightG = 0; if (!p.recipe) p.recipe = {};
      if (!p.color) p.color = p.id === 'prod_large' ? 'blue' : p.id === 'prod_small' ? 'red' : 'gray';
    });
    d.expenseCats.forEach(function (c) { if (!c.key && CAT_KEYS[c.id]) c.key = CAT_KEYS[c.id]; });
    var order = d.sales.map(function (s, i) { return { s: s, i: i }; }).sort(function (a, b) { return a.s.date < b.s.date ? -1 : a.s.date > b.s.date ? 1 : a.i - b.i; });
    order.forEach(function (x, n) {
      var s = x.s;
      s.items = [{ productId: s.productId, qty: s.qty, unitPrice: s.unitPrice, weightG: 0 }];
      s.subtotal = s.total; s.discount = 0; s.no = n + 1;
      delete s.productId; delete s.qty; delete s.unitPrice;
    });
    d.counters = { invoice: d.sales.length };
    d.production.forEach(function (r) { r.good = r.qty; r.defective = 0; r.grams = {}; delete r.qty; });
    d.workers = d.workers || []; d.machines = d.machines || []; d.attendance = d.attendance || []; d.notes = d.notes || [];
    d.schema = SCHEMA; d.app = 'KHALDI_PLAST';
    return d;
  }

  function makeBackup(d) { return { app: BACKUP_ID, schema: SCHEMA, exportedAt: stamp(), data: d }; }

  var ARRAYS = ['customers', 'suppliers', 'products', 'materials', 'expenseCats', 'production', 'sales', 'payments', 'purchases', 'supplierPayments', 'expenses', 'movements', 'workers', 'machines', 'attendance'];
  // Returns {ok:true, data, migrated} or {ok:false, errors}. Never modifies anything it is given.
  function validateBackup(obj) {
    var errors = [];
    if (!obj || typeof obj !== 'object' || obj.app !== BACKUP_ID) return { ok: false, errors: ['not_a_backup'] };
    if (obj.schema !== 1 && obj.schema !== 2) return { ok: false, errors: ['bad_schema'] };
    if (!obj.data || typeof obj.data !== 'object') return { ok: false, errors: ['not_a_backup'] };
    var d = obj.data, migrated = false;
    if (obj.schema === 1) {
      var old1 = ['customers', 'suppliers', 'products', 'materials', 'expenseCats', 'production', 'sales', 'payments', 'purchases', 'supplierPayments', 'expenses', 'movements'];
      old1.forEach(function (k) { if (!Array.isArray(d[k])) errors.push('missing:' + k); });
      if (!d.settings || typeof d.settings !== 'object') errors.push('missing:settings');
      if (errors.length) return { ok: false, errors: errors };
      try { d = migrate(Object.assign({}, d, { schema: 1 })); migrated = true; } catch (e) { return { ok: false, errors: ['migration_failed'] }; }
    }
    ARRAYS.forEach(function (k) { if (!Array.isArray(d[k])) errors.push('missing:' + k); });
    if (!d.settings || typeof d.settings !== 'object') errors.push('missing:settings');
    if (!d.counters || typeof d.counters.invoice !== 'number') errors.push('missing:counters');
    if (errors.length) return { ok: false, errors: errors };

    if (!Array.isArray(d.notes)) d = Object.assign({}, d, { notes: [] });
    var ids = {};
    ARRAYS.concat(['notes']).forEach(function (k) { d[k].forEach(function (r) { if (!r || typeof r.id !== 'string' || !r.id) errors.push('bad_id:' + k); else if (ids[r.id]) errors.push('dup_id:' + r.id); else ids[r.id] = k; }); });
    function isInt(n) { return typeof n === 'number' && isFinite(n) && Math.floor(n) === n && n >= 0; }
    function ref(arr, id, label) { if (!byId(arr, id)) errors.push('bad_ref:' + label); }
    d.products.forEach(function (p) { if (typeof p.stock !== 'number' || p.stock < 0) errors.push('bad_stock:' + p.id); });
    d.materials.forEach(function (m) { if (typeof m.stock !== 'number' || m.stock < 0) errors.push('bad_stock:' + m.id); });
    d.sales.forEach(function (s) {
      if (!validDate(s.date) || !isInt(s.total) || !isInt(s.subtotal) || !isInt(s.discount) || !Array.isArray(s.items) || !s.items.length || !isInt(s.no)) { errors.push('bad_sale:' + s.id); return; }
      if (s.subtotal - s.discount !== s.total) errors.push('bad_sale_total:' + s.id);
      s.items.forEach(function (it) { if (!isInt(it.qty) || !isInt(it.unitPrice)) errors.push('bad_sale:' + s.id); ref(d.products, it.productId, 'sale.product'); });
      if (s.customerId) ref(d.customers, s.customerId, 'sale.customer');
      if (!s.voided && salePaid(d, s.id) > s.total) errors.push('overpaid:' + s.id);
    });
    d.payments.forEach(function (p) { if (!validDate(p.date) || !isInt(p.amount)) errors.push('bad_payment:' + p.id); ref(d.sales, p.saleId, 'payment.sale'); });
    d.purchases.forEach(function (p) {
      if (!validDate(p.date) || !isInt(p.total) || !isInt(p.unitCost)) errors.push('bad_purchase:' + p.id);
      ref(d.materials, p.materialId, 'purchase.material'); ref(d.suppliers, p.supplierId, 'purchase.supplier');
    });
    d.supplierPayments.forEach(function (p) { if (!validDate(p.date) || !isInt(p.amount)) errors.push('bad_supplier_payment:' + p.id); ref(d.purchases, p.purchaseId, 'spay.purchase'); });
    d.expenses.forEach(function (e) { if (!validDate(e.date) || !isInt(e.amount)) errors.push('bad_expense:' + e.id); ref(d.expenseCats, e.categoryId, 'expense.category'); });
    d.production.forEach(function (r) {
      if (!validDate(r.date) || !isInt(r.good) || !isInt(r.defective) || !Array.isArray(r.consumption)) { errors.push('bad_production:' + r.id); return; }
      ref(d.products, r.productId, 'production.product'); r.consumption.forEach(function (l) { ref(d.materials, l.materialId, 'production.material'); });
    });
    d.movements.forEach(function (m) { if (typeof m.qty !== 'number') errors.push('bad_movement:' + m.id); ref(m.kind === 'product' ? d.products : d.materials, m.itemId, 'movement.item'); });
    var seenAtt = {};
    d.attendance.forEach(function (a) {
      if (!validDate(a.date) || [1, 2, 3].indexOf(a.shift) < 0) errors.push('bad_attendance:' + a.id);
      ref(d.workers, a.workerId, 'attendance.worker'); if (a.machineId) ref(d.machines, a.machineId, 'attendance.machine');
      var k = a.date + '|' + a.shift + '|' + a.workerId; if (seenAtt[k]) errors.push('dup_attendance:' + a.id); seenAtt[k] = 1;
    });
    // Stock must equal the sum of its movements (catches damaged or hand-edited files).
    [['product', d.products], ['material', d.materials]].forEach(function (pair) {
      pair[1].forEach(function (it) {
        var s = round3(sum(d.movements.filter(function (m) { return m.kind === pair[0] && m.itemId === it.id; }), function (m) { return m.qty; }));
        if (s !== round3(it.stock)) errors.push('stock_mismatch:' + it.name);
      });
    });
    if (errors.length) return { ok: false, errors: errors.slice(0, 8) };
    var out = clone(d); out.app = 'KHALDI_PLAST'; out.schema = SCHEMA;
    out.settings = Object.assign({}, emptyData().settings, d.settings);
    return { ok: true, data: out, migrated: migrated };
  }

  var API = {
    SHIFTS: SHIFTS, SCHEMA: SCHEMA, E: E, uid: uid, clone: clone, byId: byId, sum: sum, live: live, tx: tx, round3: round3,
    parseMoney: parseMoney, parseQty: parseQty, fmtMoney: fmtMoney, fmtQty: fmtQty, groupInt: groupInt,
    today: today, addDays: addDays, validDate: validDate, inRange: inRange, fmtDate: fmtDate, monthRange: monthRange, addMonths: addMonths,
    startOfWeek: startOfWeek, weekDates: weekDates, weekdayIndex: weekdayIndex, pad2: pad2,
    emptyData: emptyData,
    addCustomer: addCustomer, addSupplier: addSupplier, updateParty: updateParty, addProduct: addProduct, updateProduct: updateProduct,
    addMaterial: addMaterial, updateMaterial: updateMaterial, addExpenseCat: addExpenseCat, adjustStock: adjustStock,
    recordPurchase: recordPurchase, editPurchase: editPurchase, recordSupplierPayment: recordSupplierPayment, editSupplierPayment: editSupplierPayment,
    voidPurchase: voidPurchase, voidSupplierPayment: voidSupplierPayment, purchaseOutstanding: purchaseOutstanding,
    recordSale: recordSale, editSale: editSale, recordCustomerPayment: recordCustomerPayment, editPayment: editPayment, voidSale: voidSale, voidPayment: voidPayment,
    saleOutstanding: saleOutstanding, salePaid: salePaid, saleMethod: saleMethod, customerBalance: customerBalance, supplierBalance: supplierBalance,
    recordProduction: recordProduction, editProduction: editProduction, voidProduction: voidProduction, productionCost: productionCost, avgMaterialCost: avgMaterialCost,
    recordExpense: recordExpense, editExpense: editExpense, voidExpense: voidExpense,
    addWorker: addWorker, updateWorker: updateWorker, addMachine: addMachine, updateMachine: updateMachine, updateExpenseCat: updateExpenseCat, addNote: addNote, updateNote: updateNote, removeEntity: removeEntity, usedBy: usedBy, activeOnly: activeOnly, setShiftRoster: setShiftRoster, rosterFor: rosterFor, workerStats: workerStats,
    debtAsOf: debtAsOf, totalCustomerDebt: totalCustomerDebt, totalSupplierDebt: totalSupplierDebt, expensesByCategory: expensesByCategory,
    monthlyReport: monthlyReport, periodReport: periodReport, compareMonths: compareMonths, monthSeries: monthSeries, dailySales: dailySales, dailyProduction: dailyProduction,
    feed: feed, dashboard: dashboard, migrate: migrate, makeBackup: makeBackup, validateBackup: validateBackup
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.KP = API;
})(typeof window !== 'undefined' ? window : this);
