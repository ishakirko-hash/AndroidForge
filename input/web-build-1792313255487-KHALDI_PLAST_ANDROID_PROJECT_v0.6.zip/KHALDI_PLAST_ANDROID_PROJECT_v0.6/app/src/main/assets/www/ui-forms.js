/* KHALDI PLAST - data-entry forms (create AND edit). Business rules live in core.js. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, F = U.forms = {};

  function done(msg) { U.closeModal(); U.render(true); U.toast(msg || t('saved_ok'), 'ok'); }
  function resolveParty(d, v, field, kind) {
    if (v[field] === '__new__') {
      var o = { name: v[field + '_new'] };
      return (kind === 'customer' ? K.addCustomer(d, o) : kind === 'supplier' ? K.addSupplier(d, o) : K.addExpenseCat(d, o)).id;
    }
    return v[field] || null;
  }
  function partyOptions(list, extra) { return (extra || []).concat(list.map(function (p) { return { v: p.id, l: p.name + (p.phone ? ' - ' + p.phone : '') }; })); }

  /* ---------- sale / invoice ---------- */
  F.sale = function (editId) {
    var D = U.D, s = editId ? K.byId(D.sales, editId) : null, prods = D.products.filter(function (p) { return !p.archived || (s && s.items.some(function (i) { return i.productId === p.id; })); });
    if (!prods.length) { U.toast(t('err_no_product'), 'bad'); return; }
    var rows = s ? s.items.map(function (it) { return { product: it.productId, qty: String(it.qty), price: U.forInput(it.unitPrice), weight: it.weightG ? String(it.weightG) : '' }; })
      : [{ product: prods[0].id, qty: '', price: U.forInput(prods[0].price), weight: prods[0].weightG ? String(prods[0].weightG) : '' }];
    var fields = [
      { name: 'date', label: t('date'), type: 'date', value: s ? s.date : K.today() },
      { name: 'customer', label: t('customer'), type: 'select', allowNew: true, newLabel: t('new_customer'), value: s ? (s.customerId || '') : '', options: partyOptions(U.act(D.customers, s ? s.customerId : ''), [{ v: '', l: t('walkin') }]) },
      { name: 'items', label: t('invoice_items'), type: 'items', rows: rows, products: prods },
      { name: 'discount', label: t('discount'), type: 'money', optional: true, value: s ? U.forInput(s.discount) : '' }
    ];
    if (!s) { fields.push({ name: 'paid', label: t('amount_paid'), type: 'money', optional: true }); fields.push({ name: 'method', label: t('pay_method'), type: 'select', options: U.methodOptions() }); }
    fields.push({ name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: s ? s.notes : '' });
    function parsedItems(v) {
      var out = [];
      for (var i = 0; i < v.items.length; i++) {
        var r = v.items[i], q = K.parseQty(r.qty, false), p = K.parseMoney(r.price, U.mode());
        if (!q.ok || !p.ok || q.q <= 0) return null;
        var g = String(r.weight || '').trim() ? K.parseQty(r.weight, false) : { ok: true, q: 0 };
        out.push({ productId: r.product, qty: q.q, unitPrice: p.c, weightG: g.ok ? g.q : 0 });
      }
      return out;
    }
    U.openForm({
      title: s ? t('edit_invoice') + ' ' + U.invNo(s.no) : t('new_sale'), submit: s ? t('save_changes') : t('save_sale'), fields: fields,
      intro: s ? esc(t('edit_sale_note')) : '',
      extra: s ? null : [
        { label: t('paid_full'), run: function (f) { var it = parsedItems({ items: [].slice.call(f.querySelectorAll('.itrow')).map(function (el) { return { product: el.querySelector('[data-k=product]').value, qty: el.querySelector('[data-k=qty]').value, price: el.querySelector('[data-k=price]').value }; }) }), dsc = f.elements.discount.value.trim() ? K.parseMoney(f.elements.discount.value, U.mode()) : { ok: true, c: 0 };
          if (it && dsc.ok) { var sub = K.sum(it, function (x) { return x.qty * x.unitPrice; }); f.elements.paid.value = U.forInput(Math.max(0, sub - dsc.c)); } } },
        { label: t('paid_none'), run: function (f) { f.elements.paid.value = ''; } }
      ],
      calc: function (v) {
        var it = parsedItems(v); if (!it) return '';
        var sub = K.sum(it, function (x) { return x.qty * x.unitPrice; }), dsc = v.discount.trim() ? K.parseMoney(v.discount, U.mode()) : { ok: true, c: 0 };
        if (!dsc.ok) return '';
        var total = sub - dsc.c, kg = K.sum(it, function (x) { return x.qty * x.weightG; }) / 1000;
        var out = t('subtotal') + ': <b>' + U.money(sub) + '</b>' + (dsc.c ? '<br>' + t('discount') + ': <b>' + U.money(dsc.c) + '</b>' : '') + '<br>' + t('grand_total') + ': <b>' + U.money(total) + '</b>';
        if (kg > 0) out += '<br>' + t('total_weight') + ': <b>' + U.qty(K.round3(kg)) + ' ' + t('kg') + '</b>';
        if (!s) { var pd = v.paid.trim() ? K.parseMoney(v.paid, U.mode()) : { ok: true, c: 0 }; if (pd.ok) out += '<br>' + t('remaining') + ': <b>' + U.money(total - pd.c) + '</b>' + (pd.c < total ? ' ' + U.badge(t('on_credit'), 'amber') : ''); }
        return out;
      },
      onSubmit: function (v) {
        var items = v.items.map(function (r) { return { productId: r.product, qty: U.parseQ(r.qty, false, true), unitPrice: U.parseM(r.price, true), weightG: U.parseG(r.weight) }; });
        var discount = U.parseM(v.discount, false), paid = s ? 0 : U.parseM(v.paid, false), newId = null;
        U.commit(function (d) {
          var cid = resolveParty(d, v, 'customer', 'customer');
          if (s) K.editSale(d, s.id, { date: v.date, customerId: cid, items: items, discount: discount, notes: v.notes });
          else newId = K.recordSale(d, { date: v.date, customerId: cid, items: items, discount: discount, paid: paid, method: v.method, notes: v.notes }).id;
        });
        U.closeModal(); U.toast(t('saved_ok'), 'ok');
        if (newId) U.go('invoice', newId, true); else U.render(true);
      }
    });
  };

  /* ---------- production ---------- */
  F.production = function (editId) {
    var D = U.D, r = editId ? K.byId(D.production, editId) : null, mats = U.act(D.materials), p0 = r ? K.byId(D.products, r.productId) : U.act(D.products)[0];
    if (!p0) { U.toast(t('err_no_product'), 'bad'); return; }
    var fields = [
      { name: 'date', label: t('date'), type: 'date', value: r ? r.date : K.today() },
      { name: 'product', label: t('product'), type: 'select', value: p0.id, options: U.act(D.products, r ? r.productId : '').map(function (p) { return { v: p.id, l: p.name }; }) },
      { name: 'good', label: t('good_crates'), type: 'qty', ph: '0', value: r ? String(r.good) : '' },
      { name: 'bad', label: t('defective_crates'), type: 'qty', ph: '0', optional: true, value: r && r.defective ? String(r.defective) : '' },
      { type: 'html', html: '<label style="margin-top:16px">' + esc(t('grams_per_crate')) + '</label><div class="muted">' + esc(t('grams_hint')) + '</div>' }
    ];
    mats.forEach(function (m) {
      var g = r ? (r.grams[m.id] || '') : (p0.recipe[m.id] || '');
      fields.push({ name: 'g_' + m.id, label: m.name + ' (' + t('gram') + ' / ' + t('crate') + ') - ' + t('in_stock') + ' ' + K.fmtQty(m.stock) + ' ' + t('kg'), type: 'grams', optional: true, ph: '0', value: g === '' ? '' : String(g) });
    });
    fields.push({ name: 'saveRecipe', label: t('save_recipe'), type: 'check', value: false });
    fields.push({ name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: r ? r.notes : '' });
    function gramsOf(v) {
      var g = {}; mats.forEach(function (m) { var s = (v['g_' + m.id] || '').trim(); if (!s) return; var x = K.parseQty(s, false); if (x.ok && x.q > 0) g[m.id] = x.q; }); return g;
    }
    U.openForm({
      title: r ? t('edit_production') : t('new_production'), submit: r ? t('save_changes') : t('save_production'), fields: fields,
      onChange: function (form, name) {
        if (name === 'product' && !r) { var p = K.byId(U.D.products, form.elements.product.value); mats.forEach(function (m) { form.elements['g_' + m.id].value = p && p.recipe[m.id] ? p.recipe[m.id] : ''; }); }
      },
      calc: function (v) {
        var g = K.parseQty(v.good || '0', false), b = K.parseQty(v.bad || '0', false); if (!g.ok || !b.ok || g.q + b.q <= 0) return '';
        var total = g.q + b.q, gr = gramsOf(v), out = t('total_crates') + ': <b>' + U.qty(total) + '</b> (' + t('good_short') + ' ' + g.q + ' / ' + t('defective_short') + ' ' + b.q + ')', lines = [];
        Object.keys(gr).forEach(function (mid) { lines.push({ materialId: mid, qty: K.round3(total * gr[mid] / 1000) }); });
        if (!lines.length) return out + '<br><span class="muted">' + t('cost_unknown_noconsumption') + '</span>';
        lines.forEach(function (l) { var m = K.byId(D.materials, mid(l)); out += '<br>' + esc(m.name) + ': <b>' + U.qty(l.qty) + ' ' + t('kg') + '</b>'; });
        function mid(l) { return l.materialId; }
        var c = K.productionCost(D, { consumption: lines, good: g.q, defective: b.q });
        if (!c.complete) return out + '<br>' + t('cost_missing') + ': <b>' + esc(c.missing.join(', ')) + '</b>';
        out += '<br>' + t('est_cost') + ': <b>' + U.money(c.total) + '</b>';
        if (g.q > 0) out += '<br>' + t('cost_per_good') + ': <b>' + U.money(c.perGood) + '</b>';
        if (b.q > 0) out += '<br>' + t('defect_loss') + ': <b>' + U.money(c.defectCost) + '</b>';
        return out + '<div class="muted">' + t('cost_note') + '</div>';
      },
      onSubmit: function (v) {
        var good = U.parseQ(v.good, false, false), bad = U.parseQ(v.bad, false, false), grams = {};
        mats.forEach(function (m) { var g = U.parseG(v['g_' + m.id]); if (g) grams[m.id] = g; });
        U.commit(function (d) {
          if (r) K.editProduction(d, r.id, { date: v.date, productId: v.product, good: good, defective: bad, grams: grams, notes: v.notes });
          else K.recordProduction(d, { date: v.date, productId: v.product, good: good, defective: bad, grams: grams, notes: v.notes });
          if (v.saveRecipe) K.byId(d.products, v.product).recipe = grams;
        });
        done();
      }
    });
  };

  /* ---------- purchase ---------- */
  F.purchase = function (editId) {
    var D = U.D, p = editId ? K.byId(D.purchases, editId) : null;
    var fields = [
      { name: 'date', label: t('date'), type: 'date', value: p ? p.date : K.today() },
      { name: 'supplier', label: t('supplier'), type: 'select', allowNew: true, newLabel: t('new_supplier'), value: p ? p.supplierId : '', options: partyOptions(U.act(D.suppliers, p ? p.supplierId : '')) },
      { name: 'material', label: t('material'), type: 'select', value: p ? p.materialId : '', options: U.act(D.materials, p ? p.materialId : '').map(function (m) { return { v: m.id, l: m.name + ' (' + t('kg') + ')' }; }) },
      { name: 'qty', label: t('quantity') + ' (' + t('kg') + ')', type: 'qtyd', ph: '0', value: p ? String(p.qty) : '' },
      { name: 'cost', label: t('unit_cost_per_kg'), type: 'money', value: p ? U.forInput(p.unitCost) : '' }
    ];
    if (!p) { fields.push({ name: 'paid', label: t('amount_paid'), type: 'money', optional: true }); fields.push({ name: 'method', label: t('pay_method'), type: 'select', options: U.methodOptions() }); }
    fields.push({ name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: p ? p.notes : '' });
    U.openForm({
      title: p ? t('edit_purchase') : t('new_purchase'), submit: p ? t('save_changes') : t('save_purchase'), fields: fields,
      extra: p ? null : [{ label: t('paid_full'), run: function (f) { var q = K.parseQty(f.elements.qty.value, true), c = K.parseMoney(f.elements.cost.value, U.mode()); if (q.ok && c.ok) f.elements.paid.value = U.forInput(Math.round(q.q * c.c)); } }],
      calc: function (v) {
        var q = K.parseQty(v.qty, true), c = K.parseMoney(v.cost, U.mode()); if (!q.ok || !c.ok) return '';
        var total = Math.round(q.q * c.c), out = t('total') + ': <b>' + U.money(total) + '</b>';
        if (!p) { var pd = v.paid.trim() ? K.parseMoney(v.paid, U.mode()) : { ok: true, c: 0 }; if (pd.ok) out += '<br>' + t('remaining') + ': <b>' + U.money(total - pd.c) + '</b>'; }
        return out;
      },
      onSubmit: function (v) {
        var q = U.parseQ(v.qty, true, true), c = U.parseM(v.cost, true), paid = p ? 0 : U.parseM(v.paid, false);
        U.commit(function (d) {
          var sid = resolveParty(d, v, 'supplier', 'supplier');
          if (p) K.editPurchase(d, p.id, { date: v.date, supplierId: sid, materialId: v.material, qty: q, unitCost: c, notes: v.notes });
          else K.recordPurchase(d, { date: v.date, supplierId: sid, materialId: v.material, qty: q, unitCost: c, paid: paid, method: v.method, notes: v.notes });
        });
        done();
      }
    });
  };

  /* ---------- expense ---------- */
  F.expense = function (editId) {
    var D = U.D, e = editId ? K.byId(D.expenses, editId) : null;
    U.openForm({
      title: e ? t('edit_expense') : t('new_expense'), submit: e ? t('save_changes') : t('save'),
      fields: [
        { name: 'date', label: t('date'), type: 'date', value: e ? e.date : K.today() },
        { name: 'cat', label: t('category'), type: 'select', allowNew: true, newLabel: t('new_category'), value: e ? e.categoryId : '', options: U.act(D.expenseCats, e ? e.categoryId : '').map(function (c) { return { v: c.id, l: U.catName(c.id) }; }) },
        { name: 'desc', label: t('description'), type: 'text', optional: true, value: e ? e.description : '' },
        { name: 'amount', label: t('amount'), type: 'money', value: e ? U.forInput(e.amount) : '' },
        { name: 'method', label: t('pay_method'), type: 'select', value: e ? e.method : 'cash', options: U.methodOptions() },
        { name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: e ? e.notes : '' }
      ],
      onSubmit: function (v) {
        var amount = U.parseM(v.amount, true);
        U.commit(function (d) {
          var cid = resolveParty(d, v, 'cat', 'cat'), o = { date: v.date, categoryId: cid, description: v.desc, amount: amount, method: v.method, notes: v.notes };
          if (e) K.editExpense(d, e.id, o); else K.recordExpense(d, o);
        });
        done();
      }
    });
  };

  /* ---------- parties ---------- */
  /* delete anything: unused -> removed, used in history -> archived (hidden, history kept). Always asks first. */
  F.remove = function (kind, id, label, after) {
    var it = K.byId(U.D[{ customer: 'customers', supplier: 'suppliers', product: 'products', material: 'materials', expenseCat: 'expenseCats', worker: 'workers', machine: 'machines', note: 'notes' }[kind]], id);
    var used = K.usedBy(U.D, kind, id);
    U.openForm({
      title: t('delete_item') + ': ' + (label || (it && (it.name || it.title)) || ''), submit: t('delete_confirm'), danger: true, fields: [],
      intro: '<div class="alert red">' + esc(used ? t('delete_used_note', { n: used }) : t('delete_unused_note')) + '</div>',
      onSubmit: function () {
        var res; U.commit(function (d) { res = K.removeEntity(d, kind, id); });
        U.closeModal(); U.toast(t(res === 'archived' ? 'archived_ok' : 'deleted_item_ok'), 'ok'); if (after) after(); else U.render(true);
      }
    });
  };
  F.party = function (kind, id) {
    var p = id ? K.byId(kind === 'customer' ? U.D.customers : U.D.suppliers, id) : null;
    U.openForm({
      title: t(p ? 'edit' : (kind === 'customer' ? 'new_customer' : 'new_supplier')), submit: t('save'),
      fields: [{ name: 'name', label: t('name'), type: 'text', value: p ? p.name : '' }, { name: 'phone', label: t('phone'), type: 'text', optional: true, value: p ? p.phone : '' },
        { name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: p ? p.notes : '' }],
      onDelete: p ? function () { F.remove(kind, id, p.name, function () { U.stack = []; U.route = 'debts'; U.arg = null; U.render(); }); } : null,
      onSubmit: function (v) { U.commit(function (d) { if (p) K.updateParty(d, kind, id, v); else (kind === 'customer' ? K.addCustomer : K.addSupplier)(d, v); }); done(); }
    });
  };
  // Pick a customer/supplier, then open the payment form (used by the "+" quick menu).
  F.pickParty = function (kind) {
    var list = U.act(kind === 'customer' ? U.D.customers : U.D.suppliers);
    if (!list.length) { U.toast(t('no_records'), 'bad'); return; }
    U.openForm({ title: t(kind === 'customer' ? 'receive_payment' : 'pay_supplier'), submit: t('next'), fields: [{ name: 'party', label: t(kind === 'customer' ? 'customer' : 'supplier'), type: 'select', options: partyOptions(list) }],
      onSubmit: function (v) { U.closeModal(); F.payment(kind, v.party); } });
  };

  /* ---------- payments (new + EDIT of a saved payment) ---------- */
  F.payment = function (kind, pid) {
    var D = U.D, isC = kind === 'customer';
    var open = isC ? D.sales.filter(function (s) { return s.customerId === pid && !s.voided && K.saleOutstanding(D, s.id) > 0; }) : D.purchases.filter(function (p) { return p.supplierId === pid && !p.voided && K.purchaseOutstanding(D, p.id) > 0; });
    open.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    if (!open.length) { U.toast(t('nothing_owed'), 'bad'); return; }
    var bal = isC ? K.customerBalance(D, pid) : K.supplierBalance(D, pid), name = isC ? U.custName(pid) : U.supName(pid);
    U.openForm({
      title: t(isC ? 'receive_payment' : 'pay_supplier') + ': ' + name, submit: t('save'), intro: t('balance') + ': <b>' + U.money(bal) + '</b>',
      fields: [
        { name: 'date', label: t('date'), type: 'date', value: K.today() },
        { name: 'doc', label: t('apply_to'), type: 'select', options: [{ v: '', l: t('oldest_first') }].concat(open.map(function (x) {
          return { v: x.id, l: K.fmtDate(x.date) + ' - ' + (isC ? U.invNo(x.no) : U.matName(x.materialId)) + ' - ' + t('remaining') + ' ' + U.moneyTxt(isC ? K.saleOutstanding(D, x.id) : K.purchaseOutstanding(D, x.id)) }; })) },
        { name: 'amount', label: t('amount'), type: 'money' },
        { name: 'method', label: t('pay_method'), type: 'select', options: U.methodOptions() },
        { name: 'notes', label: t('notes'), type: 'textarea', optional: true }
      ],
      extra: [{ label: t('pay_all'), run: function (f) { var id = f.elements.doc.value; f.elements.amount.value = U.forInput(id ? (isC ? K.saleOutstanding(D, id) : K.purchaseOutstanding(D, id)) : bal); } }],
      onSubmit: function (v) {
        var amount = U.parseM(v.amount, true);
        U.commit(function (d) {
          if (isC) K.recordCustomerPayment(d, { date: v.date, customerId: pid, saleId: v.doc || null, amount: amount, method: v.method, notes: v.notes });
          else K.recordSupplierPayment(d, { date: v.date, supplierId: pid, purchaseId: v.doc || null, amount: amount, method: v.method, notes: v.notes });
        });
        done();
      }
    });
  };
  F.editPayment = function (kind, id) {
    var D = U.D, isC = kind === 'customer', x = K.byId(isC ? D.payments : D.supplierPayments, id); if (!x) return;
    var doc = K.byId(isC ? D.sales : D.purchases, isC ? x.saleId : x.purchaseId), others = K.sum((isC ? D.payments : D.supplierPayments).filter(function (y) { return (isC ? y.saleId === x.saleId : y.purchaseId === x.purchaseId) && !y.voided && y.id !== id; }), function (y) { return y.amount; });
    var maxAmt = doc.total - others;
    U.openForm({
      title: t('edit_payment'), submit: t('save_changes'),
      intro: esc(isC ? U.custName(x.customerId) : U.supName(x.supplierId)) + ' - ' + (isC ? U.invNo(doc.no) : esc(U.matName(doc.materialId))) + '<br>' + t('max_allowed') + ': <b>' + U.money(maxAmt) + '</b><div class="muted">' + t('edit_payment_note') + '</div>',
      fields: [
        { name: 'date', label: t('date'), type: 'date', value: x.date },
        { name: 'amount', label: t('amount'), type: 'money', value: U.forInput(x.amount) },
        { name: 'method', label: t('pay_method'), type: 'select', value: x.method, options: U.methodOptions() },
        { name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: x.notes }
      ],
      calc: function (v) {
        var a = K.parseMoney(v.amount, U.mode()); if (!a.ok) return '';
        return t('new_remaining') + ': <b>' + U.money(doc.total - others - a.c) + '</b>';
      },
      onSubmit: function (v) {
        var amount = U.parseM(v.amount, true);
        U.commit(function (d) { (isC ? K.editPayment : K.editSupplierPayment)(d, id, { date: v.date, amount: amount, method: v.method, notes: v.notes }); });
        done(t('payment_updated'));
      }
    });
  };

  /* ---------- products / materials / stock ---------- */
  F.item = function (kind, id) {
    var D = U.D, isP = kind === 'product', it = id ? K.byId(isP ? D.products : D.materials, id) : null;
    var fields = [{ name: 'name', label: t('name'), type: 'text', value: it ? it.name : '' }];
    if (isP) {
      fields.push({ name: 'code', label: t('code'), type: 'text', optional: true, value: it ? it.code : '' });
      fields.push({ name: 'color', label: t('color'), type: 'select', value: it ? it.color : 'blue', options: ['blue', 'green', 'red', 'black', 'gray'].map(function (c) { return { v: c, l: t('col_' + c) }; }) });
      fields.push({ name: 'price', label: t('default_price'), type: 'money', optional: true, value: it ? U.forInput(it.price) : '' });
      fields.push({ name: 'weight', label: t('weight_per_crate') + ' (' + t('gram') + ')', type: 'grams', optional: true, value: it && it.weightG ? String(it.weightG) : '' });
      U.act(D.materials).forEach(function (m) { fields.push({ name: 'g_' + m.id, label: t('recipe_for') + ' ' + m.name + ' (' + t('gram') + ' / ' + t('crate') + ')', type: 'grams', optional: true, value: it && it.recipe[m.id] ? String(it.recipe[m.id]) : '' }); });
    }
    fields.push({ name: 'min', label: t('min_stock'), type: isP ? 'qty' : 'qtyd', optional: true, value: it && it.minStock ? String(it.minStock) : '' });
    if (!it) fields.push({ name: 'open', label: t('opening_stock'), type: isP ? 'qty' : 'qtyd', optional: true });
    U.openForm({
      title: t(it ? 'edit' : (isP ? 'new_product' : 'new_material')), submit: t('save'), fields: fields,
      onDelete: it ? function () { F.remove(kind, id, it.name); } : null,
      onSubmit: function (v) {
        var recipe = {}; if (isP) U.act(D.materials).forEach(function (m) { var g = U.parseG(v['g_' + m.id]); if (g) recipe[m.id] = g; });
        var o = { name: v.name, code: v.code, color: v.color, minStock: U.parseQ(v.min, !isP, false), price: isP ? U.parseM(v.price, false) : 0, weightG: isP ? U.parseG(v.weight) : 0, recipe: recipe, openingStock: it ? 0 : U.parseQ(v.open, !isP, false) };
        U.commit(function (d) { if (isP) { if (it) K.updateProduct(d, id, o); else K.addProduct(d, o); } else { if (it) K.updateMaterial(d, id, o); else K.addMaterial(d, o); } });
        done();
      }
    });
  };
  F.adjust = function (kind, id) {
    var it = K.byId(kind === 'product' ? U.D.products : U.D.materials, id);
    U.openForm({
      title: t('adjust_stock') + ': ' + it.name, intro: t('current_stock') + ': <b>' + U.qty(it.stock) + '</b>', submit: t('save'),
      fields: [{ name: 'date', label: t('date'), type: 'date', value: K.today() }, { name: 'newStock', label: t('new_stock'), type: kind === 'product' ? 'qty' : 'qtyd' }, { name: 'note', label: t('reason'), type: 'textarea', optional: true }],
      calc: function (v) { var r = K.parseQty(v.newStock, kind !== 'product'); if (!r.ok) return ''; var diff = K.round3(r.q - it.stock); return t('difference') + ': <b>' + (diff > 0 ? '+' : '') + '<bdi class="num">' + K.fmtQty(diff) + '</bdi></b>'; },
      onSubmit: function (v) { var ns = U.parseQ(v.newStock, kind !== 'product', true); U.commit(function (d) { K.adjustStock(d, { date: v.date, kind: kind, itemId: id, newStock: ns, note: v.note }); }); done(); }
    });
  };

  /* ---------- workers, machines, weekly roster ---------- */
  F.worker = function (id) {
    var w = id ? K.byId(U.D.workers, id) : null;
    U.openForm({
      title: t(w ? 'edit' : 'new_worker'), submit: t('save'),
      fields: [{ name: 'name', label: t('name'), type: 'text', value: w ? w.name : '' }, { name: 'phone', label: t('phone'), type: 'text', optional: true, value: w ? w.phone : '' },
        { name: 'hireDate', label: t('hire_date'), type: 'date', optional: true, value: w ? (w.hireDate || '') : '' }].concat(w ? [{ name: 'active', label: t('worker_active'), type: 'check', value: w.active }] : []),
      onDelete: w ? function () { F.remove('worker', id, w.name); } : null,
      onSubmit: function (v) { U.commit(function (d) { if (w) K.updateWorker(d, id, { name: v.name, phone: v.phone, hireDate: v.hireDate, active: v.active }); else K.addWorker(d, v); }); done(); }
    });
  };
  F.machine = function (id) {
    var m = id ? K.byId(U.D.machines, id) : null;
    U.openForm({ title: t(m ? 'edit' : 'new_machine'), submit: t('save'), fields: [{ name: 'name', label: t('name'), type: 'text', value: m ? m.name : '' }],
      onDelete: m ? function () { F.remove('machine', id, m.name); } : null,
      onSubmit: function (v) { U.commit(function (d) { if (m) K.updateMachine(d, id, v); else K.addMachine(d, v); }); done(); } });
  };
  // One cell of the weekly grid: for each worker choose "worked" / "did not work" (+ machine). Shift times are fixed.
  F.roster = function (date, shift) {
    var D = U.D, sh = K.SHIFTS[shift - 1], cur = K.rosterFor(D, date, shift);
    var workers = U.act(D.workers).filter(function (w) { return w.active || cur.some(function (a) { return a.workerId === w.id; }); });
    if (!workers.length) { U.closeModal(); U.toast(t('add_workers_first'), 'bad'); return; }
    var h = '<form id="f" novalidate><h3>' + t('shift') + ' ' + shift + '</h3><div class="muted">' + U.dayName(date) + ' ' + K.fmtDate(date) + ' · <bdi class="num" dir="ltr">' + sh.start + ' - ' + sh.end + '</bdi> · 8 ' + t('hours') + '</div>';
    workers.forEach(function (w) {
      var a = cur.filter(function (x) { return x.workerId === w.id; })[0], st = a ? (a.worked ? 'w' : 'n') : '-';
      h += '<div class="card" style="box-shadow:none;border:1px solid var(--line);margin-top:10px"><div style="font-weight:800">' + esc(w.name) + '</div>' +
        '<select name="st_' + w.id + '"><option value="-"' + (st === '-' ? ' selected' : '') + '>' + t('not_listed') + '</option><option value="w"' + (st === 'w' ? ' selected' : '') + '>' + t('worked') + '</option><option value="n"' + (st === 'n' ? ' selected' : '') + '>' + t('did_not_work') + '</option></select>' +
        (U.act(D.machines).length ? '<select name="mc_' + w.id + '" style="margin-top:6px"><option value="">' + t('no_machine') + '</option>' + U.act(D.machines, a ? a.machineId : '').map(function (m) { return '<option value="' + m.id + '"' + (a && a.machineId === m.id ? ' selected' : '') + '>' + esc(m.name) + '</option>'; }).join('') + '</select>' : '') + '</div>';
    });
    h += '<div id="ferr" class="ferr"></div><div class="btns"><button type="button" class="btn ghost" data-act="close">' + t('cancel') + '</button><button type="submit" class="btn primary">' + t('save') + '</button></div></form>';
    U.showModal(h);
    U.$('#f').addEventListener('submit', function (e) {
      e.preventDefault(); var f = U.$('#f'), entries = [];
      workers.forEach(function (w) { var s = f.elements['st_' + w.id].value; if (s === '-') return; entries.push({ workerId: w.id, worked: s === 'w', machineId: f.elements['mc_' + w.id] ? (f.elements['mc_' + w.id].value || null) : null }); });
      try { U.commit(function (d) { K.setShiftRoster(d, { date: date, shift: shift, entries: entries }); }); done(); } catch (err) { U.$('#ferr').textContent = U.errMsg(err); }
    });
  };

  /* ---------- settings ---------- */
  F.company = function () {
    var s = U.D.settings;
    U.openForm({
      title: t('company_info'), submit: t('save'),
      fields: [{ name: 'address', label: t('address'), type: 'text', value: s.address }, { name: 'phone', label: t('phone'), type: 'text', value: s.phone }, { name: 'email', label: t('email'), type: 'text', value: s.email }],
      onSubmit: function (v) { U.commit(function (d) { d.settings.address = v.address.trim(); d.settings.phone = v.phone.trim(); d.settings.email = v.email.trim(); }); done(); }
    });
  };
  F.category = function (id) {
    var c = id ? K.byId(U.D.expenseCats, id) : null;
    U.openForm({ title: t(c ? 'edit' : 'new_category'), submit: t('save'), fields: [{ name: 'name', label: t('name'), type: 'text', value: c ? U.catName(id) : '' }],
      onDelete: c ? function () { F.remove('expenseCat', id, U.catName(id)); } : null,
      onSubmit: function (v) { U.commit(function (d) { if (c) K.updateExpenseCat(d, id, v); else K.addExpenseCat(d, v); }); done(); } });
  };
  F.note = function (id) {
    var n = id ? K.byId(U.D.notes, id) : null;
    U.openForm({ title: t(n ? 'edit_note' : 'new_note'), submit: t('save'),
      fields: [{ name: 'date', label: t('date'), type: 'date', value: n ? n.date : K.today() }, { name: 'title', label: t('note_title'), type: 'text', optional: true, value: n ? n.title : '' }, { name: 'text', label: t('note_text'), type: 'textarea', value: n ? n.text : '' }],
      onDelete: n ? function () { F.remove('note', id, n.title || n.date, function () { U.render(true); }); } : null,
      onSubmit: function (v) { U.commit(function (d) { if (n) K.updateNote(d, id, v); else K.addNote(d, v); }); done(); } });
  };

  /* ---------- void (what the "delete" button does) ---------- */
  F.void = function (kind, id) {
    var fn = { sale: K.voidSale, payment: K.voidPayment, spayment: K.voidSupplierPayment, purchase: K.voidPurchase, expense: K.voidExpense, production: K.voidProduction }[kind];
    U.openForm({
      title: t('delete_tx'), intro: '<div class="alert red">' + esc(t('delete_note')) + '</div>', submit: t('delete_confirm'), danger: true,
      fields: [{ name: 'reason', label: t('reason'), type: 'textarea', optional: true }],
      onSubmit: function (v) { U.commit(function (d) { fn(d, id, v.reason); }); U.closeModal(); U.toast(t('deleted_ok'), 'ok'); U.back(); }
    });
  };
})();
