from pathlib import Path
import re, subprocess, sys
root = Path(__file__).resolve().parents[1]
html = root / 'app/src/main/assets/www/index.html'
s = html.read_text(encoding='utf-8')
checks = {
    'existing local storage key preserved': 'kp_mobile_db' in s,
    'actual consumption fields': 'granuleKgActual' in s and 'broyeKgActual' in s,
    'actual consumption mode stored': "consumptionMode='actual_weight'" in s,
    'persistent notes data model': 'notes:[]' in s and 'function renderNotes()' in s,
    'editable stock thresholds': 'saveStockThresholds' in s and 'thresholdGranule' in s,
    'daily/monthly reporting preserved': 'renderMonthlyFinanceReport' in s and 'renderAnalytics' in s,
    'official master logo included': (root / 'app/src/main/assets/www/khaldi-plast-logo.png').exists(),
    'production section retained': '<section id="production"' in s,
    'sales section retained': '<section id="sales"' in s,
    'inventory section retained': '<section id="inventory"' in s,
}
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + label)
script = '\n'.join(re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>', s, re.S | re.I))
tmp = Path('/tmp/kp-inline-check.js'); tmp.write_text(script, encoding='utf-8')
r = subprocess.run(['node', '--check', str(tmp)], capture_output=True, text=True)
print(('PASS' if r.returncode == 0 else 'FAIL') + ': JavaScript syntax check')
if r.returncode: print(r.stderr)
sys.exit(0 if all(checks.values()) and r.returncode == 0 else 1)
