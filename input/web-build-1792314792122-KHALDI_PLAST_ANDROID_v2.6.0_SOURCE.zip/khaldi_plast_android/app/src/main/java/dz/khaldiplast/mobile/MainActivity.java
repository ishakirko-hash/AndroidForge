package dz.khaldiplast.mobile;

import android.app.Activity;
import android.content.Context;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.URLDecoder;

public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT = 7101;
    private static final int REQUEST_SAVE_BACKUP = 7102;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupContent = "";
    private String pendingBackupName = "Khaldi-Plast-Backup.json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF0B1A2E);
        getWindow().setNavigationBarColor(0xFF0B1A2E);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF3F6FA);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setDefaultTextEncodingName("UTF-8");
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetResponse(request.getUrl().getPath());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                try { return assetResponse(Uri.parse(url).getPath()); }
                catch (Exception e) { return super.shouldInterceptRequest(view, url); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (ActivityNotFoundException ignored) {}
                    return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain", "*/*"});
                try { startActivityForResult(intent, REQUEST_IMPORT); }
                catch (ActivityNotFoundException e) { filePathCallback = null; Toast.makeText(MainActivity.this, "تعذر فتح مدير الملفات", Toast.LENGTH_LONG).show(); return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl(APP_URL);
    }

    private WebResourceResponse assetResponse(String path) {
        if (path == null || !path.startsWith("/assets/www/")) return null;
        String name = path.substring("/assets/www/".length());
        if (name.isEmpty()) name = "index.html";
        String mime = "application/octet-stream";
        if (name.endsWith(".html")) mime = "text/html";
        else if (name.endsWith(".js")) mime = "application/javascript";
        else if (name.endsWith(".css")) mime = "text/css";
        else if (name.endsWith(".png")) mime = "image/png";
        else if (name.endsWith(".json")) mime = "application/json";
        try {
            InputStream stream = getAssets().open("www/" + name);
            return new WebResourceResponse(mime, "UTF-8", stream);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                    new ByteArrayInputStream("Not found".getBytes(StandardCharsets.UTF_8)));
        }
    }

    private class NativeBridge {
        @JavascriptInterface public void shareText(String title, String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "KHALDI PLAST" : title);
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(send, "مشاركة الفاتورة"));
            });
        }

        @JavascriptInterface public void printHtml(String html, String jobName) {
            runOnUiThread(() -> {
                WebView printView = new WebView(MainActivity.this);
                WebSettings ps = printView.getSettings();
                ps.setJavaScriptEnabled(true);
                ps.setDefaultTextEncodingName("UTF-8");
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (manager == null) {
                            Toast.makeText(MainActivity.this, "خدمة الطباعة غير متاحة", Toast.LENGTH_LONG).show();
                            return;
                        }
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter("KHALDI-PLAST-" + (jobName == null ? "Document" : jobName));
                        PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("kp_pdf", "KHALDI PLAST PDF", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        manager.print("KHALDI-PLAST-" + (jobName == null ? "Document" : jobName), adapter, attributes);
                    }
                });
                printView.loadDataWithBaseURL("https://appassets.androidplatform.net/", html == null ? "" : html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface public void saveBackup(String content, String filename) {
            pendingBackupContent = content == null ? "{}" : content;
            pendingBackupName = filename == null || filename.trim().isEmpty() ? "Khaldi-Plast-Backup.json" : filename;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
                try { startActivityForResult(intent, REQUEST_SAVE_BACKUP); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "تعذر فتح مدير الملفات لحفظ النسخة", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT) {
            if (filePathCallback != null) {
                Uri[] results = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_SAVE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out == null) throw new IOException("No output stream");
                out.write(pendingBackupContent.getBytes(StandardCharsets.UTF_8));
                out.flush();
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية بنجاح", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); }
        super.onDestroy();
    }
}
