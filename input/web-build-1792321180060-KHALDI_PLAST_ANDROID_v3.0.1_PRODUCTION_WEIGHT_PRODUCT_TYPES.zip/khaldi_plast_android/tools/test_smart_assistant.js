const assert = require('node:assert/strict');
require('../app/src/main/assets/www/assistant-engine.js');
const engine = global.KPSmartEngine;
function check(name, input, expectedValue) {
  const out = engine.parse(input);
  assert.equal(out.handled, true, `${name}: should be handled`);
  assert.ok(out.result, `${name}: should return a result`);
  assert.ok(out.result.value.includes(expectedValue), `${name}: got ${out.result.value}, expected to include ${expectedValue}`);
  console.log('PASS:', name, '=>', out.result.value);
}
check('two materials total', 'عندي 120 كغ Granulé بسعر 250 دج للكيلوغرام و50 كغ Broyé بسعر 180 دج للكيلوغرام، احسب الإجمالي', '39');
check('discount percent first', 'خصم 10% من 5000 دج', '4');
check('discount percent last', '5000 دج خصم 10%', '4');
check('percentage of amount', 'احسب 15% من 20000 دج', '3');
check('increase percent', 'زيادة 5% على 1000 دج', '1');
check('grams to kg', 'حوّل 2500 غرام إلى كغ', '2,5');
check('ton to kg', 'حوّل 2 طن إلى كغ', '2');
check('arithmetic', 'احسب 125 × 4', '500');
assert.equal(engine.parse('كم عندي من Granulé؟').handled, false, 'factory insight should fall back to existing DB reader');
console.log('PASS: existing factory insight falls back');
