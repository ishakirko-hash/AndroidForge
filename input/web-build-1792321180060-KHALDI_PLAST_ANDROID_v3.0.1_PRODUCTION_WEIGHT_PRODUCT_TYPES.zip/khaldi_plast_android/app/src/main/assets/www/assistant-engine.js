/* KHALDI PLAST Smart Assistant Engine v2.9.0
 * Deterministic offline parsing only. No network access and no database writes.
 */
(function(root){
 'use strict';
 const digits=s=>String(s??'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
 const norm=s=>digits(s).replace(/[٬،]/g,'').replace(/[٫٬]/g,'.').replace(/\u066b/g,'.').replace(/[−–]/g,'-').normalize('NFD').replace(/[\u0300-\u036f\u064b-\u065f\u0670]/g,'').toLowerCase().replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/\s+/g,' ').trim();
 const nums=s=>(norm(s).match(/-?\d+(?:\.\d+)?/g)||[]).map(Number).filter(Number.isFinite);
 const fmt=(n,max=2)=>Number(n).toLocaleString('fr-DZ',{maximumFractionDigits:max});
 const result=(title,value,details)=>({handled:true,result:{title,value,details}});
 const toast=message=>({handled:true,message});
 const materialRx=/(granule|granulé|حبيبات|granules|broy[eé]|بروي|برويي|مطحون|معاد طحن)/i;
 const hasQtyUnit=s=>/(كغ|كيلوغرام|كيلوجرام|kg|غرام|جرام|طن|tonne|tons?)(?:\b|\s)/i.test(s);
 const priceCue=s=>/(سعر|بسعر|ثمن|تكلفه|تكلفة|دج|دينار|للكيلو|للكيلوغرام|للطُن|للطون|da\b|dzd)/i.test(s);
 function tryMultiMaterial(raw){
   const t=norm(raw); if(!materialRx.test(t)||!/(اجمالي|الإجمالي|المجموع|احسب|تكلفه|تكلفة|سعر)/.test(t)) return null;
   const parts=t.split(/\s+و\s*(?=\d|granule|broy|حبيبات|بروي)|[,؛;]+/).map(x=>x.trim()).filter(Boolean);
   const rows=[];
   for(const p of parts){
     const m=p.match(materialRx); if(!m)continue;
     const n=nums(p); if(n.length<2||!hasQtyUnit(p)||!priceCue(p))continue;
     let q=n[0], price=n[n.length-1];
     const qEnd=p.indexOf(String(n[0]))+String(n[0]).length; const qAfter=p.slice(qEnd);
     if(/^\s*(?:طن|tonne|tons?)\b/.test(qAfter))q*=1000; else if(/^\s*(?:غرام|جرام|gram)\b/.test(qAfter))q/=1000;
     let pricePerKg=price;
     if(/سعر الطن|للطُن|للطون|دج\s*\/\s*طن|da\s*\/\s*ton/i.test(p))pricePerKg=price/1000;
     const material=/broy|بروي|مطحون|معاد طحن/.test(p)?'Broyé':'Granulé';
     rows.push({material,qtyKg:q,priceKg:pricePerKg,total:q*pricePerKg});
   }
   // If multiple named materials were given but the wording is ambiguous, ask instead of guessing.
   const mentions=(t.match(/granule|granulé|حبيبات|broy[eé]|بروي|مطحون|معاد طحن/g)||[]).length;
   if(rows.length<2||mentions<2)return null;
   const total=rows.reduce((a,x)=>a+x.total,0),weight=rows.reduce((a,x)=>a+x.qtyKg,0),avg=weight?total/weight:0;
   const details=rows.map(x=>`${x.material}: ${fmt(x.qtyKg,3)} كغ × ${fmt(x.priceKg,2)} دج/كغ = ${fmt(x.total,2)} دج`).join('؛ ')+`. الوزن الإجمالي: ${fmt(weight,3)} كغ. متوسط التكلفة المرجح: ${fmt(avg,2)} دج/كغ. لم يتم تسجيل شراء أو تعديل المخزون.`;
   return result('إجمالي تكلفة المواد',fmt(total,2)+' دج',details);
 }
 function tryPercent(raw){
   const t=norm(raw);if(!/(%|بالمئه|في المئه|نسبه)/.test(t))return null;
   const pm=t.match(/(-?\d+(?:\.\d+)?)\s*(?:%|بالمئه|في المئه)/);if(!pm)return null;
   const pct=Number(pm[1]),rest=t.slice(0,pm.index)+t.slice(pm.index+pm[0].length),remaining=nums(rest);if(!remaining.length)return null;const base=remaining[0];
   if(pct<0||pct>10000||base<0)return toast('تحقق من النسبة والمبلغ؛ يجب ألا تكون القيم سالبة.');
   const amount=base*pct/100;
   if(/خصم|تنزيل|تخفيض/.test(t)){const final=base-amount;return result('حساب الخصم',fmt(final,2)+' دج',`المبلغ الأصلي: ${fmt(base,2)} دج. نسبة الخصم: ${fmt(pct,3)}%. قيمة الخصم: ${fmt(amount,2)} دج. المبلغ بعد الخصم: ${fmt(final,2)} دج.`)}
   if(/زياده|اضافه|رفع/.test(t)){return result('المبلغ بعد الزيادة',fmt(base+amount,2)+' دج',`المبلغ الأصلي: ${fmt(base,2)} دج. الزيادة ${fmt(pct,3)}% = ${fmt(amount,2)} دج. الإجمالي: ${fmt(base+amount,2)} دج.`)}
   return result('حساب النسبة المئوية',fmt(amount,2)+' دج',`${fmt(pct,3)}% من ${fmt(base,2)} دج = ${fmt(amount,2)} دج.`);
 }
 function tryUnitConversion(raw){
   const t=norm(raw);if(!/(حول|تحويل|كم كغ|كم كيلو|كم غرام|كم جرام)/.test(t))return null;
   const n=nums(raw);if(!n.length)return null;const q=n[0];if(q<0)return toast('أدخل كمية غير سالبة للتحويل.');
   const isTon=/(طن|tonne|tons?)/.test(t),isGram=/(غرام|جرام|\bغ\b|\bgram\b)/.test(t),isKg=/(كغ|كيلوغرام|كيلوجرام|\bkg\b|كيلو)/.test(t);
   if(isTon){const kg=q*1000;return result('تحويل الوزن',fmt(kg,4)+' كغ',`${fmt(q,4)} طن = ${fmt(kg,4)} كغ = ${fmt(kg*1000,2)} غرام.`)}
   if(isGram&&(/كغ|كيلوغرام|كيلوجرام|\bkg\b|كيلو/.test(t))){return result('تحويل الوزن',fmt(q/1000,5)+' كغ',`${fmt(q,4)} غرام ÷ 1000 = ${fmt(q/1000,5)} كغ.`)}
   if(isKg&&isGram){return result('تحويل الوزن',fmt(q*1000,3)+' غرام',`${fmt(q,4)} كغ × 1000 = ${fmt(q*1000,3)} غرام.`)}
   return null;
 }
 function tryArithmetic(raw){
   const t=digits(raw).replace(/,/g,'.');
   const m=t.match(/(-?\d+(?:\.\d+)?)\s*([+×÷*\/])\s*(-?\d+(?:\.\d+)?)/);
   if(!m)return null;const a=Number(m[1]),op=m[2],b=Number(m[3]);if(!Number.isFinite(a)||!Number.isFinite(b))return null;
   if((op==='÷'||op==='/')&&b===0)return toast('لا يمكن القسمة على صفر.');
   const v=op==='+'?a+b:(op==='×'||op==='*')?a*b:(op==='÷'||op==='/')?a/b:a-b;
   if(!Number.isFinite(v))return toast('تعذر حساب العملية بهذه القيم.');
   return result('نتيجة العملية الحسابية',fmt(v,6),`${fmt(a,6)} ${op} ${fmt(b,6)} = ${fmt(v,6)}.`);
 }
 function parse(raw){
   if(!String(raw||'').trim())return {handled:false};
   return tryMultiMaterial(raw)||tryPercent(raw)||tryUnitConversion(raw)||tryArithmetic(raw)||{handled:false};
 }
 root.KPSmartEngine={parse,normalize:norm,version:'2.9.0'};
})(typeof window!=='undefined'?window:globalThis);
