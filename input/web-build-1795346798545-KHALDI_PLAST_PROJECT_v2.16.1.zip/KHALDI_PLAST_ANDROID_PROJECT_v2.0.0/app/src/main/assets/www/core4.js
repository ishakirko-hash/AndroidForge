/* KHALDI PLAST - v2.16 business logic (pure functions, same rules as core*.js: integer centimes, nothing invented, everything derived).
 *   1. shiftReport(d, date, shift)  - operations report of a shift (shift 0 = whole day): production, defects, material use,
 *      machines (counted output vs target, stops), crew, sales / cash / expenses / trips of the day, comparison and rule-based findings.
 *   2. costing(d, from, to, opts)   - full cost of one good crate = materials (scrap included) + labour + overheads, price, profit, margin,
 *      break-even and suggested price, change versus the previous period. Labour and overheads are shared by weight (kg) or by count.
 * Machine counters / stops live in d.settings.mon, trips in d.settings.dist (no schema change). */
(function (root) {
  'use strict';
  var K = (typeof module !== 'undefined' && module.exports) ? require('./core3.js') : root.KP;
  var byId = K.byId, sum = K.sum, live = K.live;
  function r1(x) { return Math.round(x * 10) / 10; }
  function pct(a, b) { return b > 0 ? r1(a * 100 / b) : null; }
  function mon(d) { var m = (d.settings && d.settings.mon) || {}; return { cfg: m.cfg || {}, stops: m.stops || [], counts: m.counts || {} }; }
  function shiftWin(date, n) {
    var sh = K.SHIFTS[n - 1], p = String(date).split('-'), s = new Date(+p[0], +p[1] - 1, +p[2], parseInt(sh.start, 10), 0, 0, 0).getTime();
    return { s: s, e: s + sh.hours * 3600000, sh: sh };
  }

  /* ---------- 1. shift / day report ---------- */
  function production(d, date, shift) {
    var recs = live(d.production).filter(function (r) { return r.date === date && (!shift || r.shift === shift); }), by = {}, good = 0, bad = 0, kg = 0, cost = 0, costed = 0, unknown = 0, defCost = 0;
    recs.forEach(function (r) {
      var c = K.productionCost(d, r), x = by[r.productId] || (by[r.productId] = { productId: r.productId, good: 0, defective: 0, kg: 0, cost: 0, costKnown: true, records: 0 });
      x.good += r.good; x.defective += r.defective; x.records++; good += r.good; bad += r.defective;
      var k = sum(r.consumption || [], function (l) { return l.qty; }); x.kg += k; kg += k;
      if (c.complete) { x.cost += c.total; cost += c.total; costed += r.good + r.defective; defCost += c.defectCost; } else { x.costKnown = false; unknown++; }
    });
    var rows = Object.keys(by).map(function (k) { var x = by[k]; x.defPct = pct(x.defective, x.good + x.defective); x.perGood = x.costKnown && x.good > 0 ? Math.round(x.cost / x.good) : null; x.kg = Math.round(x.kg * 1000) / 1000; return x; }).sort(function (a, b) { return b.good - a.good; });
    return { rows: rows, good: good, defective: bad, defPct: pct(bad, good + bad), kg: Math.round(kg * 1000) / 1000, cost: cost, costComplete: unknown === 0 && recs.length > 0, defectCost: defCost, records: recs.length, unassigned: shift ? 0 : recs.filter(function (r) { return !r.shift; }).length };
  }
  function machines(d, date, shift, now) {
    var M = mon(d), ms = d.machines.filter(function (m) { return !m.archived; }), shifts = shift ? [shift] : [1, 2, 3];
    return ms.map(function (m) {
      var cf = M.cfg[m.id] || {}, cyc = cf.cycle > 0 ? cf.cycle : 0, out = 0, exp = 0, expKnown = !!cyc, jm = 0, um = 0, crew = {}, reasons = {}, worked = 0;
      shifts.forEach(function (n) {
        var c = M.counts[m.id + '|' + date + '|' + n]; if (c) out += c.n;
        var w = shiftWin(date, n), upto = Math.min(Math.max(now, w.s), w.e), el = (upto - w.s) / 1000, j = 0;
        M.stops.forEach(function (x) {
          if (x.m !== m.id) return; var a = Math.max(x.from, w.s), b = Math.min(x.to == null ? now : x.to, upto); if (b <= a) return;
          var sec = (b - a) / 1000; if (x.kind === 'j') { j += sec; jm += sec; } else { um += sec; } var rs = x.reason || ''; if (rs) reasons[rs] = (reasons[rs] || 0) + sec;
        });
        if (cyc && el > 0) exp += Math.max(0, Math.floor((el - j) / cyc));
        K.rosterFor(d, date, n).forEach(function (a) { if (a.machineId === m.id) { crew[a.workerId] = (crew[a.workerId] || 0) + (a.worked ? 1 : 0); if (a.worked) worked++; } });
      });
      var names = Object.keys(crew).filter(function (k) { return crew[k] > 0; }).map(function (k) { var w = byId(d.workers, k); return w ? w.name : '?'; });
      return { machine: m, out: out, expected: expKnown ? exp : null, eff: expKnown && exp > 0 ? r1(out * 100 / exp) : null, justMin: Math.round(jm / 60), unjMin: Math.round(um / 60), reasons: Object.keys(reasons).sort(function (a, b) { return reasons[b] - reasons[a]; }).slice(0, 3),
        crew: names, crewCount: names.length, perWorker: names.length ? Math.round(out / names.length) : null };
    });
  }
  function crewSummary(d, date, shift) {
    var shifts = shift ? [shift] : [1, 2, 3], present = {}, absent = {}, noMachine = {}, any = false;
    shifts.forEach(function (n) { K.rosterFor(d, date, n).forEach(function (a) { any = true; if (a.worked) { present[a.workerId] = 1; if (!a.machineId) noMachine[a.workerId] = 1; } else absent[a.workerId] = 1; }); });
    Object.keys(present).forEach(function (k) { delete absent[k]; });
    function nm(o) { return Object.keys(o).map(function (k) { var w = byId(d.workers, k); return w ? w.name : '?'; }); }
    return { any: any, present: Object.keys(present).length, absent: nm(absent), noMachine: nm(noMachine), earned: sum(Object.keys(present), function (k) { var w = byId(d.workers, k); return w ? (w.rate || 0) * shifts.filter(function (n) { return K.rosterFor(d, date, n).some(function (a) { return a.workerId === k && a.worked; }); }).length : 0; }) };
  }
  function dayMoney(d, date) {
    var sales = live(d.sales).filter(function (s) { return s.date === date; }), total = sum(sales, function (s) { return s.total; }), crates = sum(sales, function (s) { return sum(s.items, function (i) { return i.qty; }); });
    var pays = live(d.payments).filter(function (p) { return p.date === date; }), exps = live(d.expenses).filter(function (e) { return e.date === date; });
    var paidOnSale = sum(sales, function (s) { return s.paid || 0; });
    return { salesCount: sales.length, sales: total, crates: crates, collected: sum(pays, function (p) { return p.amount; }), expenses: sum(exps, function (e) { return e.amount; }), expenseCount: exps.length, unpaidShare: total > 0 ? pct(Math.max(0, total - paidOnSale), total) : null,
      list: sales.map(function (s) { var c = byId(d.customers, s.customerId); return { no: s.no, customer: c ? c.name : '', total: s.total, paid: s.paid || 0, id: s.id }; }) };
  }
  function trips(d, date) {
    var t = ((d.settings.dist || {}).trips || []).filter(function (x) { return x.date === date; });
    return { total: t.length, done: t.filter(function (x) { return x.status === 'done'; }).length, late: t.filter(function (x) { return x.status === 'late'; }).length, go: t.filter(function (x) { return x.status === 'go'; }).length, km: sum(t, function (x) { return x.km || 0; }) };
  }
  function shiftReport(d, date, shift, nowMs) {
    shift = shift || 0; var now = nowMs || Date.now(), isDay = !shift, prod = production(d, date, shift), prev = production(d, K.addDays(date, -1), shift), mc = machines(d, date, shift, now), crew = crewSummary(d, date, shift);
    var hist = [1, 2, 3, 4, 5, 6, 7].map(function (i) { return production(d, K.addDays(date, -i), shift); }).filter(function (p) { return p.records > 0; });
    var avgGood = hist.length ? Math.round(sum(hist, function (p) { return p.good; }) / hist.length) : null, hg = sum(hist, function (p) { return p.good; }), hb = sum(hist, function (p) { return p.defective; }), avgDef = hist.length ? pct(hb, hg + hb) : null;
    var money = isDay ? dayMoney(d, date) : null, tr = isDay ? trips(d, date) : null, ins = [], today = K.today(), past = date < today, hasPlan = crew.any;
    // ---- findings (rule based, every threshold is shown in the footnote) ----
    if (prod.records && prod.defPct != null && prod.defPct >= 3 && (avgDef == null || prod.defPct > Math.max(3, avgDef * 1.25))) ins.push({ k: 'warn', c: 'defect_high', v: { p: prod.defPct, a: avgDef, cost: prod.costComplete ? prod.defectCost : null } });
    if (prod.records && prod.defPct != null && avgDef != null && prod.defPct <= avgDef * 0.8 && prod.defPct < 3) ins.push({ k: 'ok', c: 'defect_low', v: { p: prod.defPct, a: avgDef } });
    mc.forEach(function (m) {
      if (m.eff != null && m.expected >= 20 && m.eff < 85) ins.push({ k: 'warn', c: 'mach_low', v: { name: m.machine.name, eff: m.eff, out: m.out, exp: m.expected } });
      if (m.eff != null && m.expected >= 20 && m.eff >= 105) ins.push({ k: 'ok', c: 'mach_high', v: { name: m.machine.name, eff: m.eff } });
      if (m.unjMin >= 20) ins.push({ k: 'warn', c: 'stop_unj', v: { name: m.machine.name, min: m.unjMin, why: m.reasons } });
      if (hasPlan && !m.crewCount && (past || !isDay)) ins.push({ k: 'warn', c: 'no_crew', v: { name: m.machine.name } });
    });
    if (crew.noMachine.length) ins.push({ k: 'info', c: 'no_machine', v: { names: crew.noMachine } });
    if (crew.absent.length) ins.push({ k: 'info', c: 'absent', v: { names: crew.absent } });
    if (prod.records && prev.records && prev.good > 0) { var ch = r1((prod.good - prev.good) * 100 / prev.good); if (ch >= 10) ins.push({ k: 'ok', c: 'up', v: { p: ch } }); else if (ch <= -15) ins.push({ k: 'warn', c: 'down', v: { p: ch } }); }
    if (!prod.records && past && isDay && hist.length) ins.push({ k: 'warn', c: 'no_prod', v: {} });
    if (prod.records && !prod.costComplete) ins.push({ k: 'info', c: 'cost_unknown', v: {} });
    if (money && money.unpaidShare != null && money.unpaidShare >= 50 && money.sales > 0) ins.push({ k: 'warn', c: 'credit', v: { p: money.unpaidShare } });
    var best = prod.rows[0], bm = mc.filter(function (m) { return m.out > 0; }).sort(function (a, b) { return b.out - a.out; })[0];
    if (best && prod.rows.length > 1) ins.push({ k: 'info', c: 'best_prod', v: { id: best.productId, good: best.good } });
    if (bm && mc.length > 1) ins.push({ k: 'info', c: 'best_mach', v: { name: bm.machine.name, out: bm.out } });
    return { date: date, shift: shift, production: prod, prev: prev, avgGood: avgGood, avgDef: avgDef, machines: mc, crew: crew, money: money, trips: tr, insights: ins,
      empty: !prod.records && !(money && money.salesCount) && !crew.any && !mc.some(function (m) { return m.out > 0; }) };
  }

  /* ---------- 2. full crate cost ---------- */
  function period(d, from, to, alloc) {
    var recs = live(d.production).filter(function (r) { return r.date >= from && r.date <= to; }), by = {};
    recs.forEach(function (r) {
      var x = by[r.productId] || (by[r.productId] = { good: 0, bad: 0, kg: 0, mat: 0, matOk: true, noCons: false, scrap: 0, records: 0 }), c = K.productionCost(d, r, to);
      x.good += r.good; x.bad += r.defective; x.records++; x.kg += sum(r.consumption || [], function (l) { return l.qty; });
      if (c.noConsumption) { x.noCons = true; x.matOk = false; } else if (!c.complete) x.matOk = false; else { x.mat += c.total; x.scrap += c.defectCost; }
    });
    var workers = d.workers.reduce(function (s, w) { return s + K.workerLedger(d, w.id, from, to).earned; }, 0);
    var cats = K.expensesByCategory(d, from, to).filter(function (c) { var cat = byId(d.expenseCats, c.categoryId); return !(cat && cat.key === 'salaries'); });
    var overhead = sum(cats, function (c) { return c.amount; });
    var weight = 0, count = 0; Object.keys(by).forEach(function (k) { var x = by[k], p = byId(d.products, k); x.w = x.kg > 0 ? x.kg : (p && p.weightG ? (x.good + x.bad) * p.weightG / 1000 : 0); weight += x.w; count += x.good; });
    return { by: by, labor: workers, overhead: overhead, cats: cats, weight: weight, count: count };
  }
  function sold(d, from, to) {
    var by = {};
    live(d.sales).filter(function (s) { return s.date >= from && s.date <= to; }).forEach(function (s) {
      var f = s.subtotal > 0 ? s.total / s.subtotal : 1;
      s.items.forEach(function (i) { var x = by[i.productId] || (by[i.productId] = { qty: 0, rev: 0 }); x.qty += i.qty; x.rev += i.qty * i.unitPrice * f; });
    });
    return by;
  }
  function recipeCost(d, p, asOf) {
    var ks = Object.keys(p.recipe || {}); if (!ks.length) return null; var t = 0;
    for (var i = 0; i < ks.length; i++) { var a = K.avgMaterialCost(d, ks[i], asOf); if (a === null) return null; t += a * p.recipe[ks[i]] / 1000; }
    return t;
  }
  function costing(d, from, to, opts) {
    opts = opts || {}; var alloc = opts.alloc === 'count' ? 'count' : 'weight', P = period(d, from, to, alloc), S = sold(d, from, to);
    var len = Math.round((Date.UTC(+to.slice(0, 4), +to.slice(5, 7) - 1, +to.slice(8, 10)) - Date.UTC(+from.slice(0, 4), +from.slice(5, 7) - 1, +from.slice(8, 10))) / 86400000) + 1;
    var pTo = K.addDays(from, -1), pFrom = K.addDays(from, -len), PP = period(d, pFrom, pTo, alloc);
    var ids = {}; Object.keys(P.by).forEach(function (k) { ids[k] = 1; }); Object.keys(S).forEach(function (k) { ids[k] = 1; });
    var rows = Object.keys(ids).map(function (pid) {
      var p = byId(d.products, pid); if (!p) return null; var x = P.by[pid], s = S[pid], warn = [], matPerGood = null, theo = null, defRate = null, labor = null, over = null;
      if (x && x.good > 0 && x.matOk) { matPerGood = x.mat / x.good; theo = x.mat / (x.good + x.bad); defRate = x.bad / (x.good + x.bad); }
      var basis = matPerGood != null ? 'production' : null;
      if (matPerGood == null) { var rc = recipeCost(d, p, to); if (rc != null) { matPerGood = rc; theo = rc; defRate = 0; basis = 'recipe'; } else warn.push(x && x.noCons ? 'no_grams' : 'no_cost'); }
      if (x && x.good > 0) {
        var share = alloc === 'weight' ? (P.weight > 0 ? x.w / P.weight : null) : (P.count > 0 ? x.good / P.count : null);
        if (share != null) { labor = P.labor * share / x.good; over = P.overhead * share / x.good; }
      } else if (basis) warn.push('no_production');
      var price = s && s.qty > 0 ? s.rev / s.qty : (p.price || null), priceBasis = s && s.qty > 0 ? 'sold' : (p.price ? 'list' : null); if (price == null) warn.push('no_price');
      var full = matPerGood != null && labor != null ? matPerGood + labor + over : null, profit = full != null && price != null ? price - full : null;
      var prevX = PP.by[pid], prevMat = prevX && prevX.good > 0 && prevX.matOk ? prevX.mat / prevX.good : null;
      return { productId: pid, product: p, good: x ? x.good : 0, defective: x ? x.bad : 0, defRate: defRate == null ? null : r1(defRate * 100), sold: s ? s.qty : 0, price: price == null ? null : Math.round(price), priceBasis: priceBasis, listPrice: p.price || null,
        mat: matPerGood == null ? null : Math.round(matPerGood), theo: theo == null ? null : Math.round(theo), scrap: x && x.good > 0 && x.matOk ? Math.round(x.scrap / x.good) : null, matBasis: basis, labor: labor == null ? null : Math.round(labor), overhead: over == null ? null : Math.round(over),
        full: full == null ? null : Math.round(full), profit: profit == null ? null : Math.round(profit), margin: profit != null && price > 0 ? r1(profit * 100 / price) : null, contribution: price != null && matPerGood != null ? Math.round(price - matPerGood) : null,
        total: profit != null && s ? Math.round(profit * s.qty) : null, breakEven: full == null ? null : Math.round(full), suggest: function (m) { return full == null || m >= 100 ? null : Math.round(full / (1 - m / 100)); },
        prevMat: prevMat == null ? null : Math.round(prevMat), matChange: prevMat != null && matPerGood != null && prevMat > 0 ? r1((matPerGood - prevMat) * 100 / prevMat) : null, warn: warn };
    }).filter(Boolean).sort(function (a, b) { return (b.total == null ? -Infinity : b.total) - (a.total == null ? -Infinity : a.total); });
    var known = rows.filter(function (r) { return r.profit != null && r.sold > 0; }), rev = sum(known, function (r) { return r.price * r.sold; }), prof = sum(known, function (r) { return r.profit * r.sold; });
    var cats = P.cats.map(function (c) { var cat = byId(d.expenseCats, c.categoryId); return { categoryId: c.categoryId, name: cat ? cat.name : '?', key: cat ? cat.key : '', amount: c.amount }; });
    return { from: from, to: to, days: len, alloc: alloc, rows: rows, labor: P.labor, overhead: P.overhead, overheadCats: cats, producedKg: Math.round(P.weight * 10) / 10, producedCrates: P.count, revenue: Math.round(rev), profit: Math.round(prof), margin: rev > 0 ? r1(prof * 100 / rev) : null, unknown: rows.length - known.length,
      avgCost: known.length && sum(known, function (r) { return r.sold; }) > 0 ? Math.round(sum(known, function (r) { return r.full * r.sold; }) / sum(known, function (r) { return r.sold; })) : null };
  }

  var API = { shiftReport: shiftReport, costing: costing, shiftWindow: shiftWin };
  Object.keys(API).forEach(function (k) { K[k] = API[k]; });
  if (typeof module !== 'undefined' && module.exports) module.exports = K;
})(typeof window !== 'undefined' ? window : this);
