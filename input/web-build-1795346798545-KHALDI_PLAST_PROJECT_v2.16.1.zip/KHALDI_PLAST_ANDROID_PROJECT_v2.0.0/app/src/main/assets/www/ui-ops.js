/* KHALDI PLAST - v2.16: "Shift & production report" (W.shiftreport) and "Crate cost & margin" (W.costing).
   Pure UI over K.shiftReport / K.costing (core4.js). Nothing is estimated that the records do not support. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, X = U.extraActions, S = U.S;
  function T(ar, fr, en) { var l = U.lang(); return l === 'fr' ? fr : l === 'en' ? en : ar; }
  function B(v) { return '<bdi class="num" dir="ltr">' + v + '</bdi>'; }
  function today() { return K.today(); }
  function plain(c) { return K.fmtMoney(c) + ' ' + t('dzd'); }
  function pn(ic, title, body, extra) { return '<div class="card op-pn"><div class="op-ph"><span class="op-pi">' + V.icon(ic, 18) + '</span><b>' + title + '</b>' + (extra || '') + '</div>' + body + '</div>'; }
  function printNow(name) { setTimeout(function () { if (U.AND && U.AND.printPage) U.AND.printPage(name); else window.print(); }, 150); }
  function share(txt) {
    if (U.AND && U.AND.shareText) U.AND.shareText(txt);
    else if (navigator.share) navigator.share({ text: txt }).catch(function () { });
    else if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { U.toast(t('copied'), 'ok'); });
  }
  function pname(id) { var p = K.byId(U.D.products, id); return p ? p.name : '?'; }
  function delta(cur, prev, inv) {
    if (cur == null || prev == null || prev === 0) return '';
    var p = Math.round((cur - prev) * 1000 / Math.abs(prev)) / 10, good = inv ? p <= 0 : p >= 0;
    return '<span class="op-d ' + (good ? 'up' : 'dn') + '">' + (p >= 0 ? '▲' : '▼') + ' ' + B(Math.abs(p) + '%') + '</span>';
  }
  function kpi(col, ic, label, val, sub) { return '<div class="op-k ' + col + '"><span class="op-ki">' + V.icon(ic, 20) + '</span><small>' + label + '</small><b>' + val + '</b>' + (sub ? '<em>' + sub + '</em>' : '') + '</div>'; }
  function curShift() { var h = new Date().getHours(); return h >= 8 && h < 16 ? 1 : h >= 16 ? 2 : 3; }
  function shiftLbl(n) { return n ? t('shift') + ' ' + n + ' · ' + K.SHIFTS[n - 1].start + '–' + K.SHIFTS[n - 1].end : T('اليوم كامل', 'Journée complète', 'Full day'); }

  /* =================================================================
     1. SHIFT / DAY REPORT
     ================================================================= */
  S.srDate = S.srDate || ''; S.srShift = S.srShift == null ? 0 : S.srShift;
  function insText(i) {
    var v = i.v || {};
    switch (i.c) {
      case 'defect_high': return T('نسبة العيوب ' + v.p + '%' + (v.a != null ? ' أعلى من متوسط آخر 7 أيام (' + v.a + '%)' : '') + (v.cost ? ' — مواد مهدورة بقيمة ' + plain(v.cost) : '') + '. راجع الحرارة ومواد الخلط.', 'Taux de défauts ' + v.p + '%' + (v.a != null ? ' > moyenne 7 j (' + v.a + '%)' : '') + (v.cost ? ' — matière perdue ' + plain(v.cost) : ''), 'Defect rate ' + v.p + '%' + (v.a != null ? ' above 7-day average (' + v.a + '%)' : '') + (v.cost ? ' — material wasted ' + plain(v.cost) : ''));
      case 'defect_low': return T('نسبة العيوب ' + v.p + '% أفضل من متوسط 7 أيام (' + v.a + '%) 👏', 'Défauts ' + v.p + '% meilleur que la moyenne (' + v.a + '%)', 'Defects ' + v.p + '% better than average (' + v.a + '%)');
      case 'mach_low': return T(v.name + ': أنجزت ' + K.groupInt(v.out) + ' من أصل ' + K.groupInt(v.exp) + ' متوقعة (' + v.eff + '%).', v.name + ' : ' + K.groupInt(v.out) + ' sur ' + K.groupInt(v.exp) + ' attendus (' + v.eff + '%)', v.name + ': ' + K.groupInt(v.out) + ' of ' + K.groupInt(v.exp) + ' expected (' + v.eff + '%)');
      case 'mach_high': return T(v.name + ' تجاوزت المتوقع (' + v.eff + '%) 👏', v.name + ' au-dessus de l\'objectif (' + v.eff + '%)', v.name + ' above target (' + v.eff + '%)');
      case 'stop_unj': return T(v.name + ': توقف غير مبرَّر ' + v.min + ' دقيقة' + (v.why && v.why.length ? ' (' + v.why.join('، ') + ')' : ''), v.name + ' : arrêt non justifié ' + v.min + ' min', v.name + ': unjustified stop ' + v.min + ' min' + (v.why && v.why.length ? ' (' + v.why.join(', ') + ')' : ''));
      case 'no_crew': return T(v.name + ' بلا عمال معيّنين في هذه الفترة.', v.name + ' sans équipe affectée', v.name + ' had no crew assigned');
      case 'no_machine': return T('حضروا بلا آلة: ' + v.names.join('، '), 'Sans machine : ' + v.names.join(', '), 'Present without machine: ' + v.names.join(', '));
      case 'absent': return T('غائبون: ' + v.names.join('، '), 'Absents : ' + v.names.join(', '), 'Absent: ' + v.names.join(', '));
      case 'up': return T('الإنتاج أعلى من الفترة السابقة بـ ' + v.p + '% 📈', 'Production +' + v.p + '% vs période précédente', 'Output up ' + v.p + '% vs previous period');
      case 'down': return T('الإنتاج أقل من الفترة السابقة بـ ' + Math.abs(v.p) + '%.', 'Production ' + v.p + '% vs période précédente', 'Output down ' + Math.abs(v.p) + '% vs previous period');
      case 'no_prod': return T('لم يُسجَّل أي إنتاج في هذا اليوم رغم وجود إنتاج في الأيام السابقة.', 'Aucune production enregistrée ce jour', 'No production recorded this day');
      case 'cost_unknown': return T('تكلفة بعض المواد غير معروفة (لا توجد مشتريات أو لم تُسجَّل غرامات)، لذلك لا تظهر التكلفة كاملة.', 'Coût incomplet : prix de matière ou grammes manquants', 'Cost incomplete: missing material price or grams');
      case 'credit': return T(v.p + '% من مبيعات اليوم لم تُدفع — انتبه لحدود الدين.', v.p + '% des ventes non payées', v.p + '% of today\'s sales unpaid');
      case 'best_prod': return T('الأكثر إنتاجاً: ' + pname(v.id) + ' (' + K.groupInt(v.good) + ' صندوق)', 'Plus produit : ' + pname(v.id), 'Top product: ' + pname(v.id) + ' (' + K.groupInt(v.good) + ')');
      case 'best_mach': return T('أفضل آلة: ' + v.name + ' (' + K.groupInt(v.out) + ' صندوق)', 'Meilleure machine : ' + v.name, 'Top machine: ' + v.name + ' (' + K.groupInt(v.out) + ')');
    }
    return '';
  }
  var ICO = { warn: '⚠️', ok: '✅', info: 'ℹ️' };

  W.shiftreport = function () {
    var D = U.D, date = S.srDate || today(), n = S.srShift || 0, r = K.shiftReport(D, date, n), isToday = date === today(), p = r.production, h = '';
    // controls (not printed)
    h += '<div class="noprint"><div class="op-nav"><button class="op-nb" data-act="sr_day" data-id="-1" aria-label="prev">' + V.icon('chevR', 18) + '</button><input type="date" id="srDate" value="' + esc(date) + '" max="' + today() + '"><button class="op-nb" data-act="sr_day" data-id="1" aria-label="next"' + (isToday ? ' disabled' : '') + '>' + V.icon('chevL', 18) + '</button>' + (isToday ? '' : '<button class="op-nb tx" data-act="sr_day" data-id="0">' + t('p_today') + '</button>') + '</div>' +
      '<div class="op-seg">' + [0, 1, 2, 3].map(function (i) { return '<button class="' + (i === n ? 'on' : '') + '" data-act="sr_shift" data-id="' + i + '">' + (i ? t('shift') + ' ' + i : T('اليوم', 'Jour', 'Day')) + (isToday && i && i === curShift() ? ' <i></i>' : '') + '</button>'; }).join('') + '</div></div>';
    if (r.empty) return h + '<div class="card">' + U.empty(T('لا توجد بيانات لهذا ' + (n ? 'الشفت' : 'اليوم') + ' بعد.', 'Aucune donnée', 'No data for this period yet.'), 'note') + '</div>';
    h += '<div class="rpt dr"><div class="rpt-h"><img src="img/logo_full.png" alt="KHALDI PLAST"><div class="rpt-t"><b>' + esc(T('تقرير الإنتاج', 'Rapport de production', 'Production report')) + '</b><span>' + B(K.fmtDate(date)) + ' · ' + esc(shiftLbl(n)) + '</span></div></div>' +
      '<div class="rpt-co">' + esc(U.dayName(date)) + ' · ' + esc(T('أُنشئ', 'Généré', 'Generated')) + ' ' + B(new Date().toTimeString().slice(0, 5)) + '</div>';
    // headline numbers
    var pg = r.prev.good ? delta(p.good, r.prev.good) : '', ad = r.avgDef != null && p.defPct != null ? (function () { var x = Math.round((p.defPct - r.avgDef) * 10) / 10; return x === 0 ? '' : '<span class="op-d ' + (x <= 0 ? 'up' : 'dn') + '">' + (x > 0 ? '▲ +' : '▼ ') + B(x) + ' ' + T('نقطة', 'pt', 'pts') + '</span>'; })() : '';
    h += '<div class="op-kg">' + kpi('blue', 'box', T('الإنتاج السليم', 'Bons produits', 'Good crates'), B(K.groupInt(p.good)), pg) + kpi(p.defPct != null && p.defPct >= 3 ? 'red' : 'green', 'alert', T('نسبة العيوب', 'Défauts', 'Defect rate'), p.defPct == null ? '—' : B(p.defPct + '%'), (p.defective ? B(K.groupInt(p.defective)) + ' ' + T('مرفوض', 'rebuts', 'rejected') : '') + ' ' + ad) +
      kpi('amber', 'scale', T('المواد المستهلكة', 'Matière', 'Material used'), B(K.fmtQty(p.kg)) + ' <small>' + t('kg') + '</small>', p.costComplete ? plain(p.cost) : '') + kpi('violet', 'users', T('العمال الحاضرون', 'Présents', 'Workers present'), r.crew.any ? B(r.crew.present) : '—', r.crew.absent.length ? B(r.crew.absent.length) + ' ' + T('غائب', 'absents', 'absent') : '') + '</div>';
    // findings
    if (r.insights.length) {
      h += '<div class="rpt-blk"><h4>' + esc(T('ملاحظات ذكية', 'Observations', 'Smart findings')) + '</h4><div class="op-ins">' + r.insights.map(function (i) { return '<div class="op-i ' + i.k + '"><span>' + ICO[i.k] + '</span><p>' + esc(insText(i)) + '</p></div>'; }).join('') + '</div></div>';
    }
    // production by product
    if (p.rows.length) {
      var mx = Math.max.apply(null, p.rows.map(function (x) { return x.good + x.defective; })) || 1;
      h += '<div class="rpt-blk"><h4>' + esc(T('الإنتاج حسب المنتج', 'Par produit', 'By product')) + '</h4>' + p.rows.map(function (x) {
        var pr = K.byId(D.products, x.productId), tot = x.good + x.defective;
        return '<div class="op-pr"><div class="op-prh"><b>' + esc(pname(x.productId)) + '</b><span>' + B(K.groupInt(x.good)) + ' <small>' + t('crate_u') + '</small></span></div><div class="op-bar"><i class="g" style="width:' + Math.round(x.good * 100 / mx) + '%"></i><i class="r" style="width:' + Math.round(x.defective * 100 / mx) + '%"></i></div>' +
          '<div class="op-prf"><span>' + (x.defective ? '<b class="rd">' + B(K.groupInt(x.defective)) + '</b> ' + T('مرفوض', 'rebuts', 'rejected') + ' (' + B(x.defPct + '%') + ')' : T('بلا عيوب', 'sans défaut', 'no defects')) + '</span><span>' + B(K.fmtQty(x.kg)) + ' ' + t('kg') + (x.perGood != null ? ' · ' + plain(x.perGood) + '/' + T('صندوق', 'caisse', 'crate') : '') + '</span></div></div>';
      }).join('') + '</div>';
    }
    // machines
    if (r.machines.length && (r.machines.some(function (m) { return m.out || m.crewCount || m.unjMin || m.justMin; }) || true)) {
      h += '<div class="rpt-blk"><h4>' + esc(T('الآلات', 'Machines', 'Machines')) + '</h4>' + r.machines.map(function (m) {
        var eff = m.eff, bar = m.expected ? Math.min(100, Math.round(m.out * 100 / m.expected)) : (m.out ? 100 : 0), cls = eff == null ? 'n' : eff >= 95 ? 'g' : eff >= 85 ? 'a' : 'r';
        return '<div class="op-m"><div class="op-mh"><b>' + esc(m.machine.name) + '</b>' + (eff != null ? '<span class="op-pill ' + cls + '">' + B(eff + '%') + '</span>' : '') + '</div>' +
          '<div class="op-bar"><i class="' + (cls === 'n' ? 'b' : cls) + '" style="width:' + bar + '%"></i></div><div class="op-prf"><span>' + T('الفعلي', 'Réel', 'Actual') + ' <b>' + B(K.groupInt(m.out)) + '</b>' + (m.expected != null ? ' / ' + T('المتوقع', 'attendu', 'target') + ' ' + B(K.groupInt(m.expected)) : '') + '</span><span>' + (m.perWorker != null ? B(K.groupInt(m.perWorker)) + '/' + T('عامل', 'ouv.', 'wkr') : '') + '</span></div>' +
          '<div class="op-prf"><span>' + (m.crew.length ? '👷 ' + esc(m.crew.join('، ')) : '<em class="mu">' + T('بلا عمال', 'sans équipe', 'no crew') + '</em>') + '</span><span>' + (m.unjMin || m.justMin ? (m.unjMin ? '<b class="rd">' + B(m.unjMin) + '</b> ' + T('د غير مبرر', 'min non just.', 'min unjustified') : '') + (m.justMin ? ' ' + B(m.justMin) + ' ' + T('د مبرر', 'min just.', 'min justified') : '') : '<em class="mu">' + T('بلا توقفات', 'aucun arrêt', 'no stops') + '</em>') + '</span></div></div>';
      }).join('') + '</div>';
    }
    // day-only blocks
    if (r.money) {
      var mo = r.money, tr = r.trips;
      h += '<div class="rpt-blk"><h4>' + esc(T('المبيعات والنقد', 'Ventes & caisse', 'Sales & cash')) + '</h4><div class="rpt-kv"><span>' + t('p_invoices') + '</span><b>' + B(mo.salesCount) + ' · ' + B(K.groupInt(mo.crates)) + ' ' + t('crate_u') + '</b></div><div class="rpt-kv"><span>' + t('p_sales') + '</span><b>' + U.money(mo.sales) + '</b></div><div class="rpt-kv"><span>' + t('p_collected') + '</span><b>' + U.money(mo.collected) + '</b></div><div class="rpt-kv"><span>' + t('expenses') + ' (' + mo.expenseCount + ')</span><b>' + U.money(mo.expenses) + '</b></div>' +
        mo.list.slice(0, 6).map(function (s) { return '<div class="rpt-kv sm"><span>' + esc(U.invNo ? U.invNo(s.no) : s.no) + ' · ' + esc(s.customer || t('walkin')) + '</span><b>' + U.money(s.total) + '</b></div>'; }).join('') + '</div>';
      if (tr.total) h += '<div class="rpt-blk"><h4>' + esc(T('التوزيع', 'Distribution', 'Distribution')) + '</h4><div class="rpt-kv"><span>' + T('الرحلات', 'Trajets', 'Trips') + '</span><b>' + B(tr.total) + ' · ' + B(tr.done) + ' ' + T('منجزة', 'livrés', 'done') + (tr.late ? ' · ' + B(tr.late) + ' ' + T('متأخرة', 'retard', 'late') : '') + '</b></div><div class="rpt-kv"><span>km</span><b>' + B(K.groupInt(tr.km)) + '</b></div></div>';
    }
    if (r.crew.any) h += '<div class="rpt-blk"><h4>' + esc(T('العمال', 'Ouvriers', 'Workers')) + '</h4><div class="rpt-kv"><span>' + T('الحاضرون', 'Présents', 'Present') + '</span><b>' + B(r.crew.present) + '</b></div>' + (r.crew.earned ? '<div class="rpt-kv"><span>' + T('أجور الفترة', 'Salaires', 'Wages of the period') + '</span><b>' + U.money(r.crew.earned) + '</b></div>' : '') + '</div>';
    h += '<div class="rpt-note">' + esc(T('الأحكام الذكية: العيوب ≥ 3% وأعلى من متوسط 7 أيام بـ 25%، كفاءة الآلة < 85% (مع هدف ≥ 20 صندوقاً)، توقف غير مبرر ≥ 20 دقيقة، مبيعات غير مدفوعة ≥ 50%. الإنتاج الفعلي للآلة هو العدّاد الذي تدخله يدوياً، والتكلفة تحسب من أسعار الشراء الفعلية.', 'Seuils : défauts ≥ 3 % et 25 % au-dessus de la moyenne, efficacité machine < 85 %, arrêt non justifié ≥ 20 min, ventes impayées ≥ 50 %.', 'Thresholds: defects ≥ 3% and 25% above the 7-day average, machine efficiency < 85%, unjustified stop ≥ 20 min, unpaid sales ≥ 50%. Machine output is the counter you enter; cost uses real purchase prices.')) + '</div></div>';
    h += '<div class="btns noprint"><button class="btn primary" data-act="sr_print">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button><button class="btn" data-act="sr_share">' + V.icon('share', 18) + ' ' + T('مشاركة (واتساب)', 'Partager', 'Share') + '</button><button class="btn" data-act="sr_csv">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button></div>';
    return h;
  };
  X.sr_day = function (el) { var id = Number(el.dataset.id), cur = S.srDate || today(); S.srDate = id === 0 ? today() : K.addDays(cur, id); if (S.srDate > today()) S.srDate = today(); U.render(true); };
  X.sr_shift = function (el) { S.srShift = Number(el.dataset.id) || 0; U.render(true); };
  X.sr_print = function () { printNow('KHALDI_PLAST_REPORT_' + (S.srDate || today()) + (S.srShift ? '_S' + S.srShift : '')); };
  X.sr_share = function () {
    var date = S.srDate || today(), n = S.srShift || 0, r = K.shiftReport(U.D, date, n), p = r.production, L = [];
    L.push('*KHALDI PLAST* — ' + T('تقرير الإنتاج', 'Rapport de production', 'Production report')); L.push(K.fmtDate(date) + ' · ' + shiftLbl(n)); L.push('');
    L.push('📦 ' + T('الإنتاج السليم', 'Bons', 'Good') + ': ' + K.groupInt(p.good) + ' ' + t('crate_u')); L.push('❌ ' + T('العيوب', 'Défauts', 'Defects') + ': ' + K.groupInt(p.defective) + (p.defPct != null ? ' (' + p.defPct + '%)' : ''));
    if (p.kg) L.push('⚖️ ' + T('المواد', 'Matière', 'Material') + ': ' + K.fmtQty(p.kg) + ' ' + t('kg') + (p.costComplete ? ' — ' + plain(p.cost) : ''));
    p.rows.forEach(function (x) { L.push('• ' + pname(x.productId) + ': ' + K.groupInt(x.good) + (x.defective ? ' (' + x.defective + ' ✗)' : '')); });
    var ms = r.machines.filter(function (m) { return m.out || m.crewCount; }); if (ms.length) { L.push(''); ms.forEach(function (m) { L.push('🏭 ' + m.machine.name + ': ' + K.groupInt(m.out) + (m.expected ? '/' + K.groupInt(m.expected) + ' (' + m.eff + '%)' : '') + (m.crew.length ? ' — ' + m.crew.join('، ') : '')); }); }
    if (r.crew.any) L.push('👷 ' + T('الحاضرون', 'Présents', 'Present') + ': ' + r.crew.present + (r.crew.absent.length ? ' — ' + T('غائبون', 'absents', 'absent') + ': ' + r.crew.absent.join('، ') : ''));
    if (r.money && r.money.salesCount) { L.push(''); L.push('💰 ' + T('المبيعات', 'Ventes', 'Sales') + ': ' + plain(r.money.sales) + ' (' + r.money.salesCount + ')'); L.push('💵 ' + T('المحصَّل', 'Encaissé', 'Collected') + ': ' + plain(r.money.collected)); }
    var w = r.insights.filter(function (i) { return i.k === 'warn'; }); if (w.length) { L.push(''); L.push('⚠️ ' + T('ملاحظات', 'À noter', 'Notes') + ':'); w.slice(0, 5).forEach(function (i) { L.push('- ' + insText(i)); }); }
    share(L.join('\n'));
  };
  X.sr_csv = function () {
    var date = S.srDate || today(), n = S.srShift || 0, r = K.shiftReport(U.D, date, n), rows = [[T('المنتج', 'Produit', 'Product'), T('سليم', 'Bons', 'Good'), T('مرفوض', 'Rebuts', 'Rejected'), '%', 'kg', T('تكلفة المواد', 'Coût', 'Material cost')]];
    r.production.rows.forEach(function (x) { rows.push([pname(x.productId), x.good, x.defective, x.defPct == null ? '' : x.defPct, x.kg, x.costKnown ? K.fmtMoney(x.cost) : '']); });
    rows.push([]); rows.push([T('الآلة', 'Machine', 'Machine'), T('الفعلي', 'Réel', 'Actual'), T('المتوقع', 'Attendu', 'Target'), '%', T('توقف غير مبرر د', 'Arrêt non just.', 'Unjust. min'), T('العمال', 'Ouvriers', 'Crew')]);
    r.machines.forEach(function (m) { rows.push([m.machine.name, m.out, m.expected == null ? '' : m.expected, m.eff == null ? '' : m.eff, m.unjMin, m.crew.join(' / ')]); });
    U.saveFile('khaldi_report_' + date + (n ? '_s' + n : '') + '.csv', 'text/csv', '﻿' + rows.map(function (x) { return x.map(U.csvEscape).join(','); }).join('\r\n'));
  };
  document.addEventListener('change', function (e) { if (e.target && e.target.id === 'srDate') { var v = e.target.value; if (v && v <= today()) { S.srDate = v; U.render(true); } } });

  /* =================================================================
     2. CRATE COST & MARGIN
     ================================================================= */
  S.csDays = S.csDays || 30; S.csAlloc = S.csAlloc || 'weight'; S.csTarget = S.csTarget || 25;
  function csRange() {
    var td = today();
    if (S.csDays === 'm') { var r = K.monthRange(td.slice(0, 7)); return { from: r.from, to: td }; }
    return { from: K.addDays(td, -(S.csDays - 1)), to: td };
  }
  var C_MAT = '#1E6FE8', C_LAB = '#7B4FD0', C_OVH = '#F59E2C';
  /* stacked bar: the whole bar = selling price; materials | labour | overheads | profit. In a loss the bar is the full cost and a red tail marks the loss. */
  function costBar(r) {
    var loss = r.profit < 0, sc = loss ? r.full : r.price || 1;
    function seg(v, col, cls, lbl) { var w = Math.max(0, v * 100 / sc); return w < 0.4 ? '' : '<i class="' + (cls || '') + '" style="width:' + w + '%' + (col ? ';background:' + col : '') + '">' + (w >= 13 ? '<b>' + Math.round(v * 100 / r.price) + '%</b>' : '') + '</i>'; }
    var h = '<div class="cs-stk' + (loss ? ' loss' : '') + '">' + seg(r.mat, C_MAT) + seg(r.labor, C_LAB) + seg(r.overhead, C_OVH) + (loss ? seg(-r.profit, '', 'lo') : seg(r.profit, '', 'pf')) + (loss ? '<u style="inset-inline-start:calc(' + (r.price * 100 / sc) + '% - 1.5px)"></u>' : '') + '</div>';
    var P = r.price || 1;
    h += '<div class="cs-cap">' + esc(T('من كل 100 دج من سعر البيع:', 'Sur 100 DA de prix :', 'Of every 100 DZD of price:')) + ' <span style="color:' + C_MAT + '">' + T('مواد', 'matière', 'materials') + ' ' + B(Math.round(r.mat * 100 / P)) + '</span> · <span style="color:' + C_LAB + '">' + T('عمالة', 'main-d\'œuvre', 'labour') + ' ' + B(Math.round(r.labor * 100 / P)) + '</span> · <span style="color:' + C_OVH + '">' + T('مصاريف', 'frais', 'overheads') + ' ' + B(Math.round(r.overhead * 100 / P)) + '</span> · <span class="' + (loss ? 'rd' : 'gn') + '">' + (loss ? T('خسارة', 'perte', 'loss') : T('ربح', 'profit', 'profit')) + ' ' + B(Math.round(r.profit * 100 / P)) + '</span></div>';
    return h;
  }
  function pill(m) { return m == null ? '<span class="cs-pill n">—</span>' : '<span class="cs-pill ' + (m >= 20 ? 'g' : m >= 8 ? 'a' : 'r') + '">' + B(m + '%') + '</span>'; }
  function warnTxt(w) {
    return { no_cost: T('لا توجد مشتريات لبعض المواد — سعرها غير معروف', 'Prix de matière inconnu', 'Material price unknown'), no_grams: T('إنتاج بلا غرامات للمواد — لا يمكن حساب التكلفة', 'Grammes manquants', 'Production without grams'), no_production: T('لا إنتاج في الفترة — التكلفة من الوصفة فقط', 'Aucune production', 'No production in period (recipe only)'), no_price: T('لا سعر بيع', 'Pas de prix', 'No selling price') }[w] || w;
  }
  W.costing = function () {
    var D = U.D, rg = csRange(), c = K.costing(D, rg.from, rg.to, { alloc: S.csAlloc }), h = '';
    h += '<div class="noprint"><div class="op-seg">' + [[30, T('30 يوم', '30 j', '30 d')], [90, T('90 يوم', '90 j', '90 d')], ['m', T('هذا الشهر', 'Ce mois', 'This month')]].map(function (x) { return '<button class="' + (S.csDays === x[0] ? 'on' : '') + '" data-act="cs_days" data-id="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<div class="op-seg sm"><button class="' + (S.csAlloc === 'weight' ? 'on' : '') + '" data-act="cs_alloc" data-id="weight">' + T('توزيع حسب الوزن', 'Par poids', 'Share by weight') + '</button><button class="' + (S.csAlloc === 'count' ? 'on' : '') + '" data-act="cs_alloc" data-id="count">' + T('حسب العدد', 'Par nombre', 'Share by count') + '</button></div></div>';
    if (!c.rows.length) return h + '<div class="card">' + U.empty(T('لا إنتاج ولا مبيعات في هذه الفترة لحساب التكلفة.', 'Aucune production ni vente sur la période.', 'No production or sales in this period.'), 'bars') + '</div>';
    h += '<div class="rpt dr"><div class="rpt-h"><img src="img/logo_full.png" alt="KHALDI PLAST"><div class="rpt-t"><b>' + esc(T('تكلفة الصندوق وهامش الربح', 'Coût de la caisse et marge', 'Crate cost & margin')) + '</b><span>' + B(K.fmtDate(rg.from)) + ' → ' + B(K.fmtDate(rg.to)) + '</span></div></div>';
    h += '<div class="op-kg">' + kpi('blue', 'box', T('متوسط تكلفة الصندوق', 'Coût moyen', 'Avg crate cost'), c.avgCost == null ? '—' : U.money(c.avgCost), '') + kpi(c.margin == null ? 'gray' : c.margin >= 15 ? 'green' : c.margin >= 5 ? 'amber' : 'red', 'check', T('هامش الربح', 'Marge', 'Margin'), c.margin == null ? '—' : B(c.margin + '%'), '') +
      kpi('green', 'wallet', T('ربح الفترة (تقدير)', 'Bénéfice estimé', 'Est. profit'), c.revenue ? U.money(c.profit) : '—', c.revenue ? T('من مبيعات ', 'sur ', 'of ') + plain(c.revenue) : '') + kpi('violet', 'users', T('عمالة + مصاريف', 'Main-d\'œuvre + frais', 'Labour + overheads'), U.money(c.labor + c.overhead), B(K.groupInt(Math.round(c.producedKg))) + ' ' + t('kg') + ' · ' + B(K.groupInt(c.producedCrates)) + ' ' + t('crate_u')) + '</div>';
    if (c.unknown) h += '<div class="alert amber">' + esc(T(c.unknown + ' منتج بلا حساب كامل (بيانات ناقصة) — انظر الملاحظات في بطاقاته.', c.unknown + ' produit(s) incomplet(s)', c.unknown + ' product(s) without a full cost (missing data)')) + '</div>';
    // cost-structure legend + pools
    h += '<div class="op-leg"><span><i style="background:' + C_MAT + '"></i>' + T('مواد خام', 'Matières', 'Materials') + '</span><span><i style="background:' + C_LAB + '"></i>' + T('عمالة', 'Main-d\'œuvre', 'Labour') + '</span><span><i style="background:' + C_OVH + '"></i>' + T('مصاريف عامة', 'Frais généraux', 'Overheads') + '</span><span><i style="background:#2DB35A"></i>' + T('الربح', 'Marge', 'Profit') + '</span></div>';
    // product cards
    var mxT = Math.max.apply(null, c.rows.map(function (r) { return Math.abs(r.total || 0); }).concat([1]));
    c.rows.forEach(function (r) {
      var pr = r.product, tgt = S.csTarget, sug = r.suggest(tgt);
      h += '<div class="card cs-c"><div class="cs-h"><div class="thumb">' + V.crate(pr.color, 40) + '</div><div class="cs-n"><b>' + esc(pr.name) + '</b><small>' + (r.sold ? B(K.groupInt(r.sold)) + ' ' + T('مبيع', 'vendus', 'sold') : '') + (r.good ? ' · ' + B(K.groupInt(r.good)) + ' ' + T('منتَج', 'produits', 'made') : '') + '</small></div>' + pill(r.margin) + '</div>';
      if (r.full != null && r.price != null) {
        h += costBar(r) + '<div class="cs-g"><div><small>' + T('سعر البيع', 'Prix de vente', 'Selling price') + (r.priceBasis === 'list' ? ' *' : '') + '</small><b>' + U.money(r.price) + '</b></div><div><small>' + T('التكلفة الكاملة', 'Coût complet', 'Full cost') + '</small><b>' + U.money(r.full) + '</b></div><div><small>' + T('ربح الصندوق', 'Profit/caisse', 'Profit/crate') + '</small><b class="' + (r.profit < 0 ? 'rd' : 'gn') + '">' + U.money(r.profit) + '</b></div></div>' +
          '<div class="cs-d"><div><i style="background:' + C_MAT + '"></i><span>' + T('مواد', 'Matière', 'Material') + '</span><b>' + plain(r.mat) + '</b>' + (r.matChange != null ? '<em class="' + (r.matChange > 0 ? 'rd' : 'gn') + '">' + (r.matChange > 0 ? '▲' : '▼') + B(Math.abs(r.matChange) + '%') + '</em>' : '') + '</div><div><i style="background:' + C_LAB + '"></i><span>' + T('عمالة', 'Main-d\'œuvre', 'Labour') + '</span><b>' + plain(r.labor) + '</b></div><div><i style="background:' + C_OVH + '"></i><span>' + T('مصاريف', 'Frais', 'Overheads') + '</span><b>' + plain(r.overhead) + '</b></div></div>' +
          '<div class="cs-x"><span>' + T('سعر التعادل', 'Seuil de rentabilité', 'Break-even') + ' <b>' + plain(r.breakEven) + '</b></span><span>' + T('لهامش ' + tgt + '% بِع بـ', 'Pour ' + tgt + ' % vendre à', 'For ' + tgt + '% sell at') + ' <b>' + (sug ? plain(sug) : '—') + '</b></span></div>' +
          (r.scrap ? '<div class="cs-s">♻️ ' + esc(T('تكلفة العيوب داخل سعر المواد: ' + plain(r.scrap) + ' لكل صندوق سليم (نسبة العيوب ' + r.defRate + '%)', 'Coût des rebuts : ' + plain(r.scrap) + '/caisse (' + r.defRate + ' %)', 'Scrap cost inside material: ' + plain(r.scrap) + ' per good crate (' + r.defRate + '% defects)')) + '</div>' : '') +
          (r.total != null ? '<div class="cs-t"><span>' + T('إسهامه في ربح الفترة', 'Contribution', 'Contribution to period profit') + '</span><div class="op-bar"><i class="' + (r.total < 0 ? 'r' : 'g') + '" style="width:' + Math.max(3, Math.round(Math.abs(r.total) * 100 / mxT)) + '%"></i></div><b class="' + (r.total < 0 ? 'rd' : 'gn') + '">' + plain(r.total) + '</b></div>' : '') +
          '<button class="btn sm cs-sim noprint" data-act="cs_sim" data-id="' + r.productId + '">🧪 ' + T('جرّب سيناريو (ماذا لو؟)', 'Simuler', 'What-if simulator') + '</button>';
      } else if (r.mat != null) {
        h += '<div class="cs-g"><div><small>' + T('تكلفة المواد', 'Matière', 'Material') + '</small><b>' + U.money(r.mat) + '</b></div><div><small>' + T('سعر البيع', 'Prix', 'Price') + '</small><b>' + (r.price ? U.money(r.price) : '—') + '</b></div></div>';
      }
      if (r.warn.length) h += '<div class="cs-w">' + r.warn.map(function (w) { return '<span>⚠️ ' + esc(warnTxt(w)) + '</span>'; }).join('') + '</div>';
      if (r.matBasis === 'recipe') h += '<div class="cs-w"><span>ℹ️ ' + esc(T('تكلفة المواد من وصفة المنتج (لا إنتاج فعلي في الفترة).', 'Coût selon la recette', 'Material cost from the recipe')) + '</span></div>';
      h += '</div>';
    });
    // overheads
    if (c.overheadCats.length) {
      var mo = c.overheadCats[0].amount || 1;
      h += pn('wallet', esc(T('المصاريف العامة المحمَّلة', 'Frais généraux répartis', 'Overheads allocated')), '<div class="hb">' + c.overheadCats.slice(0, 6).map(function (x) { return '<div class="hb-r"><div class="hb-h"><i style="background:' + C_OVH + '"></i><b>' + esc(x.name) + '</b><span class="hb-p">' + B(Math.round(x.amount * 1000 / c.overhead) / 10 + '%') + '</span></div><div class="hb-t"><u style="width:' + Math.max(3, Math.round(x.amount * 100 / mo)) + '%;background:' + C_OVH + '"></u></div><div class="hb-f"><span>' + B(K.fmtMoney(x.amount)) + ' ' + t('dzd') + '</span></div></div>'; }).join('') + '</div>', '<span class="badge amber">' + plain(c.overhead) + '</span>');
    }
    h += '<div class="rpt-note">' + esc(T('طريقة الحساب: تكلفة المواد = ما استُهلك فعلاً (بما فيه الصناديق المعيبة) بمتوسط سعر الشراء ÷ الصناديق السليمة. العمالة = أجور الشفتات الحاضرة (عدد الشفتات × أجر الشفت). المصاريف = كل مصاريف الفترة ما عدا الرواتب (حتى لا تُحسب مرتين). تُوزَّع العمالة والمصاريف على المنتجات ' + (S.csAlloc === 'weight' ? 'حسب وزن المادة المستهلكة' : 'حسب عدد الصناديق') + '. * = سعر القائمة لعدم وجود مبيعات في الفترة. النتيجة تقدير إداري وليست حساباً محاسبياً.', 'Matière = consommation réelle (rebuts inclus) au prix moyen d\'achat ÷ bons. Main-d\'œuvre = postes travaillés × tarif. Frais = dépenses hors salaires. Estimation de gestion.', 'Material = actual consumption (scrap included) at average purchase price ÷ good crates. Labour = worked shifts × shift rate. Overheads = expenses excluding salaries (no double counting). Management estimate, not accounting.')) + '</div></div>';
    h += '<div class="op-tg noprint"><span>' + T('الهامش المستهدف', 'Marge cible', 'Target margin') + '</span><input type="range" id="csTarget" min="5" max="60" step="1" value="' + S.csTarget + '"><b id="csTv">' + S.csTarget + '%</b></div>';
    h += '<div class="btns noprint"><button class="btn primary" data-act="cs_print">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button><button class="btn" data-act="cs_share">' + V.icon('share', 18) + ' ' + T('مشاركة', 'Partager', 'Share') + '</button><button class="btn" data-act="cs_csv">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button></div>';
    return h;
  };
  X.cs_days = function (el) { S.csDays = el.dataset.id === 'm' ? 'm' : Number(el.dataset.id); U.render(true); };
  X.cs_alloc = function (el) { S.csAlloc = el.dataset.id; U.render(true); };
  X.cs_print = function () { printNow('KHALDI_PLAST_COST_' + today()); };
  X.cs_share = function () {
    var rg = csRange(), c = K.costing(U.D, rg.from, rg.to, { alloc: S.csAlloc }), L = ['*KHALDI PLAST* — ' + T('تكلفة الصندوق وهامش الربح', 'Coût de la caisse', 'Crate cost & margin'), K.fmtDate(rg.from) + ' → ' + K.fmtDate(rg.to), ''];
    c.rows.forEach(function (r) { if (r.full == null || r.price == null) { L.push('• ' + r.product.name + ': ' + T('بيانات ناقصة', 'incomplet', 'incomplete')); return; } L.push('• ' + r.product.name + ': ' + T('تكلفة ', 'coût ', 'cost ') + plain(r.full) + ' | ' + T('بيع ', 'prix ', 'price ') + plain(r.price) + ' | ' + T('ربح ', 'profit ', 'profit ') + plain(r.profit) + ' (' + r.margin + '%)'); });
    if (c.margin != null) { L.push(''); L.push(T('هامش الفترة: ', 'Marge : ', 'Margin: ') + c.margin + '%  — ' + T('ربح تقديري ', 'bénéfice ', 'profit ') + plain(c.profit)); }
    share(L.join('\n'));
  };
  X.cs_csv = function () {
    var rg = csRange(), c = K.costing(U.D, rg.from, rg.to, { alloc: S.csAlloc }), rows = [[T('المنتج', 'Produit', 'Product'), T('مباع', 'Vendus', 'Sold'), T('سعر البيع', 'Prix', 'Price'), T('مواد', 'Matière', 'Material'), T('عمالة', 'Main-d\'œuvre', 'Labour'), T('مصاريف', 'Frais', 'Overheads'), T('التكلفة الكاملة', 'Coût complet', 'Full cost'), T('ربح/صندوق', 'Profit/caisse', 'Profit/crate'), T('هامش %', 'Marge %', 'Margin %'), T('ربح الفترة', 'Profit période', 'Period profit')]];
    function m(v) { return v == null ? '' : (v / 100).toFixed(2); }
    c.rows.forEach(function (r) { rows.push([r.product.name, r.sold, m(r.price), m(r.mat), m(r.labor), m(r.overhead), m(r.full), m(r.profit), r.margin == null ? '' : r.margin, m(r.total)]); });
    U.saveFile('khaldi_cost_' + rg.from + '_' + rg.to + '.csv', 'text/csv', '﻿' + rows.map(function (x) { return x.map(U.csvEscape).join(','); }).join('\r\n'));
  };
  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'csTarget') { S.csTarget = Number(e.target.value); var v = document.getElementById('csTv'); if (v) v.textContent = S.csTarget + '%'; }
  });
  document.addEventListener('change', function (e) { if (e.target && e.target.id === 'csTarget') U.render(true); });

  /* ---- what-if simulator ---- */
  X.cs_sim = function (el) {
    var rg = csRange(), c = K.costing(U.D, rg.from, rg.to, { alloc: S.csAlloc }), r = c.rows.filter(function (x) { return x.productId === el.dataset.id; })[0]; if (!r || r.full == null || r.price == null) return;
    var def0 = r.defRate || 0, h = '<form id="f" novalidate><h3>🧪 ' + esc(r.product.name) + '</h3><div class="muted">' + esc(T('غيّر الأرقام لترى أثرها فوراً. العمالة والمصاريف لكل صندوق تبقى كما هي.', 'Changez les valeurs pour voir l\'effet.', 'Move the sliders to see the effect. Labour and overheads per crate stay the same.')) + '</div>' +
      '<div class="sim-r"><label>' + T('سعر البيع', 'Prix de vente', 'Selling price') + ' <b id="sv1"></b></label><input type="range" id="sp" min="-30" max="40" step="1" value="0"></div>' +
      '<div class="sim-r"><label>' + T('سعر المادة الخام', 'Prix matière', 'Raw material price') + ' <b id="sv2"></b></label><input type="range" id="sm" min="-30" max="40" step="1" value="0"></div>' +
      '<div class="sim-r"><label>' + T('نسبة العيوب', 'Taux de défauts', 'Defect rate') + ' <b id="sv3"></b></label><input type="range" id="sd" min="0" max="25" step="0.5" value="' + def0 + '"></div>' +
      '<div class="sim-o" id="so"></div><div class="btns"><button type="button" class="btn ghost" id="sr0">' + T('إعادة الضبط', 'Réinitialiser', 'Reset') + '</button><button type="button" class="btn primary" data-act="close">' + t('close') + '</button></div></form>';
    U.showModal(h);
    function upd() {
      var dp = Number(U.$('#sp').value), dm = Number(U.$('#sm').value), dd = Number(U.$('#sd').value);
      var price = r.price * (1 + dp / 100), theo = r.theo * (1 + dm / 100), mat = theo / (1 - dd / 100), full = mat + r.labor + r.overhead, profit = price - full, margin = price > 0 ? Math.round(profit * 1000 / price) / 10 : 0, tot = profit * (r.sold || 0), tot0 = r.profit * (r.sold || 0);
      U.$('#sv1').textContent = (dp >= 0 ? '+' : '') + dp + '% → ' + K.fmtMoney(Math.round(price)) + ' ' + t('dzd');
      U.$('#sv2').textContent = (dm >= 0 ? '+' : '') + dm + '%';
      U.$('#sv3').textContent = dd + '% ' + (dd !== def0 ? '(' + T('حالياً', 'actuel', 'now') + ' ' + def0 + '%)' : '');
      U.$('#so').innerHTML = '<div class="sim-k"><small>' + T('التكلفة الكاملة', 'Coût complet', 'Full cost') + '</small><b>' + plain(Math.round(full)) + '</b><em>' + dlt(full - r.full, true) + '</em></div><div class="sim-k"><small>' + T('ربح الصندوق', 'Profit/caisse', 'Profit/crate') + '</small><b class="' + (profit < 0 ? 'rd' : 'gn') + '">' + plain(Math.round(profit)) + '</b><em>' + dlt(profit - r.profit, false) + '</em></div><div class="sim-k"><small>' + T('الهامش', 'Marge', 'Margin') + '</small><b class="' + (margin < 0 ? 'rd' : 'gn') + '">' + margin + '%</b><em>' + (r.margin != null ? (margin - r.margin >= 0 ? '+' : '') + Math.round((margin - r.margin) * 10) / 10 + ' ' + T('نقطة', 'pt', 'pts') : '') + '</em></div>' +
        (r.sold ? '<div class="sim-k w"><small>' + T('ربح الفترة بنفس الكمية المباعة', 'Profit période (même volume)', 'Period profit at the same volume') + '</small><b class="' + (tot < 0 ? 'rd' : 'gn') + '">' + plain(Math.round(tot)) + '</b><em>' + dlt(tot - tot0, false, true) + '</em></div>' : '');
    }
    function dlt(v, inv, big) { var x = Math.round(v); if (!x) return '—'; var good = inv ? x < 0 : x > 0; return '<span class="' + (good ? 'gn' : 'rd') + '">' + (x > 0 ? '▲ +' : '▼ ') + K.fmtMoney(Math.abs(x)) + '</span>'; }
    ['sp', 'sm', 'sd'].forEach(function (id) { U.$('#' + id).addEventListener('input', upd); });
    U.$('#sr0').addEventListener('click', function () { U.$('#sp').value = 0; U.$('#sm').value = 0; U.$('#sd').value = def0; upd(); });
    upd();
  };
})();
