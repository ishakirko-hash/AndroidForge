/* KHALDI PLAST - v2.14: workers <-> machines link. The shift roster already stores which machine each worker is on;
   this adds: crew card + quick assign on the machine monitor, a "who is on which machine" map with output per worker on the
   workers page, and smart alerts (machine without crew / worker without machine). No schema change. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, S = U.S, X = U.extraActions;
  function T(ar, fr, en) { var l = U.lang(); return l === 'fr' ? fr : l === 'en' ? en : ar; }
  function B(n) { return '<bdi class="num" dir="ltr">' + n + '</bdi>'; }
  function curShift() { var h = new Date().getHours(); return h >= 8 && h < 16 ? 1 : h >= 16 ? 2 : 3; }
  function today() { return K.today(); }
  function wname(id) { var w = K.byId(U.D.workers, id); return w ? w.name : '?'; }
  function mname(id) { var m = K.byId(U.D.machines, id); return m ? m.name : ''; }
  function out(mid, n) { var c = ((U.D.settings.mon || {}).counts || {})[mid + '|' + today() + '|' + n]; return c ? c.n : 0; }
  function crewOf(mid, n) { return K.rosterFor(U.D, today(), n).filter(function (a) { return a.machineId === mid; }); }

  /* alerts for the current shift: only when a roster exists for it (so a factory that never plans is not nagged) */
  U.crewAlerts = function () {
    var D = U.D, n = curShift(), r = K.rosterFor(D, today(), n), ms = U.act(D.machines);
    if (!ms.length || !r.some(function (a) { return a.worked; })) return null;
    var noMachine = r.filter(function (a) { return a.worked && !a.machineId; }).length;
    var noCrew = ms.filter(function (m) { return !r.some(function (a) { return a.worked && a.machineId === m.id; }); }).length;
    return (noMachine || noCrew) ? { noMachine: noMachine, noCrew: noCrew, n: n } : null;
  };

  function chip(a) {
    return '<span class="cw ' + (a.worked ? 'ok' : 'no') + '" data-act="open_worker" data-id="' + a.workerId + '"><i></i>' + esc(wname(a.workerId)) + (a.worked ? '' : ' <small>' + T('غائب', 'absent', 'absent') + '</small>') + '</span>';
  }

  /* ---- machine monitor: crew card ---- */
  function machCard() {
    var q = S.mm || {}, mid = q.m, n = q.shift || curShift(), main = U.$('#main'), chips = main && main.querySelector('.mm-chips');
    if (!chips || !mid) return;
    var old = document.getElementById('crew_card'); if (old) old.remove();
    var cr = crewOf(mid, n), here = cr.filter(function (a) { return a.worked; }), tot = out(mid, n);
    var live = n === curShift(), warn = !here.length;
    var h = '<div class="card crew' + (warn && live ? ' warn' : '') + '" id="crew_card"><div class="cr-h"><span class="cr-i">' + V.icon('users', 18) + '</span><b>' + T('طاقم الآلة', 'Équipe machine', 'Machine crew') + ' · ' + t('shift') + ' ' + n + '</b>' +
      '<button class="btn sm" data-act="crew_edit" data-m="' + mid + '" data-n="' + n + '">' + (cr.length ? T('تعديل', 'Modifier', 'Edit') : T('+ تعيين عمال', '+ Affecter', '+ Assign')) + '</button></div>';
    h += cr.length ? '<div class="cr-w">' + cr.map(chip).join('') + '</div>' : '<div class="cr-e">' + (live ? '⚠️ ' : '') + T('لا يوجد عمال معيّنون لهذه الآلة في هذا الشفت.', 'Aucun ouvrier affecté à cette machine pour ce poste.', 'No workers assigned to this machine for this shift.') + '</div>';
    if (here.length) h += '<div class="cr-s"><div><small>' + T('عدد العمال', 'Ouvriers', 'Workers') + '</small><b>' + B(here.length) + '</b></div><div><small>' + T('إنتاج الشفت', 'Production du poste', 'Shift output') + '</small><b>' + B(K.groupInt(tot)) + '</b></div><div><small>' + T('لكل عامل', 'Par ouvrier', 'Per worker') + '</small><b>' + B(K.groupInt(Math.round(tot / here.length))) + '</b></div></div>';
    if (!K.rosterFor(U.D, today(), n).length && yesterdayRoster(n).length) h += '<button class="btn ghost cr-cp" data-act="crew_copy" data-n="' + n + '">📋 ' + T('نسخ طاقم الأمس لهذا الشفت', 'Copier l\'équipe d\'hier', 'Copy yesterday\'s crew') + '</button>';
    h += weekBars(mid) + '</div>';
    chips.insertAdjacentHTML('afterend', h);
  }

  /* ---- workers page: who is on which machine, per shift ---- */
  function workersMap() {
    var main = U.$('#main'); if (!main) return; var rows = main.querySelectorAll('.shrow'); if (!rows.length) return;
    var D = U.D, ms = U.act(D.machines); if (!ms.length) return;
    [].forEach.call(rows, function (row) {
      var b = row.querySelector('[data-act="roster"][data-shift]'); if (!b || row.querySelector('.cmap, .cr-cp')) return; var n = parseInt(b.dataset.shift, 10), r = K.rosterFor(D, today(), n);
      if (!r.length) { if (yesterdayRoster(n).length) row.insertAdjacentHTML('beforeend', '<button class="btn ghost cr-cp" data-act="crew_copy" data-n="' + n + '">📋 ' + T('نسخ طاقم الأمس', 'Copier l\'équipe d\'hier', 'Copy yesterday\'s crew') + '</button>'); return; }
      var free = r.filter(function (a) { return a.worked && !a.machineId; }), h = '<div class="cmap">';
      ms.forEach(function (m) {
        var cr = r.filter(function (a) { return a.machineId === m.id; }), w = cr.filter(function (a) { return a.worked; }).length, o = out(m.id, n);
        h += '<div class="cm-r' + (w ? '' : ' empty') + '" data-act="crew_open" data-m="' + m.id + '" data-n="' + n + '"><b>' + esc(m.name) + '</b><div class="cm-c">' + (cr.length ? cr.map(chip).join('') : '<small>' + T('بلا عمال', 'sans ouvriers', 'no crew') + '</small>') + '</div>' +
          '<span class="cm-o">' + (o ? B(K.groupInt(o)) + ' <small>' + t('mm_crate') + (w ? ' · ' + B(K.groupInt(Math.round(o / w))) + '/' + T('عامل', 'ouv.', 'wkr') : '') + '</small>' : '<small>—</small>') + '</span></div>';
      });
      if (free.length) h += '<div class="cm-free">⚠️ ' + T('عمال بلا آلة: ', 'Sans machine : ', 'No machine: ') + free.map(function (a) { return esc(wname(a.workerId)); }).join('، ') + '</div>';
      row.insertAdjacentHTML('beforeend', h + '</div>');
    });
  }


  /* ---- output attribution: a shift's counted output is shared equally by the workers who worked on that machine ---- */
  function counts() { return (U.D.settings.mon || {}).counts || {}; }
  function sharesFor(wid, from, to) {
    var D = U.D, C = counts(), per = {}, tot = 0, sh = 0;
    D.attendance.filter(function (a) { return a.workerId === wid && a.worked && a.machineId && a.date >= from && a.date <= to; }).forEach(function (a) {
      var c = C[a.machineId + '|' + a.date + '|' + a.shift]; if (!c) return;
      var crew = D.attendance.filter(function (x) { return x.date === a.date && x.shift === a.shift && x.machineId === a.machineId && x.worked; }).length || 1;
      var v = c.n / crew, o = per[a.machineId] || (per[a.machineId] = { shifts: 0, v: 0 }); o.shifts++; o.v += v; tot += v; sh++;
    });
    return { per: per, tot: tot, shifts: sh };
  }
  function workerCard() {
    var main = U.$('#main'), id = U.arg, head = main && main.querySelector('.wk-head'); if (!head || !id) return;
    var old = document.getElementById('wperf'); if (old) old.remove();
    var to = today(), from = K.addDays(to, -29), r = sharesFor(id, from, to); if (!r.shifts) return;
    var keys = Object.keys(r.per).sort(function (a, b) { return r.per[b].v - r.per[a].v; }), mx = r.per[keys[0]].v || 1;
    var h = '<div class="card" id="wperf"><div class="cr-h"><span class="cr-i">' + V.icon('bars', 18) + '</span><b>' + T('الأداء على الآلات · آخر 30 يوماً', 'Performance machines · 30 j', 'Machine performance · 30 days') + '</b></div>' +
      '<div class="cr-s"><div><small>' + T('شفتات بإنتاج', 'Postes comptés', 'Counted shifts') + '</small><b>' + B(r.shifts) + '</b></div><div><small>' + T('إنتاج منسوب', 'Production attribuée', 'Attributed output') + '</small><b>' + B(K.groupInt(Math.round(r.tot))) + '</b></div><div><small>' + T('متوسط/شفت', 'Moy./poste', 'Avg/shift') + '</small><b>' + B(K.groupInt(Math.round(r.tot / r.shifts))) + '</b></div></div><div class="hb" style="margin-top:12px">' +
      keys.map(function (k) { var o = r.per[k]; return '<div class="hb-r"><div class="hb-h"><i style="background:#1E6FE8"></i><b>' + esc(mname(k)) + '</b><span class="hb-p">' + B(o.shifts) + ' ' + T('شفت', 'postes', 'shifts') + '</span></div><div class="hb-t"><u style="width:' + Math.max(4, Math.round(o.v * 100 / mx)) + '%;background:linear-gradient(90deg,#1E6FE8,#1E6FE8aa)"></u></div><div class="hb-f"><span>' + B(K.groupInt(Math.round(o.v))) + ' ' + t('mm_crate') + '</span><small>' + B(K.groupInt(Math.round(o.v / o.shifts))) + '/' + T('شفت', 'poste', 'shift') + '</small></div></div>'; }).join('') + '</div>' +
      '<div class="muted" style="font-size:11.5px;margin-top:8px">' + T('الإنتاج المنسوب = إنتاج الآلة في الشفت مقسوماً بالتساوي على العمال الحاضرين عليها.', 'Production répartie à parts égales entre les ouvriers présents.', 'Output shared equally between workers present on the machine.') + '</div></div>';
    var nx = head.nextElementSibling; (nx || head).insertAdjacentHTML('afterend', h);
  }
  function weekBars(mid) {
    var D = U.D, C = counts(), to = today(), days = [], mx = 1, i;
    for (i = 6; i >= 0; i--) { var d = K.addDays(to, -i), v = 0, w = 0; [1, 2, 3].forEach(function (n) { var c = C[mid + '|' + d + '|' + n]; if (c) v += c.n; w = Math.max(w, D.attendance.filter(function (a) { return a.date === d && a.machineId === mid && a.worked && a.shift === n; }).length); }); days.push({ d: d, v: v, w: w }); mx = Math.max(mx, v); }
    if (!days.some(function (x) { return x.v; })) return '';
    return '<div class="wkb"><small>' + T('إنتاج آخر 7 أيام (وعدد العمال)', 'Production 7 jours (ouvriers)', 'Last 7 days output (workers)') + '</small><div class="wkb-g">' + days.map(function (x) { return '<div class="wkb-c"><span>' + (x.v ? B(K.groupInt(x.v)) : '—') + '</span><u style="height:' + Math.max(3, Math.round(x.v * 100 / mx)) + 'px"></u><em>' + x.d.slice(8) + '</em><small>' + (x.w ? '👷' + x.w : '') + '</small></div>'; }).join('') + '</div></div>';
  }

  /* ---- copy yesterday's crew (same shift) when today's is still empty ---- */
  function yesterdayRoster(n) { var D = U.D; return K.rosterFor(D, K.addDays(today(), -1), n).filter(function (a) { var w = K.byId(D.workers, a.workerId); return w && !w.archived && (!a.machineId || K.byId(D.machines, a.machineId)); }); }
  X.crew_copy = function (el) {
    var n = parseInt(el.dataset.n, 10) || curShift(), y = yesterdayRoster(n);
    if (K.rosterFor(U.D, today(), n).length) { U.toast(T('طاقم اليوم موجود بالفعل', 'Équipe déjà définie', 'Today\'s crew already set'), 'bad'); return; }
    if (!y.length) { U.toast(T('لا يوجد طاقم أمس لنسخه', 'Rien à copier', 'Nothing to copy'), 'bad'); return; }
    try { U.commit(function (d) { K.setShiftRoster(d, { date: today(), shift: n, entries: y.map(function (a) { return { workerId: a.workerId, worked: true, machineId: a.machineId || null }; }) }); }); U.render(true); U.toast(T('تم نسخ طاقم الأمس (' + y.length + ' عامل)', 'Équipe d\'hier copiée', 'Yesterday\'s crew copied'), 'ok'); } catch (err) { U.toast(U.errMsg(err), 'bad'); }
  };

  var prev = U.afterRender;
  U.afterRender = function (R) { if (prev) prev(R); try { if (R === 'machmon') machCard(); if (R === 'workers') workersMap(); if (R === 'worker') workerCard(); } catch (e) { } };

  X.crew_open = function (el) { S.mm = S.mm || {}; S.mm.m = el.dataset.m; S.mm.shift = parseInt(el.dataset.n, 10) || 1; U.go('machmon'); };

  /* ---- quick assign form ---- */
  X.crew_edit = function (el) {
    var mid = el.dataset.m, n = parseInt(el.dataset.n, 10) || curShift(), D = U.D, day = today(), cur = K.rosterFor(D, day, n);
    var ws = U.act(D.workers).filter(function (w) { return w.active || cur.some(function (a) { return a.workerId === w.id; }); });
    if (!ws.length) { U.toast(t('add_workers_first'), 'bad'); return; }
    var h = '<form id="f" novalidate><h3>' + T('تعيين العمال', 'Affecter les ouvriers', 'Assign workers') + ' · ' + esc(mname(mid)) + '</h3><div class="muted">' + t('shift') + ' ' + n + ' · ' + K.fmtDate(day) + '</div><div class="crl">';
    ws.forEach(function (w) {
      var a = cur.filter(function (x) { return x.workerId === w.id; })[0], on = a && a.worked && a.machineId === mid, other = a && a.machineId && a.machineId !== mid;
      h += '<label class="crw"><input type="checkbox" name="w_' + w.id + '"' + (on ? ' checked' : '') + '><span><b>' + esc(w.name) + '</b>' + (w.role ? ' <small>' + esc(w.role) + '</small>' : '') + (other ? '<em>' + T('حالياً على ', 'Actuellement sur ', 'Now on ') + esc(mname(a.machineId)) + '</em>' : '') + '</span></label>';
    });
    h += '</div><div id="ferr" class="ferr"></div><div class="btns"><button type="button" class="btn ghost" data-act="close">' + t('cancel') + '</button><button type="submit" class="btn primary">' + t('save') + '</button></div></form>';
    U.showModal(h);
    U.$('#f').addEventListener('submit', function (e) {
      e.preventDefault(); var f = U.$('#f'), entries = [], seen = {};
      ws.forEach(function (w) {
        var a = cur.filter(function (x) { return x.workerId === w.id; })[0], chk = f.elements['w_' + w.id].checked;
        if (chk) entries.push({ workerId: w.id, worked: true, machineId: mid });
        else if (a) entries.push({ workerId: w.id, worked: a.worked, machineId: a.machineId === mid ? null : a.machineId });
        seen[w.id] = 1;
      });
      cur.forEach(function (a) { if (!seen[a.workerId]) entries.push({ workerId: a.workerId, worked: a.worked, machineId: a.machineId }); });
      try { U.commit(function (d) { K.setShiftRoster(d, { date: day, shift: n, entries: entries }); }); U.closeModal(); U.render(true); U.toast(t('saved_ok'), 'ok'); } catch (err) { U.$('#ferr').textContent = U.errMsg(err); }
    });
  };
})();
