const L=require('./lib.js');let pass=0,fail=0;const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n);};
(async()=>{const s=await L.start(process.argv[2],390);const p=s.page;await p.waitForSelector('#splash.hidden',{state:'attached'});await L.legacyHome(p);
const r=await p.evaluate(()=>{const U=window.KPU,K=U.K;let r={};const td=K.today(),yd=K.addDays(td,-1);U.commit(d=>{
const sp=K.addSupplier(d,{name:'S'});K.recordPurchase(d,{date:K.addDays(td,-20),supplierId:sp.id,materialId:'mat_granule',qty:9000,unitCost:15000,paid:0,method:'cash'});K.recordPurchase(d,{date:K.addDays(td,-3),supplierId:sp.id,materialId:'mat_granule',qty:6000,unitCost:16500,paid:0,method:'cash'});
const c=K.addCustomer(d,{name:'مزرعة النور'});K.addMachine(d,{name:'آلة 01'});K.addMachine(d,{name:'آلة 02'});
const a=K.addProduct(d,{name:'صندوق فواكه كبير',price:42000,weightG:900,color:'blue',recipe:{mat_granule:900}}),b=K.addProduct(d,{name:'صندوق فواكه صغير',price:24000,weightG:450,color:'green',recipe:{mat_granule:450}});
const ws=['يوسف','كريم','سمير','أمين'].map((n,i)=>K.addWorker(d,{name:n,role:'مشغّل',rate:200000,hireDate:'2025-03-01',phone:'07700'+i}));
const h=new Date().getHours(),sh=(h>=8&&h<16)?1:(h>=16?2:3);r.sh=sh;const m=d.machines.map(x=>x.id);const C={};
for(let i=9;i>=0;i--){const dy=K.addDays(td,-i);K.setShiftRoster(d,{date:dy,shift:sh,entries:[{workerId:ws[0].id,worked:true,machineId:m[0]},{workerId:ws[1].id,worked:true,machineId:m[0]},{workerId:ws[2].id,worked:true,machineId:m[1]},{workerId:ws[3].id,worked:i%4!==0,machineId:m[1]}]});
K.recordProduction(d,{date:dy,shift:sh,productId:a.id,good:300+i*8,defective:i===0?42:10,grams:{mat_granule:900}});K.recordProduction(d,{date:dy,shift:sh,productId:b.id,good:420,defective:6,grams:{mat_granule:450}});
C[m[0]+'|'+dy+'|'+sh]={n:640+i*5,ts:1};C[m[1]+'|'+dy+'|'+sh]={n:380,ts:1};}
for(let i=6;i>=0;i--){const dy=K.addDays(td,-i);K.recordSale(d,{date:dy,customerId:c.id,items:[{productId:a.id,qty:150,unitPrice:42000},{productId:b.id,qty:200,unitPrice:24000}],discount:0,paid:i%2?9000000:0,method:'cash'});}
const cat=d.expenseCats.filter(x=>x.key!=='salaries');K.recordExpense(d,{date:K.addDays(td,-2),categoryId:cat[0].id,amount:4500000,note:''});K.recordExpense(d,{date:K.addDays(td,-5),categoryId:cat[1%cat.length].id,amount:2500000,note:''});
d.settings.mon={cfg:{[m[0]]:{model:'HAITIAN',cycle:45,spd:1},[m[1]]:{model:'JSW',cycle:60,spd:1}},stops:[{id:'a',m:m[0],from:K.shiftWindow(td,sh).s+3600000,to:K.shiftWindow(td,sh).s+3600000+2700000,kind:'u',reason:'عطل قالب'}],counts:C};});
return r;});
await p.evaluate(()=>{window._sh=[];KPU.AND=KPU.AND||{};KPU.AND.shareText=t=>window._sh.push(t);});
const go=async r=>{await p.evaluate(r=>{KPU.stack=[];KPU.route=r;KPU.render();},r);await p.waitForTimeout(350);};
await go('shiftreport');
ok(await p.$('.dr .op-kg')!==null,'report shows KPI grid');
ok(await p.evaluate(()=>document.querySelectorAll('.op-i').length)>=3,'smart findings listed');
ok(await p.evaluate(()=>/عطل قالب/.test(document.querySelector('.op-ins').textContent)),'unjustified stop reason appears');
ok(await p.evaluate(()=>document.querySelectorAll('.op-m').length)===2,'both machines listed');
ok(await p.evaluate(()=>[...document.querySelectorAll('.op-m')].some(e=>/يوسف/.test(e.textContent))),'crew names appear under machine');
await p.click('[data-act=sr_shift][data-id="'+r.sh+'"]');await p.waitForTimeout(300);
ok(await p.evaluate(()=>!document.querySelector('.rpt-blk h4')||![...document.querySelectorAll('.rpt-blk h4')].some(h=>/المبيعات والنقد/.test(h.textContent))),'shift scope hides day-only sales block');
await p.click('[data-act=sr_shift][data-id="0"]');await p.waitForTimeout(300);
await p.click('[data-act=sr_day][data-id="-1"]');await p.waitForTimeout(300);
ok(await p.evaluate(()=>KPU.S.srDate===KPU.K.addDays(KPU.K.today(),-1)),'previous day navigation');
ok(await p.evaluate(()=>document.querySelector('[data-act=sr_day][data-id="1"]').disabled===false),'next enabled after going back');
await p.evaluate(()=>{KPU.S.srDate=KPU.K.addDays(KPU.K.today(),-60);KPU.render(true)});await p.waitForTimeout(300);
ok(await p.evaluate(()=>/لا توجد بيانات/.test(document.querySelector('#main').textContent)),'empty day shows friendly empty state');
await p.evaluate(()=>{KPU.S.srDate='';KPU.render(true)});await p.waitForTimeout(300);
await p.click('[data-act=sr_share]');await p.waitForTimeout(200);
ok(await p.evaluate(()=>window._sh.length===1&&/KHALDI PLAST/.test(window._sh[0])&&/📦/.test(window._sh[0])),'share text built');
await go('costing');
ok(await p.evaluate(()=>document.querySelectorAll('.cs-c').length)===2,'one cost card per product');
ok(await p.evaluate(()=>{const s=document.querySelectorAll('.cs-stk');return s.length===2&&[...s].every(x=>x.children.length>=2)&&document.querySelectorAll('.cs-cap').length===2;}),'stacked cost bars');
const m1=await p.evaluate(()=>document.querySelector('.op-kg .op-k.green b, .op-kg .op-k.amber b').textContent);
await p.click('[data-act=cs_alloc][data-id=count]');await p.waitForTimeout(300);
ok(await p.evaluate(()=>KPU.S.csAlloc==='count'),'allocation toggle');
await p.click('[data-act=cs_days][data-id="90"]');await p.waitForTimeout(300);
ok(await p.evaluate(()=>KPU.S.csDays===90),'period toggle');
await p.evaluate(()=>{document.querySelector('[data-act=cs_sim]').click()});await p.waitForTimeout(300);
ok(await p.$('#so .sim-k')!==null,'simulator opens');
const before=await p.textContent('#so');await p.evaluate(()=>{const e=document.querySelector('#sp');e.value=20;e.dispatchEvent(new Event('input'))});await p.waitForTimeout(150);
ok((await p.textContent('#so'))!==before,'raising the price changes simulator output');
await p.evaluate(()=>{const e=document.querySelector('#sd');e.value=0;e.dispatchEvent(new Event('input'))});
await p.click('#sr0');ok(await p.evaluate(()=>document.querySelector('#sp').value==='0'),'simulator reset');
await p.evaluate(()=>KPU.closeModal());
await p.evaluate(()=>{KPU.U&&0;const e=document.querySelector('#csTarget');e.value=40;e.dispatchEvent(new Event('input',{bubbles:true}))});
ok(await p.evaluate(()=>KPU.S.csTarget===40&&document.querySelector('#csTv').textContent==='40%'),'target margin slider');
await p.click('[data-act=cs_share]');await p.waitForTimeout(200);ok(await p.evaluate(()=>window._sh.length===2&&/%/.test(window._sh[1])),'cost share text');
// honesty: product without any purchase price must not get invented numbers
await p.evaluate(()=>{KPU.commit(d=>{KPU.K.addProduct(d,{name:'منتج جديد',price:10000,recipe:{mat_broye:300}});const sp=d.suppliers[0];});KPU.render(true)});
const c=await p.evaluate(()=>{const K=KPU.K,rg={from:K.addDays(K.today(),-89),to:K.today()};return K.costing(KPU.D,rg.from,rg.to).rows.filter(r=>r.product.name==='منتج جديد').length});ok(c===0,'unsold & unproduced product is not listed');
// dark mode
await p.evaluate(()=>{KPU.commit(d=>{d.settings.theme='dark'})});await go('costing');await p.screenshot({path:'/tmp/op_dark.png',clip:{x:0,y:200,width:390,height:700}});
await go('more');ok(await p.evaluate(()=>/تقرير الشفت/.test(document.querySelector('#main').textContent)&&/تكلفة الصندوق/.test(document.querySelector('#main').textContent)),'both tiles reachable from More');
console.log('errors:',s.errors.length?s.errors.join('|'):'none');console.log('pass',pass,'fail',fail);await s.close();})();
