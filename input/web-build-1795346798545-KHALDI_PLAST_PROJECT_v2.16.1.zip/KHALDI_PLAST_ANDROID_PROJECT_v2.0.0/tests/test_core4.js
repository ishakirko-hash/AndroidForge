// Run with:  node tests/test_core4.js   (shift report + full crate cost, hand-calculated expectations)
const K = require('../app/src/main/assets/www/core4.js');
let pass = 0, fail = 0;
const ok = (c, n) => { if (c) pass++; else { fail++; console.log('FAIL:', n); } };
const near = (a, b, n, tol) => ok(a != null && Math.abs(a - b) <= (tol || 1), n + ' (got ' + a + ', want ' + b + ')');
let d = K.emptyData(); const D1 = '2026-10-14';
d = K.tx(d, x => { K.addSupplier(x, { name: 'S' }); K.addCustomer(x, { name: 'Ali' }); K.addMachine(x, { name: 'M1' }); K.addMachine(x, { name: 'M2' }); });
const sup = d.suppliers[0].id, cus = d.customers[0].id, m1 = d.machines[0].id, m2 = d.machines[1].id;
d = K.tx(d, x => K.recordPurchase(x, { date: '2026-10-01', supplierId: sup, materialId: 'mat_granule', qty: 1000, unitCost: 15000, paid: 15000000 }));
d = K.tx(d, x => { K.addProduct(x, { name: 'Crate A', price: 16000, weightG: 500, recipe: { mat_granule: 500 } }); K.addWorker(x, { name: 'Yousef', rate: 200000, hireDate: '2026-01-01' }); K.addWorker(x, { name: 'Karim', rate: 200000, hireDate: '2026-01-01' }); });
const pid = d.products[0].id, w1 = d.workers[0].id, w2 = d.workers[1].id;
d = K.tx(d, x => { K.setShiftRoster(x, { date: D1, shift: 1, entries: [{ workerId: w1, worked: true, machineId: m1 }, { workerId: w2, worked: false, machineId: m1 }] }); });
d = K.tx(d, x => K.recordProduction(x, { date: D1, shift: 1, productId: pid, good: 90, defective: 10, grams: { mat_granule: 500 } }));
const cat = d.expenseCats.filter(c => c.key !== 'salaries')[0].id;
d = K.tx(d, x => K.recordExpense(x, { date: D1, categoryId: cat, amount: 90000, note: '' }));
d = K.tx(d, x => K.recordSale(x, { date: D1, customerId: cus, items: [{ productId: pid, qty: 90, unitPrice: 15000 }], discount: 0, paid: 0, method: 'cash' }));
d.settings.mon = { cfg: { [m1]: { cycle: 20, spd: 3 } }, counts: { [m1 + '|' + D1 + '|1']: { n: 100, ts: 1 } }, stops: [] };

/* ---- shift report ---- */
const NOW = new Date(2026, 9, 15, 12, 0).getTime();               // day is over -> full 8h window
const r = K.shiftReport(d, D1, 1, NOW);
ok(r.production.good === 90 && r.production.defective === 10, 'production totals');
near(r.production.defPct, 10, 'defect % = 10');
near(r.production.kg, 50, 'kg used = 100 crates x 0.5kg', 0.001);
near(r.production.cost, 750000, 'material cost = 50kg x 150 DZD');
near(r.production.rows[0].perGood, 8333, 'cost per good crate includes scrap');
near(r.production.defectCost, 75000, 'defect cost = 10% of material');
const mm = r.machines.filter(x => x.machine.id === m1)[0];
near(mm.expected, 1440, 'target = 8h / 20s = 1440');
near(mm.eff, 6.9, 'efficiency = 100/1440', 0.1);
ok(mm.crew.length === 1 && mm.crew[0] === 'Yousef', 'crew = workers who worked on the machine');
ok(r.crew.absent.length === 1 && r.crew.absent[0] === 'Karim', 'absent listed');
ok(r.money === null, 'shift scope has no money block');
const day = K.shiftReport(d, D1, 0, NOW);
ok(day.money.salesCount === 1 && day.money.sales === 1350000 && day.money.unpaidShare === 100, 'day money block');
ok(day.insights.some(i => i.c === 'defect_high'), 'high defect finding');
ok(day.insights.some(i => i.c === 'mach_low'), 'low machine efficiency finding');
ok(day.insights.some(i => i.c === 'credit'), 'credit-risk finding');
ok(K.shiftReport(d, '2026-09-01', 0, NOW).empty === true, 'empty day flagged');
// stops: 30 unjustified minutes inside shift 1
const s0 = K.shiftWindow(D1, 1).s;
let d2 = JSON.parse(JSON.stringify(d)); d2.settings.mon.stops = [{ id: 's', m: m1, from: s0 + 3600000, to: s0 + 3600000 + 1800000, kind: 'u', reason: 'jam' }];
const r2 = K.shiftReport(d2, D1, 1, NOW).machines.filter(x => x.machine.id === m1)[0];
ok(r2.unjMin === 30 && r2.reasons[0] === 'jam', 'unjustified stop minutes + reason');
near(r2.expected, 1440, 'unjustified stop does not reduce target');
d2.settings.mon.stops[0].kind = 'j'; near(K.shiftReport(d2, D1, 1, NOW).machines.filter(x => x.machine.id === m1)[0].expected, 1350, 'justified stop reduces target by 1800s/20s = 90');

/* ---- costing ---- */
const c = K.costing(d, '2026-10-01', '2026-10-31', { alloc: 'weight' }), row = c.rows[0];
near(row.mat, 8333, 'material per good crate (actual, scrap included)');
near(row.theo, 7500, 'theoretical material per crate');
near(row.scrap, 833, 'scrap per good crate');
near(row.labor, 2222, 'labour = 2 workers? only worked shifts: 1 x 2000 DZD / 90');
near(row.overhead, 1000, 'overhead = 900 DZD / 90');
near(row.full, 11556, 'full cost', 1);
near(row.price, 15000, 'price = real sold price');
near(row.profit, 3444, 'profit per crate', 1);
near(row.margin, 23, 'margin %', 0.1);
near(row.breakEven, 11556, 'break-even = full cost', 1);
near(row.suggest(30), 16508, 'suggested price for 30% margin', 2);
near(row.total, 310000, 'period profit = per crate x sold', 100);
near(c.margin, 23, 'blended margin', 0.1);
const cc = K.costing(d, '2026-10-01', '2026-10-31', { alloc: 'count' }).rows[0]; near(cc.full, row.full, 'single product: both allocations equal', 1);
// no-purchase data -> unknown, never invented
let e = K.emptyData(); e = K.tx(e, x => K.addProduct(x, { name: 'B', price: 100, recipe: { mat_granule: 100 } }));
const ce = K.costing(e, '2026-10-01', '2026-10-31'); ok(ce.rows.length === 0 && ce.margin === null, 'nothing sold or produced -> no rows');
console.log('pass', pass, 'fail', fail);
