package dz.khaldiplast.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(28), dp(28), dp(28));
        root.setBackgroundColor(Color.WHITE);

        ImageView mark = new ImageView(this);
        int logoId = getResources().getIdentifier("kp_splash_mark", "drawable", getPackageName());
        mark.setImageResource(logoId);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(mark, new LinearLayout.LayoutParams(dp(220), dp(180)));

        TextView title = new TextView(this);
        title.setText("KHALDI PLAST");
        title.setTextColor(Color.rgb(11, 26, 46));
        title.setTextSize(25);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setLetterSpacing(0.08f);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-2, -2);
        titleLp.topMargin = dp(15);
        root.addView(title, titleLp);

        TextView arabic = new TextView(this);
        arabic.setText("خالدي بلاست");
        arabic.setTextColor(Color.rgb(0, 119, 204));
        arabic.setTextSize(19);
        arabic.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        arabic.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams arabicLp = new LinearLayout.LayoutParams(-2, -2);
        arabicLp.topMargin = dp(7);
        root.addView(arabic, arabicLp);

        TextView tagline = new TextView(this);
        tagline.setText("SHAPING TOMORROW");
        tagline.setTextColor(Color.rgb(110, 130, 151));
        tagline.setTextSize(10);
        tagline.setLetterSpacing(0.18f);
        tagline.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(-2, -2);
        tagLp.topMargin = dp(9);
        root.addView(tagline, tagLp);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(dp(110), dp(4));
        progressLp.topMargin = dp(34);
        root.addView(progress, progressLp);

        setContentView(root);
        handler.postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, 900);
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
