# No code shrinking is enabled in this first Android wrapper.
