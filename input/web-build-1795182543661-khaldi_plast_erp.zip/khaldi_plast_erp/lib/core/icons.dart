import 'package:flutter/material.dart';
import 'theme.dart';

class AppIconDef {
  final IconData icon;
  final Color color;
  const AppIconDef(this.icon, this.color);
}

class AppIcons {
  static const Map<String, AppIconDef> reg = {
    // navigation
    'app_home': AppIconDef(Icons.home_rounded, C.navy),
    'app_sales': AppIconDef(Icons.shopping_cart_rounded, C.success),
    'app_inventory': AppIconDef(Icons.inventory_2_rounded, C.primary),
    'app_production': AppIconDef(Icons.precision_manufacturing_rounded, C.primary),
    'app_more': AppIconDef(Icons.grid_view_rounded, C.navy),
    // modules
    'app_customers': AppIconDef(Icons.groups_rounded, C.purple),
    'app_suppliers': AppIconDef(Icons.local_shipping_rounded, C.warning),
    'app_products': AppIconDef(Icons.view_in_ar_rounded, C.primary),
    'app_employees': AppIconDef(Icons.badge_rounded, C.success),
    'app_shifts': AppIconDef(Icons.calendar_month_rounded, C.primary),
    'app_machines': AppIconDef(Icons.settings_suggest_rounded, C.success),
    'app_orders': AppIconDef(Icons.assignment_turned_in_rounded, C.primary),
    'app_notes': AppIconDef(Icons.edit_note_rounded, C.warning),
    'app_raw_materials': AppIconDef(Icons.layers_rounded, C.primary),
    'app_maintenance': AppIconDef(Icons.build_rounded, C.error),
    'app_expenses': AppIconDef(Icons.account_balance_wallet_rounded, C.purple),
    'app_reports': AppIconDef(Icons.bar_chart_rounded, C.warning),
    'app_settings': AppIconDef(Icons.settings_rounded, C.primary),
    'app_notifications': AppIconDef(Icons.notifications_rounded, C.error),
    'app_permissions': AppIconDef(Icons.shield_rounded, C.purple),
    'app_backup': AppIconDef(Icons.cloud_download_rounded, C.primary),
    'app_profile': AppIconDef(Icons.person_rounded, C.navy),
    'app_invoice': AppIconDef(Icons.receipt_long_rounded, C.primary),
    'app_profit': AppIconDef(Icons.trending_up_rounded, C.success),
    'app_calc': AppIconDef(Icons.calculate_rounded, C.purple),
    'app_language': AppIconDef(Icons.translate_rounded, C.primary),
    // actions
    'add': AppIconDef(Icons.add_rounded, C.primary),
    'edit': AppIconDef(Icons.edit_rounded, C.primary),
    'delete': AppIconDef(Icons.delete_rounded, C.error),
    'search': AppIconDef(Icons.search_rounded, C.text2),
    'filter': AppIconDef(Icons.filter_list_rounded, C.text2),
    'save': AppIconDef(Icons.check_rounded, C.success),
    'cancel': AppIconDef(Icons.close_rounded, C.error),
    'back': AppIconDef(Icons.arrow_back_rounded, C.navy),
    'forward': AppIconDef(Icons.arrow_forward_rounded, C.navy),
    'print': AppIconDef(Icons.print_rounded, C.primary),
    'pdf': AppIconDef(Icons.picture_as_pdf_rounded, C.error),
    'share': AppIconDef(Icons.share_rounded, C.primary),
    'download': AppIconDef(Icons.download_rounded, C.primary),
    'upload': AppIconDef(Icons.upload_rounded, C.primary),
    'refresh': AppIconDef(Icons.refresh_rounded, C.primary),
    'history': AppIconDef(Icons.history_rounded, C.text2),
    'details': AppIconDef(Icons.info_rounded, C.primary),
    // status
    'st_success': AppIconDef(Icons.check_circle_rounded, C.success),
    'st_warning': AppIconDef(Icons.warning_amber_rounded, C.warning),
    'st_error': AppIconDef(Icons.error_rounded, C.error),
    'st_running': AppIconDef(Icons.play_arrow_rounded, C.success),
    'st_paused': AppIconDef(Icons.pause_rounded, C.warning),
    'st_stopped': AppIconDef(Icons.stop_rounded, C.error),
    'st_maintenance': AppIconDef(Icons.build_circle_rounded, C.warning),
    'st_completed': AppIconDef(Icons.check_rounded, C.success),
    'st_pending': AppIconDef(Icons.schedule_rounded, C.primary),
    'st_rejected': AppIconDef(Icons.cancel_rounded, C.error),
    'st_low_stock': AppIconDef(Icons.warning_amber_rounded, C.warning),
    'st_critical': AppIconDef(Icons.error_rounded, C.error),
  };

  static AppIconDef of(String k) => reg[k] ?? const AppIconDef(Icons.circle, C.text2);
}

class AppIcon extends StatelessWidget {
  final String k;
  final double size;
  final Color? color;
  final Color? bg;
  final String? label;
  final int? badge;
  final String? tooltip;
  const AppIcon(this.k, {super.key, this.size = 24, this.color, this.bg, this.label, this.badge, this.tooltip});

  @override
  Widget build(BuildContext context) {
    final d = AppIcons.of(k);
    final c = color ?? d.color;
    Widget w = Icon(d.icon, size: size, color: c);
    if (bg != null) {
      w = Container(
        padding: EdgeInsets.all(size * 0.4),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
        child: w,
      );
    }
    if (badge != null && badge! > 0) {
      w = Stack(clipBehavior: Clip.none, children: [
        w,
        PositionedDirectional(
          top: -4,
          end: -4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
            decoration: BoxDecoration(color: C.error, borderRadius: BorderRadius.circular(10)),
            child: Text('$badge', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
          ),
        ),
      ]);
    }
    if (label != null) {
      w = Column(mainAxisSize: MainAxisSize.min, children: [
        w,
        const SizedBox(height: 4),
        Text(label!, style: TextStyle(fontSize: 12, color: c, fontWeight: FontWeight.w600)),
      ]);
    }
    if (tooltip != null) w = Tooltip(message: tooltip!, child: w);
    return w;
  }
}

/// Fully clickable navigation / quick-action tile.
class AppTile extends StatelessWidget {
  final String icon;
  final String label;
  final String? sub;
  final VoidCallback onTap;
  final int? badge;
  const AppTile({super.key, required this.icon, required this.label, this.sub, required this.onTap, this.badge});

  @override
  Widget build(BuildContext context) {
    final d = AppIcons.of(icon);
    return Material(
      color: C.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: const BorderSide(color: C.border),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
          child: FittedBox(fit: BoxFit.scaleDown, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            AppIcon(icon, size: 24, color: d.color, bg: tint(d.color), badge: badge),
            const SizedBox(height: 6),
            Text(label,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.text)),
            if (sub != null)
              Text(sub!,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, color: C.text2)),
          ])),
        ),
      ),
    );
  }
}
