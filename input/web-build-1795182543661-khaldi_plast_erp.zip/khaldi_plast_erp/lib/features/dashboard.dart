import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/charts.dart';
import '../core/format.dart';
import '../core/icons.dart';
import '../core/i18n.dart';
import '../core/labels.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import 'entities.dart';
import 'entity.dart';
import 'inventory.dart';
import 'machines.dart';
import 'notifications.dart';
import 'sales.dart';
import 'production.dart';
import 'finance.dart';
import 'settings.dart';

class DashboardPage extends StatefulWidget {
  final void Function(int) goTab;
  const DashboardPage({super.key, required this.goTab});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int months = 6;

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Scaffold(
      body: DataView<Rec>(
        load: () => Svc.dashboard(months),
        builder: (c, d) {
          final monthly = d['monthly'] as List<Rec>;
          final byProduct = d['by_product'] as List<Rec>;
          final machines = d['machines'] as List<Rec>;
          final prodBy = d['prod_by_product'] as List<Rec>;
          final orders = d['orders'] as List<Rec>;
          final alerts = d['alerts'] as List<AlertItem>;
          final moves = d['movements'] as List<Rec>;
          final unread = alerts.where((a) => !a.read).length;
          var total = 0, working = 0, stopped = 0, maint = 0;
          for (final m in machines) {
            final n = intv(m['n']);
            total += n;
            switch (m['status']) {
              case 'stopped':
                stopped += n;
                break;
              case 'maintenance':
                maint += n;
                break;
              default:
                working += n;
            }
          }
          final ready = total > 0 ? (working / total * 100).round() : 0;
          final segs = <Seg>[
            for (var i = 0; i < byProduct.length; i++) Seg(dbl(byProduct[i]['amount']), segColors[i % segColors.length], str(byProduct[i]['name'])),
          ];
          final target = dbl(d['target_today']);
          return ListView(padding: EdgeInsets.zero, children: [
            _hero(context, top, unread),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                kpiRow(
                  KpiTile(
                    icon: Icons.shopping_cart_rounded,
                    color: C.success,
                    title: 'المبيعات',
                    value: fmt(dbl(d['sales'])),
                    unit: 'دج',
                    trend: d['sales_trend'] as double?,
                    onTap: () => widget.goTab(1),
                  ),
                  KpiTile(
                    icon: Icons.precision_manufacturing_rounded,
                    color: C.primary,
                    title: 'الإنتاج اليومي',
                    value: fmt(dbl(d['prod_today'])),
                    unit: 'قطعة',
                    trend: d['prod_trend'] as double?,
                    onTap: () => widget.goTab(3),
                  ),
                ),
                kpiRow(
                  KpiTile(
                    icon: Icons.inventory_2_rounded,
                    color: C.warning,
                    title: 'المخزون',
                    value: fmt(dbl(d['stock_pieces'])),
                    unit: 'قطعة',
                    onTap: () => widget.goTab(2),
                  ),
                  KpiTile(
                    icon: Icons.account_balance_wallet_rounded,
                    color: C.error,
                    title: 'المصاريف',
                    value: fmt(dbl(d['expenses'])),
                    unit: 'دج',
                    trend: d['expenses_trend'] as double?,
                    upIsGood: false,
                    onTap: () => go(context, const TransactionsPage()),
                  ),
                ),
                kpiRow(
                  KpiTile(
                    icon: Icons.savings_rounded,
                    color: C.purple,
                    title: 'المستحقات',
                    value: fmt(dbl(d['receivables'])),
                    unit: 'دج',
                    onTap: () => widget.goTab(1),
                  ),
                  KpiTile(
                    icon: Icons.trending_up_rounded,
                    color: dbl(d['net']) >= 0 ? C.success : C.error,
                    title: 'صافي الربح (الشهر)',
                    value: fmt(dbl(d['net'])),
                    unit: 'دج',
                    onTap: () => go(context, const ProfitPage()),
                  ),
                ),
                Panel(
                  title: 'المبيعات الشهرية (دج)',
                  icon: Icons.show_chart_rounded,
                  trailing: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                      value: months,
                      items: [
                        for (final n in const [3, 6, 12]) DropdownMenuItem<int>(value: n, child: Text('${t('آخر')} $n ${t('أشهر')}')),
                      ],
                      onChanged: (v) => setState(() => months = v ?? 6),
                    ),
                  ),
                  child: LineChart(values: [for (final m in monthly) dbl(m['value'])], labels: [for (final m in monthly) str(m['label'])]),
                ),
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(
                    child: Panel(
                      title: 'حالة الآلات',
                      icon: Icons.settings_suggest_rounded,
                      onTap: () => go(context, const MachinesPage()),
                      child: Column(children: [
                        Donut(size: 96, center: '$ready%', sub: 'جاهزية', segs: [Seg(working.toDouble(), C.success, ''), Seg(maint.toDouble(), C.warning, ''), Seg(stopped.toDouble(), C.error, '')]),
                        const SizedBox(height: 6),
                        _dot(C.success, 'تعمل', working),
                        _dot(C.error, 'متوقفة', stopped),
                        _dot(C.warning, 'صيانة', maint),
                      ]),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Panel(
                      title: 'توزيع المبيعات',
                      icon: Icons.pie_chart_rounded,
                      child: segs.isEmpty
                          ? const EmptyBox('لا توجد مبيعات')
                          : Column(children: [
                              Donut(size: 96, center: compact(segs.fold<double>(0, (s, e) => s + e.value)), sub: 'دج', segs: segs),
                              const SizedBox(height: 6),
                              for (final s in segs.take(4))
                                Row(children: [
                                  Container(width: 8, height: 8, decoration: BoxDecoration(color: s.color, shape: BoxShape.circle)),
                                  const SizedBox(width: 5),
                                  Expanded(child: Text(s.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12))),
                                ]),
                            ]),
                    ),
                  ),
                ]),
                Panel(
                  title: 'إنتاج اليوم حسب المنتج',
                  icon: Icons.view_in_ar_rounded,
                  child: prodBy.isEmpty
                      ? const EmptyBox('لا يوجد إنتاج مسجل اليوم')
                      : Column(children: [
                          for (var i = 0; i < prodBy.length; i++)
                            HBar(
                              str(prodBy[i]['name']),
                              dbl(prodBy[i]['target']) > 0 ? dbl(prodBy[i]['made']) / dbl(prodBy[i]['target']) : 0,
                              segColors[i % segColors.length],
                              dbl(prodBy[i]['target']) > 0 ? '${(dbl(prodBy[i]['made']) / dbl(prodBy[i]['target']) * 100).round()}%' : fmt(dbl(prodBy[i]['made'])),
                            ),
                          if (target > 0) KV('هدف اليوم', '${fmt(dbl(d['prod_today']))} / ${fmt(target)}'),
                        ]),
                ),
                Panel(
                  title: 'المخزون',
                  icon: Icons.inventory_2_rounded,
                  onTap: () => widget.goTab(2),
                  child: Column(children: [
                    KV('المنتجات النهائية', '${fmt(dbl(d['stock_pieces']))} ${t('قطعة')}'),
                    KV('المواد الأولية', '${fmt2(dbl(d['raw_kg']))} ${t('كغ')}'),
                    KV('عناصر تحت الحد الأدنى', fmt(dbl(d['low'])), vColor: dbl(d['low']) > 0 ? C.warning : C.success),
                    if (moves.isNotEmpty) const Divider(),
                    for (final m in moves)
                      KV('${str(m['item'])} • ${movementLabel(str(m['kind']))}', '${dbl(m['qty']) >= 0 ? '+' : ''}${fmt2(dbl(m['qty']))}',
                          vColor: dbl(m['qty']) >= 0 ? C.success : C.error),
                  ]),
                ),
                Panel(
                  title: 'الطلبات القادمة',
                  icon: Icons.assignment_turned_in_rounded,
                  trailing: TextButton(onPressed: () => go(context, EntityPage(entity: ordersEntityFull())), child: Text(t('عرض الكل'))),
                  child: orders.isEmpty
                      ? const EmptyBox('لا توجد طلبات قادمة')
                      : Column(children: [
                          for (final o in orders)
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4),
                              child: Row(children: [
                                Expanded(
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Text('#${str(o['number'])} • ${str(o['customer'])}', style: const TextStyle(fontWeight: FontWeight.w700)),
                                    Text('${str(o['product'])} • ${fmt(dbl(o['qty']))} ${t('قطعة')}${str(o['delivery_date']).isEmpty ? '' : ' • ${showDate(str(o['delivery_date']))}'}',
                                        style: const TextStyle(fontSize: 12, color: C.text2)),
                                  ]),
                                ),
                                Tag(orderStatus(str(o['status'])).label, orderStatus(str(o['status'])).color),
                              ]),
                            ),
                        ]),
                ),
                Panel(
                  title: 'تنبيهات مهمة',
                  icon: Icons.warning_amber_rounded,
                  iconColor: C.error,
                  trailing: TextButton(onPressed: () => go(context, const NotificationsPage()), child: Text(t('عرض الكل'))),
                  child: alerts.isEmpty
                      ? const EmptyBox('لا توجد تنبيهات حالياً')
                      : Column(children: [for (final a in alerts.take(3)) AlertTile(a: a)]),
                ),
                Panel(
                  title: 'إضافة سريعة',
                  icon: Icons.bolt_rounded,
                  child: GridView.count(
                    crossAxisCount: 3,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    childAspectRatio: 0.95,
                    children: [
                      AppTile(icon: 'app_invoice', label: t('إضافة فاتورة'), onTap: () => go(context, const InvoiceForm())),
                      AppTile(icon: 'app_production', label: t('تسجيل إنتاج'), onTap: () => go(context, const ProductionForm())),
                      AppTile(icon: 'app_inventory', label: t('إضافة مخزون'), onTap: () => go(context, const StockEntryPage())),
                      AppTile(icon: 'app_customers', label: t('عميل جديد'), onTap: () => go(context, EntityForm(entity: customersEntity()))),
                      AppTile(icon: 'app_products', label: t('منتج جديد'), onTap: () => go(context, EntityForm(entity: productsEntity()))),
                      AppTile(icon: 'app_expenses', label: t('مصروف جديد'), onTap: () => go(context, EntityForm(entity: transactionEntity()))),
                    ],
                  ),
                ),
              ]),
            ),
          ]);
        },
      ),
    );
  }

  Widget _dot(Color c, String label, int n) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 1),
        child: Row(children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Expanded(child: Text(t(label), style: const TextStyle(fontSize: 12))),
          Text('$n', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
        ]),
      );

  Widget _hero(BuildContext context, double top, int unread) {
    final now = DateTime.now();
    return Container(
      decoration: const BoxDecoration(
        color: C.navy,
        image: DecorationImage(image: AssetImage('assets/images/banner.jpg'), fit: BoxFit.cover, alignment: Alignment.centerRight),
      ),
      child: Container(
        color: tint(C.navy, 0.78),
        padding: EdgeInsets.fromLTRB(12, top + 8, 12, 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            IconButton(icon: const Icon(Icons.menu_rounded, color: Colors.white), onPressed: () => widget.goTab(4)),
            Expanded(
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Image.asset('assets/images/logo_white.png', height: 34),
                const SizedBox(width: 8),
                Flexible(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${AppState.i.company} ERP', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
                    Text(t('نظام إدارة المصنع'), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                  ]),
                ),
              ]),
            ),
            IconButton(
              icon: AppIcon('app_notifications', color: Colors.white, badge: unread),
              onPressed: () => go(context, const NotificationsPage()),
            ),
            IconButton(icon: const Icon(Icons.account_circle_rounded, color: Colors.white, size: 30), onPressed: () => go(context, const SettingsPage())),
          ]),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('مرحباً بك'), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
              Text(t('لوحة التحكم الرئيسية'), style: const TextStyle(color: Colors.white, fontSize: 15)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.calendar_month_rounded, size: 18, color: C.primary),
                  const SizedBox(width: 6),
                  Text(fullDate(now), style: const TextStyle(fontWeight: FontWeight.w700, color: C.navy, fontSize: 13)),
                ]),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
