import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/icons.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import 'entities.dart';
import 'entity.dart';
import 'finance.dart';
import 'inventory.dart';
import 'machines.dart';
import 'notifications.dart';
import 'production.dart';
import 'reports.dart';
import 'sales.dart';
import 'settings.dart';

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    final modules = <List<Object>>[
      ['app_employees', 'الموظفون', 'إدارة الموظفين'],
      ['app_products', 'المنتجات', 'تعريف المنتجات'],
      ['app_suppliers', 'الموردون', 'إدارة الموردين'],
      ['app_customers', 'العملاء', 'إدارة العملاء'],
      ['app_shifts', 'المناوبات', 'الحضور والغياب'],
      ['app_machines', 'الآلات', 'إدارة الآلات'],
      ['app_orders', 'الطلبات', 'الطلبات القادمة'],
      ['app_notes', 'الملاحظات', 'ملاحظات العمل'],
      ['app_expenses', 'المصاريف', 'المعاملات المالية'],
      ['app_reports', 'التقارير', 'تقارير تفصيلية'],
      ['app_raw_materials', 'المواد الأولية', 'إدارة المواد الخام'],
      ['app_maintenance', 'الصيانة', 'الصيانة والقطع'],
      ['app_profit', 'الأرباح', 'الأرباح والتكاليف'],
      ['app_calc', 'الحاسبة', 'الوزن والمواد'],
      ['app_settings', 'الإعدادات', 'إعدادات النظام'],
    ];
    void open(String k) {
      switch (k) {
        case 'app_employees':
          go(context, EntityPage(entity: employeesEntity()));
          break;
        case 'app_products':
          go(context, EntityPage(entity: productsEntity()));
          break;
        case 'app_suppliers':
          go(context, EntityPage(entity: suppliersEntity()));
          break;
        case 'app_customers':
          go(context, EntityPage(entity: customersEntity()));
          break;
        case 'app_shifts':
          go(context, const ShiftsPage());
          break;
        case 'app_machines':
          go(context, const MachinesPage());
          break;
        case 'app_orders':
          go(context, EntityPage(entity: ordersEntityFull()));
          break;
        case 'app_notes':
          go(context, EntityPage(entity: notesEntity()));
          break;
        case 'app_expenses':
          go(context, const TransactionsPage());
          break;
        case 'app_reports':
          go(context, const ReportsPage());
          break;
        case 'app_raw_materials':
          go(context, EntityPage(entity: materialsEntity()));
          break;
        case 'app_maintenance':
          go(context, EntityPage(entity: maintenanceEntity()));
          break;
        case 'app_profit':
          go(context, const ProfitPage());
          break;
        case 'app_calc':
          go(context, const WeightCalcPage());
          break;
        case 'app_settings':
          go(context, const SettingsPage());
          break;
      }
    }

    return Scaffold(
      body: ListView(padding: EdgeInsets.zero, children: [
        Container(
          decoration: const BoxDecoration(
            color: C.navy,
            image: DecorationImage(image: AssetImage('assets/images/banner.jpg'), fit: BoxFit.cover, alignment: Alignment.centerRight),
          ),
          child: Container(
            color: tint(C.navy, 0.8),
            padding: EdgeInsets.fromLTRB(16, top + 14, 16, 16),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t('المزيد'), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                  Text(t('جميع أقسام وإعدادات النظام'), style: const TextStyle(color: Colors.white70, fontSize: 14)),
                ]),
              ),
              Image.asset('assets/images/logo_white.png', height: 38),
              IconButton(
                icon: const AppIcon('app_notifications', color: Colors.white),
                onPressed: () => go(context, const NotificationsPage()),
              ),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Panel(
              title: 'أقسام النظام',
              icon: Icons.grid_view_rounded,
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 0.82,
                children: [
                  for (final m in modules) AppTile(icon: m[0] as String, label: t(m[1] as String), sub: t(m[2] as String), onTap: () => open(m[0] as String)),
                ],
              ),
            ),
            Panel(
              title: 'إجراءات سريعة',
              icon: Icons.bolt_rounded,
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 0.95,
                children: [
                  AppTile(icon: 'app_invoice', label: t('إضافة فاتورة'), onTap: () => go(context, const InvoiceForm())),
                  AppTile(icon: 'app_production', label: t('تسجيل إنتاج'), onTap: () => go(context, const ProductionForm())),
                  AppTile(icon: 'app_inventory', label: t('حركة مخزون'), onTap: () => go(context, const StockEntryPage())),
                  AppTile(icon: 'app_products', label: t('منتج جديد'), onTap: () => go(context, EntityForm(entity: productsEntity()))),
                  AppTile(icon: 'app_customers', label: t('عميل جديد'), onTap: () => go(context, EntityForm(entity: customersEntity()))),
                  AppTile(icon: 'app_expenses', label: t('مصروف جديد'), onTap: () => go(context, EntityForm(entity: transactionEntity()))),
                ],
              ),
            ),
            DataView<Map<String, int>>(
              load: () async {
                Future<int> n(String table) async => (await Db.sum('SELECT COUNT(*) FROM $table')).toInt();
                return {
                  'products': await n('products'),
                  'customers': await n('customers'),
                  'suppliers': await n('suppliers'),
                  'employees': await n('employees'),
                  'machines': await n('machines'),
                };
              },
              builder: (c, s) => Panel(
                title: 'إحصائيات النظام',
                icon: Icons.bar_chart_rounded,
                child: Column(children: [
                  KV('إجمالي المنتجات', '${s['products']}'),
                  KV('إجمالي العملاء', '${s['customers']}'),
                  KV('إجمالي الموردين', '${s['suppliers']}'),
                  KV('إجمالي الموظفين', '${s['employees']}'),
                  KV('إجمالي الآلات', '${s['machines']}'),
                ]),
              ),
            ),
            Panel(
              title: 'تقارير سريعة',
              icon: Icons.description_rounded,
              padding: EdgeInsets.zero,
              child: Column(children: [
                for (final d in reportDefs.take(5))
                  ListTile(
                    dense: true,
                    leading: Icon(d.icon, color: d.color),
                    title: Text(t(d.title), style: const TextStyle(fontWeight: FontWeight.w700)),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => go(context, ReportView(def: d)),
                  ),
              ]),
            ),
            Panel(
              title: 'إعدادات النظام',
              icon: Icons.settings_rounded,
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 0.95,
                children: [
                  AppTile(icon: 'app_settings', label: t('إعدادات عامة'), onTap: () => go(context, const SettingsPage())),
                  AppTile(icon: 'app_language', label: t('اللغة'), onTap: () => go(context, const SettingsPage())),
                  AppTile(icon: 'app_permissions', label: t('الصلاحيات'), onTap: () => go(context, const RolesPage())),
                  AppTile(icon: 'app_backup', label: t('النسخ الاحتياطي'), onTap: () => go(context, const BackupPage())),
                  AppTile(icon: 'app_notifications', label: t('التنبيهات'), onTap: () => go(context, const NotificationsPage())),
                ],
              ),
            ),
            Panel(
              child: Row(children: [
                const Icon(Icons.info_rounded, color: C.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${AppState.i.company} ERP', style: const TextStyle(fontWeight: FontWeight.w800)),
                    Text('${t('قاعدة البيانات: محلية (بدون إنترنت)')}  |  v1.0.0', style: const TextStyle(fontSize: 12, color: C.text2)),
                  ]),
                ),
                Image.asset('assets/images/logo_color.png', height: 40),
              ]),
            ),
          ]),
        ),
      ]),
    );
  }
}
