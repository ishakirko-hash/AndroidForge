/* KHALDI PLAST - v2.14: workers <-> machines link. The shift roster already stores which machine each worker is on;
   this adds: crew card + quick assign on the machine monitor, a "who is on which machine" map with output per worker on the
   workers page, and smart alerts (machine without crew / worker without machine). No schema change. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, S = U.S, X = U.extraActions;
  function T(ar, fr, en) { var l = U.lang(); return l === 'fr' ? fr : l === 'en' ? en : ar; }
  function B(n) { return '<bdi class="num" dir="ltr">' + n + '</bdi>'; }
  function curShift() { var h = new Date().getHours(); return h >= 8 && h < 16 ? 1 : h >= 16 ? 2 : 3; }
  function today() { return K.today(); }
  function wname(id) { var w = K.byId(U.D.workers, id); return w ? w.name : '?'; }
  function mname(id) { var m = K.byId(U.D.machines, id); return m ? m.name : ''; }
  function out(mid, n) { var c = ((U.D.settings.mon || {}).counts || {})[mid + '|' + today() + '|' + n]; return c ? c.n : 0; }
  function crewOf(mid, n) { return K.rosterFor(U.D, today(), n).filter(function (a) { return a.machineId === mid; }); }

  /* alerts for the current shift: only when a roster exists for it (so a factory that never plans is not nagged) */
  U.crewAlerts = function () {
    var D = U.D, n = curShift(), r = K.rosterFor(D, today(), n), ms = U.act(D.machines);
    if (!ms.length || !r.some(function (a) { return a.worked; })) return null;
    var noMachine = r.filter(function (a) { return a.worked && !a.machineId; }).length;
    var noCrew = ms.filter(function (m) { return !r.some(function (a) { return a.worked && a.machineId === m.id; }); }).length;
    return (noMachine || noCrew) ? { noMachine: noMachine, noCrew: noCrew, n: n } : null;
  };

  function chip(a) {
    return '<span class="cw ' + (a.worked ? 'ok' : 'no') + '" data-act="open_worker" data-id="' + a.workerId + '"><i></i>' + esc(wname(a.workerId)) + (a.worked ? '' : ' <small>' + T('غائب', 'absent', 'absent') + '</small>') + '</span>';
  }

  /* ---- machine monitor: crew card ---- */
  function machCard() {
    var q = S.mm || {}, mid = q.m, n = q.shift || curShift(), main = U.$('#main'), chips = main && main.querySelector('.mm-chips');
    if (!chips || !mid) return;
    var old = document.getElementById('crew_card'); if (old) old.remove();
    var cr = crewOf(mid, n), here = cr.filter(function (a) { return a.worked; }), tot = out(mid, n);
    var live = n === curShift(), warn = !here.length;
    var h = '<div class="card crew' + (warn && live ? ' warn' : '') + '" id="crew_card"><div class="cr-h"><span class="cr-i">' + V.icon('users', 18) + '</span><b>' + T('طاقم الآلة', 'Équipe machine', 'Machine crew') + ' · ' + t('shift') + ' ' + n + '</b>' +
      '<button class="btn sm" data-act="crew_edit" data-m="' + mid + '" data-n="' + n + '">' + (cr.length ? T('تعديل', 'Modifier', 'Edit') : T('+ تعيين عمال', '+ Affecter', '+ Assign')) + '</button></div>';
    h += cr.length ? '<div class="cr-w">' + cr.map(chip).join('') + '</div>' : '<div class="cr-e">' + (live ? '⚠️ ' : '') + T('لا يوجد عمال معيّنون لهذه الآلة في هذا الشفت.', 'Aucun ouvrier affecté à cette machine pour ce poste.', 'No workers assigned to this machine for this shift.') + '</div>';
    if (here.length) h += '<div class="cr-s"><div><small>' + T('عدد العمال', 'Ouvriers', 'Workers') + '</small><b>' + B(here.length) + '</b></div><div><small>' + T('إنتاج الشفت', 'Production du poste', 'Shift output') + '</small><b>' + B(K.groupInt(tot)) + '</b></div><div><small>' + T('لكل عامل', 'Par ouvrier', 'Per worker') + '</small><b>' + B(K.groupInt(Math.round(tot / here.length))) + '</b></div></div>';
    h += '</div>';
    chips.insertAdjacentHTML('afterend', h);
  }

  /* ---- workers page: who is on which machine, per shift ---- */
  function workersMap() {
    var main = U.$('#main'); if (!main) return; var rows = main.querySelectorAll('.shrow'); if (!rows.length) return;
    var D = U.D, ms = U.act(D.machines); if (!ms.length) return;
    [].forEach.call(rows, function (row) {
      var b = row.querySelector('[data-act="roster"][data-shift]'); if (!b || row.querySelector('.cmap')) return; var n = parseInt(b.dataset.shift, 10), r = K.rosterFor(D, today(), n);
      if (!r.length) return;
      var free = r.filter(function (a) { return a.worked && !a.machineId; }), h = '<div class="cmap">';
      ms.forEach(function (m) {
        var cr = r.filter(function (a) { return a.machineId === m.id; }), w = cr.filter(function (a) { return a.worked; }).length, o = out(m.id, n);
        h += '<div class="cm-r' + (w ? '' : ' empty') + '" data-act="crew_open" data-m="' + m.id + '" data-n="' + n + '"><b>' + esc(m.name) + '</b><div class="cm-c">' + (cr.length ? cr.map(chip).join('') : '<small>' + T('بلا عمال', 'sans ouvriers', 'no crew') + '</small>') + '</div>' +
          '<span class="cm-o">' + (o ? B(K.groupInt(o)) + ' <small>' + t('mm_crate') + (w ? ' · ' + B(K.groupInt(Math.round(o / w))) + '/' + T('عامل', 'ouv.', 'wkr') : '') + '</small>' : '<small>—</small>') + '</span></div>';
      });
      if (free.length) h += '<div class="cm-free">⚠️ ' + T('عمال بلا آلة: ', 'Sans machine : ', 'No machine: ') + free.map(function (a) { return esc(wname(a.workerId)); }).join('، ') + '</div>';
      row.insertAdjacentHTML('beforeend', h + '</div>');
    });
  }

  var prev = U.afterRender;
  U.afterRender = function (R) { if (prev) prev(R); try { if (R === 'machmon') machCard(); if (R === 'workers') workersMap(); } catch (e) { } };

  X.crew_open = function (el) { S.mm = S.mm || {}; S.mm.m = el.dataset.m; S.mm.shift = parseInt(el.dataset.n, 10) || 1; U.go('machmon'); };

  /* ---- quick assign form ---- */
  X.crew_edit = function (el) {
    var mid = el.dataset.m, n = parseInt(el.dataset.n, 10) || curShift(), D = U.D, day = today(), cur = K.rosterFor(D, day, n);
    var ws = U.act(D.workers).filter(function (w) { return w.active || cur.some(function (a) { return a.workerId === w.id; }); });
    if (!ws.length) { U.toast(t('add_workers_first'), 'bad'); return; }
    var h = '<form id="f" novalidate><h3>' + T('تعيين العمال', 'Affecter les ouvriers', 'Assign workers') + ' · ' + esc(mname(mid)) + '</h3><div class="muted">' + t('shift') + ' ' + n + ' · ' + K.fmtDate(day) + '</div><div class="crl">';
    ws.forEach(function (w) {
      var a = cur.filter(function (x) { return x.workerId === w.id; })[0], on = a && a.worked && a.machineId === mid, other = a && a.machineId && a.machineId !== mid;
      h += '<label class="crw"><input type="checkbox" name="w_' + w.id + '"' + (on ? ' checked' : '') + '><span><b>' + esc(w.name) + '</b>' + (w.role ? ' <small>' + esc(w.role) + '</small>' : '') + (other ? '<em>' + T('حالياً على ', 'Actuellement sur ', 'Now on ') + esc(mname(a.machineId)) + '</em>' : '') + '</span></label>';
    });
    h += '</div><div id="ferr" class="ferr"></div><div class="btns"><button type="button" class="btn ghost" data-act="close">' + t('cancel') + '</button><button type="submit" class="btn primary">' + t('save') + '</button></div></form>';
    U.showModal(h);
    U.$('#f').addEventListener('submit', function (e) {
      e.preventDefault(); var f = U.$('#f'), entries = [], seen = {};
      ws.forEach(function (w) {
        var a = cur.filter(function (x) { return x.workerId === w.id; })[0], chk = f.elements['w_' + w.id].checked;
        if (chk) entries.push({ workerId: w.id, worked: true, machineId: mid });
        else if (a) entries.push({ workerId: w.id, worked: a.worked, machineId: a.machineId === mid ? null : a.machineId });
        seen[w.id] = 1;
      });
      cur.forEach(function (a) { if (!seen[a.workerId]) entries.push({ workerId: a.workerId, worked: a.worked, machineId: a.machineId }); });
      try { U.commit(function (d) { K.setShiftRoster(d, { date: day, shift: n, entries: entries }); }); U.closeModal(); U.render(true); U.toast(t('saved_ok'), 'ok'); } catch (err) { U.$('#ferr').textContent = U.errMsg(err); }
    });
  };
})();
