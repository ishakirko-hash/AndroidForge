/* KHALDI PLAST v2.2 - customers & prospects (CRM) and the purchases table. Pure UI over core3.js; every number comes from the real records. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, F = U.forms, X = U.extraActions, S = U.S;
  function B(v) { return '<bdi class="num" dir="ltr">' + v + '</bdi>'; }
  function today() { return K.today(); }
  function chev() { return V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 20); }
  function csvFile(name, rows) { U.saveFile(name, 'text/csv', '﻿' + rows.map(function (r) { return r.map(U.csvEscape).join(','); }).join('\r\n')); }
  function printNow(name) { setTimeout(function () { if (U.AND && U.AND.printPage) U.AND.printPage(name); else window.print(); }, 150); }
  function share(txt) {
    if (U.AND && U.AND.shareText) U.AND.shareText(txt);
    else if (navigator.share) navigator.share({ text: txt }).catch(function () {});
    else if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { U.toast(t('copied'), 'ok'); });
  }
  function stat(label, val, cls) { return '<div><small>' + esc(label) + '</small><b class="' + (cls || '') + '">' + val + '</b></div>'; }
  var STAGE_TONE = { 'new': '', contacted: '', quoted: 'amber', negotiation: 'amber', won: 'green', lost: 'gray' };
  var SEG_TONE = { vip: 'green', active: '', 'new': '', dormant: 'amber', risk: 'red', prospect: 'gray' };
  function stageBadge(s) { return U.badge(t('crm_st_' + s), STAGE_TONE[s]); }
  function segBadge(s) { return U.badge(t('crm_sg_' + s), SEG_TONE[s]); }
  function followBadge(l) {
    var st = K.leadState(l, today()); if (st === 'closed' || st === 'none' || st === 'void') return '';
    return U.badge(st === 'overdue' ? t('crm_fu_overdue', { n: Math.abs(daysTo(l.nextFollow)) }) : st === 'today' ? t('crm_fu_today') : t('crm_fu_on') + ' ' + K.fmtDate(l.nextFollow), st === 'overdue' ? 'red' : st === 'today' ? 'amber' : '');
  }
  function daysTo(dt) { return Math.round((Date.UTC(+dt.slice(0, 4), +dt.slice(5, 7) - 1, +dt.slice(8, 10)) - Date.UTC(+today().slice(0, 4), +today().slice(5, 7) - 1, +today().slice(8, 10))) / 86400000); }
  function srcLabel(s) { return t('crm_src_' + s); }

  /* ---------- live duplicate hint (also used by the plain "new customer" form) ---------- */
  U.dupHint = function (v, excludeId) {
    try {
      var dup = K.findDuplicates(U.D, { name: v.name || '', phone: v.phone || '', excludeId: excludeId });
      if (!dup.length) return '';
      return '<div class="crm-dup">' + V.icon('alert', 18) + '<div>' + dup.slice(0, 3).map(function (x) {
        return '<div><b>' + esc(x.rec.name) + '</b>' + (x.rec.phone ? ' · <bdi class="num">' + esc(x.rec.phone) + '</bdi>' : '') + ' <small>(' + esc(t('crm_dup_' + x.kind)) + ' · ' + esc(t('crm_dup_r_' + x.reason)) + ')</small></div>';
      }).join('') + (dup.some(function (x) { return x.strong; }) ? '<small class="crm-dup-n">' + esc(t('crm_dup_hint')) + '</small>' : '') + '</div></div>';
    } catch (e) { return ''; }
  };

  /* ================= CRM screen ================= */
  W.crm = function () {
    var D = U.D, td = today(), tab = S.crmTab || 'leads', sm = K.leadsSummary(D, td), prof = K.customerProfiles(D, td), h = '';
    var seg = { vip: 0, active: 0, 'new': 0, dormant: 0, risk: 0, prospect: 0 }; prof.forEach(function (r) { seg[r.segment]++; });
    h += '<div class="kpis4"><div class="kpi bg-blue"><div class="kt"><span class="ki">' + V.icon('users', 22) + '</span><span class="kl">' + esc(t('tile_customers')) + '</span></div><div class="kv2">' + B(prof.length) + '</div><div class="kn"><span>' + esc(t('crm_vip_n', { n: seg.vip })) + '</span></div></div>' +
      '<div class="kpi bg-amber"><div class="kt"><span class="ki">' + V.icon('phone', 22) + '</span><span class="kl">' + esc(t('crm_open_leads')) + '</span></div><div class="kv2">' + B(sm.open) + '</div><div class="kn"><span>' + esc(t('crm_followups_due', { n: sm.overdue + sm.dueToday })) + '</span></div></div></div>';
    h += '<div class="btns"><button class="btn primary" data-act="lead_new">' + V.icon('plus', 18) + ' ' + t('crm_new_lead') + '</button><button class="btn" data-act="new_party" data-kind="customer">' + V.icon('user', 18) + ' ' + t('new_customer') + '</button></div>';
    h += U.seg([['leads', t('crm_tab_leads')], ['customers', t('crm_tab_customers')], ['funnel', t('crm_tab_funnel')]], tab, 'crm_tab');
    h += '<div class="filterrow">' + U.searchbox('crmq', S.crmQ || '', t('search')).replace('id="crmq"', 'id="crmq" data-bind="crmQ"') + '</div>';
    var q = (S.crmQ || '').trim().toLowerCase();
    if (tab === 'leads') return h + leadsTab(sm, q);
    if (tab === 'customers') return h + customersTab(prof, seg, q);
    return h + funnelTab(sm);
  };
  X.crm_tab = function (el) { S.crmTab = el.dataset.id; U.render(true); };

  function leadsTab(sm, q) {
    var D = U.D, td = today(), f = S.leadF || 'open', all = (D.leads || []).filter(function (l) { return !l.voided; });
    var cnt = { open: sm.open, 'new': sm.stages['new'].n, contacted: sm.stages.contacted.n, quoted: sm.stages.quoted.n, negotiation: sm.stages.negotiation.n, won: sm.stages.won.n, lost: sm.stages.lost.n, all: all.length };
    var h = U.chips([['open', t('crm_f_open') + ' (' + cnt.open + ')'], ['new', t('crm_st_new') + ' (' + cnt['new'] + ')'], ['contacted', t('crm_st_contacted') + ' (' + cnt.contacted + ')'], ['quoted', t('crm_st_quoted') + ' (' + cnt.quoted + ')'], ['negotiation', t('crm_st_negotiation') + ' (' + cnt.negotiation + ')'], ['won', t('crm_st_won') + ' (' + cnt.won + ')'], ['lost', t('crm_st_lost') + ' (' + cnt.lost + ')'], ['all', t('all')]], f, 'lead_f');
    var list = all.filter(function (l) { return f === 'all' || (f === 'open' ? K.OPEN_STAGES.indexOf(l.stage) >= 0 : l.stage === f); }).filter(function (l) { return !q || (l.name + ' ' + l.phone + ' ' + l.address + ' ' + l.notes).toLowerCase().indexOf(q) >= 0; });
    var rank = { overdue: 0, today: 1, soon: 2, ok: 3, none: 4, closed: 5 };
    list.sort(function (a, b) { var ra = rank[K.leadState(a, td)], rb = rank[K.leadState(b, td)]; return ra - rb || ((a.nextFollow || '9999') < (b.nextFollow || '9999') ? -1 : 1); });
    if (!list.length) return h + '<div class="card">' + U.empty(all.length ? t('no_results') : t('crm_no_leads'), 'phone') + '</div>';
    return h + '<div class="card">' + U.limit(list, 'leads', 40).map(function (l) {
      var p = l.productId ? K.byId(D.products, l.productId) : null;
      return '<div class="row tap" data-act="goto" data-id="lead" data-arg="' + l.id + '"><div class="ibox ' + (K.leadState(l, td) === 'overdue' ? 'red' : '') + '">' + V.icon('phone', 22) + '</div><div class="main"><div class="t">' + esc(l.name) + '</div>' +
        '<div class="s">' + (l.phone ? B(esc(l.phone)) + ' · ' : '') + esc(srcLabel(l.source)) + (p ? ' · ' + esc(p.name) + (l.qty ? ' × ' + B(K.fmtQty(l.qty)) : '') : '') + '</div><div style="margin-top:3px">' + stageBadge(l.stage) + ' ' + followBadge(l) + '</div></div>' +
        '<div class="r">' + (l.value ? U.money(l.value) : '') + '</div></div>';
    }).join('') + '</div>' + U.moreBtn('leads', 40, list.length);
  }
  X.lead_f = function (el) { S.leadF = el.dataset.id; U.render(true); };

  function customersTab(prof, seg, q) {
    var f = S.custSeg || 'all', due = prof.filter(function (r) { return r.reorderDue; }).length;
    var h = U.chips([['all', t('all') + ' (' + prof.length + ')'], ['vip', t('crm_sg_vip') + ' (' + seg.vip + ')'], ['active', t('crm_sg_active') + ' (' + seg.active + ')'], ['new', t('crm_sg_new') + ' (' + seg['new'] + ')'], ['dormant', t('crm_sg_dormant') + ' (' + seg.dormant + ')'], ['risk', t('crm_sg_risk') + ' (' + seg.risk + ')'], ['prospect', t('crm_sg_prospect') + ' (' + seg.prospect + ')'], ['reorder', t('crm_reorder') + ' (' + due + ')']], f, 'cust_seg');
    h += '<div class="muted" style="margin:0 2px 8px">' + esc(t('crm_seg_help')) + '</div>';
    var list = prof.filter(function (r) { return f === 'all' || (f === 'reorder' ? r.reorderDue : r.segment === f); }).filter(function (r) { return !q || (r.customer.name + ' ' + (r.customer.phone || '') + ' ' + (r.customer.address || '')).toLowerCase().indexOf(q) >= 0; })
      .sort(function (a, b) { return b.rev365 - a.rev365 || (a.customer.name < b.customer.name ? -1 : 1); });
    if (!list.length) return h + '<div class="card">' + U.empty(t('no_results'), 'users') + '</div>';
    return h + '<div class="card">' + U.limit(list, 'crmc', 40).map(function (r) {
      var c = r.customer;
      return '<div class="row tap" data-act="party" data-kind="customer" data-id="' + c.id + '"><div class="ibox ' + (r.segment === 'risk' ? 'red' : r.segment === 'vip' ? 'green' : '') + '">' + V.icon('user', 22) + '</div><div class="main"><div class="t">' + esc(c.name) + '</div>' +
        '<div class="s">' + (r.count ? esc(t('crm_orders_n', { n: r.count })) + ' · ' + esc(t('crm_last_order')) + ': ' + (r.daysSince === 0 ? esc(t('p_today')) : esc(t('crm_days_ago', { n: r.daysSince }))) : esc(t('crm_never_bought'))) + '</div>' +
        '<div style="margin-top:3px">' + segBadge(r.segment) + (r.reorderDue ? ' ' + U.badge(t('crm_reorder_due'), 'amber') : '') + (r.balance > 0 ? ' ' + U.badge(t('balance') + ' ' + K.fmtMoney(r.balance), 'red') : '') + '</div></div><div class="r">' + (r.rev365 ? U.money(r.rev365) : '') + '</div></div>';
    }).join('') + '</div>' + U.moreBtn('crmc', 40, list.length);
  }
  X.cust_seg = function (el) { S.custSeg = el.dataset.id; U.render(true); };

  function funnelTab(sm) {
    var h = '', stages = ['new', 'contacted', 'quoted', 'negotiation', 'won', 'lost'], mx = Math.max.apply(null, stages.map(function (s) { return sm.stages[s].n; }).concat([1]));
    h += '<div class="statgrid">' + stat(t('crm_pipeline'), U.money(sm.pipeline)) + stat(t('crm_weighted'), U.money(sm.weighted)) + stat(t('crm_conversion'), sm.conversion == null ? '—' : B(sm.conversion + '%')) + '</div>';
    h += '<div class="card crm-funnel">' + stages.map(function (s) {
      var x = sm.stages[s];
      return '<div class="crm-fr"><span class="crm-fl">' + esc(t('crm_st_' + s)) + '</span><span class="crm-fb"><i class="st-' + s + '" style="width:' + Math.round(x.n * 100 / mx) + '%"></i></span><b>' + B(x.n) + '</b></div>';
    }).join('') + '</div>';
    h += '<div class="card">' + U.kv('calendar', t('crm_avg_days'), sm.avgDaysToWin == null ? '—' : B(sm.avgDaysToWin) + ' ' + esc(t('days'))) + U.kv('wallet', t('crm_won_value'), U.money(sm.wonValue)) + U.kv('alert', t('crm_followups_due', { n: sm.overdue + sm.dueToday }), '') + '</div>';
    var srcs = K.LEAD_SOURCES.filter(function (s) { return sm.bySource[s].n > 0; });
    if (srcs.length) {
      h += U.sec(t('crm_by_source')) + '<div class="tablewrap"><table class="rpt-tb"><thead><tr><th>' + esc(t('crm_source')) + '</th><th class="n">' + esc(t('crm_leads')) + '</th><th class="n">' + esc(t('crm_st_won')) + '</th><th class="n">' + esc(t('crm_st_lost')) + '</th></tr></thead><tbody>' +
        srcs.map(function (s) { var b = sm.bySource[s]; return '<tr><td>' + esc(srcLabel(s)) + '</td><td class="n">' + B(b.n) + '</td><td class="n">' + B(b.won) + '</td><td class="n">' + B(b.lost) + '</td></tr>'; }).join('') + '</tbody></table></div>';
    }
    var reasons = {}; (U.D.leads || []).forEach(function (l) { if (!l.voided && l.stage === 'lost' && l.lostReason) reasons[l.lostReason] = (reasons[l.lostReason] || 0) + 1; });
    var rk = Object.keys(reasons).sort(function (a, b) { return reasons[b] - reasons[a]; }).slice(0, 5);
    if (rk.length) h += U.sec(t('crm_lost_reasons')) + '<div class="card">' + rk.map(function (r) { return '<div class="rpt-kv"><span>' + esc(r) + '</span><b>' + B(reasons[r]) + '</b></div>'; }).join('') + '</div>';
    if (!sm.total) h += '<div class="card">' + U.empty(t('crm_no_leads'), 'phone') + '</div>';
    return h;
  }

  /* ================= lead details ================= */
  W.lead = function (id) {
    var D = U.D, l = K.byId(D.leads || [], id); if (!l || l.voided) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    var p = l.productId ? K.byId(D.products, l.productId) : null, cust = l.customerId ? K.byId(D.customers, l.customerId) : null, open = K.OPEN_STAGES.indexOf(l.stage) >= 0, h = '';
    h += '<div class="wk-head"><div class="ibox ' + (l.stage === 'won' ? 'green' : l.stage === 'lost' ? 'red' : '') + '">' + V.icon('phone', 28) + '</div><div style="flex:1;min-width:0"><div class="big">' + esc(l.name) + '</div><div class="muted">' + stageBadge(l.stage) + ' ' + followBadge(l) + '</div></div></div>';
    h += '<div class="card">' + U.kv('phone', t('phone'), l.phone ? '<a href="tel:' + esc(l.phone.replace(/[^\d+]/g, '')) + '">' + B(esc(l.phone)) + '</a>' : '—') + U.kv('pin', t('place_address'), esc(l.address || '—')) + U.kv('tag', t('crm_source'), esc(srcLabel(l.source))) +
      (l.activity ? U.kv('factory', t('activity_customer'), esc(l.activity)) : '') + (p ? U.kv('box', t('crm_interest'), esc(p.name) + (l.qty ? ' × ' + B(K.fmtQty(l.qty)) : '')) : '') + (l.value ? U.kv('wallet', t('crm_value'), U.money(l.value)) : '') +
      U.kv('calendar', t('crm_created'), U.dt(l.created)) + (l.nextFollow ? U.kv('clock', t('crm_next_follow'), U.dt(l.nextFollow)) : '') + (l.lostReason ? U.kv('alert', t('crm_lost_reason'), esc(l.lostReason)) : '') + (l.notes ? U.kv('note', t('notes'), esc(l.notes)) : '') +
      (cust ? U.kv('user', t('customer'), '<a data-act="party" data-kind="customer" data-id="' + cust.id + '">' + esc(cust.name) + '</a>') : '') + '</div>';
    if (open) {
      h += U.sec(t('crm_move_to')) + U.chips(['new', 'contacted', 'quoted', 'negotiation'].map(function (s) { return [s, t('crm_st_' + s)]; }), l.stage, 'lead_stage');
      h += '<div class="btns"><button class="btn primary" data-act="lead_note" data-id="' + l.id + '">' + V.icon('chat', 18) + ' ' + t('crm_log_contact') + '</button><button class="btn" data-act="lead_quote" data-id="' + l.id + '">' + V.icon('note', 18) + ' ' + t('p_new_quote') + '</button></div>';
      h += '<div class="btns"><button class="btn success" data-act="lead_won" data-id="' + l.id + '">' + V.icon('check', 18) + ' ' + t('crm_convert') + '</button><button class="btn danger-o" data-act="lead_lost" data-id="' + l.id + '">' + t('crm_mark_lost') + '</button></div>';
    } else if (l.stage === 'lost') h += '<div class="btns"><button class="btn" data-act="lead_reopen" data-id="' + l.id + '">' + t('crm_reopen') + '</button></div>';
    h += '<div class="btns"><button class="btn ghost" data-act="lead_edit" data-id="' + l.id + '">' + V.icon('edit', 18) + ' ' + t('edit') + '</button><button class="btn ghost" data-act="lead_void" data-id="' + l.id + '">' + t('crm_delete') + '</button></div>';
    h += U.sec(t('crm_history')) + '<div class="card">' + l.log.slice().reverse().map(function (g) {
      var txt = g.type === 'created' ? t('crm_log_created') : g.type === 'stage' ? t('crm_log_stage') + ': ' + t('crm_st_' + g.text.split(':')[0]) + (g.text.indexOf(':') > 0 ? ' (' + esc(g.text.slice(g.text.indexOf(':') + 1).trim()) + ')' : '') : esc(g.text);
      return '<div class="row"><div class="ibox">' + V.icon(g.type === 'note' ? 'chat' : g.type === 'stage' ? 'bars' : 'plus', 20) + '</div><div class="main"><div class="t" style="font-weight:600">' + txt + '</div><div class="s">' + U.dt(g.date) + '</div></div></div>';
    }).join('') + '</div>';
    return h;
  };
  X.lead_stage = function (el) { var id = U.arg, s = el.dataset.id; U.commit(function (d) { K.setLeadStage(d, id, s, { date: today() }); }); U.toast(t('saved_ok'), 'ok'); U.render(true); };
  X.lead_void = function (el) { var id = el.dataset.id; U.confirmBox(t('crm_delete'), t('crm_delete_q'), t('crm_delete'), function () { U.commit(function (d) { K.voidLead(d, id); }); U.toast(t('saved_ok'), 'ok'); U.back(); }, true); };
  X.lead_reopen = function (el) { var id = el.dataset.id; U.commit(function (d) { K.setLeadStage(d, id, 'contacted', { date: today() }); }); U.toast(t('saved_ok'), 'ok'); U.render(true); };
  X.lead_note = function (el) {
    var id = el.dataset.id;
    U.openForm({ title: t('crm_log_contact'), submit: t('save'), fields: [{ name: 'date', label: t('date'), type: 'date', value: today() }, { name: 'text', label: t('crm_what_said'), type: 'textarea' }, { name: 'next', label: t('crm_next_follow'), type: 'date', optional: true, value: K.addDays(today(), 3) }],
      onSubmit: function (v) { U.commit(function (d) { K.addLeadNote(d, id, { date: v.date, text: v.text, nextFollow: v.next }); }); U.closeModal(); U.toast(t('saved_ok'), 'ok'); U.render(true); } });
  };
  X.lead_lost = function (el) {
    var id = el.dataset.id;
    U.openForm({ title: t('crm_mark_lost'), submit: t('crm_mark_lost'), danger: true, fields: [{ name: 'reason', label: t('crm_lost_reason'), type: 'select', options: ['price', 'competitor', 'no_answer', 'not_needed', 'other'].map(function (r) { return { v: r, l: t('crm_lr_' + r) }; }) }, { name: 'more', label: t('notes'), type: 'text', optional: true }],
      onSubmit: function (v) { U.commit(function (d) { K.setLeadStage(d, id, 'lost', { date: today(), reason: t('crm_lr_' + v.reason) + (v.more ? ' - ' + v.more : '') }); }); U.closeModal(); U.toast(t('saved_ok'), 'ok'); U.render(true); } });
  };
  X.lead_won = function (el) {
    var id = el.dataset.id, l = K.byId(U.D.leads, id); if (!l) return;
    U.confirmBox(t('crm_convert'), t('crm_convert_q', { name: l.name }), t('crm_convert'), function () {
      var cid = null, linked = false; U.commit(function (d) { var r = K.convertLead(d, id, { date: today() }); cid = r.customer.id; linked = r.linked; });
      U.toast(t(linked ? 'crm_linked' : 'crm_converted'), 'ok'); U.render(true);
    });
  };
  X.lead_quote = function (el) {
    var id = el.dataset.id, l = K.byId(U.D.leads, id); if (!l || !F.quote) return;
    F.quote(null, { customerId: l.customerId || '', customerName: l.customerId ? '' : l.name, productId: l.productId, qty: l.qty, onSaved: function () { U.commit(function (d) { var x = K.byId(d.leads, id); if (x && K.OPEN_STAGES.indexOf(x.stage) >= 0 && x.stage !== 'negotiation') K.setLeadStage(d, id, 'quoted', { date: today() }); }); } });
  };

  /* ---------- lead form ---------- */
  function prodOptions() { return [{ v: '', l: '—' }].concat(U.act(U.D.products).map(function (p) { return { v: p.id, l: p.name }; })); }
  F.lead = function (id) {
    var D = U.D, l = id ? K.byId(D.leads, id) : null, g = function (k) { return l ? (l[k] == null ? '' : l[k]) : ''; };
    U.openForm({
      title: l ? t('edit') : t('crm_new_lead'), submit: t('save'),
      fields: [{ name: 'name', label: t('name'), type: 'text', value: g('name') }, { name: 'phone', label: t('phone'), type: 'text', optional: true, value: g('phone') },
        { name: 'source', label: t('crm_source'), type: 'select', value: l ? l.source : 'visit', options: K.LEAD_SOURCES.map(function (s) { return { v: s, l: srcLabel(s) }; }) },
        { name: 'product', label: t('crm_interest'), type: 'select', value: g('productId'), options: prodOptions() },
        { name: 'qty', label: t('crm_qty'), type: 'qty', optional: true, value: l && l.qty ? l.qty : '' }, { name: 'value', label: t('crm_value'), type: 'money', optional: true, value: l && l.value ? U.forInput(l.value) : '' },
        { name: 'next', label: t('crm_next_follow'), type: 'date', optional: true, value: l ? l.nextFollow : K.addDays(today(), 2) },
        { name: 'address', label: t('place_address'), type: 'text', optional: true, value: g('address') }, { name: 'activity', label: t('activity_customer'), type: 'text', optional: true, value: g('activity') },
        { name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: g('notes') }].concat(l ? [] : [{ name: 'force', label: t('crm_force'), type: 'check' }]),
      calc: function (v) { return U.dupHint(v, id); },
      onSubmit: function (v) {
        var o = { name: v.name, phone: v.phone, source: v.source, productId: v.product, qty: U.parseQ(v.qty, false, false) || 0, value: U.parseM(v.value, false) || 0, nextFollow: v.next, address: v.address, activity: v.activity, notes: v.notes }, nid = null;
        if (!l && !v.force) { var dup = K.findDuplicates(U.D, o).filter(function (x) { return x.strong; }); if (dup.length) throw K.E('dup_party', { name: dup[0].rec.name }); }
        U.commit(function (d) { if (l) K.editLead(d, l.id, o); else nid = K.addLead(d, o).id; });
        U.closeModal(); U.toast(t('saved_ok'), 'ok'); if (nid) { S.crmTab = 'leads'; U.go('lead', nid); } else U.render(true);
      }
    });
  };
  X.lead_new = function () { F.lead(); };
  X.lead_new_q = function () { U.closeModal(); F.lead(); };
  X.lead_edit = function (el) { F.lead(el.dataset.id); };

  /* ================= purchases table ================= */
  var PF = function () { return S.ptF || (S.ptF = { range: 'month', supplier: '', material: '', void: false, from: '', to: '' }); };
  function ptRange(f) {
    var td = today(), ym = td.slice(0, 7);
    if (f.range === 'month') return { from: ym + '-01', to: K.monthRange(ym).to };
    if (f.range === 'last') { var pm = K.addMonths(ym, -1); return { from: pm + '-01', to: K.monthRange(pm).to }; }
    if (f.range === '90') return { from: K.addDays(td, -89), to: td };
    if (f.range === 'year') return { from: td.slice(0, 4) + '-01-01', to: td.slice(0, 4) + '-12-31' };
    if (f.range === 'custom') return { from: f.from || '', to: f.to || '' };
    return { from: '', to: '' };
  }
  function ptData() { var f = PF(), r = ptRange(f); return K.purchaseTable(U.D, { from: r.from, to: r.to, supplierId: f.supplier, materialId: f.material, includeVoid: f.void }); }
  W.purchtable = function () {
    var D = U.D, f = PF(), r = ptRange(f), pt = ptData(), tt = pt.totals, h = '';
    h += U.chips([['month', t('this_month')], ['last', t('pt_last_month')], ['90', t('pt_90')], ['year', t('pt_year')], ['all', t('p_all')], ['custom', t('pt_custom')]], f.range, 'pt_range');
    if (f.range === 'custom') h += '<div class="datebar noprint"><label>' + esc(t('from')) + '</label><input type="date" id="ptFrom" value="' + esc(f.from) + '"><label>' + esc(t('to')) + '</label><input type="date" id="ptTo" value="' + esc(f.to) + '"></div>';
    h += '<div class="filterrow noprint"><select id="ptSup"><option value="">' + esc(t('pt_all_suppliers')) + '</option>' + D.suppliers.map(function (s) { return '<option value="' + s.id + '"' + (f.supplier === s.id ? ' selected' : '') + '>' + esc(s.name) + '</option>'; }).join('') + '</select>' +
      '<select id="ptMat"><option value="">' + esc(t('pt_all_materials')) + '</option>' + D.materials.map(function (m) { return '<option value="' + m.id + '"' + (f.material === m.id ? ' selected' : '') + '>' + esc(m.name) + '</option>'; }).join('') + '</select></div>';
    h += '<label class="chk noprint" style="margin:0 2px 8px"><input type="checkbox" id="ptVoid"' + (f.void ? ' checked' : '') + '> ' + esc(t('pt_show_void')) + '</label>';
    h += '<div class="statgrid">' + stat(t('total'), U.money(tt.total)) + stat(t('paid'), U.money(tt.paid), 'green') + stat(t('remaining'), U.money(tt.remaining), tt.remaining > 0 ? 'red' : '') + '</div>';
    h += '<div class="btns noprint"><button class="btn" data-act="pt_print">' + V.icon('print', 18) + ' ' + t('p_print') + '</button><button class="btn" data-act="pt_csv">' + V.icon('download', 18) + ' CSV</button><button class="btn primary" data-act="new_purchase">' + V.icon('plus', 18) + ' ' + t('new_purchase') + '</button></div>';
    if (pt.priceAlerts.length) h += '<div class="card crm-alert">' + pt.priceAlerts.slice(0, 3).map(function (m) { return '<div class="row"><div class="ibox amber">' + V.icon('truck', 20) + '</div><div class="main"><div class="t" style="font-weight:600">' + esc(t('pt_price_up', { name: m.material, pct: m.change })) + '</div><div class="s">' + esc(t('pt_last')) + ' ' + K.fmtMoney(m.last) + ' · ' + esc(t('pt_avg')) + ' ' + K.fmtMoney(m.avg) + '</div></div></div>'; }).join('') + '</div>';
    if (!pt.rows.length) return h + '<div class="card">' + U.empty(t('pt_none'), 'truck') + '</div>';
    h += '<div class="rpt-only rpt-h"><img src="img/logo_full.png" alt="KHALDI PLAST"><div class="rpt-t"><b>' + esc(t('tile_purchtable')) + '</b><span>' + (r.from ? U.dt(r.from) : '…') + ' → ' + (r.to ? U.dt(r.to) : '…') + '</span></div></div>';
    h += '<div class="tablewrap"><table class="rpt-tb pt-tb"><thead><tr><th>' + esc(t('date')) + '</th><th>' + esc(t('supplier')) + '</th><th>' + esc(t('pt_material')) + '</th><th class="n">' + esc(t('quantity')) + '</th><th class="n">' + esc(t('pt_unit_price')) + '</th><th class="n">' + esc(t('total')) + '</th><th class="n">' + esc(t('paid')) + '</th><th class="n">' + esc(t('remaining')) + '</th></tr></thead><tbody>' +
      U.limit(pt.rows, 'pt', 60).map(function (x) {
        return '<tr class="' + (x.voided ? 'pt-void' : 'tap') + '"' + (x.voided ? '' : ' data-act="pt_row" data-id="' + x.id + '"') + '><td>' + U.dt(x.date) + '</td><td>' + esc(x.supplier) + '</td><td>' + esc(x.material) + '</td><td class="n">' + B(K.fmtQty(x.qty)) + ' <small>' + esc(x.unit) + '</small></td><td class="n">' + B(K.fmtMoney(x.unitCost)) + '</td><td class="n">' + B(K.fmtMoney(x.total)) + '</td><td class="n">' + B(K.fmtMoney(x.paid)) + '</td><td class="n' + (x.remaining > 0 ? ' neg' : '') + '">' + (x.voided ? esc(t('voided')) : B(K.fmtMoney(x.remaining))) + '</td></tr>';
      }).join('') + '</tbody><tfoot><tr><td colspan="3"><b>' + esc(t('total')) + ' (' + B(tt.count) + ')</b></td><td class="n"><b>' + B(K.fmtQty(tt.qty)) + '</b></td><td></td><td class="n"><b>' + B(K.fmtMoney(tt.total)) + '</b></td><td class="n"><b>' + B(K.fmtMoney(tt.paid)) + '</b></td><td class="n"><b>' + B(K.fmtMoney(tt.remaining)) + '</b></td></tr></tfoot></table></div>' + '<div class="noprint">' + U.moreBtn('pt', 60, pt.rows.length) + '</div>';
    h += U.sec(t('pt_by_material')) + '<div class="tablewrap"><table class="rpt-tb"><thead><tr><th>' + esc(t('pt_material')) + '</th><th class="n">' + esc(t('quantity')) + '</th><th class="n">' + esc(t('pt_avg')) + '</th><th class="n">' + esc(t('pt_last')) + '</th><th class="n">%</th><th class="n">' + esc(t('total')) + '</th></tr></thead><tbody>' +
      pt.byMaterial.map(function (m) { return '<tr><td>' + esc(m.material) + '</td><td class="n">' + B(K.fmtQty(m.qty)) + '</td><td class="n">' + B(K.fmtMoney(m.avg)) + '</td><td class="n">' + B(K.fmtMoney(m.last)) + '</td><td class="n ' + (m.change > 0 ? 'neg' : m.change < 0 ? 'pos' : '') + '">' + (m.change == null ? '—' : B((m.change > 0 ? '+' : '') + m.change + '%')) + '</td><td class="n">' + B(K.fmtMoney(m.total)) + '</td></tr>'; }).join('') + '</tbody></table></div>';
    h += U.sec(t('pt_by_supplier')) + '<div class="tablewrap"><table class="rpt-tb"><thead><tr><th>' + esc(t('supplier')) + '</th><th class="n">#</th><th class="n">' + esc(t('total')) + '</th><th class="n">' + esc(t('paid')) + '</th><th class="n">' + esc(t('remaining')) + '</th></tr></thead><tbody>' +
      pt.bySupplier.map(function (s) { return '<tr><td>' + esc(s.supplier) + '</td><td class="n">' + B(s.count) + '</td><td class="n">' + B(K.fmtMoney(s.total)) + '</td><td class="n">' + B(K.fmtMoney(s.paid)) + '</td><td class="n' + (s.remaining > 0 ? ' neg' : '') + '">' + B(K.fmtMoney(s.remaining)) + '</td></tr>'; }).join('') + '</tbody></table></div>';
    return h;
  };
  X.pt_range = function (el) { PF().range = el.dataset.id; U.render(true); };
  X.pt_row = function (el) { U.go('tx', { kind: 'purchase', id: el.dataset.id }); };
  X.pt_print = function () { printNow('KHALDI_PLAST_' + t('tile_purchtable').replace(/\s+/g, '_') + '_' + today()); };
  X.pt_csv = function () {
    var pt = ptData(), rows = [[t('date'), t('supplier'), t('pt_material'), t('quantity'), t('pt_unit_price'), t('total'), t('paid'), t('remaining'), t('notes')]];
    pt.rows.forEach(function (x) { rows.push([x.date, x.supplier, x.material, x.qty, K.fmtMoney(x.unitCost), K.fmtMoney(x.total), K.fmtMoney(x.paid), K.fmtMoney(x.remaining), x.voided ? t('voided') : x.notes]); });
    rows.push([t('total'), '', '', pt.totals.qty, '', K.fmtMoney(pt.totals.total), K.fmtMoney(pt.totals.paid), K.fmtMoney(pt.totals.remaining), '']);
    csvFile('khaldi_purchases_' + today() + '.csv', rows);
  };
  // select / checkbox / date filters of the purchases table
  var prevAfter = U.afterRender;
  U.afterRender = function (R) {
    if (prevAfter) prevAfter(R);
    if (R !== 'purchtable') return;
    var f = PF(), on = function (id, fn, ev) { var el = document.getElementById(id); if (el) el.addEventListener(ev || 'change', fn); };
    on('ptSup', function (e) { f.supplier = e.target.value; U.render(true); }); on('ptMat', function (e) { f.material = e.target.value; U.render(true); });
    on('ptVoid', function (e) { f.void = e.target.checked; U.render(true); }); on('ptFrom', function (e) { f.from = e.target.value; U.render(true); }); on('ptTo', function (e) { f.to = e.target.value; U.render(true); });
  };

  /* ================= home widgets ================= */
  U.crmWidgets = {
    follow: function () {
      var td = today(), l = (U.D.leads || []).filter(function (x) { return !x.voided && K.OPEN_STAGES.indexOf(x.stage) >= 0 && x.nextFollow && x.nextFollow <= td; }).sort(function (a, b) { return a.nextFollow < b.nextFollow ? -1 : 1; });
      return l;
    }
  };
})();
