/* KHALDI PLAST - v2.2 business logic (pure functions, same rules as core.js / core2.js: integer centimes, void-never-delete,
 * everything derived from the records, nothing invented).
 *   1. CRM: smart customer registration (duplicate detection), leads (prospects) with a sales pipeline, automatic customer segments.
 *   2. Purchases table: filters, totals, per-material price statistics, per-supplier summary.
 *   3. Company analysis: KPIs vs the previous period, health score (transparent weights), sales / customers / costs / cash / stock /
 *      production findings and a prioritised list of recommendations.
 * New data array (additive, created lazily): d.leads. */
(function (root) {
  'use strict';
  var K = (typeof module !== 'undefined' && module.exports) ? require('./core2.js') : root.KP;
  var E = K.E, byId = K.byId, sum = K.sum, live = K.live;
  function dn(s) { return Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)) / 86400000; }
  function age(from, to) { return Math.round(dn(to) - dn(from)); }
  function str(v) { return v == null ? '' : String(v).trim(); }
  function okDate(s) { return K.validDate(s); }
  function needDate(s) { if (!okDate(s)) throw E('bad_date'); }
  function stampNow() { return new Date().toISOString(); }
  function ensure(d) { d.leads = d.leads || []; return d; }
  function pct(cur, prev) { return prev > 0 ? Math.round((cur - prev) * 1000 / prev) / 10 : null; }
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function lin(x, x0, s0, x1, s1) { return Math.round(clamp(s0 + (x - x0) * (s1 - s0) / (x1 - x0), Math.min(s0, s1), Math.max(s0, s1))); }

  /* ================= 1. CRM ================= */
  var STAGES = ['new', 'contacted', 'quoted', 'negotiation', 'won', 'lost'];
  var OPEN = ['new', 'contacted', 'quoted', 'negotiation'];
  var WEIGHT = { new: 0.1, contacted: 0.25, quoted: 0.5, negotiation: 0.7 };
  var SOURCES = ['visit', 'referral', 'phone', 'social', 'market', 'other'];

  // phone -> last 9 digits (07 98 58 74 64 == +213 798 58 74 64 == 00213798587464)
  function normPhone(s) { var x = String(s || '').replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 1632; }).replace(/\D+/g, ''); return x.length >= 8 ? x.slice(-9) : ''; }
  function normName(s) {
    return String(s || '').toLowerCase().replace(/[ً-ْـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/[^a-z0-9؀-ۿ ]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function nameSim(a, b) {
    a = normName(a); b = normName(b); if (!a || !b) return 0; if (a === b) return 1;
    if (a.length >= 4 && b.length >= 4 && (a.indexOf(b) >= 0 || b.indexOf(a) >= 0)) return 0.85;
    var ta = a.split(' '), tb = b.split(' '), inter = ta.filter(function (x) { return tb.indexOf(x) >= 0; }).length, uni = ta.length + tb.length - inter;
    return uni ? inter / uni : 0;
  }
  // Possible duplicates among customers, leads and suppliers. strong = same phone or identical name.
  function findDuplicates(d, o) {
    ensure(d); var ph = normPhone(o.phone), nm = str(o.name), out = [];
    function scan(kind, arr) {
      arr.forEach(function (r) {
        if (r.voided || r.archived || r.id === o.excludeId) return;
        if (kind === 'lead' && (r.stage === 'won' && r.customerId)) return;      // already a customer: the customer record is the one that counts
        var samePhone = ph && normPhone(r.phone) === ph, sim = nm ? nameSim(nm, r.name) : 0;
        if (samePhone) out.push({ kind: kind, rec: r, reason: 'phone', strong: true });
        else if (sim >= 1) out.push({ kind: kind, rec: r, reason: 'name', strong: true });
        else if (sim >= 0.6) out.push({ kind: kind, rec: r, reason: 'similar', strong: false });
      });
    }
    scan('customer', d.customers); scan('lead', d.leads); scan('supplier', d.suppliers);
    return out.sort(function (a, b) { return (b.strong ? 1 : 0) - (a.strong ? 1 : 0); });
  }
  // Registers a customer after the duplicate check (o.force skips it). Throws dup_party with the existing name.
  function registerCustomer(d, o) {
    var dup = o.force ? [] : findDuplicates(d, o).filter(function (x) { return x.strong && x.kind !== 'supplier'; });
    if (dup.length) throw E('dup_party', { name: dup[0].rec.name });
    return K.addCustomer(d, o);
  }

  function cleanLead(d, o, base) {
    var name = str(o.name); if (!name) throw E('name_required');
    var date = o.date || (base && base.created) || K.today(); needDate(date);
    var value = o.value == null || o.value === '' ? 0 : Number(o.value); if (!(value >= 0) || Math.floor(value) !== value) throw E('bad_amount');
    var qty = o.qty == null || o.qty === '' ? 0 : Number(o.qty); if (!(qty >= 0)) throw E('bad_qty');
    var pid = str(o.productId); if (pid && !byId(d.products, pid)) throw E('no_item');
    var nf = str(o.nextFollow); if (nf) { needDate(nf); }
    var src = SOURCES.indexOf(o.source) >= 0 ? o.source : 'other';
    return { name: name, phone: str(o.phone), address: str(o.address), activity: str(o.activity), source: src, productId: pid, qty: qty, value: value, nextFollow: nf, notes: str(o.notes), created: date };
  }
  function addLead(d, o) {
    ensure(d); var c = cleanLead(d, o);
    if (!c.nextFollow) c.nextFollow = K.addDays(c.created, 2);            // smart default: follow up in 2 days
    var l = Object.assign({ id: K.uid('led'), ts: stampNow(), stage: 'new', customerId: '', lastContact: '', closed: '', lostReason: '', log: [{ date: c.created, type: 'created', text: '' }], voided: false }, c);
    d.leads.push(l); return l;
  }
  function editLead(d, id, o) {
    ensure(d); var l = byId(d.leads, id); if (!l || l.voided) throw E('no_item');
    var c = cleanLead(d, o, l); c.created = l.created; Object.keys(c).forEach(function (k) { l[k] = c[k]; }); return l;
  }
  function setStage(d, id, stage, o) {
    ensure(d); o = o || {}; var l = byId(d.leads, id); if (!l || l.voided) throw E('no_item');
    if (STAGES.indexOf(stage) < 0) throw E('bad_range');
    var day = o.date || K.today(); needDate(day);
    l.stage = stage; l.lastContact = day;
    if (stage === 'lost') { l.lostReason = str(o.reason); l.closed = day; l.nextFollow = ''; }
    else if (stage === 'won') { l.closed = day; l.nextFollow = ''; l.lostReason = ''; }
    else { l.closed = ''; l.lostReason = ''; if (!l.nextFollow || l.nextFollow < day) l.nextFollow = K.addDays(day, 3); }
    l.log.push({ date: day, type: 'stage', text: stage + (l.lostReason ? ': ' + l.lostReason : '') });
    return l;
  }
  function addLeadNote(d, id, o) {
    ensure(d); var l = byId(d.leads, id); if (!l || l.voided) throw E('no_item');
    var day = o.date || K.today(); needDate(day); var text = str(o.text); if (!text) throw E('name_required');
    var nf = str(o.nextFollow); if (nf) { needDate(nf); if (nf < day) throw E('bad_range'); l.nextFollow = nf; }
    l.lastContact = day; if (l.stage === 'new') l.stage = 'contacted';
    l.log.push({ date: day, type: 'note', text: text }); return l;
  }
  function voidLead(d, id) { ensure(d); var l = byId(d.leads, id); if (!l || l.voided) throw E('no_item'); l.voided = true; }
  // Turns a prospect into a real customer (or links to the one that already exists with the same phone/name).
  function convertLead(d, id, o) {
    ensure(d); o = o || {}; var l = byId(d.leads, id); if (!l || l.voided) throw E('no_item');
    var cust = l.customerId ? byId(d.customers, l.customerId) : null, linked = !!cust;
    if (!cust) {
      var dup = findDuplicates(d, { name: l.name, phone: l.phone }).filter(function (x) { return x.kind === 'customer' && x.strong; })[0];
      if (dup) { cust = dup.rec; linked = true; }
      else cust = K.addCustomer(d, { name: l.name, phone: l.phone, address: l.address, activity: l.activity, notes: l.notes });
    }
    l.customerId = cust.id; setStage(d, id, 'won', { date: o.date });
    return { customer: cust, linked: linked, lead: l };
  }
  function leadState(l, today) {
    if (l.voided) return 'void'; if (l.stage === 'won' || l.stage === 'lost') return 'closed';
    if (!l.nextFollow) return 'none'; if (l.nextFollow < today) return 'overdue'; if (l.nextFollow === today) return 'today';
    return age(today, l.nextFollow) <= 3 ? 'soon' : 'ok';
  }
  function leadsSummary(d, today) {
    ensure(d); var all = d.leads.filter(function (l) { return !l.voided; }), st = {}, i;
    STAGES.forEach(function (s) { st[s] = { n: 0, value: 0 }; });
    all.forEach(function (l) { st[l.stage].n++; st[l.stage].value += l.value; });
    var open = all.filter(function (l) { return OPEN.indexOf(l.stage) >= 0; }), won = all.filter(function (l) { return l.stage === 'won'; }), lost = all.filter(function (l) { return l.stage === 'lost'; });
    var pipeline = sum(open, function (l) { return l.value; }), weighted = Math.round(sum(open, function (l) { return l.value * WEIGHT[l.stage]; }));
    var overdue = open.filter(function (l) { return leadState(l, today) === 'overdue'; }), dueToday = open.filter(function (l) { return leadState(l, today) === 'today'; });
    var bySrc = {}; SOURCES.forEach(function (s) { bySrc[s] = { n: 0, won: 0, lost: 0 }; });
    all.forEach(function (l) { var b = bySrc[l.source] || bySrc.other; b.n++; if (l.stage === 'won') b.won++; if (l.stage === 'lost') b.lost++; });
    var days = won.filter(function (l) { return l.closed; }).map(function (l) { return age(l.created, l.closed); });
    var closed = won.length + lost.length;
    return { total: all.length, stages: st, open: open.length, pipeline: pipeline, weighted: weighted, won: won.length, lost: lost.length, wonValue: sum(won, function (l) { return l.value; }),
      conversion: closed ? Math.round(won.length * 100 / closed) : null, overdue: overdue.length, dueToday: dueToday.length, bySource: bySrc,
      avgDaysToWin: days.length ? Math.round(days.reduce(function (a, b) { return a + b; }, 0) / days.length) : null };
  }

  /* ---- automatic customer segments (rules, from the real invoices and payments) ----
   * risk      : an unpaid invoice older than 60 days, or the balance is more than half of the last-90-day sales
   * dormant   : no invoice for longer than max(60 days, 2.5 x the customer's usual gap between orders)
   * vip       : in the top 20% by sales of the last 365 days (3+ customers) with at least 3 invoices
   * new       : first invoice in the last 30 days
   * active    : everything else with invoices;  prospect: registered but never invoiced */
  function customerProfiles(d, today) {
    ensure(d); var y0 = K.addDays(today, -365), n90 = K.addDays(today, -90), rows = [];
    d.customers.filter(function (c) { return !c.archived; }).forEach(function (c) {
      var sales = live(d.sales).filter(function (s) { return s.customerId === c.id; }).sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
      var rev365 = sum(sales.filter(function (s) { return s.date >= y0; }), function (s) { return s.total; }), rev90 = sum(sales.filter(function (s) { return s.date >= n90; }), function (s) { return s.total; });
      var bal = K.customerBalance(d, c.id), oldest = 0;
      sales.forEach(function (s) { if (K.saleOutstanding(d, s.id) > 0) oldest = Math.max(oldest, age(s.date, today)); });
      var gaps = []; for (var i = 1; i < sales.length; i++) gaps.push(age(sales[i - 1].date, sales[i].date));
      var avgGap = gaps.length >= 2 ? gaps.reduce(function (a, b) { return a + b; }, 0) / gaps.length : null;
      var last = sales.length ? sales[sales.length - 1].date : '', first = sales.length ? sales[0].date : '', since = last ? age(last, today) : null;
      var expected = avgGap != null && last ? K.addDays(last, Math.round(avgGap)) : '';
      rows.push({ customer: c, count: sales.length, revenue: sum(sales, function (s) { return s.total; }), rev365: rev365, rev90: rev90, balance: bal, oldestUnpaid: oldest, first: first, last: last, daysSince: since,
        avgGap: avgGap == null ? null : Math.round(avgGap), expected: expected, avgOrder: sales.length ? Math.round(sum(sales, function (s) { return s.total; }) / sales.length) : 0, segment: 'active', vip: false, reorderDue: false });
    });
    var ranked = rows.filter(function (r) { return r.rev365 > 0; }).sort(function (a, b) { return b.rev365 - a.rev365; }), topN = ranked.length >= 3 ? Math.max(1, Math.ceil(ranked.length * 0.2)) : 0;
    ranked.slice(0, topN).forEach(function (r) { if (r.count >= 3) r.vip = true; });
    rows.forEach(function (r) {
      var dormantAfter = Math.max(60, r.avgGap != null ? r.avgGap * 2.5 : 0);
      if (!r.count) r.segment = 'prospect';
      else if (r.oldestUnpaid > 60 || (r.balance > 0 && r.rev90 > 0 && r.balance * 2 > r.rev90)) r.segment = 'risk';
      else if (r.daysSince > dormantAfter) r.segment = 'dormant';
      else if (r.vip) r.segment = 'vip';
      else if (r.first && age(r.first, today) <= 30) r.segment = 'new';
      if (r.segment !== 'dormant' && r.expected && r.expected < today && r.daysSince != null && r.daysSince <= dormantAfter) r.reorderDue = true;
    });
    return rows;
  }

  /* ================= 2. purchases table ================= */
  function purchaseTable(d, f) {
    f = f || {}; var rows = [];
    d.purchases.forEach(function (p) {
      if (p.voided && !f.includeVoid) return;
      if (f.from && p.date < f.from) return; if (f.to && p.date > f.to) return;
      if (f.supplierId && p.supplierId !== f.supplierId) return; if (f.materialId && p.materialId !== f.materialId) return;
      var s = byId(d.suppliers, p.supplierId), m = byId(d.materials, p.materialId), rem = p.voided ? 0 : K.purchaseOutstanding(d, p.id);
      rows.push({ id: p.id, date: p.date, ts: p.ts || '', supplierId: p.supplierId, supplier: s ? s.name : '', materialId: p.materialId, material: m ? m.name : '', unit: m ? m.unit : '', qty: p.qty, unitCost: p.unitCost,
        total: p.total, paid: p.voided ? 0 : p.total - rem, remaining: rem, voided: !!p.voided, notes: p.notes || '' });
    });
    rows.sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : (a.ts < b.ts ? 1 : a.ts > b.ts ? -1 : 0); });
    var liveRows = rows.filter(function (r) { return !r.voided; });
    var totals = { count: liveRows.length, qty: K.round3(sum(liveRows, function (r) { return r.qty; })), total: sum(liveRows, function (r) { return r.total; }), paid: sum(liveRows, function (r) { return r.paid; }), remaining: sum(liveRows, function (r) { return r.remaining; }) };
    var bm = {}, bs = {};
    liveRows.slice().sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.ts < b.ts ? -1 : 1); }).forEach(function (r) {
      var m = bm[r.materialId] || (bm[r.materialId] = { materialId: r.materialId, material: r.material, unit: r.unit, qty: 0, total: 0, min: Infinity, max: 0, last: 0, lastDate: '', prev: [], count: 0 });
      m.qty += r.qty; m.total += r.total; m.count++; m.min = Math.min(m.min, r.unitCost); m.max = Math.max(m.max, r.unitCost); m.prev.push(r.unitCost); m.last = r.unitCost; m.lastDate = r.date;
      var s = bs[r.supplierId] || (bs[r.supplierId] = { supplierId: r.supplierId, supplier: r.supplier, count: 0, total: 0, paid: 0, remaining: 0 });
      s.count++; s.total += r.total; s.paid += r.paid; s.remaining += r.remaining;
    });
    var byMaterial = Object.keys(bm).map(function (k) {
      var m = bm[k], earlier = m.prev.slice(0, -1), ea = earlier.length ? earlier.reduce(function (a, b) { return a + b; }, 0) / earlier.length : null;
      return { materialId: m.materialId, material: m.material, unit: m.unit, count: m.count, qty: K.round3(m.qty), total: m.total, avg: m.qty ? Math.round(m.total / m.qty) : 0, min: m.min, max: m.max, last: m.last, lastDate: m.lastDate, change: ea ? Math.round((m.last - ea) * 1000 / ea) / 10 : null };
    }).sort(function (a, b) { return b.total - a.total; });
    var bySupplier = Object.keys(bs).map(function (k) { return bs[k]; }).sort(function (a, b) { return b.total - a.total; });
    return { rows: rows, totals: totals, byMaterial: byMaterial, bySupplier: bySupplier, priceAlerts: byMaterial.filter(function (m) { return m.change != null && m.change >= 8; }) };
  }

  /* ================= 3. company analysis ================= */
  // days: length of the analysed period; it is compared with the equally long period just before it.
  function analysis(d, today, days) {
    ensure(d); var N = days || 30, cf = K.addDays(today, -(N - 1)), pt = K.addDays(cf, -1), pf = K.addDays(pt, -(N - 1));
    var cur = K.periodReport(d, cf, today), prev = K.periodReport(d, pf, pt);
    function inR(x, a, b) { return x >= a && x <= b; }
    function periodExtra(f, t) {
      var cons = sum(live(d.production).filter(function (r) { return inR(r.date, f, t); }), function (r) { return r.good + r.defective; });
      var bad = sum(live(d.production).filter(function (r) { return inR(r.date, f, t); }), function (r) { return r.defective; });
      return { defectPct: cons ? Math.round(bad * 1000 / cons) / 10 : null, newCustomers: d.customers.filter(function (c) { return c.created && inR(c.created, f, t); }).length,
        newLeads: d.leads.filter(function (l) { return !l.voided && inR(l.created, f, t); }).length, wonLeads: d.leads.filter(function (l) { return !l.voided && l.stage === 'won' && l.closed && inR(l.closed, f, t); }).length,
        paidSuppliers: sum(live(d.supplierPayments).filter(function (p) { return inR(p.date, f, t); }), function (p) { return p.amount; }) };
    }
    var xc = periodExtra(cf, today), xp = periodExtra(pf, pt);
    var kpis = { sales: { cur: cur.sales, prev: prev.sales, pct: pct(cur.sales, prev.sales) }, collected: { cur: cur.collected, prev: prev.collected, pct: pct(cur.collected, prev.collected) },
      purchases: { cur: cur.purchases, prev: prev.purchases, pct: pct(cur.purchases, prev.purchases) }, expenses: { cur: cur.expenses, prev: prev.expenses, pct: pct(cur.expenses, prev.expenses) },
      profit: { cur: cur.operatingProfit, prev: prev.operatingProfit, pct: cur.operatingProfit != null && prev.operatingProfit != null && prev.operatingProfit > 0 ? pct(cur.operatingProfit, prev.operatingProfit) : null },
      good: { cur: cur.good, prev: prev.good, pct: pct(cur.good, prev.good) }, invoices: { cur: cur.salesCount, prev: prev.salesCount, pct: pct(cur.salesCount, prev.salesCount) } };
    var margin = cur.operatingProfit != null && cur.sales > 0 ? Math.round(cur.operatingProfit * 1000 / cur.sales) / 10 : null;
    var cashIn = cur.collected, cashOut = xc.paidSuppliers + cur.expenses + 0;     // initial payments are included in collected / paidSuppliers; worker payments are expenses

    // products
    var sold = {}; live(d.sales).filter(function (s) { return inR(s.date, cf, today); }).forEach(function (s) { s.items.forEach(function (i) { var x = sold[i.productId] || (sold[i.productId] = { qty: 0, revenue: 0 }); x.qty += i.qty; x.revenue += i.qty * i.unitPrice; }); });
    var sold30 = {}, last60 = {}; live(d.sales).forEach(function (s) { s.items.forEach(function (i) { if (s.date > K.addDays(today, -30)) sold30[i.productId] = (sold30[i.productId] || 0) + i.qty; if (s.date > K.addDays(today, -60)) last60[i.productId] = 1; }); });
    var totRev = sum(Object.keys(sold), function (k) { return sold[k].revenue; });
    var products = d.products.filter(function (p) { return !p.archived; }).map(function (p) {
      var s = sold[p.id] || { qty: 0, revenue: 0 }, daily = (sold30[p.id] || 0) / 30;
      return { product: p, qty: s.qty, revenue: s.revenue, share: totRev ? Math.round(s.revenue * 1000 / totRev) / 10 : 0, avgPrice: s.qty ? Math.round(s.revenue / s.qty) : 0, cover: daily > 0 ? Math.round(p.stock / daily * 10) / 10 : null, dead: p.stock > 0 && !last60[p.id] };
    }).sort(function (a, b) { return b.revenue - a.revenue; });

    // customers
    var byC = {}; live(d.sales).filter(function (s) { return inR(s.date, cf, today) && s.customerId; }).forEach(function (s) { byC[s.customerId] = (byC[s.customerId] || 0) + s.total; });
    var walkin = sum(live(d.sales).filter(function (s) { return inR(s.date, cf, today) && !s.customerId; }), function (s) { return s.total; });
    var topC = Object.keys(byC).sort(function (a, b) { return byC[b] - byC[a]; }).slice(0, 5).map(function (id) { return { customer: byId(d.customers, id), revenue: byC[id], share: cur.sales ? Math.round(byC[id] * 1000 / cur.sales) / 10 : 0 }; });
    var profiles = customerProfiles(d, today), seg = { vip: 0, active: 0, new: 0, dormant: 0, risk: 0, prospect: 0 };
    profiles.forEach(function (r) { seg[r.segment]++; });
    var dormant = profiles.filter(function (r) { return r.segment === 'dormant'; }).sort(function (a, b) { return b.rev365 - a.rev365 || b.revenue - a.revenue; }), reorder = profiles.filter(function (r) { return r.reorderDue; });
    var dso = []; live(d.sales).filter(function (s) { return s.customerId && s.date >= K.addDays(today, -180) && K.saleOutstanding(d, s.id) === 0; }).forEach(function (s) {
      var ps = live(d.payments).filter(function (p) { return p.saleId === s.id; }); if (!ps.length) return; var lastP = ps.map(function (p) { return p.date; }).sort().pop(); dso.push(Math.max(0, age(s.date, lastP)));
    });
    var wd = [0, 0, 0, 0, 0, 0, 0]; live(d.sales).filter(function (s) { return inR(s.date, cf, today); }).forEach(function (s) { wd[new Date(dn(s.date) * 86400000).getUTCDay()] += s.total; });

    // costs
    var catTotal = cur.expenses, prevByCat = {}; prev.expensesByCat.forEach(function (c) { prevByCat[c.categoryId] = c.amount; });
    var expCats = cur.expensesByCat.map(function (c) { var cat = byId(d.expenseCats, c.categoryId); return { categoryId: c.categoryId, name: cat ? cat.name : '', key: cat && cat.key || '', amount: c.amount, share: catTotal ? Math.round(c.amount * 1000 / catTotal) / 10 : 0, change: pct(c.amount, prevByCat[c.categoryId] || 0) }; });
    var pt3 = purchaseTable(d, { from: K.addDays(today, -90), to: today });

    // cash & debts
    var ag = K.ageingReport(d, today), payables = K.totalSupplierDebt(d), longOver = ag.totals[2] + ag.totals[3];

    // stock
    var fc = K.materialForecast(d, today), critical = fc.filter(function (x) { return x.status === 'critical'; });

    // production
    var prodDays = {}; live(d.production).filter(function (r) { return inR(r.date, cf, today); }).forEach(function (r) { prodDays[r.date] = 1; });
    var byShift = { 1: 0, 2: 0, 3: 0 }; live(d.production).filter(function (r) { return inR(r.date, cf, today); }).forEach(function (r) { if (byShift[r.shift] != null) byShift[r.shift] += r.good; });
    var production = { good: cur.good, defective: cur.defective, defectPct: xc.defectPct, prevDefectPct: xp.defectPct, days: Object.keys(prodDays).length, perDay: Object.keys(prodDays).length ? Math.round(cur.good / Object.keys(prodDays).length) : 0, byShift: byShift, defectCost: cur.defectCost };

    var leads = leadsSummary(d, today), series = K.monthSeries(d, today.slice(0, 7), 6);

    // ---- health score (every component is shown with its value, score and weight) ----
    var comps = [];
    function comp(id, weight, value, score) { comps.push({ id: id, weight: weight, value: value, score: score, ok: score != null }); }
    comp('profit', 25, margin, margin == null ? null : margin >= 25 ? 100 : margin >= 0 ? lin(margin, 0, 40, 25, 100) : lin(margin, -20, 0, 0, 40));
    var ovShare = ag.total ? (ag.totals[2] + ag.totals[3] + ag.totals[1]) / ag.total : 0;
    comp('collect', 20, Math.round((1 - ovShare) * 100), Math.round((1 - ovShare) * 100));
    comp('growth', 15, kpis.sales.pct, kpis.sales.pct == null ? null : kpis.sales.pct >= 10 ? 100 : kpis.sales.pct >= 0 ? lin(kpis.sales.pct, 0, 60, 10, 100) : lin(kpis.sales.pct, -30, 0, 0, 60));
    var nM = fc.filter(function (x) { return x.status !== 'nodata'; }).length, nP = products.filter(function (p) { return p.cover != null; }).length, badStock = critical.length + products.filter(function (p) { return p.cover != null && p.cover < 3; }).length;
    comp('stock', 15, nM + nP ? badStock : null, nM + nP ? Math.round(100 * (1 - badStock / (nM + nP))) : null);
    comp('quality', 15, xc.defectPct, xc.defectPct == null ? null : xc.defectPct <= 2 ? 100 : lin(xc.defectPct, 2, 100, 8, 0));
    var pur90 = pt3.totals.total, payRatio = pur90 > 0 ? payables / pur90 : (payables > 0 ? 2 : 0);
    comp('suppliers', 10, Math.round(payRatio * 100) / 100, pur90 > 0 || payables > 0 ? lin(payRatio, 0.3, 100, 1.5, 0) : null);
    var wsum = 0, ssum = 0; comps.forEach(function (c) { if (c.ok) { wsum += c.weight; ssum += c.weight * c.score; } });
    var score = wsum >= 40 ? Math.round(ssum / wsum) : null, level = score == null ? 'nodata' : score >= 80 ? 'excellent' : score >= 60 ? 'good' : score >= 40 ? 'watch' : 'critical';

    // ---- recommendations ----
    var rec = []; function add(id, sev, icon, params, route) { rec.push({ id: id, sev: sev, icon: icon, params: params || {}, route: route || '' }); }
    if (cur.operatingProfit != null && cur.sales > 0) { if (cur.operatingProfit < 0) add('loss', 'high', 'alert', { amount: -cur.operatingProfit }, 'reports'); else if (margin < 10) add('margin_low', 'med', 'bars', { pct: margin }, 'reports'); }
    if (kpis.sales.pct != null) { if (kpis.sales.pct <= -15) add('sales_down', 'high', 'bars', { pct: Math.abs(kpis.sales.pct) }, 'sales'); else if (kpis.sales.pct >= 10) add('sales_up', 'good', 'bars', { pct: kpis.sales.pct }, 'sales'); }
    if (topC.length && cur.sales > 0 && topC[0].share >= 40 && topC[0].customer) add('concentration', 'med', 'user', { name: topC[0].customer.name, pct: Math.round(topC[0].share) }, 'crm');
    if (ag.totals[3] > 0) add('overdue90', 'high', 'wallet', { amount: ag.totals[3], n: ag.rows.filter(function (r) { return r.buckets[3] > 0; }).length }, 'collect');
    else if (ag.totals[1] + ag.totals[2] > 0) add('overdue', 'med', 'wallet', { amount: ag.totals[1] + ag.totals[2], n: ag.rows.filter(function (r) { return r.buckets[1] + r.buckets[2] > 0; }).length }, 'collect');
    if (dormant.length) add('dormant', 'med', 'user', { n: dormant.length, name: dormant[0].customer.name, days: dormant[0].daysSince }, 'crm');
    if (reorder.length) add('reorder', 'low', 'calendar', { n: reorder.length, name: reorder[0].customer.name }, 'crm');
    if (leads.overdue + leads.dueToday > 0) add('followups', 'med', 'phone', { n: leads.overdue + leads.dueToday }, 'crm');
    if (leads.open > 0) add('pipeline', 'low', 'bars', { n: leads.open, amount: leads.pipeline }, 'crm');
    if (critical.length) add('material_critical', 'high', 'scale', { name: critical[0].material.name, days: Math.max(0, Math.floor(critical[0].cover)), n: critical.length }, 'forecast');
    if (pt3.priceAlerts.length) add('price_up', 'med', 'truck', { name: pt3.priceAlerts[0].material, pct: pt3.priceAlerts[0].change }, 'purchtable');
    var low = products.filter(function (p) { return p.cover != null && p.cover < 5; }); if (low.length) add('product_low', 'med', 'box', { name: low[0].product.name, days: Math.floor(low[0].cover), n: low.length }, 'stock');
    var dead = products.filter(function (p) { return p.dead; }); if (dead.length) add('dead_stock', 'low', 'box', { name: dead[0].product.name, n: dead.length }, 'stock');
    if (xc.defectPct != null && xc.defectPct > 5) add('defect_high', 'med', 'machine', { pct: xc.defectPct }, 'production');
    expCats.forEach(function (c) { if (c.change != null && c.change >= 30 && c.share >= 10 && !rec.some(function (r) { return r.id === 'expense_jump'; })) add('expense_jump', 'med', 'wallet', { name: c.name, key: c.key, pct: Math.round(c.change) }, 'expenses'); });
    if (pur90 > 0 && payables > pur90) add('supplier_debt', 'med', 'truck', { amount: payables }, 'suppliers');
    if (cur.sales > 0 && cur.collected * 2 < cur.sales) add('low_collect', 'med', 'wallet', { pct: Math.round(cur.collected * 100 / cur.sales) }, 'collect');
    var lb = d.settings && d.settings.lastBackup; if (!lb || Date.now() - new Date(lb).getTime() > 7 * 864e5) add('backup_old', 'low', 'save', {}, 'backup');
    var records = d.sales.length + d.purchases.length + d.production.length; if (records < 15) add('few_data', 'low', 'note', { n: records }, '');
    var ord = { high: 0, med: 1, low: 2, good: 3 }; rec.sort(function (a, b) { return ord[a.sev] - ord[b.sev]; });

    return { today: today, days: N, from: cf, to: today, prevFrom: pf, prevTo: pt, kpis: kpis, margin: margin, extra: xc, extraPrev: xp, series: series, cash: { in: cashIn, out: cashOut, net: cashIn - cashOut },
      products: products, customers: { top: topC, walkin: walkin, topShare: topC.length ? topC[0].share : 0, top3Share: cur.sales ? Math.round(sum(topC.slice(0, 3), function (x) { return x.revenue; }) * 1000 / cur.sales) / 10 : 0, segments: seg, dormant: dormant.slice(0, 5), reorder: reorder.slice(0, 5), avgCollectDays: dso.length >= 3 ? Math.round(dso.reduce(function (a, b) { return a + b; }, 0) / dso.length) : null, total: d.customers.filter(function (c) { return !c.archived; }).length },
      weekday: wd, expenses: expCats, purchases: pt3, receivables: { total: ag.total, buckets: ag.totals, overdue: ag.overdue, longOverdue: longOver, top: ag.rows.slice(0, 5) }, payables: payables,
      materials: fc, production: production, leads: leads, health: { score: score, level: level, components: comps }, recommendations: rec, report: cur, prevReport: prev };
  }

  var API = { STAGES: STAGES, OPEN_STAGES: OPEN, LEAD_SOURCES: SOURCES, normPhone: normPhone, normName: normName, findDuplicates: findDuplicates, registerCustomer: registerCustomer,
    addLead: addLead, editLead: editLead, setLeadStage: setStage, addLeadNote: addLeadNote, voidLead: voidLead, convertLead: convertLead, leadState: leadState, leadsSummary: leadsSummary,
    customerProfiles: customerProfiles, purchaseTable: purchaseTable, analysis: analysis, ensure3: ensure };
  Object.keys(API).forEach(function (k) { K[k] = API[k]; });
  if (typeof module !== 'undefined' && module.exports) module.exports = K;
})(typeof window !== 'undefined' ? window : this);
