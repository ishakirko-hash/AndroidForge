/* KHALDI PLAST v2.3 - polish helpers: page-entrance flag, button ripple, header shadow on scroll. Pure UI; no data access. */
(function () {
  'use strict';
  var U = window.KPU, last = '', tm;
  var render = U.render;
  U.render = function () {
    var r = render.apply(this, arguments), key = U.route + '|' + (U.arg == null ? '' : U.arg), m = document.getElementById('main');
    if (m && key !== last && U.route !== 'home' && !(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) {
      m.classList.remove('pg-in'); void m.offsetWidth; m.classList.add('pg-in'); clearTimeout(tm); tm = setTimeout(function () { m.classList.remove('pg-in'); }, 700);
    }
    last = key; return r;
  };
  document.addEventListener('pointerdown', function (e) {
    var b = e.target.closest && e.target.closest('.btn'); if (!b || b.disabled) return;
    var r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2, x = document.createElement('span');
    x.className = 'rip'; x.style.cssText = 'width:' + s + 'px;height:' + s + 'px;left:' + (e.clientX - r.left - s / 2) + 'px;top:' + (e.clientY - r.top - s / 2) + 'px';
    b.appendChild(x); setTimeout(function () { if (x.parentNode) x.parentNode.removeChild(x); }, 600);
  }, { passive: true });
  var main = document.getElementById('main');
  if (main) main.addEventListener('scroll', function () { var h = document.getElementById('hdr'); if (h) h.classList.toggle('scrolled', main.scrollTop > 6); }, { passive: true });
})();
