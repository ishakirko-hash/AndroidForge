/* KHALDI PLAST - v2.6: distribution monitor (trucks, trips: deliveries out / raw materials in) */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, S = U.S, X = U.extraActions;
  S.ds = S.ds || { t: null };

  function B(n) { return '<bdi class="num" dir="ltr">' + n + '</bdi>'; }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function clock(ms) { if (!ms) return '--:--'; var d = new Date(ms); return p2(d.getHours()) + ':' + p2(d.getMinutes()); }
  function DS(d) { var s = (d || U.D).settings; return s.dist || { trucks: [], trips: [] }; }
  function ensure(d) { var s = d.settings; s.dist = s.dist || {}; s.dist.trucks = s.dist.trucks || []; s.dist.trips = s.dist.trips || []; return s.dist; }
  function num(v) { var n = parseFloat(String(v).replace(',', '.').replace(/[^\d.]/g, '')); return isFinite(n) ? n : 0; }
  function trucks() { return DS().trucks.filter(function (x) { return !x.archived; }); }
  function tripsOf(id) { return DS().trips.filter(function (x) { return x.truckId === id; }); }
  function curTrip(id) {
    var l = tripsOf(id), g = l.filter(function (x) { return x.status === 'go'; })[0];
    if (g) return g;
    return l.filter(function (x) { return x.status === 'plan' && x.date === K.today(); }).sort(function (a, b) { return (a.t || 0) - (b.t || 0); })[0] || null;
  }
  function stateOf(tk) { if (tk.state === 'maint' || tk.state === 'stopped') return tk.state; return tripsOf(tk.id).some(function (x) { return x.status === 'go'; }) ? 'go' : 'ready'; }
  var STL = { ready: ['ds_ready', 'g'], go: ['ds_go', 'b'], stopped: ['ds_stopped', 'o'], maint: ['ds_maint', 'r'] };
  var TSL = { plan: ['ds_t_plan', 'n'], go: ['ds_t_go', 'b'], done: ['ds_t_done', 'g'], late: ['ds_t_late', 'r'] };
  function pill(map, k) { var s = map[k] || map.ready; return '<span class="ds-pill ' + s[1] + '"><i></i>' + t(s[0]) + '</span>'; }
  function tripName(x) { return x.type === 'in' ? t('ds_in') : t('ds_out'); }
  function loadTxt(x) { return (x.load || []).map(function (l) { return esc(l.name) + (l.qty ? ' × ' + K.groupInt(l.qty) : ''); }).join('، '); }
  function pc(a, b) { return b ? Math.round((a - b) * 1000 / Math.abs(b)) / 10 : null; }
  function delta(a, b, inv) { var d = pc(a, b); if (d == null) return ''; var good = inv ? d <= 0 : d >= 0; return '<span class="ds-dl ' + (good ? 'up' : 'dn') + '">' + (d >= 0 ? '↑' : '↓') + ' ' + B((d >= 0 ? '+' : '') + d + '%') + '</span>'; }

  function dayStats(date) {
    var l = DS().trips.filter(function (x) { return x.date === date; }), km = 0, fuel = 0;
    l.forEach(function (x) { if (x.status === 'done' || x.status === 'go') { km += x.km || 0; } if (x.status === 'done') fuel += x.fuel || 0; });
    return { all: l, n: l.length, done: l.filter(function (x) { return x.status === 'done'; }).length, go: l.filter(function (x) { return x.status === 'go'; }).length, late: l.filter(function (x) { return x.status === 'late'; }).length, plan: l.filter(function (x) { return x.status === 'plan'; }).length, km: km, fuel: fuel };
  }
  function donut(p) {
    var r = 42, c = 2 * Math.PI * r, o = c * (1 - Math.min(100, p) / 100);
    return '<svg viewBox="0 0 100 100" class="ds-dn"><circle cx="50" cy="50" r="' + r + '" fill="none" stroke="rgba(11,26,46,.1)" stroke-width="11"/><circle cx="50" cy="50" r="' + r + '" fill="none" stroke="#2DB35A" stroke-width="11" stroke-linecap="round" stroke-dasharray="' + c + '" stroke-dashoffset="' + o + '" transform="rotate(-90 50 50)"/></svg><b>' + B(p + '%') + '</b>';
  }
  function route(x) {
    var co = U.D.settings.company || 'KHALDI PLAST', a = x.type === 'in' ? x.dest : co, b = x.type === 'in' ? co : x.dest, p = x.status === 'done' ? 100 : (x.prog || 0);
    return '<div class="ds-route"><div class="ds-rp"><i class="o"></i><span>' + esc(a || '—') + '</span></div><div class="ds-rl"><u style="width:' + p + '%"></u><em style="right:' + p + '%">' + V.icon('truck', 14) + '</em></div><div class="ds-rp"><i class="d"></i><span>' + esc(b || '—') + '</span></div></div>';
  }

  /* decorative route map (offline: stylised, not a real map) */
  var SEG = [[[24, 128], [62, 62], [104, 112], [142, 74]], [[142, 74], [182, 38], [222, 104], [258, 34]]];
  function bz(s, t) { var u = 1 - t; return [0, 1].map(function (i) { return u * u * u * s[0][i] + 3 * u * u * t * s[1][i] + 3 * u * t * t * s[2][i] + t * t * t * s[3][i]; }); }
  function ptAt(p) { p = clamp01(p / 100); var k = p < 0.5 ? 0 : 1, t = p < 0.5 ? p * 2 : (p - 0.5) * 2; return bz(SEG[k], t); }
  function clamp01(x) { return Math.max(0, Math.min(1, x)); }
  function mapHtml(ct, st) {
    var path = 'M' + SEG[0][0].join(' ') + ' C' + SEG[0].slice(1).map(function (q) { return q.join(' '); }).join(',') + ' C' + SEG[1].slice(1).map(function (q) { return q.join(' '); }).join(','), h = '<div class="dv-map"><svg viewBox="0 0 280 170" preserveAspectRatio="none"><rect width="280" height="170" fill="#e8eef0"/><ellipse cx="40" cy="30" rx="46" ry="26" fill="#cfe8cf"/><ellipse cx="236" cy="132" rx="52" ry="30" fill="#cfe8cf"/><ellipse cx="150" cy="150" rx="40" ry="16" fill="#cde3f2"/>' +
      '<g stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round"><path d="M0 70 L110 40 L190 90 L280 60"/><path d="M60 0 L90 170"/><path d="M180 0 L210 170"/><path d="M0 140 L280 120"/></g><g stroke="#fff" stroke-width="2.5" fill="none"><path d="M0 100 L280 90"/><path d="M130 0 L150 170"/></g>' +
      (ct ? '<path d="' + path + '" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round"/><path d="' + path + '" fill="none" stroke="#2563eb" stroke-width="5" stroke-linecap="round"/>' : '') + '</svg>';
    if (ct) {
      var a = ptAt(0), z = ptAt(100), m = ptAt(ct.status === 'done' ? 100 : (ct.prog || 0));
      function pos(q) { return 'left:' + (q[0] / 280 * 100) + '%;top:' + (q[1] / 170 * 100) + '%'; }
      h += '<i class="dv-pin g" style="' + pos(a) + '"></i><i class="dv-pin r" style="' + pos(z) + '"></i><span class="dv-mk" style="' + pos(m) + '">' + V.icon('truck', 18) + '</span>';
    }
    return h + '<span class="dv-ms ' + STL[st][1] + '"><i></i>' + (st === 'go' ? t('ds_going_now') : t(STL[st][0])) + '</span></div>';
  }
  function tripNo(x) { var l = DS().trips.slice().sort(function (a, b) { return (a.t || 0) - (b.t || 0); }); return l.map(function (y) { return y.id; }).indexOf(x.id) + 1; }
  function ic(n, c) { return '<span class="dv-i ' + c + '">' + n + '</span>'; }

  W.distribution = function () {
    var tk = trucks();
    if (!tk.length) return '<div class="card" style="text-align:center"><img class="dv-img big" src="img/truck.jpg" alt=""><div class="muted" style="margin:10px 0">' + t('ds_no_trucks') + '</div><button class="btn primary" data-act="ds_truck">+ ' + t('ds_add_truck') + '</button></div>';
    if (!S.ds.t || !tk.some(function (x) { return x.id === S.ds.t; })) S.ds.t = tk[0].id;
    var sel = tk.filter(function (x) { return x.id === S.ds.t; })[0], cnt = { ready: 0, go: 0, stopped: 0, maint: 0 }, h = '';
    tk.forEach(function (x) { cnt[stateOf(x)]++; });
    // summary: ready | on route | stopped | maintenance
    h += '<div class="dv-sum">' + [['ready', ic('✔', 'g'), 'g'], ['go', ic(V.icon('truck', 22), 'b'), 'b'], ['stopped', ic('❚❚', 'o'), 'o'], ['maint', ic('🔧', 'r'), 'r']].map(function (a) { return '<div class="dv-sc ' + a[2] + '">' + a[1] + '<b>' + B(cnt[a[0]]) + '</b><small>' + t(STL[a[0]][0]) + '</small></div>'; }).join('') + '</div>';
    // selected truck
    var st = stateOf(sel), ct = curTrip(sel.id);
    h += '<div class="card dv-main"><div class="dv-top">' + mapHtml(ct, st) + '<div class="dv-tr"><div class="dv-ttl"><b>' + esc(sel.no) + '</b><span dir="ltr">' + esc(sel.plate || '') + '</span></div><img class="dv-img" src="img/truck.jpg" alt=""></div></div>' +
      '<div class="dv-drv"><span class="dv-av">' + V.icon('user', 22) + '</span><div><small>' + t('ds_driver') + '</small><b>' + (sel.driver ? esc(sel.driver) : '—') + '</b></div>' + (sel.phone ? '<a class="dv-call" href="tel:' + esc(sel.phone) + '" aria-label="call">' + V.icon('phone', 22) + '</a>' : '') + '<button class="dv-edit" data-act="ds_truck" data-id="' + sel.id + '" aria-label="edit">' + V.icon('edit', 18) + '</button></div>';
    var tt = DS().trips.filter(function (x) { return x.truckId === sel.id && x.date === K.today(); }), tdn = tt.filter(function (x) { return x.status === 'done'; }), tkm = tt.filter(function (x) { return x.status === 'done' || x.status === 'go'; }).reduce(function (a, x) { return a + (x.km || 0); }, 0);
    h += '<div class="dv-ts"><div><b>' + B(tt.length) + '</b><small>' + t('ds_today_trips') + '</small></div><div><b>' + B(tdn.length) + '</b><small>' + t('ds_done_short') + '</small></div><div><b>' + B(K.groupInt(tkm)) + '</b><small>' + t('ds_km') + '</small></div></div>';
    if (ct) {
      h += '<div class="ds-ct tap" data-act="ds_trip" data-id="' + ct.id + '"><div class="ds-cth"><b>' + tripName(ct) + ' · ' + esc(ct.dest || '—') + '</b>' + pill(TSL, ct.status) + '</div>' + route(ct) +
        '<div class="ds-cm"><span>↔ ' + B(K.groupInt(ct.km || 0) + ' ' + t('ds_km')) + '</span><span>' + (ct.status === 'go' ? B((ct.prog || 0) + '%') : B(clock(ct.t))) + '</span></div>' +
        (ct.load && ct.load.length ? '<div class="ds-ld"><small>' + t(ct.type === 'in' ? 'ds_mats' : 'ds_loaded') + '</small>' + loadTxt(ct) + '</div>' : '') + '</div>';
    } else h += '<div class="muted" style="text-align:center;padding:6px 0">' + t('ds_no_trip') + '</div>';
    h += '<button class="btn primary block" data-act="ds_trip_new" data-id="' + sel.id + '">+ ' + t('ds_new_trip') + '</button></div>';
    // list
    var all = !!S.ds.all, shown = all ? tk : tk.slice(0, 4);
    h += '<div class="card"><div class="dv-lh"><b>' + t('ds_list') + '</b>' + (tk.length > 4 ? '<button class="dv-all" data-act="ds_all">' + t(all ? 'ds_less' : 'ds_all') + ' ' + V.icon('chevL', 14) + '</button>' : '<button class="dv-all" data-act="ds_truck">+ ' + t('ds_add_truck') + '</button>') + '</div>';
    shown.forEach(function (x) {
      var s2 = stateOf(x), c = curTrip(x.id), p = c && c.status === 'go' ? c.prog || 0 : null;
      h += '<button class="dv-row' + (x.id === sel.id ? ' on' : '') + '" data-act="ds_pick" data-id="' + x.id + '"><span class="dv-chev">' + V.icon('chevL', 18) + '</span><div class="dv-rs"><span class="dv-st ' + STL[s2][1] + '"><i></i>' + t(s2 === 'go' ? 'ds_go' : STL[s2][0]) + '</span>' + (p != null ? '<div class="dv-pb"><i style="width:' + p + '%"></i><em>' + p + '%</em></div>' : '') + '</div><div class="dv-rn"><b>' + esc(x.no) + '</b><small dir="ltr">' + esc(x.plate || '') + '</small></div><img class="dv-th" src="img/truck.jpg" alt=""></button>';
    });
    h += '</div>';
    // efficiency + tasks
    var td = dayStats(K.today()), yd = dayStats(K.addDays(K.today(), -1)), eff = td.n ? Math.round(td.done * 100 / td.n) : 0;
    h += '<div class="ds-g2"><div class="card dv-eff"><div class="dv-h"><span class="dv-hi">' + V.icon('truck', 18) + '</span><b>' + t('ds_eff') + '</b></div><div class="ds-dw">' + donut(eff) + '</div></div>' +
      '<div class="card dv-tasks"><div class="dv-h"><span class="dv-hi">' + V.icon('calendar', 18) + '</span><b>' + t('ds_tasks') + '</b></div>' + [['ds_orders', td.n, 'o', '▣'], ['ds_delivered', td.done, 'g', '✔'], ['ds_going', td.go, 'b', '➜'], ['ds_late', td.late, 'r', '◷']].map(function (r) { return '<div class="dv-tk ' + r[2] + '"><span class="dv-tki">' + r[3] + '</span><span class="dv-tkl">' + t(r[0]) + '</span><b>' + B(r[1]) + '</b></div>'; }).join('') + '</div></div>';
    // km + fuel
    h += '<div class="ds-g2"><div class="card dv-km"><div class="dv-h"><span class="dv-hi">' + V.icon('pin', 18) + '</span><b>' + t('ds_km_today') + '</b></div><div class="ds-v">' + B(K.groupInt(td.km)) + ' <small>' + t('ds_km') + '</small></div>' + delta(td.km, yd.km, true) + '<span class="dv-deco road"></span></div>' +
      '<div class="card dv-km"><div class="dv-h"><span class="dv-hi">⛽</span><b>' + t('ds_fuel') + '</b></div><div class="ds-v">' + U.money(td.fuel) + '</div>' + delta(td.fuel, yd.fuel, true) + '<span class="dv-deco fuel"></span></div></div>';
    // recent
    var rc = DS().trips.slice().sort(function (a, b) { return (b.t || 0) - (a.t || 0); }).slice(0, 6);
    h += '<div class="card"><div class="dv-h"><span class="dv-hi">' + V.icon('clock', 18) + '</span><b>' + t('ds_recent') + '</b></div>';
    if (!rc.length) h += '<div class="muted" style="text-align:center;padding:8px 0">' + t('no_records') + '</div>';
    rc.forEach(function (x) {
      var n = tripNo(x), done = x.status === 'done';
      h += '<button class="dv-rr" data-act="ds_trip" data-id="' + x.id + '"><span class="dv-chev">' + V.icon('chevL', 18) + '</span><div class="dv-rcol"><span class="dv-tm">' + B(clock(x.t0 || x.t)) + '</span>' +
        '<span class="dv-rs2 ' + (done ? 'g' : x.status === 'late' ? 'r' : x.status === 'go' ? 'o' : 'n') + '">' + (done ? '✔ ' : x.status === 'go' ? '🚚 ' : '') + t(TSL[x.status][0] === 'ds_t_go' ? 'ds_in_delivery' : TSL[x.status][0]) + '</span></div>' +
        '<div class="dv-rm"><b>' + esc(x.dest || '—') + '</b><small dir="ltr">TR-' + (n < 10 ? '000' : n < 100 ? '00' : '0') + n + '</small></div><span class="dv-bx ' + (x.type === 'in' ? 'in' : '') + '">' + V.icon('box', 20) + '</span><div class="dv-no"><small>' + t(x.type === 'in' ? 'ds_in_short' : 'ds_trip_no') + '</small><b>#' + n + '</b></div></button>';
    });
    return h + '</div><div class="muted" style="font-size:12px;margin:6px 4px">' + t('ds_note') + '</div>';
  };
  X.ds_all = function () { S.ds.all = !S.ds.all; U.render(true); };

  X.ds_pick = function (el) { S.ds.t = el.dataset.id; U.render(true); };
  X.ds_truck = function (el) {
    var id = el && el.dataset && el.dataset.id, x = id ? DS().trucks.filter(function (y) { return y.id === id; })[0] : null;
    U.openForm({
      title: t(x ? 'ds_edit_truck' : 'ds_add_truck'), submit: t('save'),
      fields: [
        { name: 'no', label: t('ds_truck_no'), type: 'text', value: x ? x.no : t('ds_truck') + ' ' + p2(DS().trucks.length + 1) },
        { name: 'plate', label: t('ds_plate'), type: 'text', optional: true, value: x ? x.plate : '' },
        { name: 'driver', label: t('ds_driver'), type: 'text', optional: true, value: x ? x.driver : '' },
        { name: 'phone', label: t('phone'), type: 'text', optional: true, value: x ? x.phone : '' },
        { name: 'state', label: t('ds_state'), type: 'select', value: x ? (x.state || 'ready') : 'ready', options: [{ v: 'ready', l: t('ds_ready') }, { v: 'stopped', l: t('ds_stopped') }, { v: 'maint', l: t('ds_maint') }] }
      ],
      onDelete: x ? function () { U.commit(function (d) { var o = ensure(d); o.trucks.forEach(function (y) { if (y.id === id) y.archived = true; }); }); U.closeModal(); U.render(true); } : null,
      onSubmit: function (v) {
        if (!v.no.trim()) throw new Error(t('ds_need_name'));
        var nid = x ? id : K.uid('tk');
        U.commit(function (d) { var o = ensure(d), r = { id: nid, no: v.no.trim(), plate: v.plate.trim(), driver: v.driver.trim(), phone: v.phone.trim(), state: v.state };
          if (x) o.trucks = o.trucks.map(function (y) { return y.id === id ? Object.assign(y, r) : y; }); else o.trucks.push(r); });
        S.ds.t = nid; U.closeModal(); U.render(true); U.toast(t('saved_ok'), 'ok');
      }
    });
  };
  function opts(list) { return [{ v: '', l: '—' }].concat(list.map(function (p) { return { v: p.name, l: p.name }; })); }
  X.ds_trip_new = function (el) { tripForm(null, el && el.dataset && el.dataset.id); };
  function tripForm(tr, truckId) {
    var D = U.D, tk = trucks(), src = (tr && tr.type === 'in') ? D.materials : D.products;
    var f = [
      { name: 'truck', label: t('ds_truck'), type: 'select', value: tr ? tr.truckId : (truckId || S.ds.t), options: tk.map(function (x) { return { v: x.id, l: x.no + (x.plate ? ' · ' + x.plate : '') }; }) },
      { name: 'type', label: t('ds_type'), type: 'select', value: tr ? tr.type : 'out', options: [{ v: 'out', l: t('ds_out') }, { v: 'in', l: t('ds_in') }] },
      { name: 'dest', label: t('ds_dest') + ' / ' + t('ds_from'), type: 'text', value: tr ? tr.dest : '' },
      { name: 'km', label: t('ds_km_trip'), type: 'text', optional: true, value: tr ? tr.km || '' : '' },
      { name: 'date', label: t('date'), type: 'date', value: tr ? tr.date : K.today() }
    ];
    var items = tr && tr.load ? tr.load : [];
    for (var i = 0; i < 3; i++) {
      var cur = items[i];
      f.push({ name: 'l' + i, label: t('ds_item') + ' ' + (i + 1), type: 'select', value: cur ? cur.name : '', options: opts(D.products.concat(D.materials)), allowNew: i === 0 || true, newLabel: t('ds_other_item') });
      f.push({ name: 'q' + i, label: t('quantity'), type: 'text', optional: true, value: cur ? cur.qty || '' : '' });
    }
    f.push({ name: 'fuel', label: t('ds_fuel') + ' (' + t(U.mode() === 'centimes' ? 'unit_centimes' : 'unit_dzd') + ')', type: 'text', optional: true, value: tr && tr.fuel ? U.forInput(tr.fuel) : '' });
    f.push({ name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: tr ? tr.notes : '' });
    U.openForm({
      title: t(tr ? 'ds_edit_trip' : 'ds_new_trip'), submit: t('save'), fields: f,
      onDelete: tr ? function () { X.ds_del({ dataset: { id: tr.id } }); } : null,
      onSubmit: function (v) {
        if (!v.truck) throw new Error(t('ds_no_trucks'));
        if (!v.dest.trim()) throw new Error(t('ds_need_dest'));
        var load = [];
        for (var i = 0; i < 3; i++) { var nm = v['l' + i] === '__new__' ? (v['l' + i + '_new'] || '').trim() : v['l' + i]; if (nm) load.push({ name: nm, qty: Math.round(num(v['q' + i])) }); }
        var fuel = U.parseM(v.fuel, false);
        U.commit(function (d) { var o = ensure(d), r = { truckId: v.truck, type: v.type, dest: v.dest.trim(), km: num(v.km), date: v.date, load: load, fuel: fuel, notes: (v.notes || '').trim() };
          if (tr) o.trips = o.trips.map(function (y) { return y.id === tr.id ? Object.assign(y, r) : y; });
          else { r.id = K.uid('tp'); r.status = 'plan'; r.prog = 0; r.t = Date.now(); o.trips.push(r); } });
        S.ds.t = v.truck; U.closeModal(); U.render(true); U.toast(t('saved_ok'), 'ok');
      }
    });
  }
  function getTrip(id) { return DS().trips.filter(function (x) { return x.id === id; })[0]; }
  X.ds_trip = function (el) {
    var x = getTrip(el.dataset.id); if (!x) return;
    var tr = DS().trucks.filter(function (y) { return y.id === x.truckId; })[0], h = '<h3>' + tripName(x) + ' · ' + esc(x.dest) + '</h3>' +
      '<div class="muted">' + (tr ? esc(tr.no) + ' · ' + esc(tr.plate || '') : '') + ' · ' + B(K.fmtDate(x.date)) + '</div><div style="margin:8px 0">' + pill(TSL, x.status) + '</div>' + route(x) +
      '<div class="ds-cm"><span>' + '↔' + ' ' + B(K.groupInt(x.km || 0) + ' ' + t('ds_km')) + '</span><span>' + B((x.status === 'done' ? 100 : x.prog || 0) + '%') + '</span></div>' +
      (x.load && x.load.length ? '<div class="ds-ld"><small>' + t(x.type === 'in' ? 'ds_mats' : 'ds_loaded') + '</small>' + loadTxt(x) + '</div>' : '') +
      (x.fuel ? '<div class="ds-ld"><small>' + t('ds_fuel') + '</small>' + U.money(x.fuel) + '</div>' : '') + (x.notes ? '<div class="muted">' + esc(x.notes) + '</div>' : '') +
      (x.t0 ? '<div class="muted">' + t('ds_started') + ' ' + B(clock(x.t0)) + (x.t1 ? ' · ' + t('ds_finished') + ' ' + B(clock(x.t1)) : '') + '</div>' : '');
    h += '<div class="btns" style="margin-top:12px;flex-wrap:wrap">';
    if (x.status === 'plan' || x.status === 'late') h += '<button class="btn primary" data-act="ds_start" data-id="' + x.id + '">' + t('ds_start') + '</button>';
    if (x.status === 'go') h += [25, 50, 75].map(function (p) { return '<button class="btn sm" data-act="ds_prog" data-id="' + x.id + '" data-p="' + p + '">' + p + '%</button>'; }).join('') + '<button class="btn primary" data-act="ds_finish" data-id="' + x.id + '">' + t('ds_finish') + '</button>';
    if (x.status === 'plan' || x.status === 'go') h += '<button class="btn soft-danger" data-act="ds_late" data-id="' + x.id + '">' + t('ds_postpone') + '</button>';
    h += '<button class="btn ghost" data-act="ds_edit_trip" data-id="' + x.id + '">' + t('edit') + '</button><button class="btn ghost" data-act="close">' + t('close') + '</button></div>';
    U.showModal('<div>' + h + '</div>');
  };
  X.ds_edit_trip = function (el) { var x = getTrip(el.dataset.id); U.closeModal(); if (x) tripForm(x); };
  function patch(id, fn) { U.commit(function (d) { ensure(d).trips.forEach(function (y) { if (y.id === id) fn(y); }); }); U.closeModal(); U.render(true); }
  X.ds_start = function (el) {
    var x = getTrip(el.dataset.id), tr = x && DS().trucks.filter(function (y) { return y.id === x.truckId; })[0];
    if (!tr || tr.state === 'maint' || tr.state === 'stopped') { U.toast(t('ds_cant_start'), 'bad'); return; }
    if (tripsOf(tr.id).some(function (y) { return y.status === 'go' && y.id !== x.id; })) { U.toast(t('ds_has_active'), 'bad'); return; }
    patch(x.id, function (y) { y.status = 'go'; y.t0 = Date.now(); y.prog = y.prog || 5; });
  };
  X.ds_prog = function (el) { var p = parseInt(el.dataset.p, 10); patch(el.dataset.id, function (y) { y.prog = p; }); };
  X.ds_finish = function (el) { patch(el.dataset.id, function (y) { y.status = 'done'; y.prog = 100; y.t1 = Date.now(); }); U.toast(t('ds_done_msg'), 'ok'); };
  X.ds_late = function (el) { patch(el.dataset.id, function (y) { y.status = 'late'; y.prog = 0; }); };
  X.ds_del = function (el) { var id = el.dataset.id; U.commit(function (d) { var o = ensure(d); o.trips = o.trips.filter(function (y) { return y.id !== id; }); }); U.closeModal(); U.render(true); };
})();
