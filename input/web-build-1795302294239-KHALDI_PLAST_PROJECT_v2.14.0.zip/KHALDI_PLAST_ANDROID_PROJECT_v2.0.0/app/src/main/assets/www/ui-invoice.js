/* KHALDI PLAST v2.2.1 - A4 invoice page (fixed 794x1123 design, scaled to the screen width, prints at real A4). */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc;
  U.invDisp = function (s) { return 'INV-' + ('000000' + s.no).slice(-6); };
  function ico(n, z) { return V.icon(n, z || 16); }
  function money2(c) { var n = (c / 100).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','); return '<bdi class="num" dir="ltr">' + n + '</bdi>'; }
  function dots(v) { return v ? v : '<i class="dots"></i>'; }
  function swoosh() {
    return '<svg class="ivx-bg" viewBox="0 0 794 1123" preserveAspectRatio="none" aria-hidden="true">' +
      '<defs><linearGradient id="ivg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0A2F7A"/><stop offset=".5" stop-color="#1688FF"/><stop offset="1" stop-color="#7FD0FF"/></linearGradient>' +
      '<linearGradient id="ivg2" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#C9D3E3"/><stop offset=".5" stop-color="#fff"/><stop offset="1" stop-color="#9FB0CC"/></linearGradient></defs>' +
      '<path d="M0 0H250C170 40 90 110 50 230 30 290 15 330 0 360Z" fill="url(#ivg1)" opacity=".95"/>' +
      '<path d="M0 0H300C210 30 120 100 70 220 40 290 20 340 0 400" fill="none" stroke="url(#ivg2)" stroke-width="5" opacity=".9"/>' +
      '<path d="M0 1123V1035C140 1085 330 1075 520 1055 650 1040 730 1060 794 1085V1123Z" fill="url(#ivg1)"/>' +
      '<path d="M0 1050C150 1095 350 1085 540 1062 670 1046 740 1062 794 1078" fill="none" stroke="url(#ivg2)" stroke-width="4"/>' +
      '<path d="M794 1123V1070C760 1060 730 1058 690 1062" fill="none" stroke="#1688FF" stroke-width="3" opacity=".5"/></svg>';
  }
  U.invoiceHtml = function (s, qm) {
    var D = U.D, st = D.settings, c = s.customerId ? K.byId(D.customers, s.customerId) : null, paid = K.salePaid(D, s.id), method = K.saleMethod(D, s.id);
    var rem = s.voided ? 0 : s.total - paid, stKey = s.voided ? 'void' : (s.total - paid <= 0 ? 'paid' : paid > 0 ? 'partial' : 'unpaid');
    var notes = (st.invoiceNotes == null ? t('inv_default_notes') : st.invoiceNotes).split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean);
    if (s.notes) notes.unshift(s.notes);
    var dv = s.delivery || {}, dvl = [dv.date ? K.fmtDate(dv.date) : '', dv.method || '', dv.notes || ''].filter(Boolean);
    if (dvl.length) notes.unshift(t('inv_delivery_info') + ' : ' + dvl.join(' · '));
    var no = qm ? qm.no : U.invDisp(s);
    var qrTxt = qm ? ['KHALDI PLAST', qm.no, s.date, 'TOTAL ' + (s.total / 100).toFixed(2) + ' DZD', st.phone].join('\n')
      : ['KHALDI PLAST', U.invFull(s) + (s.voided ? ' (VOID)' : ''), s.date, 'TOTAL ' + (s.total / 100).toFixed(2) + ' DZD', 'PAID ' + (paid / 100).toFixed(2) + ' DZD', 'DUE ' + (rem / 100).toFixed(2) + ' DZD', st.phone].join('\n');
    var qr = ''; try { qr = window.KPQR ? window.KPQR.svg(qrTxt, { level: 'M' }) : ''; } catch (e) { qr = ''; }
    var due = s.dueDate ? '<bdi class="num">' + esc(K.fmtDate(s.dueDate)) + '</bdi>' : '';
    var web = st.website || 'www.khaldiplast.dz';
    var h = '<div class="ivfit" dir="ltr"><div class="ivx" dir="rtl">' + swoosh() + '<img class="ivx-crates" src="img/inv_crates.jpg" alt="">';
    /* header */
    h += '<div class="ivx-head"><img class="ivx-logo" src="img/logo_full.png" alt="KHALDI PLAST"><div class="ivx-ar">خالدي بلاست</div><div class="ivx-sub">تصنيع الصناديق البلاستيكية</div></div>';
    h += '<div class="ivx-title"><span class="ivx-tt"><b>' + (qm ? qm.title : t('inv_word')) + '</b><em>' + (qm ? 'DEVIS' : 'INVOICE') + '</em></span><span class="ivx-ti">' + ico('note', 38) + '</span></div>';
    /* meta + customer */
    h += '<div class="ivx-mid"><div class="ivx-meta">' +
      '<div class="mr"><span>' + t('invoice_no') + ' :</span><b class="pillx" dir="ltr">' + esc(no) + '</b></div>' +
      '<div class="mr"><span>' + t('date') + ' :</span><b class="pillx"><bdi class="num">' + esc(K.fmtDate(s.date)) + '</bdi></b></div>' +
      (qm ? (qm.meta || '') : '<div class="mr"><span>' + t('inv_due') + ' :</span><b class="pillx">' + (due || '<i class="dots s"></i>') + '</b></div>') + '</div>' +
      '<div class="ivx-cust"><div class="tab"><span class="ci">' + ico('user', 20) + '</span><b>' + t('inv_customer_info') + '</b></div><div class="rows">' +
      '<div><span class="k">' + ico('building', 17) + t('customer_name') + ' :</span><span class="v">' + dots(esc(qm && qm.customer ? qm.customer : (s.customerId ? U.custName(s.customerId) : ''))) + '</span></div>' +
      '<div><span class="k">' + ico('pin', 17) + t('place_address') + ' :</span><span class="v">' + dots(c && c.address ? esc(c.address) : '') + '</span></div>' +
      '<div><span class="k">' + ico('phone', 17) + t('phone_number') + ' :</span><span class="v">' + dots(c && c.phone ? '<bdi class="num">' + esc(c.phone) + '</bdi>' : '') + '</span></div>' +
      '<div><span class="k">' + ico('card', 17) + t('inv_nif') + ' :</span><span class="v">' + dots(c && c.nif ? '<bdi class="num">' + esc(c.nif) + '</bdi>' : '') + '</span></div></div></div></div>';
    /* table */
    h += '<table class="ivx-t"><thead><tr><th class="n">' + t('inv_no_col') + '</th><th class="p">' + t('inv_items_col') + '</th><th class="q">' + t('quantity') + '</th><th class="u">' + t('unit_price') + '<small>(' + t('dzd_short') + ')</small></th><th class="a">' + t('inv_amount_col') + '<small>(' + t('dzd_short') + ')</small></th></tr></thead><tbody>' +
      s.items.map(function (i, k) {
        var p = K.byId(D.products, i.productId), wg = i.weightG || (p && p.weightG) || 0, spec = [p && p.code ? esc(p.code) : '', p && p.spec ? esc(p.spec) : (wg ? wg + ' ' + t('gram') : '')].filter(Boolean).join(' · ');
        return '<tr><td class="n">' + ('0' + (k + 1)).slice(-2) + '</td><td class="p">' + esc(U.prodName(i.productId)) + (spec ? '<small>' + spec + '</small>' : '') + '</td><td class="q"><bdi class="num">' + K.fmtQty(i.qty) + '</bdi></td><td class="u">' + money2(i.unitPrice) + '</td><td class="a">' + money2(Math.round(i.qty * i.unitPrice)) + '</td></tr>';
      }).join('') + '</tbody></table>';
    /* totals + notes */
    var tot = '<div class="tr"><span>' + t('inv_subtotal') + '</span><b>' + money2(s.subtotal) + ' <u>' + t('dzd_short') + '</u></b></div>' +
      (s.discount ? '<div class="tr"><span>' + t('discount') + '</span><b>' + money2(s.discount) + ' <u>' + t('dzd_short') + '</u></b></div>' : '') +
      '<div class="tr grand"><span>' + t('inv_grand') + '</span><b>' + money2(s.total) + ' <u>' + t('dzd_short') + '</u></b></div>' +
      (qm ? '' : '<div class="tr sm"><span>' + t('paid') + ' (' + (method ? U.methodLabel(method) : t('on_credit')) + ')</span><b>' + money2(paid) + ' <u>' + t('dzd_short') + '</u></b></div><div class="tr sm"><span>' + t('remaining') + '</span><b>' + money2(rem) + ' <u>' + t('dzd_short') + '</u></b></div>');
    h += '<div class="ivx-two"><div class="ivx-notes"><div class="tab"><span class="ci">' + ico('note', 20) + '</span><b>' + t('inv_notes') + ' :</b></div><ul>' +
      notes.slice(0, 5).map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + (notes.length < 3 ? '<li class="dl"></li>' : '') + '</ul></div><div class="ivx-tot">' + tot + '</div></div>';
    /* footer */
    h += '<div class="ivx-foot"><div class="ivx-sign"><div class="sh"><span class="ci">' + ico('check', 22) + '</span><b>' + t('inv_sign_stamp') + '</b></div></div>' +
      '<div class="ivx-contact"><div class="ct"><div><span>' + ico('pin', 18) + '</span><b>' + esc(st.address) + '</b></div><div><span>' + ico('phone', 18) + '</span><b class="num" dir="ltr">' + esc(st.phone) + '</b></div><div><span>' + ico('mail', 18) + '</span><b dir="ltr">' + esc(st.email) + '</b></div><div><span>' + ico('globe', 18) + '</span><b dir="ltr">' + esc(web) + '</b></div></div>' +
      (qr ? '<div class="qrbox noprintx" dir="ltr" data-act="qr_big" data-id="' + esc(no) + '">' + qr + '</div>' : '') + '</div></div>';
    return h + '</div></div>';
  };
  U.extraActions.qr_big = function () {
    var q = document.querySelector('.ivx .qrbox svg'), n = document.querySelector('.ivx .qrbox'); if (!q) return;
    U.showModal('<div class="qrbig"><b>' + t('qr_title') + '</b><div class="q">' + q.outerHTML + '</div><small>' + esc(n.dataset.id) + '</small><div class="muted" style="text-align:center">' + t('qr_help') + '</div></div><div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
  };
  /* scale the fixed A4 page to the available width */
  function fit() {
    var f = document.querySelector('.ivfit'); if (!f) return;
    var p = f.querySelector('.ivx'), cs = getComputedStyle(f.parentNode), w = (f.parentNode.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0)) || 360, k = Math.min(1, w / 794);
    p.style.transform = 'scale(' + k + ')'; f.style.height = Math.ceil(p.offsetHeight * k) + 'px'; f.style.width = Math.floor(794 * k) + 'px';
  }
  U.fitInvoice = fit;
  var prev = U.afterRender;
  U.afterRender = function (R) { if (prev) prev(R); fit(); };
  window.addEventListener('resize', fit);
  window.addEventListener('beforeprint', function () { var f = document.querySelector('.ivfit'); if (f) { f.style.height = ''; f.style.width = ''; } });
  window.addEventListener('afterprint', fit);
})();
