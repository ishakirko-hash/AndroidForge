/* KHALDI PLAST v2.2 - smart analysis of the whole company. Pure UI over K.analysis (core3.js): every number is computed from the real records,
   the health score shows its own weights, and nothing is estimated unless the data supports it. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, X = U.extraActions, S = U.S;
  function B(v) { return '<bdi class="num" dir="ltr">' + v + '</bdi>'; }
  function today() { return K.today(); }
  function plain(c) { return K.fmtMoney(c) + ' ' + t('dzd'); }
  function printNow(name) { setTimeout(function () { if (U.AND && U.AND.printPage) U.AND.printPage(name); else window.print(); }, 150); }
  function share(txt) {
    if (U.AND && U.AND.shareText) U.AND.shareText(txt);
    else if (navigator.share) navigator.share({ text: txt }).catch(function () {});
    else if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { U.toast(t('copied'), 'ok'); });
  }
  var LV = { excellent: '#2E9E57', good: '#1E6FE8', watch: '#F59E2C', critical: '#E04A3C', nodata: '#8A97AB' };
  function delta(p, inv) {
    if (p == null) return '<span class="an-d nil">—</span>';
    var good = inv ? p <= 0 : p >= 0;
    return '<span class="an-d ' + (good ? 'up' : 'dn') + '">' + (p >= 0 ? '▲' : '▼') + ' ' + B(Math.abs(p) + '%') + '</span>';
  }
  function kpi(cls, icon, label, val, p, inv, route) {
    return '<div class="kpi bg-' + cls + (route ? ' tap' : '') + '"' + (route ? ' data-act="an_go" data-id="' + route + '" role="button"' : '') + '><div class="kt"><span class="ki">' + V.icon(icon, 22) + '</span><span class="kl">' + esc(label) + '</span></div><div class="kv2">' + val + '</div><div class="kn">' + delta(p, inv) + '<span>' + esc(t('an_vs_prev')) + '</span></div></div>';
  }
  function ring(score, level) {
    var R = 52, C = 2 * Math.PI * R, v = score == null ? 0 : score;
    return '<svg class="an-ring" viewBox="0 0 130 130" role="img" aria-label="' + (score == null ? '—' : score) + '"><circle cx="65" cy="65" r="' + R + '" fill="none" stroke="rgba(120,140,170,.22)" stroke-width="12"/><circle cx="65" cy="65" r="' + R + '" fill="none" stroke="' + LV[level] + '" stroke-width="12" stroke-linecap="round" stroke-dasharray="' + (C * v / 100).toFixed(1) + ' ' + C.toFixed(1) + '" transform="rotate(-90 65 65)"/>' +
      '<text x="65" y="70" text-anchor="middle" class="an-rt">' + (score == null ? '—' : score) + '</text><text x="65" y="90" text-anchor="middle" class="an-rs">/100</text></svg>';
  }
  function hrow(label, share, valHtml, cls) { return '<div class="an-hr"><span class="an-hl">' + label + '</span><span class="an-hb"><i class="' + (cls || '') + '" style="width:' + Math.max(0, Math.min(100, share)) + '%"></i></span><b>' + valHtml + '</b></div>'; }

  function recText(r) {
    var p = {}; Object.keys(r.params || {}).forEach(function (k) { p[k] = r.params[k]; });
    if (p.amount != null) p.amount = plain(p.amount);
    if (r.id === 'expense_jump') p.name = p.key && U.hasKey('cat_' + p.key) ? t('cat_' + p.key) : p.name;
    return t('an_r_' + r.id, p);
  }
  var SEVC = { high: 'red', med: 'amber', low: '', good: 'green' };

  function trendSvg(series) {
    var W0 = 300, H0 = 130, L = 8, Rr = 8, T = 10, Bt = 22, iw = W0 - L - Rr, ih = H0 - T - Bt, mx = 1;
    series.forEach(function (s) { mx = Math.max(mx, s.sales, s.purchases, s.expenses); });
    var gw = iw / series.length, bw = Math.max(5, gw / 4.2), out = '';
    series.forEach(function (s, i) {
      var x0 = L + gw * i + (gw - bw * 3 - 4) / 2;
      [[s.sales, 'an-b1'], [s.purchases, 'an-b2'], [s.expenses, 'an-b3']].forEach(function (b, k) { var h = Math.round(b[0] * ih / mx); out += '<rect class="' + b[1] + '" x="' + (x0 + k * (bw + 2)).toFixed(1) + '" y="' + (T + ih - h) + '" width="' + bw.toFixed(1) + '" height="' + h + '" rx="2"/>'; });
      out += '<text x="' + (L + gw * i + gw / 2).toFixed(1) + '" y="' + (H0 - 6) + '" text-anchor="middle" class="an-gt">' + esc(U.monthShort ? U.monthShort(s.ym) : s.ym.slice(5)) + '</text>';
    });
    return '<svg viewBox="0 0 ' + W0 + ' ' + H0 + '" class="an-chart" dir="ltr" role="img" aria-label="' + esc(t('an_trend')) + '">' + out + '</svg>' +
      '<div class="an-leg"><span><i class="an-b1"></i>' + esc(t('an_sales')) + '</span><span><i class="an-b2"></i>' + esc(t('an_purchases')) + '</span><span><i class="an-b3"></i>' + esc(t('an_expenses')) + '</span></div>';
  }
  function ageBar(b, total) {
    if (!total) return '';
    var cls = ['an-a0', 'an-a1', 'an-a2', 'an-a3'];
    return '<div class="an-age">' + b.map(function (v, i) { return v > 0 ? '<i class="' + cls[i] + '" style="width:' + (v * 100 / total).toFixed(1) + '%"></i>' : ''; }).join('') + '</div><div class="an-leg">' +
      b.map(function (v, i) { return '<span><i class="' + cls[i] + '"></i>' + esc(t('an_b' + i)) + ' ' + B(K.fmtMoney(v)) + '</span>'; }).join('') + '</div>';
  }

  W.analysis = function () {
    var D = U.D, N = S.anDays || 30, a = K.analysis(D, today(), N), h = '', hl = a.health;
    var title = t('an_period', { from: K.fmtDate(a.from), to: K.fmtDate(a.to) });
    h += '<div class="muted" style="margin:0 2px 8px">' + esc(t('an_help')) + '</div>';
    h += U.chips([['7', t('an_d7')], ['30', t('an_d30')], ['90', t('an_d90')], ['365', t('an_d365')]], String(N), 'an_days');
    /* ---- health ---- */
    h += '<div class="card an-health"><div class="an-hrow">' + ring(hl.score, hl.level) + '<div class="an-hm"><div class="an-hlvl" style="color:' + LV[hl.level] + '">' + esc(t('an_lv_' + hl.level)) + '</div><div class="muted">' + esc(t('an_health')) + '</div><small class="muted">' + esc(title) + '</small></div></div>';
    h += '<div class="an-comps">' + hl.components.map(function (c) {
      var val = c.value == null ? '—' : c.id === 'profit' ? B(c.value + '%') : c.id === 'collect' ? B(c.value + '%') : c.id === 'growth' ? B((c.value > 0 ? '+' : '') + c.value + '%') : c.id === 'quality' ? B(c.value + '%') : c.id === 'stock' ? B(c.value) : B(c.value);
      return '<div class="an-comp"><span class="an-cl">' + esc(t('an_c_' + c.id)) + ' <small>(' + c.weight + '%)</small></span><span class="an-hb"><i class="' + (c.score == null ? '' : c.score >= 70 ? 'g' : c.score >= 40 ? 'a' : 'r') + '" style="width:' + (c.score == null ? 0 : c.score) + '%"></i></span><b>' + (c.score == null ? '—' : B(c.score)) + '</b></div><div class="an-cn">' + esc(t('an_cn_' + c.id)) + ': ' + val + '</div>';
    }).join('') + '</div><small class="muted">' + esc(t('an_health_note')) + '</small></div>';
    /* ---- KPIs ---- */
    var k = a.kpis;
    h += '<div class="kpis4">' + kpi('blue', 'bars', t('an_sales'), U.money(k.sales.cur), k.sales.pct, false, 'sales') + kpi('green', 'download', t('an_collected'), U.money(k.collected.cur), k.collected.pct, false, 'collect') +
      kpi('amber', 'truck', t('an_purchases'), U.money(k.purchases.cur), k.purchases.pct, true, 'purchtable') + kpi('red', 'wallet', t('an_expenses'), U.money(k.expenses.cur), k.expenses.pct, true, 'expenses') + '</div>';
    h += '<div class="statgrid">' + '<div><small>' + esc(t('an_profit_est')) + '</small><b class="' + (k.profit.cur != null && k.profit.cur < 0 ? 'red' : '') + '">' + (k.profit.cur == null ? '—' : U.money(k.profit.cur)) + '</b></div>' +
      '<div><small>' + esc(t('an_margin')) + '</small><b>' + (a.margin == null ? '—' : B(a.margin + '%')) + '</b></div><div><small>' + esc(t('an_crates')) + '</small><b>' + B(K.groupInt(k.good.cur)) + '</b></div></div>';
    if (k.profit.cur == null) h += '<div class="muted" style="margin:-4px 2px 10px">' + esc(t('an_profit_unknown')) + '</div>';
    /* ---- recommendations ---- */
    h += U.sec(t('an_recs'));
    if (!a.recommendations.length) h += '<div class="card">' + U.empty(t('an_no_recs'), 'check') + '</div>';
    else h += '<div class="card">' + a.recommendations.map(function (r) {
      var go = r.route ? ' tap" data-act="an_go" data-id="' + r.route : '';
      return '<div class="row' + go + '"><div class="ibox ' + SEVC[r.sev] + '">' + V.icon(r.icon, 22) + '</div><div class="main"><div class="t" style="font-weight:600">' + esc(recText(r)) + '</div><div class="s">' + U.badge(t('an_sev_' + r.sev), SEVC[r.sev] || 'gray') + '</div></div>' + (r.route ? '<div class="r">' + V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 20) + '</div>' : '') + '</div>';
    }).join('') + '</div>';
    /* ---- trend ---- */
    h += U.sec(t('an_trend')) + '<div class="card">' + trendSvg(a.series) + '</div>';
    /* ---- sales ---- */
    h += U.sec(t('an_sales_sec'));
    var prods = a.products.filter(function (p) { return p.revenue > 0 || p.product.stock > 0; });
    h += '<div class="card"><h4 class="an-h4">' + esc(t('an_by_product')) + '</h4>' + (prods.length ? prods.map(function (p) {
      return hrow(esc(p.product.name), p.share, B(p.share + '%') + ' · ' + B(K.groupInt(p.qty)), 'b') + '<div class="an-sub">' + esc(t('an_avg_price')) + ' ' + B(K.fmtMoney(p.avgPrice)) + (p.cover != null ? ' · ' + esc(t('an_cover', { n: Math.floor(p.cover) })) : '') + (p.dead ? ' · ' + esc(t('an_dead')) : '') + '</div>';
    }).join('') : U.empty(t('no_records'), 'box')) + '</div>';
    var wmax = Math.max.apply(null, a.weekday.concat([1]));
    h += '<div class="card"><h4 class="an-h4">' + esc(t('an_by_day')) + '</h4><div class="an-wd">' + a.weekday.map(function (v, i) { return '<div class="an-wc"><i style="height:' + Math.round(v * 70 / wmax) + 'px"></i><span>' + esc(U.lang() === 'ar' ? t('p_dow' + i) : t('p_dow' + i).slice(0, 3)) + '</span></div>'; }).join('') + '</div></div>';
    /* ---- customers ---- */
    var c = a.customers, sg = c.segments;
    h += U.sec(t('an_customers_sec')) + '<div class="card"><h4 class="an-h4">' + esc(t('an_top_customers')) + '</h4>' + (c.top.length ? c.top.map(function (x) { return hrow(esc(x.customer ? x.customer.name : ''), x.share, B(x.share + '%') + ' · ' + B(K.fmtMoney(x.revenue)), 'b'); }).join('') : U.empty(t('no_records'), 'users')) +
      (c.walkin > 0 ? '<div class="an-sub">' + esc(t('an_walkin')) + ': ' + U.money(c.walkin) + '</div>' : '') + (c.top.length >= 3 ? '<div class="an-sub">' + esc(t('an_top3', { pct: c.top3Share })) + '</div>' : '') + '</div>';
    h += '<div class="card"><h4 class="an-h4">' + esc(t('an_segments')) + '</h4><div class="an-segs">' + ['vip', 'active', 'new', 'dormant', 'risk', 'prospect'].map(function (s) { return '<div class="an-sg sg-' + s + '" data-act="an_seg" data-id="' + s + '" role="button"><b>' + B(sg[s]) + '</b><span>' + esc(t('crm_sg_' + s)) + '</span></div>'; }).join('') + '</div>' +
      (c.avgCollectDays != null ? '<div class="rpt-kv"><span>' + esc(t('an_collect_days')) + '</span><b>' + B(c.avgCollectDays) + ' ' + esc(t('days')) + '</b></div>' : '') +
      (c.dormant.length ? '<h4 class="an-h4" style="margin-top:10px">' + esc(t('an_dormant_list')) + '</h4>' + c.dormant.slice(0, 3).map(function (r) { return '<div class="rpt-kv"><span>' + esc(r.customer.name) + '</span><b>' + esc(t('crm_days_ago', { n: r.daysSince })) + '</b></div>'; }).join('') : '') + '</div>';
    var ls = a.leads;
    h += '<div class="card"><h4 class="an-h4">' + esc(t('crm_tab_funnel')) + '</h4>' + (ls.total ? '<div class="statgrid">' + '<div><small>' + esc(t('crm_open_leads')) + '</small><b>' + B(ls.open) + '</b></div><div><small>' + esc(t('crm_pipeline')) + '</small><b>' + U.money(ls.pipeline) + '</b></div><div><small>' + esc(t('crm_conversion')) + '</small><b>' + (ls.conversion == null ? '—' : B(ls.conversion + '%')) + '</b></div></div>' : U.empty(t('crm_no_leads'), 'phone')) + '<div class="btns"><button class="btn" data-act="an_go" data-id="crm">' + esc(t('tile_crm')) + '</button></div></div>';
    /* ---- costs ---- */
    h += U.sec(t('an_costs_sec')) + '<div class="card"><h4 class="an-h4">' + esc(t('an_exp_cats')) + '</h4>' + (a.expenses.length ? a.expenses.map(function (e) {
      var nm = e.key && U.hasKey('cat_' + e.key) ? t('cat_' + e.key) : e.name;
      return hrow(esc(nm), e.share, B(e.share + '%') + ' · ' + B(K.fmtMoney(e.amount)), 'r') + (e.change != null ? '<div class="an-sub">' + delta(e.change, true) + ' ' + esc(t('an_vs_prev')) + '</div>' : '');
    }).join('') : U.empty(t('no_records'), 'wallet')) + '</div>';
    var pa = a.purchases.byMaterial;
    if (pa.length) h += '<div class="card"><h4 class="an-h4">' + esc(t('an_material_prices')) + '</h4>' + pa.slice(0, 5).map(function (m) { return '<div class="rpt-kv"><span>' + esc(m.material) + '</span><b>' + B(K.fmtMoney(m.last)) + ' ' + (m.change == null ? '' : delta(m.change, true)) + '</b></div>'; }).join('') + '<div class="btns"><button class="btn" data-act="an_go" data-id="purchtable">' + esc(t('tile_purchtable')) + '</button></div></div>';
    /* ---- cash & debts ---- */
    var rc = a.receivables;
    h += U.sec(t('an_cash_sec')) + '<div class="card"><div class="statgrid"><div><small>' + esc(t('an_cash_in')) + '</small><b class="green">' + U.money(a.cash.in) + '</b></div><div><small>' + esc(t('an_cash_out')) + '</small><b class="red">' + U.money(a.cash.out) + '</b></div><div><small>' + esc(t('an_cash_net')) + '</small><b class="' + (a.cash.net < 0 ? 'red' : 'green') + '">' + U.money(a.cash.net) + '</b></div></div>' +
      '<div class="rpt-kv"><span>' + esc(t('an_receivables')) + '</span><b>' + U.money(rc.total) + '</b></div>' + ageBar(rc.buckets, rc.total) + '<div class="rpt-kv"><span>' + esc(t('an_payables')) + '</span><b>' + U.money(a.payables) + '</b></div></div>';
    /* ---- stock ---- */
    var mats = a.materials.filter(function (m) { return m.status !== 'nodata'; });
    h += U.sec(t('an_stock_sec')) + '<div class="card"><h4 class="an-h4">' + esc(t('an_raw_cover')) + '</h4>' + (mats.length ? mats.map(function (m) { return hrow(esc(m.material.name), Math.min(100, m.cover * 100 / 30), B(Math.floor(m.cover)) + ' ' + esc(t('days')), m.status === 'critical' ? 'r' : m.status === 'soon' ? 'a' : 'g'); }).join('') : '<div class="muted">' + esc(t('an_no_usage')) + '</div>') +
      '<div class="btns"><button class="btn" data-act="an_go" data-id="forecast">' + esc(t('tile_forecast')) + '</button></div></div>';
    /* ---- production ---- */
    var pr = a.production;
    h += U.sec(t('an_prod_sec')) + '<div class="card"><div class="statgrid"><div><small>' + esc(t('an_crates')) + '</small><b>' + B(K.groupInt(pr.good)) + '</b></div><div><small>' + esc(t('an_per_day')) + '</small><b>' + B(K.groupInt(pr.perDay)) + '</b></div><div><small>' + esc(t('an_defect')) + '</small><b class="' + (pr.defectPct != null && pr.defectPct > 5 ? 'red' : '') + '">' + (pr.defectPct == null ? '—' : B(pr.defectPct + '%')) + '</b></div></div>' +
      (pr.prevDefectPct != null && pr.defectPct != null ? '<div class="rpt-kv"><span>' + esc(t('an_defect_prev')) + '</span><b>' + B(pr.prevDefectPct + '%') + '</b></div>' : '') + (pr.defectCost > 0 ? '<div class="rpt-kv"><span>' + esc(t('an_defect_cost')) + '</span><b>' + U.money(pr.defectCost) + '</b></div>' : '') +
      (pr.good > 0 ? '<div class="rpt-kv"><span>' + esc(t('an_by_shift')) + '</span><b>' + [1, 2, 3].map(function (s) { return esc(t('shift') + ' ' + s) + ' ' + B(K.groupInt(pr.byShift[s])); }).join(' · ') + '</b></div>' : '') + '</div>';
    h += '<div class="btns noprint"><button class="btn" data-act="an_print">' + V.icon('print', 18) + ' ' + t('p_print') + '</button><button class="btn primary" data-act="an_share">' + V.icon('share', 18) + ' ' + t('share') + '</button></div>';
    h += '<div class="muted" style="margin:6px 2px 14px">' + esc(t('an_footer')) + '</div>';
    return h;
  };
  X.an_days = function (el) { S.anDays = Number(el.dataset.id); U.render(true); };
  X.an_go = function (el) {
    var r = el.dataset.id;
    if (r === 'sales' || r === 'stock' || r === 'production') { U.stack = []; U.route = r; U.arg = null; U.render(); } else { if (r === 'reports') S.repTab = 'month'; U.go(r); }
  };
  X.an_seg = function (el) { S.crmTab = 'customers'; S.custSeg = el.dataset.id; U.go('crm'); };
  X.an_print = function () { printNow('KHALDI_PLAST_' + t('tile_analysis').replace(/\s+/g, '_') + '_' + today()); };
  X.an_share = function () {
    var a = K.analysis(U.D, today(), S.anDays || 30), k = a.kpis, L = [];
    L.push('KHALDI PLAST - ' + t('tile_analysis')); L.push(t('an_period', { from: K.fmtDate(a.from), to: K.fmtDate(a.to) }));
    L.push(t('an_health') + ': ' + (a.health.score == null ? '—' : a.health.score + '/100 (' + t('an_lv_' + a.health.level) + ')'));
    L.push(t('an_sales') + ': ' + plain(k.sales.cur) + (k.sales.pct != null ? ' (' + (k.sales.pct >= 0 ? '+' : '') + k.sales.pct + '%)' : ''));
    L.push(t('an_collected') + ': ' + plain(k.collected.cur)); L.push(t('an_purchases') + ': ' + plain(k.purchases.cur)); L.push(t('an_expenses') + ': ' + plain(k.expenses.cur));
    if (k.profit.cur != null) L.push(t('an_profit_est') + ': ' + plain(k.profit.cur) + (a.margin != null ? ' (' + a.margin + '%)' : ''));
    L.push(t('an_receivables') + ': ' + plain(a.receivables.total)); L.push(t('an_payables') + ': ' + plain(a.payables));
    if (a.recommendations.length) { L.push(''); L.push(t('an_recs') + ':'); a.recommendations.slice(0, 8).forEach(function (r, i) { L.push((i + 1) + '. ' + recText(r)); }); }
    share(L.join('\n'));
  };

  /* ---------- home widgets: health score and today's follow-ups ---------- */
  U.analysisWidget = function (z) {
    var a = K.analysis(U.D, today(), 30), hl = a.health;
    return { score: hl.score, level: hl.level, top: a.recommendations.slice(0, z === 'l' ? 4 : z === 'm' ? 2 : 1) };
  };
  U.hasKey = function (k) { return !!window.I18N[k]; };
})();
