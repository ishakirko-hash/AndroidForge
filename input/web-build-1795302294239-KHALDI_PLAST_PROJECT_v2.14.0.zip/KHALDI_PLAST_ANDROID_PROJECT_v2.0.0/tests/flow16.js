// v2.2.1: A4 invoice page; the QR text, scanned, opens the very same invoice in the app (FV- and INV- forms)
const L=require('./lib.js'), cp=require('child_process'), path=require('path'); const SH=process.env.SHOTS||'/tmp';
let pass=0,fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'}); await p.setViewportSize({width:390,height:1700});
 const ids=await p.evaluate(()=>{const U=window.KPU,K=U.K;let r=[];U.commit(d=>{d.products.forEach(q=>K.adjustStock(d,{date:K.today(),kind:'product',itemId:q.id,newStock:1000,note:'t'}));const c=K.addCustomer(d,{name:'Zed',phone:'0550'});
  for(let n=0;n<2;n++) r.push(K.recordSale(d,{date:K.today(),customerId:c.id,items:[{productId:d.products[0].id,qty:10+n,unitPrice:32000,weightG:0}],discount:0,paid:0,method:'cash'}).id);});return r;});
 const show=async i=>{ await p.evaluate(i=>{const U=window.KPU;U.stack=[];U.route='invoice';U.arg=i;U.render();},i); await p.waitForTimeout(120); };
 await show(ids[1]);
 // A4 proportions: design box is 794x1123, fitted to the screen width with the same ratio
 const g=await p.evaluate(()=>{const e=document.querySelector('.ivx'),r=e.getBoundingClientRect(),f=document.querySelector('.ivfit').getBoundingClientRect();return {w:r.width,h:r.height,fw:f.width,fh:f.height,lw:e.offsetWidth,lh:e.offsetHeight,qr:document.querySelector('.ivx .qrbox').getBoundingClientRect().width};});
 ok(g.lw===794 && g.lh===1123,'page design size is exactly A4 at 96dpi '+g.lw+'x'+g.lh);
 ok(Math.abs(g.h/g.w-1123/794)<0.01,'screen ratio equals A4 ratio '+(g.h/g.w).toFixed(3)); ok(g.fw<=390,'fits the screen width');
 ok((await p.locator('.ivx').innerText()).includes('INV-000002'),'shows INV-000002');
 // scanning: text exactly as encoded in the QR
 const txt=await p.evaluate(i=>{const U=window.KPU,K=U.K,s=K.byId(U.D.sales,i),paid=K.salePaid(U.D,i);return ['KHALDI PLAST',U.invFull(s),s.date,'TOTAL '+(s.total/100).toFixed(2)+' DZD','PAID '+(paid/100).toFixed(2)+' DZD','DUE '+((s.total-paid)/100).toFixed(2)+' DZD',U.D.settings.phone].join('\n');},ids[1]);
 await show(ids[0]); await p.evaluate(t=>window.KPScanResult(t),txt); await p.waitForTimeout(200);
 ok(await p.evaluate(i=>window.KPU.route==='invoice'&&window.KPU.arg===i,ids[1]),'scanning the QR text opens the same invoice');
 await p.evaluate(()=>window.KPScanResult('INV-000001')); await p.waitForTimeout(150);
 ok(await p.evaluate(i=>window.KPU.arg===i,ids[0]),'the printed number INV-000001 also opens its invoice');
 // QR is decodable by OpenCV at the size it is printed (116 css px = ~31 mm)
 await show(ids[1]);
 const svg=await p.locator('.ivx .qrbox svg').evaluate(e=>e.outerHTML);
 const png=path.join(SH,'qr16.png'); const ctx=await s.browser.newContext({viewport:{width:300,height:300},deviceScaleFactor:3}); const pg=await ctx.newPage();
 await pg.setContent('<body style="margin:0;background:#fff"><div style="padding:8px;width:116px;height:116px;box-sizing:content-box">'+svg.replace('<svg','<svg style="width:116px;height:116px;display:block"')+'</div></body>'); await pg.screenshot({path:png}); await ctx.close();
 const dec=cp.execFileSync('python3',['-I',path.join(__dirname,'qr_decode.py'),png]).toString(); ok(dec===txt,'OpenCV decodes the printed-size QR to the invoice text :: '+JSON.stringify(dec.split('\n')[1]));
 // tap on QR opens a big one
 await p.click('.ivx .qrbox'); await p.waitForTimeout(150); ok((await p.locator('.qrbig .q svg').count())===1,'tap on QR shows a big QR'); await p.evaluate(()=>window.KPU.closeModal());
 // widths + print layout
 for(const w of [360,390,412,820]){ await p.setViewportSize({width:w,height:1700}); await show(ids[1]); const o=await p.evaluate(()=>[document.documentElement.scrollWidth-document.documentElement.clientWidth,document.getElementById('main').scrollWidth-document.getElementById('main').clientWidth,document.querySelector('.ivfit').getBoundingClientRect().width]); ok(o[0]<=1&&o[1]<=1&&o[2]<=w,'no overflow @'+w+' '+o); }
 await p.setViewportSize({width:390,height:1700}); await show(ids[1]); await p.emulateMedia({media:'print'});
 const pr=await p.evaluate(()=>{const r=document.querySelector('.ivx').getBoundingClientRect();return [r.width,r.height];}); await p.emulateMedia({media:'screen'});
 ok(pr[0]/96*25.4<=194+0.5 && pr[1]/96*25.4<=281,'print size fits A4 minus 8mm margins '+pr.map(x=>(x/96*25.4).toFixed(0)+'mm'));
 // many items: page grows instead of breaking
 await p.evaluate(i=>{const U=window.KPU,K=U.K;U.commit(d=>{const pr=d.products;const sl=K.byId(d.sales,i);for(let k=0;k<10;k++)sl.items.push({productId:pr[k%pr.length].id,qty:1,unitPrice:1000,weightG:0});});window.KPU.render();},ids[1]); await p.waitForTimeout(100);
 ok(await p.evaluate(()=>document.querySelector('.ivx').offsetHeight>1123 && document.querySelector('.ivfit').getBoundingClientRect().height>0),'long invoice grows taller than one page and still renders');
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
