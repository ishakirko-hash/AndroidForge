// v3 dashboard engine
const L=require('./lib.js'); let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
(async()=>{ const s=await L.start(process.argv[2],390); const p=s.page; await p.waitForTimeout(700);
 const A=(n,d)=>p.evaluate(([n,d])=>window.KPU.extraActions[n]({dataset:d||{}}),[n,d]);
 const items=()=>p.evaluate(()=>window.KPU.D.settings.dash.layouts.find(l=>l.id===window.KPU.D.settings.dash.active).items.map(i=>i.k+':'+i.z));
 const go=async(r)=>{await p.evaluate((r)=>{const U=window.KPU;U.stack=[];U.route=r;U.arg=null;U.render();},r);await p.waitForTimeout(300)};
 await go('home'); ok(await p.locator('.dgrid .dc').count()>0,'home renders grid cards ('+(await p.locator('.dgrid .dc').count())+')');
 ok((await p.evaluate(()=>!!window.KPU.D.settings.dash))===true,'dash layout persisted');
 const n0=(await items()).length;
 // registry sanity: every widget renders without throwing at every size
 const bad=await p.evaluate(()=>{const U=window.KPU,K=U.K,R=U._dash.REG,out=[];const d=K.dashboard(U.D,K.today());Object.keys(R).forEach(k=>['s','m','l'].forEach(z=>{try{const h=R[k].r(d,z,{});if(h===undefined||/undefined|NaN/.test(h))out.push(k+':'+z)}catch(e){out.push(k+':'+z+':'+e.message)}}));return out});
 ok(bad.length===0,'all registry widgets render at s/m/l '+JSON.stringify(bad));
 // enter edit
 await A('dash_edit'); await p.waitForTimeout(300); ok(await p.locator('.dgrid.ed').count()===1,'edit mode on'); ok(await p.locator('.dc-dh').count()===n0,'drag handle on every card');
 // select + resize via dock
 const k0=await p.locator('.dc').first().getAttribute('data-k'); await A('dc_sel',{k:k0}); await p.waitForTimeout(250); ok(await p.locator('.dc.sel').count()===1,'select card');
 await A('dk_setsize',{s:'l'}); await p.waitForTimeout(250); ok((await items())[0]===k0+':l','resize saved');
 // move later
 await A('dk_next'); await p.waitForTimeout(250); ok((await items())[1].startsWith(k0+':'),'move later');
 // undo
 await A('dash_undo'); await p.waitForTimeout(200); ok((await items())[0].startsWith(k0+':'),'undo move');
 // real drag with mouse on handle
 await p.evaluate(()=>window.KPU.closeModal&&window.KPU.closeModal());
 const before=await items(); const h1=p.locator('.dc').nth(0).locator('.dc-dh'); await h1.scrollIntoViewIfNeeded(); const b1=await h1.boundingBox(); const t2=await p.locator('.dc').nth(2).boundingBox();
 await p.mouse.move(b1.x+b1.width/2,b1.y+b1.height/2); await p.mouse.down(); await p.mouse.move(t2.x+t2.width/2,t2.y+t2.height*0.7,{steps:12}); await p.waitForTimeout(200); ok(await p.locator('.dc-ph').count()===1,'placeholder visible while dragging'); await p.mouse.up(); await p.waitForTimeout(400);
 const after=await items(); ok(JSON.stringify(before)!==JSON.stringify(after)&&after.length===before.length,'drag & drop reorders ('+before[0]+' -> idx '+after.findIndex(x=>x.startsWith(before[0].split(':')[0]+':'))+')');
 // resize by dragging handle
 const rk=await p.locator('.dc').nth(1).getAttribute('data-k'); const z0=(await items()).find(x=>x.startsWith(rk+':')); const rh=p.locator('.dc').nth(1).locator('.dc-rh'); await rh.scrollIntoViewIfNeeded(); const rb=await rh.boundingBox();
 await p.mouse.move(rb.x+rb.width/2,rb.y+rb.height/2); await p.mouse.down(); await p.mouse.move(rb.x+160,rb.y-110,{steps:10}); await p.mouse.up(); await p.waitForTimeout(400);
 ok((await items()).find(x=>x.startsWith(rk+':'))!==z0,'resize by dragging handle ('+z0+' -> '+(await items()).find(x=>x.startsWith(rk+':'))+')');
 // overlap check: no card rects overlap
 const ov=await p.evaluate(()=>{const r=[...document.querySelectorAll('.dgrid .dc')].map(e=>e.getBoundingClientRect());let n=0;for(let i=0;i<r.length;i++)for(let j=i+1;j<r.length;j++){const a=r[i],b=r[j];if(a.left<b.right-1&&b.left<a.right-1&&a.top<b.bottom-1&&b.top<a.bottom-1)n++}return n});
 ok(ov===0,'no overlapping cards ('+ov+')');
 // delete + hide + restore via library
 const dk=await p.locator('.dc').last().getAttribute('data-k'); await A('dc_del',{k:dk}); await p.waitForTimeout(200); ok(!(await items()).some(x=>x.startsWith(dk+':')),'delete card');
 await A('dk_add'); await p.waitForTimeout(300); ok((await p.evaluate(()=>window.KPU.route))==='widgets','library opens'); ok(await p.locator('.lib-i').count()>40,'library has many widgets ('+await p.locator('.lib-i').count()+')');
 await p.fill('.lib-s input','الآلات'); await p.waitForTimeout(300); ok(await p.locator('.lib-i').count()>0&&await p.locator('.lib-i').count()<12,'library search');
 await p.fill('.lib-s input',''); await A('lib_cat',{id:'mach'}); await p.waitForTimeout(250); ok(await p.locator('.lib-i').count()>=4,'category filter machines');
 await A('lib_add',{k:'mmprod'}); await p.waitForTimeout(200); ok((await items()).some(x=>x.startsWith('mmprod:')),'add widget from library');
 await A('lib_add',{k:'sc:machmon'}); await p.waitForTimeout(200); ok((await items()).some(x=>x==='sc:machmon:xs'),'add shortcut widget');
 await p.evaluate(()=>window.KPU.back()); await p.waitForTimeout(300);
 // hide via config
 await A('dc_sel',{k:'mmprod'}); await A('dk_cfg'); await p.waitForTimeout(250); await p.selectOption('#f_hid','1'); await p.click('#f button[type=submit]'); await p.waitForTimeout(300);
 ok((await p.evaluate(()=>window.KPU.D.settings.dash.layouts[0].items.find(i=>i.k==='mmprod').h))===1,'hide keeps widget');
 // preview + done
 await A('dash_prev'); await p.waitForTimeout(200); ok(await p.locator('.dgrid.ed').count()===0&&await p.locator('.dprev-back').count()===1,'preview mode'); await A('dash_prev');
 await A('dash_done'); await p.waitForTimeout(250); ok(await p.locator('.dc-dh').count()===0,'view mode has no edit chrome'); ok(await p.locator('.dc[data-k="mmprod"]').count()===0,'hidden widget not shown in view');
 // layouts
 await go('dashmgr'); await A('dm_new',{id:'production'}); await p.waitForTimeout(250); ok((await p.evaluate(()=>window.KPU.D.settings.dash.layouts.length))===2,'new layout from template');
 await go('home'); ok(await p.locator('.dl-c').count()===2,'layout switcher chips'); const act=await p.evaluate(()=>window.KPU.D.settings.dash.active);
 await A('dm_use',{id:'main'}); await p.waitForTimeout(250); ok((await p.evaluate(()=>window.KPU.D.settings.dash.active))==='main','switch layout');
 await A('dm_dup',{id:'main'}); ok((await p.evaluate(()=>window.KPU.D.settings.dash.layouts.length))===3,'duplicate layout');
 await go('dashmgr'); await A('dm_export'); await p.waitForTimeout(200); const ex=await p.locator('textarea').inputValue(); ok(JSON.parse(ex).layouts.length===3,'export JSON'); await p.evaluate(()=>window.KPU.closeModal());
 // persistence
 const snap=await p.evaluate(()=>JSON.stringify(window.KPU.D.settings.dash)); await p.reload(); await p.waitForTimeout(900); ok((await p.evaluate(()=>JSON.stringify(window.KPU.D.settings.dash)))===snap,'layouts persist after reload');
 // old customize route + long press
 await go('customize'); ok((await p.locator('.dm-r').count())===3,'customize page = layouts manager');
 await go('home'); ok(await p.locator('.hhero').count()===1,'hero shown in view mode');
 // no overflow horizontal
 ok(await p.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1),'no horizontal overflow');
 await p.setViewportSize({width:390,height:2400}); await p.evaluate(()=>{const U=window.KPU;U.commit(d=>{const l=d.settings.dash.layouts[0];l.items=U._dash.TPL.manager.l.map(s=>{const a=s.split(':');return {k:a[0],z:a[1]}}).concat([{k:'prodx',z:'m'},{k:'salesx',z:'m'},{k:'stockx',z:'s'},{k:'mmstops',z:'w'},{k:'flow',z:'w'},{k:'sc:machmon',z:'xs'},{k:'sc:distribution',z:'xs'}]).filter(i=>U._dash.regOf(i.k))});U.render(true)}); await p.waitForTimeout(400); await p.screenshot({path:'/tmp/dash_view.png'});
 await A('dash_edit'); await p.waitForTimeout(400); await p.screenshot({path:'/tmp/dash_edit.png'});
 await go('widgets'); await p.waitForTimeout(300); await p.screenshot({path:'/tmp/dash_lib.png'});
 ok(s.errors.length===0,'no JS errors '+JSON.stringify(s.errors)); console.log('pass',pass,'fail',fail); await s.close(); })();
