// Run with:  node tests/test_core3.js   (v2.2 CRM, purchases table, company analysis)
const K = require('../app/src/main/assets/www/core3.js');
let pass = 0, fail = 0;
function ok(c, n) { if (c) pass++; else { fail++; console.log('FAIL:', n); } }
function eq(a, b, n) { if (JSON.stringify(a) === JSON.stringify(b)) pass++; else { fail++; console.log('FAIL:', n, '\n  got', JSON.stringify(a), '\n  exp', JSON.stringify(b)); } }
function throws(fn, code, n) { try { fn(); fail++; console.log('FAIL (no error):', n); } catch (e) { if (e.code === code) pass++; else { fail++; console.log('FAIL', n, 'got', e.code || e.message); } } }
const T = '2026-10-30';
let d = K.emptyData(); const P = d.products[0].id, P2 = d.products[1].id, M = d.materials[0].id, M2 = d.materials[1].id;

/* ---- phone / name normalisation & duplicates ---- */
eq(K.normPhone('0798 58 74 64'), '798587464', 'local phone'); eq(K.normPhone('+213 798-587-464'), '798587464', 'international phone'); eq(K.normPhone('00213798587464'), '798587464', '00213 prefix'); eq(K.normPhone('٠٧٩٨٥٨٧٤٦٤'), '798587464', 'arabic digits'); eq(K.normPhone('123'), '', 'too short');
eq(K.normName('  أَحْمَد  '), K.normName('احمد'), 'diacritics/alef'); ok(K.normName('فاطمة') === K.normName('فاطمه'), 'ta marbuta');
d = K.tx(d, x => { K.addCustomer(x, { name: 'Ahmed Benali', phone: '0550 11 22 33' }); K.addSupplier(x, { name: 'Plast Import', phone: '0770 00 11 22' }); });
let dup = K.findDuplicates(d, { name: 'Other', phone: '+213550112233' }); ok(dup.length === 1 && dup[0].reason === 'phone' && dup[0].strong && dup[0].kind === 'customer', 'same phone found (international format)');
dup = K.findDuplicates(d, { name: 'ahmed  BENALI' }); ok(dup.length === 1 && dup[0].reason === 'name' && dup[0].strong, 'same name found, case/space insensitive');
dup = K.findDuplicates(d, { name: 'Ahmed' }); ok(dup.length === 1 && !dup[0].strong, 'partial name = weak match'); eq(K.findDuplicates(d, { name: 'Zed Zed', phone: '0661 99 88 77' }).length, 0, 'unrelated: no match');
ok(K.findDuplicates(d, { name: 'x', phone: '0770001122' })[0].kind === 'supplier', 'supplier with the same phone is reported');
throws(() => K.tx(d, x => K.registerCustomer(x, { name: 'Ahmed Benali' })), 'dup_party', 'registerCustomer blocks a strong duplicate');
const d1 = K.tx(d, x => K.registerCustomer(x, { name: 'Ahmed Benali', force: true })); eq(d1.customers.length, 2, 'force overrides the check');
const d2 = K.tx(d, x => K.registerCustomer(x, { name: 'Ahmed', phone: '' })); eq(d2.customers.length, 2, 'weak match does not block');

/* ---- leads ---- */
let L1, L2, L3;
d = K.tx(d, x => {
  L1 = K.addLead(x, { name: 'Fruits Sud', phone: '0555 12 34 56', source: 'referral', productId: P, qty: 500, value: 5000000, date: '2026-10-20' }).id;
  L2 = K.addLead(x, { name: 'Market Z', phone: '0666 00 00 01', source: 'visit', value: 2000000, date: '2026-10-10', nextFollow: '2026-10-25' }).id;
  L3 = K.addLead(x, { name: 'Old One', source: 'bogus', date: '2026-09-01' }).id;
});
ok(d.leads.length === 3 && d.leads[0].stage === 'new' && d.leads[0].nextFollow === '2026-10-22', 'new lead: stage new, follow-up defaults to +2 days'); eq(d.leads[2].source, 'other', 'unknown source -> other');
throws(() => K.tx(d, x => K.addLead(x, { name: '' })), 'name_required', 'lead needs a name'); throws(() => K.tx(d, x => K.addLead(x, { name: 'a', value: -5 })), 'bad_amount', 'negative value'); throws(() => K.tx(d, x => K.addLead(x, { name: 'a', value: 10.5 })), 'bad_amount', 'value must be integer centimes');
throws(() => K.tx(d, x => K.addLead(x, { name: 'a', productId: 'nope' })), 'no_item', 'unknown product'); throws(() => K.tx(d, x => K.addLead(x, { name: 'a', date: '2026-13-01' })), 'bad_date', 'bad date');
const lf = id => d.leads.find(l => l.id === id);
eq(K.leadState(lf(L2), T), 'overdue', 'overdue follow-up'); eq(K.leadState(lf(L1), '2026-10-22'), 'today', 'due today'); eq(K.leadState(lf(L1), '2026-10-20'), 'soon', 'due within 3 days');
d = K.tx(d, x => K.addLeadNote(x, L2, { date: T, text: 'called, wants a quote', nextFollow: '2026-11-03' }));
eq(lf(L2).stage, 'contacted', 'a note moves new -> contacted'); eq(lf(L2).nextFollow, '2026-11-03', 'follow-up updated'); eq(lf(L2).log.length, 2, 'log keeps history');
throws(() => K.tx(d, x => K.addLeadNote(x, L2, { date: T, text: 'x', nextFollow: '2026-10-01' })), 'bad_range', 'follow-up cannot be in the past'); throws(() => K.tx(d, x => K.addLeadNote(x, L2, { date: T, text: '' })), 'name_required', 'empty note rejected');
d = K.tx(d, x => K.setLeadStage(x, L2, 'quoted', { date: T })); eq(lf(L2).stage, 'quoted', 'stage quoted');
d = K.tx(d, x => K.setLeadStage(x, L3, 'lost', { date: T, reason: 'price' })); ok(lf(L3).stage === 'lost' && lf(L3).lostReason === 'price' && lf(L3).nextFollow === '' && lf(L3).closed === T, 'lost: reason kept, follow-up cleared');
throws(() => K.tx(d, x => K.setLeadStage(x, L1, 'maybe')), 'bad_range', 'unknown stage');
let sm = K.leadsSummary(d, T); ok(sm.total === 3 && sm.open === 2 && sm.lost === 1 && sm.won === 0, 'summary counts'); eq(sm.pipeline, 7000000, 'pipeline = open values'); eq(sm.weighted, Math.round(5000000 * 0.1 + 2000000 * 0.5), 'weighted pipeline'); eq(sm.conversion, 0, 'conversion 0% when only losses'); eq(sm.overdue, 1, 'L1 follow-up (22 Oct) is overdue');
// convert
let conv; const nCust = d.customers.length;
d = K.tx(d, x => { conv = K.convertLead(x, L1, { date: T }); }); ok(!conv.linked && d.customers.length === nCust + 1 && lf(L1).stage === 'won' && lf(L1).customerId === conv.customer.id, 'convert creates the customer and marks won');
eq(d.customers.find(c => c.id === conv.customer.id).phone, '0555 12 34 56', 'customer keeps the lead phone');
d = K.tx(d, x => { conv = K.convertLead(x, L1, { date: T }); }); ok(conv.linked && d.customers.length === nCust + 1, 'converting twice does not duplicate');
let L4; d = K.tx(d, x => { L4 = K.addLead(x, { name: 'Someone', phone: '+213 550 11 22 33', date: T }).id; conv = K.convertLead(x, L4, { date: T }); }); ok(conv.linked && conv.customer.name === 'Ahmed Benali' && d.customers.length === nCust + 1, 'convert links to the existing customer with the same phone');
sm = K.leadsSummary(d, T); eq(sm.won, 2, 'two won'); eq(sm.conversion, 67, 'conversion = won / (won + lost)'); ok(sm.avgDaysToWin != null, 'avg days to win');
dup = K.findDuplicates(d, { name: 'Fruits Sud', phone: '0555123456' }); ok(dup.length === 1 && dup[0].kind === 'customer', 'a won lead is not reported twice (only the customer)');
d = K.tx(d, x => K.voidLead(x, L3)); ok(lf(L3).voided && K.leadsSummary(d, T).total === 3, 'void keeps the record, hides it from the summary'); throws(() => K.tx(d, x => K.voidLead(x, L3)), 'no_item', 'cannot void twice');

/* ---- data for the rest: suppliers, purchases, sales, production, expenses ---- */
let S1, S2, cA, cB, cC, cD;
d = K.tx(d, x => { S1 = K.addSupplier(x, { name: 'Sup One' }).id; S2 = K.addSupplier(x, { name: 'Sup Two' }).id; cA = K.addCustomer(x, { name: 'Cust A', created: '2026-01-01' }).id; cB = K.addCustomer(x, { name: 'Cust B' }).id; cC = K.addCustomer(x, { name: 'Cust C' }).id; cD = K.addCustomer(x, { name: 'Cust D' }).id; });
d = K.tx(d, x => {
  K.recordPurchase(x, { date: '2026-09-05', supplierId: S1, materialId: M, qty: 1000, unitCost: 20000, paid: 20000000, method: 'cash' });   // total 20,000,000
  K.recordPurchase(x, { date: '2026-10-05', supplierId: S1, materialId: M, qty: 500, unitCost: 22000, paid: 5000000, method: 'cash' });    // 11,000,000
  K.recordPurchase(x, { date: '2026-10-20', supplierId: S2, materialId: M, qty: 500, unitCost: 25000, paid: 0, method: 'cash' });          // 12,500,000
  K.recordPurchase(x, { date: '2026-10-22', supplierId: S2, materialId: M2, qty: 200, unitCost: 10000, paid: 2000000, method: 'cash' });   // 2,000,000
});
const pt = K.purchaseTable(d, {});
eq(pt.rows.length, 4, '4 purchases'); eq(pt.totals.total, 45500000, 'total'); eq(pt.totals.paid, 27000000, 'paid'); eq(pt.totals.remaining, 18500000, 'remaining'); eq(pt.totals.paid + pt.totals.remaining, pt.totals.total, 'paid + remaining = total'); eq(pt.totals.qty, 2200, 'quantity');
ok(pt.rows[0].date >= pt.rows[3].date, 'newest first');
const bm = pt.byMaterial.find(m => m.materialId === M); eq(bm.qty, 2000, 'material qty'); eq(bm.avg, Math.round(43500000 / 2000), 'weighted average price'); eq([bm.min, bm.max, bm.last], [20000, 25000, 25000], 'min / max / last price'); eq(bm.change, 19, 'last price 25000 vs earlier average 21000 (+19%)');
ok(pt.priceAlerts.length === 1 && pt.priceAlerts[0].materialId === M, 'price alert for the +14% material'); eq(pt.bySupplier.map(s => s.supplier), ['Sup One', 'Sup Two'], 'suppliers by amount');
eq(K.purchaseTable(d, { supplierId: S2 }).totals.total, 14500000, 'filter by supplier'); eq(K.purchaseTable(d, { materialId: M2 }).rows.length, 1, 'filter by material'); eq(K.purchaseTable(d, { from: '2026-10-01', to: '2026-10-21' }).rows.length, 2, 'filter by period');
const pid = d.purchases[2].id; d = K.tx(d, x => K.voidPurchase(x, pid));
eq(K.purchaseTable(d, {}).rows.length, 3, 'voided hidden by default'); const wv = K.purchaseTable(d, { includeVoid: true }); eq(wv.rows.length, 4, 'voided can be shown'); eq(wv.totals.total, 33000000, 'voided rows are not in totals'); ok(wv.rows.some(r => r.voided && r.remaining === 0), 'voided row has no remaining');
d = K.tx(d, x => K.recordPurchase(x, { date: '2026-10-20', supplierId: S2, materialId: M, qty: 500, unitCost: 25000, paid: 0, method: 'cash' }));   // re-add (for later analysis)
eq(K.purchaseTable(d, { from: '2030-01-01' }).totals.count, 0, 'empty result is safe');

/* ---- customers' segments ---- */
const g = {}; g[M] = 500;
d = K.tx(d, x => { K.recordProduction(x, { date: '2026-10-01', shift: 1, productId: P2, good: 50, defective: 0, grams: g }); for (let i = 0; i < 25; i++) K.recordProduction(x, { date: K.addDays('2026-10-01', i), shift: 1 + (i % 2), productId: P, good: 100, defective: i < 10 ? 10 : 2, grams: g }); });
d = K.tx(d, x => {
  // A: VIP (many orders, big), B: dormant (last order 100 days ago), C: risk (old unpaid), D: new (first order 5 days ago)
  [['2026-03-01', 30], ['2026-05-01', 30], ['2026-07-01', 30], ['2026-09-01', 30], ['2026-10-10', 40], ['2026-10-25', 40]].forEach(([dt, q]) => K.recordSale(x, { date: dt, customerId: cA, items: [{ productId: P, qty: q, unitPrice: 10000, weightG: 0 }], paid: q * 10000, method: 'cash' }));
  [['2026-05-01', 5], ['2026-06-01', 5], ['2026-07-01', 5]].forEach(([dt, q]) => K.recordSale(x, { date: dt, customerId: cB, items: [{ productId: P, qty: q, unitPrice: 10000, weightG: 0 }], paid: q * 10000, method: 'cash' }));
  K.recordSale(x, { date: '2026-08-01', customerId: cC, items: [{ productId: P, qty: 10, unitPrice: 10000, weightG: 0 }], paid: 0, method: 'cash' });
  K.recordSale(x, { date: '2026-10-25', customerId: cD, items: [{ productId: P2, qty: 10, unitPrice: 10000, weightG: 0 }], paid: 100000, method: 'cash' });
  K.recordSale(x, { date: '2026-10-28', items: [{ productId: P, qty: 10, unitPrice: 10000, weightG: 0 }], paid: 100000, method: 'cash' });   // walk-in
});
const pr = K.customerProfiles(d, T), seg = n => pr.find(r => r.customer.name === n);
eq(seg('Cust A').segment, 'vip', 'A is VIP (top 20%, 6 invoices, no debt)'); ok(seg('Cust A').vip, 'vip flag');
eq(seg('Cust B').segment, 'dormant', 'B is dormant (last order 121 days ago, usual gap 31)'); eq(seg('Cust C').segment, 'risk', 'C is at risk (unpaid invoice 90 days old)');
eq(seg('Cust D').segment, 'new', 'D is new (first invoice 5 days ago)'); eq(seg('Ahmed Benali').segment, 'prospect', 'registered but never invoiced = prospect');
eq(seg('Cust A').count, 6, 'A invoice count'); eq(seg('Cust A').last, '2026-10-25', 'A last date'); eq(seg('Cust B').avgGap, 31, 'B usual gap');
ok(seg('Cust A').daysSince === 5, 'days since last order');
// reorder due: a regular customer whose usual gap has passed but is not dormant yet
d = K.tx(d, x => { const c = K.addCustomer(x, { name: 'Cust E' }).id; ['2026-08-01', '2026-08-25', '2026-09-18'].forEach(dt => K.recordSale(x, { date: dt, customerId: c, items: [{ productId: P, qty: 5, unitPrice: 10000, weightG: 0 }], paid: 50000, method: 'cash' })); });
const pr2 = K.customerProfiles(d, T), e = pr2.find(r => r.customer.name === 'Cust E'); ok(e.reorderDue && e.segment === 'active', 'E: expected reorder date passed, still active -> reorderDue (' + e.expected + ')');
ok(pr2.every(r => ['vip', 'active', 'new', 'dormant', 'risk', 'prospect'].includes(r.segment)), 'segments are always one of the known ones');
eq(K.customerProfiles(K.emptyData(), T), [], 'no customers -> empty');

/* ---- company analysis ---- */
d = K.tx(d, x => K.addLead(x, { name: 'Late lead', date: '2026-10-01' }));
let a = K.analysis(d, T, 30);
eq([a.from, a.to, a.prevFrom, a.prevTo], ['2026-10-01', '2026-10-30', '2026-09-01', '2026-09-30'], 'period = last 30 days vs the 30 days before');
const real = K.periodReport(d, a.from, a.to); eq(a.kpis.sales.cur, real.sales, 'KPI sales = period report'); eq(a.kpis.purchases.cur, real.purchases, 'KPI purchases = period report');
eq(a.kpis.sales.cur, 40 * 10000 * 2 + 10 * 10000 + 10 * 10000, 'sales of October computed by hand (A 2 x 40, D 10, walk-in 10)');
eq(a.kpis.sales.prev, 30 * 10000 + 5 * 10000, 'previous period: A 30 crates on 1 Sep + E 5 crates on 18 Sep'); eq(a.kpis.sales.pct, Math.round((a.kpis.sales.cur - a.kpis.sales.prev) * 1000 / a.kpis.sales.prev) / 10, 'growth %');
eq(a.customers.top[0].customer.name, 'Cust A', 'top customer'); ok(a.customers.top[0].share > 50 && a.customers.topShare === a.customers.top[0].share, 'concentration share');
eq(a.customers.segments.vip, 1, 'segment counts: 1 vip'); eq(a.customers.segments.dormant, 1, '1 dormant'); eq(a.customers.segments.risk, 1, '1 risk'); eq(a.customers.walkin, 100000, 'walk-in sales');
eq(a.products[0].product.id, P, 'best product first'); eq(Math.round(a.products.reduce((s, p) => s + p.share, 0)), 100, 'product shares add up to 100%');
eq(a.production.good, 2500 + 50, 'production in period (25 days x 100 + 50)'); ok(a.production.defectPct > 0 && a.production.days === 25, 'defect % and active days');
eq(a.receivables.total, K.totalCustomerDebt(d), 'receivables = real debts'); ok(a.receivables.buckets.length === 4 && a.receivables.buckets[1] + a.receivables.buckets[2] > 0 || a.receivables.buckets[3] > 0, 'ageing buckets filled');
eq(a.payables, K.totalSupplierDebt(d), 'payables = real supplier debts');
ok(a.health.score >= 0 && a.health.score <= 100, 'health score 0..100'); eq(a.health.components.reduce((s, c) => s + c.weight, 0), 100, 'weights add to 100');
ok(a.health.components.every(c => !c.ok || (c.score >= 0 && c.score <= 100)), 'component scores are 0..100');
const ids = a.recommendations.map(r => r.id); ok(ids.includes('overdue90') || ids.includes('overdue'), 'overdue debts recommendation'); ok(ids.includes('dormant'), 'dormant customer recommendation (' + ids + ')'); ok(ids.includes('followups'), 'overdue lead follow-up recommendation');
ok(ids.includes('concentration'), 'concentration warning (A > 40% of sales)'); ok(ids.indexOf('overdue90') < 0 || a.recommendations[0].sev === 'high', 'high severity first');
ok(a.recommendations.every(r => r.id && r.sev && r.icon), 'every recommendation has id, severity and icon');
eq(a.series.length, 6, 'six month series'); eq(a.series[5].ym, '2026-10', 'series ends with the current month');
// empty data is safe
const ae = K.analysis(K.emptyData(), T, 30); eq(ae.health.score, null, 'no data -> no score (nothing invented)'); eq(ae.health.level, 'nodata', 'level nodata'); ok(ae.recommendations.some(r => r.id === 'few_data'), 'few data hint'); eq(ae.kpis.sales.pct, null, 'no growth % without a previous period'); eq(ae.customers.top.length, 0, 'no top customers');
const a90 = K.analysis(d, T, 90); eq(a90.kpis.sales.cur, K.periodReport(d, K.addDays(T, -89), T).sales, '90-day period'); const a7 = K.analysis(d, T, 7); eq(a7.from, '2026-10-24', '7-day period');
// analysis never mutates the data
const snap = JSON.stringify(d); K.analysis(d, T, 30); K.purchaseTable(d, {}); K.customerProfiles(d, T); K.leadsSummary(d, T); K.findDuplicates(d, { name: 'x' }); eq(JSON.stringify(d), snap, 'read-only functions do not change the data');
// the old datasets (no leads array) still work
const old = K.clone(d); delete old.leads; ok(Array.isArray(K.tx(old, x => K.addLead(x, { name: 'Late' })).leads), 'leads array is created lazily on old data'); ok(K.analysis(old, T, 30).leads.total === 0, 'analysis works without d.leads');
// backup validation keeps leads
const bk = K.makeBackup(d), v = K.validateBackup(JSON.parse(JSON.stringify(bk))); ok(v.ok && Array.isArray(v.data.leads) && v.data.leads.length === d.leads.length, 'backup round-trip keeps leads');
console.log('pass', pass, 'fail', fail); process.exit(fail ? 1 : 0);
