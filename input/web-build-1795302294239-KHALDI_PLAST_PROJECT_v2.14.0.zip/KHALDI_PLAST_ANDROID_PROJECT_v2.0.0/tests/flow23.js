const L=require('./lib.js');let pass=0,fail=0;const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n);};
(async()=>{const s=await L.start(process.argv[2],390);const p=s.page;await p.waitForSelector('#splash.hidden',{state:'attached'});
await p.evaluate(()=>{const U=window.KPU;U.stack=[];U.route='more';U.render();});await p.waitForTimeout(300);
const t=await p.$('#main [data-act]');await t.dblclick({delay:20});await p.waitForTimeout(500);
const st=await p.evaluate(()=>({r:KPU.route,n:KPU.stack.length}));
ok(st.n===1,'double tap opens once (stack '+st.n+', route '+st.r+')');
await p.evaluate(()=>KPU.back());await p.waitForTimeout(100);ok(await p.evaluate(()=>KPU.route==='more'),'one back returns to More');
console.log('pass',pass,'fail',fail);await s.close();})();
