const L=require('./lib.js'),path=require('path');
(async()=>{ const root=path.join(__dirname,'../app/src/main/assets/www'); const vw=+process.argv[2]||390;
 const s=await L.start(root,vw); const p=s.page; await p.waitForTimeout(500);
 await p.setViewportSize({width:vw,height:1700});
 const id=await p.evaluate(()=>{const U=window.KPU,K=U.K;let r;U.commit(d=>{d.products.forEach(q=>K.adjustStock(d,{date:K.today(),kind:'product',itemId:q.id,newStock:1000,note:'t'}));const c=K.addCustomer(d,{name:'مؤسسة الأمل للخضر',phone:'0550 12 34 56',address:'سوق الجملة، البليدة'});
  r=K.recordSale(d,{date:K.today(),customerId:c.id,items:d.products.slice(0,4).map((q,i)=>({productId:q.id,qty:100-i*20,unitPrice:250000+i*90000,weightG:0})),discount:0,paid:1000000,method:'cash'}).id;});return r;});
 await p.evaluate(i=>{window.KPU.stack=[];window.KPU.route='invoice';window.KPU.arg=i;window.KPU.render();},id); await p.waitForTimeout(300);
 console.log(await p.evaluate(()=>{const f=document.querySelector('.ivfit');return [f.style.width,f.style.height,f.parentNode.clientWidth,document.documentElement.scrollWidth]}));
 await p.screenshot({path:process.argv[3]||'/tmp/inv.png'}); await s.close(); })();
