// v2.5: machine monitor (shift timer, expected vs actual, stops, persistence)
const L=require('./lib.js'); let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
(async()=>{ const s=await L.start(process.argv[2],390); const p=s.page; await p.waitForTimeout(600);
 const go=async()=>{await p.evaluate(()=>{const U=window.KPU;U.stack=[];U.route='machmon';U.arg=null;U.render();});await p.waitForTimeout(300)};
 const A=(n,d)=>p.evaluate(([n,d])=>window.KPU.extraActions[n]({dataset:d||{}}),[n,d]);
 await go(); ok((await p.locator('.card').first().innerText()).length>0,'empty state without machines');
 await p.evaluate(()=>{const U=window.KPU,K=U.K;U.commit(d=>{K.addMachine(d,{name:'خط 1'});K.addMachine(d,{name:'خط 2'});});}); await go();
 ok(await p.locator('.mm-it').count()===2,'carousel has 2 machines');
 ok(await p.locator('.mm-it.on .mm-ck').count()===1,'selected machine has check');
 await A('mm_nav',{id:'1'}); await p.waitForTimeout(200); ok((await p.locator('.mm-it.on b').innerText()).includes('2'),'arrow selects next machine'); await A('mm_nav',{id:'-1'}); await p.waitForTimeout(200);
 ok((await p.locator('.mm-warn').count())===1,'asks for cycle time when unset');
 await A('mm_cycle'); await p.fill('#f_cycle','32'); await p.click('#f button[type=submit]'); await p.waitForTimeout(300);
 ok((await p.locator('.mm-cyc').innerText()).includes('0.533'),'cycle shows 32 sec (0.533 min)');
 const chk=await p.evaluate(()=>{const U=window.KPU,K=U.K,n=(function(){const h=new Date().getHours();return h>=8&&h<16?1:h>=16?2:3})(),sh=K.SHIFTS[n-1],h0=parseInt(sh.start,10),d=new Date();d.setHours(h0,0,0,0);
  const el=Math.min(sh.hours*3600,(Date.now()-d.getTime())/1000);return {t:document.getElementById('mm_t').textContent,exp:document.getElementById('mm_exp').textContent,calc:Math.floor(el/32),el}});
 ok(Math.abs(parseInt(chk.exp.replace(/,/g,''))-chk.calc)<=1,'expected = elapsed/cycle ('+chk.exp+' vs '+chk.calc+')');
 ok(/^\d\d:\d\d:\d\d$/.test(chk.t),'timer format '+chk.t);
 const t1=await p.locator('#mm_t').innerText(); await p.waitForTimeout(2200); const t2=await p.locator('#mm_t').innerText(); ok(t1!==t2,'timer ticks live');
 // actual count
 await A('mm_count'); await p.fill('#f_n','10'); await p.click('#f button[type=submit]'); await p.waitForTimeout(300);
 ok((await p.locator('#mm_act').innerText()).trim()==='10','actual production saved');
 const gap=await p.locator('#mm_gap').innerText(); const ex=parseInt((await p.locator('#mm_exp').innerText()).replace(/,/g,''));
 ok(parseInt(gap.replace('+',''))===10-ex || Math.abs(parseInt(gap.replace('+',''))-(10-ex))<=1,'gap = actual - expected ('+gap+')');
 // stop (unjustified) then resume
 await A('mm_stop'); await p.waitForTimeout(200); ok(await p.locator('[data-act="mm_stop_do"]').count()===2,'stop chooser');
 await p.fill('#mm_rs','عطل'); await A('mm_stop_do',{id:'u'}); await p.waitForTimeout(300);
 ok(await p.locator('.mm-pill.r').count()===1,'status stopped'); ok(await p.locator('.mm-pb.play').count()===1,'resume button shown');
 await p.waitForTimeout(1500); await A('mm_resume'); await p.waitForTimeout(300);
 ok(await p.locator('.mm-lr').count()===1,'stop logged');
 const mon=await p.evaluate(()=>window.KPU.D.settings.mon); ok(mon.stops.length===1&&mon.stops[0].to&&mon.stops[0].kind==='u','stop closed + unjustified');
 // justified stop of 10 min in past reduces expected
 const before=parseInt((await p.locator('#mm_exp').innerText()).replace(/,/g,''));
 await p.evaluate(()=>{const U=window.KPU;U.commit(d=>{d.settings.mon.stops.push({id:'x1',m:d.machines[0].id,from:Date.now()-1200000,to:Date.now()-600000,kind:'j',reason:''});});U.render(true);}); await p.waitForTimeout(300);
 const aft=parseInt((await p.locator('#mm_exp').innerText()).replace(/,/g,'')); ok(before-aft>=0,'justified stop does not raise expected ('+before+'→'+aft+')');
 ok((await p.locator('#mm_jb').innerText()).trim()!=='0','justified minutes counted');
 await A('mm_delstop',{id:'x1'}); await p.waitForTimeout(300); ok(await p.locator('.mm-lr').count()===1,'delete stop');
 // settings
 await A('mm_cfg'); await p.fill('#f_model','XY-200'); await p.click('#f button[type=submit]'); await p.waitForTimeout(300);
 ok((await p.locator('.mm-hi').innerText()).includes('XY-200'),'model saved');
 // persistence
 await p.reload(); await p.waitForTimeout(900);
 const m2=await p.evaluate(()=>{const c=window.KPU.D.settings.mon;return c&&Object.values(c.cfg)[0].cycle+'|'+Object.values(c.counts)[0].n});
 ok(m2==='32|10','persists after reload '+m2);
 // more page + shortcut
 await p.evaluate(()=>{const U=window.KPU;U.stack=[];U.route='more';U.render();}); await p.waitForTimeout(250);
 ok(await p.locator('[data-id="machmon"]').count()>=1,'tile in More page');
 await p.evaluate(()=>window.KPU.extraActions.sc({dataset:{id:'machmon'}})); await p.waitForTimeout(300); ok((await p.evaluate(()=>window.KPU.route))==='machmon','tile opens page');
 await p.screenshot({path:'/tmp/mm_shot.png',fullPage:false});
 ok(s.errors.length===0,'no JS errors '+JSON.stringify(s.errors)); console.log('pass',pass,'fail',fail); await s.close(); })();
