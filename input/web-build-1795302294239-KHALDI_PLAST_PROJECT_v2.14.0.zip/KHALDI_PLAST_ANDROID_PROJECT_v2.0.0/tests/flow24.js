const L=require('./lib.js');let pass=0,fail=0;const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n);};
(async()=>{const s=await L.start(process.argv[2],390);const p=s.page;await p.waitForSelector('#splash.hidden',{state:'attached'});
const ids=await p.evaluate(()=>{const U=window.KPU,K=U.K;let r={};U.commit(d=>{K.addMachine(d,{name:'آلة 01'});K.addMachine(d,{name:'آلة 02'});
const a=K.addWorker(d,{name:'يوسف',role:'مشغّل',rate:200000,hireDate:'2025-03-01',phone:'0770'}),b=K.addWorker(d,{name:'كريم',role:'مشغّل',rate:200000,hireDate:'2025-03-01',phone:'0771'}),c=K.addWorker(d,{name:'سمير',role:'عامل',rate:150000,hireDate:'2025-03-01',phone:'0772'});
r.m1=d.machines[0].id;r.m2=d.machines[1].id;r.a=a.id;r.b=b.id;r.c=c.id;
const sh=(new Date().getHours()>=8&&new Date().getHours()<16)?1:(new Date().getHours()>=16?2:3);r.sh=sh;
K.setShiftRoster(d,{date:K.today(),shift:sh,entries:[{workerId:a.id,worked:true,machineId:null},{workerId:c.id,worked:true,machineId:null}]});});
U.S.mm={m:r.m1,shift:r.sh};U.stack=[];U.route='machmon';U.render();return r;});
await p.waitForTimeout(400);
ok(await p.$('#crew_card.warn')!==null,'machine with no crew shows warning card');
// assign via form
await p.evaluate(([m,n])=>window.KPU.extraActions.crew_edit({dataset:{m:m,n:String(n)}}),[ids.m1,ids.sh]);await p.waitForTimeout(200);
await p.check('input[name="w_'+ids.a+'"]');await p.click('#f button[type=submit]');await p.waitForTimeout(400);
ok(await p.evaluate(()=>document.querySelectorAll('#crew_card .cw').length)===1,'assigned worker appears in crew card');
ok(await p.evaluate((a)=>KPU.D.attendance.some(x=>x.workerId===a&&x.machineId&&x.worked),ids.a),'roster stores machine link');
// output per worker
await p.evaluate(([m,n])=>{KPU.commit(d=>{d.settings.mon={cfg:{},stops:[],counts:{[m+'|'+KPU.K.today()+'|'+n]:{n:600,ts:Date.now()}}}});},[ids.m1,ids.sh]);await p.waitForTimeout(300);
await p.evaluate(()=>KPU.render(true));await p.waitForTimeout(300);console.log('DBG',await p.evaluate(()=>(document.querySelector('#crew_card')||{}).innerText));ok((await p.textContent('#crew_card .cr-s')).includes('600'),'crew card shows shift output');
// move worker to machine 2 and check machine 1 emptied
await p.evaluate(([m,n])=>window.KPU.extraActions.crew_edit({dataset:{m:m,n:String(n)}}),[ids.m2,ids.sh]);await p.waitForTimeout(200);
ok((await p.textContent('.crl')).includes('آلة 01'),'form shows worker currently on another machine');
await p.check('input[name="w_'+ids.a+'"]');await p.click('#f button[type=submit]');await p.waitForTimeout(300);
ok(await p.evaluate(([a,m2])=>KPU.D.attendance.filter(x=>x.workerId===a).every(x=>x.machineId===m2),[ids.a,ids.m2]),'worker moved to machine 2');
// workers page map
await p.evaluate(()=>{KPU.stack=[];KPU.route='workers';KPU.render();});await p.waitForTimeout(400);
ok(await p.evaluate(()=>document.querySelectorAll('.cmap .cm-r').length)>=2,'workers page lists machines with crews');
ok((await p.textContent('.cmap')).includes('سمير'),'unassigned worker flagged');
// alerts
ok(await p.evaluate(()=>!!KPU.crewAlerts()),'crew alerts computed');
await p.evaluate(()=>{KPU.stack=[];KPU.route='home';KPU.render();});await p.waitForTimeout(300);
ok(await p.evaluate(()=>/بلا/.test(document.querySelector('.bf-row')?document.querySelector('.bf-row').textContent:'')),'home briefing mentions crew gap');
console.log('errors:',s.errors.length?s.errors.join('|'):'none');console.log('pass',pass,'fail',fail);await s.close();})();
