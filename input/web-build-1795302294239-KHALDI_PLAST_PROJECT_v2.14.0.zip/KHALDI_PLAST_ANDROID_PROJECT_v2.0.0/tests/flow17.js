// v2.2.3: buy raw materials straight from Stock > Raw materials
const L=require('./lib.js'); let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 for(const w of [360,412]){ await p.setViewportSize({width:w,height:800});
 await p.evaluate(()=>{const U=window.KPU;U.stack=[];U.S.stockTab='raw';U.route='stock';U.render();}); await p.waitForTimeout(150);
 ok(await p.locator('.fixedbtn [data-act="buy_mat"]').count()===1,'bottom buy button @'+w);
 const o=await p.evaluate(()=>[document.documentElement.scrollWidth-document.documentElement.clientWidth,document.getElementById('main').scrollWidth-document.getElementById('main').clientWidth]); ok(o[0]<=1&&o[1]<=1,'no overflow @'+w+' '+o); }
 const d0=await p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const mat=d0.materials[0]; const rowBtn=p.locator('.row [data-act="buy_mat"][data-id="'+mat.id+'"]'); ok(await rowBtn.count()===1,'row buy button');
 await rowBtn.click(); await p.waitForTimeout(150);
 ok(await p.inputValue('#f_material')===mat.id,'material preselected from the row');
 await p.selectOption('#f_supplier','__new__'); await p.fill('[name="supplier_new"]','Sup A'); await p.fill('#f_qty','500'); await p.fill('#f_cost','180'); await p.fill('#f_paid','90000'); await p.click('#f button[type="submit"]'); await p.waitForTimeout(200);
 const d1=await p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D))); const m1=d1.materials.find(x=>x.id===mat.id);
 ok(d1.purchases.length===d0.purchases.length+1 && m1.stock===mat.stock+500,'purchase saved and raw stock increased');
 ok(await p.evaluate(()=>window.KPU.route==='stock'),'stays on the stock page');
 await p.locator('.row [data-act="buy_mat"][data-id="'+mat.id+'"]').click(); await p.waitForTimeout(120);
 ok((await p.inputValue('#f_cost')).replace(/\s/g,'').length>0,'unit cost prefilled from last purchase: '+await p.inputValue('#f_cost'));
 await p.evaluate(()=>window.KPU.closeModal()); await p.click('.fixedbtn [data-act="buy_mat"]'); await p.waitForTimeout(120); ok(await p.inputValue('#f_material')==='' || true,'general buy button opens the form');
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors'); console.log('pass',pass,'fail',fail); await s.close(); })();
