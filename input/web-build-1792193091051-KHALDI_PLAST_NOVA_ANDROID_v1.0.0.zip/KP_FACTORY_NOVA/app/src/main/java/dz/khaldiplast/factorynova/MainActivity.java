package dz.khaldiplast.factorynova;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.webkit.WebView;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this); setContentView(web);
    WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new Bridge(), "NovaAndroid");
    web.loadUrl("file:///android_asset/www/index.html");
  }
  public class Bridge {
    @JavascriptInterface public void toast(String message) { runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show()); }
    @JavascriptInterface public void printPage() { runOnUiThread(() -> { PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); pm.print("KHALDI PLAST NOVA", web.createPrintDocumentAdapter("KHALDI PLAST NOVA"), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()); }); }
    @JavascriptInterface public void shareText(String subject, String body) { runOnUiThread(() -> { Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,subject); i.putExtra(Intent.EXTRA_TEXT,body); startActivity(Intent.createChooser(i,"مشاركة النسخة الاحتياطية")); }); }
  }
  @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
