# IMPLEMENTATION STATUS — updated 2026-10-21 (business core + all 21 module screens built and tested in a browser; APK not built/verified)

## Architecture decisions
- **Stack:** plain ES modules (no framework) + Vite (bundling, CI only) + Capacitor 6 (Android) + SQLite (`@capacitor-community/sqlite` on device; Node built-in `node:sqlite` for tests). Chosen because the environment has Node 22 but no Android SDK/JDK/Gradle/network.
- **Layering:** `src/core` = pure business logic written against a small async driver interface (`exec/run/all/get/transaction`), so the same code runs in tests and on Android. `src/ui` = presentation only.
- **Money:** BigInt fixed-point (1e-4), half-away-from-zero rounding.

## Phase 1 — foundation
| Item | State | Evidence |
|---|---|---|
| Project spec + status docs | Done | this file, PROJECT_SPEC.md |
| Official logo preserved byte-identical | Done | `docs/logo-*-sha256.txt` match |
| Decimal engine (money, %, mass conversion) | Done, tested | `tests/decimal.test.js` (9) |
| Migration runner (checksums, rollback, no-reset) | Done, tested | `tests/db.test.js` |
| Foundation schema (settings, roles, users, audit, sequences, idempotency) | Done, tested | `tests/db.test.js` |
| Append-only audit log (DB triggers) | Done, tested | |
| Sequential document numbers, no gaps on rollback | Done, tested | |
| Exactly-once event guard (`once`) | Done, tested | |
| Role/permission matrix enforced in services | Done, tested (company settings only wired so far) | |
| FR/AR dictionaries, RTL switching, persisted language | Done; key parity tested; RTL checked in headless Chromium | `tests/i18n.test.js`, screenshots |
| Liquid Glass design system + bottom nav + More sheet | Done (shell) | headless Chromium 390x844, 0 console errors |
| Dashboard | **Shell only** — tiles show "—" (no business data exists yet) | |
| 20 other modules | **Not built** — honest "not yet developed" placeholder screens | |
| Android driver (`capacitor-driver.js`) | **Written, UNVERIFIED** (never run on device) | |
| GitHub Actions APK workflow | **Written, UNVERIFIED** | |
| APK | **NOT BUILT** (no JDK/Gradle/Android SDK/network here) | |

## Phase 2 — products, materials, recipes, inventory, production (CORE LOGIC)
| Item | State | Evidence |
|---|---|---|
| Migration 2 schema (products, materials, recipes+lines, stock ledger, production orders) | Done | tests/production.test.js |
| Products/materials: validation, unique refs, archive-not-delete, audit, permissions | Done, tested | |
| Recipes: versioned, old versions intact, units g/kg/t conversion, loss % | Done, tested | |
| Requirements calculator: shortages, estimated cost (null when cost data missing) | Done, tested with hand-computed values | |
| Stock ledger: append-only, exact integer quantities, idempotent event keys, negative stock blocked (service + DB trigger) | Done, tested | |
| Production workflow draft→planned→in_progress→completed/cancelled; atomic completion; no double completion; full rollback on insufficient stock | Done, tested | |
| Measured vs calculated consumption flagged (`useExpected`) | Done, tested | |
| Weights/metrics (net, average, rejection %, completion %, per-material per accepted unit; null on zero denominators) | Done, tested | |
| Low-stock facts from ledger | Done, tested | |
| **Screens** for products, materials, inventory, production | **NOT built** (placeholders remain) | |
| Quality records, shifts, machine downtime linkage | Not built (Phase 5) | |
| Stock valuation / weighted-average cost | Not built (Phase 4) | |
| Reservations (reserved/available stock) | Not built (Phase 3 with sales orders) | |

Why no screens yet: the browser preview has no SQLite engine (Android uses the Capacitor plugin), so a screen could not be verified end to end here. Plan: add a `sql.js` (WASM) preview driver in CI-capable environments, or verify screens on the first built APK.

## Phase 3 — customers, suppliers, sales, delivery, invoicing, collections (CORE LOGIC)
| Item | State | Evidence |
|---|---|---|
| Migration 3 schema | Done | tests/sales.test.js |
| Customers/suppliers: unique ref, duplicate NIF guard, audit, permissions | Done, tested | |
| Tax rates = configuration only (admin-only, 0..100, none shipped, rate snapshotted on each invoice line) | Done, tested | |
| Sales orders (draft → confirmed → partially delivered/delivered/cancelled); drafts reserve nothing | Done, tested | |
| Reserved vs available stock (derived from open orders, not stored) | Done, tested | |
| Delivery = validated dispatch: stock deducted exactly once, over-delivery blocked, rollback of note/number on insufficient stock | Done, tested | |
| Invoice engine: line/discount/multi-rate tax/totals by rate, hand-computed expected values; due date from terms | Done, tested | |
| Invoices immutable + undeletable (DB triggers); cancellation only if untouched; credit notes (amount-based) | Done, tested | |
| Payments: partial, multi-invoice allocation, oldest-first *suggestion*, excess kept as customer credit, duplicate prevention (event key + same ref/amount/date), cancel keeps history | Done, tested | |
| Customer balance, unallocated credit, invoice outstanding, aging buckets (not due/1-30/31-60/61-90/>90) | Done, tested with hand-computed dates | |
| Credit-limit warning (alert, not silent block) | Done, tested | |
| Mutation check (rounding + over-delivery guard broken on purpose) | 2 tests failed as intended; code restored | |
| **Screens** for customers/sales/invoices/payments | **NOT built** | |
| Invoice PDF (A4, FR/AR, logo) | **NOT built** | |
| Quotations as a separate document, customer-specific prices, shipping charges, returns of goods, line-level credit notes | Not built | |
| Supplier side (purchase orders, receipts, supplier invoices/payables) | Not built (Phase 4/5) | |
| Accounting entries from invoices/payments | Not built (Phase 4) | |

Policies to confirm with the accountant: per-line rounding to 2 decimals (document totals = sum of rounded lines); excess payment kept as customer credit; amount-based credit notes.

## Phase 4 — purchasing, expenses, cash/bank, double-entry accounting (CORE LOGIC)
| Item | State | Evidence |
|---|---|---|
| Migration 4 schema | Done | tests/accounting.test.js |
| Journal engine: balanced-only, ≥2 lines, 2-decimal amounts, closed periods, duplicate-source guard, immutable entries (DB triggers), sequential JRN numbers | Done, tested | |
| Corrections by reversal only (no double reversal, no reversal of a reversal) | Done, tested | |
| Chart of accounts: configurable; **starter** structure (NOT statutory) via admin seed; account roles mapping for auto-posting | Done, tested | |
| Auto-posting: invoice, credit note (tax pro-rata), customer payment, supplier invoice, supplier payment, expense, transfer, opening balances | Done, tested with hand-computed entries | |
| Posting is skipped (documents kept, reason reported) when roles are not configured; `postPending` catches up exactly once | Done, tested | |
| Invoice/payment cancellation posts reversals and restores cash | Done, tested | |
| Subledger = control account (customers 3000, suppliers 4000) | Verified in tests | |
| Cash/bank accounts, transfers (never revenue/expense), overdraft blocked unless allowed, idempotent keys | Done, tested | |
| Cash reconciliation vs ledger (flags discrepancies) | Done, tested | |
| Expenses by category, cancel with reversal | Done, tested | |
| Purchasing: PO (draft→approved→received), receipts increase stock only on receipt, over-receipt blocked, draft PO from shortages (priced materials only, never auto-approved) | Done, tested | |
| Supplier invoices (unique supplier ref, tax snapshot), payments fully allocated, overpayment blocked, payables | Done, tested | |
| Trial balance, income statement, balance sheet, general ledger, integrity verifier | Done, tested; hand-computed figures tie out | |
| Mutation check (balance guard + overdraft guard broken on purpose) | 3 tests failed as intended; restored | |
| **Weighted-average cost, COGS, production cost journals, stock valuation** | **NOT built** (stock value is booked at supplier-invoice time; finished goods not valued in the ledger) | |
| Bank-statement import/reconciliation by line, budgets, tax summaries, payroll | Not built | |
| Supplier payment cancellation, purchase returns, goods-received-not-invoiced accrual | Not built | |
| Screens + PDF for any of the above | **NOT built** | |

Accountant must review: starter chart; role mapping; per-line rounding; pro-rata tax on credit notes; invoice-driven stock valuation; opening balances posted against an equity account. Reports are management reports, not official filings.

## Phase 5 — costing, employees, shifts, machines, quality, budgets (CORE LOGIC)
| Item | State | Evidence |
|---|---|---|
| Migration 5 schema | Done | tests/costing.test.js, tests/operations.test.js |
| Weighted-average costing in the stock ledger (value per movement, exact integer maths, no rounding residue); unpriced stock flagged, never guessed | Done, tested with hand-computed values | |
| Stock valuation report (qty, value, avg cost, complete/incomplete) | Done, tested | |
| Production cost: material cost carried by accepted units (rejects absorbed), unit cost on the order, incomplete when any input was unpriced | Done, tested (90 kg @110 → 9,900 / 80 = 123.75) | |
| Journals: production (finished goods ↔ materials, or production loss if all rejected), COGS on delivery; catch-up via `postPending` | Done, tested; ledger = subledger for finished goods | |
| Estimated gross margin by product (labelled estimate) | Done, tested (9,000 − 3,712.50 = 5,287.50 = 58.75%) | |
| Inventory subledger vs ledger check | Done | |
| Shifts: configurable, midnight crossing, defaults only as an editable example | Done, tested | |
| Employees + attendance (no duplicate day, audited corrections, labor cost hidden from roles without employees:post) | Done, tested | |
| Shift output records (no double counting, downtime reasons, review, output by shift/operator/machine/day/order, reconciliation with the order) | Done, tested | |
| Machines: status, product-specific capacity, maintenance plans/due dates (hand-computed), costs, estimated utilization (null when capacity unknown) | Done, tested | |
| Quality inspections + rejection rates by product/machine/shift/defect; waste records; controlled recycled-material recovery (capped, no double counting) | Done, tested | |
| Budgets vs actual with configurable warning threshold | Done, tested | |
| Mutation checks | 2 of 3 mutations caught; the 3rd was an equivalent mutant (redundant shortcut) | |
| **Labor/overhead cost allocation into product cost** | **NOT built** (hourly cost is stored but not allocated) | |
| Maintenance cost is recorded on the machine but NOT posted to accounting expenses | Known gap | |
| Receipts are valued at PO price in the stock subledger while the ledger books stock at supplier-invoice time → differences appear in `inventoryLedgerCheck` | Known, by design for now | |
| Payroll, overtime pay, leave balances | Not built (needs verified Algerian rules + accountant) | |
| Screens + PDF | **NOT built** | |

## Phase 6 — alerts, offline assistant, search, backup/restore, exports (CORE LOGIC)
| Item | State | Evidence |
|---|---|---|
| Migration 6 (`backup_log`) | Done | |
| Alerts (15 kinds): low stock, insufficient materials, overdue invoices (severity by age), credit limit, high rejection, production delay, maintenance due/overdue, budget warning/exceeded, unusual consumption, expense spike, ledger unbalanced, cash/ledger mismatch, possible duplicate payments, shift/order mismatch, backup stale/failed, incomplete company identity. Each carries its evidence; thresholds are configurable (admin) and persisted | Done, tested with hand-computed cases | tests/alerts_assistant.test.js |
| Offline assistant (12 intents, FR + AR phrasing, answers in FR/AR): production today, availability, low materials, overdue/unpaid invoices, customer debt, month sales/expenses, orders in progress, maintenance, tomorrow's material needs, product cost (recorded vs ESTIMATE vs asks which product) | Done, tested | |
| Assistant safety: read-only (payment/delete/post/create requests refused, verified nothing changes), role permissions enforced per question, unknown questions get guidance, missing data is explained rather than invented, every answer states its calculation basis | Done, tested | |
| Global search over 12 entity types (FR/AR, wildcard characters literal, permission-filtered) | Done, tested | tests/backup_search_csv.test.js |
| Backup: JSON with SHA-256 checksum, schema version, row counts, backup log | Done, tested | |
| Restore: explicit confirmation + admin only; validates checksum/format/schema/tables/columns/counts BEFORE touching data; single atomic transaction; foreign keys + ledger balance verified before commit; auto-created safety backup of replaced data; triggers recreated; restore audited; failures logged | Done, tested incl. failure injection (FK violation, unbalanced ledger) with full rollback | |
| **Roundtrip acceptance test** (populated factory → backup → restore into empty disposable DB → counts, customer balance 7,305, trial balance, stock value, invoice numbering all match; protections still active) | Passed | |
| CSV export (6 reports) with BOM, escaping and formula-injection guard; customer statement with running balance (hand-computed) | Done, tested | |
| Mutation checks (checksum, confirmation, post-restore ledger check, CSV guard, search permission) | 5/5 caught | |
| Backup file encryption; native save/share via Android Storage Access Framework; automatic scheduled backups | **NOT built** (Android layer) | |
| Supplier statements, PDF/CSV for the remaining reports, tax summaries, sales/purchase aging by supplier | Not built | |
| Assistant: charts, follow-up context, free-form language beyond the listed phrasings | Not built (deliberately deterministic) | |

## UI screens (first slice) — built on the tested core
| Screen | State | Evidence |
|---|---|---|
| Dashboard (real KPIs: month sales HT, produced today, product stock, month expenses; live alerts list in FR/AR; shortcuts) | Done | E2E |
| Products (list/search, create, detail with stock/reserved/available, recipe versions, archive) | Done | E2E |
| Raw materials (list/search, create, receive stock with optional cost, double-tap safe, archive) | Done | E2E |
| Inventory (valuation, products/materials, low-stock flags, movement history, adjustments with mandatory reason) | Done | E2E |
| Production (orders list, new order with LIVE material requirements/shortage/estimated cost, plan → start → complete → cancel, measured vs calculated consumption, rejection/completion/unit cost) | Done | E2E |
| Design system, bottom nav, More sheet, FR/AR + RTL, no horizontal overflow on any built screen | Verified in headless Chromium (390×844) | E2E |
| Forms: input preserved on error, inline error, double-submit blocked, common core errors translated | Done | E2E |
| Role-based UI (buttons hidden) on top of core enforcement | Done for the built screens | E2E (sales, operator) |
| **E2E test**: real browser → real UI → real core → real SQLite (dev bridge) — 18 checks including duplicate reference, double tap, rejected completion, insufficient-stock rollback, no duplicate completion, stock effects, dashboard figures, RTL, permissions, zero console errors | PASSED | `npm run e2e` |
| A real UI bug was found and fixed by the E2E (recipe unit selector grabbed the wrong element) | Fixed | |
| **NOT built (16 modules):** Sales/orders/deliveries, Customers, Invoices, Payments/collections, Purchases, Suppliers, Expenses, Accounting, Employees, Machines, Quality, Reports, Smart assistant, Settings (incl. company identity, thresholds, shifts), Backup/restore, Audit history — their logic exists in `src/core`, their screens do not (placeholders remain) | |
| Invoice / delivery note / statement PDFs | **NOT built** | |
| Login / user sessions (**none yet**: native build runs as administrator; preview uses `?role=`) | **NOT built** | |
| Core error messages are English technical text; only the ~8 most common are translated | Known gap | |

Preview with real data in a desktop browser: `npm run preview:dev` then open http://127.0.0.1:8765/ (dev-only SQLite bridge, never shipped). E2E: `npm run e2e` (needs Playwright + Chromium).

## Screens — all 21 modules now have real screens
Dashboard, Products, Materials, Inventory, Production, Customers, Sales (orders/deliveries), Invoices (+A4 document, FR/AR, real PDF via print), Payments (suggested allocation, aging), Settings (company identity, tax rates, starter accounting, cash/bank accounts), Expenses (+budgets), Accounting (trial balance, income statement, balance sheet), Assistant, Reports (CSV), Backup/Restore, Audit, Suppliers (+payments), Purchases (PO → approve → receive → supplier invoice), Employees (+attendance), Machines (+maintenance plans), Quality.
Verified by three browser E2E suites (`npm run e2e`): ui, business (sales→cash, accounting, assistant, CSV, backup/restore, PDF), ops (purchasing, HR, machines, quality). Real bugs found and fixed by them: recipe unit selector, product price selector, invoice document wiring, error-message ordering, duplicate imports.
Known UI gaps: no login; no screens for shifts/shift output, product-specific machine capacity, waste/recovery, goods-return flows, credit-note lines, supplier payment cancellation, chart-of-accounts editing, alert-threshold editing, period closing (all exist in `src/core` but not in the UI).

## Android packaging (unverified)
Capacitor 6 project, no bundler (`npm run build` copies to `www/`). Android SQLite driver talks to the native plugin directly (`src/core/db/capacitor-driver.js`), Filesystem/Share plugins used for exports. See README_BUILD.md. **Never run on a device/emulator; APK never built here.**

## Test results
`npm test` → 119 unit/integration tests, 119 pass, 0 fail; `npm run e2e` (3 suites) → PASSED (Node 22.22, node:sqlite).

## Known gaps / limitations
- No APK yet; Android persistence, Arabic font rendering on device, and the plugin API usage are unverified.
- No login/user-session flow yet (audit `user_id` is nullable until Phase 5/7 user setup).
- Background photo of the references is not reproduced (no asset supplied); gradient used instead.
- Module icons are generic except the 5 main nav icons.

## Build commands
`npm install` · `npm test` · `npm run build` (→ `dist/`) · APK: push to GitHub and run workflow *Build Android debug APK* (or locally: `npx cap add android && npx cap sync android && cd android && ./gradlew assembleDebug`).
Preview UI locally: `python3 -m http.server` in project root → `/index.html`.

## Overall honest state
- Business core + all 21 screens: implemented and tested in a desktop browser against real SQLite.
- **NOT verified:** Android SQLite driver, Filesystem/Share on device, printing on Android, the APK itself, performance on a phone, Arabic fonts on a device.
- **NOT built:** login/sessions, backup encryption, the UI gaps listed above, signed release APK.

## Next exact tasks
1. Build the APK (README_BUILD.md) and send me the build log / device behaviour; fix Android driver issues first.
2. Close the UI gaps listed above; add login + first-run setup.
3. Security review, backup encryption, final acceptance workflow on a device.
