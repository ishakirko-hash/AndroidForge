# KHALDI PLAST ERP — Project Specification

Source of requirements: the owner's "Greenfield Master Instructions" and "Ultimate Master Prompt" (condensed here; the original wording prevails on any conflict).

## Product
Offline-first Android ERP for a plastic-crate factory in Algeria. FR (default) + AR (RTL). DZD. Local persistent SQLite. No cloud/AI API needed for core functions. Official logo used only as the supplied file (`assets/brand/logo-official.png`, checksums in `docs/`). UI reference: `reference/ui/*.png` (Liquid Glass).

## Modules (25)
Dashboard · Products/variants · Raw materials/BOM · Inventory/warehouse · Production · Shifts/operators · Machines/maintenance · Quality/waste · Sales orders/quotations · Delivery notes · Invoices/credit notes · Customers/receivables · Payment allocation/debt aging · Suppliers/purchasing · Supplier invoices/payables · Expenses · Manufacturing cost accounting · Cash & bank · Double-entry accounting · Employees/attendance · Reports · Offline smart assistant/alerts · Settings/permissions · Backup/restore · Audit history.

## Non-negotiable rules
1. Money/quantities: exact decimals only (`src/core/decimal.js`); never floats.
2. Every stock/payment/posting event is idempotent (`once()`), atomic (transaction) and audited (append-only `audit_log`).
3. Negative stock blocked by default; posted records are never edited silently (reversal/correction workflows).
4. Permissions enforced in business logic (`requirePermission`), not only in the UI.
5. Tax rates, chart of accounts, payroll rules: configurable + versioned; never presented as legally compliant without accountant review. No invented legal/bank identifiers.
6. Migrations are forward-only and checksummed; the database is never reset to fix errors.
7. Distinguish measured / entered / calculated / estimated / forecast values; never invent missing data.
8. No feature is claimed complete unless implemented AND verified (see IMPLEMENTATION_STATUS.md).

## Roadmap
P1 foundation (DB, design system, i18n, navigation, build workflow) · P2 products/materials/recipes/inventory/production · P3 customers/suppliers/sales/delivery/invoices/payments · P4 expenses/cost/accounting/cash/bank · P5 employees/shifts/maintenance/quality/purchasing intelligence · P6 reports/assistant/alerts/backup-restore · P7 integration tests, security review, UI polish, APK delivery.
