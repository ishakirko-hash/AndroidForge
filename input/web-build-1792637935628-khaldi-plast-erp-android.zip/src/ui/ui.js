import { t } from '../core/i18n/index.js';
import { esc, $, $$, rid } from './dom.js';
import { errorText } from './errors.js';

export function toast(message, kind = 'ok') {
  let host = $('#toasts'); if (!host) { host = document.createElement('div'); host.id = 'toasts'; host.setAttribute('role', 'status'); document.body.appendChild(host); }
  const el = document.createElement('div'); el.className = `toast ${kind}`; el.textContent = message; host.appendChild(el);
  setTimeout(() => el.remove(), kind === 'err' ? 6000 : 2500);
}

/** Bottom sheet. `html` is trusted markup built with esc(); mount(root, close) wires behaviour. */
export function openSheet({ title, html, mount }) {
  const back = document.createElement('div'); back.className = 'sheet-backdrop top';
  back.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="sheet-head"><h3>${esc(title)}</h3><button class="round-btn sm" data-x aria-label="${esc(t('common.close'))}">✕</button></div><div class="sheet-body">${html}</div></div>`;
  document.body.appendChild(back);
  const close = () => back.remove();
  back.addEventListener('click', (e) => { if (e.target === back || e.target.closest('[data-x]')) close(); });
  mount?.($('.sheet-body', back), close, back);
  return { close, root: back };
}

export const field = (f) => {
  const id = `f_${f.name}`, req = f.required ? ' required' : '', val = esc(f.value ?? '');
  const label = `<label for="${id}">${esc(f.label)}${f.required ? ' *' : f.hint === false ? '' : ''}</label>`;
  if (f.type === 'select') return `<div class="fld">${label}<select id="${id}" name="${f.name}"${req}>${(f.options ?? []).map((o) => `<option value="${esc(o.value)}"${String(o.value) === String(f.value ?? '') ? ' selected' : ''}>${esc(o.label)}</option>`).join('')}</select></div>`;
  if (f.type === 'textarea') return `<div class="fld">${label}<textarea id="${id}" name="${f.name}" rows="2">${val}</textarea></div>`;
  const mode = f.type === 'number' ? ' inputmode="decimal" autocomplete="off"' : '';
  return `<div class="fld">${label}<input id="${id}" name="${f.name}" type="text"${mode} value="${val}"${req}${f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : ''}>${f.help ? `<small>${esc(f.help)}</small>` : ''}</div>`;
};

/**
 * Generic form sheet. Double submission is blocked (button disabled while saving); on failure the sheet stays open with the
 * user's input preserved and the error shown inline. `extra` = extra trusted markup placed before the buttons.
 */
export function formSheet({ title, fields, submitLabel = t('common.save'), extra = '', onSubmit, mount }) {
  const html = `<form novalidate>${fields.map(field).join('')}${extra}<div class="form-error" role="alert" hidden></div>
    <div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(submitLabel)}</button></div></form>`;
  return openSheet({ title, html, mount: (root, close, back) => {
    const form = $('form', root); let busy = false;
    mount?.(root, close);
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); if (busy) return; busy = true;
      const btn = $('button[type=submit]', form); btn.disabled = true; const err = $('.form-error', form); err.hidden = true;
      try {
        const values = Object.fromEntries(new FormData(form).entries());
        for (const f of fields) if (f.required && !String(values[f.name] ?? '').trim()) throw new Error(`${f.label} is required`);
        await onSubmit(values, form); close();
      } catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; busy = false; }
    });
  } });
}
export const idemKey = (prefix) => `ui:${prefix}:${rid()}`;
export const chip = (text, tone = '') => `<span class="chip tone ${tone}">${esc(text)}</span>`;
export { $, $$, esc };
