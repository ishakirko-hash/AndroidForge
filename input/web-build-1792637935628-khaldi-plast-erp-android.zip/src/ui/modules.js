// Module registry. `phase` = roadmap phase in which the real screen is delivered; `built` is true only when it truly works.
export const MODULE_LIST = [
  { id: 'dashboard', phase: 1, built: true, tone: 'blue' },
  { id: 'sales', phase: 3, built: true, tone: 'green' },
  { id: 'inventory', phase: 2, built: true, tone: 'amber' },
  { id: 'production', phase: 2, built: true, tone: 'blue' },
  { id: 'products', phase: 2, built: true, tone: 'blue' },
  { id: 'materials', phase: 2, built: true, tone: 'amber' },
  { id: 'customers', phase: 3, built: true, tone: 'violet' },
  { id: 'invoices', phase: 3, built: true, tone: 'green' },
  { id: 'payments', phase: 3, built: true, tone: 'green' },
  { id: 'purchases', phase: 5, built: true, tone: 'amber' },
  { id: 'suppliers', phase: 3, built: true, tone: 'violet' },
  { id: 'expenses', phase: 4, built: true, tone: 'red' },
  { id: 'accounting', phase: 4, built: true, tone: 'teal' },
  { id: 'employees', phase: 5, built: true, tone: 'violet' },
  { id: 'machines', phase: 5, built: true, tone: 'teal' },
  { id: 'quality', phase: 5, built: true, tone: 'teal' },
  { id: 'reports', phase: 6, built: true, tone: 'orange' },
  { id: 'assistant', phase: 6, built: true, tone: 'blue' },
  { id: 'settings', phase: 1, built: true, tone: 'slate' },
  { id: 'backup', phase: 6, built: true, tone: 'slate' },
  { id: 'audit', phase: 4, built: true, tone: 'slate' },
];
export const BOTTOM_NAV = ['dashboard', 'sales', 'inventory', 'production']; // 5th item is "More"
export const ICONS = {
  dashboard: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  sales: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  inventory: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>',
  production: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
  more: '<circle cx="12" cy="8" r="3.5"/><path d="M5 21c0-4 3-6 7-6s7 2 7 6"/>',
  generic: '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M8 12h8M12 8v8"/>',
};
export const icon = (id, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[id] ?? ICONS.generic}</svg>`;
