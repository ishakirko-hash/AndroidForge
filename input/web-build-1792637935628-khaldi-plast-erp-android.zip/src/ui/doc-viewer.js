import { t } from '../core/i18n/index.js';
import { esc, $ } from './dom.js';
/** Full-screen scaled preview of an A4 document with Print / Save as PDF (system print dialog). */
export function openDocument(html, title) {
  const ov = document.createElement('div'); ov.className = 'doc-overlay';
  ov.innerHTML = `<div class="doc-bar"><button class="btn secondary sm" data-x>${esc(t('common.close'))}</button><button class="btn primary sm" data-print>${esc(t('inv.print'))}</button></div><div class="doc-stage" aria-label="${esc(title)}">${html}</div>`;
  document.body.appendChild(ov);
  const fit = () => { const s = Math.min(1, (window.innerWidth - 16) / 794), st = $('.doc-stage', ov); st.style.transform = `scale(${s})`; st.style.height = `${1123 * s}px`; st.parentElement.style.minHeight = '0'; };
  fit(); window.addEventListener('resize', fit);
  const close = () => { window.removeEventListener('resize', fit); ov.remove(); };
  ov.addEventListener('click', (e) => { if (e.target.closest('[data-x]')) close(); if (e.target.closest('[data-print]')) { document.body.classList.add('printing-doc'); window.addEventListener('afterprint', () => document.body.classList.remove('printing-doc'), { once: true }); window.print(); } });
  return { close, root: ov };
}
