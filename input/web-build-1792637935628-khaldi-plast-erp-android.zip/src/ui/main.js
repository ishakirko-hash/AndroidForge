import { t, setLanguage, getLanguage } from '../core/i18n/index.js';
import { initDatabase } from '../core/database.js';
import { can as canRole } from '../core/permissions.js';
import { MODULE_LIST, BOTTOM_NAV, icon } from './modules.js';
import { esc, $, $$ } from './dom.js';
import { errorText } from './errors.js';
import { dashboardScreen } from './screens/dashboard.js';
import { productsScreen } from './screens/products.js';
import { materialsScreen } from './screens/materials.js';
import { inventoryScreen } from './screens/inventory.js';
import { productionScreen } from './screens/production.js';
import { customersScreen } from './screens/customers.js';
import { salesScreen } from './screens/sales.js';
import { invoicesScreen } from './screens/invoices.js';
import { paymentsScreen } from './screens/payments.js';
import { settingsScreen } from './screens/settings.js';
import { expensesScreen } from './screens/expenses.js';
import { accountingScreen } from './screens/accounting.js';
import { assistantScreen } from './screens/assistant.js';
import { reportsScreen } from './screens/reports.js';
import { backupScreen } from './screens/backup.js';
import { auditScreen } from './screens/audit.js';
import { suppliersScreen } from './screens/suppliers.js';
import { purchasesScreen } from './screens/purchases.js';
import { employeesScreen } from './screens/employees.js';
import { machinesScreen } from './screens/machines.js';
import { qualityScreen } from './screens/quality.js';

const logoUrl = new URL('../../assets/brand/logo-official.png', import.meta.url).href; // exact official asset, never redrawn
const SCREENS = { dashboard: dashboardScreen, products: productsScreen, materials: materialsScreen, inventory: inventoryScreen, production: productionScreen, customers: customersScreen, sales: salesScreen, invoices: invoicesScreen, payments: paymentsScreen, settings: settingsScreen,
  expenses: expensesScreen, accounting: accountingScreen, assistant: assistantScreen, reports: reportsScreen, backup: backupScreen, audit: auditScreen,
  purchases: purchasesScreen, suppliers: suppliersScreen, employees: employeesScreen, machines: machinesScreen, quality: qualityScreen };
const app = document.getElementById('app');
const state = { sheet: false, db: null, dbKind: 'preview', schema: null };
const native = !!window.Capacitor?.isNativePlatform?.();
// NO AUTHENTICATION YET. Native builds run as administrator; the desktop preview may pick a role with ?role=… to exercise permissions.
const role = native ? 'admin' : (new URLSearchParams(location.search).get('role') || 'admin');
const user = { id: `local-${role}`, role };

try { const l = localStorage.getItem('kp.lang'); if (l === 'fr' || l === 'ar') setLanguage(l); } catch { /* preference only */ }
const route = () => { const r = (location.hash.replace(/^#\/?/, '') || 'dashboard'); return MODULE_LIST.some((m) => m.id === r) ? r : 'dashboard'; };

async function startDatabase() {
  try {
    if (native) {
      const { createCapacitorDriver } = await import('../core/db/capacitor-driver.js');
      const r = await initDatabase(await createCapacitorDriver()); state.db = r.db; state.dbKind = 'native'; state.schema = r.schemaVersion;
    } else {
      const { bridgeAvailable, createHttpDriver } = await import('../core/db/http-driver.js');
      if (location.protocol.startsWith('http') && await bridgeAvailable()) { const r = await initDatabase(createHttpDriver()); state.db = r.db; state.dbKind = 'bridge'; state.schema = r.schemaVersion; }
    }
  } catch (e) { console.error(e); state.dbKind = 'error'; }
  renderShell();
}

const dbChip = () => state.dbKind === 'native' || state.dbKind === 'bridge' ? `<span class="chip ok">${esc(t('status.db.native', { v: state.schema }))}${state.dbKind === 'bridge' ? ' · preview' : ''}</span>`
  : state.dbKind === 'error' ? `<span class="chip err">${esc(t('status.db.error'))}</span>` : `<span class="chip">${esc(t('status.db.preview'))}</span>`;
const mod = (id) => MODULE_LIST.find((m) => m.id === id);
const shortcut = (m) => `<button class="shortcut" data-go="${m.id}"><span class="tile tone-${m.tone}">${icon(m.id)}</span>${esc(t('nav.' + m.id))}</button>`;
const placeholder = (m) => `<section class="glass notice"><span class="tile tone-${m.tone}">${icon(m.id)}</span><h2>${esc(t('nav.' + m.id))}</h2><p>${esc(t('module.notBuilt'))}</p><p>${esc(t('module.notBuiltHint', { phase: m.phase }))}</p><span class="chip" style="margin-top:8px">${esc(t('status.planned', { phase: m.phase }))}</span></section>`;
const bottomNav = (r) => `<nav class="glass bottom-nav" aria-label="Navigation">${BOTTOM_NAV.map((id) => `<button class="nav-item" data-go="${id}" ${r === id ? 'aria-current="page"' : ''}>${icon(id)}${esc(t('nav.' + id).split(' ')[0])}</button>`).join('')}<button class="nav-item" data-more ${state.sheet || !BOTTOM_NAV.includes(r) ? 'aria-current="page"' : ''}>${icon('more')}${esc(t('common.more'))}</button></nav>`;
const sheet = () => !state.sheet ? '' : `<div class="sheet-backdrop" data-close><div class="sheet" role="dialog" aria-modal="true"><h3>${esc(t('common.language'))}</h3><div class="lang"><button data-lang="fr" aria-pressed="${getLanguage() === 'fr'}">Français</button><button data-lang="ar" aria-pressed="${getLanguage() === 'ar'}">العربية</button></div><h3>${esc(t('common.more'))}</h3><div class="shortcuts">${MODULE_LIST.filter((m) => !BOTTOM_NAV.includes(m.id) && m.id !== 'dashboard').map(shortcut).join('')}</div></div></div>`;

let token = 0;
function renderShell() {
  const r = route();
  app.innerHTML = `<div class="topbar"><button class="round-btn" data-more aria-label="${esc(t('common.more'))}">☰</button><button class="round-btn" data-lang-toggle aria-label="${esc(t('common.language'))}">${getLanguage() === 'fr' ? 'ع' : 'FR'}</button></div>
    <div class="brand ${r === 'dashboard' ? '' : 'compact'}"><img src="${logoUrl}" alt="KHALDI PLAST — SHAPING TOMORROW" /></div><main id="view" class="view" aria-live="polite"></main>${bottomNav(r)}${sheet()}`;
  renderView();
}
async function renderView() {
  const my = ++token, r = route(), m = mod(r), view = $('#view'); if (!view) return;
  const ctx = { db: state.db, user, lang: getLanguage(), can: (mm, a) => canRole(user.role, mm, a), reload: renderView, dbChip: dbChip() };
  try {
    let out;
    if (!state.db) out = { html: r === 'dashboard' ? `<section class="glass hello"><div><h1>${esc(t('common.welcome'))}</h1><p>${esc(t('common.dashboard'))}</p></div>${dbChip()}</section><div class="section-title">${esc(t('common.more'))}</div><div class="shortcuts">${MODULE_LIST.filter((x) => !['dashboard', ...BOTTOM_NAV].includes(x.id)).slice(0, 8).map(shortcut).join('')}</div>` : `<section class="glass notice"><h2>${esc(t('nav.' + r))}</h2><p>${esc(t('status.db.preview'))}</p></section>`, mount() {} };
    else if (SCREENS[r] && m.built) out = await SCREENS[r](ctx);
    else out = { html: placeholder(m), mount() {} };
    if (my !== token) return;
    view.innerHTML = out.html; out.mount(view); view.dataset.route = r;
  } catch (e) { console.error(e); if (my === token) view.innerHTML = `<section class="glass notice"><h2>${esc(t('status.db.error'))}</h2><p>${esc(errorText(e))}</p></section>`; }
}

app.addEventListener('click', (e) => {
  const el = e.target.closest('[data-go],[data-more],[data-lang],[data-lang-toggle],[data-close]'); if (!el) return;
  if (el.dataset.go) { state.sheet = false; if (location.hash !== `#/${el.dataset.go}`) location.hash = `#/${el.dataset.go}`; else renderShell(); return; }
  if (el.hasAttribute('data-more')) state.sheet = !state.sheet;
  else if (el.dataset.lang || el.hasAttribute('data-lang-toggle')) {
    const l = el.dataset.lang ?? (getLanguage() === 'fr' ? 'ar' : 'fr'); setLanguage(l); state.sheet = false; $$('.sheet-backdrop.top').forEach((s) => s.remove());
    try { localStorage.setItem('kp.lang', l); } catch { /* preference only */ }
  } else if (el.hasAttribute('data-close') && e.target === el) state.sheet = false;
  renderShell();
});
window.addEventListener('hashchange', () => { $$('.sheet-backdrop.top').forEach((s) => s.remove()); renderShell(); });
setLanguage(getLanguage());
renderShell();
startDatabase();
