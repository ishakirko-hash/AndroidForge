import { getLanguage } from '../core/i18n/index.js';
/** Quantities: only the decimals that matter (max 4). Money: always 2 decimals. */
export const qty = (d) => { const s = d.toString(); return d.format(getLanguage(), Math.min(s.includes('.') ? s.split('.')[1].length : 0, 4)); };
export const money = (d) => d.format(getLanguage(), 2);
export const dstr = (iso) => (iso ?? '').slice(0, 10);
/** Keeps numbers with their unit/percent sign in reading order inside right-to-left text (Unicode LTR isolate). */
export const ltr = (s) => `\u2066${s}\u2069`;
export const moneyDA = (d) => ltr(`${money(d)} DA`);
export const pct = (d) => ltr(`${d.round(2).format(getLanguage(), 2)} %`);
