import { t } from '../../core/i18n/index.js';
import { D, Dec } from '../../core/decimal.js';
import { recordPayment, cancelPayment, suggestAllocation, debtAging, openInvoices } from '../../core/receivables.js';
import { esc, $, $$, openSheet, idemKey, chip, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { moneyDA, money, dstr } from '../fmt.js';
import { today } from '../../core/dates.js';

const METHODS = ['cash', 'bank_transfer', 'cheque', 'other'];

/** Record a payment. Allocation is SUGGESTED (oldest due first) and editable; nothing is posted until the user confirms. */
export async function paymentSheet(ctx, customerId = '') {
  const { db } = ctx; const key = idemKey('pay');
  const customers = await db.all('SELECT id, ref, name FROM customers WHERE active=1 ORDER BY name');
  if (!customers.length) return toast(t('so.needCustomers'), 'err');
  const accounts = await db.all('SELECT id, name, kind FROM financial_accounts WHERE active=1 ORDER BY name');
  openSheet({ title: t('pay.new'), html: `<form novalidate>
    <div class="fld"><label for="pc">${esc(t('c.customer'))} *</label><select id="pc"><option value="">${esc(t('pay.pickCustomer'))}</option>${customers.map((c) => `<option value="${esc(c.id)}"${c.id === customerId ? ' selected' : ''}>${esc(c.name)} (${esc(c.ref)})</option>`).join('')}</select></div>
    <div class="fld"><label for="pa">${esc(t('pay.amount'))} *</label><input id="pa" inputmode="decimal" autocomplete="off"></div>
    <div class="fld"><label for="pm">${esc(t('pay.method'))}</label><select id="pm">${METHODS.map((m) => `<option value="${m}">${esc(t('pay.' + m))}</option>`).join('')}</select></div>
    <div class="fld"><label for="pf">${esc(t('pay.account'))}</label><select id="pf"><option value="">${esc(t('pay.noAccount'))}</option>${accounts.map((a) => `<option value="${esc(a.id)}">${esc(a.name)}</option>`).join('')}</select></div>
    <div class="fld"><label for="pr">${esc(t('pay.reference'))}</label><input id="pr" autocomplete="off"></div>
    <div class="fld"><label for="pd">${esc(t('common.date'))}</label><input id="pd" value="${today()}" autocomplete="off"></div>
    <div class="glass section" id="alloc" hidden></div><div class="form-error" hidden role="alert"></div>
    <div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => {
    const cSel = $('#pc', root), amt = $('#pa', root), box = $('#alloc', root), err = $('.form-error', root); let busy = false, timer;
    const refresh = async () => {
      err.hidden = true; box.hidden = true;
      if (!cSel.value || !amt.value.trim()) return;
      try {
        const open = await openInvoices(db, cSel.value);
        if (!open.length) { box.innerHTML = `<p>${esc(t('pay.noOpen'))}</p><div class="warn">${esc(t('pay.excess'))}</div>`; box.hidden = false; return; }
        const s = await suggestAllocation(db, cSel.value, amt.value); const sug = new Map(s.allocations.map((a) => [a.invoiceId, a.amount]));
        box.innerHTML = `<h2>${esc(t('pay.allocation'))}</h2><small>${esc(t('pay.suggest'))}</small><table class="tbl">${open.map((i) => `<tr><td>${esc(i.number)}<br><small>${esc(t('inv.dueDate'))} ${esc(i.due_date)} · ${esc(moneyDA(i.outstanding))}</small></td><td class="n"><input data-alloc="${esc(i.id)}" inputmode="decimal" autocomplete="off" value="${sug.has(i.id) ? esc(sug.get(i.id).toString()) : ''}" style="width:110px;min-height:42px;border-radius:12px;border:1px solid #c3d6f2;padding:0 8px;text-align:end"></td></tr>`).join('')}</table>
          ${s.excess.gt(0) ? `<div class="warn" data-excess>${esc(t('pay.excess'))} : ${esc(moneyDA(s.excess))}</div>` : ''}`; box.hidden = false;
      } catch (x) { err.textContent = errorText(x); err.hidden = false; }
    };
    for (const el of [cSel, amt]) el.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(refresh, 250); });
    if (customerId) refresh();
    $('form', root).addEventListener('submit', async (e) => {
      e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true; err.hidden = true;
      try {
        if (!cSel.value) throw new Error('customer is required');
        const allocations = $$('[data-alloc]', box).filter((i) => i.value.trim() && !D(i.value).isZero()).map((i) => ({ invoiceId: i.dataset.alloc, amount: i.value }));
        const r = await recordPayment(db, ctx.user, { customerId: cSel.value, amount: amt.value, method: $('#pm', root).value, reference: $('#pr', root).value.trim() || null, payDate: $('#pd', root).value.trim() || undefined, finAccountId: $('#pf', root).value || null, eventKey: key, allocations });
        toast(`${r.number} ✓`); close(); ctx.reload();
      } catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; busy = false; }
    });
  } });
}

async function paymentDetail(ctx, id) {
  const { db, can } = ctx;
  const p = await db.get('SELECT p.*, c.name cname FROM payments p JOIN customers c ON c.id=p.customer_id WHERE p.id=?', [id]);
  const al = await db.all('SELECT pa.amount, i.number FROM payment_allocations pa JOIN invoices i ON i.id=pa.invoice_id WHERE pa.payment_id=?', [id]);
  openSheet({ title: p.number, html: `<div class="glass kv"><span>${esc(t('c.customer'))}</span><span>${esc(p.cname)}</span><span>${esc(t('pay.amount'))}</span><span>${esc(moneyDA(D(p.amount)))}</span><span>${esc(t('pay.method'))}</span><span>${esc(t('pay.' + p.method))}</span><span>${esc(t('common.date'))}</span><span>${esc(p.pay_date)}</span><span>${esc(t('common.status'))}</span><span>${chip(p.status === 'valid' ? t('pay.valid') : t('pay.cancelled_st'), p.status === 'valid' ? 'green' : 'red')}</span>${p.reference ? `<span>${esc(t('pay.reference'))}</span><span>${esc(p.reference)}</span>` : ''}</div>
    ${al.length ? `<div class="glass section"><h2>${esc(t('pay.allocation'))}</h2><table class="tbl">${al.map((a) => `<tr><td>${esc(a.number)}</td><td class="n">${esc(moneyDA(D(a.amount)))}</td></tr>`).join('')}</table></div>` : ''}
    <div class="actions">${can('payments', 'post') && p.status === 'valid' ? `<button class="btn danger" data-cancel>${esc(t('pay.cancel'))}</button>` : ''}</div>`,
  mount: (root, close) => $('[data-cancel]', root)?.addEventListener('click', () => {
    close(); openSheet({ title: t('pay.cancel'), html: `<form novalidate><div class="fld"><label for="cr">${esc(t('common.reason'))} *</label><input id="cr" autocomplete="off"></div><div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn danger">${esc(t('pay.cancel'))}</button></div></form>`,
      mount: (r2, close2) => $('form', r2).addEventListener('submit', async (e) => { e.preventDefault(); try { await cancelPayment(db, ctx.user, id, $('#cr', r2).value); close2(); toast(t('common.saved')); ctx.reload(); } catch (x) { const er = $('.form-error', r2); er.textContent = errorText(x); er.hidden = false; } }) });
  }) });
}

export async function paymentsScreen(ctx) {
  const { db, can } = ctx;
  const aging = await debtAging(db), b = aging.buckets;
  const rows = await db.all('SELECT p.*, c.name cname FROM payments p JOIN customers c ON c.id=p.customer_id ORDER BY p.pay_date DESC, p.number DESC LIMIT 100');
  const html = `<div class="page-head"><h1>${esc(t('nav.payments').split(' ')[0])}</h1>${can('payments', 'post') ? `<button class="btn primary sm" data-new>+ ${esc(t('pay.new'))}</button>` : ''}</div>
    <div class="glass section"><h2>${esc(t('pay.aging'))}</h2><div class="kv" style="padding:0;margin:0"><span>${esc(t('pay.outstandingTotal'))}</span><span>${esc(moneyDA(aging.outstanding))}</span><span>${esc(t('pay.overdueTotal'))}</span><span class="${aging.overdue.gt(0) ? 'bad' : ''}">${esc(moneyDA(aging.overdue))}</span>
      <span>${esc(t('pay.notDue'))}</span><span>${esc(moneyDA(b.notDue))}</span><span>${esc(t('pay.d1'))}</span><span>${esc(moneyDA(b.d1_30))}</span><span>${esc(t('pay.d2'))}</span><span>${esc(moneyDA(b.d31_60))}</span><span>${esc(t('pay.d3'))}</span><span>${esc(moneyDA(b.d61_90))}</span><span>${esc(t('pay.over90'))}</span><span>${esc(moneyDA(b.over90))}</span></div></div>
    <div class="list">${rows.map((p) => `<button class="glass card" data-id="${esc(p.id)}"><div><div class="t1">${esc(p.number)} · ${esc(p.cname)}</div><div class="t2">${esc(dstr(p.pay_date))} · ${esc(t('pay.' + p.method))}${p.reference ? ' · ' + esc(p.reference) : ''}</div></div><div class="num">${esc(money(D(p.amount)))}<small>${p.status === 'valid' ? 'DA' : esc(t('pay.cancelled_st'))}</small></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) { $('[data-new]', root)?.addEventListener('click', () => paymentSheet(ctx)); $$('.card', root).forEach((c) => c.addEventListener('click', () => paymentDetail(ctx, c.dataset.id))); } };
}
