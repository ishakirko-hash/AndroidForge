import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { createPurchaseOrder, approvePurchaseOrder, receiveGoods, poProgress, recordSupplierInvoice, supplierInvoiceOutstanding } from '../../core/purchasing.js';
import { today } from '../../core/dates.js';
import { esc, $, $$, openSheet, chip, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { qty as fq, money, moneyDA } from '../fmt.js';
import { paySupplierSheet } from './suppliers.js';

const TONE = { draft: 'slate', approved: 'blue', partially_received: 'amber', received: 'green', cancelled: 'red' };
const errIn = (r, x) => { const e = $('.form-error', r); e.textContent = errorText(x); e.hidden = false; };

async function supplierInvoiceSheet(ctx, po, prog) {
  const { db } = ctx; const rates = await db.all('SELECT code, label, rate_pct FROM tax_rates WHERE active=1 ORDER BY rate_pct');
  const mats = Object.fromEntries((await db.all('SELECT id, ref, name FROM materials')).map((m) => [m.id, m]));
  openSheet({ title: t('po.invoice'), html: `<form novalidate><div class="fld"><label for="sr">${esc(t('po.supplierRef'))} *</label><input id="sr" autocomplete="off"></div><div class="fld"><label for="sd">${esc(t('inv.issueDate'))}</label><input id="sd" value="${today()}" autocomplete="off"></div>
    <div class="fld"><label for="stx">${esc(t('inv.taxCode'))}</label><select id="stx"><option value="">${esc(t('inv.exempt'))}</option>${rates.map((r) => `<option value="${esc(r.code)}">${esc(r.label)} ${esc(D(r.rate_pct).toString())} %</option>`).join('')}</select></div>
    ${prog.map((p) => `<div class="glass section"><b>${esc(mats[p.materialId].ref)} ${esc(mats[p.materialId].name)}</b><div class="r3" style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:6px"><input data-q inputmode="decimal" autocomplete="off" value="${esc(p.ordered.toString())}" aria-label="${esc(t('common.qty'))}"><input data-p inputmode="decimal" autocomplete="off" value="${esc(p.unitPrice.toString())}" aria-label="${esc(t('po.unitPrice'))}" data-d="${esc(mats[p.materialId].name)}" style="min-height:44px;border-radius:12px;border:1px solid #c3d6f2;padding:0 8px"></div></div>`).join('')}
    <div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => { let busy = false; $('form', root).addEventListener('submit', async (e) => { e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true;
    try { const tax = $('#stx', root).value || undefined; const lines = $$('[data-p]', root).map((pi, i) => ({ description: pi.dataset.d, qty: $$('[data-q]', root)[i].value, unitPrice: pi.value, taxCode: tax }));
      const r = await recordSupplierInvoice(db, ctx.user, { supplierId: po.supplier_id, supplierRef: $('#sr', root).value, poId: po.id, issueDate: $('#sd', root).value.trim() || undefined, lines }); toast(`${r.number} ✓`); close(); ctx.reload();
    } catch (x) { errIn(root, x); btn.disabled = false; busy = false; } }); } });
}

async function openPo(ctx, id) {
  const { db, can } = ctx;
  const po = await db.get('SELECT po.*, s.name sname FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id WHERE po.id=?', [id]);
  const prog = await poProgress(db, id); const mats = Object.fromEntries((await db.all('SELECT id, ref, name, unit FROM materials')).map((m) => [m.id, m]));
  const A = []; if (can('purchases', 'post') && po.status === 'draft') A.push('approve'); if (can('purchases', 'post') && ['approved', 'partially_received'].includes(po.status)) A.push('receive'); if (can('suppliers', 'post') && ['partially_received', 'received'].includes(po.status)) A.push('invoice');
  const label = { approve: t('po.approve'), receive: t('po.receive'), invoice: t('po.invoice') };
  openSheet({ title: po.number, html: `<div class="glass kv"><span>${esc(t('po.supplier'))}</span><span>${esc(po.sname)}</span><span>${esc(t('common.status'))}</span><span>${chip(t('po.st_' + po.status), TONE[po.status])}</span></div><div class="warn">${esc(t('po.note'))}</div>
    <div class="glass section"><table class="tbl"><tr><th>${esc(t('m.title'))}</th><th class="n">${esc(t('so.ordered'))}</th><th class="n">${esc(t('po.received'))}</th></tr>${prog.map((p) => `<tr><td>${esc(mats[p.materialId].ref)}<br><small>${esc(money(p.unitPrice))} DA</small></td><td class="n">${esc(fq(p.ordered))} ${esc(mats[p.materialId].unit)}</td><td class="n">${esc(fq(p.received))}</td></tr>`).join('')}</table></div>
    <div class="actions" style="flex-wrap:wrap">${A.map((a) => `<button class="btn primary" data-act="${a}">${esc(label[a])}</button>`).join('')}</div>`,
  mount: (root, close) => {
    $('[data-act=approve]', root)?.addEventListener('click', async (e) => { e.target.disabled = true; try { await approvePurchaseOrder(db, ctx.user, id); toast(t('common.saved')); close(); await ctx.reload(); openPo(ctx, id); } catch (x) { toast(errorText(x), 'err'); } });
    $('[data-act=invoice]', root)?.addEventListener('click', () => { close(); supplierInvoiceSheet(ctx, po, prog); });
    $('[data-act=receive]', root)?.addEventListener('click', () => { close(); const rem = prog.filter((p) => p.remaining.gt(0));
      openSheet({ title: `${t('po.receive')} — ${po.number}`, html: `<form novalidate>${rem.map((p) => `<div class="fld"><label>${esc(mats[p.materialId].ref)} — ${esc(t('so.remaining'))} ${esc(fq(p.remaining))}</label><input data-line="${p.lineNo}" inputmode="decimal" autocomplete="off" placeholder="0"></div>`).join('')}<div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('po.receive'))}</button></div></form>`,
        mount: (r, close2) => { let busy = false; $('form', r).addEventListener('submit', async (e) => { e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', r); btn.disabled = true;
          try { const lines = $$('[data-line]', r).filter((i) => i.value.trim() && !D(i.value).isZero()).map((i) => ({ lineNo: Number(i.dataset.line), qty: i.value })); if (!lines.length) throw new Error('quantity must be greater than zero');
            const x = await receiveGoods(db, ctx.user, id, { lines }); toast(`${x.number} ✓`); close2(); await ctx.reload(); openPo(ctx, id); } catch (x) { errIn(r, x); btn.disabled = false; busy = false; } }); } }); });
  } });
}

async function newPoSheet(ctx) {
  const { db } = ctx; const suppliers = await db.all('SELECT id, ref, name FROM suppliers WHERE active=1 ORDER BY name'), mats = await db.all("SELECT id, ref, name, unit, purchase_cost FROM materials WHERE status='active' ORDER BY ref");
  if (!suppliers.length) return toast(t('po.needSuppliers'), 'err'); if (!mats.length) return toast(t('p.needMaterials'), 'err');
  const line = () => `<div class="row-line glass"><div class="rh"><select data-mat aria-label="${esc(t('m.title'))}">${mats.map((m) => `<option value="${esc(m.id)}" data-pc="${esc(m.purchase_cost ?? '')}">${esc(m.ref)} — ${esc(m.name)} (${esc(m.unit)})</option>`).join('')}</select><button type="button" class="round-btn sm" data-rm aria-label="✕">✕</button></div><div class="r3" style="grid-template-columns:1fr 1fr"><input data-qty inputmode="decimal" autocomplete="off" placeholder="${esc(t('common.qty'))}" aria-label="${esc(t('common.qty'))}"><input data-price inputmode="decimal" autocomplete="off" placeholder="${esc(t('po.unitPrice'))}" aria-label="${esc(t('po.unitPrice'))}" value="${esc(mats[0].purchase_cost ?? '')}"></div></div>`;
  openSheet({ title: t('po.new'), html: `<form novalidate><div class="fld"><label for="ps">${esc(t('po.supplier'))} *</label><select id="ps">${suppliers.map((s) => `<option value="${esc(s.id)}">${esc(s.name)} (${esc(s.ref)})</option>`).join('')}</select></div><div class="row-lines" id="lines">${line()}</div><button type="button" class="btn secondary sm" data-add>+ ${esc(t('so.addLine'))}</button><div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => { const lines = $('#lines', root); let busy = false;
    $('[data-add]', root).addEventListener('click', () => lines.insertAdjacentHTML('beforeend', line()));
    root.addEventListener('click', (e) => { if (e.target.closest('[data-rm]') && $$('.row-line', lines).length > 1) e.target.closest('.row-line').remove(); });
    root.addEventListener('change', (e) => { if (e.target.matches('[data-mat]')) $('[data-price]', e.target.closest('.row-line')).value = e.target.selectedOptions[0].dataset.pc; });
    $('form', root).addEventListener('submit', async (e) => { e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true;
      try { const r = await createPurchaseOrder(db, ctx.user, { supplierId: $('#ps', root).value, lines: $$('.row-line', lines).map((l) => ({ materialId: $('[data-mat]', l).value, qty: $('[data-qty]', l).value, unitPrice: $('[data-price]', l).value })) }); toast(`${r.number} ✓`); close(); await ctx.reload(); openPo(ctx, r.id);
      } catch (x) { errIn(root, x); btn.disabled = false; busy = false; } }); } });
}

export async function purchasesScreen(ctx) {
  const { db, can } = ctx;
  const rows = await db.all('SELECT po.*, s.name sname FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id ORDER BY po.order_date DESC, po.number DESC LIMIT 100');
  const si = []; for (const i of await db.all("SELECT i.*, s.name sname FROM supplier_invoices i JOIN suppliers s ON s.id=i.supplier_id WHERE i.status='issued' ORDER BY i.issue_date DESC LIMIT 50")) si.push({ i, out: await supplierInvoiceOutstanding(db, i.id) });
  const html = `<div class="page-head"><h1>${esc(t('nav.purchases'))}</h1>${can('purchases', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('po.new'))}</button>` : ''}</div>
    <div class="list">${rows.map((o) => `<button class="glass card" data-id="${esc(o.id)}"><div><div class="t1">${esc(o.number)}</div><div class="t2">${esc(o.sname)} · ${esc(o.order_date)}</div></div><div class="num">${chip(t('po.st_' + o.status), TONE[o.status])}</div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>
    <div class="section-title">${esc(t('po.sinv'))}</div><div class="list">${si.map(({ i, out }) => `<button class="glass card" data-pay="${esc(i.supplier_id)}"><div><div class="t1">${esc(i.number)} · ${esc(i.supplier_ref)}</div><div class="t2">${esc(i.sname)} · ${esc(t('inv.dueDate'))} ${esc(i.due_date)}</div></div><div class="num">${esc(money(out))}<small>/ ${esc(money(D(i.total_ttc)))} DA</small></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) { $('[data-new]', root)?.addEventListener('click', () => newPoSheet(ctx)); $$('.card[data-id]', root).forEach((c) => c.addEventListener('click', () => openPo(ctx, c.dataset.id)));
    $$('.card[data-pay]', root).forEach((c) => c.addEventListener('click', () => { if (can('suppliers', 'post')) paySupplierSheet(ctx, c.dataset.pay); })); } };
}
