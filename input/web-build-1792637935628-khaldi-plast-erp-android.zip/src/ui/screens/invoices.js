import { t, getLanguage } from '../../core/i18n/index.js';
import { D, Dec } from '../../core/decimal.js';
import { computeInvoice, issueInvoice, cancelInvoice, issueCreditNote } from '../../core/invoicing.js';
import { invoiceOutstanding } from '../../core/receivables.js';
import { getCompany } from '../../core/settings.js';
import { today } from '../../core/dates.js';
import { esc, $, $$, openSheet, chip, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { qty as fq, moneyDA, money } from '../fmt.js';
import { invoiceDocumentHtml } from '../documents/invoice.js';
import { openDocument } from '../doc-viewer.js';
import { paymentSheet } from './payments.js';

export async function invoiceSheet(ctx, init = {}) {
  const { db } = ctx;
  const customers = await db.all('SELECT id, ref, name FROM customers WHERE active=1 ORDER BY name');
  if (!customers.length) return toast(t('so.needCustomers'), 'err');
  const products = await db.all("SELECT id, ref, name_fr, sale_price FROM products WHERE status='active' ORDER BY ref");
  const rates = await db.all('SELECT code, label, rate_pct FROM tax_rates WHERE active=1 ORDER BY rate_pct');
  const rateOf = new Map(rates.map((r) => [r.code, r.rate_pct]));
  const lineHtml = (l = {}) => `<div class="row-line glass"><div class="rh"><select data-prod aria-label="${esc(t('inv.product'))}"><option value="">${esc(t('inv.noProduct'))}</option>${products.map((p) => `<option value="${esc(p.id)}" data-sp="${esc(p.sale_price)}" data-pn="${esc(p.name_fr)}"${p.id === l.productId ? ' selected' : ''}>${esc(p.ref)} — ${esc(p.name_fr)}</option>`).join('')}</select><button type="button" class="round-btn sm" data-rm aria-label="✕">✕</button></div>
    <input data-desc placeholder="${esc(t('inv.description'))}" aria-label="${esc(t('inv.description'))}" value="${esc(l.description ?? '')}">
    <div class="r3"><input data-qty inputmode="decimal" autocomplete="off" placeholder="${esc(t('inv.qty'))}" aria-label="${esc(t('inv.qty'))}" value="${esc(l.qty ?? '')}"><input data-price inputmode="decimal" autocomplete="off" placeholder="${esc(t('inv.pu'))}" aria-label="${esc(t('inv.pu'))}" value="${esc(l.unitPrice ?? '')}"><input data-disc inputmode="decimal" autocomplete="off" placeholder="${esc(t('so.discount'))}" aria-label="${esc(t('so.discount'))}" value="${esc(l.discountPct ?? '0')}">
    <select data-tax aria-label="${esc(t('inv.taxCode'))}"><option value="">${esc(t('inv.exempt'))}</option>${rates.map((r) => `<option value="${esc(r.code)}">${esc(r.label)} ${esc(D(r.rate_pct).toString())} %</option>`).join('')}</select></div></div>`;
  const first = init.lines?.length ? init.lines : [{}];
  const prior = init.orderId ? await db.get('SELECT 1 x FROM invoices WHERE order_id=? AND status=\'issued\'', [init.orderId]) : null;
  openSheet({ title: t('inv.new'), html: `<form novalidate>
    <div class="fld"><label for="ic">${esc(t('c.customer'))} *</label><select id="ic">${customers.map((c) => `<option value="${esc(c.id)}"${c.id === init.customerId ? ' selected' : ''}>${esc(c.name)} (${esc(c.ref)})</option>`).join('')}</select></div>
    <div class="fld"><label for="id1">${esc(t('inv.issueDate'))}</label><input id="id1" value="${today()}" autocomplete="off"></div>
    <div class="fld"><label for="id2">${esc(t('inv.dueDate'))} — ${esc(t('common.optional'))}</label><input id="id2" placeholder="AAAA-MM-JJ" autocomplete="off"></div>
    ${rates.length ? '' : `<div class="warn">${esc(t('inv.noTaxRates'))}</div>`}${prior ? `<div class="warn">${esc(t('inv.alreadyInvoiced'))}</div>` : ''}
    <div class="row-lines" id="lines">${first.map(lineHtml).join('')}</div><button type="button" class="btn secondary sm" data-add>+ ${esc(t('so.addLine'))}</button>
    <div class="glass totals" id="tot"></div><div class="form-error" hidden role="alert"></div>
    <div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => {
    const lines = $('#lines', root), tot = $('#tot', root), err = $('.form-error', root); let busy = false;
    const collect = () => $$('.row-line', lines).map((l) => ({ productId: $('[data-prod]', l).value || undefined, description: $('[data-desc]', l).value.trim(), qty: $('[data-qty]', l).value, unitPrice: $('[data-price]', l).value, discountPct: $('[data-disc]', l).value || '0', taxCode: $('[data-tax]', l).value || undefined }));
    const preview = () => { // same pure calculation as the issued invoice
      try { const c = computeInvoice(collect().filter((l) => l.qty.trim() && l.unitPrice.trim()).map((l) => ({ ...l, taxRatePct: l.taxCode ? rateOf.get(l.taxCode) : '0' })));
        tot.innerHTML = `<div class="kv"><span>${esc(t('inv.subtotal'))}</span><span>${esc(moneyDA(c.subtotalHt))}</span><span>${esc(t('inv.tax'))}</span><span>${esc(moneyDA(c.taxTotal))}</span><span><b>${esc(t('inv.total'))}</b></span><span><b>${esc(moneyDA(c.totalTtc))}</b></span></div>`; } catch { tot.innerHTML = ''; } };
    preview();
    $('[data-add]', root).addEventListener('click', () => { lines.insertAdjacentHTML('beforeend', lineHtml()); });
    root.addEventListener('click', (e) => { if (e.target.closest('[data-rm]') && $$('.row-line', lines).length > 1) { e.target.closest('.row-line').remove(); preview(); } });
    root.addEventListener('change', (e) => { if (e.target.matches('[data-prod]')) { const o = e.target.selectedOptions[0], l = e.target.closest('.row-line'); if (o.value) { if (!$('[data-desc]', l).value) $('[data-desc]', l).value = o.dataset.pn; if (!$('[data-price]', l).value) $('[data-price]', l).value = o.dataset.sp; } } preview(); });
    root.addEventListener('input', preview);
    $('form', root).addEventListener('submit', async (e) => {
      e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true; err.hidden = true;
      try {
        const r = await issueInvoice(db, ctx.user, { customerId: $('#ic', root).value, orderId: init.orderId ?? null, issueDate: $('#id1', root).value.trim() || undefined, dueDate: $('#id2', root).value.trim() || undefined, lines: collect() });
        toast(r.warnings.length ? `${r.number} ✓ — ${t('inv.warnLimit')}` : `${r.number} ✓`, r.warnings.length ? 'err' : 'ok'); close(); await ctx.reload(); invoiceDetail(ctx, r.id);
      } catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; busy = false; }
    });
  } });
}

async function documentFor(ctx, id) {
  const { db } = ctx;
  const inv = await db.get('SELECT * FROM invoices WHERE id=?', [id]);
  const lines = await db.all('SELECT * FROM invoice_lines WHERE invoice_id=? ORDER BY line_no', [id]);
  const customer = await db.get('SELECT * FROM customers WHERE id=?', [inv.customer_id]);
  const paid = Dec.sum((await db.all("SELECT pa.amount FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id WHERE pa.invoice_id=? AND p.status='valid'", [id])).map((r) => D(r.amount)));
  const credited = Dec.sum((await db.all('SELECT total_ttc FROM credit_notes WHERE invoice_id=?', [id])).map((r) => D(r.total_ttc)));
  const outstanding = await invoiceOutstanding(db, id);
  return { inv, lines, customer, paid, credited, outstanding, company: await getCompany(db) };
}

export async function invoiceDetail(ctx, id) {
  const { db, can } = ctx; const d = await documentFor(ctx, id), { inv } = d;
  const byRate = new Map(); for (const l of d.lines) { const k = D(l.tax_rate_pct).toString(); const b = byRate.get(k) ?? { base: D(0), tax: D(0) }; b.base = b.base.add(l.line_ht); b.tax = b.tax.add(l.line_tax); byRate.set(k, b); }
  const open = inv.status === 'issued' && d.outstanding.gt(0);
  openSheet({ title: inv.number, html: `<div class="glass kv"><span>${esc(t('c.customer'))}</span><span>${esc(d.customer.name)}</span><span>${esc(t('inv.issueDate'))}</span><span>${esc(inv.issue_date)}</span><span>${esc(t('inv.dueDate'))}</span><span>${esc(inv.due_date)}</span><span>${esc(t('common.status'))}</span><span>${chip(inv.status === 'issued' ? t('inv.issued') : t('inv.cancelled'), inv.status === 'issued' ? 'blue' : 'red')}</span></div>
    <div class="glass section"><div class="scroll-x"><table class="tbl"><tr><th>${esc(t('inv.description'))}</th><th class="n">${esc(t('inv.qty'))}</th><th class="n">${esc(t('inv.lineHt'))}</th></tr>${d.lines.map((l) => `<tr><td>${esc(l.description)}<br><small>${esc(money(D(l.unit_price)))} · ${esc(t('inv.rate'))} ${esc(D(l.tax_rate_pct).toString())} %</small></td><td class="n">${esc(fq(D(l.qty)))}</td><td class="n">${esc(money(D(l.line_ht)))}</td></tr>`).join('')}</table></div></div>
    <div class="glass kv"><span>${esc(t('inv.subtotal'))}</span><span>${esc(moneyDA(D(inv.subtotal_ht)))}</span>${[...byRate].map(([r, b]) => `<span>${esc(t('inv.tax'))} ${esc(r)} %</span><span>${esc(moneyDA(b.tax))}</span>`).join('')}<span><b>${esc(t('inv.total'))}</b></span><span><b>${esc(moneyDA(D(inv.total_ttc)))}</b></span><span>${esc(t('inv.paid'))}</span><span>${esc(moneyDA(d.paid))}</span>${d.credited.gt(0) ? `<span>${esc(t('inv.creditNote'))}</span><span>${esc(moneyDA(d.credited))}</span>` : ''}<span>${esc(t('inv.outstanding'))}</span><span class="${open ? 'bad' : 'ok-t'}">${esc(moneyDA(d.outstanding))}</span></div>
    ${d.company.name && (!d.company.nif && !d.company.address) ? `<div class="warn">${esc(t('inv.noCompany'))}</div>` : ''}
    <div class="actions" style="flex-wrap:wrap"><button class="btn primary" data-doc>${esc(t('inv.document'))}</button>${open && can('payments', 'post') ? `<button class="btn secondary" data-pay>${esc(t('inv.recordPayment'))}</button>` : ''}${open && can('invoices', 'post') ? `<button class="btn secondary" data-cn>${esc(t('inv.creditNote'))}</button>` : ''}${inv.status === 'issued' && can('invoices', 'post') ? `<button class="btn danger" data-cancel>${esc(t('inv.cancel'))}</button>` : ''}</div>`,
  mount: (root, close) => {
    $('[data-doc]', root).addEventListener('click', () => openDocument(invoiceDocumentHtml({ ...d, invoice: d.inv, lang: getLanguage() }), inv.number));
    $('[data-pay]', root)?.addEventListener('click', () => { close(); paymentSheet(ctx, inv.customer_id); });
    const reasonSheet = (title, extraField, action) => { close(); openSheet({ title, html: `<form novalidate>${extraField ?? ''}<div class="fld"><label for="rs">${esc(t('common.reason'))} *</label><input id="rs" autocomplete="off"></div><div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
      mount: (r2, close2) => { let busy = false; $('form', r2).addEventListener('submit', async (e) => { e.preventDefault(); if (busy) return; busy = true; try { await action($('#rs', r2).value, r2); close2(); toast(t('common.saved')); await ctx.reload(); invoiceDetail(ctx, id); } catch (x) { const er = $('.form-error', r2); er.textContent = errorText(x); er.hidden = false; busy = false; } }); } }); };
    $('[data-cancel]', root)?.addEventListener('click', () => reasonSheet(t('inv.cancel'), null, (reason) => cancelInvoice(db, ctx.user, id, reason)));
    $('[data-cn]', root)?.addEventListener('click', () => reasonSheet(t('inv.creditNote'), `<div class="fld"><label for="cna">${esc(t('inv.amount'))} *</label><input id="cna" inputmode="decimal" autocomplete="off"></div>`, (reason, r2) => issueCreditNote(db, ctx.user, { invoiceId: id, amount: $('#cna', r2).value, reason })));
  } });
}

export async function invoicesScreen(ctx) {
  const { db, can } = ctx;
  const rows = await db.all('SELECT i.*, c.name cname FROM invoices i JOIN customers c ON c.id=i.customer_id ORDER BY i.issue_date DESC, i.number DESC LIMIT 200');
  const items = []; for (const i of rows) items.push({ i, out: await invoiceOutstanding(db, i.id) });
  const tone = ({ i, out }) => i.status === 'cancelled' ? ['red', t('inv.cancelled')] : out.isZero() ? ['green', t('inv.paid')] : i.due_date < today() ? ['red', t('cu.overdue')] : ['blue', t('inv.outstanding')];
  const html = `<div class="page-head"><h1>${esc(t('nav.invoices'))}</h1>${can('invoices', 'post') ? `<button class="btn primary sm" data-new>+ ${esc(t('inv.new'))}</button>` : ''}</div>
    <input class="search" type="search" placeholder="${esc(t('common.search'))}" data-q aria-label="${esc(t('common.search'))}">
    <div class="list">${items.map((x) => { const [tn, lb] = tone(x); return `<button class="glass card" data-id="${esc(x.i.id)}" data-text="${esc((x.i.number + ' ' + x.i.cname).toLowerCase())}"><div><div class="t1">${esc(x.i.number)}</div><div class="t2">${esc(x.i.cname)} · ${esc(x.i.issue_date)}</div></div><div class="num">${esc(money(D(x.i.total_ttc)))}<small>${chip(lb, tn)}</small></div></button>`; }).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-q]', root).addEventListener('input', (e) => { const q = e.target.value.toLowerCase(); $$('.card', root).forEach((c) => { c.hidden = !c.dataset.text.includes(q); }); });
    $('[data-new]', root)?.addEventListener('click', () => invoiceSheet(ctx));
    $$('.card', root).forEach((c) => c.addEventListener('click', () => invoiceDetail(ctx, c.dataset.id)));
  } };
}
