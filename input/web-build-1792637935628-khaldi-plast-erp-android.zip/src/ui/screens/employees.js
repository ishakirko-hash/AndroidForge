import { t } from '../../core/i18n/index.js';
import { createEmployee, listEmployees, recordAttendance, attendanceSummary } from '../../core/hr.js';
import { today } from '../../core/dates.js';
import { esc, $, $$, formSheet, openSheet, toast } from '../ui.js';

export async function employeesScreen(ctx) {
  const { can } = ctx; const emps = await listEmployees(ctx.db, ctx.user);
  const html = `<div class="page-head"><h1>${esc(t('nav.employees'))}</h1>${can('employees', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('em.new'))}</button>` : ''}</div>
    <div class="list">${emps.filter((e) => e.status === 'active').map((e) => `<button class="glass card" data-id="${esc(e.id)}"><div><div class="t1">${esc(e.name)}</div><div class="t2">${esc(e.ref)}${e.job_title ? ' · ' + esc(e.job_title) : ''}${e.department ? ' · ' + esc(e.department) : ''}</div></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-new]', root)?.addEventListener('click', () => formSheet({ title: t('em.new'), fields: [{ name: 'ref', label: t('common.ref'), required: true }, { name: 'name', label: t('common.name'), required: true }, { name: 'job_title', label: t('em.job') }, { name: 'department', label: t('em.dept') }, ...(can('employees', 'post') ? [{ name: 'hourly_cost', label: t('em.hourly'), type: 'number' }] : [])],
      onSubmit: async (v) => { const o = { ...v }; for (const k of Object.keys(o)) if (o[k] === '') delete o[k]; await createEmployee(ctx.db, ctx.user, o); toast(t('common.saved')); ctx.reload(); } }));
    $$('.card', root).forEach((c) => c.addEventListener('click', async () => { const e = emps.find((x) => x.id === c.dataset.id); const m = today().slice(0, 7); const s = await attendanceSummary(ctx.db, e.id, { from: `${m}-01`, to: `${m}-31` });
      openSheet({ title: e.name, html: `<div class="glass kv"><span>${esc(t('common.ref'))}</span><span>${esc(e.ref)}</span><span>${esc(t('em.summary'))}</span><span>${s.present} ${esc(t('em.present'))} · ${s.absent} ${esc(t('em.absent'))}</span><span>${esc(t('em.hours'))}</span><span>${esc(s.hours.toString())} (+${esc(s.overtime.toString())})</span></div>
        ${can('employees', 'write') ? `<form novalidate><h3>${esc(t('em.attendance'))}</h3><div class="fld"><label for="ad">${esc(t('common.date'))}</label><input id="ad" value="${today()}"></div><div class="fld"><label for="as">${esc(t('common.status'))}</label><select id="as">${['present', 'absent', 'leave', 'holiday'].map((k) => `<option value="${k}">${esc(t('em.' + k))}</option>`).join('')}</select></div>
        <div class="fld"><label for="ah">${esc(t('em.hours'))}</label><input id="ah" inputmode="decimal" value="8" autocomplete="off"></div><div class="fld"><label for="ao">${esc(t('em.overtime'))}</label><input id="ao" inputmode="decimal" value="0" autocomplete="off"></div><div class="form-error" hidden role="alert"></div><div class="actions"><button class="btn primary" type="submit">${esc(t('common.save'))}</button></div></form>` : ''}`,
      mount: (r, close) => $('form', r)?.addEventListener('submit', async (ev) => { ev.preventDefault(); try { await recordAttendance(ctx.db, ctx.user, { employeeId: e.id, workDate: $('#ad', r).value.trim(), status: $('#as', r).value, hours: $('#ah', r).value, overtimeHours: $('#ao', r).value }); toast(t('common.saved')); close(); ctx.reload(); } catch (x) { const er = $('.form-error', r); er.textContent = String(x.message); er.hidden = false; } }) }); }));
  } };
}
