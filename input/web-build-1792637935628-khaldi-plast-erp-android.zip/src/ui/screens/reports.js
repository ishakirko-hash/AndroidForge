import { t } from '../../core/i18n/index.js';
import { exportCsv, REPORT_NAMES } from '../../core/reports.js';
import { esc, $, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { exportText } from '../share.js';
import { today } from '../../core/dates.js';

export async function reportsScreen(ctx) {
  const to = today(), from = `${to.slice(0, 4)}-01-01`;
  const html = `<div class="page-head"><h1>${esc(t('nav.reports'))}</h1></div><form class="glass section" novalidate><div class="fld"><label for="rn">${esc(t('rp.pick'))}</label><select id="rn">${REPORT_NAMES.map((n) => `<option value="${n}">${esc(t('rp.' + n))}</option>`).join('')}</select></div>
    <div class="fld"><label for="rf">${esc(t('ac.from'))}</label><input id="rf" value="${from}" autocomplete="off"></div><div class="fld"><label for="rt">${esc(t('ac.to'))}</label><input id="rt" value="${to}" autocomplete="off"></div>
    <div class="form-error" hidden role="alert"></div><div class="actions"><button class="btn primary" type="submit">${esc(t('rp.export'))}</button></div></form>`;
  return { html, mount(root) { $('form', root).addEventListener('submit', async (e) => { e.preventDefault(); const err = $('.form-error', root); err.hidden = true;
    try { const n = $('#rn', root).value; const csv = await exportCsv(ctx.db, ctx.user, n, { from: $('#rf', root).value.trim(), to: $('#rt', root).value.trim() }); await exportText(`${n}-${today()}.csv`, csv, 'text/csv'); toast(t('rp.done')); }
    catch (x) { err.textContent = errorText(x); err.hidden = false; } }); } };
}
