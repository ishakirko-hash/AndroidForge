import { t } from '../../core/i18n/index.js';
import { D, Dec } from '../../core/decimal.js';
import { getBalance, getHistory, postMovement, stockValuation, lowStock } from '../../core/inventory.js';
import { availableStock } from '../../core/sales.js';
import { esc, $, $$, formSheet, openSheet, idemKey, chip, toast } from '../ui.js';
import { qty, moneyDA, dstr } from '../fmt.js';

function historySheet(ctx, type, item) {
  return ctx.db.all('SELECT * FROM stock_movements WHERE item_type=? AND item_id=? ORDER BY id DESC LIMIT 60', [type, item.id]).then((rows) => {
    openSheet({ title: `${t('i.history')} — ${item.ref}`, html: `${ctx.can('inventory', 'post') ? `<div class="actions"><button class="btn secondary sm" data-adj>${esc(t('i.adjust'))}</button></div>` : ''}
      <div class="scroll-x"><table class="tbl"><tr><th>${esc(t('common.date'))}</th><th></th><th class="n">${esc(t('common.qty'))}</th></tr>${rows.map((r) => { const q = new Dec(BigInt(r.qty_u)); return `<tr><td>${esc(dstr(r.ts))}</td><td>${esc(t('mv.' + r.movement_type))}${r.source_doc ? ` <small>${esc(r.source_doc)}</small>` : ''}</td><td class="n ${q.isNegative() ? 'bad' : 'ok-t'}">${q.isNegative() ? '' : '+'}${esc(qty(q))}</td></tr>`; }).join('') || `<tr><td colspan="3">${esc(t('common.empty'))}</td></tr>`}</table></div>`,
    mount: (r, close) => $('[data-adj]', r)?.addEventListener('click', () => { close(); adjustSheet(ctx, type, item); }) });
  });
}
function adjustSheet(ctx, type, item) {
  const key = idemKey('adjust');
  formSheet({ title: `${t('i.adjust')} — ${item.ref}`, fields: [
    { name: 'dir', label: t('common.status'), type: 'select', options: [{ value: 'adjustment_in', label: t('i.adjustIn') }, { value: 'adjustment_out', label: t('i.adjustOut') }] },
    { name: 'qty', label: t('common.qty'), type: 'number', required: true }, { name: 'reason', label: t('common.reason'), required: true }],
  onSubmit: async (v) => { await postMovement(ctx.db, ctx.user, { type: v.dir, itemType: type, itemId: item.id, qty: v.qty, reason: v.reason, eventKey: key }); toast(t('common.saved')); ctx.reload(); } });
}

export async function inventoryScreen(ctx) {
  const { db } = ctx;
  const val = await stockValuation(db), low = await lowStock(db);
  const lowIds = new Set(low.map((l) => l.id));
  const prods = [], mats = [];
  for (const p of await db.all("SELECT id, ref, name_fr name, min_stock FROM products WHERE status='active' ORDER BY ref")) prods.push({ ...p, st: await availableStock(db, p.id) });
  for (const m of await db.all("SELECT id, ref, name, unit, min_stock FROM materials WHERE status='active' ORDER BY ref")) mats.push({ ...m, bal: await getBalance(db, 'material', m.id) });
  const card = (type, i, bal, sub) => `<button class="glass card" data-type="${type}" data-id="${esc(i.id)}"><div><div class="t1">${esc(i.name)}</div><div class="t2">${esc(i.ref)} ${lowIds.has(i.id) ? chip(t('i.low'), 'red') : ''} ${sub ?? ''}</div></div><div class="num">${esc(qty(bal))}<small>${esc(type === 'product' ? t('i.physical') : i.unit)}</small></div></button>`;
  const html = `<div class="page-head"><h1>${esc(t('i.title'))}</h1></div>
    <div class="glass section"><h2>${esc(t('i.valuation'))}</h2><div class="kv" style="padding:0;margin:0"><span>${esc(t('i.materialsValue'))}</span><span>${esc(moneyDA(val.materialsValue))}</span><span>${esc(t('i.productsValue'))}</span><span>${esc(moneyDA(val.productsValue))}</span></div>${val.complete ? '' : `<div class="warn">${esc(t('i.incomplete'))}</div>`}</div>
    <div class="section-title">${esc(t('i.products'))}</div><div class="list">${prods.map((p) => card('product', p, p.st.physical, `<small>${esc(t('i.reserved'))} ${esc(qty(p.st.reserved))} · ${esc(t('i.available'))} ${esc(qty(p.st.available))}</small>`)).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>
    <div class="section-title">${esc(t('i.materials'))}</div><div class="list">${mats.map((m) => card('material', m, m.bal)).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) { $$('.card', root).forEach((c) => c.addEventListener('click', () => { const list = c.dataset.type === 'product' ? prods : mats; historySheet(ctx, c.dataset.type, list.find((x) => x.id === c.dataset.id)); })); } };
}
