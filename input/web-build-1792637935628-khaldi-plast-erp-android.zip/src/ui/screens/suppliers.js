import { t } from '../../core/i18n/index.js';
import { D, Dec } from '../../core/decimal.js';
import { createSupplier } from '../../core/parties.js';
import { paySupplier, supplierBalance, supplierInvoiceOutstanding } from '../../core/purchasing.js';
import { today } from '../../core/dates.js';
import { esc, $, $$, formSheet, openSheet, idemKey, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { moneyDA, money } from '../fmt.js';

const METHODS = ['cash', 'bank_transfer', 'cheque', 'other'];
/** Pay a supplier: allocation to open supplier invoices is pre-filled oldest-due first and editable; it must add up to the amount. */
export async function paySupplierSheet(ctx, supplierId) {
  const { db } = ctx; const key = idemKey('spay');
  const fins = await db.all('SELECT id, name FROM financial_accounts WHERE active=1 ORDER BY name');
  if (!fins.length) return toast(t('ex.needAccount'), 'err');
  const open = []; for (const i of await db.all("SELECT * FROM supplier_invoices WHERE supplier_id=? AND status='issued' ORDER BY due_date, number", [supplierId])) { const o = await supplierInvoiceOutstanding(db, i.id); if (o.gt(0)) open.push({ ...i, out: o }); }
  if (!open.length) return toast(t('su.noOpen'), 'err');
  openSheet({ title: t('su.pay'), html: `<form novalidate><div class="fld"><label for="sa">${esc(t('pay.amount'))} *</label><input id="sa" inputmode="decimal" autocomplete="off"></div>
    <div class="fld"><label for="sm">${esc(t('pay.method'))}</label><select id="sm">${METHODS.map((m) => `<option value="${m}">${esc(t('pay.' + m))}</option>`).join('')}</select></div>
    <div class="fld"><label for="sf">${esc(t('ex.account'))}</label><select id="sf">${fins.map((f) => `<option value="${esc(f.id)}">${esc(f.name)}</option>`).join('')}</select></div><div class="fld"><label for="sr">${esc(t('pay.reference'))}</label><input id="sr" autocomplete="off"></div>
    <div class="glass section"><h2>${esc(t('pay.allocation'))}</h2><table class="tbl">${open.map((i) => `<tr><td>${esc(i.supplier_ref)}<br><small>${esc(t('inv.dueDate'))} ${esc(i.due_date)} · ${esc(moneyDA(i.out))}</small></td><td class="n"><input data-alloc="${esc(i.id)}" inputmode="decimal" autocomplete="off" style="width:110px;min-height:42px;border-radius:12px;border:1px solid #c3d6f2;padding:0 8px;text-align:end"></td></tr>`).join('')}</table></div>
    <div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => { const amt = $('#sa', root), err = $('.form-error', root); let busy = false;
    amt.addEventListener('input', () => { let left; try { left = D(amt.value); } catch { return; } $$('[data-alloc]', root).forEach((inp, i) => { const a = open[i].out.lt(left) ? open[i].out : left; inp.value = a.gt(0) ? a.toString() : ''; left = left.sub(a).gt(0) ? left.sub(a) : Dec.zero(); }); });
    $('form', root).addEventListener('submit', async (e) => { e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true; err.hidden = true;
      try { const allocations = $$('[data-alloc]', root).filter((i) => i.value.trim() && !D(i.value).isZero()).map((i) => ({ invoiceId: i.dataset.alloc, amount: i.value }));
        const r = await paySupplier(db, ctx.user, { supplierId, finAccountId: $('#sf', root).value, amount: amt.value, method: $('#sm', root).value, reference: $('#sr', root).value.trim() || null, payDate: today(), eventKey: key, allocations }); toast(`${r.number} ✓`); close(); ctx.reload();
      } catch (x) { err.textContent = /add up/.test(x.message) ? t('su.allocSum') : errorText(x); err.hidden = false; btn.disabled = false; busy = false; } }); } });
}

export async function suppliersScreen(ctx) {
  const { db, can } = ctx;
  const items = []; for (const s of await db.all('SELECT * FROM suppliers WHERE active=1 ORDER BY name')) items.push({ s, b: await supplierBalance(db, s.id) });
  const html = `<div class="page-head"><h1>${esc(t('nav.suppliers'))}</h1>${can('suppliers', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('su.new'))}</button>` : ''}</div>
    <div class="list">${items.map(({ s, b }) => `<button class="glass card" data-id="${esc(s.id)}"><div><div class="t1">${esc(s.name)}</div><div class="t2">${esc(s.ref)}${s.phone ? ' · ' + esc(s.phone) : ''}</div></div><div class="num">${esc(money(b))}<small>DA</small></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-new]', root)?.addEventListener('click', () => formSheet({ title: t('su.new'), fields: [{ name: 'ref', label: t('common.ref'), required: true }, { name: 'name', label: t('common.name'), required: true }, { name: 'phone', label: t('c.phone') }, { name: 'address', label: t('c.address') }, { name: 'wilaya', label: t('c.wilaya') }, { name: 'nif', label: t('c.nif') }, { name: 'nis', label: t('c.nis') }, { name: 'rc', label: t('c.rc') }, { name: 'payment_terms_days', label: t('cu.terms'), type: 'number', value: '30' }],
      onSubmit: async (v) => { const o = { ...v, payment_terms_days: Number(v.payment_terms_days || 30) }; for (const k of Object.keys(o)) if (o[k] === '') delete o[k]; await createSupplier(db, ctx.user, o); toast(t('common.saved')); ctx.reload(); } }));
    $$('.card', root).forEach((c) => c.addEventListener('click', () => { const { s, b } = items.find((x) => x.s.id === c.dataset.id);
      openSheet({ title: s.name, html: `<div class="glass kv"><span>${esc(t('common.ref'))}</span><span>${esc(s.ref)}</span><span>${esc(t('su.payables'))}</span><span>${esc(moneyDA(b))}</span></div><div class="actions">${can('suppliers', 'post') && b.gt(0) ? `<button class="btn primary" data-pay>${esc(t('su.pay'))}</button>` : ''}</div>`,
        mount: (r, close) => $('[data-pay]', r)?.addEventListener('click', () => { close(); paySupplierSheet(ctx, s.id); }) }); }));
  } };
}
