import { t } from '../../core/i18n/index.js';
import { esc } from '../ui.js';

export async function auditScreen(ctx) {
  const rows = await ctx.db.all('SELECT * FROM audit_log ORDER BY id DESC LIMIT 150');
  const html = `<div class="page-head"><h1>${esc(t('nav.audit'))}</h1></div><div class="glass section"><div class="scroll-x"><table class="tbl"><tr><th>${esc(t('au.when'))}</th><th>${esc(t('au.action'))}</th><th>${esc(t('au.entity'))}</th><th>${esc(t('au.user'))}</th></tr>${rows.map((r) => `<tr><td>${esc(r.ts.slice(0, 16).replace('T', ' '))}</td><td>${esc(r.action)}</td><td>${esc(r.entity)}${r.entity_id ? `<br><small>${esc(String(r.entity_id).slice(0, 18))}</small>` : ''}</td><td>${esc(r.user_id ?? '—')}</td></tr>`).join('') || `<tr><td colspan="4">${esc(t('common.empty'))}</td></tr>`}</table></div></div>`;
  return { html, mount() {} };
}
