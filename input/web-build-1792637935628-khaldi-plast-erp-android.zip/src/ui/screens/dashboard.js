import { t } from '../../core/i18n/index.js';
import { D, Dec } from '../../core/decimal.js';
import { computeAlerts } from '../../core/alerts.js';
import { availableStock } from '../../core/sales.js';
import { today } from '../../core/dates.js';
import { esc, chip } from '../ui.js';
import { qty, moneyDA, ltr } from '../fmt.js';
import { MODULE_LIST, BOTTOM_NAV, icon } from '../modules.js';

const SEV = { critical: 'red', warning: 'amber', info: 'slate' };
const alertText = (a) => t('al.' + a.code, { subject: a.subject, ...Object.fromEntries(Object.entries(a.data ?? {}).map(([k, v]) => [k, Array.isArray(v) ? v.join(', ') : v])) });

export async function dashboardScreen(ctx) {
  const { db } = ctx, d = today(), month = d.slice(0, 7);
  const inv = await db.all("SELECT subtotal_ht h FROM invoices WHERE status='issued' AND substr(issue_date,1,7)=?", [month]);
  const exp = await db.all("SELECT amount a FROM expenses WHERE status='valid' AND substr(exp_date,1,7)=?", [month]);
  const prod = await db.all("SELECT accepted_qty a FROM production_orders WHERE status='completed' AND substr(finished_at,1,10)=?", [d]);
  let stock = Dec.zero(), n = 0; for (const p of await db.all("SELECT id FROM products WHERE status='active'")) { stock = stock.add((await availableStock(db, p.id)).physical); n++; }
  const alerts = await computeAlerts(db, { asOf: d });
  const val = (rows, f, fmt) => (rows.length ? fmt(rows.reduce((a, r) => a.add(r[f]), Dec.zero())) : '—');
  const k = [['sales', 'green', 'kpi.salesMonth', val(inv, 'h', (x) => moneyDA(x)), inv.length], ['production', 'blue', 'kpi.producedToday', val(prod, 'a', (x) => ltr(qty(x)) + ' ' + t('kpi.pieces')), prod.length],
    ['inventory', 'amber', 'kpi.stockProducts', n ? ltr(qty(stock)) + ' ' + t('kpi.pieces') : '—', n], ['expenses', 'red', 'kpi.expensesMonth', val(exp, 'a', (x) => moneyDA(x)), exp.length]];
  const html = `<section class="glass hello"><div><h1>${esc(t('common.welcome'))}</h1><p>${esc(t('common.dashboard'))} · ${esc(new Intl.DateTimeFormat(ctx.lang === 'ar' ? 'ar-DZ-u-nu-latn' : 'fr-DZ', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date()))}</p></div>${ctx.dbChip}</section>
    <div class="grid2">${k.map(([mod, tone, key, value, count]) => `<button class="glass kpi card" style="display:flex;flex-direction:column;align-items:flex-start" data-go="${mod}"><span class="tile tone-${tone}">${icon(mod)}</span><span class="label">${esc(t(key))}</span><span class="value">${esc(value)}</span>${count ? '' : `<span class="hint">${esc(t('kpi.pending'))}</span>`}</button>`).join('')}</div>
    <div class="glass section" style="margin-top:10px"><h2>${esc(t('common.alerts'))} ${alerts.length ? chip(String(alerts.length), alerts.some((a) => a.severity === 'critical') ? 'red' : 'amber') : ''}</h2>${alerts.slice(0, 6).map((a) => `<div class="alert-row">${chip(a.severity === 'critical' ? '!' : a.severity === 'warning' ? '▲' : 'i', SEV[a.severity])}<span>${esc(alertText(a))}</span></div>`).join('') || `<p>${esc(t('common.noAlerts'))}</p>`}</div>
    <div class="section-title">${esc(t('common.more'))}</div><div class="shortcuts">${MODULE_LIST.filter((m) => !['dashboard', ...BOTTOM_NAV].includes(m.id)).slice(0, 8).map((m) => `<button class="shortcut" data-go="${m.id}"><span class="tile tone-${m.tone}">${icon(m.id)}</span>${esc(t('nav.' + m.id))}</button>`).join('')}</div>`;
  return { html, mount() {} };
}
