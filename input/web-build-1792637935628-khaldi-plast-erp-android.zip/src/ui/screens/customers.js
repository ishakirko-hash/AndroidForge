import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { createCustomer } from '../../core/parties.js';
import { customerBalance, debtAging } from '../../core/receivables.js';
import { customerStatement } from '../../core/reports.js';
import { esc, $, $$, formSheet, openSheet, toast, chip } from '../ui.js';
import { errorText } from '../errors.js';
import { moneyDA, money } from '../fmt.js';
import { paymentSheet } from './payments.js';

async function statementSheet(ctx, c) {
  const st = await customerStatement(ctx.db, ctx.user, c.id);
  const kind = { invoice: t('inv.docTitle'), credit_note: t('inv.creditNote'), payment: t('cu.paid') };
  openSheet({ title: `${t('cu.statement')} — ${c.name}`, html: `<div class="scroll-x"><table class="tbl"><tr><th>${esc(t('common.date'))}</th><th></th><th class="n">${esc(t('cu.balance'))}</th></tr>${st.lines.map((l) => `<tr><td>${esc(l.date)}</td><td>${esc(kind[l.kind])} ${esc(l.doc)}<br><small class="${l.delta.isNegative() ? 'ok-t' : ''}">${l.delta.isNegative() ? '−' : '+'}${esc(money(l.delta.abs()))}</small></td><td class="n">${esc(money(l.balance))}</td></tr>`).join('') || `<tr><td colspan="3">${esc(t('common.empty'))}</td></tr>`}</table></div>
    <div class="glass kv" style="margin-top:8px"><span>${esc(t('cu.balance'))}</span><span>${esc(moneyDA(st.closingBalance))}</span></div>${st.consistent ? '' : '<div class="warn">≠</div>'}` });
}

export async function customersScreen(ctx) {
  const { db, can } = ctx;
  const items = []; for (const c of await db.all('SELECT * FROM customers WHERE active=1 ORDER BY name')) items.push({ c, b: await customerBalance(db, c.id) });
  const html = `<div class="page-head"><h1>${esc(t('nav.customers'))}</h1>${can('customers', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('cu.new'))}</button>` : ''}</div>
    <input class="search" type="search" placeholder="${esc(t('common.search'))}" data-q aria-label="${esc(t('common.search'))}">
    <div class="list">${items.map(({ c, b }) => `<button class="glass card" data-id="${esc(c.id)}" data-text="${esc((c.ref + ' ' + c.name + ' ' + (c.phone ?? '') + ' ' + (c.nif ?? '')).toLowerCase())}"><div><div class="t1">${esc(c.name)}</div><div class="t2">${esc(c.ref)}${c.phone ? ' · ' + esc(c.phone) : ''}</div></div><div class="num">${esc(money(b.balance))}<small>DA</small></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-q]', root).addEventListener('input', (e) => { const q = e.target.value.toLowerCase(); $$('.card', root).forEach((c) => { c.hidden = !c.dataset.text.includes(q); }); });
    $('[data-new]', root)?.addEventListener('click', () => formSheet({ title: t('cu.new'), fields: [
      { name: 'ref', label: t('common.ref'), required: true }, { name: 'name', label: t('common.name'), required: true }, { name: 'phone', label: t('c.phone') }, { name: 'email', label: t('c.email') },
      { name: 'address', label: t('c.address') }, { name: 'wilaya', label: t('c.wilaya') }, { name: 'commune', label: t('c.commune') }, { name: 'nif', label: t('c.nif') }, { name: 'nis', label: t('c.nis') }, { name: 'rc', label: t('c.rc') },
      { name: 'credit_limit', label: t('cu.creditLimit'), type: 'number', value: '0' }, { name: 'payment_terms_days', label: t('cu.terms'), type: 'number', value: '30' }],
    onSubmit: async (v) => { const o = { ...v, credit_limit: v.credit_limit || '0', payment_terms_days: Number(v.payment_terms_days || 30) }; for (const k of Object.keys(o)) if (o[k] === '') delete o[k]; await createCustomer(db, ctx.user, o); toast(t('common.saved')); ctx.reload(); } }));
    $$('.card', root).forEach((card) => card.addEventListener('click', async () => {
      const { c, b } = items.find((x) => x.c.id === card.dataset.id); const ag = await debtAging(db, { customerId: c.id });
      openSheet({ title: c.name, html: `<div class="glass kv"><span>${esc(t('common.ref'))}</span><span>${esc(c.ref)}</span>${c.nif ? `<span>${esc(t('c.nif'))}</span><span>${esc(c.nif)}</span>` : ''}<span>${esc(t('cu.invoiced'))}</span><span>${esc(moneyDA(b.invoiced))}</span><span>${esc(t('cu.credits'))}</span><span>${esc(moneyDA(b.credits))}</span><span>${esc(t('cu.paid'))}</span><span>${esc(moneyDA(b.paid))}</span><span>${esc(t('cu.balance'))}</span><span>${esc(moneyDA(b.balance))}</span><span>${esc(t('cu.overdue'))}</span><span class="${ag.overdue.gt(0) ? 'bad' : ''}">${esc(moneyDA(ag.overdue))}</span>${b.unallocated.gt(0) ? `<span>${esc(t('cu.unallocated'))}</span><span>${esc(moneyDA(b.unallocated))}</span>` : ''}<span>${esc(t('cu.creditLimit').split(' (')[0])}</span><span>${D(c.credit_limit).isZero() ? '∞' : esc(moneyDA(D(c.credit_limit)))}</span></div>
        <div class="actions"><button class="btn secondary" data-st>${esc(t('cu.statement'))}</button>${can('payments', 'post') ? `<button class="btn primary" data-pay>${esc(t('inv.recordPayment'))}</button>` : ''}</div>`,
      mount: (r, close) => { $('[data-st]', r).addEventListener('click', async () => { try { close(); await statementSheet(ctx, c); } catch (e) { toast(errorText(e), 'err'); } }); $('[data-pay]', r)?.addEventListener('click', () => { close(); paymentSheet(ctx, c.id); }); } });
    }));
  } };
}
