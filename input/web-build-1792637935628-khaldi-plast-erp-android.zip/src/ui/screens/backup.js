import { t } from '../../core/i18n/index.js';
import { createBackup, validateBackup, restoreBackup, backupHistory } from '../../core/backup.js';
import { esc, $, toast, chip } from '../ui.js';
import { errorText } from '../errors.js';
import { exportText } from '../share.js';
import { today } from '../../core/dates.js';

export async function backupScreen(ctx) {
  const { db, can } = ctx; const hist = await backupHistory(db);
  const html = `<div class="page-head"><h1>${esc(t('nav.backup'))}</h1></div><div class="warn">${esc(t('bk.info'))}</div>
    <div class="glass section">${can('backup', 'write') ? `<div class="actions"><button class="btn primary" data-create>${esc(t('bk.create'))}</button></div>` : ''}</div>
    ${can('backup', 'admin') ? `<div class="glass section"><h2>${esc(t('bk.restore'))}</h2><div class="fld"><input type="file" id="bf" accept=".json,application/json" aria-label="${esc(t('bk.pick'))}"></div><div id="bsum"></div>
      <label class="cb"><input type="checkbox" id="bc"> ${esc(t('bk.confirm'))}</label><div class="form-error" hidden role="alert"></div><div class="actions"><button class="btn danger" data-restore disabled>${esc(t('bk.run'))}</button></div></div>` : ''}
    <div class="glass section"><h2>${esc(t('bk.history'))}</h2><table class="tbl">${hist.map((h) => `<tr><td>${esc(h.ts.slice(0, 16).replace('T', ' '))}</td><td>${esc(h.kind)}</td><td>${chip(h.status, h.status === 'ok' ? 'green' : 'red')}</td></tr>`).join('') || `<tr><td>${esc(t('common.empty'))}</td></tr>`}</table></div>`;
  return { html, mount(root) {
    $('[data-create]', root)?.addEventListener('click', async (e) => { e.target.disabled = true; try { const b = await createBackup(db, ctx.user); await exportText(`khaldi-erp-backup-${today()}.json`, b.text, 'application/json'); toast(t('bk.ok')); ctx.reload(); } catch (x) { toast(errorText(x), 'err'); e.target.disabled = false; } });
    const file = $('#bf', root), btn = $('[data-restore]', root), chk = $('#bc', root), sum = $('#bsum', root), err = $('.form-error', root); let text = null;
    const sync = () => { btn.disabled = !(text && chk.checked); };
    file?.addEventListener('change', async () => { err.hidden = true; text = null; sum.innerHTML = ''; sync(); const f = file.files[0]; if (!f) return;
      try { const raw = await f.text(); const m = await validateBackup(db, raw); text = raw; const rows = Object.values(m.counts).reduce((a, b) => a + b, 0);
        sum.innerHTML = `<div class="glass kv"><span>${esc(t('bk.summary', { date: m.createdAt.slice(0, 16).replace('T', ' '), rows }))}</span><span>v${m.schemaVersion}</span></div>`; } catch (x) { err.textContent = errorText(x); err.hidden = false; } sync(); });
    chk?.addEventListener('change', sync);
    btn?.addEventListener('click', async () => { btn.disabled = true; err.hidden = true;
      try { const r = await restoreBackup(db, ctx.user, text, { confirm: chk.checked }); toast(t('bk.restored')); await exportText(`khaldi-erp-safety-${today()}.json`, r.safetyBackup, 'application/json'); setTimeout(() => location.reload(), 600); }
      catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; } });
  } };
}
