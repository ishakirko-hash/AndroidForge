import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { createProduct, createRecipe, archiveItem, latestRecipe } from '../../core/catalog.js';
import { availableStock } from '../../core/sales.js';
import { esc, $, $$, formSheet, openSheet, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { qty } from '../fmt.js';

const MASS = ['kg', 'g', 't'];
const unitOptions = (mUnit, sel) => (MASS.includes(mUnit) ? MASS : [mUnit]).map((u) => `<option value="${u}"${u === (sel ?? mUnit) ? ' selected' : ''}>${u}</option>`).join('');

function recipeSheet(ctx, product, materials) {
  const lineHtml = () => `<div class="row-line glass"><select data-mat aria-label="${esc(t('m.title'))}">${materials.map((m) => `<option value="${esc(m.id)}" data-mu="${esc(m.unit)}">${esc(m.ref)} — ${esc(m.name)} (${esc(m.unit)})</option>`).join('')}</select>
    <div class="r2"><input data-qty inputmode="decimal" autocomplete="off" placeholder="${esc(t('p.qtyPerUnit'))}" aria-label="${esc(t('p.qtyPerUnit'))}"><select data-unit aria-label="${esc(t('common.unit'))}">${unitOptions(materials[0].unit)}</select>
    <input data-loss inputmode="decimal" autocomplete="off" placeholder="${esc(t('p.lossPct'))}" value="0" aria-label="${esc(t('p.lossPct'))}"><button type="button" class="round-btn sm" data-rm aria-label="✕">✕</button></div></div>`;
  openSheet({ title: `${t('p.newRecipe')} — ${product.ref}`, html: `<form novalidate><div class="row-lines" id="lines">${lineHtml()}</div><button type="button" class="btn secondary sm" data-add>+ ${esc(t('p.addLine'))}</button>
      <div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => {
    const lines = $('#lines', root); let busy = false;
    $('[data-add]', root).addEventListener('click', () => lines.insertAdjacentHTML('beforeend', lineHtml()));
    root.addEventListener('click', (e) => { if (e.target.closest('[data-rm]') && $$('.row-line', lines).length > 1) e.target.closest('.row-line').remove(); });
    root.addEventListener('change', (e) => { if (e.target.matches('[data-mat]')) { const line = e.target.closest('.row-line'); $('select[data-unit]', line).innerHTML = unitOptions(e.target.selectedOptions[0].dataset.mu); } });
    $('form', root).addEventListener('submit', async (e) => {
      e.preventDefault(); if (busy) return; busy = true; const err = $('.form-error', root); err.hidden = true; const btn = $('button[type=submit]', root); btn.disabled = true;
      try {
        const payload = $$('.row-line', lines).map((l) => ({ materialId: $('[data-mat]', l).value, qtyPerUnit: $('[data-qty]', l).value, unit: $('select[data-unit]', l).value, lossPct: $('[data-loss]', l).value || '0' }));
        if (payload.some((p) => !p.qtyPerUnit.trim())) throw new Error('quantity is required');
        await createRecipe(ctx.db, ctx.user, { productId: product.id, lines: payload }); toast(t('common.saved')); close(); ctx.reload();
      } catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; busy = false; }
    });
  } });
}

export async function productsScreen(ctx) {
  const { db, can } = ctx;
  const rows = await db.all("SELECT * FROM products WHERE status='active' ORDER BY ref");
  const items = []; for (const p of rows) items.push({ p, st: await availableStock(db, p.id) });
  const html = `<div class="page-head"><h1>${esc(t('p.title'))}</h1>${can('products', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('p.new'))}</button>` : ''}</div>
    <input class="search" type="search" placeholder="${esc(t('common.search'))}" data-q aria-label="${esc(t('common.search'))}">
    <div class="list">${items.map(({ p, st }) => `<button class="glass card" data-id="${esc(p.id)}" data-text="${esc((p.ref + ' ' + p.name_fr + ' ' + (p.name_ar ?? '')).toLowerCase())}"><div><div class="t1">${esc(ctx.lang === 'ar' && p.name_ar ? p.name_ar : p.name_fr)}</div><div class="t2">${esc(p.ref)} · ${esc(D(p.sale_price).format(ctx.lang, 2))} DA</div></div><div class="num">${esc(qty(st.available))}<small>${esc(t('i.available'))}</small></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-q]', root).addEventListener('input', (e) => { const q = e.target.value.toLowerCase(); $$('.card', root).forEach((c) => { c.hidden = !c.dataset.text.includes(q); }); });
    $('[data-new]', root)?.addEventListener('click', () => formSheet({ title: t('p.new'), fields: [
      { name: 'ref', label: t('common.ref'), required: true }, { name: 'name_fr', label: t('p.nameFr'), required: true }, { name: 'name_ar', label: t('p.nameAr') },
      { name: 'unit_weight_g', label: t('p.weight'), type: 'number' }, { name: 'sale_price', label: t('common.price'), type: 'number', value: '0' }, { name: 'min_stock', label: t('p.minStock'), type: 'number', value: '0' }],
    onSubmit: async (v) => { await createProduct(db, ctx.user, { ...v, name_ar: v.name_ar || undefined, unit_weight_g: v.unit_weight_g?.trim() ? v.unit_weight_g : undefined, sale_price: v.sale_price || '0', min_stock: v.min_stock || '0' }); toast(t('common.saved')); ctx.reload(); } }));
    $$('.card', root).forEach((c) => c.addEventListener('click', async () => {
      const { p, st } = items.find((x) => x.p.id === c.dataset.id);
      const rc = await latestRecipe(db, p.id);
      const lines = rc ? await db.all('SELECT rl.*, m.ref, m.name FROM recipe_lines rl JOIN materials m ON m.id=rl.material_id WHERE rl.recipe_id=? ORDER BY m.ref', [rc.id]) : [];
      const materials = await db.all("SELECT id, ref, name, unit FROM materials WHERE status='active' ORDER BY ref");
      openSheet({ title: p.name_fr, html: `<div class="glass kv"><span>${esc(t('common.ref'))}</span><span>${esc(p.ref)}</span><span>${esc(t('i.physical'))}</span><span>${esc(qty(st.physical))}</span><span>${esc(t('i.reserved'))}</span><span>${esc(qty(st.reserved))}</span><span>${esc(t('i.available'))}</span><span>${esc(qty(st.available))}</span>${p.unit_weight_g ? `<span>${esc(t('p.weight'))}</span><span>${esc(p.unit_weight_g)}</span>` : ''}</div>
        <div class="glass section"><h2>${esc(t('p.recipe'))}${rc ? ` · ${esc(t('p.version'))} ${rc.version}` : ''}</h2>${lines.length ? `<table class="tbl"><tr><th>${esc(t('m.title'))}</th><th class="n">${esc(t('p.qtyPerUnit'))}</th><th class="n">${esc(t('p.lossPct'))}</th></tr>${lines.map((l) => `<tr><td>${esc(l.ref)} ${esc(l.name)}</td><td class="n">${esc(l.qty_per_unit)} ${esc(l.unit)}</td><td class="n">${esc(l.loss_pct)}</td></tr>`).join('')}</table>` : `<p>${esc(t('p.noRecipe'))}</p>`}</div>
        <div class="actions">${can('products', 'write') ? `<button class="btn primary" data-rc>${esc(t('p.newRecipe'))}</button><button class="btn secondary" data-arch>${esc(t('common.archive'))}</button>` : ''}</div>`,
      mount: (r, close) => {
        $('[data-rc]', r)?.addEventListener('click', () => { if (!materials.length) return toast(t('p.needMaterials'), 'err'); close(); recipeSheet(ctx, p, materials); });
        $('[data-arch]', r)?.addEventListener('click', async () => { try { await archiveItem(db, ctx.user, 'product', p.id); close(); ctx.reload(); } catch (e) { toast(errorText(e), 'err'); } });
      } });
    }));
  } };
}
