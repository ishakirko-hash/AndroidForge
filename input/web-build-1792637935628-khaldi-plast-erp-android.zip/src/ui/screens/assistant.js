import { t } from '../../core/i18n/index.js';
import { ask } from '../../core/assistant.js';
import { esc, $, $$ } from '../ui.js';
import { errorText } from '../errors.js';
import { today } from '../../core/dates.js';

export async function assistantScreen(ctx) {
  const ex = [1, 2, 3, 4, 5, 6].map((i) => t('as.ex' + i));
  const html = `<div class="page-head"><h1>${esc(t('nav.assistant'))}</h1></div><small>${esc(t('as.readonly'))}</small>
    <form id="askf" class="glass section" style="margin-top:8px" novalidate><div class="fld"><input id="q" placeholder="${esc(t('as.placeholder'))}" autocomplete="off" aria-label="${esc(t('as.placeholder'))}"></div><div class="actions"><button class="btn primary" type="submit">${esc(t('as.ask'))}</button></div></form>
    <div class="section-title">${esc(t('as.examples'))}</div><div class="list">${ex.map((e) => `<button class="glass card" data-ex="${esc(e)}"><span class="t1">${esc(e)}</span></button>`).join('')}</div><div id="ans"></div>`;
  return { html, mount(root) {
    const ans = $('#ans', root), q = $('#q', root);
    const run = async (text) => { try { const r = await ask(ctx.db, ctx.user, text, { asOf: today(), lang: ctx.lang });
      ans.innerHTML = `<div class="glass section" style="margin-top:10px"><div style="white-space:pre-wrap">${esc(r.text)}</div>${r.basis ? `<hr style="border:0;border-top:1px solid rgba(10,108,220,.15)"><small><b>${esc(t('as.basis'))}:</b> ${esc(r.basis)}</small>` : ''}</div>`; } catch (e) { ans.innerHTML = `<div class="form-error">${esc(errorText(e))}</div>`; } };
    $('#askf', root).addEventListener('submit', (e) => { e.preventDefault(); if (q.value.trim()) run(q.value); });
    $$('[data-ex]', root).forEach((b) => b.addEventListener('click', () => { q.value = b.dataset.ex; run(b.dataset.ex); }));
  } };
}
