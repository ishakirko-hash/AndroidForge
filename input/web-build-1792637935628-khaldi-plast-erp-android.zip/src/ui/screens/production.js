import { t } from '../../core/i18n/index.js';
import { D, Dec } from '../../core/decimal.js';
import { computeRequirements } from '../../core/bom.js';
import { latestRecipe } from '../../core/catalog.js';
import { createOrder, planOrder, startOrder, completeOrder, cancelOrder, orderSummary } from '../../core/production.js';
import { esc, $, $$, formSheet, openSheet, chip, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { qty, money, moneyDA, pct, dstr } from '../fmt.js';

const TONE = { draft: 'slate', planned: 'blue', in_progress: 'amber', completed: 'green', cancelled: 'red' };
const reqTable = (req) => `<div class="scroll-x"><table class="tbl"><tr><th>${esc(t('m.title'))}</th><th class="n">${esc(t('pr.required'))}</th><th class="n">${esc(t('pr.availableQty'))}</th><th class="n">${esc(t('pr.shortage'))}</th></tr>${req.lines.map((l) => `<tr><td>${esc(l.ref)}</td><td class="n">${esc(qty(l.required))} ${esc(l.unit)}</td><td class="n">${esc(qty(l.available))}</td><td class="n ${l.shortage.gt(0) ? 'bad' : ''}">${l.shortage.gt(0) ? esc(qty(l.shortage)) : '—'}</td></tr>`).join('')}</table></div>
  <div class="kv" style="padding:8px 0 0;margin:0"><span>${esc(t('pr.estCost'))}</span><span>${req.estimatedMaterialCost ? esc(moneyDA(req.estimatedMaterialCost)) : '—'}</span></div>${req.estimatedMaterialCost ? '' : `<div class="warn">${esc(t('pr.costMissing'))}</div>`}`;

async function openOrder(ctx, id) {
  const { db, can } = ctx;
  const s = await orderSummary(db, id), o = s.order;
  const prod = await db.get('SELECT ref, name_fr FROM products WHERE id=?', [o.product_id]);
  const rc = await db.get('SELECT version FROM recipes WHERE id=?', [o.recipe_id]);
  const open = ['draft', 'planned', 'in_progress'].includes(o.status);
  const req = open ? await computeRequirements(db, o.recipe_id, o.planned_qty) : null;
  const mats = await db.all('SELECT pm.*, m.ref, m.name, m.unit FROM production_materials pm JOIN materials m ON m.id=pm.material_id WHERE pm.order_id=? ORDER BY m.ref', [id]);
  const done = o.status === 'completed';
  const actions = [];
  if (can('production', 'write') && o.status === 'draft') actions.push('plan');
  if (can('production', 'post') && o.status === 'planned') actions.push('start');
  if (can('production', 'post') && o.status === 'in_progress') actions.push('complete');
  if (can('production', 'post') && open) actions.push('cancel');
  const label = { plan: t('pr.plan'), start: t('pr.start'), complete: t('pr.complete'), cancel: t('pr.cancel') };
  openSheet({ title: `${o.number} — ${prod.ref}`, html: `<div class="glass kv"><span>${esc(t('pr.product'))}</span><span>${esc(prod.name_fr)}</span><span>${esc(t('common.status'))}</span><span>${chip(t('st.' + o.status), TONE[o.status])}</span><span>${esc(t('pr.planned'))}</span><span>${esc(qty(D(o.planned_qty)))}</span><span>${esc(t('pr.recipeVersion', { v: rc.version }))}</span><span></span>${o.planned_date ? `<span>${esc(t('pr.plannedDate'))}</span><span>${esc(o.planned_date)}</span>` : ''}</div>
    ${req ? `<div class="glass section"><h2>${esc(t('pr.requirements'))}</h2>${reqTable(req)}${req.hasShortage ? `<div class="warn">${esc(t('pr.shortage'))}</div>` : ''}</div>` : ''}
    ${done ? `<div class="glass kv"><span>${esc(t('pr.total'))}</span><span>${esc(qty(D(o.total_qty)))}</span><span>${esc(t('pr.accepted'))}</span><span>${esc(qty(D(o.accepted_qty)))}</span><span>${esc(t('pr.rejected'))}</span><span>${esc(qty(D(o.rejected_qty)))}</span><span>${esc(t('pr.rejectionRate'))}</span><span>${s.rejectionRatePct ? esc(pct(s.rejectionRatePct)) : '—'}</span><span>${esc(t('pr.completion'))}</span><span>${s.completionRatePct ? esc(pct(s.completionRatePct)) : '—'}</span><span>${esc(t('pr.unitCost'))}</span><span>${s.unitMaterialCost ? esc(moneyDA(s.unitMaterialCost)) : '—'}</span></div>${s.costComplete === false ? `<div class="warn">${esc(t('pr.costIncomplete'))}</div>` : ''}
      <div class="glass section"><h2>${esc(t('pr.consumption'))}</h2><table class="tbl">${mats.filter((m) => m.actual_qty != null).map((m) => `<tr><td>${esc(m.ref)} ${esc(m.name)}</td><td class="n">${esc(qty(D(m.actual_qty)))} ${esc(m.unit)}</td><td>${esc(t('pr.' + m.actual_source))}</td></tr>`).join('')}</table></div>` : ''}
    <div class="actions">${actions.map((a) => `<button class="btn ${a === 'cancel' ? 'danger' : 'primary'}" data-act="${a}">${esc(label[a])}</button>`).join('')}</div>`,
  mount: (root, close) => {
    const run = async (fn) => { try { await fn(); toast(t('common.saved')); close(); ctx.reload(); } catch (e) { toast(errorText(e), 'err'); } };
    $('[data-act=plan]', root)?.addEventListener('click', (e) => { e.target.disabled = true; run(() => planOrder(db, ctx.user, id)); });
    $('[data-act=start]', root)?.addEventListener('click', (e) => { e.target.disabled = true; run(() => startOrder(db, ctx.user, id)); });
    $('[data-act=cancel]', root)?.addEventListener('click', (e) => { e.target.disabled = true; run(() => cancelOrder(db, ctx.user, id)); });
    $('[data-act=complete]', root)?.addEventListener('click', () => { close(); completeSheet(ctx, o, mats); });
  } });
}

function completeSheet(ctx, o, mats) {
  const fields = [{ name: 'total', label: t('pr.total'), type: 'number', required: true }, { name: 'accepted', label: t('pr.accepted'), type: 'number', required: true }, { name: 'rejected', label: t('pr.rejected'), type: 'number', required: true }];
  const extra = `<div class="glass section"><h2>${esc(t('pr.consumption'))}</h2>${mats.map((m) => `<div class="fld"><label for="c_${esc(m.material_id)}">${esc(m.ref)} ${esc(m.name)} (${esc(m.unit)})</label><input id="c_${esc(m.material_id)}" data-cons="${esc(m.material_id)}" inputmode="decimal" autocomplete="off" placeholder="${esc(qty(D(m.expected_qty)))}"></div>`).join('')}
    <label class="cb"><input type="checkbox" data-calc> ${esc(t('pr.useCalculated'))}</label></div>`;
  formSheet({ title: `${t('pr.complete')} — ${o.number}`, fields, extra, submitLabel: t('pr.complete'),
    mount: (root) => $('[data-calc]', root).addEventListener('change', (e) => $$('[data-cons]', root).forEach((i) => { i.disabled = e.target.checked; })),
    onSubmit: async (v, form) => {
      const useExpected = $('[data-calc]', form).checked;
      const consumption = useExpected ? undefined : $$('[data-cons]', form).map((i) => ({ materialId: i.dataset.cons, qty: i.value }));
      if (!useExpected && consumption.some((c) => !c.qty.trim())) throw new Error('consumption is required');
      await completeOrder(ctx.db, ctx.user, o.id, { totalQty: v.total, acceptedQty: v.accepted, rejectedQty: v.rejected, consumption, useExpected });
      toast(t('common.saved')); ctx.reload();
    } });
}

function newOrderSheet(ctx, products) {
  openSheet({ title: t('pr.new'), html: `<form novalidate><div class="fld"><label for="po_p">${esc(t('pr.product'))} *</label><select id="po_p">${products.map((p) => `<option value="${esc(p.id)}">${esc(p.ref)} — ${esc(p.name_fr)}</option>`).join('')}</select></div>
    <div class="fld"><label for="po_q">${esc(t('pr.planned'))} *</label><input id="po_q" inputmode="decimal" autocomplete="off"></div>
    <div class="fld"><label for="po_d">${esc(t('pr.plannedDate'))} — ${esc(t('common.optional'))} (AAAA-MM-JJ)</label><input id="po_d" placeholder="2026-12-31" autocomplete="off"></div>
    <div class="glass section" id="po_prev" hidden></div><div class="form-error" hidden role="alert"></div>
    <div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => {
    const sel = $('#po_p', root), q = $('#po_q', root), prev = $('#po_prev', root), err = $('.form-error', root); let busy = false, timer;
    const preview = async () => { // live material requirements as the planner types
      err.hidden = true; prev.hidden = true;
      try { if (!q.value.trim()) return; const rc = await latestRecipe(ctx.db, sel.value);
        if (!rc) { err.textContent = t('pr.noRecipeFor'); err.hidden = false; return; }
        prev.innerHTML = `<h2>${esc(t('pr.requirements'))}</h2>${reqTable(await computeRequirements(ctx.db, rc.id, q.value))}`; prev.hidden = false;
      } catch (x) { err.textContent = errorText(x); err.hidden = false; }
    };
    for (const el of [sel, q]) el.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(preview, 250); });
    $('form', root).addEventListener('submit', async (e) => {
      e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true; err.hidden = true;
      try {
        const rc = await latestRecipe(ctx.db, sel.value); if (!rc) throw new Error(t('pr.noRecipeFor'));
        const r = await createOrder(ctx.db, ctx.user, { productId: sel.value, recipeId: rc.id, plannedQty: q.value, plannedDate: $('#po_d', root).value.trim() || undefined });
        toast(`${r.number} ✓`); close(); await ctx.reload(); openOrder(ctx, r.id);
      } catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; busy = false; }
    });
  } });
}

export async function productionScreen(ctx) {
  const { db, can } = ctx;
  const orders = await db.all('SELECT po.*, p.ref pref, p.name_fr pname FROM production_orders po JOIN products p ON p.id=po.product_id ORDER BY po.created_at DESC, po.number DESC');
  const withRecipe = await db.all("SELECT p.id, p.ref, p.name_fr FROM products p WHERE p.status='active' AND EXISTS (SELECT 1 FROM recipes r WHERE r.product_id=p.id) ORDER BY p.ref");
  const html = `<div class="page-head"><h1>${esc(t('pr.title'))}</h1>${can('production', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('pr.new'))}</button>` : ''}</div>
    <div class="list">${orders.map((o) => `<button class="glass card" data-id="${esc(o.id)}"><div><div class="t1">${esc(o.number)} · ${esc(o.pref)}</div><div class="t2">${esc(o.pname)} · ${esc(dstr(o.created_at))}</div></div><div class="num">${esc(qty(D(o.planned_qty)))}<small>${chip(t('st.' + o.status), TONE[o.status])}</small></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-new]', root)?.addEventListener('click', () => (withRecipe.length ? newOrderSheet(ctx, withRecipe) : toast(t('pr.noProducts'), 'err')));
    $$('.card', root).forEach((c) => c.addEventListener('click', () => openOrder(ctx, c.dataset.id)));
  } };
}
