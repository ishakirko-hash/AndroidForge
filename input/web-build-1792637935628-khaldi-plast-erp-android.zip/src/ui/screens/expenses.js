import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { recordExpense, cancelExpense } from '../../core/cash.js';
import { setBudget, budgetVsActual } from '../../core/budgets.js';
import { today } from '../../core/dates.js';
import { esc, $, $$, formSheet, openSheet, idemKey, chip, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { moneyDA, money } from '../fmt.js';

export async function expensesScreen(ctx) {
  const { db, can, lang } = ctx; const month = today().slice(0, 7);
  const cats = await db.all('SELECT * FROM expense_categories ORDER BY name_fr'), fins = await db.all('SELECT id, name FROM financial_accounts WHERE active=1 ORDER BY name');
  const catName = (c) => (lang === 'ar' && c.name_ar ? c.name_ar : c.name_fr);
  const rows = await db.all('SELECT e.*, c.name_fr, c.name_ar FROM expenses e JOIN expense_categories c ON c.code=e.category_code ORDER BY e.exp_date DESC, e.number DESC LIMIT 100');
  const bud = await budgetVsActual(db, month); const TONE = { ok: 'green', warning: 'amber', over: 'red' };
  const html = `<div class="page-head"><h1>${esc(t('nav.expenses'))}</h1>${can('expenses', 'post') ? `<button class="btn primary sm" data-new>+ ${esc(t('ex.new'))}</button>` : ''}</div>
    <div class="glass section"><h2>${esc(t('ex.budget'))} · ${month}</h2><table class="tbl">${bud.map((b) => `<tr><td>${esc(b.category)}</td><td class="n">${esc(money(b.actual))} / ${esc(money(b.budget))}</td><td>${chip(t('ex.' + b.status), TONE[b.status])}</td></tr>`).join('') || `<tr><td>${esc(t('common.empty'))}</td></tr>`}</table>${can('expenses', 'post') && cats.length ? `<div class="actions"><button class="btn secondary" data-bud>${esc(t('ex.setBudget'))}</button></div>` : ''}</div>
    <div class="list">${rows.map((e) => `<button class="glass card" data-id="${esc(e.id)}"><div><div class="t1">${esc(e.number)} · ${esc(catName(e))}</div><div class="t2">${esc(e.exp_date)}${e.description ? ' · ' + esc(e.description) : ''}</div></div><div class="num">${esc(money(D(e.amount)))}<small>${e.status === 'valid' ? 'DA' : esc(t('ex.cancelled'))}</small></div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-new]', root)?.addEventListener('click', () => {
      if (!cats.length) return toast(t('ex.needCategory'), 'err'); if (!fins.length) return toast(t('ex.needAccount'), 'err'); const key = idemKey('exp');
      formSheet({ title: t('ex.new'), fields: [{ name: 'date', label: t('common.date'), value: today() }, { name: 'cat', label: t('ex.category'), type: 'select', options: cats.map((c) => ({ value: c.code, label: catName(c) })) }, { name: 'amount', label: t('pay.amount'), type: 'number', required: true },
        { name: 'fin', label: t('ex.account'), type: 'select', options: fins.map((f) => ({ value: f.id, label: f.name })) }, { name: 'description', label: t('inv.description') }, { name: 'reference', label: t('pay.reference') }],
      onSubmit: async (v) => { await recordExpense(db, ctx.user, { date: v.date.trim() || undefined, categoryCode: v.cat, amount: v.amount, finAccountId: v.fin, description: v.description || null, reference: v.reference || null, eventKey: key }); toast(t('common.saved')); ctx.reload(); } });
    });
    $('[data-bud]', root)?.addEventListener('click', () => formSheet({ title: t('ex.setBudget'), fields: [{ name: 'period', label: t('ex.month'), value: month }, { name: 'cat', label: t('ex.category'), type: 'select', options: cats.map((c) => ({ value: c.code, label: catName(c) })) }, { name: 'amount', label: t('pay.amount'), type: 'number', required: true }],
      onSubmit: async (v) => { await setBudget(db, ctx.user, { period: v.period.trim(), categoryCode: v.cat, amount: v.amount }); toast(t('common.saved')); ctx.reload(); } }));
    $$('.card', root).forEach((c) => c.addEventListener('click', () => { const e = rows.find((x) => x.id === c.dataset.id); if (e.status !== 'valid' || !can('expenses', 'post')) return;
      openSheet({ title: e.number, html: `<div class="glass kv"><span>${esc(t('common.date'))}</span><span>${esc(e.exp_date)}</span><span>${esc(t('pay.amount'))}</span><span>${esc(moneyDA(D(e.amount)))}</span>${e.description ? `<span>${esc(t('inv.description'))}</span><span>${esc(e.description)}</span>` : ''}</div><form novalidate><div class="fld"><label for="rs">${esc(t('common.reason'))} *</label><input id="rs" autocomplete="off"></div><div class="form-error" hidden role="alert"></div><div class="actions"><button type="submit" class="btn danger">${esc(t('ex.cancel'))}</button></div></form>`,
        mount: (r, close) => $('form', r).addEventListener('submit', async (ev) => { ev.preventDefault(); try { await cancelExpense(db, ctx.user, e.id, $('#rs', r).value); close(); toast(t('common.saved')); ctx.reload(); } catch (x) { const er = $('.form-error', r); er.textContent = errorText(x); er.hidden = false; } }) }); }));
  } };
}
