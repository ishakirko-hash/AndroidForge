import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { createMachine, setMachineStatus, createMaintenancePlan, recordMaintenance, dueMaintenance } from '../../core/machines.js';
import { today } from '../../core/dates.js';
import { esc, $, $$, formSheet, openSheet, chip, toast } from '../ui.js';
import { errorText } from '../errors.js';

const TONE = { operational: 'green', maintenance: 'amber', down: 'red' };
export async function machinesScreen(ctx) {
  const { db, can } = ctx;
  const ms = await db.all('SELECT * FROM machines ORDER BY ref'); const due = await dueMaintenance(db, { asOf: today(), withinDays: 7 });
  const html = `<div class="page-head"><h1>${esc(t('nav.machines'))}</h1>${can('machines', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('ma.new'))}</button>` : ''}</div>
    ${due.length ? `<div class="glass section"><h2>${esc(t('ma.due'))}</h2>${due.map((d) => `<div class="alert-row">${chip(d.overdue ? '!' : '▲', d.overdue ? 'red' : 'amber')}<span>${esc(d.machineRef)} — ${esc(d.task)} (${esc(d.dueDate)}) ${d.overdue ? esc(t('ma.overdue')) : ''}</span></div>`).join('')}</div>` : ''}
    <div class="list">${ms.map((m) => `<button class="glass card" data-id="${esc(m.id)}"><div><div class="t1">${esc(m.name)}</div><div class="t2">${esc(m.ref)}${m.line ? ' · ' + esc(m.line) : ''}</div></div><div class="num">${chip(t('ma.st_' + m.status), TONE[m.status])}</div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-new]', root)?.addEventListener('click', () => formSheet({ title: t('ma.new'), fields: [{ name: 'ref', label: t('common.ref'), required: true }, { name: 'name', label: t('common.name'), required: true }, { name: 'line', label: t('ma.line') }, { name: 'rated_capacity_per_hour', label: t('ma.capacity'), type: 'number' }],
      onSubmit: async (v) => { const o = { ...v }; for (const k of Object.keys(o)) if (o[k] === '') delete o[k]; await createMachine(db, ctx.user, o); toast(t('common.saved')); ctx.reload(); } }));
    $$('.card', root).forEach((c) => c.addEventListener('click', async () => { const m = ms.find((x) => x.id === c.dataset.id); const plans = await db.all('SELECT * FROM maintenance_plans WHERE machine_id=? AND active=1', [m.id]);
      openSheet({ title: m.name, html: `<div class="glass kv"><span>${esc(t('common.ref'))}</span><span>${esc(m.ref)}</span><span>${esc(t('common.status'))}</span><span>${chip(t('ma.st_' + m.status), TONE[m.status])}</span>${m.rated_capacity_per_hour ? `<span>${esc(t('ma.capacity'))}</span><span>${esc(D(m.rated_capacity_per_hour).toString())}</span>` : ''}</div>
        <div class="glass section"><h2>${esc(t('ma.plan'))}</h2>${plans.map((p) => `<div class="alert-row"><span>${esc(p.task)} · ${p.interval_days} ${esc(t('inv.days'))}</span></div>`).join('') || `<p>${esc(t('common.empty'))}</p>`}</div>
        <div class="actions" style="flex-wrap:wrap">${can('machines', 'write') ? `<button class="btn secondary" data-plan>${esc(t('ma.newPlan'))}</button>` : ''}${can('machines', 'post') ? `<button class="btn secondary" data-rec>${esc(t('ma.record'))}</button><button class="btn secondary" data-st>${esc(t('ma.setStatus'))}</button>` : ''}</div>`,
      mount: (r, close) => {
        $('[data-plan]', r)?.addEventListener('click', () => { close(); formSheet({ title: t('ma.newPlan'), fields: [{ name: 'task', label: t('ma.task'), required: true }, { name: 'interval', label: t('ma.interval'), type: 'number', required: true }, { name: 'start', label: t('ma.start'), value: today() }], onSubmit: async (v) => { await createMaintenancePlan(db, ctx.user, { machineId: m.id, task: v.task, intervalDays: Number(v.interval), startDate: v.start.trim() }); toast(t('common.saved')); ctx.reload(); } }); });
        $('[data-rec]', r)?.addEventListener('click', () => { close(); formSheet({ title: t('ma.record'), fields: [{ name: 'plan', label: t('ma.plan'), type: 'select', options: [{ value: '', label: '—' }, ...plans.map((p) => ({ value: p.id, label: p.task }))] }, { name: 'kind', label: t('ma.kind'), type: 'select', options: [{ value: 'preventive', label: t('ma.preventive') }, { value: 'corrective', label: t('ma.corrective') }] }, { name: 'date', label: t('common.date'), value: today() }, { name: 'cost', label: t('ma.cost'), type: 'number', value: '0' }, { name: 'down', label: t('ma.downtime'), type: 'number', value: '0' }],
          onSubmit: async (v) => { await recordMaintenance(db, ctx.user, { machineId: m.id, planId: v.plan || null, kind: v.kind, doneOn: v.date.trim(), cost: v.cost || '0', downtimeMin: Number(v.down || 0) }); toast(t('common.saved')); ctx.reload(); } }); });
        $('[data-st]', r)?.addEventListener('click', () => { close(); formSheet({ title: t('ma.setStatus'), fields: [{ name: 'st', label: t('common.status'), type: 'select', options: ['operational', 'maintenance', 'down'].map((k) => ({ value: k, label: t('ma.st_' + k) })), value: m.status }, { name: 'why', label: t('common.reason') }], onSubmit: async (v) => { await setMachineStatus(db, ctx.user, m.id, v.st, v.why || null); toast(t('common.saved')); ctx.reload(); } }); });
      } }); }));
  } };
}
