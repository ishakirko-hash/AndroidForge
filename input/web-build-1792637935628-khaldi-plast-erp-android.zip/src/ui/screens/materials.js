import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { createMaterial, archiveItem } from '../../core/catalog.js';
import { getBalance, postMovement } from '../../core/inventory.js';
import { esc, $, $$, formSheet, openSheet, idemKey, chip, toast } from '../ui.js';
import { qty } from '../fmt.js';

const UNITS = ['kg', 'g', 't', 'pcs', 'l'];

export function receiveSheet(ctx, m) {
  const key = idemKey('receipt'); // one key per opened form: a double tap can never post twice
  formSheet({ title: `${t('m.receive')} — ${m.ref}`, fields: [
    { name: 'qty', label: `${t('common.qty')} (${m.unit})`, type: 'number', required: true },
    { name: 'unitCost', label: `${t('m.unitCost')} — ${t('common.optional')}`, type: 'number', help: t('m.unitCostHint') }],
  onSubmit: async (v) => {
    await postMovement(ctx.db, ctx.user, { type: 'receipt', itemType: 'material', itemId: m.id, qty: v.qty, unitCost: v.unitCost?.trim() ? v.unitCost : undefined, eventKey: key, sourceDoc: 'UI' });
    toast(t('common.saved')); ctx.reload();
  } });
}

export async function materialsScreen(ctx) {
  const { db, can } = ctx;
  const rows = await db.all("SELECT * FROM materials WHERE status='active' ORDER BY ref");
  const items = []; for (const m of rows) items.push({ m, bal: await getBalance(db, 'material', m.id) });
  const html = `<div class="page-head"><h1>${esc(t('m.title'))}</h1>${can('materials', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('m.new'))}</button>` : ''}</div>
    <input class="search" type="search" placeholder="${esc(t('common.search'))}" data-q aria-label="${esc(t('common.search'))}">
    <div class="list">${items.map(({ m, bal }) => { const low = !D(m.min_stock).isZero() && bal.lt(m.min_stock) || (!D(m.min_stock).isZero() && bal.eq(m.min_stock));
      return `<button class="glass card" data-id="${esc(m.id)}" data-text="${esc((m.ref + ' ' + m.name).toLowerCase())}"><div><div class="t1">${esc(m.name)}</div><div class="t2">${esc(m.ref)} ${low ? chip(t('i.low'), 'red') : ''}</div></div><div class="num">${esc(qty(bal))}<small>${esc(m.unit)}</small></div></button>`; }).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) {
    $('[data-q]', root).addEventListener('input', (e) => { const q = e.target.value.toLowerCase(); $$('.card', root).forEach((c) => { c.hidden = !c.dataset.text.includes(q); }); });
    $('[data-new]', root)?.addEventListener('click', () => formSheet({ title: t('m.new'), fields: [
      { name: 'ref', label: t('common.ref'), required: true }, { name: 'name', label: t('common.name'), required: true },
      { name: 'unit', label: t('common.unit'), type: 'select', options: UNITS.map((u) => ({ value: u, label: u })), value: 'kg' },
      { name: 'category', label: t('m.category') }, { name: 'min_stock', label: t('p.minStock'), type: 'number', value: '0' },
      { name: 'purchase_cost', label: `${t('m.cost')} — ${t('common.optional')}`, type: 'number' }],
    onSubmit: async (v) => { await createMaterial(db, ctx.user, { ...v, min_stock: v.min_stock || '0', purchase_cost: v.purchase_cost?.trim() ? v.purchase_cost : undefined, category: v.category || undefined }); toast(t('common.saved')); ctx.reload(); } }));
    $$('.card', root).forEach((c) => c.addEventListener('click', () => {
      const it = items.find((x) => x.m.id === c.dataset.id), m = it.m;
      openSheet({ title: m.name, html: `<div class="glass kv"><span>${esc(t('common.ref'))}</span><span>${esc(m.ref)}</span><span>${esc(t('common.unit'))}</span><span>${esc(m.unit)}</span><span>${esc(t('i.physical'))}</span><span>${esc(qty(it.bal))}</span><span>${esc(t('i.min'))}</span><span>${esc(qty(D(m.min_stock)))}</span>${m.purchase_cost ? `<span>${esc(t('m.cost'))}</span><span>${esc(D(m.purchase_cost).format(ctx.lang, 2))}</span>` : ''}</div>
        <div class="actions">${can('inventory', 'post') ? `<button class="btn primary" data-rcv>${esc(t('m.receive'))}</button>` : ''}${can('materials', 'write') ? `<button class="btn secondary" data-arch>${esc(t('common.archive'))}</button>` : ''}</div>`,
      mount: (r, close) => {
        $('[data-rcv]', r)?.addEventListener('click', () => { close(); receiveSheet(ctx, m); });
        $('[data-arch]', r)?.addEventListener('click', async () => { try { await archiveItem(db, ctx.user, 'material', m.id); close(); ctx.reload(); } catch (e) { toast(String(e.message), 'err'); } });
      } });
    }));
  } };
}
