import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { getCompany, updateCompany } from '../../core/settings.js';
import { setTaxRate } from '../../core/parties.js';
import { esc, $, $$, formSheet, toast, chip } from '../ui.js';
import { accountingSetupSection } from './accounting.js';

const CO = [['name', 'common.name', true], ['address', 'c.address'], ['wilaya', 'c.wilaya'], ['commune', 'c.commune'], ['phone', 'c.phone'], ['email', 'c.email'], ['nif', 'c.nif'], ['nis', 'c.nis'], ['rc', 'c.rc'], ['ai', 'c.ai'], ['bank_details', 'c.bank']];

export async function settingsScreen(ctx) {
  const { db, can } = ctx; const co = await getCompany(db);
  const rates = await db.all('SELECT * FROM tax_rates ORDER BY rate_pct');
  const admin = can('settings', 'admin');
  const acct = await accountingSetupSection(ctx);
  const html = `<div class="page-head"><h1>${esc(t('nav.settings'))}</h1></div>
    <div class="glass section"><h2>${esc(t('se.company'))}</h2><small>${esc(t('se.identityHint'))}</small><div class="kv" style="padding:8px 0 0;margin:0">${CO.map(([k, lb]) => `<span>${esc(t(lb))}</span><span>${esc(co[k] || '—')}</span>`).join('')}</div>${admin ? `<div class="actions"><button class="btn primary" data-co>${esc(t('se.edit'))}</button></div>` : ''}</div>
    <div class="glass section"><h2>${esc(t('se.taxRates'))}</h2><div class="warn">${esc(t('se.warnTax'))}</div><table class="tbl">${rates.map((r) => `<tr><td>${esc(r.code)}</td><td>${esc(r.label)}</td><td class="n">${esc(D(r.rate_pct).toString())} %</td><td>${r.active ? chip('✓', 'green') : chip('—', 'slate')}</td></tr>`).join('') || `<tr><td>${esc(t('common.empty'))}</td></tr>`}</table>${admin ? `<div class="actions"><button class="btn secondary" data-rate>${esc(t('se.newRate'))}</button></div>` : ''}</div>${acct.html}`;
  return { html, mount(root) {
    $('[data-co]', root)?.addEventListener('click', () => formSheet({ title: t('se.company'), fields: CO.map(([k, lb, req]) => ({ name: k, label: t(lb), value: co[k] ?? '', required: !!req })),
      onSubmit: async (v) => { await updateCompany(db, ctx.user, v); toast(t('common.saved')); ctx.reload(); } }));
    $('[data-rate]', root)?.addEventListener('click', () => formSheet({ title: t('se.newRate'), fields: [{ name: 'code', label: t('se.code'), required: true }, { name: 'label', label: t('se.label'), required: true }, { name: 'rate', label: t('se.rate'), type: 'number', required: true },
      { name: 'active', label: t('se.active'), type: 'select', options: [{ value: '1', label: t('common.yes') }, { value: '0', label: t('common.no') }], value: '1' }],
    onSubmit: async (v) => { await setTaxRate(db, ctx.user, { code: v.code.trim(), label: v.label.trim(), ratePct: v.rate, active: v.active === '1' }); toast(t('common.saved')); ctx.reload(); } }));
    acct.mount(root);
  } };
}
