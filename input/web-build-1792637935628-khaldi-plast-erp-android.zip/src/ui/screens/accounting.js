import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { trialBalance, incomeStatement, balanceSheet, resolveRoles, ROLES } from '../../core/ledger.js';
import { createFinancialAccount, cashBalance, reconcileCash } from '../../core/cash.js';
import { setupStarterAccounting } from '../../core/setup.js';
import { postPending } from '../../core/postings.js';
import { esc, $, formSheet, toast, chip } from '../ui.js';
import { errorText } from '../errors.js';
import { moneyDA, money } from '../fmt.js';
import { today } from '../../core/dates.js';

/** Settings section: starter accounting + cash/bank accounts. */
export async function accountingSetupSection(ctx) {
  const { db, can } = ctx;
  const { missing } = await resolveRoles(db, ROLES);
  const fins = []; for (const f of await db.all('SELECT * FROM financial_accounts WHERE active=1 ORDER BY name')) fins.push({ f, b: await cashBalance(db, f.id) });
  const recon = await reconcileCash(db);
  const admin = can('accounting', 'admin');
  const html = `<div class="glass section"><h2>${esc(t('ac.setup'))}</h2><div class="warn">${esc(t('ac.starterHint'))}</div><p>${missing.length ? esc(t('ac.rolesMissing')) : esc(t('ac.rolesOk'))}</p>
    ${admin ? `<div class="actions" style="flex-wrap:wrap"><button class="btn secondary" data-seed>${esc(t('ac.seed'))}</button>${can('accounting', 'post') ? `<button class="btn secondary" data-pend>${esc(t('ac.postPending'))}</button>` : ''}</div>` : ''}
    <h2 style="margin-top:12px">${esc(t('ac.finAccounts'))}</h2><table class="tbl">${fins.map(({ f, b }) => `<tr><td>${esc(f.name)} <small>(${esc(t('ac.' + f.kind))})</small></td><td class="n">${esc(moneyDA(b))}</td></tr>`).join('') || `<tr><td>${esc(t('common.empty'))}</td></tr>`}</table>
    ${recon.some((r) => !r.ok) ? `<div class="warn">${esc(t('ac.reconcile'))} — ${recon.filter((r) => !r.ok).map((r) => `${esc(r.ledgerAccount)}: ${esc(t('ac.diff'))} ${esc(moneyDA(r.difference))}`).join(' ; ')}</div>` : ''}
    ${can('accounting', 'write') ? `<div class="actions"><button class="btn secondary" data-fin>${esc(t('ac.newFin'))}</button></div>` : ''}</div>`;
  return { html, mount(root) {
    $('[data-seed]', root)?.addEventListener('click', async (e) => { e.target.disabled = true; try { await setupStarterAccounting(db, ctx.user); toast(t('ac.seeded')); ctx.reload(); } catch (x) { toast(errorText(x), 'err'); e.target.disabled = false; } });
    $('[data-pend]', root)?.addEventListener('click', async () => { try { const r = await postPending(db, ctx.user); toast(t('ac.posted', { n: r.posted.length })); ctx.reload(); } catch (x) { toast(errorText(x), 'err'); } });
    $('[data-fin]', root)?.addEventListener('click', async () => {
      const assets = await db.all("SELECT code, name_fr FROM accounts WHERE type='asset' ORDER BY code"), equity = await db.all("SELECT code, name_fr FROM accounts WHERE type='equity' ORDER BY code");
      if (!assets.length) return toast(t('ex.needCategory'), 'err');
      formSheet({ title: t('ac.newFin'), fields: [{ name: 'name', label: t('common.name'), required: true }, { name: 'kind', label: t('ac.kind'), type: 'select', options: [{ value: 'cash', label: t('ac.cash') }, { value: 'bank', label: t('ac.bank') }] },
        { name: 'ledger', label: t('ac.ledger'), type: 'select', options: assets.map((a) => ({ value: a.code, label: `${a.code} ${a.name_fr}` })), value: '5000' },
        { name: 'opening', label: t('ac.opening'), type: 'number', value: '0' }, { name: 'equity', label: `${t('ac.equity')} (${t('ac.opening')})`, type: 'select', options: equity.map((a) => ({ value: a.code, label: `${a.code} ${a.name_fr}` })) }],
      onSubmit: async (v) => { await createFinancialAccount(db, ctx.user, { name: v.name, kind: v.kind, ledgerAccount: v.ledger, openingBalance: v.opening || '0', openingEquityAccount: v.equity || null }); toast(t('common.saved')); ctx.reload(); } });
    });
  } };
}

const tbl = (rows) => `<table class="tbl">${rows.map(([a, b, cls]) => `<tr><td>${a}</td><td class="n ${cls ?? ''}">${b}</td></tr>`).join('')}</table>`;
export async function accountingScreen(ctx) {
  const { db } = ctx; const to = today(), from = `${to.slice(0, 4)}-01-01`;
  const tb = await trialBalance(db, { from, to }), is = await incomeStatement(db, { from, to }), bs = await balanceSheet(db, { asOf: to });
  const html = `<div class="page-head"><h1>${esc(t('nav.accounting'))}</h1></div><div class="warn">${esc(t('ac.mgmtNote'))}</div><small>${esc(t('ac.from'))} ${from} ${esc(t('ac.to'))} ${to}</small>
    <div class="glass section"><h2>${esc(t('ac.trial'))} ${tb.balanced ? chip(t('ac.balancedOk'), 'green') : chip(t('ac.unbalanced'), 'red')}</h2><div class="scroll-x"><table class="tbl"><tr><th></th><th class="n">${esc(t('ac.debit'))}</th><th class="n">${esc(t('ac.credit'))}</th></tr>${tb.rows.map((r) => `<tr><td>${esc(r.code)} ${esc(r.name)}</td><td class="n">${r.debit.isZero() ? '' : esc(money(r.debit))}</td><td class="n">${r.credit.isZero() ? '' : esc(money(r.credit))}</td></tr>`).join('') || `<tr><td colspan="3">${esc(t('common.empty'))}</td></tr>`}<tr><td><b>Σ</b></td><td class="n"><b>${esc(money(tb.debit))}</b></td><td class="n"><b>${esc(money(tb.credit))}</b></td></tr></table></div></div>
    <div class="glass section"><h2>${esc(t('ac.income'))}</h2>${tbl([[esc(t('ac.revenue')), esc(moneyDA(is.totalRevenue))], [esc(t('ac.expensesT')), esc(moneyDA(is.totalExpenses))], [`<b>${esc(t('ac.net'))}</b>`, `<b>${esc(moneyDA(is.netResult))}</b>`, is.netResult.isNegative() ? 'bad' : 'ok-t']])}</div>
    <div class="glass section"><h2>${esc(t('ac.balanceSheet'))} ${bs.balanced ? chip(t('ac.balancedOk'), 'green') : chip(t('ac.unbalanced'), 'red')}</h2>${tbl([[esc(t('ac.assets')), esc(moneyDA(bs.totalAssets))], [esc(t('ac.liabilities')), esc(moneyDA(bs.totalLiabilities))], [esc(t('ac.equity')), esc(moneyDA(bs.totalEquity.sub(bs.currentResult)))], [esc(t('ac.currentResult')), esc(moneyDA(bs.currentResult))]])}</div>`;
  return { html, mount() {} };
}
