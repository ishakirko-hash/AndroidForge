import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { createSalesOrder, confirmSalesOrder, cancelSalesOrder, dispatchDelivery, orderProgress, availableStock } from '../../core/sales.js';
import { esc, $, $$, openSheet, chip, toast } from '../ui.js';
import { errorText } from '../errors.js';
import { qty as fq, money, dstr } from '../fmt.js';
import { invoiceSheet } from './invoices.js';

const TONE = { draft: 'slate', confirmed: 'blue', partially_delivered: 'amber', delivered: 'green', cancelled: 'red' };
const KEY = { draft: 'so.draft', confirmed: 'so.confirmed', partially_delivered: 'so.partially_delivered', delivered: 'so.delivered_st', cancelled: 'so.cancelled' };

async function dispatchSheet(ctx, o, prog) {
  const open = prog.filter((p) => p.remaining.gt(0));
  const names = Object.fromEntries((await ctx.db.all('SELECT id, ref FROM products')).map((p) => [p.id, p.ref]));
  openSheet({ title: `${t('so.dispatch')} — ${o.number}`, html: `<form novalidate><div class="glass section"><small>${esc(t('so.reservedNote'))}</small>${open.map((p) => `<div class="fld"><label for="d${p.lineNo}">${esc(names[p.productId])} — ${esc(t('so.remaining'))} ${esc(fq(p.remaining))}</label><input id="d${p.lineNo}" data-line="${p.lineNo}" inputmode="decimal" autocomplete="off" placeholder="0"></div>`).join('')}</div>
    <div class="form-error" hidden role="alert"></div><div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('so.dispatch'))}</button></div></form>`,
  mount: (root, close) => { let busy = false; $('form', root).addEventListener('submit', async (e) => {
    e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true; const err = $('.form-error', root); err.hidden = true;
    try { const lines = $$('[data-line]', root).filter((i) => i.value.trim() && !D(i.value).isZero()).map((i) => ({ lineNo: Number(i.dataset.line), qty: i.value })); if (!lines.length) throw new Error('quantity must be greater than zero');
      const r = await dispatchDelivery(ctx.db, ctx.user, o.id, { lines }); toast(`${r.number} ✓`); close(); await ctx.reload(); openOrder(ctx, o.id);
    } catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; busy = false; } }); } });
}

async function openOrder(ctx, id) {
  const { db, can } = ctx;
  const o = await db.get('SELECT so.*, c.name cname FROM sales_orders so JOIN customers c ON c.id=so.customer_id WHERE so.id=?', [id]);
  const prog = await orderProgress(db, id);
  const lines = await db.all('SELECT sol.*, p.ref, p.name_fr FROM sales_order_lines sol JOIN products p ON p.id=sol.product_id WHERE sol.order_id=? ORDER BY line_no', [id]);
  const dns = await db.all('SELECT number, delivery_date FROM delivery_notes WHERE order_id=? ORDER BY number', [id]);
  const A = [];
  if (can('sales', 'post') && o.status === 'draft') A.push('confirm');
  if (can('sales', 'post') && ['confirmed', 'partially_delivered'].includes(o.status)) A.push('dispatch');
  if (can('invoices', 'post') && ['partially_delivered', 'delivered'].includes(o.status)) A.push('invoice');
  if (can('sales', 'post') && ['draft', 'confirmed'].includes(o.status)) A.push('cancel');
  const label = { confirm: t('so.confirm'), dispatch: t('so.dispatch'), invoice: t('so.createInvoice'), cancel: t('so.cancel') };
  openSheet({ title: o.number, html: `<div class="glass kv"><span>${esc(t('c.customer'))}</span><span>${esc(o.cname)}</span><span>${esc(t('common.status'))}</span><span>${chip(t(KEY[o.status]), TONE[o.status])}</span><span>${esc(t('common.date'))}</span><span>${esc(o.order_date)}</span></div>
    <div class="glass section"><div class="scroll-x"><table class="tbl"><tr><th>${esc(t('pr.product'))}</th><th class="n">${esc(t('so.ordered'))}</th><th class="n">${esc(t('so.delivered'))}</th><th class="n">${esc(t('so.remaining'))}</th></tr>${lines.map((l, i) => `<tr><td>${esc(l.ref)}<br><small>${esc(money(D(l.unit_price)))} DA${D(l.discount_pct).isZero() ? '' : ' · −' + esc(D(l.discount_pct).toString()) + ' %'}</small></td><td class="n">${esc(fq(D(l.qty)))}</td><td class="n">${esc(fq(prog[i].delivered))}</td><td class="n">${esc(fq(prog[i].remaining))}</td></tr>`).join('')}</table></div>${dns.length ? `<small>${esc(t('so.dn'))}: ${dns.map((d) => esc(d.number)).join(', ')}</small>` : ''}</div>
    <div class="actions" style="flex-wrap:wrap">${A.map((a) => `<button class="btn ${a === 'cancel' ? 'danger' : 'primary'}" data-act="${a}">${esc(label[a])}</button>`).join('')}</div>`,
  mount: (root, close) => {
    const run = async (fn) => { try { await fn(); toast(t('common.saved')); close(); await ctx.reload(); openOrder(ctx, id); } catch (e) { toast(errorText(e), 'err'); } };
    $('[data-act=confirm]', root)?.addEventListener('click', (e) => { e.target.disabled = true; run(() => confirmSalesOrder(db, ctx.user, id)); });
    $('[data-act=cancel]', root)?.addEventListener('click', (e) => { e.target.disabled = true; run(() => cancelSalesOrder(db, ctx.user, id)); });
    $('[data-act=dispatch]', root)?.addEventListener('click', () => { close(); dispatchSheet(ctx, o, prog); });
    $('[data-act=invoice]', root)?.addEventListener('click', () => { close(); invoiceSheet(ctx, { customerId: o.customer_id, orderId: id, lines: prog.map((p, i) => ({ p, l: lines[i] })).filter(({ p }) => p.delivered.gt(0)).map(({ p, l }) => ({ productId: l.product_id, description: l.name_fr, qty: p.delivered.toString(), unitPrice: l.unit_price, discountPct: l.discount_pct })) }); });
  } });
}

async function newOrderSheet(ctx) {
  const { db } = ctx;
  const customers = await db.all('SELECT id, ref, name FROM customers WHERE active=1 ORDER BY name');
  const products = []; for (const p of await db.all("SELECT id, ref, name_fr, sale_price FROM products WHERE status='active' ORDER BY ref")) products.push({ ...p, av: (await availableStock(db, p.id)).available });
  if (!customers.length) return toast(t('so.needCustomers'), 'err'); if (!products.length) return toast(t('so.needProducts'), 'err');
  const line = () => `<div class="row-line glass"><div class="rh"><select data-prod aria-label="${esc(t('pr.product'))}">${products.map((p) => `<option value="${esc(p.id)}" data-sp="${esc(p.sale_price)}">${esc(p.ref)} — ${esc(p.name_fr)} (${esc(t('i.available'))} ${esc(fq(p.av))})</option>`).join('')}</select><button type="button" class="round-btn sm" data-rm aria-label="✕">✕</button></div>
    <div class="r3" style="grid-template-columns:1fr 1.3fr 1fr"><input data-qty inputmode="decimal" autocomplete="off" placeholder="${esc(t('common.qty'))}" aria-label="${esc(t('common.qty'))}"><input data-price inputmode="decimal" autocomplete="off" placeholder="${esc(t('so.unitPrice'))}" aria-label="${esc(t('so.unitPrice'))}" value="${esc(products[0].sale_price)}"><input data-disc inputmode="decimal" autocomplete="off" placeholder="${esc(t('so.discount'))}" aria-label="${esc(t('so.discount'))}" value="0"></div></div>`;
  openSheet({ title: t('so.new'), html: `<form novalidate><div class="fld"><label for="oc">${esc(t('c.customer'))} *</label><select id="oc">${customers.map((c) => `<option value="${esc(c.id)}">${esc(c.name)} (${esc(c.ref)})</option>`).join('')}</select></div>
    <div class="row-lines" id="lines">${line()}</div><button type="button" class="btn secondary sm" data-add>+ ${esc(t('so.addLine'))}</button><div class="form-error" hidden role="alert"></div>
    <div class="actions"><button type="button" class="btn secondary" data-x>${esc(t('common.cancel'))}</button><button type="submit" class="btn primary">${esc(t('common.save'))}</button></div></form>`,
  mount: (root, close) => {
    const lines = $('#lines', root), err = $('.form-error', root); let busy = false;
    $('[data-add]', root).addEventListener('click', () => lines.insertAdjacentHTML('beforeend', line()));
    root.addEventListener('click', (e) => { if (e.target.closest('[data-rm]') && $$('.row-line', lines).length > 1) e.target.closest('.row-line').remove(); });
    root.addEventListener('change', (e) => { if (e.target.matches('[data-prod]')) $('[data-price]', e.target.closest('.row-line')).value = e.target.selectedOptions[0].dataset.sp; });
    $('form', root).addEventListener('submit', async (e) => {
      e.preventDefault(); if (busy) return; busy = true; const btn = $('button[type=submit]', root); btn.disabled = true; err.hidden = true;
      try { const r = await createSalesOrder(db, ctx.user, { customerId: $('#oc', root).value, lines: $$('.row-line', lines).map((l) => ({ productId: $('[data-prod]', l).value, qty: $('[data-qty]', l).value, unitPrice: $('[data-price]', l).value, discountPct: $('[data-disc]', l).value || '0' })) });
        toast(`${r.number} ✓`); close(); await ctx.reload(); openOrder(ctx, r.id);
      } catch (x) { err.textContent = errorText(x); err.hidden = false; btn.disabled = false; busy = false; } });
  } });
}

export async function salesScreen(ctx) {
  const { db, can } = ctx;
  const rows = await db.all('SELECT so.*, c.name cname FROM sales_orders so JOIN customers c ON c.id=so.customer_id ORDER BY so.order_date DESC, so.number DESC LIMIT 200');
  const html = `<div class="page-head"><h1>${esc(t('nav.sales'))}</h1>${can('sales', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('so.new'))}</button>` : ''}</div>
    <div class="list">${rows.map((o) => `<button class="glass card" data-id="${esc(o.id)}"><div><div class="t1">${esc(o.number)}</div><div class="t2">${esc(o.cname)} · ${esc(dstr(o.order_date))}</div></div><div class="num">${chip(t(KEY[o.status]), TONE[o.status])}</div></button>`).join('') || `<div class="glass notice"><p>${esc(t('common.empty'))}</p></div>`}</div>`;
  return { html, mount(root) { $('[data-new]', root)?.addEventListener('click', () => newOrderSheet(ctx)); $$('.card', root).forEach((c) => c.addEventListener('click', () => openOrder(ctx, c.dataset.id))); } };
}
