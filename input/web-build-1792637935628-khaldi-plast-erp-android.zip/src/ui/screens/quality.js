import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { recordInspection, qualityReport } from '../../core/quality.js';
import { today, addDays } from '../../core/dates.js';
import { esc, $, formSheet, toast } from '../ui.js';
import { qty as fq } from '../fmt.js';

export async function qualityScreen(ctx) {
  const { db, can } = ctx; const to = today(), from = addDays(to, -30);
  const orders = await db.all("SELECT po.id, po.number, p.ref FROM production_orders po JOIN products p ON p.id=po.product_id WHERE po.status IN ('in_progress','completed') ORDER BY po.number DESC");
  const byP = await qualityReport(db, 'product', { from, to }), byD = await qualityReport(db, 'defect', { from, to });
  const names = Object.fromEntries((await db.all('SELECT id, ref FROM products')).map((p) => [p.id, p.ref]));
  const rate = (g) => (g.rejectionRatePct ? `${g.rejectionRatePct.round(2).format(ctx.lang, 2)} %` : '—');
  const recent = await db.all('SELECT qi.*, po.number FROM quality_inspections qi JOIN production_orders po ON po.id=qi.production_order_id ORDER BY qi.inspected_on DESC, qi.created_at DESC LIMIT 30');
  const html = `<div class="page-head"><h1>${esc(t('nav.quality'))}</h1>${can('quality', 'write') ? `<button class="btn primary sm" data-new>+ ${esc(t('qu.new'))}</button>` : ''}</div>
    <div class="glass section"><h2>${esc(t('qu.byProduct'))}</h2><table class="tbl">${byP.map((g) => `<tr><td>${esc(names[g.key] ?? g.key)}</td><td class="n">${esc(fq(g.rejected))} / ${esc(fq(g.inspected))}</td><td class="n">${esc(rate(g))}</td></tr>`).join('') || `<tr><td>${esc(t('common.empty'))}</td></tr>`}</table></div>
    <div class="glass section"><h2>${esc(t('qu.byDefect'))}</h2><table class="tbl">${byD.map((g) => `<tr><td>${esc(g.key)}</td><td class="n">${esc(fq(g.rejected))}</td><td class="n">${esc(rate(g))}</td></tr>`).join('') || `<tr><td>${esc(t('common.empty'))}</td></tr>`}</table></div>
    <div class="list">${recent.map((r) => `<div class="glass card" style="cursor:default"><div><div class="t1">${esc(r.number)} · ${esc(r.inspected_on)}</div><div class="t2">${esc(r.defect_category ?? '')}</div></div><div class="num">${esc(fq(D(r.rejected_qty)))} / ${esc(fq(D(r.inspected_qty)))}</div></div>`).join('')}</div>`;
  return { html, mount(root) { $('[data-new]', root)?.addEventListener('click', () => { if (!orders.length) return toast(t('qu.noOrders'), 'err');
    formSheet({ title: t('qu.new'), fields: [{ name: 'order', label: t('qu.order'), type: 'select', options: orders.map((o) => ({ value: o.id, label: `${o.number} — ${o.ref}` })) }, { name: 'inspected', label: t('qu.inspected'), type: 'number', required: true }, { name: 'accepted', label: t('pr.accepted'), type: 'number', required: true }, { name: 'rejected', label: t('pr.rejected'), type: 'number', required: true }, { name: 'defect', label: t('qu.defect') }, { name: 'desc', label: t('qu.defectDesc') }],
      onSubmit: async (v) => { await recordInspection(db, ctx.user, { productionOrderId: v.order, inspected: v.inspected, accepted: v.accepted, rejected: v.rejected, defectCategory: v.defect || null, defectDescription: v.desc || null }); toast(t('common.saved')); ctx.reload(); } }); }); } };
}
