// A4 invoice document (HTML, printable to PDF). Only data that exists is printed — no legal/bank details are ever invented.
import { t } from '../../core/i18n/index.js';
import { D } from '../../core/decimal.js';
import { esc } from '../dom.js';
const iso = (x) => `\u2066${x}\u2069`;

const logoUrl = new URL('../../../assets/brand/logo-official.png', import.meta.url).href; // exact official logo, uniform scaling only

export function invoiceDocumentHtml({ company, invoice, lines, customer, paid, credited = 0, outstanding, lang }) {
  const m = (v) => D(v).format(lang, 2), q = (v) => { const d = D(v), s = d.toString(); return d.format(lang, Math.min(s.includes('.') ? s.split('.')[1].length : 0, 4)); };
  const rows = (pairs) => pairs.filter(([, v]) => v && String(v).trim()).map(([k, v]) => `<div><b>${esc(k)}</b> ${esc(v)}</div>`).join('');
  const byRate = new Map();
  for (const l of lines) { const k = D(l.tax_rate_pct).toString(); const b = byRate.get(k) ?? { base: D(0), tax: D(0) }; b.base = b.base.add(l.line_ht); b.tax = b.tax.add(l.line_tax); byRate.set(k, b); }
  const days = invoice.due_date && invoice.issue_date ? Math.round((Date.parse(invoice.due_date) - Date.parse(invoice.issue_date)) / 86400000) : null;
  return `<div class="doc" dir="${lang === 'ar' ? 'rtl' : 'ltr'}" lang="${lang}">
    <div class="doc-head"><img src="${logoUrl}" alt="KHALDI PLAST" class="doc-logo"><div class="doc-co"><div class="doc-co-name">${esc(company.name)}</div>${rows([[t('c.address'), [company.address, company.commune, company.wilaya].filter(Boolean).join(', ')], [t('c.phone'), company.phone], [t('c.email'), company.email], [t('c.nif'), company.nif], [t('c.nis'), company.nis], [t('c.rc'), company.rc], [t('c.ai'), company.ai]])}</div></div>
    <div class="doc-title"><span>${esc(t('inv.docTitle'))} ${esc(invoice.number)}</span><small>${esc(t('inv.issueDate'))} : ${esc(invoice.issue_date)} · ${esc(t('inv.dueDate'))} : ${esc(invoice.due_date)}${invoice.status === 'cancelled' ? ` · ${esc(t('inv.cancelled')).toUpperCase()}` : ''}</small></div>
    <div class="doc-bill"><b>${esc(t('inv.billTo'))}</b><div class="doc-cu">${esc(customer.name)}</div>${rows([[t('c.address'), [customer.address, customer.commune, customer.wilaya].filter(Boolean).join(', ')], [t('c.phone'), customer.phone], [t('c.nif'), customer.nif], [t('c.nis'), customer.nis], [t('c.rc'), customer.rc]])}</div>
    <table class="doc-tbl"><thead><tr><th>#</th><th class="l">${esc(t('inv.description'))}</th><th>${esc(t('inv.qty'))}</th><th>${esc(t('inv.pu'))}</th><th>${esc(t('so.discount'))}</th><th>${esc(t('inv.rate'))}</th><th>${esc(t('inv.lineHt'))}</th></tr></thead><tbody>
    ${lines.map((l, i) => `<tr><td>${i + 1}</td><td class="l">${esc(l.description)}</td><td>${esc(q(l.qty))}</td><td>${esc(iso(m(l.unit_price)))}</td><td>${D(l.discount_pct).isZero() ? '' : esc(iso(q(l.discount_pct) + ' %'))}</td><td>${esc(iso(q(l.tax_rate_pct) + ' %'))}</td><td>${esc(iso(m(l.line_ht)))}</td></tr>`).join('')}</tbody></table>
    <div class="doc-tot"><table>
      <tr><td>${esc(t('inv.subtotal'))}</td><td>${esc(iso(m(invoice.subtotal_ht) + ' DA'))}</td></tr>
      ${D(invoice.discount_total).isZero() ? '' : `<tr><td>${esc(t('inv.discountTotal'))}</td><td>${esc(iso(m(invoice.discount_total) + ' DA'))}</td></tr>`}
      ${[...byRate].map(([r, b]) => `<tr class="sub"><td>${esc(t('inv.tax'))} ${esc(q(r))} % (${esc(t('inv.base'))} ${esc(iso(m(b.base)))})</td><td>${esc(iso(m(b.tax) + ' DA'))}</td></tr>`).join('')}
      <tr class="grand"><td>${esc(t('inv.total'))}</td><td>${esc(iso(m(invoice.total_ttc) + ' DA'))}</td></tr>
      <tr><td>${esc(t('inv.paid'))}</td><td>${esc(iso(m(paid) + ' DA'))}</td></tr>${D(credited).isZero() ? '' : `<tr><td>${esc(t('inv.creditNote'))}</td><td>${esc(iso(m(credited) + ' DA'))}</td></tr>`}<tr class="due"><td>${esc(t('inv.outstanding'))}</td><td>${esc(iso(m(outstanding) + ' DA'))}</td></tr></table></div>
    <div class="doc-foot"><div>${days != null ? `<b>${esc(t('inv.terms'))}</b> : ${days} ${esc(t('inv.days'))} — ${esc(t('inv.dueDate'))} ${esc(invoice.due_date)}` : ''}</div>${company.bank_details ? `<div><b>${esc(t('c.bank'))}</b> ${esc(company.bank_details)}</div>` : ''}${invoice.notes ? `<div>${esc(invoice.notes)}</div>` : ''}</div>
    <div class="doc-sign"><div>${esc(t('inv.signature'))}</div></div></div>`;
}
