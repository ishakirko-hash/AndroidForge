import { t } from '../core/i18n/index.js';
// Core errors are English technical messages; the most common ones are translated, the rest are shown with context.
const MAP = [[/Possible duplicate payment/i, 'err.dupPay'], [/Insufficient stock|Insufficient funds/i, 'err.insufficient'], [/Duplicate .*reference|already exists|already recorded/i, 'err.duplicate'], [/greater than zero/i, 'err.positive'],
  [/may not (read|write|post|admin)/i, 'err.permission'], [/is required|required/i, 'err.required'], [/must equal total|must equal produced/i, 'err.sum'], [/consumption is required/i, 'err.consumption'], [/Invalid decimal|Invalid .*decimal/i, 'err.number'], [/Over-delivery/i, 'err.over'], [/exceeds|Allocations exceed/i, 'err.exceeds'], [/period .* is closed/i, 'err.closed']];
export function errorText(e) {
  const m = e?.message ?? String(e);
  for (const [re, key] of MAP) if (re.test(m)) return t(key);
  return t('err.generic', { msg: m });
}
