/** Save/share a text file. Android (Capacitor): Filesystem + Share plugins via the native bridge (unverified on device). Browser: download. */
export async function exportText(filename, text, mime = 'text/plain') {
  const cap = window.Capacitor;
  if (cap?.isNativePlatform?.()) {
    const FS = cap.registerPlugin('Filesystem'), Share = cap.registerPlugin('Share');
    const w = await FS.writeFile({ path: filename, data: text, directory: 'CACHE', encoding: 'utf8' });
    await Share.share({ title: filename, url: w.uri, dialogTitle: filename });
    return 'shared';
  }
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: `${mime};charset=utf-8` })); a.download = filename;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); return 'downloaded';
}
