import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { recordMovement } from './inventory.js';
import { uid, nowIso } from './ids.js';
import { today } from './dates.js';

export async function recordInspection(db, user, { productionOrderId, inspectedOn = today(), inspected, accepted, rejected, defectCategory = null, defectDescription = null, machineId = null, shiftId = null, inspector = null, correctiveAction = null, notes = null }) {
  requirePermission(user, 'quality', 'write');
  const i = D(inspected), a = D(accepted), r = D(rejected);
  if (i.isNegative() || a.isNegative() || r.isNegative()) throw new Error('Quantities must not be negative');
  if (!a.add(r).eq(i)) throw new Error('Accepted + rejected must equal inspected');
  if (r.gt(0) && !defectCategory?.trim()) throw new Error('A defect category is required when units are rejected');
  return db.transaction(async (tx) => {
    const o = await tx.get('SELECT product_id FROM production_orders WHERE id=?', [productionOrderId]); if (!o) throw new Error('Production order not found');
    const id = uid('qi_');
    await tx.run(`INSERT INTO quality_inspections(id,production_order_id,product_id,inspected_on,inspected_qty,accepted_qty,rejected_qty,defect_category,defect_description,machine_id,shift_id,inspector,corrective_action,notes,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [id, productionOrderId, o.product_id, inspectedOn, i.toString(), a.toString(), r.toString(), defectCategory, defectDescription, machineId, shiftId, inspector, correctiveAction, notes, nowIso()]);
    await audit(tx, { userId: user.id, action: 'record', entity: 'inspection', entityId: id }); return id;
  });
}
const GROUP = { product: 'product_id', machine: 'machine_id', shift: 'shift_id', defect: 'defect_category', day: 'inspected_on' };
export async function qualityReport(db, by, { from, to }) {
  const col = GROUP[by]; if (!col) throw new Error('Invalid grouping');
  const m = new Map();
  for (const r of await db.all(`SELECT ${col} k, inspected_qty i, rejected_qty r FROM quality_inspections WHERE inspected_on>=? AND inspected_on<=?`, [from, to])) {
    const g = m.get(r.k ?? '—') ?? { key: r.k ?? '—', inspected: Dec.zero(), rejected: Dec.zero() };
    g.inspected = g.inspected.add(r.i); g.rejected = g.rejected.add(r.r); m.set(g.key, g);
  }
  return [...m.values()].map((g) => ({ ...g, rejectionRatePct: Dec.percent(g.rejected, g.inspected) }));
}

/** Waste is recorded separately from accepted goods. */
export async function recordWaste(db, user, { productionOrderId = null, materialId, qty, reason }) {
  requirePermission(user, 'quality', 'write');
  if (!D(qty).gt(0)) throw new Error('Quantity must be greater than zero');
  if (!reason?.trim()) throw new Error('A reason is required');
  return db.transaction(async (tx) => {
    if (!(await tx.get('SELECT 1 x FROM materials WHERE id=?', [materialId]))) throw new Error('Unknown material');
    const id = uid('wr_'); await tx.run('INSERT INTO waste_records(id,production_order_id,material_id,qty,reason,created_at) VALUES (?,?,?,?,?,?)', [id, productionOrderId, materialId, D(qty).toString(), reason, nowIso()]);
    await audit(tx, { userId: user.id, action: 'record', entity: 'waste', entityId: id }); return id;
  });
}
/**
 * Returns measured recyclable material to stock. Controlled: needs 'quality:post', a measured quantity, and can never exceed
 * the waste recorded (cumulative), so recovered material cannot be counted twice.
 */
export async function recoverWaste(db, user, wasteId, { qty, recycledMaterialId }) {
  requirePermission(user, 'quality', 'post');
  const q = D(qty); if (!q.gt(0)) throw new Error('Recovered quantity must be greater than zero');
  return db.transaction(async (tx) => {
    const w = await tx.get('SELECT * FROM waste_records WHERE id=?', [wasteId]); if (!w) throw new Error('Waste record not found');
    const already = D(w.recovered_qty);
    if (already.add(q).gt(w.qty)) throw new Error(`Recovery exceeds recorded waste (recorded ${w.qty}, already recovered ${already})`);
    await recordMovement(tx, user, { type: 'recovery', itemType: 'material', itemId: recycledMaterialId, qty: q, eventKey: `recover:${wasteId}:${already.toString()}`, sourceDoc: wasteId, reason: 'recovered recyclable' });
    await tx.run('UPDATE waste_records SET recovered_qty=? WHERE id=?', [already.add(q).toString(), wasteId]);
    await audit(tx, { userId: user.id, action: 'recover', entity: 'waste', entityId: wasteId, details: { qty: q.toString() } });
  });
}
