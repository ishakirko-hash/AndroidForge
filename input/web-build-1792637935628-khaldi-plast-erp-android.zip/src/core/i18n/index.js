import fr from './fr.js';
import ar from './ar.js';
const DICT = { fr, ar };
export const LANGS = { fr: { dir: 'ltr' }, ar: { dir: 'rtl' } };
let current = 'fr';
export const getLanguage = () => current;
export function setLanguage(lang) {
  if (!LANGS[lang]) throw new Error(`Unsupported language: ${lang}`);
  current = lang;
  if (typeof document !== 'undefined') { document.documentElement.lang = lang; document.documentElement.dir = LANGS[lang].dir; }
}
/** t('key', {n: 3}) — falls back to French, then to the key itself (visible, so missing text is noticed). */
export function t(key, params = {}, lang = current) {
  const s = DICT[lang]?.[key] ?? DICT.fr[key] ?? key;
  return s.replace(/\{(\w+)\}/g, (_, k) => (params[k] ?? `{${k}}`));
}
export const dictionaries = DICT;
