import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { lowStock, getBalance } from './inventory.js';
import { invoiceOutstanding, customerBalance } from './receivables.js';
import { dueMaintenance } from './machines.js';
import { budgetVsActual } from './budgets.js';
import { verifyLedgerIntegrity } from './ledger.js';
import { reconcileCash } from './cash.js';
import { rejectionRate } from './metrics.js';
import { addDays, daysBetween, today } from './dates.js';
import { nowIso } from './ids.js';

export const DEFAULT_THRESHOLDS = { rejectionPct: '5', consumptionTolerancePct: '10', expenseIncreasePct: '50', maintenanceDays: '7', budgetWarnPct: '90', backupMaxAgeDays: '7', overdueCriticalDays: '30' };
export async function getThresholds(db) {
  const r = await db.get("SELECT value FROM app_settings WHERE key='alerts.thresholds'");
  return { ...DEFAULT_THRESHOLDS, ...(r ? JSON.parse(r.value) : {}) };
}
export async function setThresholds(db, user, patch) {
  requirePermission(user, 'settings', 'admin');
  for (const [k, v] of Object.entries(patch)) {
    if (!(k in DEFAULT_THRESHOLDS)) throw new Error(`Unknown threshold ${k}`);
    if (D(String(v)).isNegative()) throw new Error(`${k} must not be negative`);
  }
  return db.transaction(async (tx) => {
    const next = { ...(await getThresholds(tx)), ...Object.fromEntries(Object.entries(patch).map(([k, v]) => [k, D(String(v)).toString()])) };
    await tx.run("INSERT INTO app_settings(key,value,updated_at) VALUES ('alerts.thresholds',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at", [JSON.stringify(next), nowIso()]);
    await audit(tx, { userId: user.id, action: 'set', entity: 'alert_thresholds', details: patch });
    return next;
  });
}

const SEV = { critical: 0, warning: 1, info: 2 };
/** Evidence-based alerts: every alert names the records it comes from. Nothing here changes data. */
export async function computeAlerts(db, { asOf = today() } = {}) {
  const th = await getThresholds(db), A = [];
  const add = (code, severity, subject, data, evidence = null) => A.push({ code, severity, subject, data, evidence });

  for (const l of await lowStock(db)) add('low_stock', 'warning', l.ref, { type: l.type, balance: l.balance.toString(), min: l.min.toString() });

  const need = await db.all(`SELECT pm.material_id id, SUM(CAST(pm.expected_qty AS REAL)) approx FROM production_materials pm JOIN production_orders po ON po.id=pm.order_id
    WHERE po.status IN ('planned','in_progress') AND pm.actual_qty IS NULL GROUP BY pm.material_id`);
  for (const n of need) {
    const rows = await db.all(`SELECT pm.expected_qty q FROM production_materials pm JOIN production_orders po ON po.id=pm.order_id WHERE po.status IN ('planned','in_progress') AND pm.actual_qty IS NULL AND pm.material_id=?`, [n.id]);
    const required = Dec.sum(rows.map((r) => D(r.q))), bal = await getBalance(db, 'material', n.id);
    if (required.gt(bal)) add('insufficient_materials', 'critical', (await db.get('SELECT ref FROM materials WHERE id=?', [n.id])).ref, { required: required.toString(), available: bal.toString(), shortage: required.sub(bal).toString() });
  }

  for (const i of await db.all("SELECT id, number, due_date, customer_id FROM invoices WHERE status='issued' AND due_date < ?", [asOf])) {
    const out = await invoiceOutstanding(db, i.id);
    if (out.gt(0)) { const late = daysBetween(i.due_date, asOf); add('overdue_invoice', late > Number(th.overdueCriticalDays) ? 'critical' : 'warning', i.number, { outstanding: out.toString(), daysOverdue: late, dueDate: i.due_date }); }
  }
  for (const c of await db.all("SELECT id, ref, credit_limit FROM customers WHERE active=1")) {
    if (D(c.credit_limit).isZero()) continue;
    const b = (await customerBalance(db, c.id)).balance;
    if (b.gt(c.credit_limit)) add('credit_limit_exceeded', 'warning', c.ref, { balance: b.toString(), limit: c.credit_limit });
  }
  for (const o of await db.all("SELECT id, number, total_qty, rejected_qty FROM production_orders WHERE status='completed' AND substr(finished_at,1,10) >= ?", [addDays(asOf, -30)])) {
    const rate = rejectionRate(o.rejected_qty, o.total_qty);
    if (rate && rate.gt(th.rejectionPct)) add('high_rejection', 'warning', o.number, { ratePct: rate.round(2).toString(), thresholdPct: th.rejectionPct });
  }
  for (const o of await db.all("SELECT number, planned_date, status FROM production_orders WHERE planned_date IS NOT NULL AND planned_date < ? AND status IN ('draft','planned','in_progress')", [asOf]))
    add('production_delay', 'warning', o.number, { plannedDate: o.planned_date, status: o.status, daysLate: daysBetween(o.planned_date, asOf) });
  for (const m of await dueMaintenance(db, { asOf, withinDays: Number(th.maintenanceDays) })) add(m.overdue ? 'maintenance_overdue' : 'maintenance_due', m.overdue ? 'critical' : 'warning', m.machineRef, { task: m.task, dueDate: m.dueDate, daysLeft: m.daysLeft });
  for (const b of await budgetVsActual(db, asOf.slice(0, 7), { warnPct: th.budgetWarnPct })) if (b.status !== 'ok') add(b.status === 'over' ? 'budget_exceeded' : 'budget_warning', b.status === 'over' ? 'critical' : 'warning', b.category, { budget: b.budget.toString(), actual: b.actual.toString(), usedPct: b.usedPct?.toString() ?? null });

  for (const r of await db.all("SELECT po.number, pm.material_id, pm.expected_qty e, pm.actual_qty a, po.total_qty t, po.planned_qty p FROM production_materials pm JOIN production_orders po ON po.id=pm.order_id WHERE po.status='completed' AND pm.actual_source='measured' AND substr(po.finished_at,1,10) >= ?", [addDays(asOf, -30)])) {
    const expected = D(r.e).mul(r.t).div(r.p);
    if (expected.gt(0) && D(r.a).gt(expected.mul(D('1').add(D(th.consumptionTolerancePct).div('100'))))) add('unusual_consumption', 'warning', r.number, { expected: expected.round(2).toString(), actual: r.a, tolerancePct: th.consumptionTolerancePct });
  }
  const prev = (() => { const [y, m] = asOf.slice(0, 7).split('-').map(Number); return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`; })();
  const byCat = async (p) => { const m = new Map(); for (const e of await db.all("SELECT category_code c, amount a FROM expenses WHERE status='valid' AND substr(exp_date,1,7)=?", [p])) m.set(e.c, (m.get(e.c) ?? Dec.zero()).add(e.a)); return m; };
  const cur = await byCat(asOf.slice(0, 7)), old = await byCat(prev);
  for (const [c, v] of cur) { const o = old.get(c); if (o && o.gt(0)) { const inc = v.sub(o).mul('100').div(o); if (inc.gt(th.expenseIncreasePct)) add('expense_spike', 'warning', c, { current: v.toString(), previous: o.toString(), increasePct: inc.round(1).toString() }); } }

  const bad = await verifyLedgerIntegrity(db);
  if (bad.length) add('ledger_unbalanced', 'critical', bad.join(', '), { entries: bad });
  for (const r of await reconcileCash(db)) if (!r.ok) add('cash_ledger_mismatch', 'warning', r.ledgerAccount, { cash: r.cash.toString(), ledger: r.ledger.toString(), difference: r.difference.toString() });
  for (const d of await db.all("SELECT customer_id, amount, pay_date, COUNT(*) n FROM payments WHERE status='valid' GROUP BY customer_id, amount, pay_date HAVING n > 1")) add('possible_duplicate_payment', 'warning', d.pay_date, { amount: d.amount, count: d.n });
  for (const o of await db.all("SELECT id, number, total_qty FROM production_orders WHERE status='completed' AND id IN (SELECT production_order_id FROM shift_records)")) {
    const s = Dec.sum((await db.all('SELECT produced_qty p FROM shift_records WHERE production_order_id=?', [o.id])).map((r) => D(r.p)));
    if (!s.eq(o.total_qty)) add('shift_total_mismatch', 'warning', o.number, { shiftTotal: s.toString(), orderTotal: o.total_qty });
  }

  const lastOk = await db.get("SELECT MAX(ts) ts FROM backup_log WHERE kind='create' AND status='ok'"), lastFail = await db.get("SELECT MAX(ts) ts FROM backup_log WHERE status='failed'");
  if (lastFail.ts && (!lastOk.ts || lastFail.ts > lastOk.ts)) add('backup_failed', 'critical', 'backup', { at: lastFail.ts });
  else if (!lastOk.ts || daysBetween(lastOk.ts.slice(0, 10), asOf) > Number(th.backupMaxAgeDays)) add('backup_stale', 'warning', 'backup', { lastBackup: lastOk.ts ?? null, maxAgeDays: th.backupMaxAgeDays });

  const co = await db.get('SELECT * FROM company_settings WHERE id=1');
  const missing = ['address', 'nif', 'nis', 'rc'].filter((f) => !co[f]?.trim());
  if (missing.length) add('company_identity_incomplete', 'info', 'company', { missing });

  return A.sort((a, b) => SEV[a.severity] - SEV[b.severity] || a.code.localeCompare(b.code));
}
