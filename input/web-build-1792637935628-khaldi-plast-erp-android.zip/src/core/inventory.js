import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nowIso } from './ids.js';

const IN = ['opening', 'receipt', 'production_output', 'customer_return', 'recovery', 'adjustment_in'];
const OUT = ['production_consumption', 'dispatch', 'supplier_return', 'damage', 'waste', 'adjustment_out'];
export const MOVEMENT_TYPES = [...IN, ...OUT];
const rdiv = (n, d) => { const neg = (n < 0n) !== (d < 0n); const a = n < 0n ? -n : n, b = d < 0n ? -d : d; let q = a / b; if ((a % b) * 2n >= b) q += 1n; return neg ? -q : q; };

/**
 * Appends one ledger movement. MUST run inside db.transaction (callers compose several movements atomically).
 * `eventKey` makes it idempotent: a repeated key is ignored and reported as duplicate (never applied twice).
 * Negative stock is rejected by a database trigger as well as here.
 */
export async function recordMovement(tx, user, m) {
  const type = m.type;
  if (!MOVEMENT_TYPES.includes(type)) throw new Error(`Unknown movement type ${type}`);
  if (!m.eventKey) throw new Error('eventKey is required');
  const qty = D(m.qty);
  if (!qty.gt(0)) throw new Error('Quantity must be greater than zero');
  const signed = IN.includes(type) ? qty.u : -qty.u;
  if (!(await tx.get('SELECT 1 x FROM stock_movements WHERE event_key=?', [m.eventKey]))) {
    if (signed < 0n) {
      const bal = await getBalance(tx, m.itemType, m.itemId, m.locationId);
      if (bal.lt(qty)) throw new Error(`Insufficient stock: available ${bal}, requested ${qty}`);
    }
    // Weighted-average costing. Inbound: explicit unitCost / totalValue, else current average, else unpriced (value 0, cost_known 0).
    // Outbound: current average; the last unit out clears the remaining value exactly (no rounding residue).
    const cur = await tx.get('SELECT COALESCE(SUM(qty_u),0) q, COALESCE(SUM(value_u),0) v FROM stock_movements WHERE item_type=? AND item_id=?', [m.itemType, m.itemId]);
    const curQ = BigInt(cur.q), curV = BigInt(cur.v);
    let valueU = 0n, known = 0;
    if (signed > 0n) {
      if (m.totalValue != null) { valueU = D(m.totalValue).u; known = m.costKnown === false ? 0 : 1; }
      else if (m.unitCost != null) { valueU = qty.mul(m.unitCost).u; known = 1; }
      else if (curQ > 0n && curV > 0n) { valueU = rdiv(signed * curV, curQ); known = 1; }
    } else if (curQ > 0n && curV > 0n) {
      valueU = -(-signed === curQ ? curV : rdiv(-signed * curV, curQ)); known = 1;
    }
    await tx.run(`INSERT INTO stock_movements(event_key,item_type,item_id,location_id,movement_type,qty_u,source_doc,reason,user_id,ts,value_u,cost_known)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, [m.eventKey, m.itemType, m.itemId, m.locationId ?? 'MAIN', type, signed, m.sourceDoc ?? null,
      m.reason ?? null, user?.id ?? null, nowIso(), valueU, known]);
    await audit(tx, { userId: user?.id, action: type, entity: m.itemType + '_stock', entityId: m.itemId, details: { qty: qty.toString(), doc: m.sourceDoc ?? null } });
    return { duplicate: false, value: new Dec(valueU < 0n ? -valueU : valueU), costKnown: known === 1 };
  }
  return { duplicate: true };
}

/** Standalone, permission-checked, atomic movement (for screens). */
export async function postMovement(db, user, m) {
  requirePermission(user, 'inventory', 'post');
  if (m.type === 'adjustment_in' || m.type === 'adjustment_out') { if (!m.reason) throw new Error('A reason is required for adjustments'); }
  return db.transaction((tx) => recordMovement(tx, user, m));
}

export async function getBalance(db, itemType, itemId, locationId = null) {
  const r = locationId
    ? await db.get('SELECT COALESCE(SUM(qty_u),0) s FROM stock_movements WHERE item_type=? AND item_id=? AND location_id=?', [itemType, itemId, locationId])
    : await db.get('SELECT COALESCE(SUM(qty_u),0) s FROM stock_movements WHERE item_type=? AND item_id=?', [itemType, itemId]);
  return new Dec(BigInt(r.s));
}

export const getHistory = (db, itemType, itemId) =>
  db.all('SELECT * FROM stock_movements WHERE item_type=? AND item_id=? ORDER BY id', [itemType, itemId]);

/** Items at or below their minimum stock (facts from the ledger; minimum is a configured value). */
export async function lowStock(db) {
  const out = [];
  for (const [type, table] of [['product', 'products'], ['material', 'materials']]) {
    for (const r of await db.all(`SELECT id, ref, min_stock FROM ${table} WHERE status='active'`)) {
      const bal = await getBalance(db, type, r.id);
      if (!D(r.min_stock).isZero() && (bal.lt(r.min_stock) || bal.eq(r.min_stock))) out.push({ type, id: r.id, ref: r.ref, balance: bal, min: D(r.min_stock) });
    }
  }
  return out;
}

/** Stock valuation at weighted-average cost, derived from the ledger. `complete:false` means some quantity entered without a cost. */
export async function stockValuation(db) {
  const rows = await db.all(`SELECT item_type, item_id, SUM(qty_u) q, SUM(value_u) v,
    SUM(CASE WHEN qty_u > 0 AND cost_known = 0 THEN 1 ELSE 0 END) unpriced FROM stock_movements GROUP BY item_type, item_id`);
  const items = [];
  for (const r of rows) {
    const t = r.item_type === 'product' ? 'products' : 'materials';
    const ref = (await db.get(`SELECT ref FROM ${t} WHERE id=?`, [r.item_id]))?.ref ?? r.item_id;
    const qty = new Dec(BigInt(r.q)), value = new Dec(BigInt(r.v));
    items.push({ type: r.item_type, id: r.item_id, ref, qty, value, avgCost: qty.gt(0) && value.gt(0) ? value.div(qty) : null, complete: r.unpriced === 0 });
  }
  const sum = (type) => Dec.sum(items.filter((i) => i.type === type).map((i) => i.value));
  return { items, materialsValue: sum('material'), productsValue: sum('product'), complete: items.every((i) => i.complete),
    basis: 'weighted average cost from the stock ledger; unpriced receipts are flagged, never guessed' };
}
