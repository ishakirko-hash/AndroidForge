import { D, Dec } from './decimal.js';
import { stockValuation } from './inventory.js';
import { resolveRoles } from './ledger.js';

/**
 * Estimated gross margin per product = invoiced revenue (excl. tax) - cost of goods dispatched (weighted average), same date range.
 * ESTIMATE: invoicing and dispatch dates can differ, and only material cost is in the product cost (labor/overhead not allocated).
 */
export async function productMargin(db, { from, to }) {
  const rev = new Map(), cost = new Map(), unpriced = new Set();
  for (const r of await db.all(`SELECT il.product_id p, il.line_ht h FROM invoice_lines il JOIN invoices i ON i.id=il.invoice_id
    WHERE i.status='issued' AND il.product_id IS NOT NULL AND i.issue_date>=? AND i.issue_date<=?`, [from, to])) rev.set(r.p, (rev.get(r.p) ?? Dec.zero()).add(r.h));
  for (const r of await db.all("SELECT item_id p, value_u v, cost_known k FROM stock_movements WHERE item_type='product' AND movement_type='dispatch' AND substr(ts,1,10)>=? AND substr(ts,1,10)<=?", [from, to])) {
    cost.set(r.p, (cost.get(r.p) ?? Dec.zero()).add(new Dec(-BigInt(r.v)))); if (!r.k) unpriced.add(r.p);
  }
  const out = [];
  for (const p of new Set([...rev.keys(), ...cost.keys()])) {
    const revenue = rev.get(p) ?? Dec.zero(), cogs = cost.get(p) ?? Dec.zero();
    out.push({ productId: p, ref: (await db.get('SELECT ref FROM products WHERE id=?', [p]))?.ref, revenue, cogs, margin: revenue.sub(cogs),
      marginPct: Dec.percent(revenue.sub(cogs), revenue), costComplete: !unpriced.has(p) });
  }
  return { rows: out, estimate: true, basis: 'revenue excl. tax - weighted-average cost of dispatched goods; material cost only' };
}

/** Compares the stock valuation subledger with the inventory ledger accounts. Differences are timing/price effects to be explained, not hidden. */
export async function inventoryLedgerCheck(db) {
  const v = await stockValuation(db);
  const { map } = await resolveRoles(db, ['inventory_materials', 'inventory_finished']);
  const bal = async (code) => { if (!code) return null; const r = await db.get('SELECT COALESCE(SUM(debit_u),0) d, COALESCE(SUM(credit_u),0) c FROM journal_lines WHERE account_code=?', [code]); return new Dec(BigInt(r.d) - BigInt(r.c)); };
  const rows = [['materials', v.materialsValue, await bal(map.inventory_materials)], ['products', v.productsValue, await bal(map.inventory_finished)]];
  return rows.map(([k, sub, led]) => ({ kind: k, subledger: sub, ledger: led, difference: led == null ? null : led.sub(sub), configured: led != null }));
}
