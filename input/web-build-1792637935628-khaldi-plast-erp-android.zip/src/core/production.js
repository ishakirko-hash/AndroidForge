import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nextDocumentNumber } from './sequences.js';
import { computeRequirements } from './bom.js';
import { recordMovement } from './inventory.js';
import { rejectionRate, completionRate, materialPerAccepted } from './metrics.js';
import { autoPost } from './postings.js';
import { uid, nowIso } from './ids.js';

const getOrder = (db, id) => db.get('SELECT * FROM production_orders WHERE id=?', [id]);

/** Draft: no stock effect whatsoever. Recipe version is pinned to the order. */
export async function createOrder(db, user, { productId, recipeId, plannedQty, plannedDate, machine, shift, operator, notes }) {
  requirePermission(user, 'production', 'write');
  if (!D(plannedQty).gt(0)) throw new Error('Planned quantity must be greater than zero');
  return db.transaction(async (tx) => {
    const r = await tx.get('SELECT product_id FROM recipes WHERE id=?', [recipeId]);
    if (!r || r.product_id !== productId) throw new Error('Recipe does not belong to the product');
    const id = uid('po_');
    const number = await nextDocumentNumber(tx, 'production_order', new Date().getFullYear());
    await tx.run(`INSERT INTO production_orders(id,number,product_id,recipe_id,planned_qty,planned_date,machine,shift,operator,notes,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`, [id, number, productId, recipeId, D(plannedQty).toString(), plannedDate ?? null, machine ?? null, shift ?? null, operator ?? null, notes ?? null, nowIso()]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'production_order', entityId: id, details: { number } });
    return { id, number };
  });
}

/** Re-snapshots expected consumption from the pinned recipe; changing the planned quantity recalculates it. */
async function snapshotExpected(tx, order, plannedQty) {
  const req = await computeRequirements(tx, order.recipe_id, plannedQty);
  await tx.run('DELETE FROM production_materials WHERE order_id=?', [order.id]);
  for (const l of req.lines) await tx.run('INSERT INTO production_materials(order_id,material_id,expected_qty) VALUES (?,?,?)', [order.id, l.materialId, l.required.toString()]);
  return req;
}

export async function planOrder(db, user, id, { plannedQty } = {}) {
  requirePermission(user, 'production', 'write');
  return db.transaction(async (tx) => {
    const o = await getOrder(tx, id);
    if (!o) throw new Error('Order not found');
    if (!['draft', 'planned'].includes(o.status)) throw new Error(`Cannot plan an order in status ${o.status}`);
    const q = plannedQty ?? o.planned_qty;
    const req = await snapshotExpected(tx, o, q);
    await tx.run("UPDATE production_orders SET status='planned', planned_qty=? WHERE id=?", [D(q).toString(), id]);
    await audit(tx, { userId: user.id, action: 'plan', entity: 'production_order', entityId: id });
    return req; // includes shortages for the planner to see
  });
}

export async function startOrder(db, user, id) {
  requirePermission(user, 'production', 'post');
  return db.transaction(async (tx) => {
    const o = await getOrder(tx, id);
    if (!o || o.status !== 'planned') throw new Error('Only a planned order can be started');
    await tx.run("UPDATE production_orders SET status='in_progress', started_at=? WHERE id=?", [nowIso(), id]);
    await audit(tx, { userId: user.id, action: 'start', entity: 'production_order', entityId: id });
  });
}

/**
 * Completion: one atomic transaction that consumes materials and creates finished goods exactly once.
 * total = accepted + rejected. Actual consumption must be supplied (measured) or explicitly requested as
 * `useExpected: true`, in which case it is stored as 'calculated' — never silently invented.
 */
export async function completeOrder(db, user, id, { totalQty, acceptedQty, rejectedQty, consumption, useExpected = false, finishedAt }) {
  requirePermission(user, 'production', 'post');
  const total = D(totalQty), acc = D(acceptedQty), rej = D(rejectedQty);
  if (total.isNegative() || acc.isNegative() || rej.isNegative()) throw new Error('Quantities must not be negative');
  if (!acc.add(rej).eq(total)) throw new Error('Accepted + rejected must equal total produced');
  return db.transaction(async (tx) => {
    const o = await getOrder(tx, id);
    if (!o) throw new Error('Order not found');
    if (o.status === 'completed') throw new Error('Order already completed');
    if (o.status !== 'in_progress') throw new Error(`Cannot complete an order in status ${o.status}`);
    const exp = await tx.all('SELECT material_id, expected_qty FROM production_materials WHERE order_id=?', [id]);
    let used;
    if (consumption?.length) used = consumption.map((c) => ({ materialId: c.materialId, qty: D(c.qty), source: 'measured' }));
    else if (useExpected) {
      // scale theoretical requirement from planned to actually produced total (calculated, flagged)
      used = exp.map((e) => ({ materialId: e.material_id, qty: D(e.expected_qty).mul(total).div(o.planned_qty), source: 'calculated' }));
    } else throw new Error('Actual material consumption is required (or pass useExpected to record a calculated value)');
    let matCost = Dec.zero(), costComplete = true;
    for (const u of used) {
      if (u.qty.isNegative()) throw new Error('Consumption must not be negative');
      await tx.run(`INSERT INTO production_materials(order_id,material_id,expected_qty,actual_qty,actual_source) VALUES (?,?,'0',?,?)
        ON CONFLICT(order_id,material_id) DO UPDATE SET actual_qty=excluded.actual_qty, actual_source=excluded.actual_source`,
        [id, u.materialId, u.qty.toString(), u.source]);
      if (u.qty.gt(0)) {
        const mv = await recordMovement(tx, user, { type: 'production_consumption', itemType: 'material', itemId: u.materialId,
          qty: u.qty, eventKey: `prod:${id}:cons:${u.materialId}`, sourceDoc: o.number });
        matCost = matCost.add(mv.value); if (!mv.costKnown) costComplete = false;
      }
    }
    // All consumed material cost is carried by the accepted units (rejects are absorbed). Labor/overhead are NOT yet allocated.
    if (acc.gt(0)) await recordMovement(tx, user, { type: 'production_output', itemType: 'product', itemId: o.product_id,
      qty: acc, totalValue: matCost, costKnown: costComplete, eventKey: `prod:${id}:out`, sourceDoc: o.number });
    const unitCost = acc.gt(0) && costComplete ? matCost.div(acc) : null;
    await tx.run('UPDATE production_orders SET material_cost=?, unit_cost=?, cost_complete=? WHERE id=?', [matCost.toString(), unitCost?.toString() ?? null, costComplete ? 1 : 0, id]);
    await tx.run("UPDATE production_orders SET status='completed', total_qty=?, accepted_qty=?, rejected_qty=?, finished_at=? WHERE id=?",
      [total.toString(), acc.toString(), rej.toString(), finishedAt ?? nowIso(), id]);
    await audit(tx, { userId: user.id, action: 'complete', entity: 'production_order', entityId: id, details: { total: total.toString(), accepted: acc.toString(), rejected: rej.toString() } });
    const posting = await autoPost(tx, user, 'production_order', id);
    return { ...(await orderSummary(tx, id)), posting };
  });
}

export async function cancelOrder(db, user, id) {
  requirePermission(user, 'production', 'post');
  return db.transaction(async (tx) => {
    const o = await getOrder(tx, id);
    if (!o) throw new Error('Order not found');
    if (['completed', 'cancelled'].includes(o.status)) throw new Error(`Cannot cancel an order in status ${o.status}`);
    await tx.run("UPDATE production_orders SET status='cancelled' WHERE id=?", [id]); // never touched stock, so nothing to reverse
    await audit(tx, { userId: user.id, action: 'cancel', entity: 'production_order', entityId: id });
  });
}

export async function orderSummary(db, id) {
  const o = await getOrder(db, id);
  const mats = await db.all('SELECT * FROM production_materials WHERE order_id=?', [id]);
  // per material (never summed across different units): consumed quantity per accepted unit
  const perMaterial = mats.filter((m) => m.actual_qty != null).map((m) => ({
    materialId: m.material_id, consumed: D(m.actual_qty), source: m.actual_source,
    perAcceptedUnit: o.accepted_qty == null ? null : materialPerAccepted(m.actual_qty, o.accepted_qty) }));
  return { order: o, materials: mats, perMaterial, materialCost: o.material_cost == null ? null : D(o.material_cost),
    unitMaterialCost: o.unit_cost == null ? null : D(o.unit_cost), costComplete: o.cost_complete == null ? null : o.cost_complete === 1,
    rejectionRatePct: o.total_qty == null ? null : rejectionRate(o.rejected_qty, o.total_qty),
    completionRatePct: o.accepted_qty == null ? null : completionRate(o.accepted_qty, o.planned_qty) };
}
