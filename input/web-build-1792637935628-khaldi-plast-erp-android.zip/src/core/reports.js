import { D, Dec } from './decimal.js';
import { requirePermission } from './permissions.js';
import { trialBalance } from './ledger.js';
import { stockValuation } from './inventory.js';
import { customerBalance } from './receivables.js';

/** Chronological account statement: invoices (+), credit notes (-), valid payments (-), running balance. */
export async function customerStatement(db, user, customerId) {
  requirePermission(user, 'payments', 'read');
  const c = await db.get('SELECT * FROM customers WHERE id=?', [customerId]); if (!c) throw new Error('Customer not found');
  const ev = [];
  for (const i of await db.all("SELECT number, issue_date d, total_ttc a FROM invoices WHERE customer_id=? AND status='issued'", [customerId])) ev.push({ date: i.d, doc: i.number, kind: 'invoice', delta: D(i.a) });
  for (const n of await db.all("SELECT cn.number, cn.issue_date d, cn.total_ttc a FROM credit_notes cn JOIN invoices i ON i.id=cn.invoice_id WHERE cn.customer_id=? AND i.status='issued'", [customerId])) ev.push({ date: n.d, doc: n.number, kind: 'credit_note', delta: D(n.a).neg() });
  for (const p of await db.all("SELECT number, pay_date d, amount a FROM payments WHERE customer_id=? AND status='valid'", [customerId])) ev.push({ date: p.d, doc: p.number, kind: 'payment', delta: D(p.a).neg() });
  const order = { invoice: 0, credit_note: 1, payment: 2 };
  ev.sort((a, b) => a.date.localeCompare(b.date) || order[a.kind] - order[b.kind] || a.doc.localeCompare(b.doc));
  let run = Dec.zero();
  const lines = ev.map((e) => { run = run.add(e.delta); return { ...e, balance: run }; });
  const bal = await customerBalance(db, customerId);
  return { customer: { ref: c.ref, name: c.name }, lines, closingBalance: run, consistent: run.eq(bal.balance) };
}

const esc = (v) => {
  if (v == null) return '';
  let s = String(v);
  if (typeof v === 'string' && /^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = "'" + s; // spreadsheet formula-injection guard
  return /[",\n\r;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
/** UTF-8 with BOM so Excel opens Arabic correctly. Comma separated, CRLF lines. */
export function toCsv(columns, rows) {
  return '\uFEFF' + [columns.map(esc).join(','), ...rows.map((r) => columns.map((c) => esc(r[c])).join(','))].join('\r\n') + '\r\n';
}

const REPORTS = {
  invoices: { perm: 'invoices', cols: ['number', 'issue_date', 'due_date', 'customer', 'subtotal_ht', 'tax_total', 'total_ttc', 'status'],
    run: (db, { from, to }) => db.all(`SELECT i.number, i.issue_date, i.due_date, c.name customer, i.subtotal_ht, i.tax_total, i.total_ttc, i.status FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.issue_date>=? AND i.issue_date<=? ORDER BY i.issue_date, i.number`, [from, to]) },
  payments: { perm: 'payments', cols: ['number', 'pay_date', 'customer', 'amount', 'method', 'reference', 'status'],
    run: (db, { from, to }) => db.all(`SELECT p.number, p.pay_date, c.name customer, p.amount, p.method, p.reference, p.status FROM payments p JOIN customers c ON c.id=p.customer_id WHERE p.pay_date>=? AND p.pay_date<=? ORDER BY p.pay_date, p.number`, [from, to]) },
  expenses: { perm: 'expenses', cols: ['number', 'exp_date', 'category_code', 'amount', 'description', 'status'],
    run: (db, { from, to }) => db.all('SELECT number, exp_date, category_code, amount, description, status FROM expenses WHERE exp_date>=? AND exp_date<=? ORDER BY exp_date, number', [from, to]) },
  stock_movements: { perm: 'inventory', cols: ['ts', 'item_type', 'item_ref', 'movement_type', 'qty', 'source_doc', 'reason'],
    run: async (db, { from, to }) => (await db.all(`SELECT ts, item_type, item_id, movement_type, qty_u, source_doc, reason FROM stock_movements WHERE substr(ts,1,10)>=? AND substr(ts,1,10)<=? ORDER BY id`, [from, to]))
      .map((r) => ({ ts: r.ts, item_type: r.item_type, item_ref: r.item_id, movement_type: r.movement_type, qty: new Dec(BigInt(r.qty_u)).toString(), source_doc: r.source_doc, reason: r.reason })) },
  trial_balance: { perm: 'accounting', cols: ['code', 'name', 'debit', 'credit'],
    run: async (db, { from, to }) => (await trialBalance(db, { from, to })).rows.map((r) => ({ code: r.code, name: r.name, debit: r.debit.toString(), credit: r.credit.toString() })) },
  stock_valuation: { perm: 'inventory', cols: ['type', 'ref', 'qty', 'value', 'avg_cost', 'complete'],
    run: async (db) => (await stockValuation(db)).items.map((i) => ({ type: i.type, ref: i.ref, qty: i.qty.toString(), value: i.value.toString(), avg_cost: i.avgCost?.toString() ?? '', complete: i.complete })) },
};
export const REPORT_NAMES = Object.keys(REPORTS);
export async function exportCsv(db, user, name, params = {}) {
  const r = REPORTS[name]; if (!r) throw new Error(`Unknown report ${name}`);
  requirePermission(user, r.perm, 'read');
  return toCsv(r.cols, await r.run(db, params));
}
