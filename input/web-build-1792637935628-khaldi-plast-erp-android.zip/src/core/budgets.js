import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { uid } from './ids.js';

export async function setBudget(db, user, { period, categoryCode, amount }) {
  requirePermission(user, 'expenses', 'post');
  if (!/^\d{4}-\d{2}$/.test(period)) throw new Error('period must be YYYY-MM');
  if (D(amount).isNegative()) throw new Error('Budget must not be negative');
  return db.transaction(async (tx) => {
    if (!(await tx.get('SELECT 1 x FROM expense_categories WHERE code=?', [categoryCode]))) throw new Error('Unknown expense category');
    await tx.run('INSERT INTO budgets(id,period,category_code,amount) VALUES (?,?,?,?) ON CONFLICT(period,category_code) DO UPDATE SET amount=excluded.amount', [uid('bg_'), period, categoryCode, D(amount).toString()]);
    await audit(tx, { userId: user.id, action: 'set', entity: 'budget', entityId: `${period}:${categoryCode}`, details: { amount: D(amount).toString() } });
  });
}
/** Variance = budget - actual (negative = overspent). Warning threshold is configurable (percent of budget used). */
export async function budgetVsActual(db, period, { warnPct = '90' } = {}) {
  const [y, m] = period.split('-').map(Number), last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const from = `${period}-01`, to = `${period}-${String(last).padStart(2, '0')}`;
  const rows = [];
  for (const b of await db.all('SELECT * FROM budgets WHERE period=? ORDER BY category_code', [period])) {
    const actual = Dec.sum((await db.all("SELECT amount FROM expenses WHERE status='valid' AND category_code=? AND exp_date>=? AND exp_date<=?", [b.category_code, from, to])).map((e) => D(e.amount)));
    const usedPct = Dec.percent(actual, b.amount);
    rows.push({ category: b.category_code, budget: D(b.amount), actual, variance: D(b.amount).sub(actual), usedPct,
      status: actual.gt(b.amount) ? 'over' : usedPct !== null && !usedPct.lt(warnPct) ? 'warning' : 'ok' });
  }
  return rows;
}
