// Double-entry engine. Amounts are stored as integer units (1e-4) so SQL sums are exact.
import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nextDocumentNumber } from './sequences.js';
import { uid, nowIso } from './ids.js';

export const ROLES = ['receivable', 'payable', 'sales_revenue', 'tax_collected', 'tax_deductible', 'inventory_materials', 'inventory_finished', 'cogs', 'production_waste'];
const TYPES = ['asset', 'liability', 'equity', 'revenue', 'expense'];

export async function createAccount(db, user, { code, name_fr, name_ar = null, type }) {
  requirePermission(user, 'accounting', 'write');
  if (!code?.trim() || !name_fr?.trim()) throw new Error('code and name_fr are required');
  if (!TYPES.includes(type)) throw new Error('Invalid account type');
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM accounts WHERE code=?', [code])) throw new Error(`Duplicate account code ${code}`);
    await tx.run('INSERT INTO accounts(code,name_fr,name_ar,type) VALUES (?,?,?,?)', [code.trim(), name_fr.trim(), name_ar, type]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'account', entityId: code });
  });
}

/** STARTER structure only: NOT the statutory Algerian chart. The accountant must review/replace it before real use. */
export async function seedStarterChart(db, user) {
  requirePermission(user, 'accounting', 'admin');
  const rows = [
    ['1000', 'Capital et réserves', 'رأس المال والاحتياطيات', 'equity'], ['1100', 'Résultat reporté', 'النتيجة المرحلة', 'equity'],
    ['2100', 'Matières premières (stock)', 'مخزون المواد الأولية', 'asset'], ['2200', 'Produits finis (stock)', 'مخزون المنتجات التامة', 'asset'],
    ['3000', 'Clients', 'العملاء', 'asset'], ['3100', 'TVA déductible', 'ضريبة قابلة للخصم', 'asset'],
    ['4000', 'Fournisseurs', 'الموردون', 'liability'], ['4100', 'TVA collectée', 'ضريبة محصلة', 'liability'],
    ['5000', 'Caisse', 'الصندوق', 'asset'], ['5100', 'Banque', 'البنك', 'asset'],
    ['7000', 'Ventes', 'المبيعات', 'revenue'],
    ['6000', 'Électricité et eau', 'كهرباء وماء', 'expense'], ['6100', 'Maintenance', 'صيانة', 'expense'],
    ['6200', 'Transport', 'نقل', 'expense'], ['6300', 'Loyer', 'إيجار', 'expense'], ['6400', 'Salaires', 'أجور', 'expense'],
    ['6500', 'Coût des ventes', 'تكلفة المبيعات', 'expense'], ['6600', 'Perte de production', 'خسارة الإنتاج', 'expense'],
    ['6900', 'Autres charges', 'مصاريف أخرى', 'expense'],
  ];
  return db.transaction(async (tx) => {
    let n = 0;
    for (const [c, f, a, t] of rows) n += (await tx.run('INSERT OR IGNORE INTO accounts(code,name_fr,name_ar,type) VALUES (?,?,?,?)', [c, f, a, t])).changes;
    await audit(tx, { userId: user.id, action: 'seed_starter_chart', entity: 'account', details: { added: n } });
    return n;
  });
}

export async function setAccountRole(db, user, role, accountCode) {
  requirePermission(user, 'accounting', 'admin');
  if (!ROLES.includes(role)) throw new Error(`Unknown role ${role}`);
  return db.transaction(async (tx) => {
    if (!(await tx.get('SELECT 1 x FROM accounts WHERE code=? AND active=1', [accountCode]))) throw new Error('Unknown or inactive account');
    await tx.run('INSERT INTO account_roles(role,account_code) VALUES (?,?) ON CONFLICT(role) DO UPDATE SET account_code=excluded.account_code', [role, accountCode]);
    await audit(tx, { userId: user.id, action: 'set_role', entity: 'account_role', entityId: role, details: { accountCode } });
  });
}
export async function resolveRoles(db, roles) {
  const map = {}, missing = [];
  for (const r of roles) { const row = await db.get('SELECT account_code FROM account_roles WHERE role=?', [r]); if (row) map[r] = row.account_code; else missing.push(r); }
  return { map, missing };
}

export async function closePeriod(db, user, period) {
  requirePermission(user, 'accounting', 'admin');
  if (!/^\d{4}-\d{2}$/.test(period)) throw new Error('period must be YYYY-MM');
  return db.transaction(async (tx) => {
    await tx.run("INSERT INTO accounting_periods(period,status,closed_at) VALUES (?, 'closed', ?) ON CONFLICT(period) DO UPDATE SET status='closed', closed_at=excluded.closed_at", [period, nowIso()]);
    await audit(tx, { userId: user.id, action: 'close', entity: 'accounting_period', entityId: period });
  });
}

/**
 * Posts one balanced entry. MUST run inside db.transaction. Rejects: <2 lines, unknown/inactive accounts, amounts with
 * more than 2 decimals, lines with both sides, unbalanced totals, closed periods. A repeated (sourceType, sourceId) is a no-op.
 */
export async function postEntry(tx, user, { date, description, lines, sourceType = null, sourceId = null }) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date ?? '')) throw new Error('A valid date (YYYY-MM-DD) is required');
  if (!description?.trim()) throw new Error('A description is required');
  if (!lines || lines.length < 2) throw new Error('An entry needs at least two lines');
  if (sourceType && await tx.get('SELECT id, number FROM journal_entries WHERE source_type=? AND source_id=?', [sourceType, String(sourceId)]))
    return { duplicate: true };
  const period = date.slice(0, 7);
  if ((await tx.get('SELECT status FROM accounting_periods WHERE period=?', [period]))?.status === 'closed') throw new Error(`Accounting period ${period} is closed`);
  let dr = 0n, cr = 0n; const norm = [];
  for (const l of lines) {
    const d = D(l.debit ?? '0'), c = D(l.credit ?? '0');
    if (d.isNegative() || c.isNegative()) throw new Error('Debit/credit must not be negative');
    if (!d.round(2).eq(d) || !c.round(2).eq(c)) throw new Error('Amounts are limited to 2 decimals');
    if (d.gt(0) && c.gt(0)) throw new Error('A line cannot have both debit and credit');
    if (d.isZero() && c.isZero()) throw new Error('A line must have an amount');
    if (!(await tx.get('SELECT 1 x FROM accounts WHERE code=? AND active=1', [l.account]))) throw new Error(`Unknown or inactive account ${l.account}`);
    dr += d.u; cr += c.u; norm.push({ account: l.account, d, c, memo: l.memo ?? null });
  }
  if (dr !== cr) throw new Error(`Unbalanced entry: debits ${new Dec(dr)} != credits ${new Dec(cr)}`);
  const id = uid('je_'), number = await nextDocumentNumber(tx, 'journal', Number(date.slice(0, 4)));
  await tx.run('INSERT INTO journal_entries(id,number,entry_date,period,description,source_type,source_id,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?)',
    [id, number, date, period, description.trim(), sourceType, sourceId == null ? null : String(sourceId), user?.id ?? null, nowIso()]);
  let n = 0;
  for (const l of norm) await tx.run('INSERT INTO journal_lines(entry_id,line_no,account_code,debit_u,credit_u,memo) VALUES (?,?,?,?,?,?)', [id, ++n, l.account, l.d.u, l.c.u, l.memo]);
  await audit(tx, { userId: user?.id, action: 'post', entity: 'journal_entry', entityId: id, details: { number, source: sourceType } });
  return { duplicate: false, id, number };
}

export async function postManualEntry(db, user, e) {
  requirePermission(user, 'accounting', 'post');
  return db.transaction((tx) => postEntry(tx, user, e));
}

/** Correction by reversal: never edits the original. A reversal cannot itself be reversed or applied twice. */
export async function reverseEntry(tx, user, entryId, { date, reason }) {
  const e = await tx.get('SELECT * FROM journal_entries WHERE id=?', [entryId]);
  if (!e) throw new Error('Entry not found');
  if (e.source_type === 'reversal') throw new Error('A reversal entry cannot be reversed; post a correcting entry');
  if (await tx.get("SELECT 1 x FROM journal_entries WHERE source_type='reversal' AND source_id=?", [entryId])) throw new Error('Entry already reversed');
  const lines = await tx.all('SELECT * FROM journal_lines WHERE entry_id=? ORDER BY line_no', [entryId]);
  return postEntry(tx, user, { date: date ?? e.entry_date, description: `Reversal of ${e.number}${reason ? ': ' + reason : ''}`, sourceType: 'reversal', sourceId: entryId,
    lines: lines.map((l) => ({ account: l.account_code, debit: new Dec(BigInt(l.credit_u)), credit: new Dec(BigInt(l.debit_u)), memo: l.memo })) });
}
export async function reverseManualEntry(db, user, entryId, opts) {
  requirePermission(user, 'accounting', 'post');
  return db.transaction((tx) => reverseEntry(tx, user, entryId, opts));
}
/** Reverses the entry generated for a business document, if one exists and is not yet reversed. */
export async function reverseBySource(tx, user, sourceType, sourceId, { date, reason } = {}) {
  const e = await tx.get('SELECT id FROM journal_entries WHERE source_type=? AND source_id=?', [sourceType, String(sourceId)]);
  if (!e) return null;
  if (await tx.get("SELECT 1 x FROM journal_entries WHERE source_type='reversal' AND source_id=?", [e.id])) return null;
  return reverseEntry(tx, user, e.id, { date, reason });
}

// ---------- reports (management reports generated from posted entries; not official filings) ----------
async function sums(db, from, to) {
  return db.all(`SELECT a.code, a.name_fr, a.type, COALESCE(SUM(jl.debit_u),0) d, COALESCE(SUM(jl.credit_u),0) c
    FROM accounts a LEFT JOIN journal_lines jl ON jl.account_code=a.code
    LEFT JOIN journal_entries je ON je.id=jl.entry_id
    WHERE je.id IS NULL OR ((? IS NULL OR je.entry_date >= ?) AND (? IS NULL OR je.entry_date <= ?))
    GROUP BY a.code ORDER BY a.code`, [from ?? null, from ?? null, to ?? null, to ?? null]);
}
export async function trialBalance(db, { from = null, to = null } = {}) {
  const rows = (await sums(db, from, to)).map((r) => ({ code: r.code, name: r.name_fr, type: r.type, debit: new Dec(BigInt(r.d)), credit: new Dec(BigInt(r.c)) }))
    .filter((r) => !r.debit.isZero() || !r.credit.isZero());
  const debit = Dec.sum(rows.map((r) => r.debit)), credit = Dec.sum(rows.map((r) => r.credit));
  return { rows, debit, credit, balanced: debit.eq(credit) };
}
export async function incomeStatement(db, { from, to }) {
  const rows = await sums(db, from, to);
  const rev = rows.filter((r) => r.type === 'revenue').map((r) => ({ code: r.code, name: r.name_fr, amount: new Dec(BigInt(r.c) - BigInt(r.d)) }));
  const exp = rows.filter((r) => r.type === 'expense').map((r) => ({ code: r.code, name: r.name_fr, amount: new Dec(BigInt(r.d) - BigInt(r.c)) }));
  const revenue = Dec.sum(rev.map((r) => r.amount)), expenses = Dec.sum(exp.map((r) => r.amount));
  return { revenue: rev.filter((r) => !r.amount.isZero()), expenses: exp.filter((r) => !r.amount.isZero()), totalRevenue: revenue, totalExpenses: expenses, netResult: revenue.sub(expenses) };
}
export async function balanceSheet(db, { asOf }) {
  const rows = await sums(db, null, asOf);
  const bal = (type, sign) => rows.filter((r) => r.type === type).map((r) => ({ code: r.code, name: r.name_fr, amount: new Dec(sign * (BigInt(r.d) - BigInt(r.c))) })).filter((r) => !r.amount.isZero());
  const assets = bal('asset', 1n), liabilities = bal('liability', -1n), equity = bal('equity', -1n);
  const result = (await incomeStatement(db, { from: null, to: asOf })).netResult; // cumulative result not yet closed to equity
  const tA = Dec.sum(assets.map((r) => r.amount)), tL = Dec.sum(liabilities.map((r) => r.amount)), tE = Dec.sum(equity.map((r) => r.amount));
  return { asOf, assets, liabilities, equity, currentResult: result, totalAssets: tA, totalLiabilities: tL, totalEquity: tE.add(result), balanced: tA.eq(tL.add(tE).add(result)) };
}
export async function generalLedger(db, accountCode, { from = null, to = null } = {}) {
  const rows = await db.all(`SELECT je.entry_date, je.number, je.description, jl.debit_u, jl.credit_u FROM journal_lines jl JOIN journal_entries je ON je.id=jl.entry_id
    WHERE jl.account_code=? AND (? IS NULL OR je.entry_date>=?) AND (? IS NULL OR je.entry_date<=?) ORDER BY je.entry_date, je.number, jl.line_no`, [accountCode, from, from, to, to]);
  let run = 0n;
  return rows.map((r) => { run += BigInt(r.debit_u) - BigInt(r.credit_u); return { date: r.entry_date, number: r.number, description: r.description, debit: new Dec(BigInt(r.debit_u)), credit: new Dec(BigInt(r.credit_u)), runningBalance: new Dec(run) }; });
}
/** Integrity check: every entry must balance. Returns offending entry numbers (empty = healthy). */
export async function verifyLedgerIntegrity(db) {
  return (await db.all('SELECT je.number, SUM(jl.debit_u) d, SUM(jl.credit_u) c FROM journal_entries je JOIN journal_lines jl ON jl.entry_id=je.id GROUP BY je.id HAVING d <> c')).map((r) => r.number);
}
