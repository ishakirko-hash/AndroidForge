// Offline smart assistant: deterministic intent matching + the same services/ledger as the screens. No external AI, no writes.
import { D, Dec } from './decimal.js';
import { requirePermission } from './permissions.js';
import { lowStock } from './inventory.js';
import { availableStock } from './sales.js';
import { openInvoices, debtAging, invoiceOutstanding, customerBalance } from './receivables.js';
import { dueMaintenance } from './machines.js';
import { computeRequirements } from './bom.js';
import { stockValuation } from './inventory.js';
import { getThresholds } from './alerts.js';
import { addDays, today } from './dates.js';

const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f\u064B-\u065F]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ').trim();
const rx = (src) => new RegExp(norm(src));
const all = (...parts) => (t) => parts.every((p) => p.test(t));

const MUTATION_START = ['supprim', 'efface', 'paye ', 'payer', 'regle', 'annul', 'valid', 'poste', 'cree', 'creer', 'ajoute', 'modifi', 'delete', 'remove', 'pay ', 'cancel', 'post ', 'void', 'create', 'add ', 'edit', 'update', 'احذف', 'حذف', 'ادفع', 'سدد', 'الغ', 'رحل', 'انشي', 'اضف', 'عدل'];
const INTENTS = [
  ['production_today', all(rx('produi|production|produced|إنتاج|انتاج|انتجنا|أنتج'), rx("aujourd|today|اليوم"))],
  ['requirements_tomorrow', all(rx('besoin|requirement|need|احتياج|تحتاج|المواد'), rx('demain|tomorrow|غدا'))],
  ['overdue_invoices', all(rx('retard|overdue|متاخر|متأخر|مستحقه'), rx('factur|invoice|فاتور|فواتير'))],
  ['unpaid_invoices', rx('impaye|unpaid|غير مدفوع|غير مسدد|non regle|non payee')],
  ['customer_debt', all(rx('dette|creance|debt|receivable|outstanding|ديون|دين|مستحقات'), rx('client|customer|عميل|عملاء|زبون|زبائن'))],
  ['sales_month', all(rx('vente|sales|مبيعات'), rx('mois|month|شهر'))],
  ['expenses_month', all(rx('depense|expense|مصاريف|مصروفات'), rx('mois|month|شهر'))],
  ['orders_in_progress', all(rx('ordre|order|امر|اوامر|أوامر'), rx('cours|progress|قيد|جاري'), rx('production|إنتاج|انتاج'))],
  ['maintenance', rx('maintenance|صيانه|صيانة')],
  ['product_cost', all(rx('cout|cost|تكلفه|تكلفة'), rx('fabrication|manufactur|production|تصنيع|انتاج|إنتاج|produit|product|منتج|caisse|crate|صندوق'))],
  ['low_materials', all(rx('matiere|material|مواد|مادة|premiere'), rx('bas|faible|low|running|manque|ruptur|منخفض|ناقص|تنفد|تنفذ'))],
  ['products_available', all(rx('combien|how many|كم'), rx('caisse|crate|صندوق|stock|available|disponible|متوفر|متاح|مخزون'))],
];
export const SUPPORTED_QUESTIONS = INTENTS.map(([k]) => k);

const PERM = { production_today: 'production', requirements_tomorrow: 'production', overdue_invoices: 'invoices', unpaid_invoices: 'invoices', customer_debt: 'payments',
  sales_month: 'invoices', expenses_month: 'expenses', orders_in_progress: 'production', maintenance: 'machines', product_cost: 'production', low_materials: 'inventory', products_available: 'inventory' };

const monthRange = (d) => { const [y, m] = d.slice(0, 7).split('-').map(Number); return [`${d.slice(0, 7)}-01`, `${d.slice(0, 7)}-${String(new Date(Date.UTC(y, m, 0)).getUTCDate()).padStart(2, '0')}`]; };
const L = (lang, fr, ar) => (lang === 'ar' ? ar : fr);
const money = (d, lang) => `${d.format(lang)} DA`;

const HANDLERS = {
  async production_today(db, { asOf, lang }) {
    const orders = await db.all("SELECT number, accepted_qty a, rejected_qty r, total_qty t FROM production_orders WHERE status='completed' AND substr(finished_at,1,10)=?", [asOf]);
    const shifts = await db.all('SELECT produced_qty p, accepted_qty a, rejected_qty r FROM shift_records WHERE work_date=?', [asOf]);
    if (!orders.length && !shifts.length) return { insufficient: true, text: L(lang, `Aucune production enregistrée le ${asOf}. Saisissez les sorties de poste ou terminez un ordre de fabrication.`, `لا يوجد إنتاج مسجل بتاريخ ${asOf}. سجّل إنتاج الورديات أو أكمل أمر إنتاج.`) };
    const s = (rows, k) => Dec.sum(rows.map((r) => D(r[k])));
    const data = { completedOrders: { count: orders.length, accepted: s(orders, 'a'), rejected: s(orders, 'r') }, shiftOutput: { records: shifts.length, produced: s(shifts, 'p'), accepted: s(shifts, 'a'), rejected: s(shifts, 'r') } };
    return { data, basis: L(lang, 'Deux sources séparées, non additionnées (évite le double comptage) : ordres terminés ce jour (date de fin) et sorties de poste enregistrées ce jour.', 'مصدران منفصلان غير مجموعين (لتفادي العد المزدوج): أوامر مكتملة اليوم وإنتاج الورديات المسجل اليوم.'),
      text: L(lang, `Le ${asOf} : ordres terminés = ${orders.length} (acceptés ${data.completedOrders.accepted}, rejetés ${data.completedOrders.rejected}) ; sorties de poste = ${data.shiftOutput.produced} produites (${data.shiftOutput.accepted} acceptées).`,
        `بتاريخ ${asOf}: الأوامر المكتملة = ${orders.length} (مقبول ${data.completedOrders.accepted}، مرفوض ${data.completedOrders.rejected}) ؛ إنتاج الورديات = ${data.shiftOutput.produced} (مقبول ${data.shiftOutput.accepted}).`) };
  },
  async products_available(db, { lang }) {
    const rows = [];
    for (const p of await db.all("SELECT id, ref, name_fr FROM products WHERE status='active' ORDER BY ref")) rows.push({ ref: p.ref, name: p.name_fr, ...(await availableStock(db, p.id)) });
    if (!rows.length) return { insufficient: true, text: L(lang, 'Aucun produit actif. Créez d’abord le catalogue produits.', 'لا توجد منتجات نشطة. أنشئ كتالوج المنتجات أولاً.') };
    return { data: rows, basis: L(lang, 'Disponible = stock physique (grand livre des mouvements) − quantités réservées par les commandes confirmées non livrées.', 'المتاح = المخزون الفعلي (سجل الحركات) − الكميات المحجوزة للطلبيات المؤكدة غير المسلَّمة.'),
      text: rows.map((r) => L(lang, `${r.ref} ${r.name} : ${r.physical} en stock, ${r.reserved} réservé, ${r.available} disponible`, `${r.ref} ${r.name}: ${r.physical} فعلي، ${r.reserved} محجوز، ${r.available} متاح`)).join('\n') };
  },
  async low_materials(db, { lang }) {
    const rows = (await lowStock(db)).filter((l) => l.type === 'material');
    return { data: rows.map((r) => ({ ref: r.ref, balance: r.balance, min: r.min })), basis: L(lang, 'Stock ≤ seuil minimum configuré pour la matière.', 'المخزون ≤ الحد الأدنى المضبوط للمادة.'),
      text: rows.length ? rows.map((r) => L(lang, `${r.ref} : ${r.balance} (minimum ${r.min})`, `${r.ref}: ${r.balance} (الحد الأدنى ${r.min})`)).join('\n') : L(lang, 'Aucune matière sous son seuil minimum (seuils non configurés = ignorés).', 'لا توجد مادة تحت حدها الأدنى (الحدود غير المضبوطة تُتجاهل).') };
  },
  async overdue_invoices(db, { asOf, lang }) {
    const rows = [];
    for (const i of await db.all("SELECT id, number, due_date FROM invoices WHERE status='issued' AND due_date < ? ORDER BY due_date", [asOf])) { const o = await invoiceOutstanding(db, i.id); if (o.gt(0)) rows.push({ number: i.number, dueDate: i.due_date, outstanding: o }); }
    const total = Dec.sum(rows.map((r) => r.outstanding));
    return { data: { rows, total }, basis: L(lang, `Reste dû = total − règlements valides affectés − avoirs ; en retard si échéance < ${asOf}.`, `المتبقي = الإجمالي − الدفعات الصحيحة الموزعة − الإشعارات الدائنة ؛ متأخرة إن كان الاستحقاق قبل ${asOf}.`),
      text: rows.length ? L(lang, `${rows.length} facture(s) en retard, total ${money(total, lang)} :\n`, `${rows.length} فاتورة متأخرة، المجموع ${money(total, lang)}:\n`) + rows.map((r) => `${r.number} — ${money(r.outstanding, lang)} (${r.dueDate})`).join('\n') : L(lang, 'Aucune facture en retard.', 'لا توجد فواتير متأخرة.') };
  },
  async unpaid_invoices(db, { lang }) {
    const rows = [];
    for (const c of await db.all('SELECT id, name FROM customers')) for (const i of await openInvoices(db, c.id)) rows.push({ number: i.number, customer: c.name, outstanding: i.outstanding });
    const total = Dec.sum(rows.map((r) => r.outstanding));
    return { data: { rows, total }, basis: L(lang, 'Factures émises non annulées avec reste dû > 0.', 'فواتير صادرة غير ملغاة بمتبقٍ أكبر من صفر.'),
      text: rows.length ? L(lang, `${rows.length} facture(s) impayée(s), total ${money(total, lang)} :\n`, `${rows.length} فاتورة غير مسددة، المجموع ${money(total, lang)}:\n`) + rows.map((r) => `${r.number} ${r.customer} — ${money(r.outstanding, lang)}`).join('\n') : L(lang, 'Aucune facture impayée.', 'لا توجد فواتير غير مسددة.') };
  },
  async customer_debt(db, { asOf, lang }) {
    const a = await debtAging(db, { asOf });
    let credit = Dec.zero(); for (const c of await db.all('SELECT id FROM customers')) credit = credit.add((await customerBalance(db, c.id)).unallocated);
    return { data: { outstanding: a.outstanding, overdue: a.overdue, buckets: a.buckets, unallocatedCredit: credit }, basis: a.basis,
      text: L(lang, `Créances clients au ${asOf} : ${money(a.outstanding, lang)} dont ${money(a.overdue, lang)} en retard. Règlements non affectés (avances clients) : ${money(credit, lang)}.`, `ذمم العملاء بتاريخ ${asOf}: ${money(a.outstanding, lang)} منها ${money(a.overdue, lang)} متأخرة. دفعات غير موزعة (دفعات مقدمة): ${money(credit, lang)}.`) };
  },
  async sales_month(db, { asOf, lang }) {
    const [from, to] = monthRange(asOf);
    const inv = await db.all("SELECT subtotal_ht h, tax_total t, total_ttc g FROM invoices WHERE status='issued' AND issue_date>=? AND issue_date<=?", [from, to]);
    if (!inv.length) return { insufficient: true, text: L(lang, `Aucune facture émise entre ${from} et ${to}.`, `لا توجد فواتير صادرة بين ${from} و${to}.`) };
    const cn = Dec.sum((await db.all('SELECT total_ttc a FROM credit_notes WHERE issue_date>=? AND issue_date<=?', [from, to])).map((r) => D(r.a)));
    const ht = Dec.sum(inv.map((r) => D(r.h))), ttc = Dec.sum(inv.map((r) => D(r.g)));
    return { data: { from, to, invoices: inv.length, totalHt: ht, totalTtc: ttc, creditNotesTtc: cn }, basis: L(lang, 'Factures émises non annulées du mois ; devis et commandes non comptés ; avoirs indiqués séparément (TTC).', 'فواتير الشهر الصادرة غير الملغاة ؛ عروض الأسعار والطلبيات غير محتسبة ؛ الإشعارات الدائنة منفصلة (شامل الضريبة).'),
      text: L(lang, `Ventes du ${from} au ${to} : ${inv.length} facture(s), ${money(ht, lang)} HT / ${money(ttc, lang)} TTC. Avoirs du mois : ${money(cn, lang)} TTC.`, `مبيعات ${from} إلى ${to}: ${inv.length} فاتورة، ${money(ht, lang)} دون ضريبة / ${money(ttc, lang)} شامل. إشعارات دائنة: ${money(cn, lang)}.`) };
  },
  async expenses_month(db, { asOf, lang }) {
    const [from, to] = monthRange(asOf);
    const rows = await db.all("SELECT category_code c, amount a FROM expenses WHERE status='valid' AND exp_date>=? AND exp_date<=?", [from, to]);
    if (!rows.length) return { insufficient: true, text: L(lang, `Aucune dépense enregistrée entre ${from} et ${to}.`, `لا توجد مصاريف مسجلة بين ${from} و${to}.`) };
    const m = new Map(); for (const r of rows) m.set(r.c, (m.get(r.c) ?? Dec.zero()).add(r.a));
    const total = Dec.sum([...m.values()]);
    return { data: { from, to, total, byCategory: [...m].map(([category, t]) => ({ category, total: t })) }, basis: L(lang, 'Dépenses valides (non annulées) enregistrées du mois ; encaissements/virements exclus.', 'مصاريف الشهر الصحيحة (غير الملغاة) ؛ التحصيلات والتحويلات مستثناة.'),
      text: L(lang, `Dépenses du ${from} au ${to} : ${money(total, lang)}\n`, `مصاريف ${from} إلى ${to}: ${money(total, lang)}\n`) + [...m].map(([c, t]) => `${c} : ${money(t, lang)}`).join('\n') };
  },
  async orders_in_progress(db, { lang }) {
    const rows = await db.all("SELECT po.number, p.ref, po.planned_qty, po.status FROM production_orders po JOIN products p ON p.id=po.product_id WHERE po.status IN ('planned','in_progress') ORDER BY po.number");
    return { data: rows, basis: L(lang, 'Ordres au statut « planifié » ou « en cours ».', 'أوامر بحالة «مخطط» أو «قيد التنفيذ».'),
      text: rows.length ? rows.map((r) => `${r.number} ${r.ref} × ${r.planned_qty} (${r.status})`).join('\n') : L(lang, 'Aucun ordre planifié ou en cours.', 'لا توجد أوامر مخططة أو قيد التنفيذ.') };
  },
  async maintenance(db, { asOf, lang }) {
    const th = await getThresholds(db), rows = await dueMaintenance(db, { asOf, withinDays: Number(th.maintenanceDays) });
    return { data: rows, basis: L(lang, `Échéance = dernière réalisation (ou date de début) + intervalle du plan ; fenêtre ${th.maintenanceDays} jours.`, `الاستحقاق = آخر تنفيذ (أو تاريخ البدء) + فترة الخطة ؛ النافذة ${th.maintenanceDays} أيام.`),
      text: rows.length ? rows.map((r) => `${r.machineRef} — ${r.task} : ${r.dueDate} ${r.overdue ? L(lang, '(EN RETARD)', '(متأخرة)') : ''}`).join('\n') : L(lang, 'Aucune maintenance due dans la fenêtre (ou aucun plan configuré).', 'لا صيانة مستحقة ضمن النافذة (أو لا توجد خطط).') };
  },
  async requirements_tomorrow(db, { asOf, lang }) {
    const date = addDays(asOf, 1);
    const orders = await db.all("SELECT id, number, recipe_id, planned_qty FROM production_orders WHERE planned_date=? AND status IN ('draft','planned','in_progress')", [date]);
    if (!orders.length) return { insufficient: true, text: L(lang, `Aucun ordre de fabrication n’est prévu le ${date}. Créez un ordre avec cette date prévue pour calculer les besoins.`, `لا يوجد أمر إنتاج مجدول بتاريخ ${date}. أنشئ أمراً بهذا التاريخ لحساب الاحتياجات.`) };
    const need = new Map();
    for (const o of orders) for (const l of (await computeRequirements(db, o.recipe_id, o.planned_qty)).lines) { const e = need.get(l.materialId) ?? { ref: l.ref, unit: l.unit, required: Dec.zero(), available: l.available }; e.required = e.required.add(l.required); need.set(l.materialId, e); }
    const rows = [...need.values()].map((e) => ({ ref: e.ref, unit: e.unit, required: e.required, available: e.available, shortage: e.required.gt(e.available) ? e.required.sub(e.available) : Dec.zero() }));
    return { data: { date, orders: orders.map((o) => o.number), rows }, basis: L(lang, 'Besoins théoriques = quantité/unité × quantité planifiée × (1 + perte %), comparés au stock physique.', 'الاحتياج النظري = الكمية/وحدة × الكمية المخططة × (1 + الفقد %) مقارنة بالمخزون الفعلي.'),
      text: L(lang, `Besoins pour le ${date} (${orders.map((o) => o.number).join(', ')}) :\n`, `احتياجات ${date} (${orders.map((o) => o.number).join('، ')}):\n`) + rows.map((r) => `${r.ref} : ${r.required} ${r.unit} / ${L(lang, 'dispo', 'متاح')} ${r.available}${r.shortage.gt(0) ? L(lang, ` → manque ${r.shortage}`, ` ← نقص ${r.shortage}`) : ''}`).join('\n') };
  },
  async product_cost(db, { text, lang }) {
    const products = await db.all("SELECT id, ref, name_fr FROM products WHERE status='active'");
    const p = products.find((x) => text.includes(norm(x.ref)) || text.includes(norm(x.name_fr)));
    if (!p) return { clarify: true, text: L(lang, 'De quel produit parlez-vous ? Indiquez sa référence ou son nom.', 'عن أي منتج تتحدث؟ اذكر مرجعه أو اسمه.') };
    const last = await db.get("SELECT number, unit_cost, cost_complete FROM production_orders WHERE product_id=? AND status='completed' AND unit_cost IS NOT NULL ORDER BY finished_at DESC LIMIT 1", [p.id]);
    if (last) return { data: { product: p.ref, order: last.number, unitMaterialCost: D(last.unit_cost), kind: 'recorded' }, basis: L(lang, 'Coût MATIÈRE enregistré du dernier ordre terminé (consommation au coût moyen pondéré ÷ quantité acceptée). Main-d’œuvre et frais généraux non répartis.', 'تكلفة المواد المسجلة لآخر أمر مكتمل (الاستهلاك بالمتوسط المرجح ÷ الكمية المقبولة). الأجور والتكاليف العامة غير موزعة.'),
      text: L(lang, `${p.ref} : coût matière enregistré ${money(D(last.unit_cost), lang)} / unité (ordre ${last.number}).`, `${p.ref}: تكلفة المواد المسجلة ${money(D(last.unit_cost), lang)} للوحدة (الأمر ${last.number}).`) };
    const rc = await db.get('SELECT id FROM recipes WHERE product_id=? ORDER BY version DESC LIMIT 1', [p.id]);
    if (!rc) return { insufficient: true, text: L(lang, `Aucune recette ni production terminée pour ${p.ref} : coût impossible à estimer.`, `لا وصفة ولا إنتاج مكتمل للمنتج ${p.ref}: لا يمكن تقدير التكلفة.`) };
    const req = await computeRequirements(db, rc.id, '1'), val = await stockValuation(db);
    let total = Dec.zero(); const miss = [];
    for (const l of req.lines) { const avg = val.items.find((i) => i.id === l.materialId)?.avgCost; if (avg) total = total.add(l.required.mul(avg)); else miss.push(l.ref); }
    if (miss.length) return { insufficient: true, text: L(lang, `Estimation impossible : coût inconnu pour ${miss.join(', ')} (enregistrez une réception avec prix).`, `التقدير غير ممكن: تكلفة غير معروفة للمواد ${miss.join('، ')} (سجّل استلاماً بسعر).`) };
    return { data: { product: p.ref, estimate: total, kind: 'estimate' }, basis: L(lang, 'ESTIMATION : recette actuelle × coût moyen pondéré en stock.', 'تقدير: الوصفة الحالية × متوسط تكلفة المخزون المرجح.'), text: L(lang, `${p.ref} : coût matière estimé ${money(total, lang)} / unité (estimation, aucune production terminée).`, `${p.ref}: تكلفة مواد مقدّرة ${money(total, lang)} للوحدة (تقدير، لا إنتاج مكتمل).`) };
  },
};

/** Answers one question. Read-only: any request to change data is refused (changes go through confirmed screens). */
export async function ask(db, user, question, { asOf = today(), lang = 'fr' } = {}) {
  requirePermission(user, 'assistant', 'read');
  const t = norm(question ?? '');
  if (!t) return { intent: null, text: L(lang, 'Posez une question.', 'اطرح سؤالاً.') };
  if (MUTATION_START.some((w) => t.startsWith(norm(w)))) return { intent: 'refused', text: L(lang, 'L’assistant est en lecture seule : il ne paie, ne supprime et ne comptabilise rien. Utilisez l’écran concerné (avec confirmation).', 'المساعد للقراءة فقط: لا يدفع ولا يحذف ولا يرحّل. استخدم الشاشة المعنية (مع التأكيد).') };
  const hit = INTENTS.find(([, test]) => (typeof test === "function" ? test(t) : test.test(t)));
  if (!hit) return { intent: null, supported: SUPPORTED_QUESTIONS, text: L(lang, 'Je ne comprends pas cette question. Exemples : « Production d’aujourd’hui ? », « Factures en retard ? », « Dettes clients ? ».', 'لم أفهم السؤال. أمثلة: «إنتاج اليوم؟» ، «الفواتير المتأخرة؟» ، «ديون العملاء؟».') };
  requirePermission(user, PERM[hit[0]], 'read');
  const r = await HANDLERS[hit[0]](db, { asOf, lang, text: t });
  return { intent: hit[0], asOf, ...r };
}
