import { can } from './permissions.js';

const ESC = (q) => q.replace(/[\\%_]/g, (c) => '\\' + c);
// Each source is only searched when the user's role may read that module.
const SOURCES = [
  { type: 'product', perm: 'products', sql: "SELECT id, ref label, name_fr sub FROM products WHERE ref LIKE ?1 ESCAPE '\\' OR name_fr LIKE ?1 ESCAPE '\\' OR name_ar LIKE ?1 ESCAPE '\\'" },
  { type: 'material', perm: 'materials', sql: "SELECT id, ref label, name sub FROM materials WHERE ref LIKE ?1 ESCAPE '\\' OR name LIKE ?1 ESCAPE '\\'" },
  { type: 'customer', perm: 'customers', sql: "SELECT id, ref label, name sub FROM customers WHERE ref LIKE ?1 ESCAPE '\\' OR name LIKE ?1 ESCAPE '\\' OR phone LIKE ?1 ESCAPE '\\' OR nif LIKE ?1 ESCAPE '\\'" },
  { type: 'supplier', perm: 'suppliers', sql: "SELECT id, ref label, name sub FROM suppliers WHERE ref LIKE ?1 ESCAPE '\\' OR name LIKE ?1 ESCAPE '\\' OR phone LIKE ?1 ESCAPE '\\'" },
  { type: 'invoice', perm: 'invoices', sql: "SELECT i.id, i.number label, c.name sub FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.number LIKE ?1 ESCAPE '\\' OR c.name LIKE ?1 ESCAPE '\\'" },
  { type: 'delivery_note', perm: 'sales', sql: "SELECT d.id, d.number label, c.name sub FROM delivery_notes d JOIN customers c ON c.id=d.customer_id WHERE d.number LIKE ?1 ESCAPE '\\'" },
  { type: 'production_order', perm: 'production', sql: "SELECT po.id, po.number label, p.ref sub FROM production_orders po JOIN products p ON p.id=po.product_id WHERE po.number LIKE ?1 ESCAPE '\\' OR p.ref LIKE ?1 ESCAPE '\\'" },
  { type: 'purchase_order', perm: 'purchases', sql: "SELECT po.id, po.number label, s.name sub FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id WHERE po.number LIKE ?1 ESCAPE '\\' OR s.name LIKE ?1 ESCAPE '\\'" },
  { type: 'payment', perm: 'payments', sql: "SELECT id, number label, reference sub FROM payments WHERE number LIKE ?1 ESCAPE '\\' OR reference LIKE ?1 ESCAPE '\\'" },
  { type: 'expense', perm: 'expenses', sql: "SELECT id, number label, description sub FROM expenses WHERE number LIKE ?1 ESCAPE '\\' OR description LIKE ?1 ESCAPE '\\' OR reference LIKE ?1 ESCAPE '\\'" },
  { type: 'employee', perm: 'employees', sql: "SELECT id, ref label, name sub FROM employees WHERE ref LIKE ?1 ESCAPE '\\' OR name LIKE ?1 ESCAPE '\\'" },
  { type: 'machine', perm: 'machines', sql: "SELECT id, ref label, name sub FROM machines WHERE ref LIKE ?1 ESCAPE '\\' OR name LIKE ?1 ESCAPE '\\'" },
];
export async function globalSearch(db, user, query, { limit = 8 } = {}) {
  const q = (query ?? '').trim();
  if (q.length < 2) return [];
  const out = [];
  for (const s of SOURCES) {
    if (!user?.role || !can(user.role, s.perm, 'read')) continue;
    for (const r of await db.all(`${s.sql} LIMIT ${Number(limit)}`, [`%${ESC(q)}%`])) out.push({ type: s.type, id: r.id, label: r.label, sub: r.sub ?? '' });
  }
  return out;
}
