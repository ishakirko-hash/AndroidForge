// Role/permission matrix, enforced in business logic (services call requirePermission), not only in the UI.
export const MODULES = ['dashboard', 'production', 'products', 'materials', 'inventory', 'sales', 'customers', 'invoices',
  'payments', 'purchases', 'suppliers', 'expenses', 'accounting', 'employees', 'machines', 'quality', 'reports',
  'assistant', 'settings', 'backup', 'audit'];
// actions: read < write < post (validate/issue/complete) < admin (configure/restore)
const ALL = (...a) => Object.fromEntries(MODULES.map((m) => [m, a]));
const only = (map, base = []) => ({ ...Object.fromEntries(MODULES.map((m) => [m, base])), ...map });
const R = ['read'], RW = ['read', 'write'], RWP = ['read', 'write', 'post'];

export const MATRIX = {
  admin: ALL('read', 'write', 'post', 'admin'),
  manager: { ...ALL('read', 'write', 'post'), settings: R, backup: R },
  accountant: only({ accounting: RWP, invoices: RWP, payments: RWP, purchases: RWP, suppliers: RWP, expenses: RWP,
    customers: RW, reports: RWP, assistant: R, audit: R, dashboard: R, backup: R }, R),
  sales: only({ sales: RWP, customers: RW, invoices: RWP, payments: RW, dashboard: R, assistant: R, products: R, inventory: R }),
  warehouse: only({ inventory: RWP, materials: RW, products: R, purchases: RW, dashboard: R, assistant: R }),
  prod_supervisor: only({ production: RWP, quality: RWP, machines: RWP, inventory: R, products: R, materials: R,
    employees: RW, dashboard: R, assistant: R, reports: R }),
  prod_operator: only({ production: RW, quality: RW, machines: R, dashboard: R }),
  auditor: only({ audit: R, reports: R, dashboard: R, accounting: R, invoices: R, payments: R, inventory: R, production: R,
    sales: R, purchases: R, expenses: R, customers: R, suppliers: R, products: R, materials: R, machines: R, quality: R,
    employees: R }),
};
// Empty-array entries mean "no access".
export class PermissionError extends Error {
  constructor(role, module, action) { super(`Role "${role}" may not ${action} ${module}`); this.name = 'PermissionError'; }
}
export function can(role, module, action) {
  const m = MATRIX[role]?.[module];
  return !!m && m.includes(action);
}
export function requirePermission(user, module, action) {
  if (!user || !user.role || !can(user.role, module, action)) throw new PermissionError(user?.role ?? 'none', module, action);
}
