import { D, Dec, convertMass } from './decimal.js';
import { getBalance } from './inventory.js';

/** Quantity expressed in the material's own unit; only mass units (g/kg/t) convert. */
function toUnit(qty, from, to) {
  if (from === to) return qty;
  return convertMass(qty, from, to);
}

/**
 * Theoretical requirements for a planned quantity: qtyPerUnit x planned x (1 + loss%/100), in each material's stock unit.
 * Result values are CALCULATED (theoretical), not measured.
 */
export async function computeRequirements(db, recipeId, plannedQty) {
  const planned = D(plannedQty);
  if (!planned.gt(0)) throw new Error('Planned quantity must be greater than zero');
  const lines = await db.all(`SELECT rl.material_id, rl.qty_per_unit, rl.unit AS recipe_unit, rl.loss_pct, m.unit AS stock_unit, m.ref, m.name, m.purchase_cost
    FROM recipe_lines rl JOIN materials m ON m.id = rl.material_id WHERE rl.recipe_id=? ORDER BY m.ref`, [recipeId]);
  if (!lines.length) throw new Error('Recipe has no lines');
  const out = [];
  for (const l of lines) {
    const base = D(l.qty_per_unit).mul(planned);
    const withLoss = base.mul(D('1').add(D(l.loss_pct).div('100')));
    const required = toUnit(withLoss, l.recipe_unit, l.stock_unit);
    const available = await getBalance(db, 'material', l.material_id);
    const shortage = required.gt(available) ? required.sub(available) : Dec.zero();
    // cost basis: configured purchase cost, else the stock's weighted-average cost when known (never invented)
    let unitCost = l.purchase_cost;
    if (unitCost == null) { const v = await db.get('SELECT COALESCE(SUM(qty_u),0) q, COALESCE(SUM(value_u),0) v FROM stock_movements WHERE item_type=\'material\' AND item_id=?', [l.material_id]); if (BigInt(v.q) > 0n && BigInt(v.v) > 0n) unitCost = new Dec(BigInt(v.v)).div(new Dec(BigInt(v.q))); }
    out.push({ materialId: l.material_id, ref: l.ref, name: l.name, unit: l.stock_unit, required, available, shortage,
      estimatedCost: unitCost == null ? null : required.mul(unitCost), // ESTIMATE: purchase cost or average stock cost
    });
  }
  const costs = out.map((o) => o.estimatedCost);
  return { lines: out, hasShortage: out.some((o) => o.shortage.gt(0)),
    estimatedMaterialCost: costs.every((c) => c !== null) ? Dec.sum(costs) : null, // null = cost data missing; never guessed
    basis: 'theoretical: qty/unit x planned x (1+loss%); cost = purchase cost, else weighted-average stock cost' };
}
