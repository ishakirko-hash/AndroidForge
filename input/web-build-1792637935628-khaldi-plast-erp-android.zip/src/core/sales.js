import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nextDocumentNumber } from './sequences.js';
import { recordMovement, getBalance } from './inventory.js';
import { uid, nowIso } from './ids.js';
import { today } from './dates.js';
import { autoPost } from './postings.js';

/** Quotations/drafts never reserve or move stock. Lines are validated; prices are the agreed order prices. */
export async function createSalesOrder(db, user, { customerId, lines, orderDate, notes }) {
  requirePermission(user, 'sales', 'write');
  if (!lines?.length) throw new Error('An order needs at least one line');
  return db.transaction(async (tx) => {
    const c = await tx.get('SELECT active FROM customers WHERE id=?', [customerId]);
    if (!c || !c.active) throw new Error('Unknown or inactive customer');
    const id = uid('so_'), number = await nextDocumentNumber(tx, 'sales_order', new Date().getFullYear());
    await tx.run('INSERT INTO sales_orders(id,number,customer_id,order_date,notes,created_at) VALUES (?,?,?,?,?,?)',
      [id, number, customerId, orderDate ?? today(), notes ?? null, nowIso()]);
    let n = 0;
    for (const l of lines) {
      if (!D(l.qty).gt(0)) throw new Error('Quantity must be greater than zero');
      if (D(l.unitPrice).isNegative()) throw new Error('Price must not be negative');
      const disc = D(l.discountPct ?? '0'); if (disc.isNegative() || disc.gt(100)) throw new Error('Discount must be 0..100');
      if (!(await tx.get("SELECT 1 x FROM products WHERE id=? AND status='active'", [l.productId]))) throw new Error('Unknown or archived product');
      await tx.run('INSERT INTO sales_order_lines(order_id,line_no,product_id,qty,unit_price,discount_pct) VALUES (?,?,?,?,?,?)',
        [id, ++n, l.productId, D(l.qty).toString(), D(l.unitPrice).toString(), disc.toString()]);
    }
    await audit(tx, { userId: user.id, action: 'create', entity: 'sales_order', entityId: id, details: { number } });
    return { id, number };
  });
}

export async function confirmSalesOrder(db, user, id) {
  requirePermission(user, 'sales', 'post');
  return db.transaction(async (tx) => {
    const r = await tx.run("UPDATE sales_orders SET status='confirmed' WHERE id=? AND status='draft'", [id]);
    if (!r.changes) throw new Error('Only a draft order can be confirmed');
    await audit(tx, { userId: user.id, action: 'confirm', entity: 'sales_order', entityId: id });
  });
}

export async function cancelSalesOrder(db, user, id) {
  requirePermission(user, 'sales', 'post');
  return db.transaction(async (tx) => {
    const o = await tx.get('SELECT status FROM sales_orders WHERE id=?', [id]);
    if (!o) throw new Error('Order not found');
    if (!['draft', 'confirmed'].includes(o.status)) throw new Error(`Cannot cancel an order in status ${o.status}`);
    await tx.run("UPDATE sales_orders SET status='cancelled' WHERE id=?", [id]);
    await audit(tx, { userId: user.id, action: 'cancel', entity: 'sales_order', entityId: id });
  });
}

export async function orderProgress(db, orderId) {
  const lines = await db.all('SELECT line_no, product_id, qty FROM sales_order_lines WHERE order_id=? ORDER BY line_no', [orderId]);
  const out = [];
  for (const l of lines) {
    const rows = await db.all('SELECT qty FROM delivery_lines WHERE order_id=? AND line_no=?', [orderId, l.line_no]);
    const delivered = Dec.sum(rows.map((r) => D(r.qty)));
    out.push({ lineNo: l.line_no, productId: l.product_id, ordered: D(l.qty), delivered, remaining: D(l.qty).sub(delivered) });
  }
  return out;
}

/**
 * Validated dispatch: creates the delivery note AND deducts finished-goods stock in ONE transaction.
 * Over-delivery and insufficient stock are rejected; stock leaves exactly once (event key per note line).
 */
export async function dispatchDelivery(db, user, orderId, { lines, deliveryDate, notes }) {
  requirePermission(user, 'sales', 'post');
  if (!lines?.length) throw new Error('Nothing to deliver');
  return db.transaction(async (tx) => {
    const o = await tx.get('SELECT * FROM sales_orders WHERE id=?', [orderId]);
    if (!o) throw new Error('Order not found');
    if (!['confirmed', 'partially_delivered'].includes(o.status)) throw new Error(`Cannot deliver an order in status ${o.status}`);
    const prog = await orderProgress(tx, orderId);
    const id = uid('dn_'), number = await nextDocumentNumber(tx, 'delivery_note', new Date().getFullYear());
    await tx.run('INSERT INTO delivery_notes(id,number,order_id,customer_id,delivery_date,notes,created_at) VALUES (?,?,?,?,?,?,?)',
      [id, number, orderId, o.customer_id, deliveryDate ?? today(), notes ?? null, nowIso()]);
    const seen = new Set();
    for (const l of lines) {
      const p = prog.find((x) => x.lineNo === l.lineNo);
      if (!p) throw new Error(`Unknown order line ${l.lineNo}`);
      if (seen.has(l.lineNo)) throw new Error('Duplicate line in delivery');
      seen.add(l.lineNo);
      const q = D(l.qty);
      if (!q.gt(0)) throw new Error('Delivered quantity must be greater than zero');
      if (q.gt(p.remaining)) throw new Error(`Over-delivery on line ${l.lineNo}: remaining ${p.remaining}, requested ${q}`);
      await tx.run('INSERT INTO delivery_lines(note_id,order_id,line_no,product_id,qty) VALUES (?,?,?,?,?)', [id, orderId, l.lineNo, p.productId, q.toString()]);
      await recordMovement(tx, user, { type: 'dispatch', itemType: 'product', itemId: p.productId, qty: q, eventKey: `dn:${id}:${l.lineNo}`, sourceDoc: number });
    }
    const after = await orderProgress(tx, orderId);
    const done = after.every((x) => x.remaining.isZero());
    await tx.run('UPDATE sales_orders SET status=? WHERE id=?', [done ? 'delivered' : 'partially_delivered', orderId]);
    await audit(tx, { userId: user.id, action: 'dispatch', entity: 'delivery_note', entityId: id, details: { number, orderId } });
    const posting = await autoPost(tx, user, 'delivery_note', id);
    return { id, number, orderStatus: done ? 'delivered' : 'partially_delivered', posting };
  });
}

/** Reserved = still-undelivered quantity on confirmed/partially delivered orders. Available = physical - reserved. */
export async function reservedQty(db, productId) {
  const orders = await db.all("SELECT id FROM sales_orders WHERE status IN ('confirmed','partially_delivered')");
  let total = Dec.zero();
  for (const o of orders) for (const p of await orderProgress(db, o.id)) if (p.productId === productId) total = total.add(p.remaining);
  return total;
}
export async function availableStock(db, productId) {
  const physical = await getBalance(db, 'product', productId);
  const reserved = await reservedQty(db, productId);
  return { physical, reserved, available: physical.sub(reserved) };
}
