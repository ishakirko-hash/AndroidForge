import { D } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { uid, nowIso } from './ids.js';

const need = (v, n) => { if (v == null || String(v).trim() === '') throw new Error(`${n} is required`); return String(v).trim(); };

/** Tax rates are configuration (versioned by code); the app ships NO default rate. Verify with your accountant. */
export async function setTaxRate(db, user, { code, label, ratePct, active = true }) {
  requirePermission(user, 'settings', 'admin');
  const r = D(ratePct);
  if (r.isNegative() || r.gt(100)) throw new Error('Tax rate must be between 0 and 100');
  return db.transaction(async (tx) => {
    await tx.run(`INSERT INTO tax_rates(code,label,rate_pct,active,created_at) VALUES (?,?,?,?,?)
      ON CONFLICT(code) DO UPDATE SET label=excluded.label, rate_pct=excluded.rate_pct, active=excluded.active`,
      [need(code, 'code'), need(label, 'label'), r.toString(), active ? 1 : 0, nowIso()]);
    await audit(tx, { userId: user.id, action: 'set', entity: 'tax_rate', entityId: code, details: { ratePct: r.toString(), active } });
  });
}

export async function createCustomer(db, user, c) {
  requirePermission(user, 'customers', 'write');
  const ref = need(c.ref, 'ref'), name = need(c.name, 'name');
  const limit = D(c.credit_limit ?? '0'); if (limit.isNegative()) throw new Error('credit_limit must not be negative');
  const terms = c.payment_terms_days ?? 30; if (!Number.isInteger(terms) || terms < 0) throw new Error('Invalid payment terms');
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM customers WHERE ref=?', [ref])) throw new Error(`Duplicate customer reference: ${ref}`);
    // soft duplicate guard: same NIF (when provided) is almost certainly the same company
    if (c.nif && await tx.get('SELECT 1 x FROM customers WHERE nif=?', [c.nif])) throw new Error(`A customer with NIF ${c.nif} already exists`);
    const id = uid('cus_');
    await tx.run(`INSERT INTO customers(id,ref,name,phone,email,address,wilaya,commune,nif,nis,rc,category,credit_limit,payment_terms_days,notes,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [id, ref, name, c.phone ?? null, c.email ?? null, c.address ?? null, c.wilaya ?? null,
      c.commune ?? null, c.nif ?? null, c.nis ?? null, c.rc ?? null, c.category ?? null, limit.toString(), terms, c.notes ?? null, nowIso()]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'customer', entityId: id, details: { ref } });
    return id;
  });
}

export async function createSupplier(db, user, s) {
  requirePermission(user, 'suppliers', 'write');
  const ref = need(s.ref, 'ref'), name = need(s.name, 'name');
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM suppliers WHERE ref=?', [ref])) throw new Error(`Duplicate supplier reference: ${ref}`);
    const id = uid('sup_');
    await tx.run(`INSERT INTO suppliers(id,ref,name,phone,email,address,wilaya,nif,nis,rc,payment_terms_days,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [id, ref, name, s.phone ?? null, s.email ?? null, s.address ?? null, s.wilaya ?? null, s.nif ?? null, s.nis ?? null, s.rc ?? null,
        s.payment_terms_days ?? 30, s.notes ?? null, nowIso()]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'supplier', entityId: id, details: { ref } });
    return id;
  });
}
