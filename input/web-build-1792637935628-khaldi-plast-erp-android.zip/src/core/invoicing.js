import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nextDocumentNumber } from './sequences.js';
import { uid, nowIso } from './ids.js';
import { today, addDays } from './dates.js';
import { customerBalance, invoiceOutstanding } from './receivables.js';
import { autoPost } from './postings.js';
import { reverseBySource } from './ledger.js';

/**
 * Pure calculation (no DB). Rounding policy (documented, to be confirmed by the accountant):
 *   gross = round2(qty x price); ht = round2(gross x (1 - disc/100)); tax = round2(ht x rate/100); ttc = ht + tax
 * Document totals are sums of the rounded lines, so printed lines always add up to printed totals.
 */
export function computeInvoice(lines) {
  const out = []; const byRate = new Map();
  let ht = Dec.zero(), disc = Dec.zero(), tax = Dec.zero();
  for (const l of lines) {
    const gross = D(l.qty).mul(l.unitPrice).round(2);
    const lht = gross.mul(D('1').sub(D(l.discountPct ?? '0').div('100'))).round(2);
    const ltax = lht.mul(D(l.taxRatePct ?? '0').div('100')).round(2);
    out.push({ ...l, gross, ht: lht, tax: ltax, ttc: lht.add(ltax) });
    ht = ht.add(lht); disc = disc.add(gross.sub(lht)); tax = tax.add(ltax);
    const k = D(l.taxRatePct ?? '0').toString();
    const b = byRate.get(k) ?? { ratePct: k, base: Dec.zero(), tax: Dec.zero() };
    b.base = b.base.add(lht); b.tax = b.tax.add(ltax); byRate.set(k, b);
  }
  return { lines: out, subtotalHt: ht, discountTotal: disc, taxTotal: tax, totalTtc: ht.add(tax), taxesByRate: [...byRate.values()] };
}

export async function issueInvoice(db, user, { customerId, lines, orderId = null, issueDate, dueDate, notes }) {
  requirePermission(user, 'invoices', 'post');
  if (!lines?.length) throw new Error('An invoice needs at least one line');
  return db.transaction(async (tx) => {
    const c = await tx.get('SELECT * FROM customers WHERE id=?', [customerId]);
    if (!c || !c.active) throw new Error('Unknown or inactive customer');
    const resolved = [];
    for (const l of lines) {
      if (!l.description?.trim()) throw new Error('Line description is required');
      if (!D(l.qty).gt(0)) throw new Error('Quantity must be greater than zero');
      if (D(l.unitPrice).isNegative()) throw new Error('Price must not be negative');
      const dp = D(l.discountPct ?? '0'); if (dp.isNegative() || dp.gt(100)) throw new Error('Discount must be 0..100');
      let rate = '0';
      if (l.taxCode) {
        const t = await tx.get('SELECT rate_pct, active FROM tax_rates WHERE code=?', [l.taxCode]);
        if (!t || !t.active) throw new Error(`Unknown or inactive tax code ${l.taxCode}`);
        rate = t.rate_pct; // snapshot of the rate at issue time
      }
      resolved.push({ ...l, taxRatePct: rate });
    }
    const calc = computeInvoice(resolved);
    const issue = issueDate ?? today();
    const due = dueDate ?? addDays(issue, c.payment_terms_days);
    const id = uid('inv_'), number = await nextDocumentNumber(tx, 'invoice', Number(issue.slice(0, 4)));
    await tx.run(`INSERT INTO invoices(id,number,customer_id,order_id,issue_date,due_date,subtotal_ht,discount_total,tax_total,total_ttc,notes,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, [id, number, customerId, orderId, issue, due, calc.subtotalHt.toString(), calc.discountTotal.toString(),
      calc.taxTotal.toString(), calc.totalTtc.toString(), notes ?? null, nowIso()]);
    let n = 0;
    for (const l of calc.lines) await tx.run(`INSERT INTO invoice_lines(invoice_id,line_no,product_id,description,qty,unit_price,discount_pct,tax_code,tax_rate_pct,line_gross,line_ht,line_tax,line_ttc)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`, [id, ++n, l.productId ?? null, l.description, D(l.qty).toString(), D(l.unitPrice).toString(), D(l.discountPct ?? '0').toString(),
      l.taxCode ?? null, D(l.taxRatePct).toString(), l.gross.toString(), l.ht.toString(), l.tax.toString(), l.ttc.toString()]);
    await audit(tx, { userId: user.id, action: 'issue', entity: 'invoice', entityId: id, details: { number, total: calc.totalTtc.toString() } });
    const posting = await autoPost(tx, user, 'invoice', id);
    // Credit limit is an alert, not a silent block: the caller decides (explicit authorization stays with the user).
    const bal = await customerBalance(tx, customerId);
    const limit = D(c.credit_limit);
    const warnings = !limit.isZero() && bal.balance.gt(limit) ? [{ code: 'credit_limit_exceeded', balance: bal.balance, limit }] : [];
    return { id, number, totals: calc, dueDate: due, warnings, posting };
  });
}

/** Cancellation is only possible while nothing is settled against the invoice; otherwise use a credit note. */
export async function cancelInvoice(db, user, id, reason) {
  requirePermission(user, 'invoices', 'post');
  if (!reason?.trim()) throw new Error('A cancellation reason is required');
  return db.transaction(async (tx) => {
    const inv = await tx.get('SELECT status FROM invoices WHERE id=?', [id]);
    if (!inv) throw new Error('Invoice not found');
    if (inv.status === 'cancelled') throw new Error('Invoice already cancelled');
    const a = await tx.get(`SELECT COUNT(*) n FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id WHERE pa.invoice_id=? AND p.status='valid'`, [id]);
    const c = await tx.get('SELECT COUNT(*) n FROM credit_notes WHERE invoice_id=?', [id]);
    if (a.n || c.n) throw new Error('Invoice has payments or credit notes; issue a credit note instead');
    await tx.run("UPDATE invoices SET status='cancelled', cancelled_at=?, cancel_reason=? WHERE id=?", [nowIso(), reason, id]);
    await reverseBySource(tx, user, 'invoice', id, { date: today(), reason });
    await audit(tx, { userId: user.id, action: 'cancel', entity: 'invoice', entityId: id, details: { reason } });
  });
}

export async function issueCreditNote(db, user, { invoiceId, amount, reason, issueDate }) {
  requirePermission(user, 'invoices', 'post');
  if (!reason?.trim()) throw new Error('A reason is required');
  const amt = D(amount);
  if (!amt.gt(0)) throw new Error('Amount must be greater than zero');
  return db.transaction(async (tx) => {
    const inv = await tx.get("SELECT * FROM invoices WHERE id=? AND status='issued'", [invoiceId]);
    if (!inv) throw new Error('Invoice not found or cancelled');
    const out = await invoiceOutstanding(tx, invoiceId);
    if (amt.gt(out)) throw new Error(`Credit note ${amt} exceeds the invoice outstanding amount ${out}`);
    const id = uid('cn_'), number = await nextDocumentNumber(tx, 'credit_note', new Date().getFullYear());
    await tx.run('INSERT INTO credit_notes(id,number,invoice_id,customer_id,issue_date,total_ttc,reason,created_at) VALUES (?,?,?,?,?,?,?,?)',
      [id, number, invoiceId, inv.customer_id, issueDate ?? today(), amt.toString(), reason, nowIso()]);
    await audit(tx, { userId: user.id, action: 'issue', entity: 'credit_note', entityId: id, details: { number, amount: amt.toString(), invoiceId } });
    const posting = await autoPost(tx, user, 'credit_note', id);
    return { id, number, posting };
  });
}
