import { requirePermission } from './permissions.js';
import { seedStarterChart, setAccountRole, ROLES } from './ledger.js';
import { createExpenseCategory } from './cash.js';
import { audit } from './audit.js';

export const STARTER_ROLE_MAP = { receivable: '3000', payable: '4000', sales_revenue: '7000', tax_collected: '4100', tax_deductible: '3100', inventory_materials: '2100', inventory_finished: '2200', cogs: '6500', production_waste: '6600' };
const CATS = [['ELEC', 'Électricité et eau', 'كهرباء وماء', '6000'], ['MAINT', 'Maintenance', 'صيانة', '6100'], ['TRANS', 'Transport', 'نقل', '6200'], ['RENT', 'Loyer', 'إيجار', '6300'], ['WAGES', 'Salaires', 'أجور', '6400'], ['OTHER', 'Autres charges', 'مصاريف أخرى', '6900']];

/**
 * One-click STARTER setup so documents can generate journal entries: starter chart of accounts (NOT statutory), account roles,
 * default expense categories. Idempotent. The accountant must review it before real use.
 */
export async function setupStarterAccounting(db, user) {
  requirePermission(user, 'accounting', 'admin');
  const added = await seedStarterChart(db, user);
  for (const r of ROLES) await setAccountRole(db, user, r, STARTER_ROLE_MAP[r]);
  let cats = 0;
  for (const [code, fr, ar, acc] of CATS) {
    if (await db.get('SELECT 1 x FROM expense_categories WHERE code=?', [code])) continue;
    await createExpenseCategory(db, { ...user, role: 'admin' }, { code, name_fr: fr, name_ar: ar, accountCode: acc }); cats++;
  }
  await db.transaction((tx) => audit(tx, { userId: user.id, action: 'setup_starter_accounting', entity: 'accounting', details: { accounts: added, categories: cats } }));
  return { accountsAdded: added, categoriesAdded: cats };
}
