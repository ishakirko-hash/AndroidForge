import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { can, requirePermission } from './permissions.js';
import { uid, nowIso } from './ids.js';

const need = (v, n) => { if (v == null || String(v).trim() === '') throw new Error(`${n} is required`); return String(v).trim(); };
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;

// ---------- shifts (configurable; may cross midnight) ----------
const mins = (t) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3));
export function shiftMinutes(start, end) {
  if (!HHMM.test(start) || !HHMM.test(end)) throw new Error('Times must be HH:MM');
  const d = mins(end) - mins(start);
  return d > 0 ? d : d + 24 * 60; // end <= start means it ends the next day
}
export async function createShift(db, user, { name, start, end }) {
  requirePermission(user, 'production', 'write');
  shiftMinutes(start, end);
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM shifts WHERE name=?', [need(name, 'name')])) throw new Error('Duplicate shift name');
    const id = uid('sh_'); await tx.run('INSERT INTO shifts(id,name,start_time,end_time) VALUES (?,?,?,?)', [id, name.trim(), start, end]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'shift', entityId: id }); return id;
  });
}
export async function updateShift(db, user, id, { name, start, end, active }) {
  requirePermission(user, 'production', 'post');
  const cur = await db.get('SELECT * FROM shifts WHERE id=?', [id]); if (!cur) throw new Error('Shift not found');
  const s = start ?? cur.start_time, e = end ?? cur.end_time; shiftMinutes(s, e);
  return db.transaction(async (tx) => {
    await tx.run('UPDATE shifts SET name=?, start_time=?, end_time=?, active=? WHERE id=?', [name ?? cur.name, s, e, active == null ? cur.active : (active ? 1 : 0), id]);
    await audit(tx, { userId: user.id, action: 'update', entity: 'shift', entityId: id, details: { from: cur, to: { name, start, end, active } } });
  });
}
/** Example schedule from the brief; the factory edits or replaces it. Not assumed to be the real working hours. */
export async function seedDefaultShifts(db, user) {
  return [await createShift(db, user, { name: 'Shift 1', start: '08:00', end: '16:00' }), await createShift(db, user, { name: 'Shift 2', start: '16:00', end: '00:00' }),
    await createShift(db, user, { name: 'Shift 3', start: '00:00', end: '08:00' })];
}

// ---------- employees & attendance ----------
export async function createEmployee(db, user, e) {
  requirePermission(user, 'employees', 'write');
  const ref = need(e.ref, 'ref'), name = need(e.name, 'name');
  if (e.hourly_cost != null && D(e.hourly_cost).isNegative()) throw new Error('hourly_cost must not be negative');
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM employees WHERE ref=?', [ref])) throw new Error(`Duplicate employee reference: ${ref}`);
    const id = uid('emp_');
    await tx.run('INSERT INTO employees(id,ref,name,job_title,department,start_date,default_shift_id,hourly_cost,skills,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
      [id, ref, name, e.job_title ?? null, e.department ?? null, e.start_date ?? null, e.default_shift_id ?? null, e.hourly_cost == null ? null : D(e.hourly_cost).toString(), e.skills ?? null, e.notes ?? null, nowIso()]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'employee', entityId: id, details: { ref } }); return id;
  });
}
/** Labor-cost data is sensitive: hidden unless the role may post in the employees module (manager/admin). */
export async function listEmployees(db, user) {
  requirePermission(user, 'employees', 'read');
  const rows = await db.all('SELECT * FROM employees ORDER BY ref');
  return can(user.role, 'employees', 'post') ? rows : rows.map(({ hourly_cost, ...r }) => r);
}
function checkHours(h, ot) {
  const a = D(h ?? '0'), b = D(ot ?? '0');
  if (a.isNegative() || a.gt(24) || b.isNegative() || b.gt(24)) throw new Error('Hours must be between 0 and 24');
  return [a, b];
}
export async function recordAttendance(db, user, { employeeId, workDate, status, hours = '0', overtimeHours = '0', shiftId = null, notes = null }) {
  requirePermission(user, 'employees', 'write');
  if (!['present', 'absent', 'leave', 'holiday'].includes(status)) throw new Error('Invalid status');
  const [h, ot] = status === 'present' ? checkHours(hours, overtimeHours) : [Dec.zero(), Dec.zero()];
  if (status === 'present' && !h.gt(0)) throw new Error('A present employee needs worked hours');
  return db.transaction(async (tx) => {
    const emp = await tx.get("SELECT status FROM employees WHERE id=?", [employeeId]);
    if (!emp || emp.status !== 'active') throw new Error('Unknown or inactive employee');
    if (await tx.get('SELECT 1 x FROM attendance WHERE employee_id=? AND work_date=?', [employeeId, workDate])) throw new Error('Attendance already recorded for this day; use a correction');
    await tx.run('INSERT INTO attendance(employee_id,work_date,status,hours,overtime_hours,shift_id,notes) VALUES (?,?,?,?,?,?,?)', [employeeId, workDate, status, h.toString(), ot.toString(), shiftId, notes]);
    await audit(tx, { userId: user.id, action: 'record', entity: 'attendance', entityId: `${employeeId}:${workDate}` });
  });
}
export async function correctAttendance(db, user, { employeeId, workDate, status, hours = '0', overtimeHours = '0', reason }) {
  requirePermission(user, 'employees', 'post');
  if (!reason?.trim()) throw new Error('A reason is required');
  const [h, ot] = status === 'present' ? checkHours(hours, overtimeHours) : [Dec.zero(), Dec.zero()];
  return db.transaction(async (tx) => {
    const before = await tx.get('SELECT * FROM attendance WHERE employee_id=? AND work_date=?', [employeeId, workDate]);
    if (!before) throw new Error('No attendance to correct');
    await tx.run('UPDATE attendance SET status=?, hours=?, overtime_hours=? WHERE employee_id=? AND work_date=?', [status, h.toString(), ot.toString(), employeeId, workDate]);
    await audit(tx, { userId: user.id, action: 'correct', entity: 'attendance', entityId: `${employeeId}:${workDate}`, details: { reason, before: { status: before.status, hours: before.hours, overtime: before.overtime_hours }, after: { status, hours: h.toString(), overtime: ot.toString() } } });
  });
}
export async function attendanceSummary(db, employeeId, { from, to }) {
  const rows = await db.all('SELECT status, hours, overtime_hours FROM attendance WHERE employee_id=? AND work_date>=? AND work_date<=?', [employeeId, from, to]);
  const count = (s) => rows.filter((r) => r.status === s).length;
  return { present: count('present'), absent: count('absent'), leave: count('leave'), hours: Dec.sum(rows.map((r) => D(r.hours))), overtime: Dec.sum(rows.map((r) => D(r.overtime_hours))) };
}

// ---------- shift production records ----------
export async function recordShiftOutput(db, user, { shiftId, workDate, machineId, operatorId, productionOrderId, produced, accepted, rejected, downtimeMin = 0, downtimeReason = null, notes = null }) {
  requirePermission(user, 'production', 'write');
  const p = D(produced), a = D(accepted), r = D(rejected);
  if (p.isNegative() || a.isNegative() || r.isNegative()) throw new Error('Quantities must not be negative');
  if (!a.add(r).eq(p)) throw new Error('Accepted + rejected must equal produced');
  if (!Number.isInteger(downtimeMin) || downtimeMin < 0) throw new Error('Invalid downtime');
  if (downtimeMin > 0 && !downtimeReason?.trim()) throw new Error('A downtime reason is required');
  return db.transaction(async (tx) => {
    const sh = await tx.get('SELECT * FROM shifts WHERE id=?', [shiftId]); if (!sh) throw new Error('Unknown shift');
    if (downtimeMin > shiftMinutes(sh.start_time, sh.end_time)) throw new Error('Downtime exceeds the shift length');
    const m = await tx.get('SELECT status FROM machines WHERE id=?', [machineId]); if (!m) throw new Error('Unknown machine');
    if (m.status !== 'operational') throw new Error(`Machine is ${m.status}`);
    const op = await tx.get("SELECT 1 x FROM employees WHERE id=? AND status='active'", [operatorId]); if (!op) throw new Error('Unknown or inactive operator');
    const o = await tx.get('SELECT status FROM production_orders WHERE id=?', [productionOrderId]);
    if (!o || o.status !== 'in_progress') throw new Error('Production order must be in progress');
    if (await tx.get('SELECT 1 x FROM shift_records WHERE shift_id=? AND work_date=? AND machine_id=? AND operator_id=? AND production_order_id=?', [shiftId, workDate, machineId, operatorId, productionOrderId]))
      throw new Error('This shift output was already recorded (no double counting)');
    const id = uid('sr_');
    await tx.run(`INSERT INTO shift_records(id,shift_id,work_date,machine_id,operator_id,production_order_id,produced_qty,accepted_qty,rejected_qty,downtime_min,downtime_reason,notes,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`, [id, shiftId, workDate, machineId, operatorId, productionOrderId, p.toString(), a.toString(), r.toString(), downtimeMin, downtimeReason, notes, nowIso()]);
    await audit(tx, { userId: user.id, action: 'record', entity: 'shift_record', entityId: id }); return id;
  });
}
export async function reviewShiftRecord(db, user, id) {
  requirePermission(user, 'production', 'post');
  return db.transaction(async (tx) => {
    const r = await tx.run('UPDATE shift_records SET reviewed_by=?, reviewed_at=? WHERE id=? AND reviewed_at IS NULL', [user.id, nowIso(), id]);
    if (!r.changes) throw new Error('Record not found or already reviewed');
    await audit(tx, { userId: user.id, action: 'review', entity: 'shift_record', entityId: id });
  });
}
const GROUP = { shift: 'shift_id', operator: 'operator_id', machine: 'machine_id', day: 'work_date', order: 'production_order_id' };
export async function outputBy(db, by, { from, to }) {
  const col = GROUP[by]; if (!col) throw new Error('Invalid grouping');
  const rows = await db.all(`SELECT ${col} k, produced_qty p, accepted_qty a, rejected_qty r, downtime_min d FROM shift_records WHERE work_date>=? AND work_date<=?`, [from, to]);
  const m = new Map();
  for (const r of rows) { const g = m.get(r.k) ?? { key: r.k, produced: Dec.zero(), accepted: Dec.zero(), rejected: Dec.zero(), downtimeMin: 0 };
    g.produced = g.produced.add(r.p); g.accepted = g.accepted.add(r.a); g.rejected = g.rejected.add(r.r); g.downtimeMin += r.d; m.set(r.k, g); }
  return [...m.values()].sort((x, y) => String(x.key).localeCompare(String(y.key)));
}
/** Shift records vs the completed order's totals: a mismatch is reported, never silently corrected. */
export async function shiftReconciliation(db, orderId) {
  const o = await db.get('SELECT total_qty, accepted_qty, status FROM production_orders WHERE id=?', [orderId]);
  const s = await db.all('SELECT produced_qty p, accepted_qty a FROM shift_records WHERE production_order_id=?', [orderId]);
  const produced = Dec.sum(s.map((x) => D(x.p))), accepted = Dec.sum(s.map((x) => D(x.a)));
  return { orderStatus: o.status, shiftProduced: produced, shiftAccepted: accepted, orderTotal: o.total_qty == null ? null : D(o.total_qty),
    differenceProduced: o.total_qty == null ? null : produced.sub(o.total_qty), ok: o.total_qty == null ? null : produced.eq(o.total_qty) };
}
