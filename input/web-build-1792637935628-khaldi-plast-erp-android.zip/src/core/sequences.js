// Gap-free-per-transaction sequential document numbers, e.g. FAC-2026-0001.
export const DOC_PREFIXES = {
  invoice: 'FAC', credit_note: 'AV', quotation: 'DEV', sales_order: 'CMD', delivery_note: 'BL',
  purchase_order: 'BC', goods_receipt: 'BR', production_order: 'OF', payment: 'REG', journal: 'JRN', supplier_invoice: 'FF', supplier_payment: 'RFO', expense: 'DEP', transfer: 'VIR',
};

/** Must be called inside db.transaction so a rollback also rolls the number back. */
export async function nextDocumentNumber(db, type, year, pad = 4) {
  const prefix = DOC_PREFIXES[type];
  if (!prefix) throw new Error(`Unknown document type: ${type}`);
  if (!Number.isInteger(year)) throw new Error('year must be an integer');
  const key = `${type}:${year}`;
  await db.run('INSERT OR IGNORE INTO doc_sequences(key,next_value) VALUES (?,1)', [key]);
  const row = await db.get('SELECT next_value FROM doc_sequences WHERE key=?', [key]);
  await db.run('UPDATE doc_sequences SET next_value = next_value + 1 WHERE key=?', [key]);
  return `${prefix}-${year}-${String(row.next_value).padStart(pad, '0')}`;
}
