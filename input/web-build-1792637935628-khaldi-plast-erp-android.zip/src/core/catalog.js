import { D } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { uid, nowIso } from './ids.js';

const UNITS = ['kg', 'g', 't', 'pcs', 'l'];
const need = (v, name) => { if (v == null || String(v).trim() === '') throw new Error(`${name} is required`); return String(v).trim(); };
const nonNeg = (v, name) => { const d = D(v ?? '0'); if (d.isNegative()) throw new Error(`${name} must not be negative`); return d.toString(); };

export async function createProduct(db, user, p) {
  requirePermission(user, 'products', 'write');
  const rec = { id: uid('prd_'), ref: need(p.ref, 'ref'), name_fr: need(p.name_fr, 'name_fr'), name_ar: p.name_ar ?? null,
    category: p.category ?? null, color: p.color ?? null, dimensions: p.dimensions ?? null, unit: p.unit ?? 'pcs',
    unit_weight_g: p.unit_weight_g == null ? null : nonNeg(p.unit_weight_g, 'unit_weight_g'),
    sale_price: nonNeg(p.sale_price, 'sale_price'), min_stock: nonNeg(p.min_stock, 'min_stock'), notes: p.notes ?? null };
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM products WHERE ref=?', [rec.ref])) throw new Error(`Duplicate product reference: ${rec.ref}`);
    const ts = nowIso();
    await tx.run(`INSERT INTO products(id,ref,name_fr,name_ar,category,color,dimensions,unit,unit_weight_g,sale_price,min_stock,notes,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [rec.id, rec.ref, rec.name_fr, rec.name_ar, rec.category, rec.color, rec.dimensions, rec.unit,
      rec.unit_weight_g, rec.sale_price, rec.min_stock, rec.notes, ts, ts]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'product', entityId: rec.id, details: { ref: rec.ref } });
    return rec.id;
  });
}

export async function createMaterial(db, user, m) {
  requirePermission(user, 'materials', 'write');
  const unit = need(m.unit, 'unit'); if (!UNITS.includes(unit)) throw new Error(`Invalid unit ${unit}`);
  const id = uid('mat_'), ref = need(m.ref, 'ref'), name = need(m.name, 'name');
  const min = nonNeg(m.min_stock, 'min_stock'), cost = m.purchase_cost == null ? null : nonNeg(m.purchase_cost, 'purchase_cost');
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM materials WHERE ref=?', [ref])) throw new Error(`Duplicate material reference: ${ref}`);
    const ts = nowIso();
    await tx.run(`INSERT INTO materials(id,ref,name,category,unit,min_stock,purchase_cost,notes,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [id, ref, name, m.category ?? null, unit, min, cost, m.notes ?? null, ts, ts]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'material', entityId: id, details: { ref } });
    return id;
  });
}

/** Archive instead of delete: products/materials may be referenced by history. */
export async function archiveItem(db, user, kind, id) {
  const table = kind === 'product' ? 'products' : kind === 'material' ? 'materials' : null;
  if (!table) throw new Error('kind must be product or material');
  requirePermission(user, kind === 'product' ? 'products' : 'materials', 'write');
  return db.transaction(async (tx) => {
    const r = await tx.run(`UPDATE ${table} SET status='archived', updated_at=? WHERE id=?`, [nowIso(), id]);
    if (!r.changes) throw new Error('Not found');
    await audit(tx, { userId: user.id, action: 'archive', entity: kind, entityId: id });
  });
}

/** Creates a NEW recipe version (older versions stay intact for historical production orders). */
export async function createRecipe(db, user, { productId, lines, effectiveDate }) {
  requirePermission(user, 'products', 'write');
  if (!lines?.length) throw new Error('A recipe needs at least one material line');
  return db.transaction(async (tx) => {
    if (!(await tx.get("SELECT 1 x FROM products WHERE id=? AND status='active'", [productId]))) throw new Error('Unknown or archived product');
    const seen = new Set();
    for (const l of lines) {
      if (seen.has(l.materialId)) throw new Error('Duplicate material in recipe');
      seen.add(l.materialId);
      if (!(D(l.qtyPerUnit).gt(0))) throw new Error('qtyPerUnit must be > 0');
      if (D(l.lossPct ?? '0').isNegative() || D(l.lossPct ?? '0').gt(100)) throw new Error('lossPct must be 0..100');
      if (!(await tx.get('SELECT 1 x FROM materials WHERE id=?', [l.materialId]))) throw new Error('Unknown material');
    }
    const v = ((await tx.get('SELECT MAX(version) v FROM recipes WHERE product_id=?', [productId])).v ?? 0) + 1;
    const id = uid('rcp_');
    await tx.run('INSERT INTO recipes(id,product_id,version,effective_date,created_at) VALUES (?,?,?,?,?)',
      [id, productId, v, effectiveDate ?? nowIso().slice(0, 10), nowIso()]);
    for (const l of lines) {
      const mat = await tx.get('SELECT unit FROM materials WHERE id=?', [l.materialId]);
      await tx.run('INSERT INTO recipe_lines(recipe_id,material_id,qty_per_unit,unit,loss_pct) VALUES (?,?,?,?,?)',
        [id, l.materialId, D(l.qtyPerUnit).toString(), l.unit ?? mat.unit, D(l.lossPct ?? '0').toString()]);
    }
    await audit(tx, { userId: user.id, action: 'create', entity: 'recipe', entityId: id, details: { productId, version: v } });
    return { id, version: v };
  });
}

export const latestRecipe = (db, productId) => db.get('SELECT * FROM recipes WHERE product_id=? ORDER BY version DESC LIMIT 1', [productId]);
