/**
 * Idempotency guard for business events (stock dispatch, payment posting, production completion, journal posting).
 * The marker and the work commit or roll back together, so a repeated or retried event is applied exactly once.
 * Example key: `dispatch:BL-2026-0003`.
 */
export async function once(db, eventKey, work) {
  return db.transaction(async (tx) => {
    const r = await tx.run('INSERT OR IGNORE INTO processed_events(event_key,created_at) VALUES (?,?)',
      [eventKey, new Date().toISOString()]);
    if (r.changes === 0) return { duplicate: true };
    return { duplicate: false, result: await work(tx) };
  });
}
