// Exact decimal arithmetic for money and quantities. Values are BigInt "units" of 1e-4.
// No binary floating point is ever used. Rounding: half away from zero.
const SCALE = 4;
const ONE = 10n ** BigInt(SCALE);

function roundDiv(n, d) {
  if (d === 0n) throw new RangeError('Division by zero');
  const neg = (n < 0n) !== (d < 0n);
  const an = n < 0n ? -n : n, ad = d < 0n ? -d : d;
  let q = an / ad;
  if ((an % ad) * 2n >= ad) q += 1n;
  return neg ? -q : q;
}

export class Dec {
  constructor(units) { this.u = BigInt(units); Object.freeze(this); }

  /** Parse "12.5", "12,5", "-3", or an integer Number. Fractional JS numbers are rejected. */
  static parse(v) {
    if (v instanceof Dec) return v;
    if (typeof v === 'number') {
      if (!Number.isSafeInteger(v)) throw new TypeError('Use a decimal string, not a floating-point number');
      return new Dec(BigInt(v) * ONE);
    }
    if (typeof v !== 'string') throw new TypeError('Invalid decimal input');
    let s = v.trim().replace(/[\s\u00a0\u202f]/g, '');
    if (s.includes(',') && !s.includes('.')) s = s.replace(',', '.');
    const m = /^([+-]?)(\d+)(?:\.(\d+))?$/.exec(s);
    if (!m) throw new TypeError(`Invalid decimal: "${v}"`);
    const frac = m[3] || '';
    let units = BigInt(m[2]) * ONE + BigInt(frac.slice(0, SCALE).padEnd(SCALE, '0'));
    if (frac.length > SCALE && frac[SCALE] >= '5') units += 1n;
    return new Dec(m[1] === '-' ? -units : units);
  }
  static zero() { return new Dec(0n); }
  static sum(list) { return list.reduce((a, b) => a.add(b), Dec.zero()); }
  /** Percentage of whole, or null when whole is zero (never divides by zero). */
  static percent(part, whole) {
    const w = Dec.parse(whole);
    if (w.isZero()) return null;
    return Dec.parse(part).mul('100').div(w);
  }

  add(o) { return new Dec(this.u + Dec.parse(o).u); }
  sub(o) { return new Dec(this.u - Dec.parse(o).u); }
  neg() { return new Dec(-this.u); }
  abs() { return this.u < 0n ? this.neg() : this; }
  mul(o) { return new Dec(roundDiv(this.u * Dec.parse(o).u, ONE)); }
  div(o) { return new Dec(roundDiv(this.u * ONE, Dec.parse(o).u)); }
  cmp(o) { const x = Dec.parse(o).u; return this.u < x ? -1 : this.u > x ? 1 : 0; }
  eq(o) { return this.cmp(o) === 0; }
  lt(o) { return this.cmp(o) < 0; }
  gt(o) { return this.cmp(o) > 0; }
  isZero() { return this.u === 0n; }
  isNegative() { return this.u < 0n; }

  round(places = 2) {
    if (places < 0 || places > SCALE) throw new RangeError('places must be 0..4');
    const f = 10n ** BigInt(SCALE - places);
    return new Dec(roundDiv(this.u, f) * f);
  }
  /** Machine-readable fixed string with '.' decimal, e.g. "1234.50" */
  toFixed(places = 2) {
    const r = this.round(places);
    const neg = r.u < 0n;
    const a = neg ? -r.u : r.u;
    const int = (a / ONE).toString();
    const frac = (a % ONE).toString().padStart(SCALE, '0').slice(0, places);
    return (neg ? '-' : '') + int + (places ? '.' + frac : '');
  }
  toString() {
    const s = this.toFixed(SCALE);
    return s.includes('.') ? s.replace(/\.?0+$/, '') : s;
  }
  toJSON() { return this.toString(); }

  /** Display: fr "12 560 000,00" (narrow NBSP groups); ar "12,560,000.00" (Latin digits, as in the UI references). */
  format(lang = 'fr', places = 2) {
    const s = this.toFixed(places);
    const neg = s.startsWith('-');
    const [i, f] = (neg ? s.slice(1) : s).split('.');
    const group = lang === 'ar' ? ',' : '\u202f';
    const dec = lang === 'ar' ? '.' : ',';
    return (neg ? '-' : '') + i.replace(/\B(?=(\d{3})+(?!\d))/g, group) + (f ? dec + f : '');
  }
}

export const D = (v) => Dec.parse(v);

const MASS_TO_G = { g: '1', kg: '1000', t: '1000000' };
export function convertMass(value, from, to) {
  if (!(from in MASS_TO_G) || !(to in MASS_TO_G)) throw new RangeError(`Unsupported unit ${from}->${to}`);
  return D(value).mul(MASS_TO_G[from]).div(MASS_TO_G[to]);
}
