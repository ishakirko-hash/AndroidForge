export const uid = (prefix = '') => prefix + globalThis.crypto.randomUUID();
export const nowIso = () => new Date().toISOString();
