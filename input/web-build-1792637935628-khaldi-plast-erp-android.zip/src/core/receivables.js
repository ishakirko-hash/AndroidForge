import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nextDocumentNumber } from './sequences.js';
import { uid, nowIso } from './ids.js';
import { today, daysBetween } from './dates.js';
import { recordCashMovement } from './cash.js';
import { autoPost } from './postings.js';
import { reverseBySource } from './ledger.js';

const allocatedTo = async (db, invoiceId) => Dec.sum((await db.all(
  `SELECT pa.amount FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id WHERE pa.invoice_id=? AND p.status='valid'`, [invoiceId])).map((r) => D(r.amount)));
const creditedTo = async (db, invoiceId) => Dec.sum((await db.all('SELECT total_ttc FROM credit_notes WHERE invoice_id=?', [invoiceId])).map((r) => D(r.total_ttc)));

/** Invoice outstanding = total - valid allocated payments - credit notes (0 for cancelled invoices). */
export async function invoiceOutstanding(db, invoiceId) {
  const inv = await db.get('SELECT total_ttc, status FROM invoices WHERE id=?', [invoiceId]);
  if (!inv || inv.status !== 'issued') return Dec.zero();
  return D(inv.total_ttc).sub(await allocatedTo(db, invoiceId)).sub(await creditedTo(db, invoiceId));
}

/**
 * Customer balance = issued invoices - credit notes - valid payments (allocated or not).
 * A negative balance means the customer has credit on account. `unallocated` = payments not yet applied to invoices.
 */
export async function customerBalance(db, customerId) {
  const invoiced = Dec.sum((await db.all("SELECT total_ttc FROM invoices WHERE customer_id=? AND status='issued'", [customerId])).map((r) => D(r.total_ttc)));
  const credits = Dec.sum((await db.all('SELECT cn.total_ttc FROM credit_notes cn JOIN invoices i ON i.id=cn.invoice_id WHERE cn.customer_id=? AND i.status=\'issued\'', [customerId])).map((r) => D(r.total_ttc)));
  const pays = await db.all("SELECT id, amount FROM payments WHERE customer_id=? AND status='valid'", [customerId]);
  const paid = Dec.sum(pays.map((p) => D(p.amount)));
  let allocated = Dec.zero();
  for (const p of pays) allocated = allocated.add(Dec.sum((await db.all('SELECT amount FROM payment_allocations WHERE payment_id=?', [p.id])).map((r) => D(r.amount))));
  return { invoiced, credits, paid, balance: invoiced.sub(credits).sub(paid), unallocated: paid.sub(allocated) };
}

export async function openInvoices(db, customerId) {
  const invs = await db.all("SELECT * FROM invoices WHERE customer_id=? AND status='issued' ORDER BY due_date, issue_date, number", [customerId]);
  const out = [];
  for (const i of invs) { const o = await invoiceOutstanding(db, i.id); if (o.gt(0)) out.push({ ...i, outstanding: o }); }
  return out;
}

/** Suggestion only (oldest due first). Nothing is posted until the user confirms via recordPayment/allocatePayment. */
export async function suggestAllocation(db, customerId, amount) {
  let left = D(amount); const out = [];
  for (const i of await openInvoices(db, customerId)) {
    if (!left.gt(0)) break;
    const a = i.outstanding.lt(left) ? i.outstanding : left;
    out.push({ invoiceId: i.id, number: i.number, amount: a }); left = left.sub(a);
  }
  return { allocations: out, excess: left };
}

async function applyAllocations(tx, payment, allocations) {
  const already = Dec.sum((await tx.all('SELECT amount FROM payment_allocations WHERE payment_id=?', [payment.id])).map((r) => D(r.amount)));
  let total = already;
  const seen = new Set();
  for (const a of allocations) {
    const amt = D(a.amount);
    if (!amt.gt(0)) throw new Error('Allocation must be greater than zero');
    if (seen.has(a.invoiceId)) throw new Error('Invoice appears twice in allocation');
    seen.add(a.invoiceId);
    const inv = await tx.get("SELECT customer_id FROM invoices WHERE id=? AND status='issued'", [a.invoiceId]);
    if (!inv || inv.customer_id !== payment.customer_id) throw new Error('Invoice not found for this customer');
    const out = await invoiceOutstanding(tx, a.invoiceId);
    if (amt.gt(out)) throw new Error(`Allocation ${amt} exceeds invoice outstanding ${out}`);
    total = total.add(amt);
    if (total.gt(payment.amount)) throw new Error('Allocations exceed the payment amount');
    await tx.run('INSERT INTO payment_allocations(payment_id,invoice_id,amount,created_at) VALUES (?,?,?,?)', [payment.id, a.invoiceId, amt.toString(), nowIso()]);
  }
}

/**
 * Records a payment (idempotent on eventKey) and applies the confirmed allocations atomically.
 * Any part not allocated stays as customer credit on account (policy: customer_credit).
 * A payment with the same customer, amount, date and reference as an existing valid one is rejected unless allowDuplicate.
 */
export async function recordPayment(db, user, { customerId, amount, method, reference = null, payDate, eventKey, allocations = [], allowDuplicate = false, finAccountId = null }) {
  requirePermission(user, 'payments', 'post');
  const amt = D(amount);
  if (!amt.gt(0)) throw new Error('Payment amount must be greater than zero');
  if (!eventKey) throw new Error('eventKey is required');
  return db.transaction(async (tx) => {
    const dup = await tx.get('SELECT id, number FROM payments WHERE event_key=?', [eventKey]);
    if (dup) return { duplicate: true, id: dup.id, number: dup.number };
    if (!(await tx.get('SELECT 1 x FROM customers WHERE id=?', [customerId]))) throw new Error('Unknown customer');
    const date = payDate ?? today();
    if (reference && !allowDuplicate && await tx.get("SELECT 1 x FROM payments WHERE customer_id=? AND amount=? AND pay_date=? AND reference=? AND status='valid'", [customerId, amt.toString(), date, reference]))
      throw new Error('Possible duplicate payment (same customer, amount, date and reference)');
    const id = uid('pay_'), number = await nextDocumentNumber(tx, 'payment', Number(date.slice(0, 4)));
    await tx.run('INSERT INTO payments(id,number,event_key,customer_id,pay_date,amount,method,reference,created_at,fin_account_id) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [id, number, eventKey, customerId, date, amt.toString(), method, reference, nowIso(), finAccountId]);
    await applyAllocations(tx, { id, customer_id: customerId, amount: amt }, allocations);
    if (finAccountId) await recordCashMovement(tx, { finAccountId, date, amount: amt, kind: 'customer_receipt', sourceType: 'customer_payment', sourceId: id, memo: number, eventKey: `pay:${id}` });
    const posting = await autoPost(tx, user, 'customer_payment', id);
    await audit(tx, { userId: user.id, action: 'record', entity: 'payment', entityId: id, details: { number, amount: amt.toString(), allocations: allocations.length } });
    return { duplicate: false, id, number, posting };
  });
}

/** Apply (more of) an existing payment's unallocated credit to open invoices — explicit confirmation required by the caller. */
export async function allocatePayment(db, user, paymentId, allocations) {
  requirePermission(user, 'payments', 'post');
  return db.transaction(async (tx) => {
    const p = await tx.get("SELECT * FROM payments WHERE id=? AND status='valid'", [paymentId]);
    if (!p) throw new Error('Payment not found or cancelled');
    await applyAllocations(tx, { id: p.id, customer_id: p.customer_id, amount: D(p.amount) }, allocations);
    await audit(tx, { userId: user.id, action: 'allocate', entity: 'payment', entityId: paymentId });
  });
}

/** Cancelling keeps every row (audit) but removes the payment and its allocations from all balances. */
export async function cancelPayment(db, user, paymentId, reason) {
  requirePermission(user, 'payments', 'post');
  if (!reason?.trim()) throw new Error('A reason is required');
  return db.transaction(async (tx) => {
    const p = await tx.get("SELECT * FROM payments WHERE id=? AND status='valid'", [paymentId]);
    if (!p) throw new Error('Payment not found or already cancelled');
    await tx.run("UPDATE payments SET status='cancelled' WHERE id=?", [paymentId]);
    if (p.fin_account_id) await recordCashMovement(tx, { finAccountId: p.fin_account_id, date: today(), amount: D(p.amount).neg(), kind: 'reversal', sourceType: 'customer_payment', sourceId: paymentId, memo: 'reversal', eventKey: `pay:${paymentId}:rev` });
    await reverseBySource(tx, user, 'customer_payment', paymentId, { date: today(), reason });
    await audit(tx, { userId: user.id, action: 'cancel', entity: 'payment', entityId: paymentId, details: { reason } });
  });
}

/** Aging by days past DUE date as of `asOf`. Buckets: not due, 1-30, 31-60, 61-90, >90. */
export async function debtAging(db, { customerId = null, asOf = today() } = {}) {
  const invs = customerId
    ? await db.all("SELECT * FROM invoices WHERE status='issued' AND customer_id=?", [customerId])
    : await db.all("SELECT * FROM invoices WHERE status='issued'");
  const b = { notDue: Dec.zero(), d1_30: Dec.zero(), d31_60: Dec.zero(), d61_90: Dec.zero(), over90: Dec.zero() };
  for (const i of invs) {
    const o = await invoiceOutstanding(db, i.id);
    if (!o.gt(0)) continue;
    const late = daysBetween(i.due_date, asOf);
    const k = late <= 0 ? 'notDue' : late <= 30 ? 'd1_30' : late <= 60 ? 'd31_60' : late <= 90 ? 'd61_90' : 'over90';
    b[k] = b[k].add(o);
  }
  const overdue = b.d1_30.add(b.d31_60).add(b.d61_90).add(b.over90);
  return { asOf, buckets: b, overdue, outstanding: overdue.add(b.notDue),
    basis: 'outstanding = invoice total - valid allocated payments - credit notes; age = days after due date' };
}
