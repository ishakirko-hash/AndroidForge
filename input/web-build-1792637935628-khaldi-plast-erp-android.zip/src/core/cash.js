import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nextDocumentNumber } from './sequences.js';
import { postEntry, reverseBySource } from './ledger.js';
import { uid, nowIso } from './ids.js';
import { today } from './dates.js';

export async function createFinancialAccount(db, user, { name, kind, ledgerAccount, openingBalance = '0', openingEquityAccount = null, openingDate = today(), allowNegative = false }) {
  requirePermission(user, 'accounting', 'write');
  if (!name?.trim()) throw new Error('name is required');
  if (!['cash', 'bank'].includes(kind)) throw new Error('kind must be cash or bank');
  const open = D(openingBalance); if (!open.round(2).eq(open)) throw new Error('Amounts are limited to 2 decimals');
  return db.transaction(async (tx) => {
    if (!(await tx.get('SELECT 1 x FROM accounts WHERE code=? AND type=\'asset\'', [ledgerAccount]))) throw new Error('ledgerAccount must be an existing asset account');
    const id = uid('fa_');
    await tx.run('INSERT INTO financial_accounts(id,name,kind,ledger_account,opening_balance_u,allow_negative,created_at) VALUES (?,?,?,?,?,?,?)',
      [id, name.trim(), kind, ledgerAccount, open.u, allowNegative ? 1 : 0, nowIso()]);
    if (open.gt(0)) { // the opening balance is journaled so the ledger and the cash records agree from day one
      if (!openingEquityAccount || !(await tx.get("SELECT 1 x FROM accounts WHERE code=? AND type='equity'", [openingEquityAccount]))) throw new Error('openingEquityAccount (an equity account) is required for a non-zero opening balance');
      await postEntry(tx, user, { date: openingDate, description: `Solde d'ouverture ${name.trim()}`, sourceType: 'opening', sourceId: id,
        lines: [{ account: ledgerAccount, debit: open }, { account: openingEquityAccount, credit: open }] });
    }
    await audit(tx, { userId: user.id, action: 'create', entity: 'financial_account', entityId: id, details: { name, kind } });
    return id;
  });
}

export async function cashBalance(db, finAccountId) {
  const a = await db.get('SELECT opening_balance_u o FROM financial_accounts WHERE id=?', [finAccountId]);
  if (!a) throw new Error('Unknown financial account');
  const m = await db.get('SELECT COALESCE(SUM(amount_u),0) s FROM cash_movements WHERE fin_account_id=?', [finAccountId]);
  return new Dec(BigInt(a.o) + BigInt(m.s));
}

/** Inside a transaction. Signed amount: + in, - out. Idempotent on eventKey; blocks overdraft unless the account allows it. */
export async function recordCashMovement(tx, { finAccountId, date, amount, kind, sourceType = null, sourceId = null, memo = null, eventKey }) {
  if (!eventKey) throw new Error('eventKey is required');
  const amt = D(amount);
  if (amt.isZero()) throw new Error('Amount must not be zero');
  if (!amt.round(2).eq(amt)) throw new Error('Amounts are limited to 2 decimals');
  if (await tx.get('SELECT 1 x FROM cash_movements WHERE event_key=?', [eventKey])) return { duplicate: true };
  const fa = await tx.get('SELECT * FROM financial_accounts WHERE id=? AND active=1', [finAccountId]);
  if (!fa) throw new Error('Unknown or inactive financial account');
  if (amt.isNegative() && !fa.allow_negative && (await cashBalance(tx, finAccountId)).add(amt).isNegative())
    throw new Error(`Insufficient funds in ${fa.name}`);
  await tx.run('INSERT INTO cash_movements(event_key,fin_account_id,move_date,amount_u,kind,source_type,source_id,memo,created_at) VALUES (?,?,?,?,?,?,?,?,?)',
    [eventKey, finAccountId, date, amt.u, kind, sourceType, sourceId == null ? null : String(sourceId), memo, nowIso()]);
  return { duplicate: false };
}
export const ledgerOf = (tx, finAccountId) => tx.get('SELECT ledger_account, name FROM financial_accounts WHERE id=?', [finAccountId]);

/** Transfers move money between own accounts: never revenue or expense. */
export async function transfer(db, user, { fromId, toId, amount, date = today(), eventKey, memo }) {
  requirePermission(user, 'accounting', 'post');
  const amt = D(amount);
  if (!amt.gt(0)) throw new Error('Amount must be greater than zero');
  if (fromId === toId) throw new Error('Source and destination must differ');
  if (!eventKey) throw new Error('eventKey is required');
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM cash_movements WHERE event_key=?', [`${eventKey}:out`])) return { duplicate: true };
    const id = uid('tr_'), number = await nextDocumentNumber(tx, 'transfer', Number(date.slice(0, 4)));
    await recordCashMovement(tx, { finAccountId: fromId, date, amount: amt.neg(), kind: 'transfer_out', sourceType: 'transfer', sourceId: id, memo: number, eventKey: `${eventKey}:out` });
    await recordCashMovement(tx, { finAccountId: toId, date, amount: amt, kind: 'transfer_in', sourceType: 'transfer', sourceId: id, memo: number, eventKey: `${eventKey}:in` });
    const from = await ledgerOf(tx, fromId), to = await ledgerOf(tx, toId);
    if (from.ledger_account !== to.ledger_account)
      await postEntry(tx, user, { date, description: `Virement ${from.name} → ${to.name} (${number})`, sourceType: 'transfer', sourceId: id,
        lines: [{ account: to.ledger_account, debit: amt }, { account: from.ledger_account, credit: amt }] });
    await audit(tx, { userId: user.id, action: 'transfer', entity: 'cash_transfer', entityId: id, details: { number, amount: amt.toString() } });
    return { duplicate: false, id, number };
  });
}

// ---------- expenses ----------
export async function createExpenseCategory(db, user, { code, name_fr, name_ar = null, accountCode }) {
  requirePermission(user, 'expenses', 'write');
  return db.transaction(async (tx) => {
    if (!(await tx.get("SELECT 1 x FROM accounts WHERE code=? AND type='expense'", [accountCode]))) throw new Error('accountCode must be an existing expense account');
    await tx.run('INSERT INTO expense_categories(code,name_fr,name_ar,account_code) VALUES (?,?,?,?)', [code, name_fr, name_ar, accountCode]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'expense_category', entityId: code });
  });
}

/** Paid expense: cash/bank movement + journal (Dr expense, Cr cash/bank) in one atomic step. */
export async function recordExpense(db, user, { date = today(), categoryCode, amount, finAccountId, description = null, reference = null, eventKey }) {
  requirePermission(user, 'expenses', 'post');
  const amt = D(amount);
  if (!amt.gt(0)) throw new Error('Amount must be greater than zero');
  if (!eventKey) throw new Error('eventKey is required');
  return db.transaction(async (tx) => {
    const dup = await tx.get('SELECT id, number FROM expenses WHERE event_key=?', [eventKey]);
    if (dup) return { duplicate: true, ...dup };
    const cat = await tx.get('SELECT * FROM expense_categories WHERE code=?', [categoryCode]);
    if (!cat) throw new Error('Unknown expense category');
    const id = uid('exp_'), number = await nextDocumentNumber(tx, 'expense', Number(date.slice(0, 4)));
    await tx.run('INSERT INTO expenses(id,number,event_key,exp_date,category_code,amount,fin_account_id,description,reference,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [id, number, eventKey, date, categoryCode, amt.toString(), finAccountId, description, reference, nowIso()]);
    await recordCashMovement(tx, { finAccountId, date, amount: amt.neg(), kind: 'expense', sourceType: 'expense', sourceId: id, memo: number, eventKey: `exp:${id}` });
    const fa = await ledgerOf(tx, finAccountId);
    await postEntry(tx, user, { date, description: `${number} ${cat.name_fr}${description ? ' — ' + description : ''}`, sourceType: 'expense', sourceId: id,
      lines: [{ account: cat.account_code, debit: amt }, { account: fa.ledger_account, credit: amt }] });
    await audit(tx, { userId: user.id, action: 'record', entity: 'expense', entityId: id, details: { number, amount: amt.toString() } });
    return { duplicate: false, id, number };
  });
}
export async function cancelExpense(db, user, id, reason) {
  requirePermission(user, 'expenses', 'post');
  if (!reason?.trim()) throw new Error('A reason is required');
  return db.transaction(async (tx) => {
    const e = await tx.get("SELECT * FROM expenses WHERE id=? AND status='valid'", [id]);
    if (!e) throw new Error('Expense not found or already cancelled');
    await tx.run("UPDATE expenses SET status='cancelled' WHERE id=?", [id]);
    await recordCashMovement(tx, { finAccountId: e.fin_account_id, date: today(), amount: D(e.amount), kind: 'reversal', sourceType: 'expense', sourceId: id, memo: 'reversal', eventKey: `exp:${id}:rev` });
    await reverseBySource(tx, user, 'expense', id, { date: today(), reason });
    await audit(tx, { userId: user.id, action: 'cancel', entity: 'expense', entityId: id, details: { reason } });
  });
}
export async function expensesByCategory(db, { from, to }) {
  const rows = await db.all("SELECT category_code, amount FROM expenses WHERE status='valid' AND exp_date>=? AND exp_date<=?", [from, to]);
  const m = new Map();
  for (const r of rows) m.set(r.category_code, (m.get(r.category_code) ?? Dec.zero()).add(r.amount));
  return [...m].map(([category, total]) => ({ category, total })).sort((a, b) => b.total.cmp(a.total));
}

/** Reconciliation: cash/bank records vs the general ledger, per ledger account. Any difference is a discrepancy to investigate. */
export async function reconcileCash(db) {
  const out = [];
  for (const g of await db.all('SELECT ledger_account FROM financial_accounts GROUP BY ledger_account')) {
    let cash = Dec.zero();
    for (const f of await db.all('SELECT id FROM financial_accounts WHERE ledger_account=?', [g.ledger_account])) cash = cash.add(await cashBalance(db, f.id));
    const l = await db.get('SELECT COALESCE(SUM(debit_u),0) d, COALESCE(SUM(credit_u),0) c FROM journal_lines WHERE account_code=?', [g.ledger_account]);
    const ledger = new Dec(BigInt(l.d) - BigInt(l.c));
    out.push({ ledgerAccount: g.ledger_account, cash, ledger, difference: cash.sub(ledger), ok: cash.eq(ledger) });
  }
  return out;
}
