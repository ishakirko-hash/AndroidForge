// Android driver: talks to the native @capacitor-community/sqlite plugin through the Capacitor bridge (window.Capacitor),
// so no bundler is needed. Same interface as the other drivers. NOT YET VERIFIED ON A DEVICE (see IMPLEMENTATION_STATUS.md).
const MAX = BigInt(Number.MAX_SAFE_INTEGER);
const val = (v) => (typeof v === 'bigint' ? (v <= MAX && v >= -MAX ? Number(v) : v.toString()) : v); // bridge cannot carry BigInt

export async function createCapacitorDriver(database = 'khaldi_erp') {
  const cap = window.Capacitor;
  if (!cap?.registerPlugin) throw new Error('Capacitor bridge not available');
  const SQL = cap.registerPlugin('CapacitorSQLite');
  try { await SQL.createConnection({ database, version: 1, encrypted: false, mode: 'no-encryption', readonly: false }); }
  catch (e) { if (!/already|exist/i.test(String(e?.message ?? e))) throw e; }
  await SQL.open({ database, readonly: false });
  await SQL.execute({ database, statements: 'PRAGMA foreign_keys = ON;', transaction: false });
  let queue = Promise.resolve();
  const api = {
    async exec(sql) {
      if (/^\s*PRAGMA/i.test(sql)) await SQL.execute({ database, statements: sql.trim().endsWith(';') ? sql : `${sql};`, transaction: false });
      else await SQL.run({ database, statement: sql, values: [], transaction: false }); // single statement (keeps trigger bodies intact)
    },
    async run(sql, params = []) { const r = await SQL.run({ database, statement: sql, values: params.map(val), transaction: false }); return { changes: r.changes?.changes ?? 0, lastId: r.changes?.lastId ?? 0 }; },
    async all(sql, params = []) { const r = await SQL.query({ database, statement: sql, values: params.map(val) }); return (r.values ?? []).filter((x) => !('ios_columns' in x)); },
    async get(sql, params = []) { return (await api.all(sql, params))[0] ?? null; },
    transaction(fn) {
      const run = async () => {
        await SQL.beginTransaction({ database });
        try { const out = await fn(api); await SQL.commitTransaction({ database }); return out; }
        catch (e) { try { await SQL.rollbackTransaction({ database }); } catch { /* already closed */ } throw e; }
      };
      const p = queue.then(run, run); queue = p.catch(() => {}); return p;
    },
    async close() { await SQL.closeConnection({ database, readonly: false }); },
  };
  return api;
}
