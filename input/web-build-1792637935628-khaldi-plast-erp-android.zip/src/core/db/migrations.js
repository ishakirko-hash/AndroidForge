// Forward-only, checksummed migrations. Applied migrations are never edited; schema changes add a new version.
import { MIGRATIONS } from './schema.js';

function checksum(s) { // FNV-1a 32-bit (tamper/edit detection, not security)
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(16).padStart(8, '0');
}

export async function migrate(db, migrations = MIGRATIONS) {
  await db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY, name TEXT NOT NULL, checksum TEXT NOT NULL, applied_at TEXT NOT NULL)`);
  const applied = new Map((await db.all('SELECT version, checksum FROM schema_migrations')).map((r) => [r.version, r.checksum]));
  const sorted = [...migrations].sort((a, b) => a.version - b.version);
  const maxApplied = Math.max(0, ...applied.keys());
  const ran = [];
  for (const m of sorted) {
    const sum = checksum(m.sql);
    if (applied.has(m.version)) {
      if (applied.get(m.version) !== sum) throw new Error(`Migration ${m.version} (${m.name}) was modified after being applied`);
      continue;
    }
    if (m.version < maxApplied) throw new Error(`Migration ${m.version} is older than the database version ${maxApplied}`);
    await db.transaction(async (tx) => {
      for (const stmt of splitStatements(m.sql)) await tx.exec(stmt);
      await tx.run('INSERT INTO schema_migrations(version,name,checksum,applied_at) VALUES (?,?,?,?)',
        [m.version, m.name, sum, new Date().toISOString()]);
    });
    ran.push(m.version);
  }
  return { ran, current: Math.max(maxApplied, ...ran, 0) };
}

// Splits on ';' at line end while keeping trigger bodies (BEGIN ... END;) intact.
function splitStatements(sql) {
  const out = []; let buf = ''; let inTrigger = false;
  for (const line of sql.split('\n')) {
    buf += line + '\n';
    const t = line.trim().toUpperCase();
    if (/^CREATE TRIGGER/.test(t)) inTrigger = true;
    if (inTrigger ? /^END;$/.test(t) : t.endsWith(';')) { out.push(buf.trim()); buf = ''; inTrigger = false; }
  }
  if (buf.trim()) out.push(buf.trim());
  return out;
}
