// Migration list. NEVER edit an entry once released; append a new version instead.
export const MIGRATIONS = [
  {
    version: 1,
    name: 'foundation',
    sql: `
CREATE TABLE app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE company_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  name TEXT NOT NULL DEFAULT 'KHALDI PLAST',
  address TEXT, wilaya TEXT, commune TEXT, phone TEXT, email TEXT,
  nif TEXT, nis TEXT, rc TEXT, ai TEXT, bank_details TEXT,
  currency TEXT NOT NULL DEFAULT 'DZD',
  default_language TEXT NOT NULL DEFAULT 'fr' CHECK (default_language IN ('fr','ar')),
  updated_at TEXT NOT NULL
);
INSERT INTO company_settings(id, updated_at) VALUES (1, '1970-01-01T00:00:00.000Z');
CREATE TABLE roles (
  id TEXT PRIMARY KEY,
  name_fr TEXT NOT NULL,
  name_ar TEXT NOT NULL
);
INSERT INTO roles(id,name_fr,name_ar) VALUES
 ('admin','Administrateur','مدير النظام'),
 ('manager','Directeur d''usine','مدير المصنع'),
 ('accountant','Comptable','محاسب'),
 ('sales','Commercial','مبيعات'),
 ('warehouse','Magasinier','أمين المخزن'),
 ('prod_supervisor','Chef de production','مشرف الإنتاج'),
 ('prod_operator','Opérateur de production','عامل إنتاج'),
 ('auditor','Auditeur (lecture seule)','مدقق (قراءة فقط)');
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  role_id TEXT NOT NULL REFERENCES roles(id),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  user_id TEXT,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT,
  details TEXT
);
CREATE INDEX idx_audit_entity ON audit_log(entity, entity_id);
CREATE INDEX idx_audit_ts ON audit_log(ts);
CREATE TRIGGER audit_log_no_update BEFORE UPDATE ON audit_log
BEGIN
  SELECT RAISE(ABORT, 'audit_log is append-only');
END;
CREATE TRIGGER audit_log_no_delete BEFORE DELETE ON audit_log
BEGIN
  SELECT RAISE(ABORT, 'audit_log is append-only');
END;
CREATE TABLE doc_sequences (
  key TEXT PRIMARY KEY,
  next_value INTEGER NOT NULL CHECK (next_value >= 1)
);
CREATE TABLE processed_events (
  event_key TEXT PRIMARY KEY,
  created_at TEXT NOT NULL
);
`,
  },
  {
    version: 2,
    name: 'catalog_inventory_production',
    sql: `
CREATE TABLE locations (id TEXT PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO locations(id,name) VALUES ('MAIN','Principal');
CREATE TABLE products (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL UNIQUE,
  name_fr TEXT NOT NULL, name_ar TEXT,
  category TEXT, color TEXT, dimensions TEXT,
  unit TEXT NOT NULL DEFAULT 'pcs',
  unit_weight_g TEXT,
  sale_price TEXT NOT NULL DEFAULT '0',
  min_stock TEXT NOT NULL DEFAULT '0',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  notes TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE materials (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL, category TEXT,
  unit TEXT NOT NULL CHECK (unit IN ('kg','g','t','pcs','l')),
  min_stock TEXT NOT NULL DEFAULT '0',
  purchase_cost TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  notes TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE recipes (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  version INTEGER NOT NULL CHECK (version >= 1),
  effective_date TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (product_id, version)
);
CREATE TABLE recipe_lines (
  recipe_id TEXT NOT NULL REFERENCES recipes(id),
  material_id TEXT NOT NULL REFERENCES materials(id),
  qty_per_unit TEXT NOT NULL,
  unit TEXT NOT NULL CHECK (unit IN ('kg','g','t','pcs','l')),
  loss_pct TEXT NOT NULL DEFAULT '0',
  PRIMARY KEY (recipe_id, material_id)
);
CREATE TABLE stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_key TEXT NOT NULL UNIQUE,
  item_type TEXT NOT NULL CHECK (item_type IN ('product','material')),
  item_id TEXT NOT NULL,
  location_id TEXT NOT NULL DEFAULT 'MAIN' REFERENCES locations(id),
  movement_type TEXT NOT NULL CHECK (movement_type IN
    ('opening','receipt','production_consumption','production_output','dispatch','customer_return','supplier_return',
     'damage','waste','recovery','adjustment_in','adjustment_out')),
  qty_u INTEGER NOT NULL CHECK (qty_u <> 0),
  source_doc TEXT, reason TEXT, user_id TEXT, ts TEXT NOT NULL
);
CREATE INDEX idx_stock_item ON stock_movements(item_type, item_id);
CREATE TRIGGER stock_no_update BEFORE UPDATE ON stock_movements
BEGIN
  SELECT RAISE(ABORT, 'stock_movements is append-only');
END;
CREATE TRIGGER stock_no_delete BEFORE DELETE ON stock_movements
BEGIN
  SELECT RAISE(ABORT, 'stock_movements is append-only');
END;
CREATE TRIGGER stock_no_negative BEFORE INSERT ON stock_movements
BEGIN
  SELECT RAISE(ABORT, 'negative stock not allowed')
  WHERE (SELECT COALESCE(SUM(qty_u),0) FROM stock_movements
         WHERE item_type = NEW.item_type AND item_id = NEW.item_id AND location_id = NEW.location_id) + NEW.qty_u < 0;
END;
CREATE TABLE production_orders (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  product_id TEXT NOT NULL REFERENCES products(id),
  recipe_id TEXT NOT NULL REFERENCES recipes(id),
  planned_qty TEXT NOT NULL,
  total_qty TEXT, accepted_qty TEXT, rejected_qty TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','planned','in_progress','completed','cancelled')),
  machine TEXT, shift TEXT, operator TEXT, planned_date TEXT,
  started_at TEXT, finished_at TEXT, notes TEXT, created_at TEXT NOT NULL
);
CREATE TABLE production_materials (
  order_id TEXT NOT NULL REFERENCES production_orders(id),
  material_id TEXT NOT NULL REFERENCES materials(id),
  expected_qty TEXT NOT NULL,
  actual_qty TEXT,
  actual_source TEXT CHECK (actual_source IN ('measured','calculated')),
  PRIMARY KEY (order_id, material_id)
);
`,
  },
  {
    version: 3,
    name: 'sales_receivables',
    sql: `
CREATE TABLE tax_rates (
  code TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  rate_pct TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE customers (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL, phone TEXT, email TEXT, address TEXT, wilaya TEXT, commune TEXT,
  nif TEXT, nis TEXT, rc TEXT, category TEXT,
  credit_limit TEXT NOT NULL DEFAULT '0',
  payment_terms_days INTEGER NOT NULL DEFAULT 30 CHECK (payment_terms_days >= 0),
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE suppliers (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL, phone TEXT, email TEXT, address TEXT, wilaya TEXT,
  nif TEXT, nis TEXT, rc TEXT,
  payment_terms_days INTEGER NOT NULL DEFAULT 30 CHECK (payment_terms_days >= 0),
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE sales_orders (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  order_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','confirmed','partially_delivered','delivered','cancelled')),
  notes TEXT, created_at TEXT NOT NULL
);
CREATE TABLE sales_order_lines (
  order_id TEXT NOT NULL REFERENCES sales_orders(id),
  line_no INTEGER NOT NULL,
  product_id TEXT NOT NULL REFERENCES products(id),
  qty TEXT NOT NULL, unit_price TEXT NOT NULL, discount_pct TEXT NOT NULL DEFAULT '0',
  PRIMARY KEY (order_id, line_no)
);
CREATE TABLE delivery_notes (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  order_id TEXT NOT NULL REFERENCES sales_orders(id),
  customer_id TEXT NOT NULL REFERENCES customers(id),
  delivery_date TEXT NOT NULL,
  notes TEXT, created_at TEXT NOT NULL
);
CREATE TABLE delivery_lines (
  note_id TEXT NOT NULL REFERENCES delivery_notes(id),
  order_id TEXT NOT NULL,
  line_no INTEGER NOT NULL,
  product_id TEXT NOT NULL REFERENCES products(id),
  qty TEXT NOT NULL,
  PRIMARY KEY (note_id, line_no)
);
CREATE TABLE invoices (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  order_id TEXT REFERENCES sales_orders(id),
  issue_date TEXT NOT NULL, due_date TEXT NOT NULL,
  subtotal_ht TEXT NOT NULL, discount_total TEXT NOT NULL, tax_total TEXT NOT NULL, total_ttc TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','cancelled')),
  notes TEXT, created_at TEXT NOT NULL, cancelled_at TEXT, cancel_reason TEXT
);
CREATE INDEX idx_invoices_customer ON invoices(customer_id);
CREATE TABLE invoice_lines (
  invoice_id TEXT NOT NULL REFERENCES invoices(id),
  line_no INTEGER NOT NULL,
  product_id TEXT REFERENCES products(id),
  description TEXT NOT NULL,
  qty TEXT NOT NULL, unit_price TEXT NOT NULL, discount_pct TEXT NOT NULL,
  tax_code TEXT, tax_rate_pct TEXT NOT NULL,
  line_gross TEXT NOT NULL, line_ht TEXT NOT NULL, line_tax TEXT NOT NULL, line_ttc TEXT NOT NULL,
  PRIMARY KEY (invoice_id, line_no)
);
CREATE TRIGGER invoice_core_immutable BEFORE UPDATE OF number, customer_id, issue_date, due_date, subtotal_ht, discount_total, tax_total, total_ttc ON invoices
BEGIN
  SELECT RAISE(ABORT, 'issued invoice values are immutable; use cancellation or a credit note');
END;
CREATE TRIGGER invoice_no_delete BEFORE DELETE ON invoices
BEGIN
  SELECT RAISE(ABORT, 'invoices cannot be deleted');
END;
CREATE TRIGGER invoice_lines_immutable BEFORE UPDATE ON invoice_lines
BEGIN
  SELECT RAISE(ABORT, 'invoice lines are immutable');
END;
CREATE TRIGGER invoice_lines_no_delete BEFORE DELETE ON invoice_lines
BEGIN
  SELECT RAISE(ABORT, 'invoice lines are immutable');
END;
CREATE TABLE credit_notes (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  invoice_id TEXT NOT NULL REFERENCES invoices(id),
  customer_id TEXT NOT NULL REFERENCES customers(id),
  issue_date TEXT NOT NULL,
  total_ttc TEXT NOT NULL,
  reason TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE payments (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  event_key TEXT NOT NULL UNIQUE,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  pay_date TEXT NOT NULL,
  amount TEXT NOT NULL,
  method TEXT NOT NULL CHECK (method IN ('cash','bank_transfer','cheque','other')),
  reference TEXT,
  status TEXT NOT NULL DEFAULT 'valid' CHECK (status IN ('valid','cancelled')),
  created_at TEXT NOT NULL
);
CREATE TABLE payment_allocations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id TEXT NOT NULL REFERENCES payments(id),
  invoice_id TEXT NOT NULL REFERENCES invoices(id),
  amount TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TRIGGER alloc_immutable BEFORE UPDATE ON payment_allocations
BEGIN
  SELECT RAISE(ABORT, 'allocations are immutable; cancel the payment instead');
END;
CREATE TRIGGER alloc_no_delete BEFORE DELETE ON payment_allocations
BEGIN
  SELECT RAISE(ABORT, 'allocations are immutable; cancel the payment instead');
END;
`,
  },
  {
    version: 4,
    name: 'accounting_cash_purchasing',
    sql: `
CREATE TABLE accounts (
  code TEXT PRIMARY KEY,
  name_fr TEXT NOT NULL, name_ar TEXT,
  type TEXT NOT NULL CHECK (type IN ('asset','liability','equity','revenue','expense')),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);
CREATE TABLE account_roles (
  role TEXT PRIMARY KEY,
  account_code TEXT NOT NULL REFERENCES accounts(code)
);
CREATE TABLE accounting_periods (
  period TEXT PRIMARY KEY,
  status TEXT NOT NULL CHECK (status IN ('open','closed')),
  closed_at TEXT
);
CREATE TABLE journal_entries (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  entry_date TEXT NOT NULL,
  period TEXT NOT NULL,
  description TEXT NOT NULL,
  source_type TEXT, source_id TEXT,
  created_by TEXT, created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX idx_journal_source ON journal_entries(source_type, source_id) WHERE source_type IS NOT NULL;
CREATE TABLE journal_lines (
  entry_id TEXT NOT NULL REFERENCES journal_entries(id),
  line_no INTEGER NOT NULL,
  account_code TEXT NOT NULL REFERENCES accounts(code),
  debit_u INTEGER NOT NULL DEFAULT 0,
  credit_u INTEGER NOT NULL DEFAULT 0,
  memo TEXT,
  PRIMARY KEY (entry_id, line_no),
  CHECK (debit_u >= 0 AND credit_u >= 0 AND (debit_u = 0 OR credit_u = 0) AND (debit_u + credit_u) > 0)
);
CREATE INDEX idx_jl_account ON journal_lines(account_code);
CREATE TRIGGER je_no_update BEFORE UPDATE ON journal_entries
BEGIN
  SELECT RAISE(ABORT, 'posted journal entries are immutable; post a reversal');
END;
CREATE TRIGGER je_no_delete BEFORE DELETE ON journal_entries
BEGIN
  SELECT RAISE(ABORT, 'posted journal entries are immutable; post a reversal');
END;
CREATE TRIGGER jl_no_update BEFORE UPDATE ON journal_lines
BEGIN
  SELECT RAISE(ABORT, 'posted journal entries are immutable; post a reversal');
END;
CREATE TRIGGER jl_no_delete BEFORE DELETE ON journal_lines
BEGIN
  SELECT RAISE(ABORT, 'posted journal entries are immutable; post a reversal');
END;
CREATE TABLE financial_accounts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('cash','bank')),
  ledger_account TEXT NOT NULL REFERENCES accounts(code),
  opening_balance_u INTEGER NOT NULL DEFAULT 0,
  allow_negative INTEGER NOT NULL DEFAULT 0 CHECK (allow_negative IN (0,1)),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE cash_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_key TEXT NOT NULL UNIQUE,
  fin_account_id TEXT NOT NULL REFERENCES financial_accounts(id),
  move_date TEXT NOT NULL,
  amount_u INTEGER NOT NULL CHECK (amount_u <> 0),
  kind TEXT NOT NULL CHECK (kind IN ('customer_receipt','supplier_payment','expense','transfer_in','transfer_out','reversal','other')),
  source_type TEXT, source_id TEXT, memo TEXT, created_at TEXT NOT NULL
);
CREATE TRIGGER cash_no_update BEFORE UPDATE ON cash_movements
BEGIN
  SELECT RAISE(ABORT, 'cash_movements is append-only');
END;
CREATE TRIGGER cash_no_delete BEFORE DELETE ON cash_movements
BEGIN
  SELECT RAISE(ABORT, 'cash_movements is append-only');
END;
ALTER TABLE payments ADD COLUMN fin_account_id TEXT REFERENCES financial_accounts(id);
CREATE TABLE expense_categories (
  code TEXT PRIMARY KEY,
  name_fr TEXT NOT NULL, name_ar TEXT,
  account_code TEXT NOT NULL REFERENCES accounts(code)
);
CREATE TABLE expenses (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  event_key TEXT NOT NULL UNIQUE,
  exp_date TEXT NOT NULL,
  category_code TEXT NOT NULL REFERENCES expense_categories(code),
  amount TEXT NOT NULL,
  fin_account_id TEXT NOT NULL REFERENCES financial_accounts(id),
  description TEXT, reference TEXT,
  status TEXT NOT NULL DEFAULT 'valid' CHECK (status IN ('valid','cancelled')),
  created_at TEXT NOT NULL
);
CREATE TABLE purchase_orders (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  supplier_id TEXT NOT NULL REFERENCES suppliers(id),
  order_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','partially_received','received','cancelled')),
  notes TEXT, created_at TEXT NOT NULL
);
CREATE TABLE po_lines (
  po_id TEXT NOT NULL REFERENCES purchase_orders(id),
  line_no INTEGER NOT NULL,
  material_id TEXT NOT NULL REFERENCES materials(id),
  qty TEXT NOT NULL, unit_price TEXT NOT NULL,
  PRIMARY KEY (po_id, line_no)
);
CREATE TABLE goods_receipts (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  po_id TEXT NOT NULL REFERENCES purchase_orders(id),
  supplier_id TEXT NOT NULL REFERENCES suppliers(id),
  receipt_date TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE receipt_lines (
  receipt_id TEXT NOT NULL REFERENCES goods_receipts(id),
  po_id TEXT NOT NULL, line_no INTEGER NOT NULL,
  material_id TEXT NOT NULL REFERENCES materials(id),
  qty TEXT NOT NULL,
  PRIMARY KEY (receipt_id, line_no)
);
CREATE TABLE supplier_invoices (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  supplier_id TEXT NOT NULL REFERENCES suppliers(id),
  supplier_ref TEXT NOT NULL,
  po_id TEXT REFERENCES purchase_orders(id),
  issue_date TEXT NOT NULL, due_date TEXT NOT NULL,
  debit_account_code TEXT REFERENCES accounts(code),
  subtotal_ht TEXT NOT NULL, tax_total TEXT NOT NULL, total_ttc TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','cancelled')),
  created_at TEXT NOT NULL,
  UNIQUE (supplier_id, supplier_ref)
);
CREATE TABLE supplier_invoice_lines (
  invoice_id TEXT NOT NULL REFERENCES supplier_invoices(id),
  line_no INTEGER NOT NULL,
  description TEXT NOT NULL, qty TEXT NOT NULL, unit_price TEXT NOT NULL,
  tax_code TEXT, tax_rate_pct TEXT NOT NULL, line_ht TEXT NOT NULL, line_tax TEXT NOT NULL,
  PRIMARY KEY (invoice_id, line_no)
);
CREATE TRIGGER sinv_core_immutable BEFORE UPDATE OF number, supplier_id, supplier_ref, issue_date, due_date, subtotal_ht, tax_total, total_ttc ON supplier_invoices
BEGIN
  SELECT RAISE(ABORT, 'supplier invoice values are immutable');
END;
CREATE TABLE supplier_payments (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  event_key TEXT NOT NULL UNIQUE,
  supplier_id TEXT NOT NULL REFERENCES suppliers(id),
  fin_account_id TEXT NOT NULL REFERENCES financial_accounts(id),
  pay_date TEXT NOT NULL, amount TEXT NOT NULL,
  method TEXT NOT NULL CHECK (method IN ('cash','bank_transfer','cheque','other')),
  reference TEXT, created_at TEXT NOT NULL
);
CREATE TABLE supplier_payment_allocations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id TEXT NOT NULL REFERENCES supplier_payments(id),
  invoice_id TEXT NOT NULL REFERENCES supplier_invoices(id),
  amount TEXT NOT NULL
);
CREATE TRIGGER spa_immutable BEFORE UPDATE ON supplier_payment_allocations
BEGIN
  SELECT RAISE(ABORT, 'allocations are immutable');
END;
CREATE TRIGGER spa_no_delete BEFORE DELETE ON supplier_payment_allocations
BEGIN
  SELECT RAISE(ABORT, 'allocations are immutable');
END;
CREATE TRIGGER sinv_no_delete BEFORE DELETE ON supplier_invoices
BEGIN
  SELECT RAISE(ABORT, 'supplier invoices cannot be deleted');
END;
CREATE TRIGGER sinv_lines_update BEFORE UPDATE ON supplier_invoice_lines
BEGIN
  SELECT RAISE(ABORT, 'supplier invoice lines are immutable');
END;
CREATE TRIGGER sinv_lines_delete BEFORE DELETE ON supplier_invoice_lines
BEGIN
  SELECT RAISE(ABORT, 'supplier invoice lines are immutable');
END;
`,
  },
  {
    version: 5,
    name: 'costing_operations',
    sql: `
ALTER TABLE stock_movements ADD COLUMN value_u INTEGER NOT NULL DEFAULT 0;
ALTER TABLE stock_movements ADD COLUMN cost_known INTEGER NOT NULL DEFAULT 0;
ALTER TABLE production_orders ADD COLUMN material_cost TEXT;
ALTER TABLE production_orders ADD COLUMN unit_cost TEXT;
ALTER TABLE production_orders ADD COLUMN cost_complete INTEGER;
CREATE TABLE shifts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  start_time TEXT NOT NULL, end_time TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);
CREATE TABLE employees (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL, job_title TEXT, department TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','left')),
  start_date TEXT, default_shift_id TEXT REFERENCES shifts(id),
  hourly_cost TEXT, skills TEXT, notes TEXT, created_at TEXT NOT NULL
);
CREATE TABLE attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_id TEXT NOT NULL REFERENCES employees(id),
  work_date TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('present','absent','leave','holiday')),
  hours TEXT NOT NULL DEFAULT '0', overtime_hours TEXT NOT NULL DEFAULT '0',
  shift_id TEXT REFERENCES shifts(id), notes TEXT,
  UNIQUE (employee_id, work_date)
);
CREATE TABLE machines (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL, line TEXT, manufacturer TEXT, model TEXT,
  rated_capacity_per_hour TEXT, installed_on TEXT,
  status TEXT NOT NULL DEFAULT 'operational' CHECK (status IN ('operational','maintenance','down')),
  notes TEXT, created_at TEXT NOT NULL
);
CREATE TABLE machine_capacity (
  machine_id TEXT NOT NULL REFERENCES machines(id),
  product_id TEXT NOT NULL REFERENCES products(id),
  units_per_hour TEXT NOT NULL,
  PRIMARY KEY (machine_id, product_id)
);
CREATE TABLE maintenance_plans (
  id TEXT PRIMARY KEY,
  machine_id TEXT NOT NULL REFERENCES machines(id),
  task TEXT NOT NULL,
  interval_days INTEGER NOT NULL CHECK (interval_days > 0),
  start_date TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);
CREATE TABLE maintenance_records (
  id TEXT PRIMARY KEY,
  machine_id TEXT NOT NULL REFERENCES machines(id),
  plan_id TEXT REFERENCES maintenance_plans(id),
  kind TEXT NOT NULL CHECK (kind IN ('preventive','corrective')),
  done_on TEXT NOT NULL,
  cost TEXT NOT NULL DEFAULT '0',
  downtime_min INTEGER NOT NULL DEFAULT 0 CHECK (downtime_min >= 0),
  description TEXT, created_at TEXT NOT NULL
);
CREATE TABLE shift_records (
  id TEXT PRIMARY KEY,
  shift_id TEXT NOT NULL REFERENCES shifts(id),
  work_date TEXT NOT NULL,
  machine_id TEXT NOT NULL REFERENCES machines(id),
  operator_id TEXT NOT NULL REFERENCES employees(id),
  production_order_id TEXT NOT NULL REFERENCES production_orders(id),
  produced_qty TEXT NOT NULL, accepted_qty TEXT NOT NULL, rejected_qty TEXT NOT NULL,
  downtime_min INTEGER NOT NULL DEFAULT 0 CHECK (downtime_min >= 0),
  downtime_reason TEXT, notes TEXT,
  reviewed_by TEXT, reviewed_at TEXT, created_at TEXT NOT NULL,
  UNIQUE (shift_id, work_date, machine_id, operator_id, production_order_id)
);
CREATE TABLE quality_inspections (
  id TEXT PRIMARY KEY,
  production_order_id TEXT NOT NULL REFERENCES production_orders(id),
  product_id TEXT NOT NULL REFERENCES products(id),
  inspected_on TEXT NOT NULL,
  inspected_qty TEXT NOT NULL, accepted_qty TEXT NOT NULL, rejected_qty TEXT NOT NULL,
  defect_category TEXT, defect_description TEXT,
  machine_id TEXT REFERENCES machines(id), shift_id TEXT REFERENCES shifts(id),
  inspector TEXT, corrective_action TEXT, notes TEXT, created_at TEXT NOT NULL
);
CREATE TABLE waste_records (
  id TEXT PRIMARY KEY,
  production_order_id TEXT REFERENCES production_orders(id),
  material_id TEXT NOT NULL REFERENCES materials(id),
  qty TEXT NOT NULL, recovered_qty TEXT NOT NULL DEFAULT '0',
  reason TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE budgets (
  id TEXT PRIMARY KEY,
  period TEXT NOT NULL,
  category_code TEXT NOT NULL REFERENCES expense_categories(code),
  amount TEXT NOT NULL,
  UNIQUE (period, category_code)
);
`,
  },
  {
    version: 6,
    name: 'backup_log',
    sql: `
CREATE TABLE backup_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('create','restore')),
  status TEXT NOT NULL CHECK (status IN ('ok','failed')),
  detail TEXT
);
`,
  },
];
