// Driver used by automated tests and tooling (Node's built-in SQLite). Not shipped in the APK.
import { DatabaseSync } from 'node:sqlite';

export function createNodeDriver(path = ':memory:') {
  const raw = new DatabaseSync(path);
  raw.exec('PRAGMA foreign_keys = ON;');
  let queue = Promise.resolve();
  let depth = 0;
  const api = {
    async exec(sql) { raw.exec(sql); },
    async run(sql, params = []) { const r = raw.prepare(sql).run(...params); return { changes: Number(r.changes), lastId: Number(r.lastInsertRowid) }; },
    async all(sql, params = []) { return raw.prepare(sql).all(...params).map((r) => ({ ...r })); },
    async get(sql, params = []) { const r = raw.prepare(sql).get(...params); return r ? { ...r } : null; },
    /** Atomic transaction; rolls back on any thrown error. Calls are serialized. */
    transaction(fn) {
      const run = async () => {
        raw.exec('BEGIN IMMEDIATE');
        try { const out = await fn(api); raw.exec('COMMIT'); return out; }
        catch (e) { raw.exec('ROLLBACK'); throw e; }
      };
      const p = queue.then(run, run);
      queue = p.catch(() => {});
      return p;
    },
    async close() { raw.close(); },
  };
  return api;
}
