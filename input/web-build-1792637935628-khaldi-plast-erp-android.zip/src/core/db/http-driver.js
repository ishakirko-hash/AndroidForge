// Browser driver for the DEV preview bridge (tools/dev-server.mjs). Same interface as the Android driver.
const enc = (_k, v) => (typeof v === 'bigint' ? { $big: v.toString() } : v);
async function call(payload) {
  const w = globalThis; w.__sqlPending = (w.__sqlPending ?? 0) + 1; // lets the dev E2E tests wait until the app is idle
  try { return await rawCall(payload); } finally { w.__sqlPending -= 1; }
}
async function rawCall(payload) {
  const res = await fetch('/__sql', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload, enc) });
  const body = await res.json();
  if (!res.ok) throw new Error(body.error ?? 'SQL bridge error');
  return body;
}
export async function bridgeAvailable() {
  try { return (await fetch('/__sql', { method: 'POST', body: '{"op":"ping"}' })).ok; } catch { return false; }
}
export function createHttpDriver() {
  let queue = Promise.resolve();
  const api = {
    exec: (sql) => call({ op: 'exec', sql }),
    run: (sql, params = []) => call({ op: 'run', sql, params }),
    all: (sql, params = []) => call({ op: 'all', sql, params }),
    get: (sql, params = []) => call({ op: 'get', sql, params }),
    transaction(fn) {
      const run = async () => {
        await call({ op: 'begin' });
        try { const out = await fn(api); await call({ op: 'commit' }); return out; }
        catch (e) { await call({ op: 'rollback' }); throw e; }
      };
      const p = queue.then(run, run); queue = p.catch(() => {}); return p;
    },
    async close() {},
  };
  return api;
}
