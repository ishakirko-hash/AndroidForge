/** Append-only audit record. Call inside the same transaction as the change it describes. */
export async function audit(db, { userId = null, action, entity, entityId = null, details = null }) {
  if (!action || !entity) throw new Error('audit requires action and entity');
  await db.run('INSERT INTO audit_log(ts,user_id,action,entity,entity_id,details) VALUES (?,?,?,?,?,?)',
    [new Date().toISOString(), userId, action, entity, entityId == null ? null : String(entityId),
      details == null ? null : JSON.stringify(details)]);
}
