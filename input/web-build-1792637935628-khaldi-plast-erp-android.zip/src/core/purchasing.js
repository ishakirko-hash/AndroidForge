import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { nextDocumentNumber } from './sequences.js';
import { recordMovement } from './inventory.js';
import { computeRequirements } from './bom.js';
import { computeInvoice } from './invoicing.js';
import { recordCashMovement } from './cash.js';
import { autoPost } from './postings.js';
import { uid, nowIso } from './ids.js';
import { today, addDays } from './dates.js';

const yr = (d) => Number(d.slice(0, 4));

export async function createPurchaseOrder(db, user, { supplierId, lines, orderDate = today(), notes = null }) {
  requirePermission(user, 'purchases', 'write');
  if (!lines?.length) throw new Error('A purchase order needs at least one line');
  return db.transaction(async (tx) => {
    if (!(await tx.get('SELECT 1 x FROM suppliers WHERE id=? AND active=1', [supplierId]))) throw new Error('Unknown or inactive supplier');
    const id = uid('po_'), number = await nextDocumentNumber(tx, 'purchase_order', yr(orderDate));
    await tx.run('INSERT INTO purchase_orders(id,number,supplier_id,order_date,notes,created_at) VALUES (?,?,?,?,?,?)', [id, number, supplierId, orderDate, notes, nowIso()]);
    let n = 0;
    for (const l of lines) {
      if (!D(l.qty).gt(0)) throw new Error('Quantity must be greater than zero');
      if (D(l.unitPrice).isNegative()) throw new Error('Price must not be negative');
      if (!(await tx.get('SELECT 1 x FROM materials WHERE id=?', [l.materialId]))) throw new Error('Unknown material');
      await tx.run('INSERT INTO po_lines(po_id,line_no,material_id,qty,unit_price) VALUES (?,?,?,?,?)', [id, ++n, l.materialId, D(l.qty).toString(), D(l.unitPrice).toString()]);
    }
    await audit(tx, { userId: user.id, action: 'create', entity: 'purchase_order', entityId: id, details: { number } });
    return { id, number };
  });
}

/** Never approves/sends by itself: a human approves explicitly. Stock is NOT affected until goods are received. */
export async function approvePurchaseOrder(db, user, id) {
  requirePermission(user, 'purchases', 'post');
  return db.transaction(async (tx) => {
    const r = await tx.run("UPDATE purchase_orders SET status='approved' WHERE id=? AND status='draft'", [id]);
    if (!r.changes) throw new Error('Only a draft purchase order can be approved');
    await audit(tx, { userId: user.id, action: 'approve', entity: 'purchase_order', entityId: id });
  });
}

export async function poProgress(db, poId) {
  const out = [];
  for (const l of await db.all('SELECT * FROM po_lines WHERE po_id=? ORDER BY line_no', [poId])) {
    const received = Dec.sum((await db.all('SELECT qty FROM receipt_lines WHERE po_id=? AND line_no=?', [poId, l.line_no])).map((r) => D(r.qty)));
    out.push({ lineNo: l.line_no, materialId: l.material_id, ordered: D(l.qty), received, remaining: D(l.qty).sub(received), unitPrice: D(l.unit_price) });
  }
  return out;
}

/** Goods receipt: increases material stock (once per receipt line) and tracks received vs ordered. Over-receipt is blocked. */
export async function receiveGoods(db, user, poId, { lines, date = today() }) {
  requirePermission(user, 'purchases', 'post');
  if (!lines?.length) throw new Error('Nothing received');
  return db.transaction(async (tx) => {
    const po = await tx.get('SELECT * FROM purchase_orders WHERE id=?', [poId]);
    if (!po) throw new Error('Purchase order not found');
    if (!['approved', 'partially_received'].includes(po.status)) throw new Error(`Cannot receive against an order in status ${po.status}`);
    const prog = await poProgress(tx, poId);
    const id = uid('gr_'), number = await nextDocumentNumber(tx, 'goods_receipt', yr(date));
    await tx.run('INSERT INTO goods_receipts(id,number,po_id,supplier_id,receipt_date,created_at) VALUES (?,?,?,?,?,?)', [id, number, poId, po.supplier_id, date, nowIso()]);
    const seen = new Set();
    for (const l of lines) {
      const p = prog.find((x) => x.lineNo === l.lineNo);
      if (!p) throw new Error(`Unknown PO line ${l.lineNo}`);
      if (seen.has(l.lineNo)) throw new Error('Duplicate line in receipt'); seen.add(l.lineNo);
      const q = D(l.qty);
      if (!q.gt(0)) throw new Error('Received quantity must be greater than zero');
      if (q.gt(p.remaining)) throw new Error(`Over-receipt on line ${l.lineNo}: remaining ${p.remaining}, received ${q}`);
      await tx.run('INSERT INTO receipt_lines(receipt_id,po_id,line_no,material_id,qty) VALUES (?,?,?,?,?)', [id, poId, l.lineNo, p.materialId, q.toString()]);
      await recordMovement(tx, user, { type: 'receipt', itemType: 'material', itemId: p.materialId, qty: q, unitCost: p.unitPrice, eventKey: `gr:${id}:${l.lineNo}`, sourceDoc: number });
    }
    const done = (await poProgress(tx, poId)).every((x) => x.remaining.isZero());
    await tx.run('UPDATE purchase_orders SET status=? WHERE id=?', [done ? 'received' : 'partially_received', poId]);
    await audit(tx, { userId: user.id, action: 'receive', entity: 'goods_receipt', entityId: id, details: { number, poId } });
    return { id, number, poStatus: done ? 'received' : 'partially_received' };
  });
}

/**
 * Builds a DRAFT purchase order from production shortages. Uses each material's configured purchase cost;
 * materials without a configured cost are returned in `missingPrice` and left out (no invented prices). Never approved automatically.
 */
export async function draftPoFromShortages(db, user, { supplierId, recipeId, plannedQty }) {
  requirePermission(user, 'purchases', 'write');
  const req = await computeRequirements(db, recipeId, plannedQty);
  const lines = [], missingPrice = [];
  for (const l of req.lines.filter((x) => x.shortage.gt(0))) {
    const m = await db.get('SELECT purchase_cost FROM materials WHERE id=?', [l.materialId]);
    if (m.purchase_cost == null) missingPrice.push(l.ref); else lines.push({ materialId: l.materialId, qty: l.shortage, unitPrice: m.purchase_cost });
  }
  if (!lines.length) return { po: null, missingPrice, note: lines.length ? '' : 'no priced shortages' };
  return { po: await createPurchaseOrder(db, user, { supplierId, lines, notes: 'Brouillon généré depuis un besoin de production' }), missingPrice };
}

/** Supplier invoice (invoice-driven valuation in this version: stock value is booked when the supplier invoice is recorded). */
export async function recordSupplierInvoice(db, user, { supplierId, supplierRef, lines, poId = null, issueDate = today(), dueDate, debitAccountCode = null }) {
  requirePermission(user, 'suppliers', 'post');
  if (!supplierRef?.trim()) throw new Error('supplierRef is required');
  if (!lines?.length) throw new Error('An invoice needs at least one line');
  return db.transaction(async (tx) => {
    const s = await tx.get('SELECT * FROM suppliers WHERE id=?', [supplierId]);
    if (!s) throw new Error('Unknown supplier');
    if (await tx.get('SELECT 1 x FROM supplier_invoices WHERE supplier_id=? AND supplier_ref=?', [supplierId, supplierRef.trim()])) throw new Error(`Supplier invoice ${supplierRef} already recorded`);
    const resolved = [];
    for (const l of lines) {
      if (!D(l.qty).gt(0) || D(l.unitPrice).isNegative()) throw new Error('Invalid quantity or price');
      let rate = '0';
      if (l.taxCode) { const t = await tx.get('SELECT rate_pct, active FROM tax_rates WHERE code=?', [l.taxCode]); if (!t || !t.active) throw new Error(`Unknown or inactive tax code ${l.taxCode}`); rate = t.rate_pct; }
      resolved.push({ ...l, taxRatePct: rate, discountPct: '0' });
    }
    const calc = computeInvoice(resolved);
    const id = uid('sinv_'), number = await nextDocumentNumber(tx, 'supplier_invoice', yr(issueDate));
    await tx.run(`INSERT INTO supplier_invoices(id,number,supplier_id,supplier_ref,po_id,issue_date,due_date,debit_account_code,subtotal_ht,tax_total,total_ttc,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, [id, number, supplierId, supplierRef.trim(), poId, issueDate, dueDate ?? addDays(issueDate, s.payment_terms_days), debitAccountCode,
      calc.subtotalHt.toString(), calc.taxTotal.toString(), calc.totalTtc.toString(), nowIso()]);
    let n = 0;
    for (const l of calc.lines) await tx.run('INSERT INTO supplier_invoice_lines(invoice_id,line_no,description,qty,unit_price,tax_code,tax_rate_pct,line_ht,line_tax) VALUES (?,?,?,?,?,?,?,?,?)',
      [id, ++n, l.description, D(l.qty).toString(), D(l.unitPrice).toString(), l.taxCode ?? null, D(l.taxRatePct).toString(), l.ht.toString(), l.tax.toString()]);
    const posting = await autoPost(tx, user, 'supplier_invoice', id);
    await audit(tx, { userId: user.id, action: 'record', entity: 'supplier_invoice', entityId: id, details: { number, total: calc.totalTtc.toString() } });
    return { id, number, totals: calc, posting };
  });
}

export async function supplierInvoiceOutstanding(db, invoiceId) {
  const i = await db.get("SELECT total_ttc FROM supplier_invoices WHERE id=? AND status='issued'", [invoiceId]);
  if (!i) return Dec.zero();
  return D(i.total_ttc).sub(Dec.sum((await db.all('SELECT amount FROM supplier_payment_allocations WHERE invoice_id=?', [invoiceId])).map((r) => D(r.amount))));
}
/** Payables = issued supplier invoices - payments (every supplier payment must be fully allocated, so no advances here). */
export async function supplierBalance(db, supplierId) {
  let total = Dec.zero();
  for (const i of await db.all("SELECT id FROM supplier_invoices WHERE supplier_id=? AND status='issued'", [supplierId])) total = total.add(await supplierInvoiceOutstanding(db, i.id));
  return total;
}

/** Payment is fully allocated to invoices of that supplier and cannot exceed what is owed. Money leaves the chosen cash/bank account. */
export async function paySupplier(db, user, { supplierId, finAccountId, amount, method, reference = null, payDate = today(), eventKey, allocations }) {
  requirePermission(user, 'suppliers', 'post');
  const amt = D(amount);
  if (!amt.gt(0)) throw new Error('Payment amount must be greater than zero');
  if (!eventKey) throw new Error('eventKey is required');
  if (!allocations?.length) throw new Error('Allocations are required');
  return db.transaction(async (tx) => {
    const dup = await tx.get('SELECT id, number FROM supplier_payments WHERE event_key=?', [eventKey]);
    if (dup) return { duplicate: true, ...dup };
    if (!amt.eq(Dec.sum(allocations.map((a) => D(a.amount))))) throw new Error('Allocations must add up to the payment amount');
    const id = uid('spay_'), number = await nextDocumentNumber(tx, 'supplier_payment', yr(payDate));
    await tx.run('INSERT INTO supplier_payments(id,number,event_key,supplier_id,fin_account_id,pay_date,amount,method,reference,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [id, number, eventKey, supplierId, finAccountId, payDate, amt.toString(), method, reference, nowIso()]);
    const seen = new Set();
    for (const a of allocations) {
      if (seen.has(a.invoiceId)) throw new Error('Invoice appears twice in allocation'); seen.add(a.invoiceId);
      const inv = await tx.get("SELECT supplier_id FROM supplier_invoices WHERE id=? AND status='issued'", [a.invoiceId]);
      if (!inv || inv.supplier_id !== supplierId) throw new Error('Invoice not found for this supplier');
      const out = await supplierInvoiceOutstanding(tx, a.invoiceId);
      if (D(a.amount).gt(out)) throw new Error(`Payment ${D(a.amount)} exceeds the outstanding liability ${out}`);
      if (!D(a.amount).gt(0)) throw new Error('Allocation must be greater than zero');
      await tx.run('INSERT INTO supplier_payment_allocations(payment_id,invoice_id,amount) VALUES (?,?,?)', [id, a.invoiceId, D(a.amount).toString()]);
    }
    await recordCashMovement(tx, { finAccountId, date: payDate, amount: amt.neg(), kind: 'supplier_payment', sourceType: 'supplier_payment', sourceId: id, memo: number, eventKey: `spay:${id}` });
    const posting = await autoPost(tx, user, 'supplier_payment', id);
    await audit(tx, { userId: user.id, action: 'pay', entity: 'supplier_payment', entityId: id, details: { number, amount: amt.toString() } });
    return { duplicate: false, id, number, posting };
  });
}
