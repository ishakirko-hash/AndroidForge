import { D, Dec } from './decimal.js';
import { audit } from './audit.js';
import { requirePermission } from './permissions.js';
import { addDays, daysBetween } from './dates.js';
import { shiftMinutes } from './hr.js';
import { uid, nowIso } from './ids.js';

const need = (v, n) => { if (v == null || String(v).trim() === '') throw new Error(`${n} is required`); return String(v).trim(); };

export async function createMachine(db, user, m) {
  requirePermission(user, 'machines', 'write');
  const ref = need(m.ref, 'ref'), name = need(m.name, 'name');
  if (m.rated_capacity_per_hour != null && !D(m.rated_capacity_per_hour).gt(0)) throw new Error('Capacity must be greater than zero');
  return db.transaction(async (tx) => {
    if (await tx.get('SELECT 1 x FROM machines WHERE ref=?', [ref])) throw new Error(`Duplicate machine reference: ${ref}`);
    const id = uid('mc_');
    await tx.run('INSERT INTO machines(id,ref,name,line,manufacturer,model,rated_capacity_per_hour,installed_on,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [id, ref, name, m.line ?? null, m.manufacturer ?? null, m.model ?? null, m.rated_capacity_per_hour == null ? null : D(m.rated_capacity_per_hour).toString(), m.installed_on ?? null, m.notes ?? null, nowIso()]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'machine', entityId: id, details: { ref } }); return id;
  });
}
export async function setMachineStatus(db, user, id, status, reason) {
  requirePermission(user, 'machines', 'post');
  if (!['operational', 'maintenance', 'down'].includes(status)) throw new Error('Invalid status');
  return db.transaction(async (tx) => {
    const r = await tx.run('UPDATE machines SET status=? WHERE id=?', [status, id]); if (!r.changes) throw new Error('Machine not found');
    await audit(tx, { userId: user.id, action: 'status', entity: 'machine', entityId: id, details: { status, reason: reason ?? null } });
  });
}
export async function setMachineCapacity(db, user, machineId, productId, unitsPerHour) {
  requirePermission(user, 'machines', 'write');
  if (!D(unitsPerHour).gt(0)) throw new Error('Capacity must be greater than zero');
  return db.transaction(async (tx) => {
    await tx.run('INSERT INTO machine_capacity(machine_id,product_id,units_per_hour) VALUES (?,?,?) ON CONFLICT(machine_id,product_id) DO UPDATE SET units_per_hour=excluded.units_per_hour', [machineId, productId, D(unitsPerHour).toString()]);
    await audit(tx, { userId: user.id, action: 'set_capacity', entity: 'machine', entityId: machineId, details: { productId, unitsPerHour: D(unitsPerHour).toString() } });
  });
}
export async function createMaintenancePlan(db, user, { machineId, task, intervalDays, startDate }) {
  requirePermission(user, 'machines', 'write');
  if (!Number.isInteger(intervalDays) || intervalDays <= 0) throw new Error('intervalDays must be a positive integer');
  return db.transaction(async (tx) => {
    if (!(await tx.get('SELECT 1 x FROM machines WHERE id=?', [machineId]))) throw new Error('Machine not found');
    const id = uid('mp_'); await tx.run('INSERT INTO maintenance_plans(id,machine_id,task,interval_days,start_date) VALUES (?,?,?,?,?)', [id, machineId, need(task, 'task'), intervalDays, startDate]);
    await audit(tx, { userId: user.id, action: 'create', entity: 'maintenance_plan', entityId: id }); return id;
  });
}
export async function recordMaintenance(db, user, { machineId, planId = null, kind, doneOn, cost = '0', downtimeMin = 0, description = null }) {
  requirePermission(user, 'machines', 'post');
  if (!['preventive', 'corrective'].includes(kind)) throw new Error('Invalid kind');
  if (D(cost).isNegative() || !Number.isInteger(downtimeMin) || downtimeMin < 0) throw new Error('Invalid cost or downtime');
  return db.transaction(async (tx) => {
    if (planId && !(await tx.get('SELECT 1 x FROM maintenance_plans WHERE id=? AND machine_id=?', [planId, machineId]))) throw new Error('Plan does not belong to this machine');
    if (!(await tx.get('SELECT 1 x FROM machines WHERE id=?', [machineId]))) throw new Error('Machine not found');
    const id = uid('mr_');
    await tx.run('INSERT INTO maintenance_records(id,machine_id,plan_id,kind,done_on,cost,downtime_min,description,created_at) VALUES (?,?,?,?,?,?,?,?,?)', [id, machineId, planId, kind, doneOn, D(cost).toString(), downtimeMin, description, nowIso()]);
    await audit(tx, { userId: user.id, action: 'record', entity: 'maintenance', entityId: id, details: { kind, cost: D(cost).toString() } }); return id;
  });
}
/** Due date = last completion of the plan (or its start date) + interval. Overdue when due < asOf. */
export async function dueMaintenance(db, { asOf, withinDays = 7 }) {
  const out = [];
  for (const p of await db.all('SELECT p.*, m.ref machine_ref, m.name machine_name FROM maintenance_plans p JOIN machines m ON m.id=p.machine_id WHERE p.active=1')) {
    const last = (await db.get('SELECT MAX(done_on) d FROM maintenance_records WHERE plan_id=?', [p.id])).d ?? p.start_date;
    const due = addDays(last, p.interval_days), daysLeft = daysBetween(asOf, due);
    if (daysLeft <= withinDays) out.push({ planId: p.id, machineRef: p.machine_ref, task: p.task, lastDone: last, dueDate: due, daysLeft, overdue: daysLeft < 0 });
  }
  return out.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
}
export async function maintenanceCostByMachine(db, { from, to }) {
  const m = new Map();
  for (const r of await db.all('SELECT machine_id, cost FROM maintenance_records WHERE done_on>=? AND done_on<=?', [from, to])) m.set(r.machine_id, (m.get(r.machine_id) ?? Dec.zero()).add(r.cost));
  return [...m].map(([machineId, total]) => ({ machineId, total }));
}
/**
 * ESTIMATED utilization = produced units / (productive hours x capacity), productive = shift length - recorded downtime.
 * Uses the product-specific capacity when configured, else the machine's rated capacity; null when no capacity is known.
 */
export async function machineUtilization(db, machineId, { from, to }) {
  const recs = await db.all(`SELECT sr.produced_qty p, sr.downtime_min d, sh.start_time s, sh.end_time e, po.product_id pid FROM shift_records sr
    JOIN shifts sh ON sh.id=sr.shift_id JOIN production_orders po ON po.id=sr.production_order_id WHERE sr.machine_id=? AND sr.work_date>=? AND sr.work_date<=?`, [machineId, from, to]);
  const mc = await db.get('SELECT rated_capacity_per_hour c FROM machines WHERE id=?', [machineId]);
  let produced = Dec.zero(), capacity = Dec.zero(), unknown = false;
  for (const r of recs) {
    const hours = D(String(Math.max(0, shiftMinutes(r.s, r.e) - r.d))).div('60');
    const pc = await db.get('SELECT units_per_hour u FROM machine_capacity WHERE machine_id=? AND product_id=?', [machineId, r.pid]);
    const cap = pc?.u ?? mc.c;
    if (cap == null) { unknown = true; continue; }
    produced = produced.add(r.p); capacity = capacity.add(hours.mul(cap));
  }
  return { producedUnits: produced, capacityUnits: capacity, utilizationPct: Dec.percent(produced, capacity), incomplete: unknown, estimate: true };
}
