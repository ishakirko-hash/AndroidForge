// Automatic journal generation for business documents. Runs INSIDE the document's transaction.
// Posting only happens when the needed account roles are configured; otherwise the document is kept and reported as pending.
import { D, Dec } from './decimal.js';
import { requirePermission } from './permissions.js';
import { postEntry, resolveRoles } from './ledger.js';

const need = (...r) => r;
const valueOf = async (tx, prefix) => (await tx.get('SELECT COALESCE(SUM(value_u),0) v FROM stock_movements WHERE substr(event_key,1,?)=?', [prefix.length, prefix])).v;
const BUILDERS = {
  production_order: async (tx, id) => {
    const o = await tx.get("SELECT * FROM production_orders WHERE id=? AND status='completed'", [id]); if (!o) return null;
    const used = new Dec(-BigInt(await valueOf(tx, `prod:${id}:cons:`)));
    if (!used.gt(0)) return { unavailable: 'no_cost_value' };
    const accepted = D(o.accepted_qty).gt(0);
    return { roles: need('inventory_materials', accepted ? 'inventory_finished' : 'production_waste'), date: (o.finished_at ?? o.created_at).slice(0, 10), description: `Production ${o.number}`,
      build: (r) => [{ account: accepted ? r.inventory_finished : r.production_waste, debit: used }, { account: r.inventory_materials, credit: used }] };
  },
  delivery_note: async (tx, id) => {
    const d = await tx.get('SELECT * FROM delivery_notes WHERE id=?', [id]); if (!d) return null;
    const cogs = new Dec(-BigInt(await valueOf(tx, `dn:${id}:`)));
    if (!cogs.gt(0)) return { unavailable: 'no_cost_value' };
    return { roles: need('cogs', 'inventory_finished'), date: d.delivery_date, description: `Coût des ventes ${d.number}`,
      build: (r) => [{ account: r.cogs, debit: cogs }, { account: r.inventory_finished, credit: cogs }] };
  },
  invoice: async (tx, id) => {
    const i = await tx.get("SELECT * FROM invoices WHERE id=? AND status='issued'", [id]); if (!i) return null;
    const tax = D(i.tax_total);
    return { roles: need('receivable', 'sales_revenue', ...(tax.gt(0) ? ['tax_collected'] : [])), date: i.issue_date, description: `Facture ${i.number}`,
      build: (r) => [{ account: r.receivable, debit: i.total_ttc }, { account: r.sales_revenue, credit: i.subtotal_ht }, ...(tax.gt(0) ? [{ account: r.tax_collected, credit: i.tax_total }] : [])] };
  },
  credit_note: async (tx, id) => {
    const c = await tx.get('SELECT * FROM credit_notes WHERE id=?', [id]); if (!c) return null;
    const inv = await tx.get('SELECT tax_total, total_ttc FROM invoices WHERE id=?', [c.invoice_id]);
    // tax share is pro-rata to the original invoice (credit notes are amount-based in this version)
    const tax = D(inv.total_ttc).isZero() ? Dec.zero() : D(c.total_ttc).mul(inv.tax_total).div(inv.total_ttc).round(2);
    const ht = D(c.total_ttc).sub(tax);
    return { roles: need('receivable', 'sales_revenue', ...(tax.gt(0) ? ['tax_collected'] : [])), date: c.issue_date, description: `Avoir ${c.number}`,
      build: (r) => [{ account: r.sales_revenue, debit: ht }, ...(tax.gt(0) ? [{ account: r.tax_collected, debit: tax }] : []), { account: r.receivable, credit: c.total_ttc }] };
  },
  customer_payment: async (tx, id) => {
    const p = await tx.get("SELECT * FROM payments WHERE id=? AND status='valid'", [id]); if (!p) return null;
    if (!p.fin_account_id) return { unavailable: 'no_financial_account' };
    const fa = await tx.get('SELECT ledger_account FROM financial_accounts WHERE id=?', [p.fin_account_id]);
    return { roles: need('receivable'), date: p.pay_date, description: `Règlement ${p.number}`,
      build: (r) => [{ account: fa.ledger_account, debit: p.amount }, { account: r.receivable, credit: p.amount }] };
  },
  supplier_invoice: async (tx, id) => {
    const i = await tx.get("SELECT * FROM supplier_invoices WHERE id=? AND status='issued'", [id]); if (!i) return null;
    const tax = D(i.tax_total);
    return { roles: need('payable', ...(tax.gt(0) ? ['tax_deductible'] : []), ...(i.debit_account_code ? [] : ['inventory_materials'])), date: i.issue_date,
      description: `Facture fournisseur ${i.number} (${i.supplier_ref})`,
      build: (r) => [{ account: i.debit_account_code ?? r.inventory_materials, debit: i.subtotal_ht }, ...(tax.gt(0) ? [{ account: r.tax_deductible, debit: i.tax_total }] : []), { account: r.payable, credit: i.total_ttc }] };
  },
  supplier_payment: async (tx, id) => {
    const p = await tx.get('SELECT * FROM supplier_payments WHERE id=?', [id]); if (!p) return null;
    const fa = await tx.get('SELECT ledger_account FROM financial_accounts WHERE id=?', [p.fin_account_id]);
    return { roles: need('payable'), date: p.pay_date, description: `Paiement fournisseur ${p.number}`,
      build: (r) => [{ account: r.payable, debit: p.amount }, { account: fa.ledger_account, credit: p.amount }] };
  },
};
export const POSTABLE_KINDS = Object.keys(BUILDERS);

export async function autoPost(tx, user, kind, id) {
  const b = await BUILDERS[kind]?.(tx, id);
  if (!b) return { skipped: true, reason: 'nothing_to_post' };
  if (b.unavailable) return { skipped: true, reason: b.unavailable };
  const { map, missing } = await resolveRoles(tx, b.roles);
  if (missing.length) return { skipped: true, reason: 'accounting_roles_not_configured', missing };
  const r = await postEntry(tx, user, { date: b.date, description: b.description, sourceType: kind, sourceId: id, lines: b.build(map) });
  return { skipped: false, ...r };
}

const PENDING = {
  invoice: ['invoices', "status='issued'"], credit_note: ['credit_notes', '1=1'],
  customer_payment: ['payments', "status='valid'"], supplier_invoice: ['supplier_invoices', "status='issued'"],
  supplier_payment: ['supplier_payments', '1=1'],
  production_order: ['production_orders', "status='completed'"], delivery_note: ['delivery_notes', '1=1'],
};
/** Catch-up for documents created before accounting was configured. Idempotent; each document is posted in its own transaction. */
export async function postPending(db, user) {
  requirePermission(user, 'accounting', 'post');
  const posted = [], skipped = [];
  for (const kind of POSTABLE_KINDS) {
    const [table, cond] = PENDING[kind];
    for (const r of await db.all(`SELECT id FROM ${table} WHERE ${cond} AND id NOT IN (SELECT source_id FROM journal_entries WHERE source_type=?)`, [kind])) {
      const res = await db.transaction((tx) => autoPost(tx, user, kind, r.id));
      (res.skipped ? skipped : posted).push({ kind, id: r.id, ...(res.skipped ? { reason: res.reason, missing: res.missing } : {}) });
    }
  }
  return { posted, skipped };
}
