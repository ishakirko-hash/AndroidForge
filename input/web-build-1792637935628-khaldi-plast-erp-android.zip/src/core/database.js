import { migrate } from './db/migrations.js';
/** Opens the schema on any driver; safe to call at every start (applies only pending migrations). */
export async function initDatabase(driver) {
  const res = await migrate(driver);
  return { db: driver, schemaVersion: res.current, migrationsRun: res.ran };
}
