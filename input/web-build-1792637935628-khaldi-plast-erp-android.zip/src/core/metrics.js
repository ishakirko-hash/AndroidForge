import { D, Dec } from './decimal.js';
// All ratios return null (not 0, not NaN) when the denominator is zero.

export const netWeight = (gross, tare) => {
  const n = D(gross).sub(tare);
  if (n.isNegative()) throw new Error('Tare weight exceeds gross weight');
  return n;
};
/** Actual average unit weight = measured total net weight / measured quantity. */
export const avgUnitWeight = (totalNet, qty) => (D(qty).gt(0) ? D(totalNet).div(qty) : null);
export const acceptedWeight = (acceptedQty, avgNetUnitWeight) => D(acceptedQty).mul(avgNetUnitWeight);
/** rejection rate = rejected / total produced x 100 */
export const rejectionRate = (rejected, total) => Dec.percent(rejected, total);
/** completion = accepted / planned accepted x 100 */
export const completionRate = (accepted, planned) => Dec.percent(accepted, planned);
/** material consumed per accepted unit */
export const materialPerAccepted = (consumed, accepted) => (D(accepted).gt(0) ? D(consumed).div(accepted) : null);
export const outputPerHour = (qty, hours) => (D(hours).gt(0) ? D(qty).div(hours) : null);
