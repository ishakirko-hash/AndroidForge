// Backup / restore. Format: JSON manifest {format, formatVersion, schemaVersion, createdAt, counts, checksum, tables}.
// Included: every business table (incl. financial history, stock ledger, production, audit log, settings).
// Excluded: schema_migrations (kept from the running app) and backup_log (device-local state).
// NOT included yet: encryption of the file, native file picking (Storage Access Framework) — both belong to the Android layer.
import { requirePermission } from './permissions.js';
import { audit } from './audit.js';
import { verifyLedgerIntegrity } from './ledger.js';
import { nowIso } from './ids.js';

const FORMAT = 'khaldi-erp-backup', FORMAT_VERSION = 1;
const EXCLUDED = ['schema_migrations', 'backup_log'];

async function sha256(text) {
  const buf = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
const userTables = async (db) => (await db.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")).map((r) => r.name).filter((n) => !EXCLUDED.includes(n));
const logEvent = (db, kind, status, detail) => db.run('INSERT INTO backup_log(ts,kind,status,detail) VALUES (?,?,?,?)', [nowIso(), kind, status, detail ?? null]);
const schemaVersion = async (db) => (await db.get('SELECT MAX(version) v FROM schema_migrations')).v ?? 0;

export async function createBackup(db, user) {
  requirePermission(user, 'backup', 'write');
  try {
    const tables = {}, counts = {};
    for (const t of await userTables(db)) {
      const columns = (await db.all(`PRAGMA table_info(${t})`)).map((c) => c.name);
      const rows = (await db.all(`SELECT * FROM ${t} ORDER BY rowid`)).map((r) => columns.map((c) => r[c]));
      for (const row of rows) for (const v of row) if (typeof v === 'number' && !Number.isSafeInteger(v) && Number.isInteger(v)) throw new Error(`Unsafe integer in ${t}`);
      tables[t] = { columns, rows }; counts[t] = rows.length;
    }
    const manifest = { format: FORMAT, formatVersion: FORMAT_VERSION, schemaVersion: await schemaVersion(db), createdAt: nowIso(), counts, checksum: await sha256(JSON.stringify(tables)), tables };
    const text = JSON.stringify(manifest);
    await logEvent(db, 'create', 'ok', `${Object.values(counts).reduce((a, b) => a + b, 0)} rows, ${text.length} bytes`);
    return { text, manifest: { ...manifest, tables: undefined } };
  } catch (e) { await logEvent(db, 'create', 'failed', e.message); throw e; }
}

/** Validates a backup without touching any data. Returns the parsed manifest or throws a specific reason. */
export async function validateBackup(db, text) {
  let m;
  try { m = JSON.parse(text); } catch { throw new Error('Backup file is not valid JSON'); }
  if (m?.format !== FORMAT) throw new Error('Not a KHALDI PLAST ERP backup');
  if (m.formatVersion !== FORMAT_VERSION) throw new Error(`Unsupported backup format version ${m.formatVersion}`);
  if (!m.tables || typeof m.tables !== 'object') throw new Error('Backup has no data');
  if ((await sha256(JSON.stringify(m.tables))) !== m.checksum) throw new Error('Backup integrity check failed (checksum mismatch): the file is damaged or was modified');
  const current = await schemaVersion(db);
  if (m.schemaVersion > current) throw new Error(`Backup comes from a newer app version (schema ${m.schemaVersion} > ${current}); update the app first`);
  const have = new Set(await userTables(db));
  for (const [t, d] of Object.entries(m.tables)) {
    if (!have.has(t)) throw new Error(`Backup contains an unknown table: ${t}`);
    const cols = new Set((await db.all(`PRAGMA table_info(${t})`)).map((c) => c.name));
    for (const c of d.columns) if (!cols.has(c)) throw new Error(`Backup column ${t}.${c} does not exist in this app version`);
    if (d.rows.length !== m.counts[t]) throw new Error(`Row count mismatch in ${t}`);
  }
  return m;
}

/**
 * Replaces ALL business data with the backup, atomically. Requires confirm:true (UI must ask the user). If anything fails —
 * foreign keys, counts, ledger integrity — the transaction rolls back and the current data is untouched.
 * Returns the safety backup of the data that was replaced, to be saved by the caller.
 */
export async function restoreBackup(db, user, text, { confirm = false } = {}) {
  requirePermission(user, 'backup', 'admin');
  if (confirm !== true) throw new Error('Restore replaces all current data and must be confirmed explicitly');
  const m = await validateBackup(db, text);
  const safety = await createBackup(db, user);
  try {
    await db.transaction(async (tx) => {
      await tx.exec('PRAGMA defer_foreign_keys = ON');
      const triggers = await tx.all("SELECT name, sql FROM sqlite_master WHERE type='trigger'");
      for (const t of triggers) await tx.exec(`DROP TRIGGER ${t.name}`);
      for (const t of await userTables(tx)) await tx.exec(`DELETE FROM ${t}`);
      for (const [t, d] of Object.entries(m.tables)) {
        if (!d.rows.length) continue;
        const sql = `INSERT INTO ${t}(${d.columns.join(',')}) VALUES (${d.columns.map(() => '?').join(',')})`;
        for (const row of d.rows) await tx.run(sql, row);
      }
      for (const t of triggers) await tx.exec(t.sql);
      for (const t of await userTables(tx)) {
        const n = (await tx.get(`SELECT COUNT(*) n FROM ${t}`)).n;
        if (n !== (m.counts[t] ?? 0)) throw new Error(`Post-restore count mismatch in ${t}`);
      }
      const bad = await verifyLedgerIntegrity(tx);
      if (bad.length) throw new Error(`Restored ledger is unbalanced (${bad.join(', ')})`);
      await audit(tx, { userId: user.id, action: 'restore', entity: 'database', details: { backupCreatedAt: m.createdAt, schemaVersion: m.schemaVersion } });
    });
  } catch (e) { await logEvent(db, 'restore', 'failed', e.message); throw e; }
  await logEvent(db, 'restore', 'ok', `from backup of ${m.createdAt}`);
  return { restored: m.counts, safetyBackup: safety.text };
}

export const backupHistory = (db) => db.all('SELECT * FROM backup_log ORDER BY id DESC LIMIT 50');
