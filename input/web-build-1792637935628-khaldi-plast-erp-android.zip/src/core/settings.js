import { audit } from './audit.js';
import { requirePermission } from './permissions.js';

const FIELDS = ['name', 'address', 'wilaya', 'commune', 'phone', 'email', 'nif', 'nis', 'rc', 'ai', 'bank_details', 'default_language'];

export async function getCompany(db) { return db.get('SELECT * FROM company_settings WHERE id=1'); }

/** Updates company identity. Legal identifiers are stored only as entered; the app never invents them. */
export async function updateCompany(db, user, patch) {
  requirePermission(user, 'settings', 'admin');
  const keys = Object.keys(patch).filter((k) => FIELDS.includes(k));
  if (!keys.length) throw new Error('No valid fields');
  if (patch.default_language && !['fr', 'ar'].includes(patch.default_language)) throw new Error('Invalid language');
  return db.transaction(async (tx) => {
    const before = await getCompany(tx);
    await tx.run(`UPDATE company_settings SET ${keys.map((k) => `${k}=?`).join(',')}, updated_at=? WHERE id=1`,
      [...keys.map((k) => patch[k]), new Date().toISOString()]);
    await audit(tx, { userId: user.id, action: 'update', entity: 'company_settings', entityId: 1,
      details: Object.fromEntries(keys.map((k) => [k, { from: before[k], to: patch[k] }])) });
    return getCompany(tx);
  });
}
