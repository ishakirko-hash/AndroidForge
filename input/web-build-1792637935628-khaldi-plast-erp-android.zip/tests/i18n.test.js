import test from 'node:test';
import assert from 'node:assert/strict';
import { dictionaries, t } from '../src/core/i18n/index.js';
import { MODULES } from '../src/core/permissions.js';

test('French and Arabic define exactly the same keys', () => {
  const fr = Object.keys(dictionaries.fr).sort(), ar = Object.keys(dictionaries.ar).sort();
  assert.deepEqual(fr, ar);
});
test('every module has a navigation label in both languages', () => {
  for (const m of MODULES) for (const l of ['fr', 'ar']) assert.ok(dictionaries[l][`nav.${m}`], `${l} nav.${m}`);
});
test('no empty strings; params interpolate; missing key is visible', () => {
  for (const l of ['fr', 'ar']) for (const [k, v] of Object.entries(dictionaries[l])) assert.ok(v.trim(), `${l}:${k}`);
  assert.equal(t('status.planned', { phase: 3 }, 'fr'), 'Prévu — phase 3');
  assert.equal(t('nope.key'), 'nope.key');
});
