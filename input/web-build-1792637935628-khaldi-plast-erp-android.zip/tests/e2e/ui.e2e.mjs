// End-to-end UI test: real browser (Chromium) -> real UI -> real core -> real SQLite (via the dev bridge).
// Run: node tests/e2e/ui.e2e.mjs   (needs Playwright; not part of `npm test`)
import assert from 'node:assert/strict';
let chromium;
try { ({ chromium } = await import('playwright')); } catch { ({ chromium } = await import('/home/claude/.npm-global/lib/node_modules/playwright/index.mjs')); }
import { startDevServer } from '../../tools/dev-server.mjs';

const srv = await startDevServer({ port: 8791 });
const base = `http://127.0.0.1:${srv.port}`;
const browser = await chromium.launch();
const errors = [];
async function open(role = 'admin') {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const p = await ctx.newPage(); p.on('pageerror', (e) => errors.push('pageerror: ' + e)); p.on('console', (m) => m.type() === 'error' && errors.push('console: ' + m.text()));
  await p.goto(`${base}/?role=${role}`); await p.waitForSelector('.chip.ok'); return p;
}
const go = async (p, id) => { await p.evaluate((x) => { location.hash = `#/${x}`; }, id); await p.waitForSelector(`#view[data-route="${id}"]`, { timeout: 20000 }); await p.waitForTimeout(80); };
const fill = async (p, name, v) => p.fill(`.sheet [name="${name}"]`, v);
const submit = async (p) => { await p.click('.sheet button[type=submit]'); await settle(p); };
const text = (p, sel = '#view') => p.locator(sel).innerText();
const settle = async (p) => { for (let i = 0; i < 3; i++) { await p.waitForFunction(() => (globalThis.__sqlPending ?? 0) === 0, null, { timeout: 30000 }); await new Promise((r) => setTimeout(r, 150)); } };
const step = (s) => console.log('  ✓', s);

const p = await open();
// ---- materials
await go(p, 'materials');
await p.click('[data-new]'); await fill(p, 'ref', 'RM001'); await fill(p, 'name', 'Granulé bleu'); await fill(p, 'min_stock', '100'); await submit(p);
assert.match(await text(p), /Granulé bleu/); step('material created');
await p.click('[data-new]'); await fill(p, 'ref', 'RM001'); await fill(p, 'name', 'Doublon'); await p.click('.sheet button[type=submit]'); await settle(p);
assert.match(await text(p, '.sheet .form-error'), /existe déjà/); assert.equal(await p.inputValue('.sheet [name="name"]'), 'Doublon'); step('duplicate reference rejected, input preserved');
await p.click('.sheet [data-x]');
await p.click('.card[data-id]'); await p.click('[data-rcv]'); await fill(p, 'qty', '1 000'); await fill(p, 'unitCost', '100,50');
await p.evaluate(() => { const b = document.querySelector('.sheet button[type=submit]'); b.click(); b.click(); }); await settle(p); // double tap on purpose
await p.click('.card[data-id]'); assert.match(await text(p, '.sheet'), /1\s?000/); await p.click('.sheet [data-x]');
await go(p, 'inventory'); await p.click('.card[data-type=material]'); await p.waitForSelector('.sheet table');
assert.equal(await p.locator('.sheet table tr').count(), 2, 'exactly one receipt movement after a double tap'); step('double-tap posts one receipt only');
await p.click('.sheet [data-x]');
assert.match(await text(p), /100.500,00 DA/, 'valuation shows 1000 x 100.50'); step('valuation = 100 500,00 DA');
// ---- product + recipe
await go(p, 'products');
await p.click('[data-new]'); await fill(p, 'ref', 'PL001'); await fill(p, 'name_fr', 'Grande caisse'); await fill(p, 'name_ar', 'الصندوق الكبير'); await fill(p, 'sale_price', '950'); await submit(p);
await p.click('.card'); await p.click('[data-rc]'); await p.fill('.sheet [data-qty]', '0,8'); await p.fill('.sheet [data-loss]', '5'); await p.click('.sheet button[type=submit]'); await settle(p);
await p.click('.card'); assert.match(await text(p, '.sheet'), /0\.8 kg/); assert.match(await text(p, '.sheet'), /Version 1|version 1/i); await p.click('.sheet [data-x]'); step('product + recipe v1');
// ---- production: preview, plan, start, complete
await go(p, 'production');
await p.click('[data-new]'); await p.fill('#po_q', '100'); await settle(p);
assert.match(await text(p, '#po_prev'), /84/); assert.match(await text(p, '#po_prev'), /8.442,00/); step('live requirement preview: 84 kg, est. cost 8 442,00');
await p.click('.sheet button[type=submit]'); await p.waitForSelector('.sheet [data-act=plan]');
assert.match(await text(p, '.sheet'), /OF-\d{4}-0001/); await p.click('[data-act=plan]'); await settle(p);
await p.click('.card'); await p.click('[data-act=start]'); await settle(p);
await p.click('.card'); await p.click('[data-act=complete]');
await fill(p, 'total', '100'); await fill(p, 'accepted', '90'); await fill(p, 'rejected', '5'); await p.fill('.sheet [data-cons]', '84');
await p.click('.sheet button[type=submit]'); await settle(p);
assert.match(await text(p, '.sheet .form-error'), /Accepté \+ rejeté/); assert.equal(await p.inputValue('.sheet [data-cons]'), '84'); step('accepted+rejected mismatch rejected, input preserved');
await fill(p, 'rejected', '10'); await p.click('.sheet button[type=submit]'); await settle(p);
await p.click('.card'); const done = await text(p, '.sheet');
assert.match(done, /Terminé/); assert.match(done, /10,00 %/); assert.match(done, /90,00 %/); assert.match(done, /93,80 DA/); // isolates keep unit order // 84 kg x 100.50 = 8 442 / 90 accepted
step('completed: rejection 10,00 %, completion 90,00 %, unit cost 93,80 DA'); await p.click('.sheet [data-x]');
assert.equal(await p.locator('[data-act]').count(), 0); step('no completion action left (no duplicate completion)');
// ---- stock effects visible in inventory
await go(p, 'inventory'); const inv = await text(p);
assert.match(inv, /Grande caisse[\s\S]*90/); assert.match(inv, /916/); step('stock: product 90, resin 916');
// ---- insufficient stock: whole completion rolled back, order stays in progress
await go(p, 'production'); await p.click('[data-new]'); await p.fill('#po_q', '2000'); await settle(p);
assert.match(await text(p, '#po_prev'), /1\s?680/); await p.click('.sheet button[type=submit]'); await p.waitForSelector('.sheet [data-act=plan]');
assert.match(await text(p, '.sheet .warn'), /Manque/); await p.click('[data-act=plan]'); await settle(p);
await p.click('.card:first-child'); await p.click('[data-act=start]'); await settle(p);
await p.click('.card:first-child'); await p.click('[data-act=complete]');
await fill(p, 'total', '10'); await fill(p, 'accepted', '10'); await fill(p, 'rejected', '0'); await p.fill('.sheet [data-cons]', '5000');
await p.click('.sheet button[type=submit]'); await settle(p);
assert.match(await text(p, '.sheet .form-error'), /Stock insuffisant/); await p.click('.sheet [data-x]');
assert.match(await text(p, '.card:first-child'), /En cours/); step('insufficient stock: error shown, order unchanged');
await p.click('.card:first-child'); await p.click('[data-act=cancel]'); await settle(p); assert.match(await text(p, '.card:first-child'), /Annulé/); step('order cancelled');
await go(p, 'inventory'); assert.match(await text(p), /916/); step('stock untouched by the failed completion and the cancellation');
// ---- dashboard with real figures and alerts
await go(p, 'dashboard'); const dash = await text(p);
assert.match(dash, /90.{0,2}pcs/); assert.match(dash, /sauvegarde/i); step('dashboard: produced today 90 pcs, backup alert shown');
// ---- Arabic / RTL on every built screen, no horizontal overflow
for (const id of ['dashboard', 'products', 'materials', 'inventory', 'production']) {
  await go(p, id); if (id === 'dashboard') await p.click('[data-lang-toggle]'); await settle(p);
  assert.equal(await p.evaluate(() => document.documentElement.dir), 'rtl');
  assert.ok(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `horizontal overflow on ${id} (ar)`);
  if (id === 'production' || id === 'dashboard') await p.screenshot({ path: `/tmp/ui-ar-${id}.png` });
}
await go(p, 'production'); await p.click('.card:nth-child(2)'); await p.waitForSelector('.sheet'); await p.screenshot({ path: '/tmp/ui-ar-order.png' });
assert.ok(await p.evaluate(() => { const s = document.querySelector('.sheet'); return s.scrollWidth <= s.clientWidth + 1; }), 'sheet overflow (ar)');
await p.click('.sheet [data-x]'); step('Arabic RTL, no overflow on all built screens');
await p.click('[data-lang-toggle]'); await settle(p);
for (const id of ['products', 'materials', 'inventory', 'production']) { await go(p, id); assert.ok(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `overflow ${id} (fr)`); }
await p.screenshot({ path: '/tmp/ui-fr-production.png' });
// ---- permissions in the UI (core also enforces them; see unit tests)
const s = await open('sales'); await go(s, 'products'); assert.equal(await s.locator('[data-new]').count(), 0);
await go(s, 'production'); assert.equal(await s.locator('[data-new]').count(), 0); step('sales role: no create buttons on products/production');
const o = await open('prod_operator'); await go(o, 'production'); assert.equal(await o.locator('[data-new]').count(), 1);
await o.click('.card:first-child'); await o.waitForSelector('.sheet'); assert.equal(await o.locator('.sheet [data-act]').count(), 0); step('operator: can create orders but not start/complete/cancel');
assert.deepEqual(errors, [], 'no console/page errors'); step('no console or page errors');
await browser.close(); await srv.close(); console.log('E2E PASSED');
