// E2E #3: suppliers, purchasing, employees, machines, quality through the real UI.
import assert from 'node:assert/strict';
let chromium;
try { ({ chromium } = await import('playwright')); } catch { ({ chromium } = await import('/home/claude/.npm-global/lib/node_modules/playwright/index.mjs')); }
import { startDevServer } from '../../tools/dev-server.mjs';
const srv = await startDevServer({ port: 8793 }); const base = `http://127.0.0.1:${srv.port}`;
const browser = await chromium.launch(); const errors = [];
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
const p = await ctx.newPage(); p.on('pageerror', (e) => errors.push('pageerror: ' + e)); p.on('console', (m) => m.type() === 'error' && errors.push('console: ' + m.text()));
const settle = async () => { for (let i = 0; i < 3; i++) { await p.waitForFunction(() => (globalThis.__sqlPending ?? 0) === 0, null, { timeout: 30000 }); await new Promise((r) => setTimeout(r, 150)); } };
const go = async (id) => { await p.evaluate((x) => { location.hash = `#/${x}`; }, id); await p.waitForSelector(`#view[data-route="${id}"]`, { timeout: 20000 }); await p.waitForTimeout(80); };
const fill = (sel, v) => p.fill(`.sheet ${sel}`, v); const text = (sel = '#view') => p.locator(sel).innerText(); const submit = async () => { await p.click('.sheet button[type=submit]'); await settle(); };
const step = (s) => console.log('  ✓', s);
await p.goto(`${base}/?role=admin`); await p.waitForSelector('.chip.ok');
await p.evaluate(async () => { const { createHttpDriver } = await import('/src/core/db/http-driver.js'); const { initDatabase } = await import('/src/core/database.js'); const C = await import('/src/core/catalog.js'); const P = await import('/src/core/parties.js'); const S = await import('/src/core/setup.js'); const K = await import('/src/core/cash.js'); const PR = await import('/src/core/production.js'); const I = await import('/src/core/inventory.js');
  const { db } = await initDatabase(createHttpDriver()); const u = { id: 'seed', role: 'admin' };
  await S.setupStarterAccounting(db, u); await K.createFinancialAccount(db, u, { name: 'Caisse', kind: 'cash', ledgerAccount: '5000', openingBalance: '100000', openingEquityAccount: '1000', openingDate: '2026-01-01' });
  await P.setTaxRate(db, u, { code: 'T1', label: 'Taux test', ratePct: '19' });
  const m = await C.createMaterial(db, u, { ref: 'RM001', name: 'Granulé', unit: 'kg', purchase_cost: '100' }); const pr = await C.createProduct(db, u, { ref: 'PL001', name_fr: 'Grande caisse' });
  const rc = await C.createRecipe(db, u, { productId: pr, lines: [{ materialId: m, qtyPerUnit: '0.8' }] }); await I.postMovement(db, u, { type: 'receipt', itemType: 'material', itemId: m, qty: '1000', unitCost: '100', eventKey: 'seed' });
  const o = await PR.createOrder(db, u, { productId: pr, recipeId: rc.id, plannedQty: '100' }); await PR.planOrder(db, u, o.id); await PR.startOrder(db, u, o.id); });
await p.reload(); await p.waitForSelector('.chip.ok');
// suppliers + purchasing
await go('suppliers'); await p.click('[data-new]'); await fill('[name=ref]', 'S001'); await fill('[name=name]', 'Fournisseur Plast'); await submit(); assert.match(await text(), /Fournisseur Plast/); step('supplier created');
await go('purchases'); await p.click('[data-new]'); await fill('[data-qty]', '500'); await submit(); await p.waitForSelector('.sheet [data-act=approve]'); assert.match(await text('.sheet'), /BC-\d{4}-0001/);
await p.click('[data-act=approve]'); await settle(); await p.waitForSelector('.sheet [data-act=receive]');
await p.click('[data-act=receive]'); await fill('[data-line="1"]', '300'); await submit(); await p.waitForSelector('.sheet [data-act=receive]'); assert.match(await text('.sheet'), /Partiellement reçu/); step('PO approved, partial receipt 300/500');
await p.click('[data-act=receive]'); await fill('[data-line="1"]', '300'); await p.click('.sheet button[type=submit]'); await settle(); assert.match(await text('.sheet .form-error'), /Over-receipt|Opération impossible/); step('over-receipt blocked'); await p.click('.sheet [data-x]');
await p.evaluate(() => document.querySelector('.card[data-id]').click()); await p.waitForSelector('.sheet [data-act=receive]'); await p.click('[data-act=receive]'); await fill('[data-line="1"]', '200'); await submit(); await p.waitForSelector('.sheet [data-act=invoice]'); assert.match(await text('.sheet'), /Reçu/); step('fully received');
await p.click('[data-act=invoice]'); await fill('#sr', 'F-100'); await p.selectOption('.sheet #stx', 'T1'); await submit(); await go('suppliers'); assert.match(await text(), /59.500,00/); step('supplier invoice 50 000 + 19 % = 59 500 → payable');
await p.click('.card'); await p.click('[data-pay]'); await fill('#sa', '60000'); await settle(); await p.click('.sheet button[type=submit]'); await settle(); assert.match(await text('.sheet .form-error'), /somme des affectations|dépasse/i); step('overpayment blocked');
await fill('#sa', '20000'); await settle(); assert.equal(await p.inputValue('.sheet [data-alloc]'), '20000'); await submit(); await go('suppliers'); assert.match(await text(), /39.500,00/); step('payment 20 000 → payable 39 500');
await go('inventory'); assert.match(await text(), /1.?500/); step('stock increased only by receipts (1000 + 500)');
// employees
await go('employees'); await p.click('[data-new]'); await fill('[name=ref]', 'E001'); await fill('[name=name]', 'Karim'); await submit(); await p.click('.card'); await p.waitForSelector('.sheet form'); await p.click('.sheet button[type=submit]'); await settle();
await p.click('.card'); assert.match(await text('.sheet'), /1 Présent/); await p.click('.sheet button[type=submit]'); await settle(); assert.match(await text('.sheet .form-error'), /already recorded/); step('attendance recorded once; duplicate day refused'); await p.click('.sheet [data-x]');
// machines
await go('machines'); await p.click('[data-new]'); await fill('[name=ref]', 'M1'); await fill('[name=name]', 'Presse 1'); await submit(); await p.click('.card'); await p.click('[data-plan]'); await fill('[name=task]', 'Graissage'); await fill('[name=interval]', '30');
const old = new Date(Date.now() - 35 * 864e5).toISOString().slice(0, 10); await fill('[name=start]', old); await submit(); await go('machines'); assert.match(await text(), /EN RETARD/); step('maintenance plan overdue shown');
await p.click('.card'); await p.click('[data-rec]'); await p.selectOption('.sheet [name=plan]', { index: 1 }); await fill('[name=cost]', '1500'); await submit(); await go('machines'); assert.doesNotMatch(await text(), /EN RETARD/); step('maintenance recorded → no longer due');
// quality
await go('quality'); await p.click('[data-new]'); await fill('[name=inspected]', '100'); await fill('[name=accepted]', '95'); await fill('[name=rejected]', '5'); await p.click('.sheet button[type=submit]'); await settle(); assert.match(await text('.sheet .form-error'), /obligatoire/i); step('rejection requires a defect category');
await fill('[name=defect]', 'bavure'); await submit(); const q = await text(); assert.match(q, /5\s?\/\s?100/); assert.match(q, /5,00 %/); step('quality report: 5/100 = 5,00 %');
// RTL
await p.click('[data-lang-toggle]'); await settle();
for (const id of ['suppliers', 'purchases', 'employees', 'machines', 'quality']) { await go(id); assert.ok(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `overflow ${id}`); } step('Arabic RTL, no overflow');
assert.deepEqual(errors, []); step('no console or page errors'); await browser.close(); await srv.close(); console.log('OPS E2E PASSED');
