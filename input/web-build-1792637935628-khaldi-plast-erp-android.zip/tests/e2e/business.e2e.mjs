// E2E #2: complete sales-to-cash and accounting flow through the real UI, plus PDF, CSV and backup/restore.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { execSync } from 'node:child_process';
let chromium;
try { ({ chromium } = await import('playwright')); } catch { ({ chromium } = await import('/home/claude/.npm-global/lib/node_modules/playwright/index.mjs')); }
import { startDevServer } from '../../tools/dev-server.mjs';

const srv = await startDevServer({ port: 8792 }); const base = `http://127.0.0.1:${srv.port}`;
const browser = await chromium.launch(); const errors = [];
async function open(role = 'admin') {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, acceptDownloads: true });
  const p = await ctx.newPage(); p.on('pageerror', (e) => errors.push('pageerror: ' + e)); p.on('console', (m) => m.type() === 'error' && errors.push('console: ' + m.text()));
  await p.goto(`${base}/?role=${role}`); await p.waitForSelector('.chip.ok'); return p;
}
const go = async (p, id) => { await p.evaluate((x) => { location.hash = `#/${x}`; }, id); await p.waitForSelector(`#view[data-route="${id}"]`, { timeout: 20000 }); await p.waitForTimeout(80); };
const fill = (p, sel, v) => p.fill(`.sheet ${sel}`, v);
const text = (p, sel = '#view') => p.locator(sel).innerText();
const sheetText = (p) => text(p, '.sheet');
const submit = async (p) => { await p.click('.sheet button[type=submit]'); await settle(p); };
const closeSheet = (p) => p.click('.sheet [data-x]');
const settle = async (p) => { for (let i = 0; i < 3; i++) { await p.waitForFunction(() => (globalThis.__sqlPending ?? 0) === 0, null, { timeout: 30000 }); await new Promise((r) => setTimeout(r, 150)); } };
const step = (s) => console.log('  ✓', s);
const T = new Date().toISOString().slice(0, 4);

const p = await open();
// seed a finished product with stock via the same runtime the app uses (HTTP driver → SQLite)
await p.evaluate(async () => { const { createHttpDriver } = await import('/src/core/db/http-driver.js'); const { initDatabase } = await import('/src/core/database.js'); const { createProduct } = await import('/src/core/catalog.js'); const { postMovement } = await import('/src/core/inventory.js');
  const { db } = await initDatabase(createHttpDriver()); const u = { id: 'seed', role: 'admin' }; const id = await createProduct(db, u, { ref: 'PL001', name_fr: 'Grande caisse', name_ar: 'الصندوق الكبير', sale_price: '950' });
  await postMovement(db, u, { type: 'opening', itemType: 'product', itemId: id, qty: '100', unitCost: '600', eventKey: 'seed:open' }); });
await p.reload(); await p.waitForSelector('.chip.ok');

// ---- settings: company identity, tax rate, starter accounting, cash account
await go(p, 'settings');
await p.click('[data-co]'); await fill(p, '[name=name]', 'KHALDI PLAST'); await fill(p, '[name=address]', 'Zone industrielle (test)'); await fill(p, '[name=nif]', 'NIF-TEST-1'); await submit(p);
await p.click('[data-rate]'); await fill(p, '[name=code]', 'T1'); await fill(p, '[name=label]', 'Taux test'); await fill(p, '[name=rate]', '19'); await submit(p);
assert.match(await text(p), /NIF-TEST-1/); assert.match(await text(p), /Taux test/); step('company identity + tax rate saved');
await p.click('[data-seed]'); await settle(p); assert.match(await text(p), /Comptes liés configurés/);
await p.click('[data-fin]'); await fill(p, '[name=name]', 'Caisse'); await fill(p, '[name=opening]', '50000'); await submit(p);
assert.match(await text(p), /Caisse[\s\S]*50.000,00 DA/); step('starter accounting + cash account with opening balance');
// ---- customer
await go(p, 'customers'); await p.click('[data-new]'); await fill(p, '[name=ref]', 'C001'); await fill(p, '[name=name]', 'Société El Amel'); await fill(p, '[name=nif]', 'NIF-CLIENT-1'); await submit(p);
assert.match(await text(p), /Société El Amel/); step('customer created');
// ---- sales order → confirm → partial deliveries
await go(p, 'sales'); await p.click('[data-new]'); await p.fill('.sheet [data-qty]', '30'); await submit(p);
await p.waitForSelector('.sheet [data-act=confirm]'); assert.match(await sheetText(p), /CMD-\d{4}-0001/);
await p.click('[data-act=confirm]'); await settle(p); await p.waitForSelector('.sheet [data-act=dispatch]');
await p.click('[data-act=dispatch]'); await p.fill('.sheet [data-line="1"]', '15'); await submit(p); await p.waitForSelector('.sheet [data-act=dispatch]');
assert.match(await sheetText(p), /Partiellement livrée/); step('partial delivery 15/30');
await p.click('[data-act=dispatch]'); await p.fill('.sheet [data-line="1"]', '20'); await p.click('.sheet button[type=submit]'); await settle(p);
assert.match(await text(p, '.sheet .form-error'), /supérieure au reste/); step('over-delivery rejected'); await closeSheet(p);
await p.evaluate(() => document.querySelector('.card[data-id]').click()); await p.waitForSelector('.sheet [data-act=dispatch]');
await p.click('[data-act=dispatch]'); await p.fill('.sheet [data-line="1"]', '15'); await submit(p); await p.waitForSelector('.sheet [data-act=invoice]');
assert.match(await sheetText(p), /Livrée/); step('order fully delivered');
// ---- invoice from the order with tax: 30 x 950 = 28 500 HT, 19 % = 5 415, TTC 33 915
await p.click('[data-act=invoice]'); await p.waitForSelector('.sheet #tot'); await p.selectOption('.sheet [data-tax]', 'T1'); await settle(p);
const tot = await text(p, '.sheet #tot'); assert.match(tot, /28.500,00 DA/); assert.match(tot, /5.415,00 DA/); assert.match(tot, /33.915,00 DA/); step('live invoice totals 28 500 / 5 415 / 33 915');
await submit(p); await p.waitForSelector('.sheet [data-doc]');
assert.match(await sheetText(p), new RegExp(`FAC-${T}-0001`)); assert.match(await sheetText(p), /33.915,00 DA/); step('invoice issued');
// ---- A4 document + real PDF
await p.click('[data-doc]'); await p.waitForSelector('.doc'); const doc = await text(p, '.doc');
assert.match(doc, /KHALDI PLAST/); assert.match(doc, /NIF-TEST-1/); assert.match(doc, /Société El Amel/); assert.match(doc, /NIF-CLIENT-1/); assert.match(doc, /33.915,00 DA/); assert.match(doc, /Taxes 19 %/); step('invoice document content (company, customer, tax by rate)');
await p.evaluate(() => document.body.classList.add('printing-doc')); await p.emulateMedia({ media: 'print' });
await p.pdf({ path: '/tmp/invoice-fr.pdf', format: 'A4', printBackground: true, preferCSSPageSize: true });
await p.emulateMedia({ media: 'screen' }); await p.evaluate(() => document.body.classList.remove('printing-doc'));
const info = execSync('pdfinfo /tmp/invoice-fr.pdf').toString(); assert.match(info, /Pages:\s+1/); assert.match(info, /A4|595\.\d+ x 841\.\d+/); assert.equal(fs.readFileSync('/tmp/invoice-fr.pdf').subarray(0, 4).toString(), '%PDF');
const pdfText = execSync('pdftotext -layout /tmp/invoice-fr.pdf -').toString(); assert.match(pdfText, /FAC-\d{4}-0001/); assert.match(pdfText, /33\s?.?915,00/); step('real A4 PDF generated: 1 page, text extractable');
await p.click('.doc-bar [data-x]');
// ---- payment with suggested allocation
await p.click('[data-pay]'); await p.waitForSelector('.sheet #pc'); await p.fill('.sheet #pa', '10000'); await settle(p);
assert.equal(await p.inputValue('.sheet [data-alloc]'), '10000'); await p.selectOption('.sheet #pf', { index: 1 }); await p.fill('.sheet #pr', 'CHQ-1'); await submit(p);
await go(p, 'customers'); assert.match(await text(p), /23.915,00/); step('payment 10 000 allocated → customer balance 23 915,00');
await go(p, 'payments'); assert.match(await text(p), /23.915,00 DA/); step('aging card shows outstanding');
await p.click('[data-new]'); await p.selectOption('.sheet #pc', { index: 1 }); await p.fill('.sheet #pa', '10000'); await settle(p); await p.fill('.sheet #pr', 'CHQ-1'); await p.click('.sheet button[type=submit]'); await settle(p);
assert.match(await text(p, '.sheet .form-error'), /doublon/); step('duplicate payment (same customer/amount/date/reference) blocked'); await p.fill('.sheet #pr', 'CHQ-2');
await p.fill('.sheet #pa', '100'); await settle(p); await p.fill('.sheet [data-alloc]', '999999'); await p.click('.sheet button[type=submit]'); await settle(p);
assert.match(await text(p, '.sheet .form-error'), /dépasse/); step('over-allocation blocked'); await closeSheet(p);
// ---- credit note, cancellation rule
await go(p, 'invoices'); await p.click('.card'); await p.click('[data-cn]'); await p.fill('.sheet #cna', '1000'); await p.fill('.sheet #rs', 'Retour'); await submit(p); await p.waitForSelector('.sheet [data-doc]');
assert.match(await sheetText(p), /22.915,00 DA/); step('credit note 1 000 → outstanding 22 915');
await p.click('[data-cancel]'); await p.fill('.sheet #rs', 'Erreur'); await p.click('.sheet button[type=submit]'); await settle(p);
assert.match(await text(p, '.sheet .form-error'), /credit note|avoir/i); step('invoice with payments cannot be cancelled'); await closeSheet(p);
// ---- expenses and budget
await go(p, 'expenses'); await p.click('[data-new]'); await fill(p, '[name=amount]', '3000'); await fill(p, '[name=description]', 'Facture électricité'); await submit(p);
await p.click('[data-bud]'); await fill(p, '[name=amount]', '5000'); await submit(p);
assert.match(await text(p), /3.000,00 \/ 5.000,00/); step('expense 3 000 paid from cash; budget 5 000 tracked');
// ---- accounting reports tie out: revenue 28 500 − credit-note HT 840,34 = 27 659,66; COGS 18 000 + expense 3 000 → net 6 659,66
await go(p, 'accounting'); const acc = await text(p);
assert.match(acc, /Équilibrée/); assert.match(acc, /27.659,66 DA/); assert.match(acc, /21.000,00 DA/); assert.match(acc, /6.659,66 DA/); step('trial balance balanced; revenue 27 659,66 (after credit note), charges 21 000, net 6 659,66');
// ---- assistant
await go(p, 'assistant'); await p.fill('#q', 'Dette totale des clients ?'); await p.click('#askf button'); await settle(p);
assert.match(await text(p, '#ans'), /22.915,00/); step('assistant answers from real records: customer debt 22 915,00');
await p.fill('#q', 'Supprimer la facture'); await p.click('#askf button'); await settle(p); assert.match(await text(p, '#ans'), /lecture seule/); step('assistant refuses to change data');
// ---- CSV export
await go(p, 'reports'); const [dl] = await Promise.all([p.waitForEvent('download'), p.click('form button[type=submit]')]);
const csv = fs.readFileSync(await dl.path(), 'utf8'); assert.ok(csv.startsWith('\uFEFFnumber,issue_date')); assert.match(csv, new RegExp(`FAC-${T}-0001`)); step('CSV export downloaded with real invoice row');
// ---- backup, then change data, then restore
await go(p, 'backup'); const [bk] = await Promise.all([p.waitForEvent('download'), p.click('[data-create]')]); const bkPath = '/tmp/kp-backup.json'; fs.copyFileSync(await bk.path(), bkPath);
const manifest = JSON.parse(fs.readFileSync(bkPath, 'utf8')); assert.equal(manifest.counts.invoices, 1); step(`backup file created (${Object.values(manifest.counts).reduce((a, b) => a + b, 0)} rows, sha256 sealed)`);
await go(p, 'expenses'); await p.click('[data-new]'); await fill(p, '[name=amount]', '111'); await submit(p); assert.equal(await p.locator('.card').count(), 2);
await go(p, 'backup'); await p.setInputFiles('#bf', bkPath); await settle(p); assert.equal(await p.locator('[data-restore]').isDisabled(), true); await p.check('#bc'); assert.equal(await p.locator('[data-restore]').isDisabled(), false);
const [safety] = await Promise.all([p.waitForEvent('download'), p.click('[data-restore]')]); assert.ok((await safety.suggestedFilename()).includes('safety')); await p.waitForEvent('load', { timeout: 15000 });
await settle(p); await p.waitForSelector('#view[data-route="backup"]', { timeout: 30000 }); await go(p, 'expenses'); assert.equal(await p.locator('.card').count(), 1); step('restore: data returned to the backed-up state, safety backup offered');
await go(p, 'invoices'); assert.match(await text(p), new RegExp(`FAC-${T}-0001`));
// ---- Arabic RTL, overflow, Arabic invoice document + PDF
await p.click('[data-lang-toggle]'); await settle(p);
for (const id of ['customers', 'sales', 'invoices', 'payments', 'settings', 'expenses', 'accounting', 'assistant', 'reports', 'backup', 'audit']) { await go(p, id);
  assert.ok(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `overflow on ${id} (ar)`); }
await go(p, 'invoices'); await p.click('.card'); await p.click('[data-doc]'); await p.waitForSelector('.doc'); assert.equal(await p.evaluate(() => document.querySelector('.doc').dir), 'rtl');
await p.screenshot({ path: '/tmp/doc-ar.png' });
await p.evaluate(() => document.body.classList.add('printing-doc')); await p.emulateMedia({ media: 'print' }); await p.pdf({ path: '/tmp/invoice-ar.pdf', format: 'A4', printBackground: true, preferCSSPageSize: true });
assert.match(execSync('pdfinfo /tmp/invoice-ar.pdf').toString(), /Pages:\s+1/); step('Arabic RTL on all screens (no overflow); Arabic invoice → 1-page PDF');
await p.emulateMedia({ media: 'screen' });
// ---- permissions
const s = await open('sales'); await go(s, 'sales'); assert.equal(await s.locator('[data-new]').count(), 1); await go(s, 'payments'); assert.equal(await s.locator('[data-new]').count(), 0);
await go(s, 'backup'); assert.equal(await s.locator('[data-create]').count(), 0); step('sales role: orders yes, payments/backup no');
assert.deepEqual(errors, [], 'no console/page errors'); step('no console or page errors');
await browser.close(); await srv.close(); console.log('BUSINESS E2E PASSED');
