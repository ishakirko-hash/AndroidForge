import test from 'node:test';
import assert from 'node:assert/strict';
import { D, Dec, convertMass } from '../src/core/decimal.js';

test('0.1 + 0.2 is exactly 0.3 (no binary floating point)', () => {
  assert.equal(D('0.1').add('0.2').toString(), '0.3');
});
test('invoice example: 3 x 1250.50 with 19% tax and 5% discount', () => {
  // independently computed by hand: line=3751.50; disc=187.575 -> net 3563.925; tax 19% = 677.14575
  const line = D('1250.50').mul('3');
  assert.equal(line.toFixed(2), '3751.50');
  const disc = line.mul('0.05');
  const net = line.sub(disc);
  assert.equal(net.toString(), '3563.925');
  const tax = net.mul('0.19');
  assert.equal(tax.toString(), '677.1458'); // 677.14575 rounded half-up at 4 dp
  assert.equal(net.add(tax).toFixed(2), '4241.07'); // 4241.0708 -> 4241.07
});
test('rounding is half away from zero', () => {
  assert.equal(D('2.345').round(2).toString(), '2.35');
  assert.equal(D('-2.345').round(2).toString(), '-2.35');
  assert.equal(D('0.004').round(2).toString(), '0');
});
test('parsing: comma decimals, spaces, rejects floats and garbage', () => {
  assert.equal(D('12,5').toString(), '12.5');
  assert.equal(D('1 250,00').toString(), '1250');
  assert.throws(() => D(0.1));
  assert.throws(() => D('abc'));
  assert.throws(() => D('1.2.3'));
  assert.equal(D(42).toString(), '42');
});
test('division by zero is rejected; percent returns null', () => {
  assert.throws(() => D('1').div('0'), RangeError);
  assert.equal(Dec.percent('5', '0'), null);
  assert.equal(Dec.percent('50', '1000').toString(), '5'); // rejection rate 5%
});
test('formatting fr / ar', () => {
  assert.equal(D('12560000').format('fr'), '12\u202f560\u202f000,00');
  assert.equal(D('12560000').format('ar'), '12,560,000.00');
  assert.equal(D('-1234.5').format('ar'), '-1,234.50');
  assert.equal(D('999').format('fr', 0), '999');
});
test('mass conversion g<->kg<->t', () => {
  assert.equal(convertMass('800', 'g', 'kg').toString(), '0.8');
  assert.equal(convertMass('0.8', 'kg', 'g').toString(), '800');
  assert.equal(convertMass('1.5', 't', 'kg').toString(), '1500');
  assert.throws(() => convertMass('1', 'lb', 'kg'));
});
test('BOM example: 0.8 kg x 1000 units = 800 kg', () => {
  assert.equal(D('0.8').mul('1000').toString(), '800');
});
test('sum of many small amounts has no drift', () => {
  const total = Dec.sum(Array.from({ length: 1000 }, () => D('0.01')));
  assert.equal(total.toString(), '10');
});
