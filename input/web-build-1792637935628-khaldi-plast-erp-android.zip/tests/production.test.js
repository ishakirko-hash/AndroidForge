import test from 'node:test';
import assert from 'node:assert/strict';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { createProduct, createMaterial, createRecipe, archiveItem } from '../src/core/catalog.js';
import { postMovement, getBalance, getHistory, recordMovement, lowStock } from '../src/core/inventory.js';
import { computeRequirements } from '../src/core/bom.js';
import { createOrder, planOrder, startOrder, completeOrder, cancelOrder, orderSummary } from '../src/core/production.js';
import { netWeight, avgUnitWeight, acceptedWeight, rejectionRate } from '../src/core/metrics.js';
import { PermissionError } from '../src/core/permissions.js';
import { D } from '../src/core/decimal.js';

const mgr = { id: 'm1', role: 'manager' };
async function world() {
  const { db } = await initDatabase(createNodeDriver());
  const product = await createProduct(db, mgr, { ref: 'PL001', name_fr: 'Grande caisse', name_ar: 'الصندوق الكبير', unit_weight_g: '1200', sale_price: '950', min_stock: '100' });
  const resin = await createMaterial(db, mgr, { ref: 'RM001', name: 'Granulé', unit: 'kg', min_stock: '100', purchase_cost: '120' });
  const mb = await createMaterial(db, mgr, { ref: 'RM003', name: 'Masterbatch', unit: 'kg', min_stock: '5', purchase_cost: '450' });
  const rcp = await createRecipe(db, mgr, { productId: product, lines: [
    { materialId: resin, qtyPerUnit: '0.8', unit: 'kg', lossPct: '5' },
    { materialId: mb, qtyPerUnit: '20', unit: 'g', lossPct: '0' }] });
  await postMovement(db, mgr, { type: 'opening', itemType: 'material', itemId: resin, qty: '900', eventKey: 'open:resin' });
  await postMovement(db, mgr, { type: 'opening', itemType: 'material', itemId: mb, qty: '15', eventKey: 'open:mb' });
  return { db, product, resin, mb, rcp };
}

test('catalog: duplicate refs rejected, archive instead of delete, validation', async () => {
  const { db, product } = await world();
  await assert.rejects(createProduct(db, mgr, { ref: 'PL001', name_fr: 'x' }), /Duplicate product/);
  await assert.rejects(createProduct(db, mgr, { ref: 'PL9', name_fr: 'x', sale_price: '-1' }), /negative/);
  await assert.rejects(createMaterial(db, mgr, { ref: 'M9', name: 'x', unit: 'lb' }), /Invalid unit/);
  await archiveItem(db, mgr, 'product', product);
  assert.equal((await db.get('SELECT status FROM products WHERE id=?', [product])).status, 'archived');
});
test('permissions: sales cannot create products; operator cannot complete production', async () => {
  const { db, product, rcp } = await world();
  await assert.rejects(createProduct(db, { id: 's', role: 'sales' }, { ref: 'X', name_fr: 'x' }), PermissionError);
  const o = await createOrder(db, { id: 'op', role: 'prod_operator' }, { productId: product, recipeId: rcp.id, plannedQty: '10' });
  await assert.rejects(startOrder(db, { id: 'op', role: 'prod_operator' }, o.id), PermissionError);
});
test('BOM: 1000 units -> resin 840 kg (0.8kg + 5% loss), masterbatch 20 kg (20 g/unit converted), shortage and estimated cost', async () => {
  const { db, rcp, resin, mb } = await world();
  const r = await computeRequirements(db, rcp.id, '1000');
  const by = Object.fromEntries(r.lines.map((l) => [l.materialId, l]));
  assert.equal(by[resin].required.toString(), '840');
  assert.equal(by[resin].shortage.toString(), '0');
  assert.equal(by[mb].required.toString(), '20');
  assert.equal(by[mb].available.toString(), '15');
  assert.equal(by[mb].shortage.toString(), '5');
  assert.equal(r.hasShortage, true);
  assert.equal(r.estimatedMaterialCost.toString(), '109800'); // 840*120 + 20*450
});
test('BOM: cost is null (not guessed) when a material has no cost', async () => {
  const { db, product } = await world();
  const m = await createMaterial(db, mgr, { ref: 'RM9', name: 'Additif', unit: 'kg' });
  const rc = await createRecipe(db, mgr, { productId: product, lines: [{ materialId: m, qtyPerUnit: '0.1' }] });
  assert.equal((await computeRequirements(db, rc.id, '10')).estimatedMaterialCost, null);
});
test('recipes are versioned and old versions stay intact', async () => {
  const { db, product, resin, rcp } = await world();
  const v2 = await createRecipe(db, mgr, { productId: product, lines: [{ materialId: resin, qtyPerUnit: '0.9' }] });
  assert.equal(rcp.version, 1); assert.equal(v2.version, 2);
  assert.equal((await computeRequirements(db, rcp.id, '100')).lines.find((l) => l.materialId === resin).required.toString(), '84');
  assert.equal((await computeRequirements(db, v2.id, '100')).lines[0].required.toString(), '90');
});
test('draft/planned/in-progress orders do not touch stock; replanning recalculates expectations', async () => {
  const { db, product, rcp, resin, mb } = await world();
  const o = await createOrder(db, mgr, { productId: product, recipeId: rcp.id, plannedQty: '1000' });
  assert.match(o.number, /^OF-\d{4}-0001$/);
  await planOrder(db, mgr, o.id);
  await startOrder(db, mgr, o.id);
  assert.equal((await getBalance(db, 'material', resin)).toString(), '900');
  assert.equal((await getBalance(db, 'product', product)).toString(), '0');
  await assert.rejects(planOrder(db, mgr, o.id), /Cannot plan/);
  const o2 = await createOrder(db, mgr, { productId: product, recipeId: rcp.id, plannedQty: '1000' });
  await planOrder(db, mgr, o2.id, { plannedQty: '500' });
  const exp = await db.get('SELECT expected_qty FROM production_materials WHERE order_id=? AND material_id=?', [o2.id, resin]);
  assert.equal(exp.expected_qty, '420');
  void mb;
});
test('full completion: stock moves exactly once, metrics match hand calculation', async () => {
  const { db, product, rcp, resin, mb } = await world();
  await postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: mb, qty: '10', eventKey: 'rcpt:mb1' }); // mb = 25
  const o = await createOrder(db, mgr, { productId: product, recipeId: rcp.id, plannedQty: '1000' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  const s = await completeOrder(db, mgr, o.id, { totalQty: '980', acceptedQty: '950', rejectedQty: '30',
    consumption: [{ materialId: resin, qty: '835' }, { materialId: mb, qty: '19.5' }] });
  assert.equal((await getBalance(db, 'material', resin)).toString(), '65');   // 900-835
  assert.equal((await getBalance(db, 'material', mb)).toString(), '5.5');     // 25-19.5
  assert.equal((await getBalance(db, 'product', product)).toString(), '950');
  assert.equal(s.rejectionRatePct.toString(), '3.0612');                      // 30/980*100
  assert.equal(s.completionRatePct.toString(), '95');                         // 950/1000*100
  assert.equal(s.perMaterial.find((m) => m.materialId === resin).perAcceptedUnit.toString(), '0.8789'); // 835/950
  assert.equal(s.perMaterial[0].source, 'measured');
  // duplicate completion must fail and change nothing
  await assert.rejects(completeOrder(db, mgr, o.id, { totalQty: '980', acceptedQty: '950', rejectedQty: '30', consumption: [{ materialId: resin, qty: '1' }] }), /already completed/);
  assert.equal((await getBalance(db, 'product', product)).toString(), '950');
  assert.equal((await getHistory(db, 'product', product)).length, 1);
  await assert.rejects(cancelOrder(db, mgr, o.id), /Cannot cancel/);
});
test('useExpected records calculated (not measured) consumption scaled to produced total', async () => {
  const { db, product, rcp, resin } = await world();
  const o = await createOrder(db, mgr, { productId: product, recipeId: rcp.id, plannedQty: '1000' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  await assert.rejects(completeOrder(db, mgr, o.id, { totalQty: '10', acceptedQty: '10', rejectedQty: '0' }), /consumption is required/);
  await db.run("UPDATE production_materials SET expected_qty=expected_qty WHERE 1=0");
  const mbBal = await getBalance(db, 'material', (await db.get("SELECT id FROM materials WHERE ref='RM003'")).id);
  assert.equal(mbBal.toString(), '15');
  const s = await completeOrder(db, mgr, o.id, { totalQty: '700', acceptedQty: '700', rejectedQty: '0', useExpected: true });
  const r = s.perMaterial.find((m) => m.materialId === resin);
  assert.equal(r.consumed.toString(), '588'); // 840 * 700/1000
  assert.equal(r.source, 'calculated');
});
test('insufficient material rolls back the whole completion (no partial stock change)', async () => {
  const { db, product, rcp, resin, mb } = await world();
  const o = await createOrder(db, mgr, { productId: product, recipeId: rcp.id, plannedQty: '1000' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  await assert.rejects(completeOrder(db, mgr, o.id, { totalQty: '100', acceptedQty: '100', rejectedQty: '0',
    consumption: [{ materialId: mb, qty: '10' }, { materialId: resin, qty: '1000' }] }), /Insufficient stock/);
  assert.equal((await getBalance(db, 'material', mb)).toString(), '15');
  assert.equal((await getBalance(db, 'material', resin)).toString(), '900');
  assert.equal((await getBalance(db, 'product', product)).toString(), '0');
  assert.equal((await orderSummary(db, o.id)).order.status, 'in_progress');
});
test('accepted + rejected must equal total; negative inputs rejected', async () => {
  const { db, product, rcp, resin } = await world();
  const o = await createOrder(db, mgr, { productId: product, recipeId: rcp.id, plannedQty: '10' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  await assert.rejects(completeOrder(db, mgr, o.id, { totalQty: '10', acceptedQty: '9', rejectedQty: '2', consumption: [{ materialId: resin, qty: '1' }] }), /must equal total/);
  await assert.rejects(completeOrder(db, mgr, o.id, { totalQty: '10', acceptedQty: '-1', rejectedQty: '11', consumption: [] }), /negative/);
});
test('cancel: allowed before completion, never moved stock', async () => {
  const { db, product, rcp, resin } = await world();
  const o = await createOrder(db, mgr, { productId: product, recipeId: rcp.id, plannedQty: '10' });
  await planOrder(db, mgr, o.id); await cancelOrder(db, mgr, o.id);
  assert.equal((await orderSummary(db, o.id)).order.status, 'cancelled');
  assert.equal((await getBalance(db, 'material', resin)).toString(), '900');
});
test('ledger: duplicate event ignored, negative stock blocked (service + DB trigger), history immutable', async () => {
  const { db, resin } = await world();
  const r1 = await postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: resin, qty: '50', eventKey: 'rcpt:1' });
  const r2 = await postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: resin, qty: '50', eventKey: 'rcpt:1' });
  assert.equal(r1.duplicate, false); assert.equal(r2.duplicate, true);
  assert.equal((await getBalance(db, 'material', resin)).toString(), '950');
  await assert.rejects(postMovement(db, mgr, { type: 'waste', itemType: 'material', itemId: resin, qty: '951', eventKey: 'w1' }), /Insufficient/);
  await assert.rejects(db.run("INSERT INTO stock_movements(event_key,item_type,item_id,movement_type,qty_u,ts) VALUES ('raw','material',?,'waste',-99999999999,'t')", [resin]), /negative stock/);
  await assert.rejects(db.run('UPDATE stock_movements SET qty_u=1'), /append-only/);
  await assert.rejects(db.run('DELETE FROM stock_movements'), /append-only/);
  await assert.rejects(postMovement(db, mgr, { type: 'adjustment_out', itemType: 'material', itemId: resin, qty: '1', eventKey: 'a1' }), /reason/);
  await assert.rejects(postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: resin, qty: '0', eventKey: 'z' }), /greater than zero/);
  await assert.rejects(postMovement(db, { id: 'x', role: 'auditor' }, { type: 'receipt', itemType: 'material', itemId: resin, qty: '1', eventKey: 'k' }), PermissionError);
});
test('decimal quantities stay exact in the ledger (0.1 x 3 receipts = 0.3)', async () => {
  const { db, resin } = await world();
  for (let i = 0; i < 3; i++) await postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: resin, qty: '0.1', eventKey: 'd' + i });
  assert.equal((await getBalance(db, 'material', resin)).toString(), '900.3');
});
test('low stock: facts from ledger vs configured minimum', async () => {
  const { db, product, mb } = await world();
  const low = await lowStock(db);
  assert.deepEqual(low.map((l) => l.ref).sort(), ['PL001']); // product 0 <= 100; mb 15 > 5; resin 900 > 100
  await postMovement(db, mgr, { type: 'waste', itemType: 'material', itemId: mb, qty: '10', eventKey: 'w' });
  assert.deepEqual((await lowStock(db)).map((l) => l.ref).sort(), ['PL001', 'RM003']);
});
test('weights: net = gross - tare, average and accepted weight, zero-quantity safe', () => {
  assert.equal(netWeight('25.5', '1.5').toString(), '24');
  assert.throws(() => netWeight('1', '2'), /Tare/);
  assert.equal(avgUnitWeight('24', '20').toString(), '1.2');
  assert.equal(avgUnitWeight('24', '0'), null);
  assert.equal(acceptedWeight('18', '1.2').toString(), '21.6');
  assert.equal(rejectionRate('0', '0'), null);
  assert.equal(D('1200').div('1000').toString(), '1.2');
});

test('BOM cost estimate falls back to the weighted-average stock cost; still null when nothing is known', async () => {
  const { db, product } = await world();
  const m = await createMaterial(db, mgr, { ref: 'RMX', name: 'Sans prix', unit: 'kg' }); // no purchase cost
  const rc = await createRecipe(db, mgr, { productId: product, lines: [{ materialId: m, qtyPerUnit: '2' }] });
  assert.equal((await computeRequirements(db, rc.id, '10')).estimatedMaterialCost, null);
  await postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: m, qty: '100', unitCost: '100.5', eventKey: 'x1' });
  assert.equal((await computeRequirements(db, rc.id, '10')).estimatedMaterialCost.toString(), '2010'); // 20 kg x 100.5
});
