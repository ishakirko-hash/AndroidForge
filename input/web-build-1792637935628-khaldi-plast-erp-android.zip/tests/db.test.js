import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { migrate } from '../src/core/db/migrations.js';
import { audit } from '../src/core/audit.js';
import { nextDocumentNumber } from '../src/core/sequences.js';
import { once } from '../src/core/once.js';
import { can, requirePermission, PermissionError, MODULES, MATRIX } from '../src/core/permissions.js';
import { updateCompany, getCompany } from '../src/core/settings.js';

const fresh = async () => (await initDatabase(createNodeDriver())).db;
const admin = { id: 'u1', role: 'admin' };

test('migrations apply once and are idempotent', async () => {
  const d = createNodeDriver();
  const a = await migrate(d); const b = await migrate(d);
  assert.deepEqual(a.ran, [1, 2, 3, 4, 5, 6]); assert.deepEqual(b.ran, []); assert.equal(b.current, 6);
});
test('editing an applied migration is detected', async () => {
  const d = createNodeDriver();
  await migrate(d, [{ version: 1, name: 'x', sql: 'CREATE TABLE t(a);' }]);
  await assert.rejects(migrate(d, [{ version: 1, name: 'x', sql: 'CREATE TABLE t(a,b);' }]), /modified after being applied/);
});
test('a failing migration rolls back completely and keeps existing data', async () => {
  const d = createNodeDriver();
  await migrate(d, [{ version: 1, name: 'a', sql: 'CREATE TABLE t(a);' }]);
  await d.run('INSERT INTO t VALUES (7)');
  await assert.rejects(migrate(d, [{ version: 1, name: 'a', sql: 'CREATE TABLE t(a);' },
    { version: 2, name: 'bad', sql: 'CREATE TABLE u(x);\nCREATE TABLE u(x);' }]));
  assert.equal((await d.all("SELECT name FROM sqlite_master WHERE name='u'")).length, 0);
  assert.equal((await d.get('SELECT a FROM t')).a, 7);
});
test('later migration preserves data added after v1', async () => {
  const d = createNodeDriver();
  await migrate(d);
  await updateCompany(d, admin, { name: 'KHALDI PLAST', phone: '0550 00 00 00' });
  await migrate(d, [...(await import('../src/core/db/schema.js')).MIGRATIONS, { version: 7, name: 'add', sql: 'CREATE TABLE extra(id INTEGER);' }]);
  assert.equal((await getCompany(d)).phone, '0550 00 00 00');
});
test('persistence across close/reopen of a real file', async () => {
  const path = join(mkdtempSync(join(tmpdir(), 'kp-')), 'erp.db');
  let { db } = await initDatabase(createNodeDriver(path));
  await updateCompany(db, admin, { name: 'KHALDI PLAST', nif: 'TEST-NIF-1' });
  await db.close();
  ({ db } = await initDatabase(createNodeDriver(path)));
  assert.equal((await getCompany(db)).nif, 'TEST-NIF-1');
  assert.equal((await db.all('SELECT 1 FROM audit_log')).length, 1);
  await db.close();
});
test('audit log is append-only', async () => {
  const db = await fresh();
  await audit(db, { userId: 'u1', action: 'x', entity: 'e', entityId: 5, details: { a: 1 } });
  await assert.rejects(db.run("UPDATE audit_log SET action='y'"), /append-only/);
  await assert.rejects(db.run('DELETE FROM audit_log'), /append-only/);
  assert.equal((await db.get('SELECT COUNT(*) n FROM audit_log')).n, 1);
});
test('document numbers are sequential per type and year', async () => {
  const db = await fresh();
  const n = [];
  for (let i = 0; i < 3; i++) n.push(await db.transaction((tx) => nextDocumentNumber(tx, 'invoice', 2026)));
  n.push(await db.transaction((tx) => nextDocumentNumber(tx, 'invoice', 2027)));
  n.push(await db.transaction((tx) => nextDocumentNumber(tx, 'delivery_note', 2026)));
  assert.deepEqual(n, ['FAC-2026-0001', 'FAC-2026-0002', 'FAC-2026-0003', 'FAC-2027-0001', 'BL-2026-0001']);
});
test('document number is rolled back with a failed transaction (no gaps)', async () => {
  const db = await fresh();
  await assert.rejects(db.transaction(async (tx) => { await nextDocumentNumber(tx, 'invoice', 2026); throw new Error('boom'); }));
  assert.equal(await db.transaction((tx) => nextDocumentNumber(tx, 'invoice', 2026)), 'FAC-2026-0001');
});
test('concurrent number allocation yields unique numbers', async () => {
  const db = await fresh();
  const all = await Promise.all(Array.from({ length: 20 }, () => db.transaction((tx) => nextDocumentNumber(tx, 'invoice', 2026))));
  assert.equal(new Set(all).size, 20);
});
test('once(): duplicate event applied exactly once; failed work can be retried', async () => {
  const db = await fresh();
  await db.exec('CREATE TABLE stock(q INTEGER)'); await db.run('INSERT INTO stock VALUES (100)');
  const dispatch = () => once(db, 'dispatch:BL-2026-0001', (tx) => tx.run('UPDATE stock SET q=q-10'));
  const r1 = await dispatch(); const r2 = await dispatch();
  assert.equal(r1.duplicate, false); assert.equal(r2.duplicate, true);
  assert.equal((await db.get('SELECT q FROM stock')).q, 90);
  await assert.rejects(once(db, 'dispatch:BL-2', async (tx) => { await tx.run('UPDATE stock SET q=q-5'); throw new Error('fail'); }));
  assert.equal((await db.get('SELECT q FROM stock')).q, 90);
  const retry = await once(db, 'dispatch:BL-2', (tx) => tx.run('UPDATE stock SET q=q-5'));
  assert.equal(retry.duplicate, false); assert.equal((await db.get('SELECT q FROM stock')).q, 85);
});
test('foreign keys are enforced', async () => {
  const db = await fresh();
  await assert.rejects(db.run("INSERT INTO users(id,username,display_name,role_id,created_at) VALUES ('1','a','A','nope','t')"));
});
test('permissions enforced in business logic', async () => {
  const db = await fresh();
  await assert.rejects(updateCompany(db, { id: 'u2', role: 'sales' }, { name: 'X' }), PermissionError);
  await assert.rejects(updateCompany(db, null, { name: 'X' }), PermissionError);
  const c = await updateCompany(db, admin, { name: 'KHALDI PLAST SARL' });
  assert.equal(c.name, 'KHALDI PLAST SARL');
  const log = await db.get("SELECT details FROM audit_log WHERE entity='company_settings'");
  assert.equal(JSON.parse(log.details).name.to, 'KHALDI PLAST SARL');
});
test('role matrix: auditor read-only, operator limited, accountant cannot change settings', () => {
  for (const m of MODULES) for (const a of ['write', 'post', 'admin']) assert.equal(can('auditor', m, a), false, `auditor ${a} ${m}`);
  assert.equal(can('prod_operator', 'invoices', 'read'), false);
  assert.equal(can('prod_operator', 'production', 'write'), true);
  assert.equal(can('prod_operator', 'production', 'post'), false);
  assert.equal(can('accountant', 'settings', 'admin'), false);
  assert.equal(can('accountant', 'accounting', 'post'), true);
  assert.equal(can('admin', 'backup', 'admin'), true);
  assert.throws(() => requirePermission({ role: 'sales' }, 'accounting', 'post'), PermissionError);
  assert.equal(Object.keys(MATRIX).length, 8);
});
