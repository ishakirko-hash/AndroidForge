import test from 'node:test';
import assert from 'node:assert/strict';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { createProduct, createMaterial, createRecipe } from '../src/core/catalog.js';
import { postMovement, getBalance } from '../src/core/inventory.js';
import { createOrder, planOrder, startOrder, completeOrder } from '../src/core/production.js';
import { shiftMinutes, createShift, updateShift, seedDefaultShifts, createEmployee, listEmployees, recordAttendance, correctAttendance, attendanceSummary,
  recordShiftOutput, reviewShiftRecord, outputBy, shiftReconciliation } from '../src/core/hr.js';
import { createMachine, setMachineStatus, setMachineCapacity, createMaintenancePlan, recordMaintenance, dueMaintenance, maintenanceCostByMachine, machineUtilization } from '../src/core/machines.js';
import { recordInspection, qualityReport, recordWaste, recoverWaste } from '../src/core/quality.js';
import { budgetVsActual, setBudget } from '../src/core/budgets.js';
import { seedStarterChart } from '../src/core/ledger.js';
import { createFinancialAccount, createExpenseCategory, recordExpense } from '../src/core/cash.js';
import { PermissionError } from '../src/core/permissions.js';

const admin = { id: 'a', role: 'admin' }, mgr = { id: 'm', role: 'manager' }, sup = { id: 's', role: 'prod_supervisor' }, op = { id: 'o', role: 'prod_operator' };

async function plant() {
  const { db } = await initDatabase(createNodeDriver());
  const product = await createProduct(db, mgr, { ref: 'PL001', name_fr: 'Caisse' });
  const resin = await createMaterial(db, mgr, { ref: 'RM1', name: 'Granulé', unit: 'kg' });
  const rc = await createRecipe(db, mgr, { productId: product, lines: [{ materialId: resin, qtyPerUnit: '1' }] });
  await postMovement(db, mgr, { type: 'opening', itemType: 'material', itemId: resin, qty: '10000', eventKey: 'open' });
  const [s1, s2] = await seedDefaultShifts(db, mgr);
  const machine = await createMachine(db, mgr, { ref: 'M1', name: 'Presse 1', rated_capacity_per_hour: '100' });
  const emp = await createEmployee(db, mgr, { ref: 'E1', name: 'Opérateur', hourly_cost: '350' });
  const order = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '1000' });
  await planOrder(db, mgr, order.id); await startOrder(db, mgr, order.id);
  return { db, product, resin, rc, s1, s2, machine, emp, order };
}

test('shift length: default shifts, midnight crossing, custom and 30-minute offsets', () => {
  assert.deepEqual([['08:00', '16:00'], ['16:00', '00:00'], ['00:00', '08:00'], ['22:00', '06:00'], ['06:00', '14:00'], ['21:30', '05:00']].map(([a, b]) => shiftMinutes(a, b)), [480, 480, 480, 480, 480, 450]);
  assert.throws(() => shiftMinutes('8:00', '16:00'), /HH:MM/); assert.throws(() => shiftMinutes('24:00', '01:00'), /HH:MM/);
});
test('shifts are configurable: editable, duplicates rejected, permissions', async () => {
  const { db, s1 } = await plant();
  await updateShift(db, mgr, s1, { start: '06:00', end: '14:00', name: 'Matin' });
  assert.deepEqual((await db.get('SELECT name, start_time, end_time FROM shifts WHERE id=?', [s1])), { name: 'Matin', start_time: '06:00', end_time: '14:00' });
  await assert.rejects(createShift(db, mgr, { name: 'Matin', start: '01:00', end: '02:00' }), /Duplicate/);
  await assert.rejects(createShift(db, { id: 'x', role: 'auditor' }, { name: 'z', start: '01:00', end: '02:00' }), PermissionError);
});
test('employees: unique ref; labor cost hidden from roles that cannot post employees', async () => {
  const { db } = await plant();
  await assert.rejects(createEmployee(db, mgr, { ref: 'E1', name: 'dup' }), /Duplicate/);
  await assert.rejects(createEmployee(db, mgr, { ref: 'E2', name: 'x', hourly_cost: '-1' }), /negative/);
  assert.equal((await listEmployees(db, mgr))[0].hourly_cost, '350');
  assert.equal('hourly_cost' in (await listEmployees(db, sup))[0], false);
  await assert.rejects(listEmployees(db, { id: 'n', role: 'nobody' }), PermissionError);
});
test('attendance: validation, no duplicate day, audited correction (reason + supervisor cannot correct), summary', async () => {
  const { db, emp } = await plant();
  await recordAttendance(db, sup, { employeeId: emp, workDate: '2026-03-02', status: 'present', hours: '8', overtimeHours: '1' });
  await recordAttendance(db, sup, { employeeId: emp, workDate: '2026-03-03', status: 'present', hours: '7.5' });
  await recordAttendance(db, sup, { employeeId: emp, workDate: '2026-03-04', status: 'absent', hours: '8' }); // hours ignored for absence
  await assert.rejects(recordAttendance(db, sup, { employeeId: emp, workDate: '2026-03-02', status: 'present', hours: '8' }), /already recorded/);
  await assert.rejects(recordAttendance(db, sup, { employeeId: emp, workDate: '2026-03-05', status: 'present', hours: '25' }), /0 and 24/);
  await assert.rejects(recordAttendance(db, sup, { employeeId: emp, workDate: '2026-03-05', status: 'present', hours: '0' }), /worked hours/);
  const s = await attendanceSummary(db, emp, { from: '2026-03-01', to: '2026-03-31' });
  assert.deepEqual([s.present, s.absent, s.hours, s.overtime].map(String), ['2', '1', '15.5', '1']);
  await assert.rejects(correctAttendance(db, sup, { employeeId: emp, workDate: '2026-03-03', status: 'present', hours: '8', reason: 'x' }), PermissionError);
  await assert.rejects(correctAttendance(db, mgr, { employeeId: emp, workDate: '2026-03-03', status: 'present', hours: '8', reason: ' ' }), /reason/);
  await correctAttendance(db, mgr, { employeeId: emp, workDate: '2026-03-03', status: 'present', hours: '8', reason: 'pointage erroné' });
  const log = await db.get("SELECT details FROM audit_log WHERE action='correct'");
  assert.equal(JSON.parse(log.details).before.hours, '7.5');
});
test('shift output: validations, no double counting, grouping by day/machine, supervisor review, reconciliation with the order', async () => {
  const { db, s1, s2, machine, emp, order, resin } = await plant();
  const base = { machineId: machine, operatorId: emp, productionOrderId: order.id };
  await assert.rejects(recordShiftOutput(db, op, { ...base, shiftId: s1, workDate: '2026-03-02', produced: '100', accepted: '90', rejected: '5' }), /must equal produced/);
  await assert.rejects(recordShiftOutput(db, op, { ...base, shiftId: s1, workDate: '2026-03-02', produced: '100', accepted: '90', rejected: '10', downtimeMin: 30 }), /reason/);
  await assert.rejects(recordShiftOutput(db, op, { ...base, shiftId: s1, workDate: '2026-03-02', produced: '100', accepted: '90', rejected: '10', downtimeMin: 500, downtimeReason: 'x' }), /exceeds the shift/);
  const r1 = await recordShiftOutput(db, op, { ...base, shiftId: s1, workDate: '2026-03-02', produced: '300', accepted: '285', rejected: '15', downtimeMin: 20, downtimeReason: 'changement de moule' });
  await assert.rejects(recordShiftOutput(db, op, { ...base, shiftId: s1, workDate: '2026-03-02', produced: '300', accepted: '285', rejected: '15' }), /double counting/);
  await recordShiftOutput(db, op, { ...base, shiftId: s2, workDate: '2026-03-02', produced: '200', accepted: '200', rejected: '0' });
  await recordShiftOutput(db, op, { ...base, shiftId: s1, workDate: '2026-03-03', produced: '100', accepted: '95', rejected: '5' });
  const byDay = await outputBy(db, 'day', { from: '2026-03-01', to: '2026-03-31' });
  assert.deepEqual(byDay.map((d) => [d.key, d.produced.toString(), d.accepted.toString(), d.rejected.toString(), d.downtimeMin]), [['2026-03-02', '500', '485', '15', 20], ['2026-03-03', '100', '95', '5', 0]]);
  assert.equal((await outputBy(db, 'machine', { from: '2026-03-01', to: '2026-03-31' }))[0].produced.toString(), '600');
  await assert.rejects(reviewShiftRecord(db, op, r1), PermissionError);
  await reviewShiftRecord(db, sup, r1); await assert.rejects(reviewShiftRecord(db, sup, r1), /already reviewed/);
  await completeOrder(db, mgr, order.id, { totalQty: '600', acceptedQty: '580', rejectedQty: '20', consumption: [{ materialId: resin, qty: '600' }] });
  const rec = await shiftReconciliation(db, order.id);
  assert.equal(rec.ok, true);
  await assert.rejects(recordShiftOutput(db, op, { ...base, shiftId: s2, workDate: '2026-03-09', produced: '1', accepted: '1', rejected: '0' }), /in progress/);
});
test('shift output rejects machines not operational, and unknown/inactive operators', async () => {
  const { db, s1, machine, emp, order } = await plant();
  await setMachineStatus(db, mgr, machine, 'maintenance', 'préventive');
  await assert.rejects(recordShiftOutput(db, op, { shiftId: s1, workDate: '2026-03-02', machineId: machine, operatorId: emp, productionOrderId: order.id, produced: '1', accepted: '1', rejected: '0' }), /maintenance/);
  await assert.rejects(setMachineStatus(db, op, machine, 'operational'), PermissionError);
  await setMachineStatus(db, mgr, machine, 'operational');
  await assert.rejects(recordShiftOutput(db, op, { shiftId: s1, workDate: '2026-03-02', machineId: machine, operatorId: 'nope', productionOrderId: order.id, produced: '1', accepted: '1', rejected: '0' }), /operator/);
});
test('machine utilization (hand-computed): 8h shift - 60 min downtime = 7h; capacity 100/h → 700; produced 560 → 80%; product capacity overrides', async () => {
  const { db, s1, machine, emp, order, product } = await plant();
  await recordShiftOutput(db, op, { shiftId: s1, workDate: '2026-03-02', machineId: machine, operatorId: emp, productionOrderId: order.id, produced: '560', accepted: '560', rejected: '0', downtimeMin: 60, downtimeReason: 'panne' });
  let u = await machineUtilization(db, machine, { from: '2026-03-01', to: '2026-03-31' });
  assert.deepEqual([u.capacityUnits, u.utilizationPct].map(String), ['700', '80']); assert.equal(u.estimate, true);
  await setMachineCapacity(db, mgr, machine, product, '80');
  u = await machineUtilization(db, machine, { from: '2026-03-01', to: '2026-03-31' });
  assert.deepEqual([u.capacityUnits, u.utilizationPct].map(String), ['560', '100']);
  const m2 = await createMachine(db, mgr, { ref: 'M2', name: 'Sans capacité' });
  await recordShiftOutput(db, op, { shiftId: s1, workDate: '2026-03-02', machineId: m2, operatorId: emp, productionOrderId: order.id, produced: '10', accepted: '10', rejected: '0' });
  u = await machineUtilization(db, m2, { from: '2026-03-01', to: '2026-03-31' });
  assert.equal(u.utilizationPct, null); assert.equal(u.incomplete, true); // unknown capacity: no invented figure
});
test('maintenance due dates from plan + history (hand-computed), costs by machine', async () => {
  const { db, machine } = await plant();
  const plan = await createMaintenancePlan(db, mgr, { machineId: machine, task: 'Graissage', intervalDays: 30, startDate: '2026-01-01' });
  await assert.rejects(createMaintenancePlan(db, mgr, { machineId: machine, task: 'x', intervalDays: 0, startDate: '2026-01-01' }), /positive/);
  let d = await dueMaintenance(db, { asOf: '2026-01-25', withinDays: 7 });
  assert.deepEqual([d[0].dueDate, d[0].daysLeft, d[0].overdue], ['2026-01-31', 6, false]);
  assert.equal((await dueMaintenance(db, { asOf: '2026-01-10', withinDays: 7 })).length, 0);
  d = await dueMaintenance(db, { asOf: '2026-02-05', withinDays: 7 }); assert.deepEqual([d[0].daysLeft, d[0].overdue], [-5, true]);
  await recordMaintenance(db, mgr, { machineId: machine, planId: plan, kind: 'preventive', doneOn: '2026-02-01', cost: '1500', downtimeMin: 90 });
  assert.equal((await dueMaintenance(db, { asOf: '2026-02-05', withinDays: 7 })).length, 0); // next due 2026-03-03
  assert.equal((await dueMaintenance(db, { asOf: '2026-03-01', withinDays: 7 }))[0].dueDate, '2026-03-03');
  await recordMaintenance(db, mgr, { machineId: machine, kind: 'corrective', doneOn: '2026-02-10', cost: '250.50', description: 'résistance' });
  assert.equal((await maintenanceCostByMachine(db, { from: '2026-02-01', to: '2026-02-28' }))[0].total.toString(), '1750.5');
  await assert.rejects(recordMaintenance(db, mgr, { machineId: machine, kind: 'x', doneOn: '2026-02-10' }), /Invalid kind/);
  await assert.rejects(recordMaintenance(db, op, { machineId: machine, kind: 'corrective', doneOn: '2026-02-10' }), PermissionError);
});
test('quality: validation, rejection rates by product and defect (hand-computed 15/300 = 5%)', async () => {
  const { db, order, product } = await plant();
  await assert.rejects(recordInspection(db, op, { productionOrderId: order.id, inspected: '100', accepted: '90', rejected: '5' }), /must equal/);
  await assert.rejects(recordInspection(db, op, { productionOrderId: order.id, inspected: '100', accepted: '90', rejected: '10' }), /defect category/);
  await recordInspection(db, op, { productionOrderId: order.id, inspectedOn: '2026-03-02', inspected: '200', accepted: '190', rejected: '10', defectCategory: 'déformation' });
  await recordInspection(db, op, { productionOrderId: order.id, inspectedOn: '2026-03-03', inspected: '100', accepted: '95', rejected: '5', defectCategory: 'bavure' });
  await recordInspection(db, op, { productionOrderId: order.id, inspectedOn: '2026-03-04', inspected: '50', accepted: '50', rejected: '0' });
  const byProduct = await qualityReport(db, 'product', { from: '2026-03-01', to: '2026-03-31' });
  assert.deepEqual([byProduct[0].key === product, byProduct[0].inspected.toString(), byProduct[0].rejected.toString(), byProduct[0].rejectionRatePct.toString()], [true, '350', '15', '4.2857']);
  const byDefect = await qualityReport(db, 'defect', { from: '2026-03-01', to: '2026-03-31' });
  assert.equal(byDefect.find((g) => g.key === 'déformation').rejected.toString(), '10');
});
test('waste recovery is controlled: cannot exceed recorded waste, no double counting, needs quality:post', async () => {
  const { db, order } = await plant();
  const recycled = await createMaterial(db, mgr, { ref: 'RM2', name: 'Broyé', unit: 'kg' });
  const w = await recordWaste(db, op, { productionOrderId: order.id, materialId: recycled, qty: '50', reason: 'purge' });
  await assert.rejects(recoverWaste(db, op, w, { qty: '10', recycledMaterialId: recycled }), PermissionError);
  await recoverWaste(db, sup, w, { qty: '30', recycledMaterialId: recycled });
  assert.equal((await getBalance(db, 'material', recycled)).toString(), '30');
  await assert.rejects(recoverWaste(db, sup, w, { qty: '21', recycledMaterialId: recycled }), /exceeds recorded waste/);
  await recoverWaste(db, sup, w, { qty: '20', recycledMaterialId: recycled });
  await assert.rejects(recoverWaste(db, sup, w, { qty: '1', recycledMaterialId: recycled }), /exceeds recorded waste/);
  assert.equal((await getBalance(db, 'material', recycled)).toString(), '50');
  await assert.rejects(recordWaste(db, op, { materialId: recycled, qty: '1', reason: '' }), /reason/);
});
test('budgets vs actual (hand-computed): 3000 → ok; 4600 → warning at 90%; 5100 → over by 100; other months excluded', async () => {
  const { db } = await plant();
  await seedStarterChart(db, admin);
  const caisse = await createFinancialAccount(db, mgr, { name: 'Caisse', kind: 'cash', ledgerAccount: '5000', openingBalance: '100000', openingEquityAccount: '1000', openingDate: '2026-01-01' });
  await createExpenseCategory(db, mgr, { code: 'ELEC', name_fr: 'Électricité', accountCode: '6000' });
  await setBudget(db, mgr, { period: '2026-02', categoryCode: 'ELEC', amount: '5000' });
  await assert.rejects(setBudget(db, mgr, { period: '2026-2', categoryCode: 'ELEC', amount: '1' }), /YYYY-MM/);
  await assert.rejects(setBudget(db, mgr, { period: '2026-02', categoryCode: 'NOPE', amount: '1' }), /Unknown/);
  const exp = (date, amount, k) => recordExpense(db, mgr, { date, categoryCode: 'ELEC', amount, finAccountId: caisse, eventKey: k });
  await exp('2026-02-03', '3000', 'a'); await exp('2026-03-01', '9999', 'z'); // March must not count
  let r = (await budgetVsActual(db, '2026-02'))[0];
  assert.deepEqual([r.actual, r.variance, r.usedPct, r.status].map(String), ['3000', '2000', '60', 'ok']);
  await exp('2026-02-28', '1600', 'b');
  r = (await budgetVsActual(db, '2026-02'))[0]; assert.deepEqual([r.actual.toString(), r.usedPct.toString(), r.status], ['4600', '92', 'warning']);
  assert.equal((await budgetVsActual(db, '2026-02', { warnPct: '95' }))[0].status, 'ok'); // threshold is configurable
  await exp('2026-02-15', '500', 'c');
  r = (await budgetVsActual(db, '2026-02'))[0]; assert.deepEqual([r.variance.toString(), r.status], ['-100', 'over']);
  await assert.rejects(setBudget(db, { id: 's', role: 'sales' }, { period: '2026-02', categoryCode: 'ELEC', amount: '1' }), PermissionError);
});
