import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { seedStarterChart, setAccountRole, trialBalance, verifyLedgerIntegrity } from '../src/core/ledger.js';
import { createProduct, createMaterial, createRecipe } from '../src/core/catalog.js';
import { postMovement, stockValuation } from '../src/core/inventory.js';
import { createOrder, planOrder, startOrder, completeOrder } from '../src/core/production.js';
import { setTaxRate, createCustomer, createSupplier } from '../src/core/parties.js';
import { issueInvoice, issueCreditNote } from '../src/core/invoicing.js';
import { recordPayment, customerBalance } from '../src/core/receivables.js';
import { createFinancialAccount, createExpenseCategory, recordExpense } from '../src/core/cash.js';
import { createMachine, createMaintenancePlan } from '../src/core/machines.js';
import { createEmployee } from '../src/core/hr.js';
import { createBackup, restoreBackup, validateBackup, backupHistory } from '../src/core/backup.js';
import { globalSearch } from '../src/core/search.js';
import { toCsv, exportCsv, customerStatement, REPORT_NAMES } from '../src/core/reports.js';
import { PermissionError } from '../src/core/permissions.js';

const admin = { id: 'a', role: 'admin' }, mgr = { id: 'm', role: 'manager' };
const ROLES = { receivable: '3000', payable: '4000', sales_revenue: '7000', tax_collected: '4100', tax_deductible: '3100', inventory_materials: '2100', inventory_finished: '2200', cogs: '6500', production_waste: '6600' };
const sha = async (s) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map((b) => b.toString(16).padStart(2, '0')).join('');
const reseal = async (m) => { m.checksum = await sha(JSON.stringify(m.tables)); return JSON.stringify(m); };

/** A small but complete factory, all disposable test data. */
async function factory(db) {
  await seedStarterChart(db, admin); for (const [r, c] of Object.entries(ROLES)) await setAccountRole(db, admin, r, c);
  await setTaxRate(db, admin, { code: 'T19', label: 'Taux test', ratePct: '19' });
  const caisse = await createFinancialAccount(db, mgr, { name: 'Caisse', kind: 'cash', ledgerAccount: '5000', openingBalance: '100000', openingEquityAccount: '1000', openingDate: '2026-01-01' });
  await createExpenseCategory(db, mgr, { code: 'ELEC', name_fr: 'Électricité', accountCode: '6000' });
  const product = await createProduct(db, mgr, { ref: 'PL001', name_fr: 'Grande caisse', name_ar: 'الصندوق الكبير', unit_weight_g: '1200' });
  const resin = await createMaterial(db, mgr, { ref: 'RM001', name: 'Granulé', unit: 'kg' });
  const rc = await createRecipe(db, mgr, { productId: product, lines: [{ materialId: resin, qtyPerUnit: '0.8', lossPct: '5' }] });
  await postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: resin, qty: '1000', unitCost: '100', eventKey: 'rcpt' });
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '100' }); await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  await completeOrder(db, mgr, o.id, { totalQty: '100', acceptedQty: '90', rejectedQty: '10', consumption: [{ materialId: resin, qty: '84' }] });
  const cust = await createCustomer(db, mgr, { ref: 'C001', name: 'Société El Amel', phone: '0550123456', nif: 'NIF-TEST-1' });
  await createSupplier(db, mgr, { ref: 'S001', name: 'Fournisseur Plast' });
  const inv = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [{ productId: product, description: 'Grande caisse', qty: '10', unitPrice: '950', taxCode: 'T19' }] });
  await recordPayment(db, mgr, { customerId: cust, amount: '4000', method: 'bank_transfer', eventKey: 'pay1', payDate: '2026-02-10', finAccountId: caisse, allocations: [{ invoiceId: inv.id, amount: '4000' }] });
  await recordExpense(db, mgr, { date: '2026-02-12', categoryCode: 'ELEC', amount: '2500', finAccountId: caisse, eventKey: 'exp1', description: 'Facture électricité' });
  const mc = await createMachine(db, mgr, { ref: 'M1', name: 'Presse 1' }); await createMaintenancePlan(db, mgr, { machineId: mc, task: 'Graissage', intervalDays: 30, startDate: '2026-01-01' });
  await createEmployee(db, mgr, { ref: 'E1', name: 'Karim' });
  return { cust, inv, product, caisse };
}
const tableCounts = async (db) => { const o = {}; for (const t of (await db.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT IN ('schema_migrations','backup_log') ORDER BY name"))) o[t.name] = (await db.get(`SELECT COUNT(*) n FROM ${t.name}`)).n; return o; };
const fingerprint = async (db, cust) => JSON.stringify({ counts: await tableCounts(db), bal: String((await customerBalance(db, cust)).balance), tb: (await trialBalance(db)).rows.map((r) => [r.code, String(r.debit), String(r.credit)]), val: String((await stockValuation(db)).materialsValue) });
const fresh = async () => (await initDatabase(createNodeDriver())).db;

// ------------------------------------------------------------------ backup / restore
test('ROUNDTRIP: backup a working factory, restore into a disposable empty database, records and balances match', async () => {
  const src = await fresh(); const { cust, inv } = await factory(src);
  assert.equal(String((await customerBalance(src, cust)).balance), '7305'); // 9500 + 1805 tax − 4000 paid (hand-computed)
  const { text, manifest } = await createBackup(src, admin);
  assert.equal(manifest.formatVersion, 1); assert.equal(manifest.counts.invoices, 1); assert.ok(manifest.counts.journal_entries >= 5);
  const dst = await fresh();
  const res = await restoreBackup(dst, admin, text, { confirm: true });
  assert.ok(res.safetyBackup.length > 100);
  const a = JSON.parse(await fingerprint(src, cust)), b = JSON.parse(await fingerprint(dst, cust));
  assert.equal(b.counts.audit_log, a.counts.audit_log + 1);   // the restore itself is audited
  a.counts.audit_log = b.counts.audit_log;
  assert.deepEqual(b, a);
  assert.equal(String((await customerBalance(dst, cust)).balance), '7305');
  assert.deepEqual(await verifyLedgerIntegrity(dst), []); assert.equal((await trialBalance(dst)).balanced, true);
  assert.equal((await dst.get('SELECT status FROM invoices WHERE id=?', [inv.id])).status, 'issued');
  // protections survive the restore (triggers re-created)
  await assert.rejects(dst.run("UPDATE audit_log SET action='x'"), /append-only/);
  await assert.rejects(dst.run('DELETE FROM journal_entries'), /immutable/);
  await assert.rejects(dst.run("UPDATE invoices SET total_ttc='1'"), /immutable/);
  await assert.rejects(dst.run('DELETE FROM stock_movements'), /append-only/);
  // numbering continues where the source left off (no duplicate invoice numbers after restore)
  const next = await issueInvoice(dst, mgr, { customerId: cust, issueDate: '2026-02-20', lines: [{ description: 'x', qty: '1', unitPrice: '10' }] });
  assert.equal(next.number, 'FAC-2026-0002');
});
test('restoring over a live database returns it exactly to the backed-up state', async () => {
  const db = await fresh(); const { cust } = await factory(db);
  const { text } = await createBackup(db, admin); const before = await fingerprint(db, cust);
  await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-03-01', lines: [{ description: 'later', qty: '1', unitPrice: '999' }] });
  await recordExpense(db, mgr, { date: '2026-03-02', categoryCode: 'ELEC', amount: '10', finAccountId: (await db.get('SELECT id FROM financial_accounts')).id, eventKey: 'later' });
  assert.notEqual(await fingerprint(db, cust), before);
  const r = await restoreBackup(db, admin, text, { confirm: true });
  const after = JSON.parse(await fingerprint(db, cust)), b = JSON.parse(before);
  after.counts.audit_log -= 1; assert.deepEqual(after, b);
  const undo = JSON.parse(r.safetyBackup); assert.equal(undo.counts.invoices, 2); // the replaced data was handed back as a safety backup
});
test('restored data persists in a real file after closing and reopening', async () => {
  const src = await fresh(); const { cust } = await factory(src);
  const { text } = await createBackup(src, admin);
  const path = join(mkdtempSync(join(tmpdir(), 'kp-restore-')), 'erp.db');
  let { db } = await initDatabase(createNodeDriver(path)); await restoreBackup(db, admin, text, { confirm: true }); await db.close();
  ({ db } = await initDatabase(createNodeDriver(path)));
  assert.equal(String((await customerBalance(db, cust)).balance), '7305'); await db.close();
});
test('rejected backups leave the database completely untouched: tampering, wrong format, newer app, unknown table/column, count mismatch', async () => {
  const db = await fresh(); const { cust } = await factory(db);
  const { text } = await createBackup(db, admin); const before = await fingerprint(db, cust);
  const bad = async (mutate, re, reseal_ = true) => { const m = JSON.parse(text); mutate(m); await assert.rejects(restoreBackup(db, admin, reseal_ ? await reseal(m) : JSON.stringify(m), { confirm: true }), re); };
  await bad((m) => { m.tables.customers.rows[0][2] = 'Pirate'; }, /checksum mismatch/, false);        // edited after export
  await bad((m) => { m.format = 'other'; }, /Not a KHALDI/);
  await bad((m) => { m.formatVersion = 99; }, /Unsupported backup format/);
  await bad((m) => { m.schemaVersion = 99; }, /newer app version/, false);
  await bad((m) => { m.tables.evil_table = { columns: ['a'], rows: [] }; m.counts.evil_table = 0; }, /unknown table/);
  await bad((m) => { m.tables.customers.columns.push('ghost'); m.tables.customers.rows.forEach((r) => r.push(1)); }, /does not exist/);
  await bad((m) => { m.counts.customers += 1; }, /Row count mismatch/);
  await assert.rejects(restoreBackup(db, admin, '{not json', { confirm: true }), /not valid JSON/);
  assert.equal(await fingerprint(db, cust), before);
});
test('older schema versions are accepted (data restores into the current schema)', async () => {
  const db = await fresh(); await factory(db);
  const { text } = await createBackup(db, admin); const m = JSON.parse(text); m.schemaVersion = 5;
  await restoreBackup(db, admin, JSON.stringify(m), { confirm: true });
});
test('restore needs explicit confirmation and admin rights; creating a backup needs backup:write', async () => {
  const db = await fresh(); await factory(db);
  const { text } = await createBackup(db, admin);
  await assert.rejects(restoreBackup(db, admin, text), /confirmed explicitly/);
  await assert.rejects(restoreBackup(db, admin, text, { confirm: 'yes' }), /confirmed explicitly/);
  await assert.rejects(restoreBackup(db, mgr, text, { confirm: true }), PermissionError);
  await assert.rejects(createBackup(db, mgr), PermissionError);
  await assert.rejects(createBackup(db, { id: 'x', role: 'accountant' }), PermissionError);
});
test('a backup that would break referential integrity or the ledger is rolled back atomically, and the failure is logged', async () => {
  const db = await fresh(); const { cust } = await factory(db);
  const { text } = await createBackup(db, admin); const before = await fingerprint(db, cust);
  // (1) customer removed while invoices/payments still reference it → foreign-key violation at commit
  let m = JSON.parse(text); m.tables.customers.rows = []; m.counts.customers = 0;
  await assert.rejects(restoreBackup(db, admin, await reseal(m), { confirm: true }), /FOREIGN KEY|constraint/i);
  assert.equal(await fingerprint(db, cust), before);
  // (2) valid checksum but an unbalanced journal line
  m = JSON.parse(text); const c = m.tables.journal_lines.columns.indexOf('debit_u'); const row = m.tables.journal_lines.rows.find((r) => r[c] > 0); row[c] += 10000;
  await assert.rejects(restoreBackup(db, admin, await reseal(m), { confirm: true }), /unbalanced/);
  assert.equal(await fingerprint(db, cust), before);
  await assert.rejects(db.run("UPDATE audit_log SET action='x'"), /append-only/);   // triggers still in place after the failed attempts
  const log = await backupHistory(db);
  assert.equal(log.filter((l) => l.kind === 'restore' && l.status === 'failed').length, 2);
  assert.ok(log.some((l) => l.kind === 'create' && l.status === 'ok'));
  assert.equal((await validateBackup(db, text)).counts.invoices, 1);
});

// ------------------------------------------------------------------ search
test('global search: FR/AR names, references, customer names, wildcard characters are literal, minimum length, limit', async () => {
  const db = await fresh(); await factory(db);
  const kinds = (r) => r.map((x) => x.type).sort();
  assert.ok(kinds(await globalSearch(db, mgr, 'PL001')).includes('product'));
  assert.deepEqual((await globalSearch(db, mgr, 'الصندوق')).map((x) => x.label), ['PL001']);
  const amel = await globalSearch(db, mgr, 'amel'); assert.deepEqual(kinds(amel), ['customer', 'invoice']); // customer + their invoice
  assert.ok((await globalSearch(db, mgr, 'FAC-2026')).some((x) => x.type === 'invoice'));
  assert.equal((await globalSearch(db, mgr, '%%')).length, 0); assert.equal((await globalSearch(db, mgr, '__')).length, 0);
  assert.equal((await globalSearch(db, mgr, 'a')).length, 0);
  assert.equal((await globalSearch(db, mgr, 'électricité')).some((x) => x.type === 'expense'), true);
  assert.ok((await globalSearch(db, mgr, 'PL', { limit: 1 })).filter((x) => x.type === 'product').length <= 1);
});
test('global search respects permissions: an operator finds machines but not customers, invoices or employees', async () => {
  const db = await fresh(); await factory(db);
  const op = { id: 'o', role: 'prod_operator' };
  assert.deepEqual((await globalSearch(db, op, 'Presse')).map((x) => x.type), ['machine']);
  assert.equal((await globalSearch(db, op, 'Amel')).length, 0); assert.equal((await globalSearch(db, op, 'Karim')).length, 0);
  assert.equal((await globalSearch(db, null, 'Presse')).length, 0);
  assert.ok((await globalSearch(db, mgr, 'Karim')).some((x) => x.type === 'employee'));
});

// ------------------------------------------------------------------ CSV and statements
test('CSV: escaping, BOM, Arabic preserved, spreadsheet formula-injection guard, numbers untouched', () => {
  const out = toCsv(['a', 'b'], [{ a: 'x,y', b: 'say "hi"' }, { a: 'line\nbreak', b: 'الصندوق' }, { a: '=SUM(A1)', b: '-5' }, { a: '+213 550', b: null }, { a: 0, b: undefined }]);
  assert.ok(out.startsWith('\uFEFFa,b\r\n'));
  assert.equal(out, '\uFEFFa,b\r\n"x,y","say ""hi"""\r\n"line\nbreak",الصندوق\r\n\'=SUM(A1),-5\r\n\'+213 550,\r\n0,\r\n');
});
test('CSV reports: real rows, permissions, unknown names; stock movements carry signed exact quantities', async () => {
  const db = await fresh(); await factory(db);
  const inv = await exportCsv(db, mgr, 'invoices', { from: '2026-01-01', to: '2026-12-31' });
  const rows = inv.split('\r\n'); assert.equal(rows[0], '\uFEFFnumber,issue_date,due_date,customer,subtotal_ht,tax_total,total_ttc,status');
  assert.equal(rows[1], 'FAC-2026-0001,2026-02-01,2026-03-03,Société El Amel,9500,1805,11305,issued');
  const mv = await exportCsv(db, mgr, 'stock_movements', { from: '2000-01-01', to: '2100-01-01' });
  assert.ok(mv.includes(',receipt,1000,')); assert.ok(mv.includes(',production_consumption,-84,')); assert.ok(mv.includes(',production_output,90,'));
  assert.ok((await exportCsv(db, mgr, 'trial_balance', { from: null, to: null })).includes('7000,Ventes'));
  assert.ok((await exportCsv(db, mgr, 'stock_valuation')).includes('material,RM001'));
  await assert.rejects(exportCsv(db, { id: 'o', role: 'prod_operator' }, 'invoices', { from: '2026-01-01', to: '2026-12-31' }), PermissionError);
  await assert.rejects(exportCsv(db, mgr, 'secrets'), /Unknown report/);
  assert.equal(REPORT_NAMES.length, 6);
});
test('customer statement (hand-computed): 1000 → 600 → 500 → 1000, consistent with the customer balance', async () => {
  const { db } = { db: await fresh() };
  await seedStarterChart(db, admin); for (const [r, c] of Object.entries(ROLES)) await setAccountRole(db, admin, r, c);
  const cust = await createCustomer(db, mgr, { ref: 'C9', name: 'Client' });
  const i1 = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-01', lines: [{ description: 'a', qty: '1', unitPrice: '1000' }] });
  await recordPayment(db, mgr, { customerId: cust, amount: '400', method: 'cash', eventKey: 'p', payDate: '2026-01-10', allocations: [{ invoiceId: i1.id, amount: '400' }] });
  await issueCreditNote(db, mgr, { invoiceId: i1.id, amount: '100', reason: 'remise', issueDate: '2026-01-15' });
  await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [{ description: 'b', qty: '1', unitPrice: '500' }] });
  const st = await customerStatement(db, mgr, cust);
  assert.deepEqual(st.lines.map((l) => [l.kind, l.balance.toString()]), [['invoice', '1000'], ['payment', '600'], ['credit_note', '500'], ['invoice', '1000']]);
  assert.equal(st.closingBalance.toString(), '1000'); assert.equal(st.consistent, true);
  await assert.rejects(customerStatement(db, { id: 'o', role: 'prod_operator' }, cust), PermissionError);
});
