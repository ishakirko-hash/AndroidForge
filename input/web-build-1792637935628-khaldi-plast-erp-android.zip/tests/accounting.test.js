import test from 'node:test';
import assert from 'node:assert/strict';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { seedStarterChart, setAccountRole, createAccount, postManualEntry, reverseManualEntry, closePeriod, trialBalance, incomeStatement, balanceSheet, generalLedger, verifyLedgerIntegrity } from '../src/core/ledger.js';
import { createFinancialAccount, cashBalance, transfer, createExpenseCategory, recordExpense, cancelExpense, reconcileCash, expensesByCategory } from '../src/core/cash.js';
import { setTaxRate, createCustomer, createSupplier } from '../src/core/parties.js';
import { issueInvoice, cancelInvoice, issueCreditNote } from '../src/core/invoicing.js';
import { recordPayment, cancelPayment, customerBalance } from '../src/core/receivables.js';
import { postPending } from '../src/core/postings.js';
import { createMaterial, createProduct, createRecipe } from '../src/core/catalog.js';
import { getBalance, postMovement } from '../src/core/inventory.js';
import { createPurchaseOrder, approvePurchaseOrder, receiveGoods, recordSupplierInvoice, paySupplier, supplierBalance, supplierInvoiceOutstanding, draftPoFromShortages } from '../src/core/purchasing.js';
import { PermissionError } from '../src/core/permissions.js';

const admin = { id: 'a', role: 'admin' }, mgr = { id: 'm', role: 'manager' }, acc = { id: 'ac', role: 'accountant' };
const ROLE_MAP = { receivable: '3000', payable: '4000', sales_revenue: '7000', tax_collected: '4100', tax_deductible: '3100', inventory_materials: '2100' };

async function world({ roles = true } = {}) {
  const { db } = await initDatabase(createNodeDriver());
  await seedStarterChart(db, admin);
  if (roles) for (const [r, c] of Object.entries(ROLE_MAP)) await setAccountRole(db, admin, r, c);
  await setTaxRate(db, admin, { code: 'T19', label: 'Taux test', ratePct: '19' });
  const caisse = await createFinancialAccount(db, acc, { name: 'Caisse', kind: 'cash', ledgerAccount: '5000', openingBalance: '10000', openingEquityAccount: '1000', openingDate: '2026-01-01' });
  const banque = await createFinancialAccount(db, acc, { name: 'Banque', kind: 'bank', ledgerAccount: '5100', openingBalance: '50000', openingEquityAccount: '1000', openingDate: '2026-01-01' });
  const cust = await createCustomer(db, mgr, { ref: 'C1', name: 'Client' });
  const sup = await createSupplier(db, mgr, { ref: 'S1', name: 'Fournisseur' });
  return { db, caisse, banque, cust, sup };
}
const bal = async (db, code) => { const g = await generalLedger(db, code); return g.length ? g[g.length - 1].runningBalance.toString() : '0'; };
const line = (price, extra = {}) => ({ description: 'x', qty: '1', unitPrice: price, ...extra });

test('journal engine: balanced entries only, strict validation, sequential numbers', async () => {
  const { db } = await world();
  const ok = await postManualEntry(db, acc, { date: '2026-02-01', description: 'ok', lines: [{ account: '6900', debit: '100' }, { account: '5000', credit: '100' }] });
  assert.match(ok.number, /^JRN-2026-000\d$/);
  const bad = (lines, re) => assert.rejects(postManualEntry(db, acc, { date: '2026-02-01', description: 'x', lines }), re);
  await bad([{ account: '6900', debit: '100' }, { account: '5000', credit: '99.99' }], /Unbalanced/);
  await bad([{ account: '6900', debit: '100' }], /at least two/);
  await bad([{ account: '6900', debit: '100', credit: '100' }, { account: '5000', credit: '0' }], /both debit and credit/);
  await bad([{ account: '9999', debit: '1' }, { account: '5000', credit: '1' }], /Unknown or inactive/);
  await bad([{ account: '6900', debit: '1.005' }, { account: '5000', credit: '1.005' }], /2 decimals/);
  await bad([{ account: '6900', debit: '-1' }, { account: '5000', credit: '-1' }], /negative/);
  await assert.rejects(postManualEntry(db, { id: 's', role: 'sales' }, { date: '2026-02-01', description: 'x', lines: [] }), PermissionError);
  assert.deepEqual(await verifyLedgerIntegrity(db), []);
});
test('journal entries are immutable at database level; duplicate source posts once', async () => {
  const { db } = await world();
  const e = await postManualEntry(db, acc, { date: '2026-02-01', description: 'x', lines: [{ account: '6900', debit: '5' }, { account: '5000', credit: '5' }] });
  await assert.rejects(db.run("UPDATE journal_entries SET description='y'"), /immutable/);
  await assert.rejects(db.run('DELETE FROM journal_entries'), /immutable/);
  await assert.rejects(db.run('UPDATE journal_lines SET debit_u=1'), /immutable/);
  await assert.rejects(db.run('DELETE FROM journal_lines'), /immutable/);
  const a = await postManualEntry(db, acc, { date: '2026-02-01', description: 's', sourceType: 'x', sourceId: '1', lines: [{ account: '6900', debit: '5' }, { account: '5000', credit: '5' }] });
  const b = await postManualEntry(db, acc, { date: '2026-02-01', description: 's', sourceType: 'x', sourceId: '1', lines: [{ account: '6900', debit: '5' }, { account: '5000', credit: '5' }] });
  assert.equal(a.duplicate, false); assert.equal(b.duplicate, true);
  void e;
});
test('reversal: nets to zero, original untouched, cannot reverse twice or reverse a reversal', async () => {
  const { db } = await world();
  const e = await postManualEntry(db, acc, { date: '2026-02-01', description: 'x', lines: [{ account: '6900', debit: '250' }, { account: '5000', credit: '250' }] });
  assert.equal(await bal(db, '6900'), '250');
  const r = await reverseManualEntry(db, acc, e.id, { date: '2026-02-02', reason: 'erreur' });
  assert.equal(await bal(db, '6900'), '0');
  await assert.rejects(reverseManualEntry(db, acc, e.id, {}), /already reversed/);
  await assert.rejects(reverseManualEntry(db, acc, r.id, {}), /cannot be reversed/);
  assert.equal((await db.get('SELECT description d FROM journal_entries WHERE id=?', [e.id])).d, 'x');
});
test('closed period blocks posting, and the whole business transaction rolls back', async () => {
  const { db, cust } = await world();
  await closePeriod(db, admin, '2026-01');
  await assert.rejects(closePeriod(db, acc, '2026-02'), PermissionError);
  await assert.rejects(postManualEntry(db, acc, { date: '2026-01-15', description: 'x', lines: [{ account: '6900', debit: '1' }, { account: '5000', credit: '1' }] }), /closed/);
  await assert.rejects(issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-20', lines: [line('100')] }), /closed/);
  assert.equal((await db.get('SELECT COUNT(*) n FROM invoices')).n, 0);
  const ok = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-20', lines: [line('100')] });
  assert.equal(ok.number, 'FAC-2026-0001'); // number was not burned by the failed attempt
});
test('invoice → journal: Dr clients 1190 / Cr ventes 1000 / Cr TVA collectée 190; subledger = control account', async () => {
  const { db, cust } = await world();
  const inv = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [line('1000', { taxCode: 'T19' })] });
  assert.equal(inv.posting.skipped, false);
  assert.deepEqual([await bal(db, '3000'), await bal(db, '7000'), await bal(db, '4100')], ['1190', '-1000', '-190']);
  await recordPayment(db, mgr, { customerId: cust, amount: '500', method: 'bank_transfer', eventKey: 'p1', payDate: '2026-02-05', finAccountId: (await db.get("SELECT id FROM financial_accounts WHERE name='Banque'")).id });
  assert.equal(await bal(db, '3000'), '690');
  assert.equal((await customerBalance(db, cust)).balance.toString(), '690'); // customer subledger == ledger control account
  assert.equal(await bal(db, '5100'), '50500');
  const tb = await trialBalance(db); assert.equal(tb.balanced, true);
});
test('cancelling an invoice or payment posts reversals and restores cash', async () => {
  const { db, cust, banque } = await world();
  const inv = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [line('1000', { taxCode: 'T19' })] });
  const p = await recordPayment(db, mgr, { customerId: cust, amount: '300', method: 'cash', eventKey: 'p', payDate: '2026-02-02', finAccountId: banque });
  await cancelPayment(db, mgr, p.id, 'erreur');
  assert.equal((await cashBalance(db, banque)).toString(), '50000'); assert.equal(await bal(db, '5100'), '50000');
  await cancelInvoice(db, mgr, inv.id, 'erreur');
  assert.deepEqual([await bal(db, '3000'), await bal(db, '7000'), await bal(db, '4100')], ['0', '0', '0']);
  assert.equal((await reconcileCash(db)).every((r) => r.ok), true);
  assert.deepEqual(await verifyLedgerIntegrity(db), []);
});
test('credit note posts pro-rata tax: 595 of a 1190 invoice → Dr ventes 500, Dr TVA 95, Cr clients 595', async () => {
  const { db, cust } = await world();
  const inv = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [line('1000', { taxCode: 'T19' })] });
  await issueCreditNote(db, mgr, { invoiceId: inv.id, amount: '595', reason: 'retour', issueDate: '2026-02-10' });
  assert.deepEqual([await bal(db, '3000'), await bal(db, '7000'), await bal(db, '4100')], ['595', '-500', '-95']);
});
test('accounting configured late: documents are kept, reported as pending, then posted exactly once', async () => {
  const { db, cust, banque } = await world({ roles: false });
  const inv = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [line('1000', { taxCode: 'T19' })] });
  assert.equal(inv.posting.skipped, true); assert.equal(inv.posting.reason, 'accounting_roles_not_configured');
  assert.ok(inv.posting.missing.includes('receivable'));
  await recordPayment(db, mgr, { customerId: cust, amount: '100', method: 'cash', eventKey: 'a', payDate: '2026-02-02', finAccountId: banque });
  await recordPayment(db, mgr, { customerId: cust, amount: '50', method: 'cash', eventKey: 'b', payDate: '2026-02-02' }); // no financial account
  for (const [r, c] of Object.entries(ROLE_MAP)) await setAccountRole(db, admin, r, c);
  const r1 = await postPending(db, acc);
  assert.deepEqual(r1.posted.map((x) => x.kind).sort(), ['customer_payment', 'invoice']);
  assert.deepEqual(r1.skipped.map((x) => x.reason), ['no_financial_account']);
  const r2 = await postPending(db, acc);
  assert.equal(r2.posted.length, 0);
  assert.equal(await bal(db, '3000'), '1090');
  assert.equal((await trialBalance(db)).balanced, true);
});
test('expenses: cash out + journal; duplicate key no-op; overdraft blocked atomically; cancel restores', async () => {
  const { db, caisse } = await world();
  await createExpenseCategory(db, mgr, { code: 'ELEC', name_fr: 'Électricité', accountCode: '6000' });
  await assert.rejects(createExpenseCategory(db, mgr, { code: 'X', name_fr: 'x', accountCode: '7000' }), /expense account/);
  const e = await recordExpense(db, mgr, { date: '2026-02-03', categoryCode: 'ELEC', amount: '3000', finAccountId: caisse, eventKey: 'e1' });
  assert.match(e.number, /^DEP-2026-0001$/);
  assert.equal((await recordExpense(db, mgr, { date: '2026-02-03', categoryCode: 'ELEC', amount: '3000', finAccountId: caisse, eventKey: 'e1' })).duplicate, true);
  assert.equal((await cashBalance(db, caisse)).toString(), '7000');
  assert.deepEqual([await bal(db, '6000'), await bal(db, '5000')], ['3000', '7000']);
  await assert.rejects(recordExpense(db, mgr, { date: '2026-02-03', categoryCode: 'ELEC', amount: '8000', finAccountId: caisse, eventKey: 'e2' }), /Insufficient funds/);
  assert.equal((await db.get('SELECT COUNT(*) n FROM expenses')).n, 1);
  assert.equal((await expensesByCategory(db, { from: '2026-02-01', to: '2026-02-28' }))[0].total.toString(), '3000');
  await cancelExpense(db, mgr, e.id, 'doublon');
  assert.equal((await cashBalance(db, caisse)).toString(), '10000'); assert.equal(await bal(db, '6000'), '0');
  assert.equal((await expensesByCategory(db, { from: '2026-02-01', to: '2026-02-28' })).length, 0);
  await assert.rejects(cancelExpense(db, mgr, e.id, 'again'), /already cancelled/);
  await assert.rejects(recordExpense(db, { id: 'o', role: 'prod_operator' }, { categoryCode: 'ELEC', amount: '1', finAccountId: caisse, eventKey: 'z' }), PermissionError);
});
test('transfers: move money, never revenue/expense, idempotent, overdraft/same-account blocked', async () => {
  const { db, caisse, banque } = await world();
  const t = await transfer(db, acc, { fromId: caisse, toId: banque, amount: '2000', date: '2026-02-04', eventKey: 't1' });
  assert.match(t.number, /^VIR-2026-0001$/);
  assert.equal((await transfer(db, acc, { fromId: caisse, toId: banque, amount: '2000', date: '2026-02-04', eventKey: 't1' })).duplicate, true);
  assert.deepEqual([(await cashBalance(db, caisse)).toString(), (await cashBalance(db, banque)).toString()], ['8000', '52000']);
  const is = await incomeStatement(db, { from: '2026-01-01', to: '2026-12-31' });
  assert.equal(is.totalRevenue.toString(), '0'); assert.equal(is.totalExpenses.toString(), '0');
  await assert.rejects(transfer(db, acc, { fromId: caisse, toId: banque, amount: '9000', eventKey: 't2' }), /Insufficient funds/);
  await assert.rejects(transfer(db, acc, { fromId: caisse, toId: caisse, amount: '1', eventKey: 't3' }), /differ/);
  assert.equal((await reconcileCash(db)).every((r) => r.ok), true);
});
test('reconciliation flags a discrepancy when someone posts directly to a cash ledger account', async () => {
  const { db } = await world();
  await postManualEntry(db, acc, { date: '2026-02-01', description: 'manuel', lines: [{ account: '5000', debit: '77' }, { account: '1000', credit: '77' }] });
  const r = (await reconcileCash(db)).find((x) => x.ledgerAccount === '5000');
  assert.equal(r.ok, false); assert.equal(r.difference.toString(), '-77');
});
test('purchasing: PO → approve → partial receipts (stock only on receipt) → over-receipt blocked', async () => {
  const { db, sup } = await world();
  const resin = await createMaterial(db, mgr, { ref: 'RM1', name: 'Granulé', unit: 'kg', purchase_cost: '100' });
  const po = await createPurchaseOrder(db, mgr, { supplierId: sup, orderDate: '2026-03-01', lines: [{ materialId: resin, qty: '500', unitPrice: '100' }] });
  assert.match(po.number, /^BC-2026-0001$/);
  await assert.rejects(receiveGoods(db, mgr, po.id, { lines: [{ lineNo: 1, qty: '1' }] }), /Cannot receive/);
  assert.equal((await getBalance(db, 'material', resin)).toString(), '0');
  await approvePurchaseOrder(db, mgr, po.id);
  assert.equal((await receiveGoods(db, mgr, po.id, { lines: [{ lineNo: 1, qty: '300' }], date: '2026-03-05' })).poStatus, 'partially_received');
  assert.equal((await getBalance(db, 'material', resin)).toString(), '300');
  await assert.rejects(receiveGoods(db, mgr, po.id, { lines: [{ lineNo: 1, qty: '201' }] }), /Over-receipt/);
  assert.equal((await receiveGoods(db, mgr, po.id, { lines: [{ lineNo: 1, qty: '200' }], date: '2026-03-06' })).poStatus, 'received');
  assert.equal((await getBalance(db, 'material', resin)).toString(), '500');
  await assert.rejects(createPurchaseOrder(db, { id: 's', role: 'sales' }, { supplierId: sup, lines: [] }), PermissionError);
});
test('supplier invoice + payments: Dr stock 50000 / Dr TVA 9500 / Cr fournisseurs 59500; no overpayment; control account = payables', async () => {
  const { db, sup, banque } = await world();
  const inv = await recordSupplierInvoice(db, mgr, { supplierId: sup, supplierRef: 'F-100', issueDate: '2026-03-10', lines: [{ description: 'Granulé', qty: '500', unitPrice: '100', taxCode: 'T19' }] });
  assert.equal(inv.totals.totalTtc.toString(), '59500');
  assert.deepEqual([await bal(db, '2100'), await bal(db, '3100'), await bal(db, '4000')], ['50000', '9500', '-59500']);
  await assert.rejects(recordSupplierInvoice(db, mgr, { supplierId: sup, supplierRef: 'F-100', lines: [{ description: 'again', qty: '1', unitPrice: '1' }] }), /already recorded/);
  const pay = { supplierId: sup, finAccountId: banque, method: 'bank_transfer', payDate: '2026-03-20' };
  await assert.rejects(paySupplier(db, mgr, { ...pay, amount: '60000', eventKey: 'x', allocations: [{ invoiceId: inv.id, amount: '60000' }] }), /exceeds the outstanding/);
  await assert.rejects(paySupplier(db, mgr, { ...pay, amount: '100', eventKey: 'y', allocations: [{ invoiceId: inv.id, amount: '99' }] }), /add up/);
  assert.equal((await cashBalance(db, banque)).toString(), '50000');
  const p = await paySupplier(db, mgr, { ...pay, amount: '20000', eventKey: 'p1', allocations: [{ invoiceId: inv.id, amount: '20000' }] });
  assert.equal((await paySupplier(db, mgr, { ...pay, amount: '20000', eventKey: 'p1', allocations: [{ invoiceId: inv.id, amount: '20000' }] })).duplicate, true);
  assert.equal((await cashBalance(db, banque)).toString(), '30000');
  assert.equal((await supplierInvoiceOutstanding(db, inv.id)).toString(), '39500');
  assert.equal((await supplierBalance(db, sup)).toString(), '39500');
  assert.equal(await bal(db, '4000'), '-39500'); // ledger control account equals the supplier subledger
  assert.match(p.number, /^RFO-2026-0001$/);
  await assert.rejects(db.run('DELETE FROM supplier_payment_allocations'), /immutable/);
  await assert.rejects(db.run('DELETE FROM supplier_invoices'), /cannot be deleted/);
  await assert.rejects(db.run("UPDATE supplier_invoice_lines SET qty='1'"), /immutable/);
  await assert.rejects(db.run("UPDATE supplier_invoices SET total_ttc='1'"), /immutable/);
});
test('draft PO from shortages: priced shortages only, never approved, no stock effect', async () => {
  const { db, sup } = await world();
  const prod = await createProduct(db, mgr, { ref: 'P1', name_fr: 'Caisse' });
  const resin = await createMaterial(db, mgr, { ref: 'RM1', name: 'Granulé', unit: 'kg', purchase_cost: '120' });
  const mb = await createMaterial(db, mgr, { ref: 'RM3', name: 'Masterbatch', unit: 'kg' }); // no cost on file
  const rc = await createRecipe(db, mgr, { productId: prod, lines: [{ materialId: resin, qtyPerUnit: '0.8', lossPct: '5' }, { materialId: mb, qtyPerUnit: '0.02' }] });
  await postMovement(db, mgr, { type: 'opening', itemType: 'material', itemId: resin, qty: '600', eventKey: 'o1' });
  const d = await draftPoFromShortages(db, mgr, { supplierId: sup, recipeId: rc.id, plannedQty: '1000' }); // needs 840 resin → short 240; mb short 20
  assert.deepEqual(d.missingPrice, ['RM3']);
  const lines = await db.all('SELECT * FROM po_lines WHERE po_id=?', [d.po.id]);
  assert.equal(lines.length, 1); assert.equal(lines[0].qty, '240'); assert.equal(lines[0].unit_price, '120');
  assert.equal((await db.get('SELECT status FROM purchase_orders WHERE id=?', [d.po.id])).status, 'draft');
  assert.equal((await getBalance(db, 'material', resin)).toString(), '600');
});
test('financial reports tie out: trial balance, income statement, balance sheet (hand-computed)', async () => {
  const { db, cust, caisse } = await world();
  await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [line('1000', { taxCode: 'T19' })] });
  await createExpenseCategory(db, mgr, { code: 'ELEC', name_fr: 'Électricité', accountCode: '6000' });
  await recordExpense(db, mgr, { date: '2026-02-03', categoryCode: 'ELEC', amount: '300', finAccountId: caisse, eventKey: 'e' });
  const tb = await trialBalance(db);
  assert.equal(tb.balanced, true); assert.equal(tb.debit.toString(), '61490'); // 60000 opening + 1190 invoice + 300 expense
  const is = await incomeStatement(db, { from: '2026-01-01', to: '2026-12-31' });
  assert.deepEqual([is.totalRevenue, is.totalExpenses, is.netResult].map(String), ['1000', '300', '700']);
  const bs = await balanceSheet(db, { asOf: '2026-12-31' });
  assert.deepEqual([bs.totalAssets, bs.totalLiabilities, bs.totalEquity, bs.currentResult].map(String), ['60890', '190', '60700', '700']);
  assert.equal(bs.balanced, true);
  const jan = await incomeStatement(db, { from: '2026-01-01', to: '2026-01-31' });
  assert.equal(jan.netResult.toString(), '0'); // date filtering works
  assert.deepEqual(await verifyLedgerIntegrity(db), []);
});
test('integrity check detects an unbalanced entry inserted behind the service layer', async () => {
  const { db } = await world();
  await db.run("INSERT INTO journal_entries(id,number,entry_date,period,description,created_at) VALUES ('bad','JRN-BAD','2026-02-01','2026-02','raw','t')");
  await db.run("INSERT INTO journal_lines(entry_id,line_no,account_code,debit_u,credit_u) VALUES ('bad',1,'6900',1000000,0)");
  await db.run("INSERT INTO journal_lines(entry_id,line_no,account_code,debit_u,credit_u) VALUES ('bad',2,'5000',0,999900)");
  assert.deepEqual(await verifyLedgerIntegrity(db), ['JRN-BAD']);
  assert.equal((await trialBalance(db)).balanced, false);
});
test('accounts: duplicate code rejected; roles need an existing account; starter chart is idempotent', async () => {
  const { db } = await world();
  await assert.rejects(createAccount(db, acc, { code: '6900', name_fr: 'dup', type: 'expense' }), /Duplicate/);
  await assert.rejects(setAccountRole(db, admin, 'receivable', '0000'), /Unknown/);
  await assert.rejects(setAccountRole(db, admin, 'nonsense', '3000'), /Unknown role/);
  assert.equal(await seedStarterChart(db, admin), 0);
});

import { setupStarterAccounting } from '../src/core/setup.js';
test('starter accounting setup: idempotent, enables auto-posting, admin only', async () => {
  const { db } = await initDatabase(createNodeDriver());
  await assert.rejects(setupStarterAccounting(db, { id: 'm', role: 'manager' }), PermissionError);
  const r1 = await setupStarterAccounting(db, admin), r2 = await setupStarterAccounting(db, admin);
  assert.ok(r1.accountsAdded > 10 && r1.categoriesAdded === 6); assert.deepEqual(r2, { accountsAdded: 0, categoriesAdded: 0 });
  const cust = await createCustomer(db, mgr, { ref: 'C1', name: 'Client' });
  const inv = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [{ description: 'x', qty: '1', unitPrice: '100' }] });
  assert.equal(inv.posting.skipped, false);
});
