import test from 'node:test';
import assert from 'node:assert/strict';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { seedStarterChart, setAccountRole, postManualEntry } from '../src/core/ledger.js';
import { createProduct, createMaterial, createRecipe } from '../src/core/catalog.js';
import { postMovement } from '../src/core/inventory.js';
import { createOrder, planOrder, startOrder, completeOrder } from '../src/core/production.js';
import { setTaxRate, createCustomer } from '../src/core/parties.js';
import { createSalesOrder, confirmSalesOrder } from '../src/core/sales.js';
import { issueInvoice, issueCreditNote } from '../src/core/invoicing.js';
import { recordPayment } from '../src/core/receivables.js';
import { createFinancialAccount, createExpenseCategory, recordExpense } from '../src/core/cash.js';
import { setBudget } from '../src/core/budgets.js';
import { createMachine, createMaintenancePlan } from '../src/core/machines.js';
import { computeAlerts, getThresholds, setThresholds, DEFAULT_THRESHOLDS } from '../src/core/alerts.js';
import { ask, SUPPORTED_QUESTIONS } from '../src/core/assistant.js';
import { createBackup } from '../src/core/backup.js';
import { today, addDays } from '../src/core/dates.js';
import { PermissionError } from '../src/core/permissions.js';

const admin = { id: 'a', role: 'admin' }, mgr = { id: 'm', role: 'manager' };
const ROLES = { receivable: '3000', payable: '4000', sales_revenue: '7000', tax_collected: '4100', tax_deductible: '3100', inventory_materials: '2100', inventory_finished: '2200', cogs: '6500', production_waste: '6600' };

async function base() {
  const { db } = await initDatabase(createNodeDriver());
  await seedStarterChart(db, admin); for (const [r, c] of Object.entries(ROLES)) await setAccountRole(db, admin, r, c);
  await setTaxRate(db, admin, { code: 'T19', label: 'Taux test', ratePct: '19' });
  const caisse = await createFinancialAccount(db, mgr, { name: 'Caisse', kind: 'cash', ledgerAccount: '5000', openingBalance: '100000', openingEquityAccount: '1000', openingDate: '2026-01-01' });
  await createExpenseCategory(db, mgr, { code: 'ELEC', name_fr: 'Électricité', accountCode: '6000' });
  const product = await createProduct(db, mgr, { ref: 'PL001', name_fr: 'Grande caisse', name_ar: 'الصندوق الكبير', min_stock: '100' });
  const resin = await createMaterial(db, mgr, { ref: 'RM001', name: 'Granulé', unit: 'kg', min_stock: '100' });
  const rc = await createRecipe(db, mgr, { productId: product, lines: [{ materialId: resin, qtyPerUnit: '0.8', lossPct: '5' }] });
  const cust = await createCustomer(db, mgr, { ref: 'C1', name: 'Client Un', credit_limit: '1000' });
  return { db, caisse, product, resin, rc, cust };
}
const stock = (db, id, qty, key, cost = '100') => postMovement(db, mgr, { type: 'receipt', itemType: 'material', itemId: id, qty, unitCost: cost, eventKey: key });
const line = (p) => ({ description: 'x', qty: '1', unitPrice: p });
const alertOf = (alerts, code) => alerts.filter((a) => a.code === code);
const inProgress = async (db, product, rc, qty, extra = {}) => { const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: qty, ...extra }); await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id); return o; };

// ------------------------------------------------------------------ alerts
test('thresholds: defaults, admin-only, validated, persisted and applied', async () => {
  const { db } = await base();
  assert.deepEqual(await getThresholds(db), DEFAULT_THRESHOLDS);
  await assert.rejects(setThresholds(db, mgr, { rejectionPct: '3' }), PermissionError);
  await assert.rejects(setThresholds(db, admin, { nonsense: '1' }), /Unknown threshold/);
  await assert.rejects(setThresholds(db, admin, { rejectionPct: '-1' }), /negative/);
  assert.equal((await setThresholds(db, admin, { rejectionPct: '12' })).rejectionPct, '12');
  assert.equal((await getThresholds(db)).rejectionPct, '12'); assert.equal((await getThresholds(db)).budgetWarnPct, '90');
});
test('low stock and insufficient materials for planned production (shortage = required − available)', async () => {
  const { db, product, resin, rc } = await base();
  await stock(db, resin, '90', 's1');
  let a = await computeAlerts(db, { asOf: '2026-03-15' });
  assert.equal(alertOf(a, 'low_stock').find((x) => x.subject === 'RM001').data.balance, '90');
  assert.ok(alertOf(a, 'low_stock').some((x) => x.subject === 'PL001')); // product min 100, stock 0
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '1000' }); await planOrder(db, mgr, o.id);
  a = await computeAlerts(db, { asOf: '2026-03-15' });
  const ins = alertOf(a, 'insufficient_materials')[0];
  assert.deepEqual([ins.severity, ins.data.required, ins.data.available, ins.data.shortage], ['critical', '840', '90', '750']);
});
test('overdue invoices: severity by age, cleared when paid; credit limit exceeded', async () => {
  const { db, cust } = await base();
  const inv = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-01', lines: [line('1500')] }); // due 01-31, over the 1000 limit
  let a = await computeAlerts(db, { asOf: '2026-02-15' });
  assert.deepEqual([alertOf(a, 'overdue_invoice')[0].severity, alertOf(a, 'overdue_invoice')[0].data.daysOverdue], ['warning', 15]);
  a = await computeAlerts(db, { asOf: '2026-03-15' }); assert.equal(alertOf(a, 'overdue_invoice')[0].severity, 'critical');
  assert.equal(alertOf(a, 'credit_limit_exceeded')[0].data.balance, '1500');
  await recordPayment(db, mgr, { customerId: cust, amount: '1500', method: 'cash', eventKey: 'p', payDate: '2026-02-20', allocations: [{ invoiceId: inv.id, amount: '1500' }] });
  a = await computeAlerts(db, { asOf: '2026-03-15' });
  assert.equal(alertOf(a, 'overdue_invoice').length + alertOf(a, 'credit_limit_exceeded').length, 0);
});
test('high rejection uses the configurable threshold; unusual consumption uses tolerance', async () => {
  const { db, product, resin, rc } = await base();
  await stock(db, resin, '1000', 's');
  const o = await inProgress(db, product, rc, '100');
  await completeOrder(db, mgr, o.id, { totalQty: '100', acceptedQty: '90', rejectedQty: '10', consumption: [{ materialId: resin, qty: '100' }] }); // expected 84 → 100 is +19%
  let a = await computeAlerts(db, { asOf: today() });
  assert.equal(alertOf(a, 'high_rejection')[0].data.ratePct, '10');
  const uc = alertOf(a, 'unusual_consumption')[0]; assert.deepEqual([uc.data.expected, uc.data.actual], ['84', '100']);
  await setThresholds(db, admin, { rejectionPct: '15', consumptionTolerancePct: '25' });
  a = await computeAlerts(db, { asOf: today() });
  assert.equal(alertOf(a, 'high_rejection').length + alertOf(a, 'unusual_consumption').length, 0);
});
test('production delay, maintenance (due/overdue), budget warning/exceeded, expense spike', async () => {
  const { db, product, rc, caisse } = await base();
  await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '10', plannedDate: '2026-03-01' });
  const mc = await createMachine(db, mgr, { ref: 'M1', name: 'Presse' });
  await createMaintenancePlan(db, mgr, { machineId: mc, task: 'Graissage', intervalDays: 30, startDate: '2026-01-01' }); // due 2026-01-31
  await setBudget(db, mgr, { period: '2026-03', categoryCode: 'ELEC', amount: '2000' });
  await recordExpense(db, mgr, { date: '2026-02-10', categoryCode: 'ELEC', amount: '1000', finAccountId: caisse, eventKey: 'f' });
  await recordExpense(db, mgr, { date: '2026-03-05', categoryCode: 'ELEC', amount: '1850', finAccountId: caisse, eventKey: 'm1' });
  let a = await computeAlerts(db, { asOf: '2026-03-10' });
  assert.equal(alertOf(a, 'production_delay')[0].data.daysLate, 9);
  assert.equal(alertOf(a, 'maintenance_overdue')[0].data.daysLeft, -38);
  assert.equal(alertOf(a, 'budget_warning')[0].data.usedPct, '92.5');
  const sp = alertOf(a, 'expense_spike')[0]; assert.deepEqual([sp.data.current, sp.data.previous, sp.data.increasePct], ['1850', '1000', '85']);
  await recordExpense(db, mgr, { date: '2026-03-06', categoryCode: 'ELEC', amount: '200', finAccountId: caisse, eventKey: 'm2' });
  a = await computeAlerts(db, { asOf: '2026-03-10' });
  assert.equal(alertOf(a, 'budget_exceeded')[0].severity, 'critical'); assert.equal(alertOf(a, 'budget_warning').length, 0);
});
test('data-integrity alerts: cash/ledger mismatch, possible duplicate payments, backup status, incomplete company identity', async () => {
  const { db, cust } = await base();
  await postManualEntry(db, mgr, { date: '2026-02-01', description: 'manuel', lines: [{ account: '5000', debit: '77' }, { account: '1000', credit: '77' }] });
  await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-01', lines: [line('900')] });
  for (const k of ['a', 'b']) await recordPayment(db, mgr, { customerId: cust, amount: '100', method: 'cash', eventKey: k, payDate: '2026-02-05' });
  let a = await computeAlerts(db, { asOf: '2026-02-10' });
  assert.equal(alertOf(a, 'cash_ledger_mismatch')[0].data.difference, '-77');
  assert.equal(alertOf(a, 'possible_duplicate_payment')[0].data.count, 2);
  assert.equal(alertOf(a, 'backup_stale').length, 1);
  assert.deepEqual(alertOf(a, 'company_identity_incomplete')[0].data.missing, ['address', 'nif', 'nis', 'rc']);
  await createBackup(db, admin);
  assert.equal(alertOf(await computeAlerts(db, { asOf: today() }), 'backup_stale').length, 0);
  await db.run("INSERT INTO backup_log(ts,kind,status,detail) VALUES (?, 'create', 'failed', 'disk full')", [new Date(Date.now() + 1000).toISOString()]);
  a = await computeAlerts(db, { asOf: today() });
  assert.equal(alertOf(a, 'backup_failed')[0].severity, 'critical');
  assert.equal(a[0].severity, 'critical'); // sorted by severity
});

// ------------------------------------------------------------------ assistant
test('assistant: permissions and read-only safety (mutation requests refused, nothing changes)', async () => {
  const { db, cust } = await base();
  await issueInvoice(db, mgr, { customerId: cust, lines: [line('100')] });
  const counts = async () => JSON.stringify([await db.get('SELECT COUNT(*) n FROM invoices'), await db.get('SELECT COUNT(*) n FROM payments'), await db.get('SELECT COUNT(*) n FROM journal_entries'), await db.get('SELECT COUNT(*) n FROM customers')]);
  const before = await counts();
  for (const q of ['Supprimer la facture FAC-2026-0001', 'Payer le fournisseur', 'paye la facture', 'Annuler la dernière facture', 'احذف العميل', 'ادفع الفاتورة', 'Delete all invoices', 'Crée un client']) {
    const r = await ask(db, mgr, q); assert.equal(r.intent, 'refused', q);
  }
  assert.equal(await counts(), before);
  assert.notEqual((await ask(db, mgr, 'Quelles sont les factures impayées ?')).intent, 'refused'); // "impayées" is a read question
  await assert.rejects(ask(db, { id: 'o', role: 'prod_operator' }, 'factures en retard ?'), PermissionError); // no assistant access
  await assert.rejects(ask(db, { id: 's', role: 'sales' }, 'Dépenses du mois ?'), PermissionError);          // assistant ok, expenses not readable
});
test('assistant: unknown or empty questions get guidance, never an invented answer', async () => {
  const { db } = await base();
  const r = await ask(db, mgr, 'Quelle est la météo ?'); assert.equal(r.intent, null); assert.deepEqual(r.supported, SUPPORTED_QUESTIONS);
  assert.equal((await ask(db, mgr, '  ')).intent, null);
});
test('assistant: production today — insufficient data message, then two separate sources (no double counting)', async () => {
  const { db, product, resin, rc } = await base();
  let r = await ask(db, mgr, "Qu'est-ce qui a été produit aujourd'hui ?", { asOf: today() });
  assert.equal(r.intent, 'production_today'); assert.equal(r.insufficient, true);
  await stock(db, resin, '500', 's'); const o = await inProgress(db, product, rc, '100');
  await completeOrder(db, mgr, o.id, { totalQty: '100', acceptedQty: '90', rejectedQty: '10', consumption: [{ materialId: resin, qty: '84' }] });
  r = await ask(db, mgr, "Qu'a-t-on produit aujourd'hui ?", { asOf: today() });
  assert.deepEqual([r.data.completedOrders.accepted.toString(), r.data.completedOrders.rejected.toString(), r.data.shiftOutput.records], ['90', '10', 0]);
  assert.match(r.basis, /double comptage/);
  r = await ask(db, mgr, 'ما هو إنتاج اليوم؟', { asOf: today(), lang: 'ar' });
  assert.equal(r.intent, 'production_today'); assert.match(r.text, /[\u0600-\u06FF]/);
});
test('assistant: availability = physical − reserved (100 in stock, 60 reserved → 40), FR and AR', async () => {
  const { db, product, cust } = await base();
  await postMovement(db, mgr, { type: 'opening', itemType: 'product', itemId: product, qty: '100', eventKey: 'o' });
  const so = await createSalesOrder(db, mgr, { customerId: cust, lines: [{ productId: product, qty: '60', unitPrice: '950' }] }); await confirmSalesOrder(db, mgr, so.id);
  for (const [q, lang] of [['Combien de caisses sont disponibles ?', 'fr'], ['كم صندوق متوفر؟', 'ar']]) {
    const r = await ask(db, mgr, q, { lang });
    assert.equal(r.intent, 'products_available', q);
    assert.deepEqual([r.data[0].physical, r.data[0].reserved, r.data[0].available].map(String), ['100', '60', '40']);
  }
});
test('assistant: low materials (FR/AR), requirements for tomorrow (840 kg, shortage), maintenance, orders in progress', async () => {
  const { db, product, resin, rc } = await base();
  await stock(db, resin, '90', 's');
  const low = await ask(db, mgr, 'Quelles matières premières sont faibles ?'); assert.equal(low.intent, 'low_materials'); assert.equal(low.data[0].ref, 'RM001');
  assert.equal((await ask(db, mgr, 'ما هي المواد الأولية المنخفضة؟', { lang: 'ar' })).intent, 'low_materials');
  const asOf = '2026-03-10';
  assert.equal((await ask(db, mgr, 'Quels sont les besoins en matières pour demain ?', { asOf })).insufficient, true); // nothing scheduled
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '1000', plannedDate: '2026-03-11' });
  const req = await ask(db, mgr, 'Quels sont les besoins en matières pour demain ?', { asOf });
  assert.equal(req.intent, 'requirements_tomorrow'); assert.deepEqual([req.data.rows[0].required, req.data.rows[0].available, req.data.rows[0].shortage].map(String), ['840', '90', '750']);
  await planOrder(db, mgr, o.id);
  assert.equal((await ask(db, mgr, 'Quels ordres de production sont en cours ?')).data[0].number.slice(0, 3), 'OF-');
  const mc = await createMachine(db, mgr, { ref: 'M1', name: 'Presse' }); await createMaintenancePlan(db, mgr, { machineId: mc, task: 'Graissage', intervalDays: 30, startDate: '2026-01-01' });
  const m = await ask(db, mgr, 'Quelles machines ont une maintenance à prévoir ?', { asOf: '2026-01-28' }); assert.equal(m.data[0].dueDate, '2026-01-31');
});
test('assistant: receivables, sales and expenses with explained basis (hand-computed)', async () => {
  const { db, cust, caisse } = await base();
  const i1 = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-03', lines: [{ ...line('1000'), taxCode: 'T19' }] }); // 1190 TTC, due 03-05
  await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-10', lines: [line('500')] });                                    // due 03-12
  await recordPayment(db, mgr, { customerId: cust, amount: '190', method: 'cash', eventKey: 'p', payDate: '2026-02-12', allocations: [{ invoiceId: i1.id, amount: '190' }] });
  await issueCreditNote(db, mgr, { invoiceId: i1.id, amount: '100', reason: 'retour', issueDate: '2026-02-15' });
  await recordExpense(db, mgr, { date: '2026-02-20', categoryCode: 'ELEC', amount: '300', finAccountId: caisse, eventKey: 'e' });
  const sales = await ask(db, mgr, 'Quelles sont les ventes de ce mois ?', { asOf: '2026-02-20' });
  assert.deepEqual([sales.data.invoices, sales.data.totalHt, sales.data.totalTtc, sales.data.creditNotesTtc].map(String), ['2', '1500', '1690', '100']);
  const debt = await ask(db, mgr, 'Quelle est la dette totale des clients ?', { asOf: '2026-03-10' });
  assert.deepEqual([debt.data.outstanding, debt.data.overdue].map(String), ['1400', '900']); // 1190−190−100=900 overdue (due 03-05) + 500 not yet due
  assert.ok(debt.basis.length > 20);
  const over = await ask(db, mgr, 'Quelles factures sont en retard ?', { asOf: '2026-03-10' });
  assert.deepEqual([over.data.rows.length, over.data.total.toString()], [1, '900']);
  assert.equal((await ask(db, mgr, 'الفواتير المتأخرة', { asOf: '2026-03-10', lang: 'ar' })).intent, 'overdue_invoices');
  assert.equal((await ask(db, mgr, 'ديون العملاء', { asOf: '2026-03-10', lang: 'ar' })).intent, 'customer_debt');
  assert.equal((await ask(db, mgr, 'مبيعات هذا الشهر', { asOf: '2026-02-20', lang: 'ar' })).intent, 'sales_month');
  const exp = await ask(db, mgr, 'Quelles sont les dépenses de ce mois ?', { asOf: '2026-02-20' }); assert.equal(exp.data.total.toString(), '300');
  assert.equal((await ask(db, mgr, 'Dépenses du mois', { asOf: '2026-05-20' })).insufficient, true);
  assert.equal((await ask(db, mgr, 'Quelles factures sont impayées ?')).data.total.toString(), '1400');
});
test('assistant: product cost — clarification, insufficient data, estimate, then recorded cost', async () => {
  const { db, product, resin, rc } = await base();
  assert.equal((await ask(db, mgr, 'Quel est le coût de fabrication ?')).clarify, true);
  assert.equal((await ask(db, mgr, 'Quel est le coût de fabrication de PL001 ?')).insufficient, true); // recipe exists but no known material cost
  await stock(db, resin, '1000', 's', '100');
  const est = await ask(db, mgr, 'Quel est le coût de fabrication de PL001 ?'); // 0.8 kg × 1.05 × 100 = 84
  assert.deepEqual([est.data.kind, est.data.estimate.toString()], ['estimate', '84']); assert.match(est.basis, /ESTIMATION/);
  const o = await inProgress(db, product, rc, '100');
  await completeOrder(db, mgr, o.id, { totalQty: '100', acceptedQty: '80', rejectedQty: '20', consumption: [{ materialId: resin, qty: '84' }] }); // 8400 / 80 = 105
  const rec = await ask(db, mgr, 'Coût de fabrication de la grande caisse', {});
  assert.deepEqual([rec.data.kind, rec.data.unitMaterialCost.toString()], ['recorded', '105']);
});
