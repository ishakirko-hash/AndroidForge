import test from 'node:test';
import assert from 'node:assert/strict';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { createProduct } from '../src/core/catalog.js';
import { postMovement, getBalance } from '../src/core/inventory.js';
import { setTaxRate, createCustomer, createSupplier } from '../src/core/parties.js';
import { createSalesOrder, confirmSalesOrder, cancelSalesOrder, dispatchDelivery, availableStock, orderProgress } from '../src/core/sales.js';
import { computeInvoice, issueInvoice, cancelInvoice, issueCreditNote } from '../src/core/invoicing.js';
import { recordPayment, allocatePayment, cancelPayment, suggestAllocation, customerBalance, invoiceOutstanding, debtAging, openInvoices } from '../src/core/receivables.js';
import { PermissionError } from '../src/core/permissions.js';
import { D } from '../src/core/decimal.js';

const admin = { id: 'a', role: 'admin' }, mgr = { id: 'm', role: 'manager' };
async function world() {
  const { db } = await initDatabase(createNodeDriver());
  await setTaxRate(db, admin, { code: 'T19', label: 'Taux A (test)', ratePct: '19' });
  await setTaxRate(db, admin, { code: 'T09', label: 'Taux B (test)', ratePct: '9' });
  const cust = await createCustomer(db, mgr, { ref: 'C001', name: 'Client Test', payment_terms_days: 30 });
  const prod = await createProduct(db, mgr, { ref: 'PL001', name_fr: 'Caisse', sale_price: '950' });
  await postMovement(db, mgr, { type: 'opening', itemType: 'product', itemId: prod, qty: '100', eventKey: 'open:p' });
  return { db, cust, prod };
}
const simple = (amount, extra = {}) => ({ description: 'Service', qty: '1', unitPrice: amount, ...extra });

test('invoice maths (hand-computed): lines, discount, two tax rates, exempt line, totals by rate', () => {
  const c = computeInvoice([
    { description: 'a', qty: '3', unitPrice: '1250.50', discountPct: '5', taxRatePct: '19' },
    { description: 'b', qty: '10', unitPrice: '200', taxRatePct: '0' },
    { description: 'c', qty: '2', unitPrice: '500', taxRatePct: '9' }]);
  assert.deepEqual(c.lines.map((l) => [l.ht.toString(), l.tax.toString(), l.ttc.toString()]),
    [['3563.93', '677.15', '4241.08'], ['2000', '0', '2000'], ['1000', '90', '1090']]);
  assert.equal(c.subtotalHt.toString(), '6563.93');
  assert.equal(c.taxTotal.toString(), '767.15');
  assert.equal(c.totalTtc.toString(), '7331.08');
  assert.equal(c.discountTotal.toString(), '187.57');
  assert.deepEqual(c.taxesByRate.map((t) => [t.ratePct, t.base.toString(), t.tax.toString()]), [['19', '3563.93', '677.15'], ['0', '2000', '0'], ['9', '1000', '90']]);
  assert.equal(c.lines.reduce((a, l) => a.add(l.ttc), D(0)).toString(), c.totalTtc.toString()); // lines add up to total
});
test('tax rates are configuration: admin only, bounded, no defaults shipped', async () => {
  const { db } = await world();
  await assert.rejects(setTaxRate(db, { id: 'x', role: 'accountant' }, { code: 'Z', label: 'z', ratePct: '5' }), PermissionError);
  await assert.rejects(setTaxRate(db, admin, { code: 'Z', label: 'z', ratePct: '120' }), /between/);
  const fresh = (await initDatabase(createNodeDriver())).db;
  assert.equal((await fresh.get('SELECT COUNT(*) n FROM tax_rates')).n, 0);
});
test('customers/suppliers: duplicate ref and NIF rejected', async () => {
  const { db } = await world();
  await assert.rejects(createCustomer(db, mgr, { ref: 'C001', name: 'x' }), /Duplicate customer/);
  await createCustomer(db, mgr, { ref: 'C002', name: 'y', nif: '123' });
  await assert.rejects(createCustomer(db, mgr, { ref: 'C003', name: 'z', nif: '123' }), /NIF/);
  await createSupplier(db, mgr, { ref: 'S001', name: 'Fournisseur' });
  await assert.rejects(createSupplier(db, mgr, { ref: 'S001', name: 'again' }), /Duplicate supplier/);
});
test('sales flow: draft reserves nothing; confirm reserves; partial deliveries deduct exactly; over-delivery blocked', async () => {
  const { db, cust, prod } = await world();
  const o = await createSalesOrder(db, mgr, { customerId: cust, lines: [{ productId: prod, qty: '60', unitPrice: '950' }] });
  assert.deepEqual((await availableStock(db, prod)).reserved.toString(), '0');          // quotation/draft
  await confirmSalesOrder(db, mgr, o.id);
  let a = await availableStock(db, prod);
  assert.deepEqual([a.physical, a.reserved, a.available].map(String), ['100', '60', '40']);
  const d1 = await dispatchDelivery(db, mgr, o.id, { lines: [{ lineNo: 1, qty: '25' }] });
  assert.equal(d1.orderStatus, 'partially_delivered');
  a = await availableStock(db, prod);
  assert.deepEqual([a.physical, a.reserved, a.available].map(String), ['75', '35', '40']);
  await assert.rejects(dispatchDelivery(db, mgr, o.id, { lines: [{ lineNo: 1, qty: '40' }] }), /Over-delivery/);
  assert.equal((await getBalance(db, 'product', prod)).toString(), '75');
  const d2 = await dispatchDelivery(db, mgr, o.id, { lines: [{ lineNo: 1, qty: '35' }] });
  assert.equal(d2.orderStatus, 'delivered');
  assert.equal((await getBalance(db, 'product', prod)).toString(), '40');
  assert.equal((await orderProgress(db, o.id))[0].remaining.toString(), '0');
  await assert.rejects(dispatchDelivery(db, mgr, o.id, { lines: [{ lineNo: 1, qty: '1' }] }), /Cannot deliver/);
  assert.equal((await db.get('SELECT COUNT(*) n FROM stock_movements WHERE movement_type=\'dispatch\'')).n, 2);
});
test('dispatch without enough stock rolls back note, number and stock', async () => {
  const { db, cust, prod } = await world();
  const o = await createSalesOrder(db, mgr, { customerId: cust, lines: [{ productId: prod, qty: '200', unitPrice: '950' }] });
  await confirmSalesOrder(db, mgr, o.id);
  await assert.rejects(dispatchDelivery(db, mgr, o.id, { lines: [{ lineNo: 1, qty: '150' }] }), /Insufficient stock/);
  assert.equal((await db.get('SELECT COUNT(*) n FROM delivery_notes')).n, 0);
  assert.equal((await getBalance(db, 'product', prod)).toString(), '100');
  const ok = await dispatchDelivery(db, mgr, o.id, { lines: [{ lineNo: 1, qty: '100' }] });
  assert.match(ok.number, /^BL-\d{4}-0001$/); // number was not burned by the failed attempt
});
test('order cancel only before delivery; invalid order input rejected', async () => {
  const { db, cust, prod } = await world();
  await assert.rejects(createSalesOrder(db, mgr, { customerId: cust, lines: [] }), /at least one/);
  await assert.rejects(createSalesOrder(db, mgr, { customerId: cust, lines: [{ productId: prod, qty: '0', unitPrice: '1' }] }), /greater than zero/);
  const o = await createSalesOrder(db, mgr, { customerId: cust, lines: [{ productId: prod, qty: '5', unitPrice: '950' }] });
  await confirmSalesOrder(db, mgr, o.id); await dispatchDelivery(db, mgr, o.id, { lines: [{ lineNo: 1, qty: '1' }] });
  await assert.rejects(cancelSalesOrder(db, mgr, o.id), /Cannot cancel/);
});
test('invoice issue: snapshots tax rate, due date from terms, unknown tax code rejected, sequential numbers', async () => {
  const { db, cust } = await world();
  const i1 = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-01', lines: [simple('1000', { taxCode: 'T19' })] });
  assert.equal(i1.number, 'FAC-2026-0001'); assert.equal(i1.dueDate, '2026-01-31'); assert.equal(i1.totals.totalTtc.toString(), '1190');
  await setTaxRate(db, admin, { code: 'T19', label: 'changed', ratePct: '20' });  // later rate change must not alter the issued invoice
  const line = await db.get('SELECT tax_rate_pct, line_tax FROM invoice_lines WHERE invoice_id=?', [i1.id]);
  assert.deepEqual([line.tax_rate_pct, line.line_tax], ['19', '190']);
  const i2 = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-02', lines: [simple('10')] });
  assert.equal(i2.number, 'FAC-2026-0002');
  await assert.rejects(issueInvoice(db, mgr, { customerId: cust, lines: [simple('10', { taxCode: 'NOPE' })] }), /tax code/);
  await assert.rejects(issueInvoice(db, mgr, { customerId: cust, lines: [{ description: 'x', qty: '1', unitPrice: '1', discountPct: '101' }] }), /Discount/);
  assert.equal((await db.get('SELECT COUNT(*) n FROM invoices')).n, 2);
});
test('issued invoices are immutable and undeletable at database level', async () => {
  const { db, cust } = await world();
  const i = await issueInvoice(db, mgr, { customerId: cust, lines: [simple('100')] });
  await assert.rejects(db.run("UPDATE invoices SET total_ttc='1' WHERE id=?", [i.id]), /immutable/);
  await assert.rejects(db.run('DELETE FROM invoices WHERE id=?', [i.id]), /cannot be deleted/);
  await assert.rejects(db.run("UPDATE invoice_lines SET qty='9'"), /immutable/);
  await assert.rejects(db.run('DELETE FROM invoice_lines'), /immutable/);
});
test('payments: partial payment, remaining debt, allocation rules, excess kept as customer credit', async () => {
  const { db, cust } = await world();
  const i = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-01', lines: [{ description: 'x', qty: '1', unitPrice: '7331.08' }] });
  const p1 = await recordPayment(db, mgr, { customerId: cust, amount: '3000', method: 'cash', eventKey: 'k1', payDate: '2026-01-10', allocations: [{ invoiceId: i.id, amount: '3000' }] });
  assert.match(p1.number, /^REG-2026-0001$/);
  assert.equal((await invoiceOutstanding(db, i.id)).toString(), '4331.08');
  let b = await customerBalance(db, cust);
  assert.deepEqual([b.invoiced, b.paid, b.balance, b.unallocated].map(String), ['7331.08', '3000', '4331.08', '0']);
  await assert.rejects(recordPayment(db, mgr, { customerId: cust, amount: '100', method: 'cash', eventKey: 'k2', allocations: [{ invoiceId: i.id, amount: '200' }] }), /exceed/);
  await assert.rejects(recordPayment(db, mgr, { customerId: cust, amount: '5000', method: 'cash', eventKey: 'k3', allocations: [{ invoiceId: i.id, amount: '4331.09' }] }), /outstanding/);
  assert.equal((await db.get('SELECT COUNT(*) n FROM payments')).n, 1); // failed attempts left nothing behind
  await recordPayment(db, mgr, { customerId: cust, amount: '4500', method: 'bank_transfer', eventKey: 'k4', allocations: [{ invoiceId: i.id, amount: '4331.08' }] });
  b = await customerBalance(db, cust);
  assert.deepEqual([b.balance, b.unallocated].map(String), ['-168.92', '168.92']); // credit on account
  assert.equal((await invoiceOutstanding(db, i.id)).toString(), '0');
});
test('duplicate payment prevention: same event key is a no-op; same ref/amount/date flagged', async () => {
  const { db, cust } = await world();
  await issueInvoice(db, mgr, { customerId: cust, lines: [simple('1000')] });
  const a = await recordPayment(db, mgr, { customerId: cust, amount: '500', method: 'cheque', reference: 'CHQ-77', payDate: '2026-02-01', eventKey: 'e1' });
  const b = await recordPayment(db, mgr, { customerId: cust, amount: '500', method: 'cheque', reference: 'CHQ-77', payDate: '2026-02-01', eventKey: 'e1' });
  assert.equal(b.duplicate, true); assert.equal(b.id, a.id);
  await assert.rejects(recordPayment(db, mgr, { customerId: cust, amount: '500', method: 'cheque', reference: 'CHQ-77', payDate: '2026-02-01', eventKey: 'e2' }), /Possible duplicate/);
  assert.equal((await customerBalance(db, cust)).paid.toString(), '500');
});
test('allocation suggestion is oldest-due-first, posts nothing, reports excess; multi-invoice payment', async () => {
  const { db, cust } = await world();
  const b = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-02-10', lines: [simple('500')] });   // due 03-12
  const a = await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-01', lines: [simple('1000')] });  // due 01-31
  const s = await suggestAllocation(db, cust, '1700');
  assert.deepEqual(s.allocations.map((x) => [x.number, x.amount.toString()]), [[a.number, '1000'], [b.number, '500']]);
  assert.equal(s.excess.toString(), '200');
  assert.equal((await db.get('SELECT COUNT(*) n FROM payment_allocations')).n, 0);
  await recordPayment(db, mgr, { customerId: cust, amount: '1700', method: 'bank_transfer', eventKey: 'm1',
    allocations: s.allocations.map((x) => ({ invoiceId: x.invoiceId, amount: x.amount })) });
  assert.equal((await customerBalance(db, cust)).unallocated.toString(), '200');
  assert.equal((await openInvoices(db, cust)).length, 0);
});
test('allocating to another customer’s invoice is rejected; credit can be applied later', async () => {
  const { db, cust } = await world();
  const other = await createCustomer(db, mgr, { ref: 'C002', name: 'Autre' });
  const io = await issueInvoice(db, mgr, { customerId: other, lines: [simple('100')] });
  await assert.rejects(recordPayment(db, mgr, { customerId: cust, amount: '100', method: 'cash', eventKey: 'x1', allocations: [{ invoiceId: io.id, amount: '100' }] }), /not found for this customer/);
  const i = await issueInvoice(db, mgr, { customerId: cust, lines: [simple('300')] });
  const p = await recordPayment(db, mgr, { customerId: cust, amount: '300', method: 'cash', eventKey: 'x2' }); // on account
  assert.equal((await customerBalance(db, cust)).unallocated.toString(), '300');
  await allocatePayment(db, mgr, p.id, [{ invoiceId: i.id, amount: '300' }]);
  assert.equal((await customerBalance(db, cust)).unallocated.toString(), '0');
  await assert.rejects(allocatePayment(db, mgr, p.id, [{ invoiceId: i.id, amount: '1' }]), /outstanding/);
});
test('debt aging buckets (hand-computed dates)', async () => {
  const { db, cust } = await world();
  await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-01-01', lines: [simple('1000')] });   // due 01-31
  await issueInvoice(db, mgr, { customerId: cust, issueDate: '2026-03-01', lines: [simple('200')] });    // due 03-31
  const at = async (d) => (await debtAging(db, { asOf: d })).buckets;
  let k = await at('2026-01-20'); assert.equal(k.notDue.toString(), '1200');
  k = await at('2026-02-15'); assert.equal(k.d1_30.toString(), '1000'); assert.equal(k.notDue.toString(), '200');
  k = await at('2026-03-15'); assert.equal(k.d31_60.toString(), '1000');
  k = await at('2026-04-15'); assert.equal(k.d61_90.toString(), '1000'); assert.equal(k.d1_30.toString(), '200');
  k = await at('2026-05-15'); assert.equal(k.over90.toString(), '1000'); assert.equal(k.d31_60.toString(), '200');
  const full = await debtAging(db, { asOf: '2026-05-15' });
  assert.equal(full.overdue.toString(), '1200'); assert.equal(full.outstanding.toString(), '1200');
  assert.equal((await db.get("SELECT COUNT(*) n FROM invoices")).n, 2);
});
test('credit notes reduce outstanding; cannot exceed it; cancellation rules', async () => {
  const { db, cust } = await world();
  const i = await issueInvoice(db, mgr, { customerId: cust, lines: [simple('1000')] });
  await assert.rejects(issueCreditNote(db, mgr, { invoiceId: i.id, amount: '1000.01', reason: 'x' }), /exceeds/);
  await assert.rejects(issueCreditNote(db, mgr, { invoiceId: i.id, amount: '10', reason: ' ' }), /reason/);
  const cn = await issueCreditNote(db, mgr, { invoiceId: i.id, amount: '300', reason: 'Retour' });
  assert.match(cn.number, /^AV-/);
  assert.equal((await invoiceOutstanding(db, i.id)).toString(), '700');
  assert.equal((await customerBalance(db, cust)).balance.toString(), '700');
  await assert.rejects(cancelInvoice(db, mgr, i.id, 'oops'), /credit note/);
  const j = await issueInvoice(db, mgr, { customerId: cust, lines: [simple('50')] });
  await assert.rejects(cancelInvoice(db, mgr, j.id, ''), /reason/);
  await cancelInvoice(db, mgr, j.id, 'Erreur de saisie');
  assert.equal((await customerBalance(db, cust)).balance.toString(), '700');   // cancelled invoice excluded
  assert.equal((await db.get('SELECT COUNT(*) n FROM invoices WHERE id=?', [j.id])).n, 1); // still on file
  await assert.rejects(cancelInvoice(db, mgr, j.id, 'again'), /already/);
});
test('cancelling a payment restores the debt and keeps the record', async () => {
  const { db, cust } = await world();
  const i = await issueInvoice(db, mgr, { customerId: cust, lines: [simple('1000')] });
  const p = await recordPayment(db, mgr, { customerId: cust, amount: '400', method: 'cash', eventKey: 'c1', allocations: [{ invoiceId: i.id, amount: '400' }] });
  assert.equal((await invoiceOutstanding(db, i.id)).toString(), '600');
  await cancelPayment(db, mgr, p.id, 'Erreur');
  assert.equal((await invoiceOutstanding(db, i.id)).toString(), '1000');
  assert.equal((await customerBalance(db, cust)).balance.toString(), '1000');
  assert.equal((await db.get('SELECT COUNT(*) n FROM payment_allocations')).n, 1);
  await assert.rejects(db.run('DELETE FROM payment_allocations'), /immutable/);
  await assert.rejects(cancelPayment(db, mgr, p.id, 'twice'), /already cancelled/);
});
test('credit limit produces a warning (not a silent block) when exceeded', async () => {
  const { db } = await world();
  const c = await createCustomer(db, mgr, { ref: 'C9', name: 'Limité', credit_limit: '1000' });
  const ok = await issueInvoice(db, mgr, { customerId: c, lines: [simple('900')] });
  assert.equal(ok.warnings.length, 0);
  const over = await issueInvoice(db, mgr, { customerId: c, lines: [simple('200')] });
  assert.equal(over.warnings[0].code, 'credit_limit_exceeded');
  assert.equal(over.warnings[0].balance.toString(), '1100');
});
test('permissions: operator cannot invoice, sales cannot record payments, accountant can', async () => {
  const { db, cust } = await world();
  await assert.rejects(issueInvoice(db, { id: 'o', role: 'prod_operator' }, { customerId: cust, lines: [simple('1')] }), PermissionError);
  await assert.rejects(recordPayment(db, { id: 's', role: 'sales' }, { customerId: cust, amount: '1', method: 'cash', eventKey: 'p' }), PermissionError);
  await assert.rejects(createSalesOrder(db, { id: 'x', role: 'auditor' }, { customerId: cust, lines: [] }), PermissionError);
  const r = await recordPayment(db, { id: 'ac', role: 'accountant' }, { customerId: cust, amount: '1', method: 'cash', eventKey: 'p2' });
  assert.equal(r.duplicate, false);
});
