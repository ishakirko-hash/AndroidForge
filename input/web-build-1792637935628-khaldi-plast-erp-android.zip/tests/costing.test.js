import test from 'node:test';
import assert from 'node:assert/strict';
import { createNodeDriver } from '../src/core/db/node-driver.js';
import { initDatabase } from '../src/core/database.js';
import { seedStarterChart, setAccountRole, generalLedger, trialBalance, verifyLedgerIntegrity } from '../src/core/ledger.js';
import { createProduct, createMaterial, createRecipe } from '../src/core/catalog.js';
import { postMovement, getBalance, stockValuation } from '../src/core/inventory.js';
import { createOrder, planOrder, startOrder, completeOrder } from '../src/core/production.js';
import { createCustomer } from '../src/core/parties.js';
import { createSalesOrder, confirmSalesOrder, dispatchDelivery } from '../src/core/sales.js';
import { issueInvoice } from '../src/core/invoicing.js';
import { productMargin, inventoryLedgerCheck } from '../src/core/costing.js';
import { postPending } from '../src/core/postings.js';

const admin = { id: 'a', role: 'admin' }, mgr = { id: 'm', role: 'manager' };
const ROLES = { receivable: '3000', payable: '4000', sales_revenue: '7000', tax_collected: '4100', tax_deductible: '3100',
  inventory_materials: '2100', inventory_finished: '2200', cogs: '6500', production_waste: '6600' };
const bal = async (db, c) => { const g = await generalLedger(db, c); return g.length ? g.at(-1).runningBalance.toString() : '0'; };

async function world({ accounting = true } = {}) {
  const { db } = await initDatabase(createNodeDriver());
  if (accounting) { await seedStarterChart(db, admin); for (const [r, c] of Object.entries(ROLES)) await setAccountRole(db, admin, r, c); }
  const product = await createProduct(db, mgr, { ref: 'PL001', name_fr: 'Caisse' });
  const resin = await createMaterial(db, mgr, { ref: 'RM1', name: 'Granulé', unit: 'kg' });
  const rc = await createRecipe(db, mgr, { productId: product, lines: [{ materialId: resin, qtyPerUnit: '1' }] });
  return { db, product, resin, rc };
}
const mv = (db, type, itemId, qty, key, extra = {}) => postMovement(db, mgr, { type, itemType: 'material', itemId, qty, eventKey: key, ...extra });

test('weighted average cost (hand-computed): 100@100 + 100@120 → avg 110; issue 50 → 5500; +50@130 → avg 115; last unit clears exactly', async () => {
  const { db, resin } = await world({ accounting: false });
  await mv(db, 'receipt', resin, '100', 'r1', { unitCost: '100' });
  await mv(db, 'receipt', resin, '100', 'r2', { unitCost: '120' });
  let v = (await stockValuation(db)).items[0];
  assert.deepEqual([v.qty, v.value, v.avgCost].map(String), ['200', '22000', '110']);
  const out = await mv(db, 'waste', resin, '50', 'w1');
  assert.equal(out.value.toString(), '5500');
  v = (await stockValuation(db)).items[0]; assert.deepEqual([v.qty, v.value].map(String), ['150', '16500']);
  await mv(db, 'receipt', resin, '50', 'r3', { unitCost: '130' });
  v = (await stockValuation(db)).items[0]; assert.deepEqual([v.qty, v.value, v.avgCost].map(String), ['200', '23000', '115']);
  await mv(db, 'waste', resin, '200', 'w2');
  v = (await stockValuation(db)).items[0]; assert.deepEqual([v.qty, v.value].map(String), ['0', '0']);
});
test('awkward quantities never leave rounding residue: 3 units @ 100.01 issued one by one clear to exactly 0', async () => {
  const { db, resin } = await world({ accounting: false });
  await mv(db, 'receipt', resin, '3', 'r', { unitCost: '100.01' });
  for (const k of ['a', 'b', 'c']) await mv(db, 'waste', resin, '1', k);
  const v = (await stockValuation(db)).items[0]; assert.deepEqual([v.qty, v.value].map(String), ['0', '0']);
});
test('unpriced stock is flagged, never guessed: valuation incomplete, production cost incomplete', async () => {
  const { db, product, resin, rc } = await world({ accounting: false });
  await mv(db, 'opening', resin, '100', 'o'); // no cost known
  assert.equal((await stockValuation(db)).complete, false);
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '10' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  const s = await completeOrder(db, mgr, o.id, { totalQty: '10', acceptedQty: '10', rejectedQty: '0', consumption: [{ materialId: resin, qty: '10' }] });
  assert.equal(s.costComplete, false); assert.equal(s.unitMaterialCost, null);
});
test('production cost: 90 kg @ avg 110 = 9900 over 80 accepted → 123.75/unit; product stock valued; materials reduced', async () => {
  const { db, product, resin, rc } = await world({ accounting: false });
  await mv(db, 'receipt', resin, '100', 'r1', { unitCost: '100' }); await mv(db, 'receipt', resin, '100', 'r2', { unitCost: '120' });
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '100' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  const s = await completeOrder(db, mgr, o.id, { totalQty: '90', acceptedQty: '80', rejectedQty: '10', consumption: [{ materialId: resin, qty: '90' }] });
  assert.deepEqual([s.materialCost, s.unitMaterialCost].map(String), ['9900', '123.75']); assert.equal(s.costComplete, true);
  const v = await stockValuation(db);
  assert.deepEqual([v.materialsValue, v.productsValue].map(String), ['12100', '9900']);
  assert.equal(v.items.find((i) => i.type === 'product').avgCost.toString(), '123.75');
});
test('end-to-end with accounting: production, COGS journal, margin; ledger equals subledger for finished goods', async () => {
  const { db, product, resin, rc } = await world();
  await mv(db, 'receipt', resin, '100', 'r1', { unitCost: '100' }); await mv(db, 'receipt', resin, '100', 'r2', { unitCost: '120' });
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '100' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  const s = await completeOrder(db, mgr, o.id, { totalQty: '90', acceptedQty: '80', rejectedQty: '10', consumption: [{ materialId: resin, qty: '90' }] });
  assert.equal(s.posting.skipped, false);
  assert.deepEqual([await bal(db, '2200'), await bal(db, '2100')], ['9900', '-9900']);
  const cust = await createCustomer(db, mgr, { ref: 'C1', name: 'Client' });
  const so = await createSalesOrder(db, mgr, { customerId: cust, lines: [{ productId: product, qty: '30', unitPrice: '300' }] });
  await confirmSalesOrder(db, mgr, so.id);
  const d = await dispatchDelivery(db, mgr, so.id, { lines: [{ lineNo: 1, qty: '30' }] });
  assert.equal(d.posting.skipped, false);
  assert.deepEqual([await bal(db, '6500'), await bal(db, '2200')], ['3712.5', '6187.5']); // 30 x 123.75
  assert.equal((await stockValuation(db)).productsValue.toString(), '6187.5');
  assert.equal((await getBalance(db, 'product', product)).toString(), '50');
  await issueInvoice(db, mgr, { customerId: cust, lines: [{ productId: product, description: 'Caisse', qty: '30', unitPrice: '300' }] });
  const m = (await productMargin(db, { from: '2000-01-01', to: '2100-01-01' })).rows[0];
  assert.deepEqual([m.revenue, m.cogs, m.margin, m.marginPct].map(String), ['9000', '3712.5', '5287.5', '58.75']);
  assert.equal(m.costComplete, true);
  const chk = await inventoryLedgerCheck(db);
  assert.equal(chk.find((c) => c.kind === 'products').difference.toString(), '0');
  assert.equal((await trialBalance(db)).balanced, true); assert.deepEqual(await verifyLedgerIntegrity(db), []);
});
test('all-rejected production books the consumed cost as production loss, not finished goods', async () => {
  const { db, product, resin, rc } = await world();
  await mv(db, 'receipt', resin, '100', 'r', { unitCost: '100' });
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '10' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  await completeOrder(db, mgr, o.id, { totalQty: '10', acceptedQty: '0', rejectedQty: '10', consumption: [{ materialId: resin, qty: '10' }] });
  assert.deepEqual([await bal(db, '6600'), await bal(db, '2100'), await bal(db, '2200')], ['1000', '-1000', '0']);
  assert.equal((await stockValuation(db)).materialsValue.toString(), '9000');
});
test('accounting configured after the fact: production and delivery postings catch up exactly once', async () => {
  const { db, product, resin, rc } = await world({ accounting: false });
  await mv(db, 'receipt', resin, '10', 'r', { unitCost: '50' });
  const o = await createOrder(db, mgr, { productId: product, recipeId: rc.id, plannedQty: '10' });
  await planOrder(db, mgr, o.id); await startOrder(db, mgr, o.id);
  const s = await completeOrder(db, mgr, o.id, { totalQty: '10', acceptedQty: '10', rejectedQty: '0', consumption: [{ materialId: resin, qty: '10' }] });
  assert.equal(s.posting.skipped, true);
  await seedStarterChart(db, admin); for (const [r, c] of Object.entries(ROLES)) await setAccountRole(db, admin, r, c);
  assert.deepEqual((await postPending(db, admin)).posted.map((p) => p.kind), ['production_order']);
  assert.equal((await postPending(db, admin)).posted.length, 0);
  assert.equal(await bal(db, '2200'), '500');
});
