/* KHALDI PLAST ERP 4.0 — original visual language.
   Bespoke duotone utility glyphs, dimensional category marks and isometric crate art.
   No remote fonts, icon kits, or network dependencies. */
(function () {
  'use strict';
  var V = window.KPV;
  if (!V) return;
  var serial = 0;
  var C = {
    home: '<path d="M6 22V13.5L24 5l18 8.5V22H6Z" fill="url(#g)"/><path d="M6 13.5 24 5l18 8.5" fill="none" stroke="#D7F5FF" stroke-width="2.4" stroke-linecap="round"/><path d="M18 22v-8h12v8" fill="#173C70"/><path d="M22 22v-5h4v5" fill="#74D8F3"/>',
    box: '<path d="M6 16 24 6l18 10v20L24 46 6 36V16Z" fill="url(#g)"/><path d="M6 16 24 26l18-10M24 26v20" fill="none" stroke="#E4F9FF" stroke-width="2.2" stroke-linejoin="round"/><path d="M14 11.5 32 21.8 38 18.5 20 8.2Z" fill="#BCEEFF" opacity=".65"/><path d="M11 20v12l5 2.8V22.8L11 20Zm10 5.8v12l5 2.8v-12l-5-2.8Z" fill="#113C70" opacity=".78"/>',
    stock: '<path d="M6 16 24 6l18 10v20L24 46 6 36V16Z" fill="url(#g)"/><path d="M6 16 24 26l18-10M24 26v20" fill="none" stroke="#E4F9FF" stroke-width="2.2"/><path d="M14 12 24 6l10 5.5-10 5.7L14 12Z" fill="#D9F7FF" opacity=".9"/><path d="M17 28v7M24 32v8M31 28v7" stroke="#0F4A74" stroke-width="3" stroke-linecap="round"/>',
    machine: '<path d="M6 19 27 8l15 8-21 12L6 19Z" fill="#BDEFFF"/><path d="M6 19 21 31v14L6 36V19Z" fill="url(#g)"/><path d="M21 31 42 19v17L21 45V31Z" fill="#174B78"/><path d="m11 18 16-9 9 5-16 9-9-5Z" fill="#E6FAFF" opacity=".72"/><path d="M13 14V5h12v8l-6 4-6-3Z" fill="#F2B64D"/><path d="m13 5 6-3 6 3-6 4-6-4Z" fill="#FFD47C"/><path d="M19 17 25 13l5 3-6 4-5-3Z" fill="#B5EFFB"/><path d="M24 25 37 18v9l-13 8v-10Z" fill="#0F3D69"/><path d="m27 25 7-4v4l-7 4v-4Z" fill="#76DDF5"/><path d="m27 31 7-4v2l-7 4v-2Z" fill="#E8FAFF"/><path d="M9 24v9l8 5V29l-8-5Z" fill="#164D7B"/><path d="M12 27v4l3 2v-4l-3-2Z" fill="#79D9F2"/><path d="m21 36 21-12v5L21 42v-6Z" fill="#0D345B" opacity=".6"/><path d="M10 37v5m8-1v5m17-5v4m5-7v4" stroke="#153E67" stroke-width="2.6" stroke-linecap="round"/><path d="m6 19 15 12 21-12M21 31v14" fill="none" stroke="#E2F9FF" stroke-width="1.2" opacity=".72"/>' ,
    factory: '<path d="M5 43V21l11 6V19l11 7V13h6v30H5Z" fill="url(#g)"/><path d="M33 21h10v22H33z" fill="#174D76"/><path d="M35 9h6v12h-6z" fill="#55C5E8"/><path d="M10 33h4v5h-4zM20 33h4v5h-4zM30 33h4v5h-4z" fill="#DDF8FF"/><path d="M36 26h4v4h-4z" fill="#A5E8F5"/>',
    cart: '<path d="M8 10h5l5 22h20l5-16H17" fill="none" stroke="#17446C" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M19 19h20l-3 10H21z" fill="url(#g)"/><circle cx="22" cy="39" r="4.3" fill="#173C70"/><circle cx="36" cy="39" r="4.3" fill="#173C70"/><circle cx="22" cy="39" r="1.5" fill="#B5F0FF"/><circle cx="36" cy="39" r="1.5" fill="#B5F0FF"/>',
    truck: '<path d="M5 13h24v22H5z" fill="url(#g)"/><path d="M29 20h8l7 8v7H29z" fill="#174A7B"/><path d="M32 23h4l4 5h-8z" fill="#BAF1FF"/><path d="M8 17h17v3H8zM8 23h12v3H8z" fill="#D8F8FF"/><circle cx="14" cy="37" r="4.4" fill="#123459"/><circle cx="36" cy="37" r="4.4" fill="#123459"/><circle cx="14" cy="37" r="1.7" fill="#BCEFFF"/><circle cx="36" cy="37" r="1.7" fill="#BCEFFF"/>',
    wallet: '<path d="M7 13a4 4 0 0 1 4-4h27a4 4 0 0 1 4 4v23a4 4 0 0 1-4 4H11a4 4 0 0 1-4-4V13Z" fill="url(#g)"/><path d="M7 17h32" stroke="#C8F4FF" stroke-width="2.3"/><path d="M31 23h13v11H31a5.5 5.5 0 0 1 0-11Z" fill="#173F70"/><circle cx="34.5" cy="28.5" r="1.7" fill="#A6EEFF"/><path d="M12 9V6h22" fill="none" stroke="#174B77" stroke-width="3" stroke-linecap="round"/>',
    note: '<path d="M11 5h20l8 8v28H11a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4Z" fill="url(#g)"/><path d="M31 5v9h8" fill="#B9EEFA"/><path d="M14 22h19M14 28h19M14 34h13" stroke="#E8FAFF" stroke-width="2.8" stroke-linecap="round"/>',
    reports: '<path d="M7 39V25h8v14H7Zm13 0V15h8v24h-8Zm13 0V7h8v32h-8Z" fill="url(#g)"/><path d="m8 20 10-7 8 3 12-10" fill="none" stroke="#174B77" stroke-width="2.8" stroke-linecap="round"/><path d="m33 6 5-1v5" fill="none" stroke="#174B77" stroke-width="2.8" stroke-linecap="round"/>',
    user: '<circle cx="24" cy="15" r="9" fill="url(#g)"/><path d="M7 42c1-10 7-15 17-15s16 5 17 15" fill="url(#g)"/><path d="M16 15a8 8 0 0 0 16 0" fill="none" stroke="#DDF8FF" stroke-width="2"/>',
    users: '<circle cx="18" cy="16" r="7" fill="url(#g)"/><circle cx="34" cy="18" r="6" fill="#2D8FC4"/><path d="M4 40c.8-8 5.5-13 14-13s13 5 14 13H4Z" fill="url(#g)"/><path d="M29 29c7-2 13 2 15 10H32" fill="#225D92"/>',
    materials: '<circle cx="14" cy="31" r="8" fill="url(#g)"/><circle cx="32" cy="31" r="8" fill="#159DC4"/><circle cx="23" cy="14" r="8" fill="#73DDF4"/><circle cx="14" cy="31" r="2" fill="#E8FAFF"/><circle cx="32" cy="31" r="2" fill="#D8F8FF"/><circle cx="23" cy="14" r="2" fill="#fff"/>',
    maintenance: '<path d="M29 7a12 12 0 0 0-14 15L5 32l11 11 10-10a12 12 0 0 0 15-14l-8 8-7-2-2-7 8-8Z" fill="url(#g)"/><path d="m9 36 5-5" stroke="#E4F9FF" stroke-width="2.2" stroke-linecap="round"/>',
    payroll: '<ellipse cx="24" cy="12" rx="15" ry="6" fill="#91E7F5"/><path d="M9 12v20c0 3.4 6.7 6 15 6s15-2.6 15-6V12c0 3.4-6.7 6-15 6S9 15.4 9 12Z" fill="url(#g)"/><path d="M9 22c0 3.3 6.7 6 15 6s15-2.7 15-6M9 31c0 3.3 6.7 6 15 6s15-2.7 15-6" fill="none" stroke="#D9F8FF" stroke-width="2"/>',
    quotes: '<path d="M11 5h20l8 8v28H11a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4Z" fill="url(#g)"/><path d="M31 5v9h8" fill="#B9EEFA"/><path d="M16 23h5v7h-5zM27 23h5v7h-5z" fill="#E8FAFF"/><path d="M16 34h16" stroke="#D8F8FF" stroke-width="2.3" stroke-linecap="round"/>',
    insights: '<path d="M24 5a14 14 0 0 0-8 25c2 1.4 2.8 3.5 2.8 5.8h10.4c0-2.3.8-4.4 2.8-5.8A14 14 0 0 0 24 5Z" fill="url(#g)"/><path d="M18 41h12M19 36h10" stroke="#164A75" stroke-width="3" stroke-linecap="round"/><path d="M24 11v9m-4.5-4.5h9" stroke="#E9FBFF" stroke-width="2.5" stroke-linecap="round"/>',
    settings: '<path d="m20 4 8 0 1.5 5 4 2.3 4.7-1.6 4 7-3.5 3.4v4.6l3.5 3.4-4 7-4.7-1.6-4 2.3L28 42h-8l-1.5-5-4-2.3-4.7 1.6-4-7 3.5-3.4v-4.6L5.8 18l4-7 4.7 1.6 4-2.3L20 4Z" fill="url(#g)"/><circle cx="24" cy="23" r="7" fill="#EAFBFF"/><circle cx="24" cy="23" r="3.5" fill="#1D6195"/>',
    customize: '<path d="M8 13h32M8 35h32" stroke="#174A75" stroke-width="4" stroke-linecap="round"/><circle cx="18" cy="13" r="7" fill="url(#g)" stroke="#E8FAFF" stroke-width="2"/><circle cx="31" cy="35" r="7" fill="url(#g)" stroke="#E8FAFF" stroke-width="2"/>',
    assistant: '<path d="M7 9a5 5 0 0 1 5-5h24a5 5 0 0 1 5 5v19a5 5 0 0 1-5 5H23L12 43v-10a5 5 0 0 1-5-5V9Z" fill="url(#g)"/><path d="M15 15h18M15 22h13" stroke="#E8FAFF" stroke-width="3" stroke-linecap="round"/><path d="m31 4 2-3m5 9 3-1" stroke="#47C5EA" stroke-width="2" stroke-linecap="round"/>',
    crm: '<circle cx="18" cy="16" r="8" fill="url(#g)"/><path d="M4 41c1-9 5-14 14-14s13 5 14 14H4Z" fill="url(#g)"/><circle cx="36" cy="30" r="9" fill="#164B78"/><path d="M36 25v10m-5-5h10" stroke="#DFF9FF" stroke-width="2.6" stroke-linecap="round"/>',
    scan: '<path d="M7 17V9a3 3 0 0 1 3-3h8M30 6h8a3 3 0 0 1 3 3v8M41 30v8a3 3 0 0 1-3 3h-8M18 41h-8a3 3 0 0 1-3-3v-8" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round"/><path d="M9 24h30" stroke="#174A75" stroke-width="3" stroke-linecap="round"/><path d="M14 15h6v6h-6zM28 15h6v6h-6zM14 29h6v6h-6zM28 29h6v6h-6z" fill="url(#g)"/>',
    clock: '<circle cx="24" cy="24" r="18" fill="url(#g)"/><circle cx="24" cy="24" r="13" fill="#E8FAFF"/><path d="M24 14v11l8 5" fill="none" stroke="#174B75" stroke-width="3" stroke-linecap="round"/>',
    calendar: '<rect x="7" y="9" width="34" height="31" rx="6" fill="url(#g)"/><path d="M7 17h34" stroke="#E6F9FF" stroke-width="3"/><path d="M16 5v8M32 5v8" stroke="#174B75" stroke-width="3.5" stroke-linecap="round"/><path d="M15 24h5v5h-5zM25 24h5v5h-5zM15 33h5v4h-5z" fill="#E9FBFF"/>',
    alert: '<path d="M24 5 45 41H3L24 5Z" fill="url(#g)"/><path d="M24 17v12" stroke="#fff" stroke-width="4" stroke-linecap="round"/><circle cx="24" cy="35" r="2.2" fill="#fff"/>',
    check: '<circle cx="24" cy="24" r="19" fill="url(#g)"/><path d="m13 24 7 7 15-16" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>',
    bell: '<path d="M10 33V20a14 14 0 0 1 28 0v13l4 5H6l4-5Z" fill="url(#g)"/><path d="M20 41a5 5 0 0 0 8 0" fill="none" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    search: '<circle cx="21" cy="21" r="13" fill="none" stroke="url(#g)" stroke-width="5"/><path d="m31 31 11 11" stroke="#174A75" stroke-width="5" stroke-linecap="round"/>',
    edit: '<path d="m9 31 20-20a6 6 0 0 1 8 8L17 39 7 41l2-10Z" fill="url(#g)"/><path d="m27 13 8 8" stroke="#EAFBFF" stroke-width="2.6"/><path d="M7 41h16" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    trash: '<path d="M11 13h26l-2 28H13l-2-28Z" fill="url(#g)"/><path d="M7 10h34M18 10V6h12v4M19 19v15M29 19v15" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    print: '<path d="M12 6h24v10H12z" fill="url(#g)"/><rect x="6" y="16" width="36" height="17" rx="4" fill="#174A75"/><path d="M12 28h24v14H12z" fill="url(#g)"/><path d="M17 33h14M17 37h10" stroke="#E8FAFF" stroke-width="2" stroke-linecap="round"/>',
    share: '<circle cx="12" cy="24" r="6" fill="url(#g)"/><circle cx="36" cy="10" r="6" fill="url(#g)"/><circle cx="36" cy="38" r="6" fill="url(#g)"/><path d="m17 21 13-8M17 27l13 8" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    plus: '<circle cx="24" cy="24" r="19" fill="url(#g)"/><path d="M24 14v20M14 24h20" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/>',
    download: '<path d="M24 5v25m-10-10 10 10 10-10" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 34v7h32v-7" fill="none" stroke="#174A75" stroke-width="3.5" stroke-linecap="round"/>',
    upload: '<path d="M24 31V6m-10 10L24 6l10 10" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 34v7h32v-7" fill="none" stroke="#174A75" stroke-width="3.5" stroke-linecap="round"/>',
    save: '<path d="M9 5h25l7 7v29H7V7a2 2 0 0 1 2-2Z" fill="url(#g)"/><path d="M15 5v12h18V5M14 41V25h20v16" fill="none" stroke="#E8FAFF" stroke-width="2.6"/><path d="M19 30h10" stroke="#174A75" stroke-width="2.2"/>',
    lock: '<rect x="8" y="19" width="32" height="24" rx="5" fill="url(#g)"/><path d="M15 19v-6a9 9 0 0 1 18 0v6" fill="none" stroke="#174A75" stroke-width="4"/><circle cx="24" cy="30" r="3" fill="#E8FAFF"/><path d="M24 33v4" stroke="#E8FAFF" stroke-width="2.5"/>',
    globe: '<circle cx="24" cy="24" r="19" fill="url(#g)"/><path d="M5 24h38M24 5c6 6 8 12 8 19s-2 13-8 19M24 5c-6 6-8 12-8 19s2 13 8 19" fill="none" stroke="#E8FAFF" stroke-width="2.2"/>',
    pin: '<path d="M24 44S9 30 9 19a15 15 0 1 1 30 0c0 11-15 25-15 25Z" fill="url(#g)"/><circle cx="24" cy="19" r="5" fill="#E8FAFF"/>',
    phone: '<path d="M12 5h8l4 10-5 4a25 25 0 0 0 10 10l4-5 10 4v8a4 4 0 0 1-4 4A34 34 0 0 1 6 9a4 4 0 0 1 4-4Z" fill="url(#g)"/>',
    mail: '<rect x="5" y="10" width="38" height="28" rx="5" fill="url(#g)"/><path d="m7 14 17 13 17-13" fill="none" stroke="#E9FBFF" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    chat: '<path d="M7 7h34v25H24L11 42v-10H7V7Z" fill="url(#g)"/><path d="M15 16h18M15 23h12" stroke="#E8FAFF" stroke-width="3" stroke-linecap="round"/>',
    send: '<path d="m5 22 38-16-14 38-7-15-17-7Z" fill="url(#g)"/><path d="m22 29 21-23" stroke="#E8FAFF" stroke-width="2.4"/>',
    eye: '<path d="M3 24S11 10 24 10s21 14 21 14-8 14-21 14S3 24 3 24Z" fill="url(#g)"/><circle cx="24" cy="24" r="6" fill="#EAFBFF"/>',
    eyeoff: '<path d="m7 7 34 34M4 24s7-13 20-13c4 0 7 1 10 3M44 24s-7 13-20 13c-4 0-7-1-10-3" fill="none" stroke="url(#g)" stroke-width="3.2" stroke-linecap="round"/>',
    moon: '<path d="M39 29A18 18 0 0 1 19 7 19 19 0 1 0 39 29Z" fill="url(#g)"/>',
    sun: '<circle cx="24" cy="24" r="8" fill="url(#g)"/><path d="M24 4v7m0 26v7M4 24h7m26 0h7M10 10l5 5m18 18 5 5m0-28-5 5M15 33l-5 5" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    sliders: '<path d="M7 13h34M7 35h34" stroke="#174A75" stroke-width="3.3" stroke-linecap="round"/><circle cx="18" cy="13" r="7" fill="url(#g)"/><circle cx="32" cy="35" r="7" fill="url(#g)"/>',
    menu: '<path d="M7 12h34M7 24h34M7 36h34" stroke="url(#g)" stroke-width="4" stroke-linecap="round"/>',
    list: '<rect x="7" y="7" width="34" height="9" rx="3" fill="url(#g)"/><rect x="7" y="20" width="34" height="9" rx="3" fill="#226D9F"/><rect x="7" y="33" width="34" height="8" rx="3" fill="#54B9D8"/>',
    table: '<rect x="6" y="7" width="36" height="34" rx="4" fill="url(#g)"/><path d="M6 18h36M6 29h36M18 18v23M30 18v23" stroke="#E8FAFF" stroke-width="2.2"/>',
    scale: '<path d="M24 6v31M12 42h24M8 15h32" stroke="#174A75" stroke-width="3" stroke-linecap="round"/><path d="m8 15-6 14h12L8 15Zm32 0-6 14h12l-6-14Z" fill="url(#g)"/>',
    up: '<path d="m9 29 15-15 15 15" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>',
    down: '<path d="m9 19 15 15 15-15" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>',
    dots: '<circle cx="9" cy="24" r="4" fill="url(#g)"/><circle cx="24" cy="24" r="4" fill="url(#g)"/><circle cx="39" cy="24" r="4" fill="url(#g)"/>',
    back: '<path d="M30 9 15 24l15 15" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>',
    chevL: '<path d="m29 12-12 12 12 12" fill="none" stroke="url(#g)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>',
    chevR: '<path d="m19 12 12 12-12 12" fill="none" stroke="url(#g)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>',
    chevD: '<path d="m12 19 12 12 12-12" fill="none" stroke="url(#g)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>',
    x: '<path d="m12 12 24 24m0-24L12 36" stroke="url(#g)" stroke-width="4" stroke-linecap="round"/>',
    undo: '<path d="M19 13 9 23l10 10M10 23h17a10 10 0 0 1 0 20" fill="none" stroke="url(#g)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>',
    move: '<path d="M24 5v38M5 24h38m-19-19-6 6m6-6 6 6m-6 31-6-6m6 6 6-6M5 24l6-6m-6 6 6 6m31-6-6-6m6 6-6 6" fill="none" stroke="url(#g)" stroke-width="3" stroke-linecap="round"/>',
    resize: '<path d="M41 28v13H28M7 20V7h13M41 41 27 27M7 7l14 14" fill="none" stroke="url(#g)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>',
    card: '<rect x="5" y="9" width="38" height="30" rx="5" fill="url(#g)"/><path d="M5 18h38" stroke="#E7FAFF" stroke-width="3"/><rect x="11" y="25" width="10" height="6" rx="2" fill="#E7FAFF"/>',
    tag: '<path d="M7 25V9h17l17 17-16 16L7 25Z" fill="url(#g)"/><circle cx="17" cy="17" r="2.5" fill="#E8FAFF"/>',
    building: '<path d="M8 42V8l18-4v38H8Zm18-23h14v23H26Z" fill="url(#g)"/><path d="M13 14h5m-5 8h5m-5 8h5m17-7h3m-3 8h3" stroke="#E8FAFF" stroke-width="2.3" stroke-linecap="round"/>',
    coins: '<ellipse cx="24" cy="10" rx="15" ry="6" fill="#9CEBFA"/><path d="M9 10v9c0 3 6.7 5.5 15 5.5S39 22 39 19v-9c0 3-6.7 5.5-15 5.5S9 13 9 10Zm0 13v9c0 3 6.7 5.5 15 5.5S39 35 39 32v-9c0 3-6.7 5.5-15 5.5S9 26 9 23Z" fill="url(#g)"/><path d="M9 19c0 3 6.7 5.5 15 5.5S39 22 39 19" fill="none" stroke="#E8FAFF" stroke-width="2"/>',
    shifts: '<circle cx="24" cy="24" r="18" fill="url(#g)"/><circle cx="24" cy="24" r="13" fill="#E8FAFF"/><path d="M24 14v10l8 5" stroke="#174A75" stroke-width="3" fill="none" stroke-linecap="round"/>',
    profit: '<path d="m6 36 11-12 8 6 17-22" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M32 8h10v10" fill="none" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    forecast: '<path d="m6 37 10-12 8 6 9-17 9 7" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="42" cy="21" r="4" fill="#174A75"/>',
    dailyclose: '<rect x="7" y="7" width="34" height="34" rx="6" fill="url(#g)"/><path d="M7 17h34m-25 9 5 5 11-11" fill="none" stroke="#E8FAFF" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    stocktake: '<rect x="10" y="5" width="28" height="38" rx="5" fill="url(#g)"/><path d="m15 17 3 3 5-6m-8 15 3 3 5-6m4-9h5m-5 12h5" stroke="#E8FAFF" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
    purchases: '<path d="M8 7h6l5 24h19l5-17H16" fill="none" stroke="#174A75" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 19h20l-3 9H22z" fill="url(#g)"/><circle cx="23" cy="39" r="4" fill="#174A75"/><circle cx="36" cy="39" r="4" fill="#174A75"/>',
    sales: '<path d="M11 5h19l8 8v30H11a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4Z" fill="url(#g)"/><path d="M30 5v9h8" fill="#B9EEFA"/><path d="M15 22h17M15 29h17M15 36h11" stroke="#E9FBFF" stroke-width="2.6" stroke-linecap="round"/>',
    invoices: '<path d="M11 5h19l8 8v30H11a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4Z" fill="url(#g)"/><path d="M30 5v9h8" fill="#B9EEFA"/><path d="M15 22h17M15 29h17M15 36h11" stroke="#E9FBFF" stroke-width="2.6" stroke-linecap="round"/>',
    expenses: '<path d="M9 14h30l-2 27H11L9 14Z" fill="url(#g)"/><path d="M16 14V9a8 8 0 0 1 16 0v5" fill="none" stroke="#174A75" stroke-width="3.2"/><circle cx="24" cy="27" r="6" fill="#E8FAFF"/><path d="M24 23v8m-3-5h6" stroke="#1A5A88" stroke-width="2"/>',
    debts: '<circle cx="24" cy="24" r="18" fill="url(#g)"/><path d="M30 16c-2-3-11-3-12 2-1 7 13 4 12 11-1 6-11 7-15 2m9-20v26" fill="none" stroke="#E8FAFF" stroke-width="2.8" stroke-linecap="round"/>',
    transactions: '<path d="M8 10h32M8 21h32M8 32h32" stroke="#174A75" stroke-width="3.2" stroke-linecap="round"/><circle cx="10" cy="10" r="4" fill="url(#g)"/><circle cx="10" cy="21" r="4" fill="url(#g)"/><circle cx="10" cy="32" r="4" fill="url(#g)"/>',
    more: '<circle cx="9" cy="24" r="4.5" fill="url(#g)"/><circle cx="24" cy="24" r="4.5" fill="url(#g)"/><circle cx="39" cy="24" r="4.5" fill="url(#g)"/>',
    bars: '<path d="M7 40V25h8v15H7Zm13 0V14h8v26h-8Zm13 0V6h8v34h-8Z" fill="url(#g)"/><path d="M9 18 20 11l8 3 10-8" fill="none" stroke="#174B77" stroke-width="2.7" stroke-linecap="round"/>'
  };
  Object.assign(C, {
    production: '<path d="M5 42V23l11 6V19l10 7V12h6v30H5Z" fill="url(#g)"/><path d="M33 20h10v22H33z" fill="#174D76"/><path d="M35 8h6v12h-6z" fill="#55C5E8"/><path d="M10 33h4v5h-4zM20 33h4v5h-4zM36 27h4v4h-4z" fill="#E5FAFF"/>',
    table: '<rect x="6" y="8" width="36" height="32" rx="5" fill="url(#g)"/><path d="M6 18h36M18 18v22M30 18v22" stroke="#E5FAFF" stroke-width="2.2"/><path d="M11 13h5m7 0h5m7 0h5" stroke="#174A75" stroke-width="2.2" stroke-linecap="round"/>',
    shifts: '<circle cx="24" cy="24" r="18" fill="url(#g)"/><circle cx="24" cy="24" r="12.5" fill="#E8FAFF"/><path d="M24 15v9l7 4" fill="none" stroke="#174A75" stroke-width="3" stroke-linecap="round"/><path d="M13 5 9 10m26-5 4 5" stroke="#174A75" stroke-width="2.5" stroke-linecap="round"/>',
    save: '<path d="M8 5h27l6 6v30H7V6Z" fill="url(#g)"/><path d="M14 6h18v11H14z" fill="#E7FAFF"/><path d="M14 28h20v13H14z" fill="#174A75"/><path d="M18 31h12v7H18z" fill="#A9E9FA"/>',
    chevR: '<path d="m18 10 14 14-14 14" fill="none" stroke="url(#g)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>',
    down: '<path d="m10 18 14 14 14-14" fill="none" stroke="url(#g)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>',
    up: '<path d="m10 30 14-14 14 14" fill="none" stroke="url(#g)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>',
    back: '<path d="M38 24H10m0 0 12-12M10 24l12 12" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>',
    plus: '<circle cx="24" cy="24" r="19" fill="url(#g)"/><path d="M24 14v20M14 24h20" stroke="#F2FCFF" stroke-width="4" stroke-linecap="round"/>',
    x: '<circle cx="24" cy="24" r="19" fill="url(#g)"/><path d="m16 16 16 16m0-16L16 32" stroke="#F2FCFF" stroke-width="3.8" stroke-linecap="round"/>',
    search: '<circle cx="21" cy="21" r="13" fill="none" stroke="url(#g)" stroke-width="4.5"/><path d="m31 31 11 11" stroke="#174A75" stroke-width="4.5" stroke-linecap="round"/>',
    bell: '<path d="M10 33V20a14 14 0 0 1 28 0v13l4 5H6l4-5Z" fill="url(#g)"/><path d="M20 41a5 5 0 0 0 8 0" fill="none" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    lock: '<rect x="8" y="20" width="32" height="23" rx="5" fill="url(#g)"/><path d="M15 20v-6a9 9 0 0 1 18 0v6" fill="none" stroke="#174A75" stroke-width="4" stroke-linecap="round"/><circle cx="24" cy="31" r="3" fill="#E8FAFF"/>',
    edit: '<path d="m8 33-2 10 10-2L40 17l-8-8L8 33Z" fill="url(#g)"/><path d="m28 13 8 8M7 43h34" stroke="#174A75" stroke-width="2.8" stroke-linecap="round"/>',
    trash: '<path d="M10 14h28l-2 29H12l-2-29Z" fill="url(#g)"/><path d="M7 10h34M18 10V6h12v4M19 20v16m10-16v16" fill="none" stroke="#174A75" stroke-width="3" stroke-linecap="round"/>',
    print: '<path d="M13 6h22v12H13z" fill="url(#g)"/><path d="M10 18h28a5 5 0 0 1 5 5v10H35v9H13v-9H5V23a5 5 0 0 1 5-5Z" fill="#174A75"/><path d="M16 29h16v10H16z" fill="#BDEFFF"/><circle cx="36" cy="24" r="2" fill="#9DE9F6"/>',
    download: '<path d="M24 5v25m0 0 10-10m-10 10L14 20" fill="none" stroke="url(#g)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 32v9h32v-9" fill="none" stroke="#174A75" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    upload: '<path d="M24 34V9m0 0L14 19M24 9l10 10" fill="none" stroke="url(#g)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 32v9h32v-9" fill="none" stroke="#174A75" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    share: '<circle cx="12" cy="24" r="6" fill="url(#g)"/><circle cx="36" cy="11" r="6" fill="url(#g)"/><circle cx="36" cy="37" r="6" fill="url(#g)"/><path d="m17 21 13-7M17 27l13 7" stroke="#174A75" stroke-width="3.2" stroke-linecap="round"/>',
    mail: '<rect x="5" y="10" width="38" height="28" rx="5" fill="url(#g)"/><path d="m7 14 17 13 17-13" fill="none" stroke="#E8FAFF" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    phone: '<rect x="13" y="4" width="22" height="40" rx="5" fill="url(#g)"/><rect x="16" y="9" width="16" height="27" rx="2" fill="#DFF8FF"/><circle cx="24" cy="40" r="1.8" fill="#E8FAFF"/>',
    pin: '<path d="M24 44s15-16 15-26a15 15 0 0 0-30 0c0 10 15 26 15 26Z" fill="url(#g)"/><circle cx="24" cy="18" r="5" fill="#E8FAFF"/>',
    chat: '<path d="M7 9a5 5 0 0 1 5-5h24a5 5 0 0 1 5 5v20a5 5 0 0 1-5 5H22L10 44V34a5 5 0 0 1-3-5V9Z" fill="url(#g)"/><path d="M15 16h18M15 23h13" stroke="#E8FAFF" stroke-width="2.8" stroke-linecap="round"/>',
    send: '<path d="m5 7 39 17L5 41l7-15-7-19Z" fill="url(#g)"/><path d="M12 26h18" stroke="#E8FAFF" stroke-width="2.8" stroke-linecap="round"/>',
    undo: '<path d="M18 14H7v-9M7 14c5-6 11-8 18-6 10 2 16 11 15 21" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 14 18 5" stroke="#174A75" stroke-width="2.5"/>',
    resize: '<path d="M8 18V8h10M8 8l12 12m10 10 10 10m0 0V30m0 10H30" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>',
    move: '<path d="M24 5v38M5 24h38M24 5l-6 6m6-6 6 6M24 43l-6-6m6 6 6-6M5 24l6-6m-6 6 6 6m31-6-6-6m6 6-6 6" fill="none" stroke="url(#g)" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>',
    scale: '<path d="M10 36 36 10M10 10h10M10 10v10M38 38H28m10 0V28" fill="none" stroke="url(#g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="24" cy="24" r="4" fill="#174A75"/>',
    sliders: '<path d="M7 13h34M7 24h34M7 35h34" stroke="#174A75" stroke-width="3.2" stroke-linecap="round"/><circle cx="18" cy="13" r="5.5" fill="url(#g)"/><circle cx="31" cy="24" r="5.5" fill="url(#g)"/><circle cx="15" cy="35" r="5.5" fill="url(#g)"/>',
    dots: '<circle cx="10" cy="24" r="4.7" fill="url(#g)"/><circle cx="24" cy="24" r="4.7" fill="url(#g)"/><circle cx="38" cy="24" r="4.7" fill="url(#g)"/>'
  });
  var ALIAS = { customers:'users', suppliers:'truck', notes:'note', prodtable:'table', workers:'users', collect:'wallet', dailyclose:'calendar', cashbook:'wallet', forecast:'profit', purchtable:'table', analysis:'insights', orders:'calendar', backup:'save', transactions:'transactions', purchases:'purchases', more:'dots', invoice:'invoices' };
  var COLOR = {
    home:'#188BC6', box:'#0E9DD3', stock:'#14A7B1', machine:'#087FAE', factory:'#168CBA', cart:'#368DE5', truck:'#D48B2D',
    wallet:'#159A9A', note:'#3D85D7', reports:'#277AC9', user:'#318EBB', users:'#288BAE', materials:'#8B70CF', maintenance:'#647B98',
    payroll:'#D18C2E', quotes:'#7B69C7', insights:'#8066D2', settings:'#6A7C91', customize:'#2B9EBD', assistant:'#7A65C6', crm:'#199A91',
    scan:'#7E70C6', sales:'#2E89D5', invoices:'#7861C7', expenses:'#D46C4C', debts:'#3A7FC6', purchases:'#D28A33', transactions:'#318AB4', profit:'#229A74'
  };
  function svg(name, size, cls, body, view) {
    var n = ++serial, id = 'kpstudio' + n, px = Number(size) || 22;
    var painted = String(body).replace(/url\(#g\)/g, 'url(#' + id + ')').replace(/url\(#gb\)/g, 'url(#' + id + 'b)');
    return '<svg class="ic kp-icon kp-icon-' + name + ' ' + (cls || '') + '" width="' + px + '" height="' + px + '" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><defs><linearGradient id="' + id + '" x1="5" y1="4" x2="43" y2="44" gradientUnits="userSpaceOnUse"><stop stop-color="#65DDF5"/><stop offset=".48" stop-color="#168DC6"/><stop offset="1" stop-color="#174F8C"/></linearGradient><linearGradient id="' + id + 'b" x1="10" y1="8" x2="40" y2="42"><stop stop-color="#B7F1FF"/><stop offset="1" stop-color="#3AAAD6"/></linearGradient><filter id="' + id + 's" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="2" stdDeviation="1.5" flood-color="#16486B" flood-opacity=".18"/></filter></defs><g filter="url(#' + id + 's)">' + painted + '</g></svg>';
  }
  V.icon = function (name, size, cls) {
    var key = name || 'box', shape = C[ALIAS[key] || key] || C.note;
    return svg(key, size, cls, shape);
  };
  var TILE_NAMES = ['production','purchases','sales','expenses','debts','stock','invoices','reports','customers','suppliers','notes','prodtable','assistant','settings','customize','scan','quotes','collect','dailyclose','cashbook','forecast','stocktake','maintenance','insights','crm','purchtable','analysis','payroll','profit','shifts','workers','materials','backup','transactions','box','machine','factory','truck','wallet'];
  V.tile = function (name, size) { var key = name || 'box'; return svg(key, size || 40, 'tile-ic kp-tile-illustration', C[ALIAS[key] || key] || C.box); };
  V.qtile = function (name, size) { return V.tile(name, size); };
  V.qtileBg = function (name) { return (COLOR[name] || '#258CBD') + '1A'; };
  V.qtileColor = function (name) { return COLOR[name] || '#258CBD'; };
  V.tileColor = function (name) { return COLOR[name] || COLOR[ALIAS[name]] || '#258CBD'; };
  V.tileNames = function () { return TILE_NAMES.slice(); };
  V.machine3D = function (size, cls) { return V.icon('machine', size || 64, 'kp-machine-3d ' + (cls || '')); };
  var CRATES = {
    blue:['#2D8DE0','#14568F','#74CCF2'], green:['#34A96B','#176845','#85E0AE'], red:['#E45C53','#9D302F','#FF9B8E'],
    black:['#5A6574','#273342','#9BA7B7'], gray:['#9DAAB8','#5E6B7B','#D2DCE6'], orange:['#E58D31','#92501B','#FFC477']
  };
  V.crate = function (color, size) {
    var c = CRATES[color] || CRATES.gray, w = Number(size) || 56, h = Math.round(w * .78), n = ++serial, id = 'kpcrate' + n;
    var holes = '';
    for (var i=0;i<5;i++) holes += '<path d="M' + (12+i*8.1) + ' 25v8" stroke="' + c[1] + '" stroke-width="3.2" stroke-linecap="round" opacity=".82"/>';
    return '<svg class="crate kp-crate-3d" width="' + w + '" height="' + h + '" viewBox="0 0 58 46" aria-hidden="true" focusable="false"><defs><linearGradient id="' + id + 'l" x1="4" y1="17" x2="28" y2="43"><stop stop-color="' + c[2] + '"/><stop offset="1" stop-color="' + c[0] + '"/></linearGradient><linearGradient id="' + id + 'r" x1="28" y1="17" x2="55" y2="43"><stop stop-color="' + c[0] + '"/><stop offset="1" stop-color="' + c[1] + '"/></linearGradient><linearGradient id="' + id + 't" x1="5" y1="5" x2="53" y2="25"><stop stop-color="' + c[2] + '"/><stop offset="1" stop-color="' + c[0] + '"/></linearGradient><filter id="' + id + 's"><feDropShadow dx="0" dy="1.3" stdDeviation="1.2" flood-color="#163B58" flood-opacity=".24"/></filter></defs><g filter="url(#' + id + 's)"><path d="M5 15 29 3l24 12-24 13L5 15Z" fill="url(#' + id + 't)"/><path d="M5 15 29 28v17L5 32V15Z" fill="url(#' + id + 'l)"/><path d="M29 28 53 15v17L29 45V28Z" fill="url(#' + id + 'r)"/><path d="m12 13 17 9 17-9" fill="none" stroke="#E8FAFF" stroke-width="1.2" opacity=".7"/><path d="M8 19v11l17 9V28L8 19Z" fill="#0F416A" opacity=".2"/><path d="M34 29v11m7-15v12m7-16v12" stroke="#0F416A" stroke-width="2.7" stroke-linecap="round" opacity=".64"/><path d="M5 15 29 28l24-13" fill="none" stroke="#EAFBFF" stroke-width="1.4" opacity=".62"/></g></svg>';
  };
})();
