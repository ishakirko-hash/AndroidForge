/* KHALDI PLAST ERP 3.1 — interaction & personalization layer.
   Additive UI layer: preferences are stored inside settings.ui and do not alter business records. */
(function () {
  'use strict';
  var U = window.KPU;
  if (!U || !U.D) return;
  var V = U.V, esc = U.esc, X = U.extraActions = U.extraActions || {};
  var originalCustomize = U.views && U.views.customize;

  var ACCENTS = {
    blue:    { main: '#0878C9', dark: '#075B99', light: '#35A9E8', rgb: '8,120,201' },
    cyan:    { main: '#009CCB', dark: '#08789C', light: '#35C5ED', rgb: '0,156,203' },
    teal:    { main: '#078B80', dark: '#056B62', light: '#32B9A9', rgb: '7,139,128' },
    violet:  { main: '#7656D6', dark: '#563DB0', light: '#A18AF0', rgb: '118,86,214' },
    amber:   { main: '#C17A16', dark: '#945A0C', light: '#E7A43E', rgb: '193,122,22' },
    graphite:{ main: '#52657E', dark: '#39495F', light: '#8194AE', rgb: '82,101,126' }
  };
  var TXT = {
    ar: {
      title: 'مركز التخصيص الاحترافي', intro: 'تحكم في شكل التطبيق وطريقة تفاعله وسرعة الوصول إلى الوظائف. تحفظ التغييرات على هذا الجهاز ضمن بيانات التطبيق.',
      theme: 'المظهر', light: 'فاتح', dark: 'داكن', auto: 'حسب الجهاز', accent: 'اللون الرئيسي', density: 'كثافة الواجهة', compact: 'مضغوط', comfortable: 'متوازن', spacious: 'واسع',
      scale: 'حجم النص', corners: 'استدارة الزوايا', soft: 'ناعمة', medium: 'متوسطة', sharp: 'مربعة', motion: 'الحركات والانتقالات', shadows: 'الظلال والزجاج', haptics: 'اهتزاز خفيف عند اللمس',
      gestures: 'الإيماءات الذكية', allGestures: 'تفعيل الإيماءات', swipeTabs: 'السحب الأفقي للتنقل بين الأقسام', swipeBack: 'السحب للرجوع من الصفحات الداخلية', sheetClose: 'السحب للأسفل لإغلاق النوافذ', pullPalette: 'السحب للأسفل من أعلى الصفحة لفتح البحث السريع', holdBrand: 'الضغط المطوّل على الشعار لفتح الأوامر',
      shortcuts: 'اختصارات لوحة المفاتيح', command: 'لوحة الأوامر السريعة', openCmd: 'فتح لوحة الأوامر', shortcutsHint: 'Ctrl / ⌘ + K أو / للبحث عن أي قسم أو إجراء', keys: 'الاختصارات المتاحة',
      layout: 'تخصيص الصفحة الرئيسية', advanced: 'خيارات العرض', reset: 'إرجاع التخصيصات الافتراضية', saved: 'تم حفظ التخصيص', palette: 'الأوامر والبحث السريع', search: 'ابحث عن قسم أو إجراء...', nav: 'التنقل', quick: 'إجراءات سريعة', noResults: 'لا توجد نتائج مطابقة',
      home: 'الرئيسية', sales: 'المبيعات', production: 'الإنتاج', stock: 'المخزون', more: 'المزيد', invoices: 'الفواتير', purchases: 'المشتريات', expenses: 'المصاريف', debts: 'الديون', customers: 'العملاء', suppliers: 'الموردون', workers: 'العمال', notes: 'الطلبات والملاحظات', reports: 'التقارير', profit: 'الأرباح', crm: 'إدارة العملاء CRM', analysis: 'التحليل الذكي', maintenance: 'الصيانة', backup: 'النسخ الاحتياطي', settings: 'الإعدادات', customize: 'تخصيص التطبيق', assistant: 'المساعد الذكي', cashbook: 'دفتر الصندوق', dailyclose: 'إقفال اليوم', collect: 'تحصيل الديون', forecast: 'التوقعات', stocktake: 'الجرد', quotes: 'عروض الأسعار', purchtable: 'جدول المشتريات', prodtable: 'جدول الإنتاج', transactions: 'سجل العمليات',
      newSale: 'إنشاء فاتورة جديدة', newProduction: 'تسجيل إنتاج', newPurchase: 'تسجيل مشتريات', newExpense: 'تسجيل مصروف', quickAdd: 'إضافة سريعة', resetQuestion: 'إرجاع إعدادات الواجهة إلى الوضع الافتراضي؟', disabled: 'معطل', enabled: 'مفعل', shortcutOpen: 'فتح لوحة الأوامر', shortcutTabs: 'التنقل بين الأقسام الرئيسية', shortcutNew: 'الإضافة السريعة', shortcutSale: 'فاتورة جديدة', shortcutProd: 'تسجيل إنتاج'
    },
    fr: {
      title: 'Centre de personnalisation', intro: 'Personnalisez l’apparence, les interactions et les accès rapides. Vos préférences sont enregistrées sur cet appareil.',
      theme: 'Apparence', light: 'Clair', dark: 'Sombre', auto: 'Système', accent: 'Couleur principale', density: 'Densité', compact: 'Compacte', comfortable: 'Équilibrée', spacious: 'Aérée',
      scale: 'Taille du texte', corners: 'Coins', soft: 'Arrondis', medium: 'Moyens', sharp: 'Carrés', motion: 'Animations', shadows: 'Ombres et verre', haptics: 'Retour haptique',
      gestures: 'Gestes intelligents', allGestures: 'Activer les gestes', swipeTabs: 'Glisser horizontalement entre les sections', swipeBack: 'Glisser pour revenir en arrière', sheetClose: 'Glisser vers le bas pour fermer les fenêtres', pullPalette: 'Tirer depuis le haut pour ouvrir la recherche', holdBrand: 'Maintenir le logo pour ouvrir les commandes',
      shortcuts: 'Raccourcis clavier', command: 'Palette de commandes', openCmd: 'Ouvrir la palette', shortcutsHint: 'Ctrl / ⌘ + K ou / pour rechercher une section ou une action', keys: 'Raccourcis disponibles',
      layout: 'Personnaliser l’accueil', advanced: 'Options d’affichage', reset: 'Réinitialiser la personnalisation', saved: 'Préférences enregistrées', palette: 'Commandes et recherche rapide', search: 'Rechercher une section ou une action...', nav: 'Navigation', quick: 'Actions rapides', noResults: 'Aucun résultat',
      home: 'Accueil', sales: 'Ventes', production: 'Production', stock: 'Stock', more: 'Plus', invoices: 'Factures', purchases: 'Achats', expenses: 'Dépenses', debts: 'Dettes', customers: 'Clients', suppliers: 'Fournisseurs', workers: 'Employés', notes: 'Commandes et notes', reports: 'Rapports', profit: 'Bénéfices', crm: 'CRM clients', analysis: 'Analyse', maintenance: 'Maintenance', backup: 'Sauvegarde', settings: 'Paramètres', customize: 'Personnalisation', assistant: 'Assistant', cashbook: 'Caisse', dailyclose: 'Clôture journalière', collect: 'Encaissements', forecast: 'Prévisions', stocktake: 'Inventaire', quotes: 'Devis', purchtable: 'Tableau des achats', prodtable: 'Tableau de production', transactions: 'Transactions',
      newSale: 'Nouvelle facture', newProduction: 'Saisir une production', newPurchase: 'Nouvel achat', newExpense: 'Nouvelle dépense', quickAdd: 'Ajout rapide', resetQuestion: 'Réinitialiser les préférences de l’interface ?', disabled: 'Désactivé', enabled: 'Activé', shortcutOpen: 'Ouvrir la palette', shortcutTabs: 'Naviguer entre les sections', shortcutNew: 'Ajout rapide', shortcutSale: 'Nouvelle facture', shortcutProd: 'Saisir une production'
    },
    en: {
      title: 'Personalization Studio', intro: 'Control the app appearance, interactions and quick access. Preferences are stored locally on this device.',
      theme: 'Appearance', light: 'Light', dark: 'Dark', auto: 'System', accent: 'Accent color', density: 'Interface density', compact: 'Compact', comfortable: 'Comfortable', spacious: 'Spacious',
      scale: 'Text size', corners: 'Corner style', soft: 'Soft', medium: 'Medium', sharp: 'Sharp', motion: 'Motion and transitions', shadows: 'Shadows and glass', haptics: 'Haptic touch feedback',
      gestures: 'Smart gestures', allGestures: 'Enable gestures', swipeTabs: 'Swipe horizontally between sections', swipeBack: 'Swipe back from inner pages', sheetClose: 'Swipe down to close sheets', pullPalette: 'Pull down from the top to open search', holdBrand: 'Long-press the logo to open commands',
      shortcuts: 'Keyboard shortcuts', command: 'Command palette', openCmd: 'Open command palette', shortcutsHint: 'Ctrl / ⌘ + K or / to search sections and actions', keys: 'Available shortcuts',
      layout: 'Home screen layout', advanced: 'Display options', reset: 'Reset personalization', saved: 'Preferences saved', palette: 'Commands and quick search', search: 'Search for a section or action...', nav: 'Navigation', quick: 'Quick actions', noResults: 'No matching results',
      home: 'Home', sales: 'Sales', production: 'Production', stock: 'Inventory', more: 'More', invoices: 'Invoices', purchases: 'Purchases', expenses: 'Expenses', debts: 'Debts', customers: 'Customers', suppliers: 'Suppliers', workers: 'Workers', notes: 'Orders and notes', reports: 'Reports', profit: 'Profit', crm: 'Customer CRM', analysis: 'Analytics', maintenance: 'Maintenance', backup: 'Backup', settings: 'Settings', customize: 'Customize app', assistant: 'Assistant', cashbook: 'Cashbook', dailyclose: 'Daily close', collect: 'Collections', forecast: 'Forecast', stocktake: 'Stocktake', quotes: 'Quotations', purchtable: 'Purchases table', prodtable: 'Production table', transactions: 'Transactions',
      newSale: 'Create invoice', newProduction: 'Record production', newPurchase: 'Record purchase', newExpense: 'Record expense', quickAdd: 'Quick add', resetQuestion: 'Reset all interface preferences to defaults?', disabled: 'Off', enabled: 'On', shortcutOpen: 'Open command palette', shortcutTabs: 'Navigate main sections', shortcutNew: 'Quick add', shortcutSale: 'New invoice', shortcutProd: 'Record production'
    }
  };
  function T(k) { var l = (U.lang && U.lang()) || 'ar'; return (TXT[l] || TXT.ar)[k] || TXT.ar[k] || k; }
  function ui() {
    var s = (U.D.settings && U.D.settings.ui) || {};
    return Object.assign({ accent: 'blue', density: 'comfortable', scale: 100, corners: 'soft', motion: true, shadows: true, haptics: false, commandPalette: true }, s);
  }
  function gestures() {
    return Object.assign({ swipeTabs: true, swipeBack: true, sheetClose: true, pullPalette: true, holdBrand: true }, (U.D.settings && U.D.settings.gestureOptions) || {});
  }
  function pref(fn) {
    U.commit(function (d) { d.settings.ui = Object.assign({ accent: 'blue', density: 'comfortable', scale: 100, corners: 'soft', motion: true, shadows: true, haptics: false, commandPalette: true }, d.settings.ui || {}); fn(d.settings.ui, d.settings); });
    apply();
    U.render(true);
  }
  function gesturePref(fn) {
    U.commit(function (d) { d.settings.gestureOptions = Object.assign({ swipeTabs: true, swipeBack: true, sheetClose: true, pullPalette: true, holdBrand: true }, d.settings.gestureOptions || {}); fn(d.settings.gestureOptions, d.settings); });
    U.render(true);
  }
  function customAccent(hex) {
    if (!/^#[0-9a-fA-F]{6}$/.test(String(hex || ''))) return null;
    var n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    function shade(v, amount) { return Math.max(0, Math.min(255, Math.round(v + (amount > 0 ? (255 - v) * amount : v * amount)))); }
    function hx(v) { return ('0' + v.toString(16)).slice(-2); }
    return { main: hex, dark: '#' + hx(shade(r, -.24)) + hx(shade(g, -.24)) + hx(shade(b, -.24)), light: '#' + hx(shade(r, .24)) + hx(shade(g, .24)) + hx(shade(b, .24)), rgb: r + ',' + g + ',' + b };
  }
  function apply() {
    if (!U.D || !U.D.settings) return;
    var s = ui(), root = document.documentElement, a = (s.accent === 'custom' ? customAccent(s.customAccent) : null) || ACCENTS[s.accent] || ACCENTS.blue;
    root.setAttribute('data-density', ['compact', 'comfortable', 'spacious'].indexOf(s.density) >= 0 ? s.density : 'comfortable');
    root.setAttribute('data-scale', String([90, 95, 100, 105, 110, 115, 120].indexOf(Number(s.scale)) >= 0 ? Number(s.scale) : 100));
    root.setAttribute('data-corners', ['soft', 'medium', 'sharp'].indexOf(s.corners) >= 0 ? s.corners : 'soft');
    root.setAttribute('data-motion', s.motion === false ? 'off' : 'on');
    root.setAttribute('data-shadows', s.shadows === false ? 'off' : 'on');
    root.style.setProperty('--primary', a.main);
    root.style.setProperty('--primary-d', a.dark);
    root.style.setProperty('--blue', a.main);
    root.style.setProperty('--kp-blue', a.main);
    root.style.setProperty('--cyan', a.light);
    root.style.setProperty('--kp-cyan', a.light);
    root.style.setProperty('--grad', 'linear-gradient(135deg,' + a.light + ' 0%,' + a.main + ' 58%,' + a.dark + ' 100%)');
    root.style.setProperty('--sky', 'rgba(' + a.rgb + ',.13)');
    root.style.setProperty('--sky-2', 'rgba(' + a.rgb + ',.055)');
    var compact = s.density === 'compact', spacious = s.density === 'spacious';
    root.style.setProperty('--sp-1', compact ? '4px' : spacious ? '8px' : '6px');
    root.style.setProperty('--sp-2', compact ? '7px' : spacious ? '14px' : '10px');
    root.style.setProperty('--sp-3', compact ? '10px' : spacious ? '20px' : '14px');
    root.style.setProperty('--sp-4', compact ? '14px' : spacious ? '24px' : '18px');
    var rad = s.corners === 'sharp' ? [14, 16, 10, 7] : s.corners === 'medium' ? [20, 22, 14, 9] : [26, 22, 15, 11];
    root.style.setProperty('--r-lg', rad[0] + 'px'); root.style.setProperty('--r', rad[1] + 'px'); root.style.setProperty('--r-sm', rad[2] + 'px'); root.style.setProperty('--r-xs', rad[3] + 'px');
    root.style.setProperty('--kp-scale', Number(s.scale || 100) / 100);
    if (s.shadows === false) { root.style.setProperty('--shadow', 'none'); root.style.setProperty('--shadow-s', 'none'); root.style.setProperty('--kp-shadow', 'none'); }
    else { root.style.removeProperty('--shadow'); root.style.removeProperty('--shadow-s'); root.style.removeProperty('--kp-shadow'); }
  }

  /* Wrap the existing theme handler so it also applies the user's visual profile. */
  if (U.applyTheme && !U.applyTheme.__kpWrapped) {
    var baseApplyTheme = U.applyTheme;
    U.applyTheme = function () { baseApplyTheme(); apply(); };
    U.applyTheme.__kpWrapped = true;
  }

  function toggle(label, on, act, id) {
    return '<button type="button" class="kp-switch ' + (on ? 'on' : '') + '" data-act="' + act + '"' + (id ? ' data-id="' + esc(id) + '"' : '') + ' aria-pressed="' + (on ? 'true' : 'false') + '"><span>' + esc(label) + '</span><i></i></button>';
  }
  function choice(label, value, current, act) {
    return '<button type="button" class="kp-choice ' + (value === current ? 'on' : '') + '" data-act="' + act + '" data-id="' + esc(value) + '">' + esc(label) + '</button>';
  }
  function swatches(current) {
    return Object.keys(ACCENTS).map(function (key) {
      var a = ACCENTS[key];
      return '<button type="button" class="kp-swatch ' + (key === current ? 'on' : '') + '" data-act="kp_accent" data-id="' + key + '" title="' + key + '" aria-label="' + key + '"><i style="background:linear-gradient(135deg,' + a.light + ',' + a.main + ')"></i>' + (key === current ? '<b>✓</b>' : '') + '</button>';
    }).join('');
  }
  function keyboardHelp() {
    var rows = [
      ['Ctrl / ⌘ + K', T('shortcutOpen')], ['/ ', T('shortcutOpen')],
      ['Alt + 1 … 5', T('shortcutTabs')], ['Ctrl / ⌘ + Alt + N', T('shortcutNew')],
      ['Ctrl / ⌘ + Alt + I', T('shortcutSale')], ['Ctrl / ⌘ + Alt + P', T('shortcutProd')], ['Esc', (U.lang() === 'ar' ? 'إغلاق النافذة أو الرجوع' : 'Close or go back')]
    ];
    return '<div class="kp-keylist">' + rows.map(function (r) { return '<div><kbd>' + esc(r[0]) + '</kbd><span>' + esc(r[1]) + '</span></div>'; }).join('') + '</div>';
  }

  if (originalCustomize) {
    U.views.customize = function () {
      var s = ui(), g = gestures(), theme = U.D.settings.theme || 'light';
      var h = '<section class="kp-studio"><div class="kp-studio-hero"><div class="kp-studio-mark">KP</div><div><span class="kp-eyebrow">KHALDI PLAST ERP</span><h2>' + T('title') + '</h2><p>' + T('intro') + '</p></div></div>';
      h += '<div class="kp-pref-grid">';
      h += '<div class="kp-pref-card"><div class="kp-pref-head"><span class="kp-pref-icon">◐</span><div><b>' + T('theme') + '</b><small>' + (U.lang() === 'ar' ? 'اختيار نمط الإضاءة' : 'Choose your appearance') + '</small></div></div><div class="kp-choices">' + choice(T('light'), 'light', theme, 'kp_theme') + choice(T('dark'), 'dark', theme, 'kp_theme') + choice(T('auto'), 'auto', theme, 'kp_theme') + '</div></div>';
      h += '<div class="kp-pref-card"><div class="kp-pref-head"><span class="kp-pref-icon">◉</span><div><b>' + T('accent') + '</b><small>' + (U.lang() === 'ar' ? 'لون عناصر التحكم والتنقل' : 'Controls and navigation color') + '</small></div></div><div class="kp-swatches">' + swatches(s.accent) + '</div><label class="kp-custom-color"><span>' + (U.lang() === 'ar' ? 'اختر لوناً خاصاً' : U.lang() === 'fr' ? 'Choisir une couleur' : 'Choose a custom color') + '</span><input type="color" id="kpCustomAccent" value="' + esc(s.accent === 'custom' && /^#[0-9a-fA-F]{6}$/.test(s.customAccent || '') ? s.customAccent : (ACCENTS[s.accent] || ACCENTS.blue).main) + '"></label></div>';
      h += '<div class="kp-pref-card"><div class="kp-pref-head"><span class="kp-pref-icon">▤</span><div><b>' + T('density') + '</b><small>' + (U.lang() === 'ar' ? 'المسافات وحجم البطاقات' : 'Spacing and card sizing') + '</small></div></div><div class="kp-choices">' + choice(T('compact'), 'compact', s.density, 'kp_density') + choice(T('comfortable'), 'comfortable', s.density, 'kp_density') + choice(T('spacious'), 'spacious', s.density, 'kp_density') + '</div></div>';
      h += '<div class="kp-pref-card"><div class="kp-pref-head"><span class="kp-pref-icon">A</span><div><b>' + T('scale') + '</b><small>' + String(s.scale) + '%</small></div></div><div class="kp-choices kp-scale">' + [90, 95, 100, 105, 110, 115, 120].map(function (n) { return choice(n + '%', n, Number(s.scale), 'kp_scale'); }).join('') + '</div></div>';
      h += '<div class="kp-pref-card"><div class="kp-pref-head"><span class="kp-pref-icon">⌑</span><div><b>' + T('corners') + '</b><small>' + (U.lang() === 'ar' ? 'شكل البطاقات والأزرار' : 'Cards and buttons') + '</small></div></div><div class="kp-choices">' + choice(T('soft'), 'soft', s.corners, 'kp_corners') + choice(T('medium'), 'medium', s.corners, 'kp_corners') + choice(T('sharp'), 'sharp', s.corners, 'kp_corners') + '</div></div>';
      h += '<div class="kp-pref-card"><div class="kp-pref-head"><span class="kp-pref-icon">✧</span><div><b>' + T('advanced') + '</b><small>' + (U.lang() === 'ar' ? 'استجابة التطبيق ومؤثراته' : 'App feedback and effects') + '</small></div></div>' + toggle(T('motion'), s.motion !== false, 'kp_toggle_ui', 'motion') + toggle(T('shadows'), s.shadows !== false, 'kp_toggle_ui', 'shadows') + toggle(T('haptics'), s.haptics === true, 'kp_toggle_ui', 'haptics') + '</div>';
      h += '</div>';
      h += '<div class="kp-pref-card kp-wide"><div class="kp-section-title"><span>↔</span><div><b>' + T('gestures') + '</b><small>' + (U.lang() === 'ar' ? 'اختر الإيماءات التي تناسب طريقة عملك' : 'Choose the gestures that fit your workflow') + '</small></div></div>';
      h += toggle(T('allGestures'), U.D.settings.gestures !== false, 'kp_master_gestures');
      h += '<div class="kp-subtoggles' + (U.D.settings.gestures === false ? ' disabled' : '') + '">' + toggle(T('swipeTabs'), g.swipeTabs !== false, 'kp_gesture', 'swipeTabs') + toggle(T('swipeBack'), g.swipeBack !== false, 'kp_gesture', 'swipeBack') + toggle(T('sheetClose'), g.sheetClose !== false, 'kp_gesture', 'sheetClose') + toggle(T('pullPalette'), g.pullPalette !== false, 'kp_gesture', 'pullPalette') + toggle(T('holdBrand'), g.holdBrand !== false, 'kp_gesture', 'holdBrand') + '</div></div>';
      h += '<div class="kp-pref-card kp-wide"><div class="kp-section-title"><span>⌘</span><div><b>' + T('shortcuts') + '</b><small>' + T('shortcutsHint') + '</small></div></div>' + toggle(T('command'), s.commandPalette !== false, 'kp_toggle_ui', 'commandPalette') + '<button class="btn block kp-open-palette" data-act="kp_open_palette">⌕ ' + T('openCmd') + '</button>' + keyboardHelp() + '</div>';
      h += '<div class="kp-pref-card kp-wide"><div class="kp-section-title"><span>⌘</span><div><b>' + T('layout') + '</b><small>' + (U.lang() === 'ar' ? 'السحب والترتيب وإظهار وإخفاء الودجات والاختصارات' : 'Reorder, resize, show and hide widgets and shortcuts') + '</small></div></div><button class="btn block" data-act="wd_edit_go">' + V.icon('edit', 18) + ' ' + (U.lang() === 'ar' ? 'تعديل الصفحة الرئيسية مباشرة' : U.lang() === 'fr' ? 'Modifier directement l’accueil' : 'Edit the home screen') + '</button></div>';
      h += '<button class="btn danger-o block" data-act="kp_reset">' + V.icon('undo', 18) + ' ' + T('reset') + '</button></section>';
      var legacy = originalCustomize.call(this);
      h += '<details class="kp-legacy"><summary>' + T('layout') + ' · ' + (U.lang() === 'ar' ? 'إعدادات تفصيلية للأقسام والأيقونات' : 'Detailed sections and icon settings') + '</summary>' + legacy + '</details>';
      return h;
    };
  }

  function routeCommands() {
    var ids = ['home','sales','invoices','purchases','production','stock','expenses','debts','customers','suppliers','workers','notes','reports','profit','crm','analysis','maintenance','backup','settings','customize','assistant','cashbook','dailyclose','collect','forecast','stocktake','quotes','purchtable','prodtable','transactions'];
    return ids.map(function (id) { return { type: 'route', id: id, label: T(id), key: id }; });
  }
  function quickCommands() {
    return [
      { type: 'action', id: 'new_sale', label: T('newSale'), key: 'invoice sale فاتورة' },
      { type: 'action', id: 'new_production', label: T('newProduction'), key: 'production انتاج إنتاج' },
      { type: 'action', id: 'new_purchase', label: T('newPurchase'), key: 'purchase شراء' },
      { type: 'action', id: 'new_expense', label: T('newExpense'), key: 'expense مصروف' }
    ];
  }
  function openPalette() {
    if (!U.D || U.pinLocked) return;
    if (ui().commandPalette === false) { U.toast(T('disabled'), ''); return; }
    var items = quickCommands().concat(routeCommands());
    var h = '<div class="kp-palette-head"><div><b>' + T('palette') + '</b><small>' + T('shortcutsHint') + '</small></div><kbd>ESC</kbd></div>';
    h += '<div class="kp-palette-search"><span>⌕</span><input id="kpPaletteSearch" type="search" autocomplete="off" placeholder="' + esc(T('search')) + '"></div>';
    h += '<div id="kpPaletteResults" class="kp-palette-results">' + paletteRows(items) + '</div>';
    h += '<div class="kp-palette-foot"><span>↑ ↓</span><span>Enter</span><span>Esc</span></div>';
    U.showModal(h);
    var input = document.getElementById('kpPaletteSearch');
    if (input) { input.addEventListener('input', filterPalette); setTimeout(function () { try { input.focus(); } catch (e) {} }, 50); }
  }
  function paletteRows(items) {
    var quick = items.filter(function (x) { return x.type === 'action'; }), routes = items.filter(function (x) { return x.type === 'route'; });
    var out = '<div class="kp-palette-label">' + T('quick') + '</div>';
    out += quick.map(function (x) { return '<button class="kp-command" data-act="kp_command" data-type="action" data-id="' + x.id + '" data-search="' + esc((x.label + ' ' + x.key).toLowerCase()) + '"><span class="kp-command-icon">＋</span><span>' + esc(x.label) + '</span><kbd>↵</kbd></button>'; }).join('');
    out += '<div class="kp-palette-label">' + T('nav') + '</div>';
    out += routes.map(function (x) { return '<button class="kp-command" data-act="kp_command" data-type="route" data-id="' + x.id + '" data-search="' + esc((x.label + ' ' + x.key).toLowerCase()) + '"><span class="kp-command-icon">' + (x.id === 'home' ? '⌂' : '›') + '</span><span>' + esc(x.label) + '</span><kbd>↵</kbd></button>'; }).join('');
    return out;
  }
  function paletteKeys(e) {
    var results = document.getElementById('kpPaletteResults'), rows = results ? [].slice.call(results.querySelectorAll('.kp-command:not(.hidden)')) : [];
    if (!rows.length) return;
    var active = document.activeElement, index = rows.indexOf(active);
    if (e.key === 'ArrowDown') { e.preventDefault(); rows[Math.min(rows.length - 1, index + 1)].focus(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (index <= 0) { var inp = document.getElementById('kpPaletteSearch'); if (inp) inp.focus(); } else rows[index - 1].focus(); }
    else if (e.key === 'Enter' && active === document.getElementById('kpPaletteSearch')) { e.preventDefault(); rows[0].click(); }
  }
  function filterPalette() {
    var input = document.getElementById('kpPaletteSearch'), results = document.getElementById('kpPaletteResults');
    if (!input || !results) return;
    var q = input.value.trim().toLowerCase(), rows = [].slice.call(results.querySelectorAll('.kp-command')), visible = 0;
    rows.forEach(function (row) { var yes = !q || (row.getAttribute('data-search') || '').indexOf(q) >= 0; row.classList.toggle('hidden', !yes); if (yes) visible++; });
    var empty = results.querySelector('.kp-palette-empty');
    if (!visible && !empty) results.insertAdjacentHTML('beforeend', '<div class="kp-palette-empty">' + esc(T('noResults')) + '</div>');
    if (visible && empty) empty.remove();
  }
  function command(el) {
    var kind = el.dataset.type, id = el.dataset.id;
    U.closeModal();
    if (kind === 'route') {
      if (['home','sales','stock','production','more'].indexOf(id) >= 0) { U.stack = []; U.route = id; U.arg = null; U.render(); var main = U.$('#main'); if (main) main.scrollTop = 0; }
      else U.go(id);
      return;
    }
    var F = U.forms || {};
    var acts = { new_sale: F.sale, new_production: F.production, new_purchase: F.purchase, new_expense: F.expense };
    if (acts[id]) U.run(function () { acts[id](); });
  }

  X.kp_open_palette = openPalette;
  X.kp_command = command;
  X.kp_theme = function (el) { U.commit(function (d) { d.settings.theme = el.dataset.id; }); U.render(true); };
  X.kp_accent = function (el) { pref(function (s) { s.accent = el.dataset.id; }); U.toast(T('saved'), 'ok'); };
  X.kp_density = function (el) { pref(function (s) { s.density = el.dataset.id; }); };
  X.kp_scale = function (el) { pref(function (s) { s.scale = Number(el.dataset.id); }); };
  X.kp_corners = function (el) { pref(function (s) { s.corners = el.dataset.id; }); };
  X.kp_toggle_ui = function (el) {
    var key = el.dataset.id;
    pref(function (s) { s[key] = key === 'motion' || key === 'shadows' || key === 'haptics' || key === 'commandPalette' ? s[key] === false : s[key] === true ? false : true; });
  };
  X.kp_master_gestures = function () { U.commit(function (d) { d.settings.gestures = d.settings.gestures === false; }); U.render(true); };
  X.kp_gesture = function (el) { gesturePref(function (g) { var k = el.dataset.id; g[k] = g[k] === false; }); };
  X.kp_reset = function () {
    U.confirmBox(T('reset'), T('resetQuestion'), T('reset'), function () {
      U.commit(function (d) {
        d.settings.ui = { accent: 'blue', density: 'comfortable', scale: 100, corners: 'soft', motion: true, shadows: true, haptics: false, commandPalette: true };
        d.settings.gestures = true;
        d.settings.gestureOptions = { swipeTabs: true, swipeBack: true, sheetClose: true, pullPalette: true, holdBrand: true };
      });
      apply(); U.render(true); U.toast(T('saved'), 'ok');
    }, true);
  };

  /* Keyboard command layer — no shortcuts while the user is typing, except Ctrl/Cmd+K. */
  function typing(el) { return !!(el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName))); }
  function openTab(id) { U.closeModal(); U.stack = []; U.route = id; U.arg = null; U.render(); var m = U.$('#main'); if (m) m.scrollTop = 0; }
  document.addEventListener('keydown', function (e) {
    if (U.modalOpen && document.getElementById('kpPaletteSearch')) { paletteKeys(e); if (e.defaultPrevented) return; }
    var key = (e.key || '').toLowerCase(), mod = e.ctrlKey || e.metaKey, active = document.activeElement;
    if (mod && key === 'k') { e.preventDefault(); openPalette(); return; }
    if (e.key === 'Escape') {
      if (U.modalOpen) { e.preventDefault(); U.closeModal(); return; }
      if (!typing(active) && window.KPBack) { e.preventDefault(); window.KPBack(); }
      return;
    }
    if (typing(active) || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || !U.D || U.pinLocked) return;
    if (key === '/' && ui().commandPalette !== false) { e.preventDefault(); openPalette(); }
  });
  document.addEventListener('keydown', function (e) {
    var key = (e.key || '').toLowerCase(), mod = e.ctrlKey || e.metaKey;
    if (!mod || !e.altKey || typing(document.activeElement) || U.pinLocked) return;
    var action = key === 'n' ? 'quick' : key === 'i' ? 'sale' : key === 'p' ? 'production' : '';
    if (!action) return;
    e.preventDefault();
    if (action === 'quick') openPalette();
    else {
      var F = U.forms || {}, fn = action === 'sale' ? F.sale : F.production;
      if (fn) U.run(function () { fn(); });
    }
  });
  document.addEventListener('keydown', function (e) {
    if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || typing(document.activeElement) || U.pinLocked) return;
    var map = { '1': 'home', '2': 'sales', '3': 'production', '4': 'stock', '5': 'more' }, id = map[e.key];
    if (id) { e.preventDefault(); openTab(id); }
  });

  /* Additional vertical gestures: pull from the top for search, hold the brand for commands. */
  var touchStart = null, holdTimer = null, held = false;
  document.addEventListener('touchstart', function (e) {
    if (e.touches.length !== 1 || U.pinLocked || U.modalOpen || !U.D || U.D.settings.gestures === false) return;
    var t = e.touches[0], main = U.$('#main');
    touchStart = { x: t.clientX, y: t.clientY, top: main ? main.scrollTop : 0, target: e.target };
  }, { passive: true });
  document.addEventListener('touchend', function (e) {
    if (!touchStart || !e.changedTouches.length) { touchStart = null; return; }
    var s = touchStart, t = e.changedTouches[0], dy = t.clientY - s.y, dx = t.clientX - s.x;
    touchStart = null;
    if (U.pinLocked || U.modalOpen || !U.D || U.D.settings.gestures === false || Math.abs(dx) > 45 || dy < 85) return;
    var g = gestures(), main = U.$('#main');
    if (g.pullPalette !== false && s.y < 34 && s.top <= 2 && main && main.scrollTop <= 2) openPalette();
  }, { passive: true });
  document.addEventListener('touchcancel', function () { touchStart = null; clearTimeout(holdTimer); }, { passive: true });
  document.addEventListener('pointerdown', function (e) {
    var brand = e.target.closest && e.target.closest('#hdr .brand');
    if (!brand || !window.matchMedia || !matchMedia('(pointer: coarse)').matches || U.pinLocked || !U.D || U.modalOpen || U.D.settings.gestures === false || gestures().holdBrand === false) return;
    held = false; clearTimeout(holdTimer);
    holdTimer = setTimeout(function () { held = true; openPalette(); }, 620);
  }, { passive: true });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (name) { document.addEventListener(name, function () { clearTimeout(holdTimer); }, { passive: true }); });
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('button, .tilebtn, .tap');
    if (!b || !ui().haptics || !navigator.vibrate) return;
    try { navigator.vibrate(8); } catch (_) {}
  }, { passive: true });
  document.addEventListener('change', function (e) {
    if (e.target && e.target.id === 'kpCustomAccent') {
      var v = e.target.value;
      // Save the selected hex color exactly; derived shades are generated locally.
      pref(function (s) { s.accent = 'custom'; s.customAccent = v; });
    }
  });

  apply();
})();
