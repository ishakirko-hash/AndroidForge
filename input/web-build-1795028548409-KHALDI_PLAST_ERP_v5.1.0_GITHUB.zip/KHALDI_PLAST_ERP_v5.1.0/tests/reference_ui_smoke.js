/* Smoke-test the reference UI templates without a browser. Business logic is loaded from core.js. */
'use strict';
var root = __dirname + '/../app/src/main/assets/www/';
var fs = require('fs');
global.window = global;
global.document = { addEventListener: function () {}, querySelector: function () { return null; } };
global.addEventListener = function () {};
global.KP = require(root + 'core.js');
require(root + 'visual.js');
var K = global.KP, V = global.KPV, D = K.emptyData();
var today = K.today();
var customer = K.addCustomer(D, { name: 'عميل تجريبي', phone: '0550000000' });
var machine = K.addMachine(D, { name: 'آلة 1' });
var worker = K.addWorker(D, { name: 'عامل تجريبي', role: 'مشغل', rate: 1000, status: 'active' });
var mat = K.addMaterial(D, { name: 'Granulé', openingStock: 1000 });
K.adjustStock(D, { kind: 'product', itemId: 'prod_large', date: today, newStock: 1000 });
K.recordProduction(D, { date: today, productId: 'prod_large', shift: 1, good: 120, defective: 2, grams: (function () { var x = {}; x[mat.id] = 250; return x; })() });
K.setShiftRoster(D, { date: today, shift: 1, entries: [{ workerId: worker.id, worked: true, machineId: machine.id }] });
K.addNote(D, { date: today, title: 'طلب صندوق كبير', customerName: 'عميل تجريبي', phone: '0550000000', productId: 'prod_large', qty: 50, expectedDate: today, status: 'confirmed', text: 'طلبية تجريبية' });
K.recordSale(D, { date: today, customerId: customer.id, items: [{ productId: 'prod_large', qty: 5, unitPrice: 100000 }], paid: 500000 });
var fakeClasses = { add: function () {}, toggle: function () {} };
var fakeMain = { querySelector: function () { return null; }, insertAdjacentHTML: function () {}, classList: fakeClasses };
var fakeNodes = { '#app': { classList: fakeClasses }, '#hdr': { className: '', innerHTML: '' }, '#nav': { className: '', innerHTML: '' }, '#main': fakeMain };
var U = global.KPU = {
  K: K, V: V, D: D, route: 'home', arg: null, stack: [],
  S: { ym: K.today().slice(0, 7), workTab: 'today', stockTab: 'all', salesP: 'month', salesF: 'all', noteF: 'all', noteSort: 'added', showAll: {} },
  views: {}, extraActions: {},
  $: function (sel) { return fakeNodes[sel] || null; },
  esc: function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); },
  act: function (a) { return a.filter(function (x) { return !x.archived; }); },
  money: function (n) { return '<bdi>' + K.fmtMoney(n || 0) + '</bdi> دج'; },
  moneyTxt: function (n) { return K.fmtMoney(n || 0) + ' دج'; },
  qty: function (n) { return '<bdi>' + K.fmtQty(n || 0) + '</bdi>'; },
  dt: function (s) { return K.fmtDate(s); },
  t: function (s) { return s; },
  lang: function () { return 'ar'; },
  li: function () { return 0; },
  dayName: function (s) { return s; },
  longDate: function (s) { return s; },
  monthLabel: function (s) { return s; },
  custName: function (id) { var c = K.byId(D.customers, id); return c ? c.name : 'زبون'; },
  prodName: function (id) { var p = K.byId(D.products, id); return p ? p.name : 'منتج'; },
  workerName: function (id) { var w = K.byId(D.workers, id); return w ? w.name : 'عامل'; },
  supName: function (id) { return id || 'مورد'; },
  invNo: function (n) { return '#' + n; },
  invFull: function (s) { return 'FV-' + s.no; },
  methodLabel: function (s) { return s; },
  newest: function (a) { return a.slice().sort(function (x, y) { return x.date < y.date ? 1 : -1; }); },
  applyTheme: function () {}, render: function () {},
  alerts: function () { return []; },
  showModal: function () {}, closeModal: function () {},
  toast: function () {},
  U: null
};
U.U = U;
require(root + 'reference-ui.js');
var pages = ['home', 'sales', 'stock', 'production', 'workers', 'notes', 'more'];
var actionNames = new Set(['kp_drawer', 'kp_open_shifts', 'kp_edit_today_roster', 'kp_share_sales', 'tab', 'goto', 'bell']);
['ui-main.js', 'ui-extra.js', 'reference-ui.js'].forEach(function (file) {
  var src = fs.readFileSync(root + file, 'utf8'), m;
  var mapRe = /(?:^|,)\s*([A-Za-z0-9_]+):\s*function/gm;
  while ((m = mapRe.exec(src))) actionNames.add(m[1]);
  var extraRe = /X\.([A-Za-z0-9_]+)\s*=\s*function/g;
  while ((m = extraRe.exec(src))) actionNames.add(m[1]);
});
pages.forEach(function (name) {
  var html = U.views[name]();
  if (typeof html !== 'string' || html.length < 50) throw new Error(name + ' returned an invalid template');
  if (/<script\b/i.test(html)) throw new Error(name + ' unexpectedly emitted script tags');
  if (/NaN|undefined/.test(html)) throw new Error(name + ' emitted NaN/undefined');
  var actRe = /<button\b([^>]*)>/g, match;
  while ((match = actRe.exec(html))) {
    var attrs = match[1], action = /data-act="([^"]+)"/.exec(attrs);
    if (!action) continue;
    var act = action[1];
    if (!actionNames.has(act)) throw new Error(name + ' contains unhandled action: ' + act);
    if (['new_item'].indexOf(act) >= 0 && !/data-kind="[^"]+"/.test(attrs)) throw new Error(name + ' action ' + act + ' is missing data-kind');
    if (['adjust','edit_item','tx'].indexOf(act) >= 0 && (!/data-id="[^"]+"/.test(attrs) || !/data-kind="[^"]+"/.test(attrs))) throw new Error(name + ' action ' + act + ' is missing record identity');
    if (act === 'roster' && (!/data-date="[^"]+"/.test(attrs) || !/data-shift="[^"]+"/.test(attrs))) throw new Error(name + ' roster action is missing date/shift');
    if (['goto','tab','worktab','salesp','stocktab','notef','notesort'].indexOf(act) >= 0 && !/data-id="[^"]+"/.test(attrs)) throw new Error(name + ' action ' + act + ' is missing its id');
  }
  console.log('OK', name, html.length, 'characters');
});
console.log('REFERENCE UI SMOKE OK');
