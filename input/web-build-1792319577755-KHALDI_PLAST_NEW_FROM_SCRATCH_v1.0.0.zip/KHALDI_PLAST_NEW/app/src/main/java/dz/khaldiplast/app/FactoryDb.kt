package dz.khaldiplast.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FactoryDb(context: Context) : SQLiteOpenHelper(context, "khaldi_plast_factory.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE materials(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,stock_g INTEGER NOT NULL DEFAULT 0,min_g INTEGER NOT NULL DEFAULT 0,cost_per_kg_centimes INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,stock_units INTEGER NOT NULL DEFAULT 0,min_units INTEGER NOT NULL DEFAULT 0,sale_price_centimes INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE production_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,product_id INTEGER NOT NULL,shift TEXT NOT NULL,good_units INTEGER NOT NULL,defective_units INTEGER NOT NULL,granule_g INTEGER NOT NULL,broye_g INTEGER NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'CONFIRMED')")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,customer TEXT NOT NULL,product_id INTEGER NOT NULL,quantity INTEGER NOT NULL,unit_price_centimes INTEGER NOT NULL,total_centimes INTEGER NOT NULL,paid_centimes INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'CONFIRMED',note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,category TEXT NOT NULL,description TEXT NOT NULL,amount_centimes INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,customer TEXT NOT NULL,product TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 0,due_date TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,item_type TEXT NOT NULL,item_id INTEGER NOT NULL,delta INTEGER NOT NULL,unit TEXT NOT NULL,reason TEXT NOT NULL,reference_id INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL DEFAULT '',address TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL DEFAULT '',material TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE machines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'غير محدد',last_service TEXT NOT NULL DEFAULT '',next_service TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,work_date TEXT NOT NULL,shift TEXT NOT NULL,worker_name TEXT NOT NULL,worked INTEGER NOT NULL,notes TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE app_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
        db.execSQL("INSERT INTO materials(name,stock_g,min_g,cost_per_kg_centimes) VALUES('Granulé',0,0,0)")
        db.execSQL("INSERT INTO materials(name,stock_g,min_g,cost_per_kg_centimes) VALUES('Broyé',0,0,0)")
        db.execSQL("INSERT INTO products(name,stock_units,min_units,sale_price_centimes) VALUES('الصندوق الكبير',0,0,0)")
        db.execSQL("INSERT INTO products(name,stock_units,min_units,sale_price_centimes) VALUES('الصندوق الصغير',0,0,0)")
        db.execSQL("INSERT INTO app_settings(key,value) VALUES('company_name','KHALDI PLAST')")
        db.execSQL("INSERT INTO app_settings(key,value) VALUES('currency','DZD')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }

    fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    private fun values(vararg pairs: Pair<String, Any?>) = ContentValues().apply { pairs.forEach { (k,v) -> when(v) { null -> putNull(k); is String -> put(k,v); is Int -> put(k,v); is Long -> put(k,v); is Double -> put(k,v); is Boolean -> put(k,if(v)1 else 0); else -> put(k,v.toString()) } } }
    fun scalar(sql: String): Long = readableDatabase.rawQuery(sql, null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
    fun rows(sql: String): List<Map<String,String>> = readableDatabase.rawQuery(sql,null).use { c -> val out=mutableListOf<Map<String,String>>(); while(c.moveToNext()){ val m=mutableMapOf<String,String>(); for(i in 0 until c.columnCount) m[c.getColumnName(i)] = if(c.isNull(i)) "" else c.getString(i); out.add(m) }; out }
    fun setting(key:String, default:String=""):String = readableDatabase.rawQuery("SELECT value FROM app_settings WHERE key=?", arrayOf(key)).use { if(it.moveToFirst()) it.getString(0) else default }
    fun setSetting(key:String,value:String) { writableDatabase.insertWithOnConflict("app_settings",null,values("key" to key,"value" to value),SQLiteDatabase.CONFLICT_REPLACE) }

    fun receiveMaterial(name:String, kg:Double, priceDzdPerKg:Double, minimumKg:Double) {
        require(name.isNotBlank() && kg > 0 && priceDzdPerKg >= 0 && minimumKg >= 0)
        val db=writableDatabase; db.beginTransaction(); try {
            var id=-1L
            db.rawQuery("SELECT id FROM materials WHERE name=?",arrayOf(name)).use { if(it.moveToFirst()) id=it.getLong(0) }
            if(id<0) id=db.insertOrThrow("materials",null,values("name" to name,"stock_g" to 0,"min_g" to (minimumKg*1000).toLong(),"cost_per_kg_centimes" to (priceDzdPerKg*100).toLong()))
            val oldStock=scalar("SELECT stock_g FROM materials WHERE id=$id")
            val oldCost=scalar("SELECT cost_per_kg_centimes FROM materials WHERE id=$id")
            val addG=(kg*1000).toLong(); val newStock=oldStock+addG
            val newCost=if(newStock>0) ((oldStock*oldCost + addG*(priceDzdPerKg*100).toLong())/newStock) else (priceDzdPerKg*100).toLong()
            db.update("materials",values("stock_g" to newStock,"min_g" to (minimumKg*1000).toLong(),"cost_per_kg_centimes" to newCost),"id=?",arrayOf(id.toString()))
            db.insertOrThrow("stock_movements",null,values("created_at" to now(),"item_type" to "MATERIAL","item_id" to id,"delta" to addG,"unit" to "g","reason" to "استلام شراء"))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun adjustMaterial(name:String, kgDelta:Double, reason:String) {
        require(name.isNotBlank() && kgDelta != 0.0 && reason.isNotBlank())
        val db=writableDatabase; db.beginTransaction(); try {
            var id=-1L; db.rawQuery("SELECT id FROM materials WHERE name=?",arrayOf(name)).use { if(it.moveToFirst()) id=it.getLong(0) }; require(id>0)
            val delta=(kgDelta*1000).toLong(); val current=scalar("SELECT stock_g FROM materials WHERE id=$id"); require(current+delta>=0) { "الرصيد غير كافٍ" }
            db.update("materials",values("stock_g" to current+delta),"id=?",arrayOf(id.toString()))
            db.insertOrThrow("stock_movements",null,values("created_at" to now(),"item_type" to "MATERIAL","item_id" to id,"delta" to delta,"unit" to "g","reason" to reason))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun recordProduction(productName:String, shift:String, good:Int, defective:Int, granuleKg:Double, broyeKg:Double, note:String) {
        require(good>=0 && defective>=0 && good+defective>0 && granuleKg>=0 && broyeKg>=0)
        val db=writableDatabase; db.beginTransaction(); try {
            val productId=lookupId("products",productName); val granuleId=lookupId("materials","Granulé"); val broyeId=lookupId("materials","Broyé")
            val gg=(granuleKg*1000).toLong(); val bg=(broyeKg*1000).toLong()
            require(scalar("SELECT stock_g FROM materials WHERE id=$granuleId")>=gg) { "رصيد Granulé غير كافٍ" }
            require(scalar("SELECT stock_g FROM materials WHERE id=$broyeId")>=bg) { "رصيد Broyé غير كافٍ" }
            val runId=db.insertOrThrow("production_runs",null,values("created_at" to now(),"product_id" to productId,"shift" to shift,"good_units" to good,"defective_units" to defective,"granule_g" to gg,"broye_g" to bg,"note" to note,"status" to "CONFIRMED"))
            db.update("materials",values("stock_g" to scalar("SELECT stock_g FROM materials WHERE id=$granuleId")-gg),"id=?",arrayOf(granuleId.toString()))
            db.update("materials",values("stock_g" to scalar("SELECT stock_g FROM materials WHERE id=$broyeId")-bg),"id=?",arrayOf(broyeId.toString()))
            db.insertOrThrow("stock_movements",null,values("created_at" to now(),"item_type" to "MATERIAL","item_id" to granuleId,"delta" to -gg,"unit" to "g","reason" to "استهلاك إنتاج","reference_id" to runId))
            db.insertOrThrow("stock_movements",null,values("created_at" to now(),"item_type" to "MATERIAL","item_id" to broyeId,"delta" to -bg,"unit" to "g","reason" to "استهلاك إنتاج","reference_id" to runId))
            val stock=scalar("SELECT stock_units FROM products WHERE id=$productId")
            db.update("products",values("stock_units" to stock+good),"id=?",arrayOf(productId.toString()))
            db.insertOrThrow("stock_movements",null,values("created_at" to now(),"item_type" to "PRODUCT","item_id" to productId,"delta" to good,"unit" to "piece","reason" to "إنتاج سليم","reference_id" to runId))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun recordSale(customer:String, productName:String, qty:Int, unitPriceDzd:Double, paidDzd:Double, note:String) {
        require(customer.isNotBlank() && qty>0 && unitPriceDzd>=0 && paidDzd>=0)
        val db=writableDatabase; db.beginTransaction(); try {
            val productId=lookupId("products",productName); val stock=scalar("SELECT stock_units FROM products WHERE id=$productId"); require(stock>=qty) { "المخزون الجاهز غير كافٍ" }
            val unit=(unitPriceDzd*100).toLong(); val total=unit*qty; val paid=(paidDzd*100).toLong(); require(paid<=total) { "المبلغ المدفوع أكبر من إجمالي الفاتورة" }
            val saleId=db.insertOrThrow("sales",null,values("created_at" to now(),"customer" to customer,"product_id" to productId,"quantity" to qty,"unit_price_centimes" to unit,"total_centimes" to total,"paid_centimes" to paid,"status" to "CONFIRMED","note" to note))
            db.update("products",values("stock_units" to stock-qty),"id=?",arrayOf(productId.toString()))
            db.insertOrThrow("stock_movements",null,values("created_at" to now(),"item_type" to "PRODUCT","item_id" to productId,"delta" to -qty,"unit" to "piece","reason" to "بيع وتسليم","reference_id" to saleId))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun addExpense(category:String, description:String, amountDzd:Double) {
        require(category.isNotBlank() && amountDzd>0)
        writableDatabase.insertOrThrow("expenses",null,values("created_at" to now(),"category" to category,"description" to description,"amount_centimes" to (amountDzd*100).toLong()))
    }
    fun addNote(customer:String, product:String, quantity:Int, dueDate:String, note:String) {
        require(customer.isNotBlank() && product.isNotBlank() && quantity>=0)
        writableDatabase.insertOrThrow("notes",null,values("created_at" to now(),"customer" to customer,"product" to product,"quantity" to quantity,"due_date" to dueDate,"status" to "PENDING","note" to note))
    }
    fun updateProduct(name:String, priceDzd:Double, minUnits:Int) {
        require(name.isNotBlank() && priceDzd>=0 && minUnits>=0)
        val db=writableDatabase; var id=-1L; db.rawQuery("SELECT id FROM products WHERE name=?",arrayOf(name)).use { if(it.moveToFirst()) id=it.getLong(0) }
        if(id<0) db.insertOrThrow("products",null,values("name" to name,"sale_price_centimes" to (priceDzd*100).toLong(),"min_units" to minUnits)) else db.update("products",values("sale_price_centimes" to (priceDzd*100).toLong(),"min_units" to minUnits),"id=?",arrayOf(id.toString()))
    }
    fun updateMaterialConfig(name:String, minKg:Double, costDzdPerKg:Double) {
        require(name.isNotBlank() && minKg>=0 && costDzdPerKg>=0)
        val db=writableDatabase; var id=-1L; db.rawQuery("SELECT id FROM materials WHERE name=?",arrayOf(name)).use { if(it.moveToFirst()) id=it.getLong(0) }
        if(id<0) db.insertOrThrow("materials",null,values("name" to name,"stock_g" to 0,"min_g" to (minKg*1000).toLong(),"cost_per_kg_centimes" to (costDzdPerKg*100).toLong())) else db.update("materials",values("min_g" to (minKg*1000).toLong(),"cost_per_kg_centimes" to (costDzdPerKg*100).toLong()),"id=?",arrayOf(id.toString()))
    }
    private fun lookupId(table:String,name:String):Long { var id=-1L; readableDatabase.rawQuery("SELECT id FROM $table WHERE name=?",arrayOf(name)).use { if(it.moveToFirst()) id=it.getLong(0) }; require(id>0) { "العنصر غير موجود: $name" }; return id }
    fun totalsFor(period: String): Map<String,Long> {
        val where = when(period) {
            "day" -> "substr(created_at,1,10)=date('now','localtime')"
            "month" -> "substr(created_at,1,7)=strftime('%Y-%m','now','localtime')"
            else -> "1=1"
        }
        return mapOf(
            "sales" to scalar("SELECT COALESCE(SUM(total_centimes),0) FROM sales WHERE status='CONFIRMED' AND $where"),
            "collected" to scalar("SELECT COALESCE(SUM(paid_centimes),0) FROM sales WHERE status='CONFIRMED' AND $where"),
            "expenses" to scalar("SELECT COALESCE(SUM(amount_centimes),0) FROM expenses WHERE $where"),
            "production" to scalar("SELECT COALESCE(SUM(good_units),0) FROM production_runs WHERE status='CONFIRMED' AND $where"),
            "defective" to scalar("SELECT COALESCE(SUM(defective_units),0) FROM production_runs WHERE status='CONFIRMED' AND $where"),
            "receivables" to scalar("SELECT COALESCE(SUM(total_centimes-paid_centimes),0) FROM sales WHERE status='CONFIRMED' AND $where")
        )
    }

    fun totals(): Map<String,Long> = mapOf(
        "sales" to scalar("SELECT COALESCE(SUM(total_centimes),0) FROM sales WHERE status='CONFIRMED'"),
        "collected" to scalar("SELECT COALESCE(SUM(paid_centimes),0) FROM sales WHERE status='CONFIRMED'"),
        "expenses" to scalar("SELECT COALESCE(SUM(amount_centimes),0) FROM expenses"),
        "production" to scalar("SELECT COALESCE(SUM(good_units),0) FROM production_runs WHERE status='CONFIRMED'"),
        "defective" to scalar("SELECT COALESCE(SUM(defective_units),0) FROM production_runs WHERE status='CONFIRMED'"),
        "receivables" to scalar("SELECT COALESCE(SUM(total_centimes-paid_centimes),0) FROM sales WHERE status='CONFIRMED'")
    )
    fun materials():List<Map<String,String>> = rows("SELECT id,name,stock_g,min_g,cost_per_kg_centimes FROM materials WHERE active=1 ORDER BY name")
    fun products():List<Map<String,String>> = rows("SELECT id,name,stock_units,min_units,sale_price_centimes FROM products WHERE active=1 ORDER BY id")
    fun recentSales():List<Map<String,String>> = rows("SELECT s.id,s.created_at,s.customer,p.name AS product,s.quantity,s.total_centimes,s.paid_centimes FROM sales s JOIN products p ON p.id=s.product_id ORDER BY s.id DESC LIMIT 20")
    fun recentProduction():List<Map<String,String>> = rows("SELECT r.id,r.created_at,p.name AS product,r.shift,r.good_units,r.defective_units,r.granule_g,r.broye_g FROM production_runs r JOIN products p ON p.id=r.product_id ORDER BY r.id DESC LIMIT 20")
    fun recentExpenses():List<Map<String,String>> = rows("SELECT id,created_at,category,description,amount_centimes FROM expenses ORDER BY id DESC LIMIT 20")
    fun recentNotes():List<Map<String,String>> = rows("SELECT id,created_at,customer,product,quantity,due_date,status,note FROM notes ORDER BY id DESC LIMIT 30")
    fun movements():List<Map<String,String>> = rows("SELECT m.id,m.created_at,m.item_type,CASE WHEN m.item_type='MATERIAL' THEN (SELECT name FROM materials WHERE id=m.item_id) ELSE (SELECT name FROM products WHERE id=m.item_id) END AS item,m.delta,m.unit,m.reason FROM stock_movements m ORDER BY id DESC LIMIT 50")
    fun addCustomer(name:String,phone:String,address:String,notes:String) { require(name.isNotBlank()); writableDatabase.insertOrThrow("customers",null,values("name" to name,"phone" to phone,"address" to address,"notes" to notes)) }
    fun addSupplier(name:String,phone:String,material:String,notes:String) { require(name.isNotBlank()); writableDatabase.insertOrThrow("suppliers",null,values("name" to name,"phone" to phone,"material" to material,"notes" to notes)) }
    fun addMachine(name:String,status:String,last:String,next:String,notes:String) { require(name.isNotBlank()); writableDatabase.insertOrThrow("machines",null,values("name" to name,"status" to status,"last_service" to last,"next_service" to next,"notes" to notes)) }
    fun addAttendance(shift:String,worker:String,worked:Boolean,notes:String) { require(worker.isNotBlank()); writableDatabase.insertOrThrow("attendance",null,values("work_date" to now().take(10),"shift" to shift,"worker_name" to worker,"worked" to worked,"notes" to notes)) }
    fun customers():List<Map<String,String>> = rows("SELECT id,name,phone,address,notes FROM customers ORDER BY name")
    fun suppliers():List<Map<String,String>> = rows("SELECT id,name,phone,material,notes FROM suppliers ORDER BY name")
    fun machines():List<Map<String,String>> = rows("SELECT id,name,status,last_service,next_service,notes FROM machines ORDER BY name")
    fun attendance():List<Map<String,String>> = rows("SELECT id,work_date,shift,worker_name,worked,notes FROM attendance ORDER BY id DESC LIMIT 100")
    fun lowStockCount():Long = scalar("SELECT COUNT(*) FROM materials WHERE min_g>0 AND stock_g<=min_g") + scalar("SELECT COUNT(*) FROM products WHERE min_units>0 AND stock_units<=min_units")
}
