package dz.khaldiplast.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToLong

private val Navy = Color(0xFF092541)
private val Blue = Color(0xFF087FE5)
private val Cyan = Color(0xFF00B7E8)
private val Canvas = Color(0xFFF3F7FC)
private val Ink = Color(0xFF173453)
private val Muted = Color(0xFF71849A)
private val Green = Color(0xFF08A978)
private val Orange = Color(0xFFF2A431)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = FactoryDb(this)
        setContent { KpApp(db) }
    }
}

private data class NavItem(val label: String, val icon: ImageVector, val key: String)
private val navItems = listOf(
    NavItem("الرئيسية", Icons.Default.Home, "home"),
    NavItem("المبيعات", Icons.Default.ShoppingCart, "sales"),
    NavItem("المخزون", Icons.Default.Inventory2, "inventory"),
    NavItem("الإنتاج", Icons.Default.Factory, "production"),
    NavItem("المزيد", Icons.Default.GridView, "more")
)

@Composable
private fun KpApp(db: FactoryDb) {
    var selected by remember { mutableStateOf("home") }
    var refresh by remember { mutableIntStateOf(0) }
    var dialogType by remember { mutableStateOf<String?>(null) }
    var assistantInput by remember { mutableStateOf("") }
    var assistantAnswer by remember { mutableStateOf("مرحبًا! اكتب عملية حسابية أو اسأل عن بيانات المصنع المسجلة.") }
    var message by remember { mutableStateOf<String?>(null) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Cyan, background = Canvas, surface = Color.White, onPrimary = Color.White, onSurface = Ink)) {
            Scaffold(
                containerColor = Canvas,
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 6.dp) {
                        navItems.forEach { item ->
                            NavigationBarItem(
                                selected = selected == item.key,
                                onClick = { selected = item.key },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = { Text(item.label, fontSize = 11.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, indicatorColor = Color(0xFFE2F2FF), selectedTextColor = Blue, unselectedTextColor = Muted)
                            )
                        }
                    }
                },
                snackbarHost = { message?.let { Snackbar(modifier = Modifier.padding(12.dp), action = { TextButton(onClick={message=null}) { Text("حسنًا") } }) { Text(it) } } }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    Header(selected, db)
                    key(refresh) {
                        when (selected) {
                            "home" -> HomeScreen(db, onNavigate = { selected = it }, onAdd = { dialogType = it })
                            "sales" -> SalesScreen(db, onAdd = { dialogType = "sale" })
                            "inventory" -> InventoryScreen(db, onAdd = { dialogType = "purchase" }, onAdjust = { dialogType = "adjust" })
                            "production" -> ProductionScreen(db, onAdd = { dialogType = "production" })
                            "more" -> MoreScreen(onNavigate = { selected = it })
                            "notes" -> NotesScreen(db, onAdd = { dialogType = "note" })
                            "expenses" -> ExpensesScreen(db, onAdd = { dialogType = "expense" })
                            "reports" -> ReportsScreen(db)
                            "assistant" -> AssistantScreen(db, assistantInput, { assistantInput = it }, assistantAnswer, { assistantAnswer = answerAssistant(db, assistantInput) })
                            "shifts" -> ShiftsScreen(db)
                            "settings" -> SettingsScreen(db, onSaved = { refresh++ })
                            "movements" -> MovementsScreen(db)
                            "customers" -> DirectoryScreen("الزبائن", db.customers(), onAdd = { dialogType = "customer" })
                            "suppliers" -> DirectoryScreen("الموردون", db.suppliers(), onAdd = { dialogType = "supplier" })
                            "machines" -> MachinesScreen(db, onAdd = { dialogType = "machine" })
                            "attendance" -> AttendanceScreen(db, onAdd = { dialogType = "attendance" })
                            else -> HomeScreen(db, onNavigate = { selected = it }, onAdd = { dialogType = it })
                        }
                    }
                }
                if (dialogType != null) EntryDialog(db, dialogType!!, onDismiss = { dialogType = null }, onSaved = { success -> refresh++; dialogType = null; message = if (success) "تم حفظ العملية بنجاح" else "تعذر حفظ العملية؛ تحقق من البيانات والرصيد" })
            }
        }
    }
}

@Composable
private fun Header(selected: String, db: FactoryDb) {
    val title = when(selected) { "home"->"الرئيسية"; "sales"->"المبيعات"; "inventory"->"المخزون"; "production"->"الإنتاج"; "notes"->"الطلبات القادمة"; "expenses"->"المصاريف"; "reports"->"التقارير"; "assistant"->"المساعد الذكي"; "shifts"->"الشفتات"; "settings"->"الإعدادات"; "movements"->"حركة المخزون"; "customers"->"الزبائن"; "suppliers"->"الموردون"; "machines"->"الآلات والصيانة"; "attendance"->"الحضور"; else->"المزيد" }
    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("إدارة مصنع KHALDI PLAST", fontSize = 11.sp, color = Muted)
        }
        Box(Modifier.size(42.dp).background(Color(0xFFE5F4FF), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.NotificationsNone, null, tint = Blue) }
        Spacer(Modifier.width(10.dp))
        Box(Modifier.size(48.dp).background(Color.White, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Image(painterResource(R.drawable.khaldi_plast_official_logo), contentDescription = "KHALDI PLAST official logo", modifier = Modifier.fillMaxSize().padding(2.dp), contentScale = ContentScale.Fit) }
    }
}

@Composable
private fun ScreenScroll(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp), content = content)
}

@Composable
private fun HomeScreen(db: FactoryDb, onNavigate: (String)->Unit, onAdd:(String)->Unit) {
    val totals = db.totals()
    val materials = db.materials()
    val products = db.products()
    ScreenScroll {
        Spacer(Modifier.height(12.dp))
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مرحبًا بك", color = Color.White.copy(alpha=0.75f), fontSize = 13.sp)
                    Text("KHALDI PLAST", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("لوحة متابعة المصنع", color = Color(0xFFBFEAFF), fontSize = 12.sp)
                }
                Box(Modifier.size(58.dp).background(Color(0xFF0B78C9), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Factory, null, tint = Color.White, modifier = Modifier.size(32.dp)) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("إجمالي المبيعات", money(totals["sales"] ?: 0), Icons.Default.TrendingUp, Blue, Modifier.weight(1f))
            MetricCard("المبالغ المحصلة", money(totals["collected"] ?: 0), Icons.Default.AccountBalanceWallet, Green, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("إنتاج سليم", (totals["production"] ?: 0).toString()+" قطعة", Icons.Default.Factory, Cyan, Modifier.weight(1f))
            MetricCard("ديون الزبائن", money(totals["receivables"] ?: 0), Icons.Default.RequestQuote, Orange, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        SectionTitle("الوصول السريع", "أهم العمليات")
        val shortcuts = listOf(Triple("فاتورة جديدة", Icons.Default.AddShoppingCart, "sale"), Triple("تسجيل إنتاج", Icons.Default.Factory, "production"), Triple("شراء مواد", Icons.Default.Inventory2, "purchase"), Triple("مصروف جديد", Icons.Default.ReceiptLong, "expense"), Triple("طلب قادم", Icons.Default.EventNote, "note"), Triple("المساعد الذكي", Icons.Default.AutoAwesome, "assistant"))
        shortcuts.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { item -> Shortcut(item.first, item.second, Modifier.weight(1f)) { if(item.third=="assistant") onNavigate("assistant") else onAdd(item.third) } }
                if(row.size<3) repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(8.dp))
        SectionTitle("تنبيهات المخزون", "${db.lowStockCount()} عناصر عند الحد الأدنى أو دونه")
        if(materials.isEmpty() && products.isEmpty()) EmptyCard("لا توجد بيانات مخزون بعد") else {
            materials.filter { (it["min_g"]?.toLongOrNull()?:0L)>0 && (it["stock_g"]?.toLongOrNull()?:0L) <= (it["min_g"]?.toLongOrNull()?:0L) }.forEach { SimpleRow(Icons.Default.WarningAmber, it["name"] ?: "", "الرصيد: ${formatKg((it["stock_g"]?.toLongOrNull()?:0L)/1000.0)} كغ", Orange) }
            products.filter { (it["min_units"]?.toLongOrNull()?:0L)>0 && (it["stock_units"]?.toLongOrNull()?:0L) <= (it["min_units"]?.toLongOrNull()?:0L) }.forEach { SimpleRow(Icons.Default.Inventory2, it["name"] ?: "", "الرصيد: ${it["stock_units"]} قطعة", Orange) }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun MetricCard(title:String, value:String, icon:ImageVector, tint:Color, modifier:Modifier=Modifier) {
    Card(modifier, shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(13.dp)) {
            Box(Modifier.size(38.dp).background(tint.copy(alpha=0.12f), RoundedCornerShape(12.dp)), contentAlignment=Alignment.Center) { Icon(icon,null,tint=tint) }
            Spacer(Modifier.height(10.dp)); Text(title, color=Muted, fontSize=11.sp); Spacer(Modifier.height(4.dp)); Text(value, color=Navy, fontSize=17.sp, fontWeight=FontWeight.Bold, maxLines=1, overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun Shortcut(title:String, icon:ImageVector, modifier:Modifier=Modifier, onClick:()->Unit) {
    Card(modifier.clickable(onClick=onClick), shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(vertical=14.dp, horizontal=4.dp).fillMaxWidth(), horizontalAlignment=Alignment.CenterHorizontally) {
            Box(Modifier.size(42.dp).background(Color(0xFFE6F4FF), RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center) { Icon(icon,null,tint=Blue,modifier=Modifier.size(23.dp)) }
            Spacer(Modifier.height(7.dp)); Text(title, fontSize=11.sp, color=Ink, fontWeight=FontWeight.SemiBold, maxLines=1)
        }
    }
}

@Composable
private fun SectionTitle(title:String, subtitle:String?=null) {
    Row(Modifier.fillMaxWidth().padding(vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight=FontWeight.Bold, color=Navy, fontSize=15.sp); if(subtitle!=null) Text(subtitle, color=Muted, fontSize=10.sp) }
    }
}

@Composable
private fun SalesScreen(db:FactoryDb,onAdd:()->Unit) {
    val totals=db.totals(); val sales=db.recentSales()
    ScreenScroll {
        Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { MetricCard("المبيعات",money(totals["sales"]?:0),Icons.Default.Receipt,Blue,Modifier.weight(1f)); MetricCard("المتبقي",money(totals["receivables"]?:0),Icons.Default.AccountBalance,Orange,Modifier.weight(1f)) }
        Spacer(Modifier.height(12.dp)); Button(onClick=onAdd, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(6.dp)); Text("إنشاء فاتورة جديدة") }
        SectionTitle("آخر الفواتير", "${sales.size} سجلات أخيرة")
        if(sales.isEmpty()) EmptyCard("لا توجد فواتير بعد. ابدأ بإنشاء فاتورة جديدة.") else sales.forEach { s -> DataCard(title="${s["customer"]} • ${s["product"]}", subtitle="${s["created_at"]} • الكمية ${s["quantity"]}", value=money(s["total_centimes"]?.toLongOrNull()?:0), foot="محصل: ${money(s["paid_centimes"]?.toLongOrNull()?:0)}") }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun InventoryScreen(db:FactoryDb,onAdd:()->Unit,onAdjust:()->Unit) {
    val materials=db.materials(); val products=db.products()
    ScreenScroll {
        Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick=onAdd, modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)) { Icon(Icons.Default.Add,null); Text("استلام شراء") }; OutlinedButton(onClick=onAdjust, modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)) { Icon(Icons.Default.SwapVert,null); Text("تسوية المخزون") } }
        SectionTitle("المواد الخام", "الرصيد بالكيلوغرام")
        materials.forEach { m ->
            val stock=(m["stock_g"]?.toLongOrNull()?:0L)/1000.0; val min=(m["min_g"]?.toLongOrNull()?:0L)/1000.0
            DataCard(m["name"]?:"", "الرصيد ${formatKg(stock)} كغ • الحد الأدنى ${formatKg(min)} كغ", money(m["cost_per_kg_centimes"]?.toLongOrNull()?:0)+" / كغ", if(stock<=min) "تنبيه: الرصيد عند الحد الأدنى" else "متاح", if(stock<=min) Orange else Green)
        }
        SectionTitle("المنتجات الجاهزة", "الرصيد بالقطعة")
        products.forEach { p -> val stock=p["stock_units"]?.toLongOrNull()?:0L; val min=p["min_units"]?.toLongOrNull()?:0L; DataCard(p["name"]?:"", "الرصيد $stock قطعة • الحد الأدنى $min", money(p["sale_price_centimes"]?.toLongOrNull()?:0), if(stock<=min) "تنبيه: منخفض" else "متاح", if(stock<=min) Orange else Green) }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun ProductionScreen(db:FactoryDb,onAdd:()->Unit) {
    val totals=db.totals(); val runs=db.recentProduction()
    ScreenScroll {
        Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { MetricCard("إنتاج سليم", "${totals["production"]?:0}", Icons.Default.Factory, Blue, Modifier.weight(1f)); MetricCard("إنتاج معيب", "${totals["defective"]?:0}", Icons.Default.WarningAmber, Orange, Modifier.weight(1f)) }
        Spacer(Modifier.height(10.dp)); Button(onClick=onAdd, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add,null); Text("تسجيل عملية إنتاج") }
        SectionTitle("سجل الإنتاج", "آخر العمليات")
        if(runs.isEmpty()) EmptyCard("لا توجد عمليات إنتاج مسجلة") else runs.forEach { r -> DataCard("${r["product"]}", "${r["created_at"]} • ${r["shift"]}", "سليم: ${r["good_units"]}", "معيب: ${r["defective_units"]} • Granulé ${formatKg((r["granule_g"]?.toDoubleOrNull()?:0.0)/1000)} كغ • Broyé ${formatKg((r["broye_g"]?.toDoubleOrNull()?:0.0)/1000)} كغ") }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun MoreScreen(onNavigate:(String)->Unit) {
    val items=listOf(Triple("الطلبات والملاحظات",Icons.Default.EventNote,"notes"),Triple("المصاريف",Icons.Default.ReceiptLong,"expenses"),Triple("التقارير اليومية والشهرية",Icons.Default.BarChart,"reports"),Triple("المساعد الذكي",Icons.Default.AutoAwesome,"assistant"),Triple("الشفتات",Icons.Default.Schedule,"shifts"),Triple("حركة المخزون",Icons.Default.SwapHoriz,"movements"),Triple("الزبائن",Icons.Default.People,"customers"),Triple("الموردون",Icons.Default.LocalShipping,"suppliers"),Triple("الآلات والصيانة",Icons.Default.Build,"machines"),Triple("الحضور والعمال",Icons.Default.Badge,"attendance"),Triple("الإعدادات والتخصيص",Icons.Default.Settings,"settings"))
    ScreenScroll { Spacer(Modifier.height(10.dp)); items.forEach { (title,icon,key)-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp).background(Color.White,RoundedCornerShape(16.dp)).clickable { onNavigate(key) }.padding(15.dp), verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(42.dp).background(Color(0xFFE7F4FF),RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){Icon(icon,null,tint=Blue)}; Spacer(Modifier.width(12.dp)); Text(title,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,color=Ink); Icon(Icons.Default.ChevronLeft,null,tint=Muted) } }; Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun NotesScreen(db:FactoryDb,onAdd:()->Unit) {
    val notes=db.recentNotes()
    ScreenScroll { Spacer(Modifier.height(10.dp)); Button(onClick=onAdd,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,null);Text("إضافة طلب قادم")}; SectionTitle("الطلبات القادمة", "تذكير بالطلبات غير المحولة إلى فواتير")
        if(notes.isEmpty()) EmptyCard("لا توجد طلبات قادمة") else notes.forEach { n->DataCard("${n["customer"]} • ${n["product"]}","الكمية ${n["quantity"]} • التسليم ${n["due_date"].takeIf{!it.isNullOrBlank()}?:"غير محدد"}",n["status"]?:"قيد الانتظار",n["note"]?:"") }
        Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun ExpensesScreen(db:FactoryDb,onAdd:()->Unit) {
    val rows=db.recentExpenses(); val total=db.totals()["expenses"]?:0
    ScreenScroll { Spacer(Modifier.height(10.dp)); MetricCard("إجمالي المصاريف المسجلة",money(total),Icons.Default.ReceiptLong,Orange,Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp)); Button(onClick=onAdd,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,null);Text("تسجيل مصروف")}; SectionTitle("آخر المصاريف")
        if(rows.isEmpty()) EmptyCard("لا توجد مصاريف مسجلة") else rows.forEach { r->DataCard(r["category"]?:"", "${r["created_at"]} • ${r["description"]}",money(r["amount_centimes"]?.toLongOrNull()?:0)) }; Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun ReportsScreen(db:FactoryDb) {
    val t=db.totals(); val mats=db.materials(); val prods=db.products()
    ScreenScroll { Spacer(Modifier.height(10.dp)); SectionTitle("ملخص التشغيل", "أرقام محسوبة من قاعدة البيانات المحلية")
        listOf(Triple("المبيعات المفوترة",money(t["sales"]?:0),Icons.Default.TrendingUp),Triple("التحصيلات المسجلة",money(t["collected"]?:0),Icons.Default.Payments),Triple("الديون المسجلة",money(t["receivables"]?:0),Icons.Default.AccountBalance),Triple("المصاريف المسجلة",money(t["expenses"]?:0),Icons.Default.Receipt),Triple("الإنتاج السليم", "${t["production"]?:0} قطعة",Icons.Default.Factory),Triple("الإنتاج المعيب","${t["defective"]?:0} قطعة",Icons.Default.WarningAmber)).forEach { DataCard(it.first,it.second,"بيانات فعلية",icon=it.third) }
        SectionTitle("تنبيه منهجي")
        EmptyCard("هذه نسخة أولية تحسب الإجماليات المسجلة. يجب استكمال تصنيف الفترات بالتاريخ والتحقق المحاسبي قبل اعتمادها كتقرير إقفال رسمي.")
        Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun AssistantScreen(db:FactoryDb,input:String,onInput:(String)->Unit,answer:String,onCalculate:()->Unit) {
    ScreenScroll { Spacer(Modifier.height(10.dp)); Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Navy)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(44.dp).background(Color(0xFF0B78C9),CircleShape),contentAlignment=Alignment.Center){Icon(Icons.Default.AutoAwesome,null,tint=Color.White)}; Spacer(Modifier.width(10.dp)); Column { Text("المساعد الذكي",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold); Text("حسابات محلية وقراءة بيانات مسجلة",color=Color(0xFFBFEAFF),fontSize=11.sp) } }; Spacer(Modifier.height(12.dp)); Text(answer,color=Color.White,fontSize=14.sp,lineHeight=22.sp) } }
        Spacer(Modifier.height(12.dp)); OutlinedTextField(value=input,onValueChange=onInput,modifier=Modifier.fillMaxWidth(),label={Text("اكتب طلبك الحسابي")},placeholder={Text("مثال: 120 كغ بسعر 250 دج للكيلوغرام")},minLines=2,shape=RoundedCornerShape(16.dp))
        Spacer(Modifier.height(8.dp)); Button(onClick=onCalculate,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Calculate,null);Text("احسب / حلّل")}
        SectionTitle("أمثلة سريعة")
        listOf("كم إجمالي المبيعات المسجلة؟","كم بقي من Granulé؟","كم الديون المسجلة؟","احسب 120 كغ بسعر 250 دج للكيلوغرام").forEach { q->Text(q,Modifier.fillMaxWidth().padding(vertical=4.dp).background(Color.White,RoundedCornerShape(12.dp)).clickable { onInput(q) }.padding(12.dp),color=Blue,fontSize=13.sp) }
        EmptyCard("المساعد لا يعدّل المخزون أو الفواتير. أي عملية تسجيل يجب أن تتم من الشاشة المخصصة وبعد التحقق من البيانات.")
        Spacer(Modifier.height(18.dp)) }
}

private fun answerAssistant(db:FactoryDb, raw:String):String {
    val q=raw.trim(); if(q.isBlank()) return "اكتب طلبًا أولًا."
    val lower=q.lowercase(Locale.ROOT); val t=db.totals()
    if(lower.contains("مبيعات")||lower.contains("المبيعات")) return "إجمالي المبيعات المسجلة: ${money(t["sales"]?:0)}. المبالغ المحصلة: ${money(t["collected"]?:0)}."
    if(lower.contains("ديون")||lower.contains("الدين")) return "إجمالي المبالغ المتبقية على الفواتير المسجلة: ${money(t["receivables"]?:0)}."
    if(lower.contains("مصاريف")||lower.contains("المصاريف")) return "إجمالي المصاريف المسجلة: ${money(t["expenses"]?:0)}."
    if(lower.contains("إنتاج")||lower.contains("الانتاج")) return "إجمالي الإنتاج السليم المسجل: ${t["production"]?:0} قطعة. المعيب: ${t["defective"]?:0} قطعة."
    if(lower.contains("granulé")||lower.contains("granule")||lower.contains("granulé")) {
        if(lower.contains("مخزون")||lower.contains("بقي")||lower.contains("رصيد")) { val m=db.materials().firstOrNull{it["name"]=="Granulé"}; return "رصيد Granulé المسجل: ${formatKg(((m?.get("stock_g")?.toDoubleOrNull()?:0.0)/1000))} كغ." }
    }
    val nums=Regex("\\d+(?:[.,]\\d+)?").findAll(q).mapNotNull { it.value.replace(',','.').toDoubleOrNull() }.toList()
    if(nums.size>=2 && (lower.contains("كغ")||lower.contains("kg")||lower.contains("كيلوغرام")||lower.contains("سعر")||lower.contains("دج"))) {
        val total=nums[0]*nums[1]; return "الحساب: ${formatNum(nums[0])} × ${formatNum(nums[1])} = ${moneyDzd(total)}.\nاعتبرت الرقم الأول كمية والثاني سعر الوحدة. راجع ترتيب الأرقام قبل اعتماد النتيجة."
    }
    if(nums.size>=2) return "الناتج الحسابي للرقمين الأولين: ${formatNum(nums[0])} × ${formatNum(nums[1])} = ${formatNum(nums[0]*nums[1])}. إذا كنت تقصد عملية أخرى، اكتبها بوضوح مثل: 120 × 250."
    return "أستطيع حاليًا حساب الكميات والأسعار وقراءة الإجماليات المسجلة. جرّب مثلًا: «كم الديون المسجلة؟» أو «120 كغ بسعر 250 دج للكيلوغرام». لا أُجري تغييرات على بيانات المصنع من خلال المحادثة."
}

@Composable
private fun ShiftsScreen(db:FactoryDb) {
    val runs=db.recentProduction()
    ScreenScroll { Spacer(Modifier.height(10.dp)); SectionTitle("الورديات المعتمدة", "أوقات ثابتة للمصنع")
        listOf(Triple("الصباحية","08:00 – 16:00","morning"),Triple("المسائية","16:00 – 00:00","evening"),Triple("الليلية","00:00 – 08:00","night")).forEach { (name,time,key)-> Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Schedule,null,tint=Blue);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold,color=Navy);Text(time,color=Muted,fontSize=12.sp)};Text("${runs.filter{it["shift"]==name}.sumOf{it["good_units"]?.toLongOrNull()?:0L} } قطعة",color=Blue,fontWeight=FontWeight.Bold,fontSize=12.sp)}} }
        SectionTitle("ملاحظة")
        EmptyCard("تسجيل الحضور والأسماء يحتاج إلى إدارة عمال مخصصة، ولم تتم إضافة بيانات عمال افتراضية.")
        Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun DirectoryScreen(title:String, rows:List<Map<String,String>>, onAdd:()->Unit) {
    ScreenScroll { Spacer(Modifier.height(10.dp)); Button(onClick=onAdd,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,null);Text("إضافة سجل")}; SectionTitle(title,"السجلات المحفوظة محليًا")
        if(rows.isEmpty()) EmptyCard("لا توجد سجلات بعد") else rows.forEach { r ->
            val subtitle=listOfNotNull(r["phone"]?.takeIf{it.isNotBlank()},r["address"]?.takeIf{it.isNotBlank()},r["material"]?.takeIf{it.isNotBlank()},r["notes"]?.takeIf{it.isNotBlank()}).joinToString(" • ")
            DataCard(r["name"]?:"",subtitle, "مسجل", icon=Icons.Default.Person)
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun MachinesScreen(db:FactoryDb,onAdd:()->Unit) {
    val rows=db.machines()
    ScreenScroll { Spacer(Modifier.height(10.dp)); Button(onClick=onAdd,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,null);Text("إضافة آلة أو موعد صيانة")}; SectionTitle("الآلات والصيانة")
        if(rows.isEmpty()) EmptyCard("أضف الآلات ومواعيد صيانتها لبدء المتابعة") else rows.forEach { r->DataCard(r["name"]?:"", "الحالة: ${r["status"]} • آخر صيانة: ${r["last_service"]}", "القادم: ${r["next_service"]}", r["notes"]?:"", if(r["status"]?.contains("عطل")==true) Orange else Blue, Icons.Default.Build)}
        Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun AttendanceScreen(db:FactoryDb,onAdd:()->Unit) {
    val rows=db.attendance()
    ScreenScroll { Spacer(Modifier.height(10.dp)); Button(onClick=onAdd,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,null);Text("تسجيل حضور عامل")}; SectionTitle("الحضور حسب الوردية", "تسجيل الاسم وحالة عمل/لم يعمل")
        if(rows.isEmpty()) EmptyCard("لا توجد سجلات حضور بعد") else rows.forEach { r-> val worked=r["worked"]=="1"; DataCard(r["worker_name"]?:"", "${r["work_date"]} • ${r["shift"]}", if(worked) "عمل" else "لم يعمل", r["notes"]?:"", if(worked) Green else Orange, Icons.Default.Badge) }
        Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun SettingsScreen(db:FactoryDb,onSaved:()->Unit) {
    var company by remember { mutableStateOf(db.setting("company_name","KHALDI PLAST")) }
    var phone by remember { mutableStateOf(db.setting("company_phone","0798587564")) }
    var email by remember { mutableStateOf(db.setting("company_email","khaldiplast@gmail.com")) }
    var address by remember { mutableStateOf(db.setting("company_address","مركز بن خليل")) }
    val products=db.products(); val materials=db.materials()
    var bigPrice by remember { mutableStateOf(((products.firstOrNull{it["name"]=="الصندوق الكبير"}?.get("sale_price_centimes")?.toLongOrNull()?:0L)/100.0).toString()) }
    var bigMin by remember { mutableStateOf(products.firstOrNull{it["name"]=="الصندوق الكبير"}?.get("min_units")?:"0") }
    var smallPrice by remember { mutableStateOf(((products.firstOrNull{it["name"]=="الصندوق الصغير"}?.get("sale_price_centimes")?.toLongOrNull()?:0L)/100.0).toString()) }
    var smallMin by remember { mutableStateOf(products.firstOrNull{it["name"]=="الصندوق الصغير"}?.get("min_units")?:"0") }
    var granuleMin by remember { mutableStateOf(((materials.firstOrNull{it["name"]=="Granulé"}?.get("min_g")?.toLongOrNull()?:0L)/1000.0).toString()) }
    var granuleCost by remember { mutableStateOf(((materials.firstOrNull{it["name"]=="Granulé"}?.get("cost_per_kg_centimes")?.toLongOrNull()?:0L)/100.0).toString()) }
    var broyeMin by remember { mutableStateOf(((materials.firstOrNull{it["name"]=="Broyé"}?.get("min_g")?.toLongOrNull()?:0L)/1000.0).toString()) }
    var broyeCost by remember { mutableStateOf(((materials.firstOrNull{it["name"]=="Broyé"}?.get("cost_per_kg_centimes")?.toLongOrNull()?:0L)/100.0).toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    ScreenScroll { Spacer(Modifier.height(10.dp)); SectionTitle("بيانات الشركة", "تُحفظ الإعدادات محليًا")
        OutlinedTextField(company,{company=it},modifier=Modifier.fillMaxWidth(),label={Text("اسم الشركة")},singleLine=true)
        Spacer(Modifier.height(8.dp)); OutlinedTextField(phone,{phone=it},modifier=Modifier.fillMaxWidth(),label={Text("رقم الهاتف")},singleLine=true)
        Spacer(Modifier.height(8.dp)); OutlinedTextField(email,{email=it},modifier=Modifier.fillMaxWidth(),label={Text("البريد الإلكتروني")},singleLine=true)
        Spacer(Modifier.height(8.dp)); OutlinedTextField(address,{address=it},modifier=Modifier.fillMaxWidth(),label={Text("العنوان")},singleLine=true)
        SectionTitle("الصندوق الكبير", "السعر والحد الأدنى للمخزون")
        Field("سعر البيع بالدينار",bigPrice,{bigPrice=it},true); Field("حد التنبيه بالقطعة",bigMin,{bigMin=it},true)
        SectionTitle("الصندوق الصغير")
        Field("سعر البيع بالدينار",smallPrice,{smallPrice=it},true); Field("حد التنبيه بالقطعة",smallMin,{smallMin=it},true)
        SectionTitle("Granulé", "حد التنبيه والتكلفة المرجعية")
        Field("الحد الأدنى بالكيلوغرام",granuleMin,{granuleMin=it},true); Field("التكلفة المرجعية دج/كغ",granuleCost,{granuleCost=it},true)
        SectionTitle("Broyé")
        Field("الحد الأدنى بالكيلوغرام",broyeMin,{broyeMin=it},true); Field("التكلفة المرجعية دج/كغ",broyeCost,{broyeCost=it},true)
        error?.let { Text(it,color=MaterialTheme.colorScheme.error,fontSize=12.sp) }
        Spacer(Modifier.height(12.dp)); Button(onClick={
            try {
                db.setSetting("company_name",company.trim());db.setSetting("company_phone",phone.trim());db.setSetting("company_email",email.trim());db.setSetting("company_address",address.trim())
                db.updateProduct("الصندوق الكبير",bigPrice.toDouble(),bigMin.toInt()); db.updateProduct("الصندوق الصغير",smallPrice.toDouble(),smallMin.toInt())
                db.updateMaterialConfig("Granulé",granuleMin.toDouble(),granuleCost.toDouble()); db.updateMaterialConfig("Broyé",broyeMin.toDouble(),broyeCost.toDouble())
                error=null; onSaved()
            } catch(e:Exception) { error=e.message ?: "تحقق من الإعدادات" }
        },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Save,null);Text("حفظ كل الإعدادات")}
        Text("المبالغ تدخل بالدينار وتُخزن داخليًا بالسنتيم. تغييرات التكلفة المرجعية لا تعيد كتابة أسعار الفواتير القديمة.",color=Muted,fontSize=11.sp,lineHeight=17.sp)
        Spacer(Modifier.height(18.dp)) }
}
@Composable
private fun MovementsScreen(db:FactoryDb) {
    val rows=db.movements()
    ScreenScroll { Spacer(Modifier.height(10.dp)); SectionTitle("آخر حركات المخزون", "كل حركة مرتبطة بسببها")
        if(rows.isEmpty()) EmptyCard("لا توجد حركات مخزون بعد") else rows.forEach { r-> val d=r["delta"]?.toLongOrNull()?:0L; DataCard(r["item"]?:"", "${r["created_at"]} • ${r["reason"]}", (if(d>0) "+" else "")+d.toString()+" ${r["unit"]}", if(d<0) "خروج" else "دخول", if(d<0) Orange else Green) }
        Spacer(Modifier.height(18.dp)) }
}

@Composable
private fun EntryDialog(db:FactoryDb,type:String,onDismiss:()->Unit,onSaved:(Boolean)->Unit) {
    val title=when(type){"sale"->"فاتورة بيع جديدة";"production"->"تسجيل عملية إنتاج";"purchase"->"استلام شراء مواد";"adjust"->"تسوية مادة خام";"expense"->"تسجيل مصروف";"note"->"طلب قادم / ملاحظة";"customer"->"إضافة زبون";"supplier"->"إضافة مورد";"machine"->"إضافة آلة";"attendance"->"تسجيل حضور عامل";else->"إضافة"}
    var name by remember { mutableStateOf(when(type){"production","sale"->"الصندوق الكبير";"purchase","adjust"->"Granulé";else->""}) }
    var secondary by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var shift by remember { mutableStateOf("الصباحية") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest=onDismiss, title={Text(title,fontWeight=FontWeight.Bold,color=Navy)}, text={
        Column(Modifier.fillMaxWidth().heightIn(max=520.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            when(type) {
                "sale" -> {
                    Field("اسم الزبون",secondary,{secondary=it}); ChoiceField("المنتج",name,{name=it},listOf("الصندوق الكبير","الصندوق الصغير"))
                    Field("الكمية بالقطعة",qty,{qty=it},true); Field("سعر الوحدة بالدينار",price,{price=it},true); Field("المبلغ المدفوع بالدينار",paid,{paid=it},true); Field("ملاحظات",note,{note=it})
                    val total=(qty.toDoubleOrNull()?:0.0)*(price.toDoubleOrNull()?:0.0); Text("الإجمالي التقديري: ${moneyDzd(total)}",color=Blue,fontWeight=FontWeight.Bold)
                }
                "production" -> {
                    ChoiceField("نوع الصندوق",name,{name=it},listOf("الصندوق الكبير","الصندوق الصغير")); ChoiceField("الوردية",shift,{shift=it},listOf("الصباحية","المسائية","الليلية"))
                    Field("عدد الصناديق السليمة",qty,{qty=it},true); Field("عدد الصناديق المعيبة",price,{price=it},true); Field("Granulé المستهلك (كغ)",paid,{paid=it},true); Field("Broyé المستهلك (كغ)",extra,{extra=it},true); Field("ملاحظات",note,{note=it})
                }
                "purchase" -> { ChoiceField("المادة الخام",name,{name=it},listOf("Granulé","Broyé")); Field("الكمية المستلمة (كغ)",qty,{qty=it},true); Field("سعر الشراء للدينار/كغ",price,{price=it},true); Field("الحد الأدنى للتنبيه (كغ)",paid,{paid=it},true) }
                "adjust" -> { ChoiceField("المادة الخام",name,{name=it},listOf("Granulé","Broyé")); Field("تغير الرصيد بالكيلوغرام (+ أو -)",qty,{qty=it},true); Field("سبب التسوية",note,{note=it}) }
                "expense" -> { Field("نوع المصروف",name,{name=it}); Field("الوصف",secondary,{secondary=it}); Field("المبلغ بالدينار",qty,{qty=it},true) }
                "note" -> { Field("اسم الزبون",name,{name=it}); Field("المنتج المطلوب",secondary,{secondary=it}); Field("الكمية المطلوبة",qty,{qty=it},true); Field("تاريخ التسليم (YYYY-MM-DD)",price,{price=it}); Field("ملاحظات",note,{note=it}) }
                "customer" -> { Field("اسم الزبون",name,{name=it}); Field("الهاتف",secondary,{secondary=it}); Field("العنوان",qty,{qty=it}); Field("ملاحظات",note,{note=it}) }
                "supplier" -> { Field("اسم المورد",name,{name=it}); Field("الهاتف",secondary,{secondary=it}); Field("المادة التي يوردها",qty,{qty=it}); Field("ملاحظات",note,{note=it}) }
                "machine" -> { Field("اسم/رقم الآلة",name,{name=it}); Field("الحالة",secondary,{secondary=it}); Field("آخر صيانة",qty,{qty=it}); Field("موعد الصيانة القادمة",price,{price=it}); Field("ملاحظات",note,{note=it}) }
                "attendance" -> { Field("اسم العامل",name,{name=it}); ChoiceField("الوردية",shift,{shift=it},listOf("الصباحية","المسائية","الليلية")); ChoiceField("الحالة (عمل/لم يعمل)",secondary,{secondary=it},listOf("عمل","لم يعمل")); Field("ملاحظات",note,{note=it}) }
            }
            error?.let { Text(it,color=MaterialTheme.colorScheme.error,fontSize=12.sp) }
        }
    }, confirmButton={Button(onClick={
        try {
            when(type) {
                "sale" -> db.recordSale(secondary,name,qty.toInt(),price.toDouble(),(paid.toDoubleOrNull()?:0.0),note)
                "production" -> db.recordProduction(name,shift,qty.toInt(),price.toInt(),(paid.toDoubleOrNull()?:0.0),(extra.toDoubleOrNull()?:0.0),note)
                "purchase" -> { db.receiveMaterial(name,qty.toDouble(),price.toDouble(),(paid.toDoubleOrNull()?:0.0)) }
                "adjust" -> db.adjustMaterial(name,qty.toDouble(),note)
                "expense" -> db.addExpense(name,secondary,qty.toDouble())
                "note" -> db.addNote(name,secondary,qty.toInt(),price,note)
                "customer" -> db.addCustomer(name,secondary,qty,note)
                "supplier" -> db.addSupplier(name,secondary,qty,note)
                "machine" -> db.addMachine(name,secondary,qty,price,note)
                "attendance" -> db.addAttendance(shift,name,secondary=="عمل",note)
            }; onSaved(true)
        } catch(e:Exception) { error=e.message ?: "تحقق من القيم المدخلة" }
    }) { Text("حفظ") }}, dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}

@Composable
private fun Field(label:String,value:String,onValue:(String)->Unit,numeric:Boolean=false) {
    OutlinedTextField(value=value,onValueChange=onValue,label={Text(label,fontSize=12.sp)},modifier=Modifier.fillMaxWidth(),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=if(numeric) KeyboardType.Decimal else KeyboardType.Text),shape=RoundedCornerShape(12.dp))
}

@Composable
private fun ChoiceField(label:String,value:String,onValue:(String)->Unit,options:List<String>) {
    var expanded by remember { mutableStateOf(false) }
    Box { OutlinedTextField(value=value,onValueChange={},readOnly=true,label={Text(label,fontSize=12.sp)},modifier=Modifier.fillMaxWidth().clickable { expanded=true },trailingIcon={Icon(Icons.Default.ArrowDropDown,null,Modifier.clickable { expanded=true })},singleLine=true,shape=RoundedCornerShape(12.dp)); DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { options.forEach { option->DropdownMenuItem(text={Text(option)},onClick={onValue(option);expanded=false}) } } }
}

@Composable
private fun DataCard(title:String,subtitle:String,value:String,foot:String="",tint:Color=Blue,icon:ImageVector?=null) {
    Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
            if(icon!=null){Box(Modifier.size(38.dp).background(tint.copy(alpha=0.12f),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(icon,null,tint=tint)};Spacer(Modifier.width(10.dp))}
            Column(Modifier.weight(1f)) { Text(title,color=Navy,fontWeight=FontWeight.Bold,fontSize=13.sp); if(subtitle.isNotBlank()) Text(subtitle,color=Muted,fontSize=10.sp,lineHeight=15.sp); if(foot.isNotBlank()) Text(foot,color=Muted,fontSize=10.sp) }
            Spacer(Modifier.width(6.dp)); Text(value,color=tint,fontWeight=FontWeight.Bold,fontSize=12.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun SimpleRow(icon:ImageVector,title:String,subtitle:String,tint:Color) {
    Row(Modifier.fillMaxWidth().padding(vertical=4.dp).background(Color.White,RoundedCornerShape(14.dp)).padding(12.dp),verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=tint);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(title,color=Ink,fontWeight=FontWeight.Bold,fontSize=12.sp);Text(subtitle,color=Muted,fontSize=10.sp)} }
}

@Composable
private fun EmptyCard(text:String) { Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Info,null,tint=Blue);Spacer(Modifier.width(10.dp));Text(text,color=Muted,fontSize=12.sp,lineHeight=18.sp)}} }

private fun money(centimes:Long):String = moneyDzd(centimes/100.0)
private fun moneyDzd(dzd:Double):String = NumberFormat.getNumberInstance(Locale("fr","DZ")).apply { maximumFractionDigits=2; minimumFractionDigits=0 }.format(dzd)+" دج"
private fun formatNum(n:Double):String = NumberFormat.getNumberInstance(Locale.US).apply { maximumFractionDigits=3 }.format(n)
private fun formatKg(n:Double):String = NumberFormat.getNumberInstance(Locale.US).apply { maximumFractionDigits=3 }.format(n)
