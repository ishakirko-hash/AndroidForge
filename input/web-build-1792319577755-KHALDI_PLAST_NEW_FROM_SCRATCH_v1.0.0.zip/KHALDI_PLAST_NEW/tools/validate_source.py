"""Offline structural smoke checks for the KHALDI PLAST new project."""
from pathlib import Path
import re, sqlite3
ROOT = Path(__file__).resolve().parents[1]
db_source = (ROOT / 'app/src/main/java/dz/khaldiplast/app/FactoryDb.kt').read_text(encoding='utf-8')
ui_source = (ROOT / 'app/src/main/java/dz/khaldiplast/app/MainActivity.kt').read_text(encoding='utf-8')
statements = re.findall(r'db\.execSQL\("((?:[^"\\]|\\.)*)"\)', db_source)
con = sqlite3.connect(':memory:')
for statement in statements:
    con.execute(statement.replace('\\"', '"'))
tables = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
required = {'materials','products','production_runs','sales','expenses','notes','stock_movements','app_settings','customers','suppliers','machines','attendance'}
assert required.issubset(tables), f'Missing tables: {required - tables}'
assert con.execute('SELECT COUNT(*) FROM materials').fetchone()[0] == 2
assert con.execute('SELECT COUNT(*) FROM products').fetchone()[0] == 2
for token in ['recordProduction','recordSale','receiveMaterial','addExpense','addNote','addCustomer','addSupplier','addMachine','addAttendance','totalsFor']:
    assert token in db_source, f'Missing database workflow: {token}'
for token in ['HomeScreen','SalesScreen','InventoryScreen','ProductionScreen','AssistantScreen','ReportsScreen','SettingsScreen','AttendanceScreen','MachinesScreen']:
    assert token in ui_source, f'Missing UI screen: {token}'
assert 'khaldi_plast_official_logo' in ui_source
assert 'kp_mobile_db' not in db_source, 'New app should have its own database, not modify older app database.'
print('PASS: SQLite schema creates successfully.')
print('PASS: Required local data tables exist.')
print('PASS: Initial setup contains two raw materials and two crate products, with zero stock.')
print('PASS: Core screen and workflow source markers exist.')
print('NOTE: This is a source/schema smoke test, not an Android build or device test.')
