# KHALDI PLAST ERP — مشروع Android (Gradle) / Android Gradle project

مشروع Android أصلي جاهز للبناء مباشرةً (لا يحتاج npm ولا Capacitor):
- `settings.gradle` و`build.gradle` و`app/` في **جذر** الملف.
- التطبيق = WebView يحمّل الواجهة من `app/src/main/assets/` + جسر SQLite أصلي (`AndroidBridge.java`) تُحفظ فيه بياناتك على الهاتف.
- التصدير (CSV والنسخ الاحتياطي) يُحفظ في **Download/KhaldiPlastERP**؛ الطباعة/PDF عبر نافذة الطباعة في النظام.

## البناء
```
gradle assembleDebug        # أو ./gradlew assembleDebug إن وُجد المغلّف
```
النتيجة: `app/build/outputs/apk/debug/app-debug.apk`
المتطلبات: JDK 17+، Android SDK (platform 34 + build-tools)، Gradle 8.5 (AGP 8.2.2).

## التثبيت
انقل `app-debug.apk` إلى هاتف Android 10 أو أحدث، وفعّل التثبيت من مصادر غير معروفة. (APK تجريبي debug).

## ملاحظات صادقة
- الشيفرة تُترجم بلا أخطاء مقابل واجهات أندرويد مبسّطة، لكن **لم تُشغَّل على جهاز حقيقي**. إن ظهر خطأ فأرسل سجل البناء.
- لا يوجد تسجيل دخول بعد (يعمل بصلاحية المدير). دليل الحسابات أولي وغير رسمي. النسخة الاحتياطية غير مشفّرة.
