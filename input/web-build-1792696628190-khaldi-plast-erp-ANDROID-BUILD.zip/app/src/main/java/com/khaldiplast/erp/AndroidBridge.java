package com.khaldiplast.erp;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * JavaScript bridge exposed as window.AndroidDB.
 *  - sql(json)            : SQLite access (all calls run on ONE dedicated thread, so transactions keep thread affinity)
 *  - saveFile(...)        : writes a file into Downloads/KhaldiPlastERP
 *  - printHtml(html,title): opens the system print dialog (which can "Save as PDF")
 */
public class AndroidBridge {

    private final Activity activity;
    private final WebViewAssetLoader loader;
    private final SQLiteDatabase db;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private WebView printView;

    public AndroidBridge(Activity activity, WebViewAssetLoader loader) {
        this.activity = activity;
        this.loader = loader;
        File file = activity.getDatabasePath("khaldi_erp.db");
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        this.db = SQLiteDatabase.openOrCreateDatabase(file, null);
        this.db.setForeignKeyConstraintsEnabled(true);
    }

    // ------------------------------------------------------------------ SQL

    @JavascriptInterface
    public String sql(final String json) {
        Future<String> future = executor.submit(new Callable<String>() {
            @Override
            public String call() {
                return handle(json);
            }
        });
        try {
            return future.get();
        } catch (Exception e) {
            return error(String.valueOf(e.getMessage()));
        }
    }

    private String handle(String json) {
        try {
            JSONObject request = new JSONObject(json);
            String op = request.getString("op");
            String statement = request.optString("sql", "");
            JSONArray params = request.optJSONArray("params");

            if (op.equals("ping")) {
                return ok(Boolean.TRUE);
            }
            if (op.equals("exec")) {
                db.execSQL(statement);
                return ok(null);
            }
            if (op.equals("begin")) {
                if (db.inTransaction()) {
                    db.endTransaction();
                }
                db.beginTransactionNonExclusive();
                return ok(null);
            }
            if (op.equals("commit")) {
                db.setTransactionSuccessful();
                db.endTransaction();
                return ok(null);
            }
            if (op.equals("rollback")) {
                if (db.inTransaction()) {
                    db.endTransaction();
                }
                return ok(null);
            }
            if (op.equals("run")) {
                return ok(run(statement, params));
            }
            if (op.equals("all")) {
                return ok(query(statement, params));
            }
            return error("unknown op " + op);
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    private JSONObject run(String statement, JSONArray params) throws JSONException {
        String head = statement.trim().toUpperCase(Locale.ROOT);
        SQLiteStatement st = db.compileStatement(statement);
        try {
            bindAll(st, params);
            if (head.startsWith("INSERT") || head.startsWith("REPLACE")) {
                st.executeInsert();
            } else if (head.startsWith("UPDATE") || head.startsWith("DELETE")) {
                st.executeUpdateDelete();
            } else {
                st.execute();
            }
        } finally {
            st.close();
        }
        JSONObject result = new JSONObject();
        result.put("changes", DatabaseUtils.longForQuery(db, "SELECT changes()", null));
        result.put("lastId", DatabaseUtils.longForQuery(db, "SELECT last_insert_rowid()", null));
        return result;
    }

    private JSONArray query(String statement, final JSONArray params) throws JSONException {
        Cursor cursor = db.rawQueryWithFactory(new SQLiteDatabase.CursorFactory() {
            @Override
            public Cursor newCursor(SQLiteDatabase database, SQLiteCursorDriver driver, String editTable, SQLiteQuery query) {
                try {
                    bindAll(query, params);
                } catch (JSONException e) {
                    throw new IllegalArgumentException(e.getMessage());
                }
                return new SQLiteCursor(driver, editTable, query);
            }
        }, statement, null, null);
        try {
            return rows(cursor);
        } finally {
            cursor.close();
        }
    }

    /** Typed binding: numbers stay numbers (keeps integer affinity), NULL stays NULL, {"$big":"n"} becomes a 64-bit integer. */
    private static void bindAll(SQLiteProgram program, JSONArray params) throws JSONException {
        if (params == null) {
            return;
        }
        for (int i = 0; i < params.length(); i++) {
            Object value = params.get(i);
            int index = i + 1;
            if (value == null || value == JSONObject.NULL) {
                program.bindNull(index);
            } else if (value instanceof Boolean) {
                program.bindLong(index, ((Boolean) value).booleanValue() ? 1L : 0L);
            } else if (value instanceof Integer || value instanceof Long) {
                program.bindLong(index, ((Number) value).longValue());
            } else if (value instanceof Double) {
                double d = ((Double) value).doubleValue();
                if (d == Math.rint(d) && Math.abs(d) < 9.0e15) {
                    program.bindLong(index, (long) d);
                } else {
                    program.bindDouble(index, d);
                }
            } else if (value instanceof JSONObject) {
                program.bindLong(index, Long.parseLong(((JSONObject) value).getString("$big")));
            } else {
                program.bindString(index, String.valueOf(value));
            }
        }
    }

    private static JSONArray rows(Cursor cursor) throws JSONException {
        JSONArray out = new JSONArray();
        String[] names = cursor.getColumnNames();
        while (cursor.moveToNext()) {
            JSONObject row = new JSONObject();
            for (int i = 0; i < names.length; i++) {
                int type = cursor.getType(i);
                if (type == Cursor.FIELD_TYPE_NULL || type == Cursor.FIELD_TYPE_BLOB) {
                    row.put(names[i], JSONObject.NULL);
                } else if (type == Cursor.FIELD_TYPE_INTEGER) {
                    row.put(names[i], cursor.getLong(i));
                } else if (type == Cursor.FIELD_TYPE_FLOAT) {
                    row.put(names[i], cursor.getDouble(i));
                } else {
                    row.put(names[i], cursor.getString(i));
                }
            }
            out.put(row);
        }
        return out;
    }

    private static String ok(Object data) throws JSONException {
        JSONObject response = new JSONObject();
        response.put("ok", true);
        response.put("data", data == null ? JSONObject.NULL : data);
        return response.toString();
    }

    private static String error(String message) {
        try {
            JSONObject response = new JSONObject();
            response.put("ok", false);
            response.put("error", message == null ? "error" : message);
            return response.toString();
        } catch (JSONException e) {
            return "{\"ok\":false,\"error\":\"error\"}";
        }
    }

    // ------------------------------------------------------------------ files

    /** Saves a text file to Downloads/KhaldiPlastERP (MediaStore, no storage permission needed on Android 10+). */
    @JavascriptInterface
    public String saveFile(String filename, String text, String mime) {
        try {
            ContentResolver resolver = activity.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KhaldiPlastERP");
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                return error("Could not create the file");
            }
            OutputStream stream = resolver.openOutputStream(uri);
            if (stream == null) {
                return error("Could not open the file");
            }
            try {
                stream.write(text.getBytes(StandardCharsets.UTF_8));
            } finally {
                stream.close();
            }
            JSONObject response = new JSONObject();
            response.put("ok", true);
            response.put("path", "Download/KhaldiPlastERP/" + filename);
            return response.toString();
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    // ------------------------------------------------------------------ printing

    @JavascriptInterface
    public void printHtml(final String html, final String title) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView view = new WebView(activity);
                printView = view;
                view.setWebViewClient(new WebViewClient() {
                    @Override
                    public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest request) {
                        return loader.shouldInterceptRequest(request.getUrl());
                    }

                    @Override
                    public void onPageFinished(WebView v, String url) {
                        PrintManager manager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                        String job = (title == null || title.length() == 0) ? "KHALDI PLAST" : title;
                        PrintDocumentAdapter adapter = v.createPrintDocumentAdapter(job);
                        PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .build();
                        manager.print(job, adapter, attributes);
                    }
                });
                view.loadDataWithBaseURL("https://appassets.androidplatform.net/assets/index.html", html, "text/html", "UTF-8", null);
            }
        });
    }
}
