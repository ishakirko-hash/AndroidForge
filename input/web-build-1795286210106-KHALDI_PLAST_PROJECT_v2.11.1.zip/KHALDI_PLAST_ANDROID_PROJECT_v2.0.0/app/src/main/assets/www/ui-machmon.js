/* KHALDI PLAST - v2.5: machine production monitor (shift timer, expected vs actual crates, stops timeline) */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, F = U.forms, S = U.S, X = U.extraActions;
  var timer = null;
  S.mm = S.mm || { m: null, shift: 0 };

  function B(n) { return '<bdi class="num" dir="ltr">' + n + '</bdi>'; }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function hms(sec) { sec = Math.max(0, Math.floor(sec)); return p2(Math.floor(sec / 3600)) + ':' + p2(Math.floor(sec % 3600 / 60)) + ':' + p2(sec % 60); }
  function curShift() { var h = new Date().getHours(); return h >= 8 && h < 16 ? 1 : h >= 16 ? 2 : 3; }
  function MON(d) { var s = (d || U.D).settings; return s.mon || { cfg: {}, stops: [], counts: {} }; }
  function ensure(d) { var s = d.settings; s.mon = s.mon || {}; s.mon.cfg = s.mon.cfg || {}; s.mon.stops = s.mon.stops || []; s.mon.counts = s.mon.counts || {}; return s.mon; }
  function cfgOf(id) { var c = MON().cfg[id] || {}; return { operator: c.operator || '', model: c.model || '', cycle: c.cycle > 0 ? c.cycle : 0, productId: c.productId || '', spd: c.spd > 0 ? c.spd : 3 }; }
  function sel() {
    var ms = U.act(U.D.machines);
    if (!ms.length) return null;
    if (!S.mm.m || !ms.some(function (m) { return m.id === S.mm.m; })) S.mm.m = ms[0].id;
    if (!S.mm.shift) S.mm.shift = curShift();
    return { ms: ms, m: ms.filter(function (m) { return m.id === S.mm.m; })[0], n: S.mm.shift };
  }
  function win(n, date) {
    var sh = K.SHIFTS[n - 1], p = String(date || K.today()).split('-'), h = parseInt(sh.start, 10);
    var s = new Date(+p[0], +p[1] - 1, +p[2], h, 0, 0, 0).getTime();
    return { s: s, e: s + sh.hours * 3600000, sh: sh };
  }
  // overlap of every stop of the machine with [s, upto], split by kind (seconds) + segments
  function calc(mid, n, now) {
    var w = win(n), upto = Math.min(Math.max(now, w.s), w.e), el = (upto - w.s) / 1000, j = 0, u = 0, segs = [], open = null;
    MON().stops.forEach(function (x) {
      if (x.m !== mid) return;
      var a = Math.max(x.from, w.s), b = Math.min(x.to == null ? now : x.to, upto);
      if (x.to == null) open = x;
      if (b <= a) return;
      var d = (b - a) / 1000; if (x.kind === 'j') j += d; else u += d;
      segs.push({ a: a, b: b, k: x.kind });
    });
    return { w: w, el: el, j: j, u: u, segs: segs, open: open, upto: upto };
  }
  function figures(mid, n, now) {
    var c = calc(mid, n, now), cf = cfgOf(mid), key = mid + '|' + K.today() + '|' + n, cnt = MON().counts[key];
    var actual = cnt ? cnt.n : 0, shiftSec = c.w.sh.hours * 3600;
    var exp = cf.cycle ? Math.max(0, Math.floor((c.el - c.j) / cf.cycle)) : 0;
    var tgt = cf.cycle ? Math.floor(shiftSec / cf.cycle) : 0;
    var day = 0; K.SHIFTS.forEach(function (s) { var q = MON().counts[mid + '|' + K.today() + '|' + s.n]; if (q) day += q.n; });
    return { c: c, cf: cf, actual: actual, exp: exp, gap: actual - exp, pct: exp > 0 ? Math.round(actual * 1000 / exp) / 10 : null, tgt: tgt, dtgt: tgt * cf.spd, day: day, run: Math.max(0, c.el - c.j - c.u) };
  }
  function operators(mid, n) {
    var r = K.rosterFor(U.D, K.today(), n).filter(function (a) { return a.worked && a.machineId === mid; });
    return r.map(function (a) { var w = U.D.workers.filter(function (x) { return x.id === a.workerId; })[0]; return w ? w.name : ''; }).filter(Boolean).join('، ');
  }
  function clock(ms) { var d = new Date(ms); return p2(d.getHours()) + ':' + p2(d.getMinutes()); }
  function tlHtml(f, now) {
    var w = f.c.w, len = w.e - w.s, up = f.c.upto, h = '';
    h += '<i class="g" style="left:0;width:' + ((up - w.s) * 100 / len) + '%"></i>';
    f.c.segs.forEach(function (s) { h += '<i class="' + (s.k === 'j' ? 'y' : 'r') + '" style="left:' + ((s.a - w.s) * 100 / len) + '%;width:' + Math.max(0.4, (s.b - s.a) * 100 / len) + '%"></i>'; });
    return h;
  }

  function ico(n, c) { return '<span class="mm-ic ' + (c || '') + '">' + V.icon(n, 20) + '</span>'; }
  function lastTs(mid, n) { var q = MON().counts[mid + '|' + K.today() + '|' + n]; return q && q.ts ? q.ts : 0; }
  function anaHtml(f, now, q) {
    var c = f.c, cf = f.cf, run = f.run, el = c.el, av = el > 0 ? Math.round(run * 1000 / el) / 10 : null;
    var rate = run > 0 ? Math.round(f.actual * 3600 / run) : null, rrate = cf.cycle ? Math.round(3600 / cf.cycle) : null;
    var eff = f.actual > 0 && run > 0 ? Math.round(run * 10 / f.actual) / 10 : null;
    var rem = Math.max(0, (c.w.e - Math.max(now, c.w.s)) / 1000), over = now >= c.w.e;
    var fc = cf.cycle ? f.actual + (over ? 0 : Math.floor(rem / cf.cycle)) : 0;
    var left = Math.max(0, f.tgt - f.actual), ns = 0, longest = 0;
    c.segs.forEach(function (x) { ns++; longest = Math.max(longest, (x.b - x.a) / 60000); });
    var lt = lastTs(q.m.id, q.n);
    function cell(cls, l, v) { return '<div class="mm-an ' + cls + '"><small>' + l + '</small><b>' + v + '</b></div>'; }
    return cell('b', t('mm_avail'), B(av == null ? '—' : av + '%')) + cell('g', t('mm_rate'), (rate == null ? B('—') : B(rate) + ' <em>/ ' + t('mm_h') + '</em>')) +
      cell('', t('mm_rate_ref'), (rrate == null ? B('—') : B(rrate) + ' <em>/ ' + t('mm_h') + '</em>')) + cell('', t('mm_real_cycle'), (eff == null ? B('—') : B(eff) + ' <em>' + t('mm_sec') + '</em>')) +
      cell('b', t('mm_forecast'), B(cf.cycle ? K.groupInt(fc) : '—')) + cell('o', t('mm_left_tgt'), B(cf.cycle ? K.groupInt(left) : '—')) +
      cell('', t('mm_remain'), B(hms(rem))) + cell('r', t('mm_stops_n'), B(ns) + (longest ? ' · ' + B(Math.round(longest)) + ' <em>' + t('mm_min_s') + '</em>' : '')) +
      cell('', t('mm_last_upd'), B(lt ? clock(lt) : '—')) + cell('', t('mm_day_pct'), B(f.dtgt ? Math.round(f.day * 100 / f.dtgt) + '%' : '—'));
  }

  W.machmon = function () {
    var q = sel();
    if (!q) return '<div class="card" style="text-align:center"><div class="muted" style="margin-bottom:10px">' + t('mm_no_machine') + '</div><button class="btn primary" data-act="new_machine">+ ' + t('mm_add_machine') + '</button></div>';
    var now = Date.now(), f = figures(q.m.id, q.n, now), cf = f.cf, w = f.c.w, h = '';
    var live = q.n === curShift(), future = now < w.s;
    // carousel (4 per view)
    h += '<div class="mm-car"><button class="mm-ar" data-act="mm_nav" data-id="-1" aria-label="prev">' + V.icon('chevR', 18) + '</button><div class="mm-row" id="mm_row">';
    q.ms.forEach(function (m) {
      var st = MON().stops.some(function (x) { return x.m === m.id && x.to == null; }), on = m.id === q.m.id;
      h += '<button class="mm-it' + (on ? ' on' : '') + '" data-act="mm_pick" data-id="' + m.id + '"><img src="img/machine_line.jpg" alt=""><span class="mm-nm"><b>' + esc(m.name) + '</b>' + (on ? '<span class="mm-ck">✓</span>' : '<span class="mm-dot ' + (st ? 'r' : 'g') + '"></span>') + '</span></button>';
    });
    h += '</div><button class="mm-ar" data-act="mm_nav" data-id="1" aria-label="next">' + V.icon('chevL', 18) + '</button></div>';
    // header card
    var pill = f.c.open ? '<span class="mm-pill r"><i></i>' + t(f.c.open.kind === 'j' ? 'mm_st_just' : 'mm_st_unj') + '</span>' : (live ? '<span class="mm-pill g"><i></i>' + t('mm_running') + '</span>' : '<span class="mm-pill n"><i></i>' + t(future ? 'mm_future' : 'mm_ended') + '</span>');
    h += '<div class="card mm-head"><div class="mm-hi"><div class="mm-hr"><div><b>' + esc(q.m.name) + '</b><span>' + (cf.model ? esc(cf.model) : t('mm_no_model')) + '</span></div><button class="mm-gear" data-act="mm_cfg" aria-label="settings">' + V.icon('settings', 22) + '</button></div>' + pill + '</div><img class="mm-photo" src="img/machine_line.jpg" alt=""></div>';
    // chips: shift | product | operator
    var op = operators(q.m.id, q.n) || cf.operator, pr = cf.productId ? U.D.products.filter(function (p) { return p.id === cf.productId; })[0] : null;
    h += '<div class="mm-chips"><div class="mm-chip">' + ico('calendar') + '<div><small>' + t('mm_cur_shift') + '</small><select id="mm_sh">' + K.SHIFTS.map(function (s) { return '<option value="' + s.n + '"' + (s.n === q.n ? ' selected' : '') + '>' + t('shift') + ' ' + s.n + '</option>'; }).join('') + '</select></div></div>' +
      '<div class="mm-chip">' + ico('box') + '<div><small>' + t('product') + '</small><b>' + (pr ? esc(pr.name) : '—') + '</b></div></div>' +
      '<div class="mm-chip">' + ico('users') + '<div><small>' + t('mm_operator') + '</small><b>' + (op ? esc(op) : '—') + '</b></div></div></div>';
    // shift times: end | start | length
    h += '<div class="mm-times"><div>' + ico('calendar') + '<span><small>' + t('mm_end') + '</small><b>' + B(w.sh.end) + '</b></span></div><div>' + ico('calendar') + '<span><small>' + t('mm_start') + '</small><b>' + B(w.sh.start) + '</b></span></div><div>' + ico('clock') + '<span><small>' + t('mm_shift_len') + '</small><b>' + B(p2(w.sh.hours) + ':00') + '</b></span></div></div>';
    // elapsed (right) + cycle (left)
    var pbtn = f.c.open ? '<button class="mm-pb play" data-act="mm_resume" aria-label="resume">▶</button>' : (live ? '<button class="mm-pb" data-act="mm_stop" aria-label="stop">❚❚</button>' : '');
    h += '<div class="mm-two"><div class="mm-el"><div class="mm-elh">' + ico('clock', 'w') + '<small>' + t('mm_elapsed') + '</small></div><div class="mm-elb">' + pbtn + '<b id="mm_t">' + hms(f.c.el) + '</b></div></div>' +
      '<div class="card mm-cyc">' + ico('box') + '<small>' + t('mm_cycle') + '</small><div class="mm-cb"><button class="mm-edit" data-act="mm_cycle" aria-label="edit">' + V.icon('edit', 18) + '</button>' + (cf.cycle ? '<div><b>' + B(cf.cycle) + ' <em>' + t('mm_sec') + '</em></b><small>(' + B(Math.round(cf.cycle / 60 * 1000) / 1000) + ' ' + t('mm_min') + ')</small></div>' : '<b>' + t('mm_set_cycle') + '</b>') + '</div></div></div>';
    if (!cf.cycle) h += '<div class="card mm-warn">' + t('mm_need_cycle') + '</div>';
    // production: expected (right) | actual (left)
    h += '<div class="mm-prod"><div class="mm-pc b">' + ico('box', 'b') + '<small>' + t('mm_expected') + '</small><div class="mm-pv"><div class="mm-ci">' + V.crate('blue', 72) + '</div><div><b id="mm_exp">' + B(K.groupInt(f.exp)) + '</b><em>' + t('mm_crate') + '</em></div></div></div>' +
      '<div class="mm-pc g">' + ico('box', 'g') + '<small>' + t('mm_actual') + '</small><div class="mm-pv"><div class="mm-ci">' + V.crate('green', 72) + '</div><div><b id="mm_act">' + B(K.groupInt(f.actual)) + '</b><em>' + t('mm_crate') + '</em></div></div>' +
      '<div class="mm-qa"><button data-act="mm_add" data-id="1">+1</button><button data-act="mm_add" data-id="10">+10</button><button data-act="mm_add" data-id="100">+100</button><button class="u" data-act="mm_count">' + t('mm_update') + '</button></div></div></div>';
    // pct (right wide) + gap (left)
    h += '<div class="mm-pg"><div class="card mm-pct">' + ico('box', 'b') + '<small class="mm-pt">' + t('mm_pct') + '</small><div class="mm-pbar big"><i id="mm_pbar" style="width:' + Math.min(100, f.pct || 0) + '%"></i><span id="mm_pct">' + (f.pct == null ? '—' : f.pct + '%') + '</span></div></div>' +
      '<div class="mm-pc ' + (f.gap < 0 ? 'r' : 'g') + ' mm-gp" id="mm_gapc"><small>' + t('mm_gap') + '</small><b id="mm_gap">' + B(f.gap > 0 ? '+' + f.gap : f.gap) + '</b><em>' + t('mm_crate') + '</em></div></div>';
    // targets
    h += '<div class="card mm-tg"><div><small>' + t('mm_shift_tgt') + '</small><b id="mm_stg">' + B(K.groupInt(f.tgt)) + '</b></div><div><small>' + t('mm_day_tgt') + ' (' + cf.spd + ' ' + t('mm_shifts_short') + ')</small><b id="mm_dtg">' + B(K.groupInt(f.dtgt)) + '</b></div>' +
      '<div><small>' + t('mm_day_done') + '</small><b>' + B(K.groupInt(f.day)) + '</b></div><div class="mm-pbar wide"><i style="width:' + (f.dtgt ? Math.min(100, f.day * 100 / f.dtgt) : 0) + '%"></i></div></div>';
    // timeline + stat boxes (run | justified | unjustified)
    var lab = ''; for (var i = 0; i <= w.sh.hours; i++) lab += '<span>' + p2((parseInt(w.sh.start, 10) + i) % 24) + ':00</span>';
    h += '<div class="card mm-tl"><div class="mm-th"><b>' + t('mm_timeline') + '</b>' + ico('machine', 'b') + '</div>' +
      '<div class="mm-bar" dir="ltr"><div id="mm_tl">' + tlHtml(f, now) + '</div></div><div class="mm-lab" dir="ltr">' + lab + '</div>' +
      '<div class="mm-stats"><div class="g"><span>▶</span><small>' + t('mm_run_h') + '</small><b id="mm_rb">' + B(hm(f.run)) + '</b></div><div class="y"><span>🔧</span><small>' + t('mm_just_min') + '</small><b id="mm_jb">' + B(p2(Math.round(f.c.j / 60))) + ' <em>' + t('mm_min') + '</em></b></div><div class="r"><span>■</span><small>' + t('mm_unj_min') + '</small><b id="mm_ub">' + B(p2(Math.round(f.c.u / 60))) + ' <em>' + t('mm_min') + '</em></b></div></div></div>';
    // analysis
    h += '<div class="card"><div class="mm-th"><b>' + t('mm_ana') + '</b>' + ico('bars', 'b') + '</div><div class="mm-ang" id="mm_ana">' + anaHtml(f, now, q) + '</div></div>';
    // stop log
    var lg = MON().stops.filter(function (x) { return x.m === q.m.id && x.from < w.e && (x.to == null || x.to > w.s); }).sort(function (a, b) { return b.from - a.from; });
    h += '<div class="card"><div class="mm-th"><b>' + t('mm_log') + '</b></div>';
    if (!lg.length) h += '<div class="muted" style="text-align:center;padding:8px 0">' + t('mm_no_stops') + '</div>';
    lg.forEach(function (x) {
      var d = ((x.to == null ? now : x.to) - x.from) / 1000;
      h += '<div class="mm-lr"><i class="' + (x.kind === 'j' ? 'y' : 'r') + '"></i><div><b>' + t(x.kind === 'j' ? 'mm_lg_just' : 'mm_lg_unj') + (x.reason ? ' · ' + esc(x.reason) : '') + '</b><small>' + B(clock(x.from) + ' → ' + (x.to == null ? t('mm_open') : clock(x.to))) + ' · ' + B(Math.round(d / 60) + ' ' + t('mm_min')) + '</small></div><button class="mm-x" data-act="mm_delstop" data-id="' + x.id + '" aria-label="delete">✕</button></div>';
    });
    h += '</div><div class="muted" style="font-size:12px;margin:6px 4px">' + t('mm_note') + '</div>';
    setTimeout(startTimer, 0);
    return h;
  };
  function hm(sec) { sec = Math.max(0, Math.floor(sec)); return p2(Math.floor(sec / 3600)) + ':' + p2(Math.floor(sec % 3600 / 60)); }

  function startTimer() {
    if (timer) clearInterval(timer);
    timer = setInterval(function () {
      if (U.route !== 'machmon' || !document.getElementById('mm_t')) { clearInterval(timer); timer = null; return; }
      var q = sel(); if (!q) return;
      var f = figures(q.m.id, q.n, Date.now()), set = function (id, v) { var e = document.getElementById(id); if (e) e.innerHTML = v; };
      set('mm_t', hms(f.c.el)); set('mm_exp', B(K.groupInt(f.exp))); set('mm_gap', B(f.gap > 0 ? '+' + f.gap : f.gap));
      set('mm_pct', f.pct == null ? '—' : f.pct + '%'); set('mm_ub', B(p2(Math.round(f.c.u / 60))) + ' <em>' + t('mm_min') + '</em>'); set('mm_jb', B(p2(Math.round(f.c.j / 60))) + ' <em>' + t('mm_min') + '</em>'); set('mm_rb', B(hm(f.run))); set('mm_ana', anaHtml(f, Date.now(), q));
      set('mm_tl', tlHtml(f, Date.now()));
      var g = document.getElementById('mm_gapc'); if (g) g.className = 'mm-pc ' + (f.gap < 0 ? 'r' : 'g');
      var pb = document.getElementById('mm_pbar'); if (pb) pb.style.width = Math.min(100, f.pct || 0) + '%';
    }, 1000);
  }

  document.addEventListener('change', function (e) {
    if (e.target && e.target.id === 'mm_sh') { S.mm.shift = parseInt(e.target.value, 10) || 1; U.render(true); }
  });

  X.mm_pick = function (el) { S.mm.m = el.dataset.id; U.render(true); };
  X.mm_nav = function (el) {
    var q = sel(); if (!q) return; var i = q.ms.indexOf(q.m) + parseInt(el.dataset.id, 10);
    i = (i + q.ms.length) % q.ms.length; S.mm.m = q.ms[i].id; U.render(true);
  };
  function saveCfg(mid, patch) {
    U.commit(function (d) { var m = ensure(d); m.cfg[mid] = Object.assign(m.cfg[mid] || {}, patch); });
    U.closeModal(); U.render(true); U.toast(t('saved_ok'), 'ok');
  }
  function num(v) { var n = parseFloat(String(v).replace(',', '.').replace(/[^\d.]/g, '')); return isFinite(n) ? n : 0; }
  X.mm_cfg = function () {
    var q = sel(); if (!q) return; var cf = cfgOf(q.m.id);
    U.openForm({
      title: t('mm_cfg_title') + ' · ' + q.m.name, intro: '', submit: t('save'),
      fields: [
        { name: 'model', label: t('mm_model'), type: 'text', value: cf.model, optional: true },
        { name: 'operator', label: t('mm_operator'), type: 'text', value: cf.operator, optional: true },
        { name: 'cycle', label: t('mm_cycle') + ' (' + t('mm_sec') + ')', type: 'text', value: cf.cycle || '', ph: '32' },
        { name: 'product', label: t('product'), type: 'select', value: cf.productId, options: [{ v: '', l: '—' }].concat(U.act(U.D.products, cf.productId).map(function (p) { return { v: p.id, l: p.name }; })) },
        { name: 'spd', label: t('mm_spd'), type: 'text', value: cf.spd, ph: '3' }
      ],
      onSubmit: function (v) {
        var c = num(v.cycle); if (v.cycle !== '' && c <= 0) throw new Error(t('mm_bad_cycle'));
        saveCfg(q.m.id, { operator: v.operator.trim(), model: v.model.trim(), cycle: c, productId: v.product, spd: Math.min(3, Math.max(1, Math.round(num(v.spd)) || 3)) });
      }
    });
  };
  X.mm_cycle = function () {
    var q = sel(); if (!q) return; var cf = cfgOf(q.m.id);
    U.openForm({
      title: t('mm_cycle'), intro: t('mm_cycle_help'), submit: t('save'),
      fields: [{ name: 'cycle', label: t('mm_sec'), type: 'text', value: cf.cycle || '', ph: '32' }],
      onSubmit: function (v) { var c = num(v.cycle); if (c <= 0) throw new Error(t('mm_bad_cycle')); saveCfg(q.m.id, { cycle: c }); }
    });
  };
  X.mm_count = function () {
    var q = sel(); if (!q) return; var f = figures(q.m.id, q.n, Date.now());
    U.openForm({
      title: t('mm_actual'), intro: t('mm_count_help') + ' (' + t('shift') + ' ' + q.n + ')', submit: t('save'),
      fields: [{ name: 'n', label: t('mm_actual'), type: 'text', value: f.actual, ph: '0' }],
      onSubmit: function (v) {
        var n = Math.round(num(v.n)); if (v.n === '' || n < 0) throw new Error(t('mm_bad_count'));
        var key = q.m.id + '|' + K.today() + '|' + q.n;
        U.commit(function (d) { ensure(d).counts[key] = { n: n, ts: Date.now() }; });
        U.closeModal(); U.render(true); U.toast(t('saved_ok'), 'ok');
      }
    });
  };
  X.mm_stop = function () {
    U.showModal('<form onsubmit="return false"><h3>' + t('mm_stop_title') + '</h3><div class="muted" style="margin-bottom:8px">' + t('mm_stop_help') + '</div>' +
      '<div class="mm-rch">' + ['maint','setup','mold','mat','fault','break'].map(function (k) { return '<button type="button" data-act="mm_reason" data-id="' + k + '">' + t('mm_r_' + k) + '</button>'; }).join('') + '</div><label for="mm_rs">' + t('mm_reason') + ' <span class="muted">(' + t('optional') + ')</span></label><input id="mm_rs" autocomplete="off">' +
      '<div class="btns" style="margin-top:12px"><button type="button" class="btn soft-danger" data-act="mm_stop_do" data-id="u">' + t('mm_lg_unj') + '</button><button type="button" class="btn primary" data-act="mm_stop_do" data-id="j">' + t('mm_lg_just') + '</button></div>' +
      '<div class="btns"><button type="button" class="btn ghost" data-act="close">' + t('cancel') + '</button></div></form>');
  };
  X.mm_reason = function (el) { var i = document.getElementById('mm_rs'); if (i) i.value = el.textContent; };
  X.mm_add = function (el) {
    var q = sel(); if (!q) return; var n = parseInt(el.dataset.id, 10) || 0, key = q.m.id + '|' + K.today() + '|' + q.n;
    U.commit(function (d) { var m = ensure(d), c = m.counts[key] || { n: 0 }; m.counts[key] = { n: c.n + n, ts: Date.now() }; });
    U.render(true);
  };
  X.mm_stop_do = function (el) {
    var q = sel(); if (!q) return; var r = (document.getElementById('mm_rs') || {}).value || '', k = el.dataset.id === 'j' ? 'j' : 'u';
    U.commit(function (d) { var m = ensure(d); if (m.stops.some(function (x) { return x.m === q.m.id && x.to == null; })) return; m.stops.push({ id: K.uid('st'), m: q.m.id, from: Date.now(), to: null, kind: k, reason: r.trim().slice(0, 60) }); });
    U.closeModal(); U.render(true);
  };
  X.mm_resume = function () {
    var q = sel(); if (!q) return;
    U.commit(function (d) { ensure(d).stops.forEach(function (x) { if (x.m === q.m.id && x.to == null) x.to = Date.now(); }); });
    U.render(true); U.toast(t('mm_resumed'), 'ok');
  };
  X.mm_delstop = function (el) {
    var id = el.dataset.id;
    U.commit(function (d) { var m = ensure(d); m.stops = m.stops.filter(function (x) { return x.id !== id; }); });
    U.render(true);
  };
  U._mm = { figures: figures, curShift: curShift, MON: MON };
})();
