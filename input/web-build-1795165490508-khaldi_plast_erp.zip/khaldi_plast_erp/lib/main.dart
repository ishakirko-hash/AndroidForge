import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/app_state.dart';
import 'core/i18n.dart';
import 'core/theme.dart';
import 'data/db.dart';
import 'features/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Db.open();
    await AppState.i.load();
    runApp(const KhaldiApp());
  } catch (e) {
    runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('تعذر فتح قاعدة البيانات\n$e', textAlign: TextAlign.center, style: const TextStyle(color: C.error)),
          ),
        ),
      ),
    ));
  }
}

class KhaldiApp extends StatelessWidget {
  const KhaldiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.i,
      builder: (context, _) {
        S.ar = AppState.i.ar;
        return MaterialApp(
          key: ValueKey<bool>(S.ar),
          title: 'KHALDI PLAST ERP',
          debugShowCheckedModeBanner: false,
          theme: buildTheme(),
          locale: Locale(S.ar ? 'ar' : 'en'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: const Shell(),
        );
      },
    );
  }
}
