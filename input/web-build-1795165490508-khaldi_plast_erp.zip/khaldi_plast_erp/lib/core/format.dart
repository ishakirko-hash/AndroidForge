import 'package:intl/intl.dart';
import 'i18n.dart';

typedef Rec = Map<String, Object?>;

double dbl(Object? v) {
  if (v is num) return v.toDouble();
  if (v is String) return parseNum(v) ?? 0;
  return 0;
}

int intv(Object? v) {
  if (v is num) return v.toInt();
  if (v is String) return int.tryParse(v) ?? 0;
  return 0;
}

String str(Object? v) => v == null ? '' : v.toString();

double r2(double v) => (v * 100).roundToDouble() / 100;

double? parseNum(String s) {
  final t = s.trim();
  if (t.isEmpty) return null;
  const ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in t.split('')) {
    final i = ar.indexOf(ch);
    if (i >= 0) {
      b.write(i);
    } else if (ch == '٫' || ch == ',') {
      b.write('.');
    } else if (ch == '٬' || ch == ' ') {
      // skip separators
    } else {
      b.write(ch);
    }
  }
  return double.tryParse(b.toString());
}

final NumberFormat _f0 = NumberFormat('#,##0', 'en_US');
final NumberFormat _f2 = NumberFormat('#,##0.##', 'en_US');

String fmt(num v) => _f0.format(v);
String fmt2(num v) => _f2.format(v);
String money(num v) => '${fmt(v)} ${t('دج')}';

String compact(double v) {
  final a = v.abs();
  if (a >= 1000000) {
    final x = v / 1000000;
    return '${x == x.roundToDouble() ? x.toStringAsFixed(0) : x.toStringAsFixed(1)}M';
  }
  if (a >= 1000) {
    final x = v / 1000;
    return '${x == x.roundToDouble() ? x.toStringAsFixed(0) : x.toStringAsFixed(1)}K';
  }
  return v.toStringAsFixed(0);
}

String two(int n) => n < 10 ? '0$n' : '$n';
String ymd(DateTime d) => '${d.year}-${two(d.month)}-${two(d.day)}';
String today() => ymd(DateTime.now());
String hm(DateTime d) => '${two(d.hour)}:${two(d.minute)}';

DateTime? parseYmd(String? s) {
  if (s == null || s.length < 10) return null;
  return DateTime.tryParse(s.substring(0, 10));
}

String showDate(String? s) {
  final d = parseYmd(s);
  if (d == null) return '';
  return '${two(d.day)}/${two(d.month)}/${d.year}';
}

const _wdAr = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
const _wdEn = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const _mAr = ['جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان', 'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const _mEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

String weekdayName(DateTime d) => S.ar ? _wdAr[d.weekday - 1] : _wdEn[d.weekday - 1];
String monthName(int m) => S.ar ? _mAr[m - 1] : _mEn[m - 1];
String fullDate(DateTime d) =>
    '${weekdayName(d)}${S.ar ? '،' : ','} ${d.day} ${monthName(d.month)} ${d.year}';

/// Period helper: returns [from, to] as yyyy-MM-dd
List<String> periodRange(String key) {
  final now = DateTime.now();
  final d0 = DateTime(now.year, now.month, now.day);
  switch (key) {
    case 'week':
      final since = (d0.weekday - 6 + 7) % 7; // week starts Saturday
      return [ymd(d0.subtract(Duration(days: since))), ymd(d0)];
    case 'month':
      return [ymd(DateTime(d0.year, d0.month, 1)), ymd(d0)];
    case 'year':
      return [ymd(DateTime(d0.year, 1, 1)), ymd(d0)];
    default:
      return [ymd(d0), ymd(d0)];
  }
}
