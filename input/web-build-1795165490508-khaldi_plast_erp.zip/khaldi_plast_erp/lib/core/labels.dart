import 'package:flutter/material.dart';
import 'theme.dart';
import 'i18n.dart';

class StatusInfo {
  final String label;
  final Color color;
  const StatusInfo(this.label, this.color);
}

const methodLabels = <String, String>{
  'cash': 'نقدًا',
  'transfer': 'تحويل بنكي',
  'check': 'شيك',
  'credit': 'آجل',
  'other': 'أخرى',
};

String methodLabel(String? m) => t(methodLabels[m] ?? (m == null || m.isEmpty ? 'غير محدد' : m));

const shiftLabels = <String, String>{
  'morning': 'الصباحية',
  'afternoon': 'المسائية',
  'night': 'الليلية',
};

String shiftLabel(String? k) => t(shiftLabels[k] ?? '-');

const shiftTimes = <String, List<String>>{
  'morning': ['06:00', '14:00'],
  'afternoon': ['14:00', '22:00'],
  'night': ['22:00', '06:00'],
};

String currentShiftKind() {
  final h = DateTime.now().hour;
  if (h >= 6 && h < 14) return 'morning';
  if (h >= 14 && h < 22) return 'afternoon';
  return 'night';
}

const unitLabels = <String, String>{'kg': 'كغ', 'g': 'غ', 'pcs': 'قطعة', 'l': 'لتر'};
String unitLabel(String? u) => t(unitLabels[u] ?? (u ?? ''));

StatusInfo invoiceStatus(String? s) {
  switch (s) {
    case 'paid':
      return StatusInfo(t('مدفوعة'), C.success);
    case 'partial':
      return StatusInfo(t('جزئية'), C.warning);
    case 'cancelled':
      return StatusInfo(t('ملغاة'), C.text2);
    default:
      return StatusInfo(t('غير مدفوعة'), C.error);
  }
}

StatusInfo machineStatus(String? s) {
  switch (s) {
    case 'stopped':
      return StatusInfo(t('متوقفة'), C.error);
    case 'maintenance':
      return StatusInfo(t('صيانة'), C.warning);
    default:
      return StatusInfo(t('تعمل'), C.success);
  }
}

const orderStatusLabels = <String, String>{
  'new': 'جديد',
  'scheduled': 'مجدول',
  'in_production': 'قيد الإنتاج',
  'ready': 'جاهز',
  'delivered': 'تم التسليم',
  'cancelled': 'ملغى',
};

StatusInfo orderStatus(String? s) {
  final label = t(orderStatusLabels[s] ?? 'جديد');
  switch (s) {
    case 'delivered':
      return StatusInfo(label, C.success);
    case 'ready':
      return StatusInfo(label, C.success);
    case 'in_production':
      return StatusInfo(label, C.primary);
    case 'scheduled':
      return StatusInfo(label, C.purple);
    case 'cancelled':
      return StatusInfo(label, C.text2);
    default:
      return StatusInfo(label, C.warning);
  }
}

StatusInfo productionStatus(String? s) {
  if (s == 'cancelled') return StatusInfo(t('ملغاة'), C.text2);
  return StatusInfo(t('مكتملة'), C.success);
}

const kindLabels = <String, String>{
  'expense': 'مصروف',
  'income': 'إيراد',
  'purchase': 'مشتريات',
  'payment': 'دفعة',
  'debt': 'دين',
};

const movementLabels = <String, String>{
  'product_receipt': 'استلام منتجات',
  'material_receipt': 'استلام مواد',
  'production_in': 'دخول إنتاج',
  'material_use': 'استهلاك إنتاج',
  'sale_out': 'صرف مبيعات',
  'product_withdraw': 'صرف منتجات',
  'material_withdraw': 'صرف مواد',
  'adjust': 'تسوية يدوية',
  'return': 'إرجاع',
  'reversal': 'عكس عملية',
};

String movementLabel(String? k) => t(movementLabels[k] ?? (k ?? ''));

const expenseCategories = <String>[
  'كهرباء', 'ماء', 'أجور', 'نقل', 'صيانة', 'وقود', 'إيجار', 'مواد', 'أخرى',
];
