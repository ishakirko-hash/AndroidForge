import 'en_strings.dart';

/// Language holder. Arabic strings are used as keys; English comes from [enStrings].
class S {
  static bool ar = true;
}

String t(String k) {
  if (S.ar) return k;
  return enStrings[k] ?? k;
}
