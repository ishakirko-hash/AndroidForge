import 'package:flutter/material.dart';
import '../data/db.dart';
import 'format.dart';
import 'i18n.dart';
import 'theme.dart';

Future<T?> go<T>(BuildContext context, Widget page) =>
    Navigator.of(context).push<T>(MaterialPageRoute<T>(builder: (_) => page));

void toast(BuildContext context, String msg, {bool error = false}) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Text(t(msg)),
    backgroundColor: error ? C.error : C.success,
    behavior: SnackBarBehavior.floating,
  ));
}

Future<bool> confirm(BuildContext ctx, String msg, {String title = 'تأكيد', String yes = 'نعم', bool danger = true}) async {
  final r = await showDialog<bool>(
    context: ctx,
    builder: (c) => AlertDialog(
      title: Text(t(title)),
      content: Text(t(msg)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(t('إلغاء'))),
        TextButton(
          onPressed: () => Navigator.pop(c, true),
          child: Text(t(yes), style: TextStyle(color: danger ? C.error : C.primary, fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );
  return r == true;
}

// ------------------------------------------------------------------ scaffolds
class PageScaffold extends StatelessWidget {
  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? fab;
  final PreferredSizeWidget? bottom;
  final bool logo;
  const PageScaffold({super.key, required this.title, required this.body, this.actions, this.fab, this.bottom, this.logo = false});

  @override
  Widget build(BuildContext context) {
    final acts = <Widget>[...?actions];
    if (logo) {
      acts.add(Padding(
        padding: const EdgeInsetsDirectional.only(end: 10, start: 4),
        child: Image.asset('assets/images/logo_white.png', height: 26),
      ));
    }
    return Scaffold(
      appBar: AppBar(title: Text(t(title)), actions: acts, bottom: bottom),
      body: SafeArea(top: false, child: body),
      floatingActionButton: fab,
    );
  }
}

// ------------------------------------------------------------------ cards
class Panel extends StatelessWidget {
  final String? title;
  final IconData? icon;
  final Color? iconColor;
  final Widget? trailing;
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const Panel({
    super.key,
    this.title,
    this.icon,
    this.iconColor,
    this.trailing,
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final content = Padding(
      padding: padding,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (title != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(children: [
                if (icon != null) ...[
                  Icon(icon, size: 20, color: iconColor ?? C.primary),
                  const SizedBox(width: 8),
                ],
                Expanded(
                  child: Text(t(title!), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: C.text)),
                ),
                if (trailing != null) trailing!,
              ]),
            ),
          child,
        ],
      ),
    );
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: C.border),
      ),
      child: onTap == null
          ? content
          : Material(
              color: Colors.transparent,
              child: InkWell(borderRadius: BorderRadius.circular(8), onTap: onTap, child: content),
            ),
    );
  }
}

class KpiTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String value;
  final String? unit;
  final double? trend;
  final bool upIsGood;
  final VoidCallback? onTap;
  const KpiTile({
    super.key,
    required this.icon,
    required this.color,
    required this.title,
    required this.value,
    this.unit,
    this.trend,
    this.upIsGood = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget? trendW;
    if (trend != null) {
      final up = trend! >= 0;
      final good = up == upIsGood;
      final c = good ? C.success : C.error;
      trendW = Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(up ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded, size: 14, color: c),
        Text('${up ? '+' : ''}${trend!.toStringAsFixed(0)}%',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: c)),
      ]);
    }
    final inner = Padding(
      padding: const EdgeInsets.all(10),
      child: Row(children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(color: tint(color, 0.14), borderRadius: BorderRadius.circular(8)),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(t(title), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, color: C.text2, fontWeight: FontWeight.w600)),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: AlignmentDirectional.centerStart,
              child: Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: C.text)),
            ),
            Row(children: [
              if (unit != null) Flexible(child: Text(t(unit!), style: const TextStyle(fontSize: 12, color: C.text2), overflow: TextOverflow.ellipsis)),
              if (unit != null && trendW != null) const SizedBox(width: 6),
              if (trendW != null) trendW,
            ]),
          ]),
        ),
      ]),
    );
    return Container(
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
      child: onTap == null
          ? inner
          : Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(8), onTap: onTap, child: inner)),
    );
  }
}

Widget kpiRow(Widget a, Widget b) => Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(child: a),
          const SizedBox(width: 8),
          Expanded(child: b),
        ]),
      ),
    );

class Tag extends StatelessWidget {
  final String text;
  final Color color;
  const Tag(this.text, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: tint(color, 0.14), borderRadius: BorderRadius.circular(6)),
        child: Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
      );
}

class EmptyBox extends StatelessWidget {
  final String text;
  final IconData icon;
  const EmptyBox(this.text, {super.key, this.icon = Icons.inbox_rounded});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(28),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 40, color: C.border),
            const SizedBox(height: 8),
            Text(t(text), textAlign: TextAlign.center, style: const TextStyle(color: C.text2, fontSize: 14)),
          ]),
        ),
      );
}

class KV extends StatelessWidget {
  final String k;
  final String v;
  final Color? vColor;
  final bool bold;
  const KV(this.k, this.v, {super.key, this.vColor, this.bold = false});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Expanded(child: Text(t(k), style: const TextStyle(color: C.text2, fontSize: 14))),
          const SizedBox(width: 8),
          Flexible(
            child: Text(v,
                textAlign: TextAlign.end,
                style: TextStyle(fontSize: 14, fontWeight: bold ? FontWeight.w800 : FontWeight.w600, color: vColor ?? C.text)),
          ),
        ]),
      );
}

class HBar extends StatelessWidget {
  final String label;
  final double frac;
  final Color color;
  final String trailing;
  const HBar(this.label, this.frac, this.color, this.trailing, {super.key});
  @override
  Widget build(BuildContext context) {
    final f = frac.isNaN ? 0.0 : frac.clamp(0.0, 1.0);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        SizedBox(width: 78, child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
        Expanded(
          child: Container(
            height: 8,
            decoration: BoxDecoration(color: C.light, borderRadius: BorderRadius.circular(4)),
            child: FractionallySizedBox(
              alignment: AlignmentDirectional.centerStart,
              widthFactor: f <= 0 ? 0.0 : f,
              child: Container(decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4))),
            ),
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(width: 52, child: Text(trailing, textAlign: TextAlign.end, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}

class SegTabs extends StatelessWidget {
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  const SegTabs({super.key, required this.labels, required this.index, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: C.navy,
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
      child: Row(children: [
        for (var i = 0; i < labels.length; i++) ...[
          if (i > 0) const SizedBox(width: 6),
          Expanded(
            child: Material(
              color: i == index ? C.primary : Colors.white,
              borderRadius: BorderRadius.circular(8),
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () => onChanged(i),
                child: Container(
                  height: 40,
                  alignment: Alignment.center,
                  child: Text(t(labels[i]),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: i == index ? Colors.white : C.text)),
                ),
              ),
            ),
          ),
        ],
      ]),
    );
  }
}

/// Period chips: today / week / month / custom range.
class PeriodBar extends StatelessWidget {
  final String value;
  final String from;
  final String to;
  final void Function(String key, String from, String to) onChanged;
  const PeriodBar({super.key, required this.value, required this.from, required this.to, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    const keys = ['today', 'week', 'month', 'custom'];
    const labels = ['اليوم', 'هذا الأسبوع', 'هذا الشهر', 'فترة مخصصة'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: [
        for (var i = 0; i < keys.length; i++)
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 6),
            child: ChoiceChip(
              label: Text(t(labels[i])),
              selected: value == keys[i],
              onSelected: (_) async {
                if (keys[i] == 'custom') {
                  final r = await showDateRangePicker(
                    context: context,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                    initialDateRange: DateTimeRange(start: parseYmd(from) ?? DateTime.now(), end: parseYmd(to) ?? DateTime.now()),
                  );
                  if (r != null) onChanged('custom', ymd(r.start), ymd(r.end));
                } else {
                  final pr = periodRange(keys[i]);
                  onChanged(keys[i], pr[0], pr[1]);
                }
              },
            ),
          ),
      ]),
    );
  }
}

// ------------------------------------------------------------------ data view
class DataView<T> extends StatefulWidget {
  final Future<T> Function() load;
  final Widget Function(BuildContext, T) builder;
  const DataView({super.key, required this.load, required this.builder});
  @override
  State<DataView<T>> createState() => _DataViewState<T>();
}

class _DataViewState<T> extends State<DataView<T>> {
  late Future<T> _f;

  @override
  void initState() {
    super.initState();
    _f = widget.load();
    Db.changes.addListener(_on);
  }

  void _on() {
    if (mounted) {
      setState(() {
        _f = widget.load();
      });
    }
  }

  @override
  void didUpdateWidget(DataView<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    _f = widget.load();
  }

  @override
  void dispose() {
    Db.changes.removeListener(_on);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<T>(
      future: _f,
      builder: (c, s) {
        if (s.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text('${t('حدث خطأ')}: ${s.error}', style: const TextStyle(color: C.error)),
            ),
          );
        }
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        return widget.builder(c, s.data as T);
      },
    );
  }
}

// ------------------------------------------------------------------ form fields
class Opt<T> {
  final T value;
  final String label;
  const Opt(this.value, this.label);
}

class _Pick<T> {
  final T? v;
  final bool clear;
  _Pick(this.v, {this.clear = false});
}

Widget tf(
  TextEditingController c,
  String label, {
  bool required = false,
  bool number = false,
  bool integer = false,
  int maxLines = 1,
  String? suffix,
  bool enabled = true,
  ValueChanged<String>? onChanged,
  String? hint,
  bool positive = false,
  TextInputType? type,
}) {
  return TextFormField(
    controller: c,
    enabled: enabled,
    maxLines: maxLines,
    onChanged: onChanged,
    keyboardType: number || integer ? const TextInputType.numberWithOptions(decimal: true) : (type ?? TextInputType.text),
    decoration: InputDecoration(
      labelText: t(label) + (required ? ' *' : ''),
      suffixText: suffix == null ? null : t(suffix),
      hintText: hint == null ? null : t(hint),
    ),
    validator: (v) {
      final s = (v ?? '').trim();
      if (s.isEmpty) return required ? t('هذا الحقل مطلوب') : null;
      if (number || integer) {
        final n = parseNum(s);
        if (n == null) return t('قيمة غير صالحة');
        if (n < 0) return t('لا يمكن أن تكون القيمة سالبة');
        if (positive && n <= 0) return t('يجب أن تكون القيمة أكبر من صفر');
        if (integer && n != n.roundToDouble()) return t('أدخل عددًا صحيحًا');
      }
      return null;
    },
  );
}

class SelectField<T> extends StatelessWidget {
  final String label;
  final T? value;
  final List<Opt<T>> options;
  final ValueChanged<T?> onChanged;
  final bool required;
  final bool allowClear;
  const SelectField({
    super.key,
    required this.label,
    required this.value,
    required this.options,
    required this.onChanged,
    this.required = false,
    this.allowClear = false,
  });

  @override
  Widget build(BuildContext context) {
    final sel = options.where((o) => o.value == value).toList();
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: () async {
        final r = await showModalBottomSheet<_Pick<T>>(
          context: context,
          isScrollControlled: true,
          builder: (_) => _PickSheet<T>(title: label, options: options, allowClear: allowClear && value != null),
        );
        if (r == null) return;
        onChanged(r.clear ? null : r.v);
      },
      child: InputDecorator(
        isEmpty: sel.isEmpty,
        decoration: InputDecoration(
          labelText: t(label) + (required ? ' *' : ''),
          suffixIcon: const Icon(Icons.arrow_drop_down_rounded),
        ),
        child: Text(sel.isEmpty ? '' : sel.first.label, maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
    );
  }
}

class _PickSheet<T> extends StatefulWidget {
  final String title;
  final List<Opt<T>> options;
  final bool allowClear;
  const _PickSheet({required this.title, required this.options, required this.allowClear});
  @override
  State<_PickSheet<T>> createState() => _PickSheetState<T>();
}

class _PickSheetState<T> extends State<_PickSheet<T>> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final list = widget.options.where((o) => q.isEmpty || o.label.toLowerCase().contains(q.toLowerCase())).toList();
    final h = MediaQuery.of(context).size.height;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: h * 0.65,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
            child: Row(children: [
              Expanded(child: Text(t(widget.title), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
              if (widget.allowClear)
                TextButton(onPressed: () => Navigator.pop(context, _Pick<T>(null, clear: true)), child: Text(t('مسح'))),
            ]),
          ),
          if (widget.options.length > 6)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
              child: TextField(
                onChanged: (v) => setState(() => q = v),
                decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: t('بحث')),
              ),
            ),
          Expanded(
            child: list.isEmpty
                ? const EmptyBox('لا توجد خيارات')
                : ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (c, i) => ListTile(
                      title: Text(list[i].label),
                      onTap: () => Navigator.pop(context, _Pick<T>(list[i].value)),
                    ),
                  ),
          ),
        ]),
      ),
    );
  }
}

class DateField extends StatelessWidget {
  final String label;
  final String? value;
  final ValueChanged<String?> onChanged;
  final bool required;
  final bool allowClear;
  const DateField({super.key, required this.label, required this.value, required this.onChanged, this.required = false, this.allowClear = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: () async {
        final r = await showDatePicker(
          context: context,
          initialDate: parseYmd(value) ?? DateTime.now(),
          firstDate: DateTime(2020),
          lastDate: DateTime(2100),
        );
        if (r != null) onChanged(ymd(r));
      },
      child: InputDecorator(
        isEmpty: value == null || value!.isEmpty,
        decoration: InputDecoration(
          labelText: t(label) + (required ? ' *' : ''),
          suffixIcon: allowClear && value != null && value!.isNotEmpty
              ? IconButton(icon: const Icon(Icons.close_rounded, size: 18), onPressed: () => onChanged(null))
              : const Icon(Icons.calendar_today_rounded, size: 18),
        ),
        child: Text(showDate(value)),
      ),
    );
  }
}

class SearchField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  final String hint;
  const SearchField({super.key, required this.onChanged, this.hint = 'بحث سريع'});
  @override
  Widget build(BuildContext context) => TextField(
        onChanged: onChanged,
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: t(hint)),
      );
}

Widget gap([double h = 10]) => SizedBox(height: h);

class PrimaryButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  const PrimaryButton(this.label, {super.key, this.icon, this.onPressed});
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 50,
        child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: Icon(icon ?? Icons.check_rounded, size: 22),
          label: Text(t(label)),
        ),
      );
}

Widget simpleTable(List<String> heads, List<List<String>> rows, {List<double>? flex, List<Color?>? colors}) {
  final fl = flex ?? List<double>.filled(heads.length, 1);
  Widget cell(String s, int i, {bool head = false, Color? color}) => Expanded(
        flex: (fl[i] * 10).round(),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: Text(
            s,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: head ? 12 : 13, fontWeight: head ? FontWeight.w700 : FontWeight.w600, color: head ? C.text2 : (color ?? C.text)),
          ),
        ),
      );
  return Column(children: [
    Container(
      color: C.light,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(children: [for (var i = 0; i < heads.length; i++) cell(t(heads[i]), i, head: true)]),
    ),
    for (final r in rows)
      Container(
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.border))),
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [for (var i = 0; i < r.length; i++) cell(r[i], i)]),
      ),
  ]);
}
