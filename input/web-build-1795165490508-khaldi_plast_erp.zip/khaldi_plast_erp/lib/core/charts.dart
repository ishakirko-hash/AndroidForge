import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'format.dart';
import 'i18n.dart';
import 'theme.dart';

double niceMax(double mx) {
  if (mx <= 0) return 1;
  final mag = math.pow(10, (math.log(mx) / math.ln10).floor()).toDouble();
  final n = mx / mag;
  double step;
  if (n <= 1) {
    step = 1;
  } else if (n <= 2) {
    step = 2;
  } else if (n <= 5) {
    step = 5;
  } else {
    step = 10;
  }
  return step * mag;
}

void _text(Canvas c, String s, Offset o, {double size = 10, Color color = C.text2, double ax = 0, double ay = 0, FontWeight w = FontWeight.w500}) {
  final tp = TextPainter(
    text: TextSpan(text: s, style: TextStyle(fontSize: size, color: color, fontWeight: w)),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(c, Offset(o.dx - tp.width * ax, o.dy - tp.height * ay));
}

class _LinePainter extends CustomPainter {
  final List<double> v;
  final List<String> labels;
  final Color color;
  _LinePainter(this.v, this.labels, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    const l = 40.0, r = 14.0, tp = 22.0, b = 22.0;
    final w = size.width - l - r;
    final h = size.height - tp - b;
    final mx = niceMax(v.isEmpty ? 0 : v.reduce(math.max));
    final grid = Paint()
      ..color = C.border
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = tp + h - h * i / 4;
      canvas.drawLine(Offset(l, y), Offset(l + w, y), grid);
      _text(canvas, compact(mx * i / 4), Offset(l - 6, y), ax: 1, ay: 0.5);
    }
    if (v.isEmpty) return;
    final n = v.length;
    Offset pt(int i) => Offset(n == 1 ? l + w / 2 : l + w * i / (n - 1), tp + h - h * (v[i] / mx));
    final path = Path()..moveTo(pt(0).dx, pt(0).dy);
    for (var i = 1; i < n; i++) {
      path.lineTo(pt(i).dx, pt(i).dy);
    }
    final fill = Path.from(path)
      ..lineTo(pt(n - 1).dx, tp + h)
      ..lineTo(pt(0).dx, tp + h)
      ..close();
    canvas.drawPath(fill, Paint()..color = tint(color, 0.14));
    canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5);
    for (var i = 0; i < n; i++) {
      canvas.drawCircle(pt(i), 4, Paint()..color = Colors.white);
      canvas.drawCircle(
          pt(i),
          4,
          Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2);
      if (i < labels.length) _text(canvas, labels[i], Offset(pt(i).dx, tp + h + 5), ax: 0.5);
    }
    // value bubble on the last point
    final last = pt(n - 1);
    final label = fmt(v[n - 1]);
    final tpn = TextPainter(
      text: TextSpan(text: label, style: const TextStyle(fontSize: 11, color: Colors.white, fontWeight: FontWeight.w700)),
      textDirection: TextDirection.ltr,
    )..layout();
    final bw = tpn.width + 14;
    var bx = last.dx - bw / 2;
    if (bx + bw > size.width) bx = size.width - bw;
    if (bx < 0) bx = 0;
    final by = math.max(0.0, last.dy - 28);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(bx, by, bw, 20), const Radius.circular(6)), Paint()..color = C.primary);
    tpn.paint(canvas, Offset(bx + 7, by + 3));
  }

  @override
  bool shouldRepaint(covariant _LinePainter old) => true;
}

class LineChart extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final double height;
  const LineChart({super.key, required this.values, required this.labels, this.height = 170});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.ltr,
        child: SizedBox(height: height, width: double.infinity, child: CustomPaint(painter: _LinePainter(values, labels, C.primary))),
      );
}

class _BarPainter extends CustomPainter {
  final List<double> a; // target
  final List<double> b; // actual
  final List<String> labels;
  _BarPainter(this.a, this.b, this.labels);

  @override
  void paint(Canvas canvas, Size size) {
    const l = 38.0, r = 6.0, tp = 8.0, bt = 22.0;
    final w = size.width - l - r;
    final h = size.height - tp - bt;
    final all = <double>[...a, ...b];
    final mx = niceMax(all.isEmpty ? 0 : all.reduce(math.max));
    final grid = Paint()
      ..color = C.border
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = tp + h - h * i / 4;
      canvas.drawLine(Offset(l, y), Offset(l + w, y), grid);
      _text(canvas, compact(mx * i / 4), Offset(l - 5, y), ax: 1, ay: 0.5);
    }
    final n = labels.length;
    if (n == 0) return;
    final slot = w / n;
    final bw = math.min(slot * 0.32, 18.0);
    for (var i = 0; i < n; i++) {
      final cx = l + slot * i + slot / 2;
      final ta = i < a.length ? a[i] : 0.0;
      final ab = i < b.length ? b[i] : 0.0;
      final ha = h * ta / mx;
      final hb = h * ab / mx;
      canvas.drawRect(Rect.fromLTWH(cx - bw - 1, tp + h - ha, bw, ha), Paint()..color = tint(C.secondary, 0.35));
      canvas.drawRect(Rect.fromLTWH(cx + 1, tp + h - hb, bw, hb), Paint()..color = C.primary);
      _text(canvas, labels[i], Offset(cx, tp + h + 5), ax: 0.5, size: 9.5);
    }
  }

  @override
  bool shouldRepaint(covariant _BarPainter old) => true;
}

class BarChart extends StatelessWidget {
  final List<double> target;
  final List<double> actual;
  final List<String> labels;
  final double height;
  const BarChart({super.key, required this.target, required this.actual, required this.labels, this.height = 170});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.ltr,
        child: SizedBox(height: height, width: double.infinity, child: CustomPaint(painter: _BarPainter(target, actual, labels))),
      );
}

class Seg {
  final double value;
  final Color color;
  final String label;
  const Seg(this.value, this.color, this.label);
}

const segColors = <Color>[C.primary, C.success, C.warning, C.purple, C.error, C.secondary];

class _DonutPainter extends CustomPainter {
  final List<Seg> segs;
  final double stroke;
  _DonutPainter(this.segs, this.stroke);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(stroke / 2, stroke / 2, size.width - stroke, size.height - stroke);
    final total = segs.fold<double>(0, (s, e) => s + e.value);
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..color = C.light;
    canvas.drawArc(rect, 0, math.pi * 2, false, base);
    if (total <= 0) return;
    var start = -math.pi / 2;
    for (final s in segs) {
      if (s.value <= 0) continue;
      final sweep = s.value / total * math.pi * 2;
      canvas.drawArc(
          rect,
          start,
          sweep,
          false,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = stroke
            ..color = s.color);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutPainter old) => true;
}

class Donut extends StatelessWidget {
  final List<Seg> segs;
  final String center;
  final String? sub;
  final double size;
  const Donut({super.key, required this.segs, required this.center, this.sub, this.size = 120});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(alignment: Alignment.center, children: [
        CustomPaint(size: Size(size, size), painter: _DonutPainter(segs, size * 0.15)),
        Padding(
          padding: EdgeInsets.all(size * 0.2),
          child: Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
            FittedBox(fit: BoxFit.scaleDown, child: Text(center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: C.text))),
            if (sub != null) FittedBox(fit: BoxFit.scaleDown, child: Text(t(sub!), style: const TextStyle(fontSize: 11, color: C.text2))),
          ]),
        ),
      ]),
    );
  }
}

/// Donut + legend row (percent of each segment).
class DonutLegend extends StatelessWidget {
  final List<Seg> segs;
  final String center;
  final String? sub;
  final bool showPercent;
  const DonutLegend({super.key, required this.segs, required this.center, this.sub, this.showPercent = true});
  @override
  Widget build(BuildContext context) {
    final total = segs.fold<double>(0, (s, e) => s + e.value);
    return Row(children: [
      Donut(segs: segs, center: center, sub: sub, size: 112),
      const SizedBox(width: 12),
      Expanded(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final s in segs)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(children: [
                Container(width: 10, height: 10, decoration: BoxDecoration(color: s.color, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Expanded(child: Text(s.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
                Text(showPercent ? '${total > 0 ? (s.value / total * 100).round() : 0}%' : fmt(s.value),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
              ]),
            ),
        ]),
      ),
    ]);
  }
}
