import 'package:flutter/foundation.dart';
import '../data/db.dart';
import 'i18n.dart';

const roles = <String, String>{
  'admin': 'مدير النظام',
  'manager': 'مدير المصنع',
  'sales': 'موظف مبيعات',
  'inventory': 'موظف مخزون',
  'production': 'مشرف إنتاج',
  'accountant': 'محاسب',
  'operator': 'مشغّل آلة',
};

const _perms = <String, Set<String>>{
  'admin': {'sales', 'inventory', 'production', 'finance', 'hr', 'reports', 'delete', 'settings', 'catalog'},
  'manager': {'sales', 'inventory', 'production', 'finance', 'hr', 'reports', 'delete', 'catalog'},
  'sales': {'sales', 'reports'},
  'inventory': {'inventory', 'reports', 'catalog'},
  'production': {'production', 'inventory', 'reports'},
  'accountant': {'finance', 'sales', 'reports'},
  'operator': {'production'},
};

class AppState extends ChangeNotifier {
  static final AppState i = AppState();

  final Map<String, String> _s = {};
  String role = 'admin';

  bool get ar => _s['lang'] != 'en';

  String get(String k, [String d = '']) => _s[k] ?? d;

  Future<void> load() async {
    _s.clear();
    final rows = await Db.q('SELECT key, value FROM settings');
    for (final r in rows) {
      _s[r['key'] as String] = (r['value'] as String?) ?? '';
    }
    role = _s['role'] ?? 'admin';
    if (!roles.containsKey(role)) role = 'admin';
    S.ar = ar;
    notifyListeners();
  }

  Future<void> set(String k, String v) async {
    _s[k] = v;
    await Db.d.rawInsert('INSERT OR REPLACE INTO settings(key, value) VALUES(?, ?)', [k, v]);
    if (k == 'lang') S.ar = ar;
    if (k == 'role') role = v;
    notifyListeners();
  }

  bool can(String perm) => (_perms[role] ?? const <String>{}).contains(perm);

  String get roleName => roles[role] ?? role;
  String get company => get('company_name', 'KHALDI PLAST');
}
