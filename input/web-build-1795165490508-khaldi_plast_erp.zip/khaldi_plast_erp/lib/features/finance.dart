import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import 'entities.dart';
import 'entity.dart';

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key});
  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {
  String pKey = 'month';
  String from = periodRange('month')[0];
  String to = periodRange('month')[1];
  String kind = 'all';
  String q = '';

  @override
  Widget build(BuildContext context) {
    final can = AppState.i.can('finance');
    final e = transactionEntity();
    return PageScaffold(
      title: 'المصاريف والمعاملات',
      actions: [
        IconButton(
          tooltip: t('الأرباح والتكاليف'),
          icon: const Icon(Icons.trending_up_rounded),
          onPressed: () => go(context, const ProfitPage()),
        ),
      ],
      fab: can
          ? FloatingActionButton.extended(
              backgroundColor: C.primary,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: Text(t('إضافة معاملة')),
              onPressed: () => go(context, EntityForm(entity: e)),
            )
          : null,
      body: DataView<List<Rec>>(
        load: () => Db.q('SELECT * FROM transactions WHERE date BETWEEN ? AND ? ORDER BY date DESC, id DESC', [from, to]),
        builder: (c, rows) {
          final sums = <String, double>{};
          for (final r in rows) {
            sums[str(r['kind'])] = (sums[str(r['kind'])] ?? 0) + dbl(r['amount']);
          }
          final ql = q.trim().toLowerCase();
          final list = rows.where((r) {
            if (kind != 'all' && r['kind'] != kind) return false;
            if (ql.isEmpty) return true;
            return str(r['description']).toLowerCase().contains(ql) ||
                str(r['category']).toLowerCase().contains(ql) ||
                str(r['party']).toLowerCase().contains(ql);
          }).toList();
          return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
            PeriodBar(
              value: pKey,
              from: from,
              to: to,
              onChanged: (k, f, tt) => setState(() {
                pKey = k;
                from = f;
                to = tt;
              }),
            ),
            gap(10),
            kpiRow(
              KpiTile(icon: Icons.south_west_rounded, color: C.success, title: 'الإيرادات', value: fmt(sums['income'] ?? 0), unit: 'دج'),
              KpiTile(icon: Icons.north_east_rounded, color: C.error, title: 'المصاريف', value: fmt(sums['expense'] ?? 0), unit: 'دج'),
            ),
            kpiRow(
              KpiTile(icon: Icons.shopping_basket_rounded, color: C.warning, title: 'المشتريات', value: fmt(sums['purchase'] ?? 0), unit: 'دج'),
              KpiTile(icon: Icons.request_quote_rounded, color: C.purple, title: 'الديون', value: fmt(sums['debt'] ?? 0), unit: 'دج'),
            ),
            SearchField(onChanged: (v) => setState(() => q = v)),
            gap(8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                for (final k in ['all', ...kindLabels.keys])
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 6),
                    child: ChoiceChip(
                      label: Text(k == 'all' ? t('الكل') : t(kindLabels[k]!)),
                      selected: kind == k,
                      onSelected: (_) => setState(() => kind = k),
                    ),
                  ),
              ]),
            ),
            gap(8),
            if (list.isEmpty) const EmptyBox('لا توجد معاملات في هذه الفترة'),
            for (final r in list) _row(context, e, r, can),
          ]);
        },
      ),
    );
  }

  Widget _row(BuildContext context, Entity e, Rec r, bool can) {
    final k = str(r['kind']);
    final inflow = k == 'income';
    final color = inflow ? C.success : (k == 'expense' ? C.error : (k == 'purchase' ? C.warning : C.purple));
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: can ? () => go(context, EntityForm(entity: e, row: r)) : null,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(str(r['description']).isEmpty ? str(r['category']) : str(r['description']),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800), maxLines: 2, overflow: TextOverflow.ellipsis),
                  Text(
                      [showDate(str(r['date'])), str(r['category']), str(r['party']), methodLabel(str(r['method']))]
                          .where((s) => s.isNotEmpty)
                          .join(' • '),
                      style: const TextStyle(fontSize: 12, color: C.text2)),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('${inflow ? '+' : '-'}${money(dbl(r['amount']))}', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: color)),
                Tag(t(kindLabels[k] ?? k), color),
              ]),
              if (can && AppState.i.can('delete'))
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded, color: C.error),
                  onPressed: () => deleteRow(context, e, r),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}

class ProfitPage extends StatefulWidget {
  const ProfitPage({super.key});
  @override
  State<ProfitPage> createState() => _ProfitPageState();
}

class _ProfitPageState extends State<ProfitPage> {
  String pKey = 'month';
  String from = periodRange('month')[0];
  String to = periodRange('month')[1];
  final Set<String> excluded = {};

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'الأرباح والتكاليف',
      body: DataView<Rec>(
        load: () => Svc.profit(from, to, excludeCats: excluded),
        builder: (c, d) {
          final cats = d['cats'] as List<Rec>;
          final net = dbl(d['net']);
          return ListView(padding: const EdgeInsets.all(12), children: [
            PeriodBar(
              value: pKey,
              from: from,
              to: to,
              onChanged: (k, f, tt) => setState(() {
                pKey = k;
                from = f;
                to = tt;
              }),
            ),
            gap(10),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: tint(net >= 0 ? C.success : C.error, 0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: net >= 0 ? C.success : C.error),
              ),
              child: Column(children: [
                Text(t(net >= 0 ? 'صافي الربح' : 'صافي الخسارة'), style: const TextStyle(fontSize: 14, color: C.text2, fontWeight: FontWeight.w700)),
                FittedBox(
                  child: Text(money(net.abs()), style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: net >= 0 ? C.success : C.error)),
                ),
                Text('${showDate(from)} - ${showDate(to)}', style: const TextStyle(fontSize: 12, color: C.text2)),
              ]),
            ),
            gap(10),
            Panel(
              title: 'الإيرادات',
              icon: Icons.south_west_rounded,
              iconColor: C.success,
              child: Column(children: [
                KV('إجمالي المبيعات (الفواتير)', money(dbl(d['sales']))),
                KV('إيرادات أخرى', money(dbl(d['other_income']))),
                KV('المحصّل فعليًا من المبيعات', money(dbl(d['collected'])), vColor: C.text2),
              ]),
            ),
            Panel(
              title: 'التكاليف',
              icon: Icons.north_east_rounded,
              iconColor: C.error,
              child: Column(children: [
                KV('تكلفة المواد المستهلكة في الإنتاج', money(dbl(d['material_cost']))),
                KV('المصاريف المحتسبة', money(dbl(d['expenses']))),
                KV('تكاليف الصيانة المنتهية', money(dbl(d['maintenance']))),
                const Divider(),
                KV('إجمالي التكاليف', money(dbl(d['total_cost'])), bold: true, vColor: C.error),
                KV('الربح الإجمالي (المبيعات - المواد)', money(dbl(d['gross'])), bold: true),
                KV('تكلفة القطعة المنتجة', '${fmt2(dbl(d['cost_per_piece']))} ${t('دج')}'),
                KV('القطع المنتجة', fmt(dbl(d['produced']))),
              ]),
            ),
            Panel(
              title: 'فئات المصاريف المحتسبة في التكلفة',
              icon: Icons.tune_rounded,
              child: cats.isEmpty
                  ? const EmptyBox('لا توجد مصاريف في هذه الفترة')
                  : Wrap(spacing: 6, runSpacing: 6, children: [
                      for (final k in cats)
                        FilterChip(
                          label: Text('${t(str(k['cat']))}: ${fmt(dbl(k['amount']))}'),
                          selected: !excluded.contains(k['cat']),
                          onSelected: (v) => setState(() {
                            if (v) {
                              excluded.remove(k['cat']);
                            } else {
                              excluded.add(str(k['cat']));
                            }
                          }),
                        ),
                    ]),
            ),
            Panel(
              title: 'طريقة الحساب',
              icon: Icons.info_rounded,
              child: Text(
                t('صافي الربح = المبيعات + الإيرادات الأخرى − تكلفة المواد المستهلكة فعليًا − المصاريف المحتسبة − تكاليف الصيانة. لا يُعتبر الإيراد ربحًا قبل خصم التكاليف. مشتريات المواد لا تُحتسب مباشرة لأنها تدخل التكلفة عند استهلاكها في الإنتاج.'),
                style: const TextStyle(fontSize: 13, color: C.text2, height: 1.5),
              ),
            ),
          ]);
        },
      ),
    );
  }
}
