import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import 'entities.dart';
import 'entity.dart';

StatusInfo stockStatus(double q, double mn) {
  if (mn > 0 && q <= 0) return StatusInfo(t('نفد'), C.error);
  if (mn > 0 && q <= mn) return StatusInfo(t('قريب من النفاد'), C.warning);
  return StatusInfo(t('متوفر'), C.success);
}

class InventoryPage extends StatefulWidget {
  const InventoryPage({super.key});
  @override
  State<InventoryPage> createState() => _InventoryPageState();
}

class _InventoryPageState extends State<InventoryPage> {
  int tab = 0;
  String q = '';
  String moveKind = 'all';
  String? from;
  String? to;

  @override
  Widget build(BuildContext context) {
    final can = AppState.i.can('inventory');
    return PageScaffold(
      title: 'المخزون',
      logo: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(50),
        child: SegTabs(labels: const ['المنتجات النهائية', 'المواد الأولية', 'حركة المخزون'], index: tab, onChanged: (i) => setState(() => tab = i)),
      ),
      fab: can
          ? FloatingActionButton.extended(
              backgroundColor: C.primary,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: Text(t('إضافة مخزون')),
              onPressed: () => go(context, StockEntryPage(itemType: tab == 1 ? 'material' : 'product', action: 'receipt')),
            )
          : null,
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 6), child: SearchField(onChanged: (v) => setState(() => q = v))),
        Expanded(child: tab == 0 ? _products() : (tab == 1 ? _materials() : _movements())),
      ]),
    );
  }

  Widget _products() {
    return DataView<Rec>(
      load: () async {
        final rows = await Db.q('SELECT * FROM products WHERE active = 1 ORDER BY name');
        return {'rows': rows};
      },
      builder: (c, d) {
        final rows = d['rows'] as List<Rec>;
        var pieces = 0.0, value = 0.0, low = 0;
        for (final r in rows) {
          pieces += dbl(r['qty']);
          value += dbl(r['qty']) * dbl(r['price']);
          if (dbl(r['min_stock']) > 0 && dbl(r['qty']) <= dbl(r['min_stock'])) low++;
        }
        final ql = q.trim().toLowerCase();
        final list = rows.where((r) => ql.isEmpty || str(r['name']).toLowerCase().contains(ql) || str(r['code']).toLowerCase().contains(ql)).toList();
        return ListView(padding: const EdgeInsets.fromLTRB(12, 4, 12, 90), children: [
          kpiRow(
            KpiTile(icon: Icons.inventory_2_rounded, color: C.success, title: 'قيمة المخزون', value: fmt(value), unit: 'دج'),
            KpiTile(icon: Icons.view_in_ar_rounded, color: C.primary, title: 'إجمالي القطع', value: fmt(pieces), unit: 'قطعة'),
          ),
          kpiRow(
            KpiTile(icon: Icons.category_rounded, color: C.purple, title: 'عدد المنتجات', value: fmt(rows.length.toDouble())),
            KpiTile(icon: Icons.warning_amber_rounded, color: low > 0 ? C.error : C.success, title: 'تنبيهات نقص المخزون', value: '$low'),
          ),
          if (list.isEmpty) const EmptyBox('لا توجد منتجات'),
          for (final r in list) _productRow(r),
        ]);
      },
    );
  }

  Widget _productRow(Rec r) {
    final st = stockStatus(dbl(r['qty']), dbl(r['min_stock']));
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () => go(context, ItemDetailPage(itemType: 'product', id: intv(r['id']))),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              productThumb(r['image'] as String?),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${str(r['name'])}  (${str(r['code'])})', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                  Text('${fmt2(dbl(r['length']))} × ${fmt2(dbl(r['width']))} × ${fmt2(dbl(r['height']))} ${t('مم')}',
                      style: const TextStyle(fontSize: 12, color: C.text2)),
                  Text('${t('الوزن')}: ${fmt2(dbl(r['weight_g']))} ${t('غ')} • ${t('الحد الأدنى')}: ${fmt(dbl(r['min_stock']))}',
                      style: const TextStyle(fontSize: 12, color: C.text2)),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(fmt(dbl(r['qty'])), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Tag(st.label, st.color),
              ]),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _materials() {
    return DataView<List<Rec>>(
      load: () => Db.q(
          "SELECT m.*, s.name AS supplier, (SELECT MAX(date) FROM stock_movements sm WHERE sm.item_type = 'material' AND sm.item_id = m.id) AS last_move FROM materials m LEFT JOIN suppliers s ON s.id = m.supplier_id ORDER BY m.name"),
      builder: (c, rows) {
        var kg = 0.0, low = 0;
        for (final r in rows) {
          if (r['unit'] == 'kg') kg += dbl(r['qty']);
          if (dbl(r['min_qty']) > 0 && dbl(r['qty']) <= dbl(r['min_qty'])) low++;
        }
        final ql = q.trim().toLowerCase();
        final list = rows.where((r) => ql.isEmpty || str(r['name']).toLowerCase().contains(ql) || str(r['code']).toLowerCase().contains(ql)).toList();
        return ListView(padding: const EdgeInsets.fromLTRB(12, 4, 12, 90), children: [
          kpiRow(
            KpiTile(icon: Icons.layers_rounded, color: C.warning, title: 'إجمالي المواد الأولية', value: fmt2(kg), unit: 'كغ'),
            KpiTile(icon: Icons.warning_amber_rounded, color: low > 0 ? C.error : C.success, title: 'تنبيهات نقص المخزون', value: '$low'),
          ),
          if (AppState.i.can('inventory'))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: OutlinedButton.icon(
                icon: const Icon(Icons.add_rounded),
                label: Text(t('إضافة مادة أولية جديدة')),
                onPressed: () => go(context, EntityForm(entity: materialsEntity())),
              ),
            ),
          if (list.isEmpty) const EmptyBox('لا توجد مواد'),
          for (final r in list) _materialRow(r),
        ]);
      },
    );
  }

  Widget _materialRow(Rec r) {
    final st = stockStatus(dbl(r['qty']), dbl(r['min_qty']));
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () => go(context, ItemDetailPage(itemType: 'material', id: intv(r['id']))),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: tint(C.primary), borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.layers_rounded, color: C.primary),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${str(r['name'])}  (${str(r['code'])})', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                  Text([str(r['category']), str(r['supplier'])].where((s) => s.isNotEmpty).join(' • '),
                      style: const TextStyle(fontSize: 12, color: C.text2)),
                  Text('${t('الحد الأدنى')}: ${fmt2(dbl(r['min_qty']))} • ${t('آخر حركة')}: ${showDate(str(r['last_move']))}',
                      style: const TextStyle(fontSize: 12, color: C.text2)),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('${fmt2(dbl(r['qty']))} ${unitLabel(str(r['unit']))}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Tag(st.label, st.color),
              ]),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _movements() {
    return Column(children: [
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(children: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 6),
            child: ActionChip(
              avatar: const Icon(Icons.date_range_rounded, size: 18),
              label: Text(from == null ? t('كل التواريخ') : '${showDate(from)} - ${showDate(to)}'),
              onPressed: () async {
                if (from != null) {
                  setState(() {
                    from = null;
                    to = null;
                  });
                  return;
                }
                final r = await showDateRangePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100));
                if (r != null) {
                  setState(() {
                    from = ymd(r.start);
                    to = ymd(r.end);
                  });
                }
              },
            ),
          ),
          for (final k in ['all', ...movementLabels.keys])
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 6),
              child: ChoiceChip(
                label: Text(k == 'all' ? t('الكل') : movementLabel(k)),
                selected: moveKind == k,
                onSelected: (_) => setState(() => moveKind = k),
              ),
            ),
        ]),
      ),
      Expanded(
        child: DataView<List<Rec>>(
          load: () => Db.q(
              "SELECT m.*, COALESCE(p.name, mt.name) AS item FROM stock_movements m LEFT JOIN products p ON (m.item_type = 'product' AND p.id = m.item_id) LEFT JOIN materials mt ON (m.item_type = 'material' AND mt.id = m.item_id) ORDER BY m.id DESC LIMIT 500"),
          builder: (c, rows) {
            final ql = q.trim().toLowerCase();
            final list = rows.where((r) {
              if (moveKind != 'all' && r['kind'] != moveKind) return false;
              if (from != null && str(r['date']).compareTo(from!) < 0) return false;
              if (to != null && str(r['date']).compareTo(to!) > 0) return false;
              return ql.isEmpty || str(r['item']).toLowerCase().contains(ql) || str(r['notes']).toLowerCase().contains(ql);
            }).toList();
            if (list.isEmpty) return const EmptyBox('لا توجد حركات');
            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
              itemCount: list.length,
              itemBuilder: (c, i) => MovementTile(r: list[i]),
            );
          },
        ),
      ),
    ]);
  }
}

class MovementTile extends StatelessWidget {
  final Rec r;
  const MovementTile({super.key, required this.r});
  @override
  Widget build(BuildContext context) {
    final q = dbl(r['qty']);
    final pos = q >= 0;
    final isMat = r['item_type'] == 'material';
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
      child: Row(children: [
        Icon(pos ? Icons.arrow_circle_up_rounded : Icons.arrow_circle_down_rounded, color: pos ? C.success : C.error, size: 28),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(str(r['item']), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
            Text('${movementLabel(str(r['kind']))} • ${showDate(str(r['date']))}', style: const TextStyle(fontSize: 12, color: C.text2)),
            if (str(r['notes']).isNotEmpty) Text(str(r['notes']), style: const TextStyle(fontSize: 12, color: C.text2), maxLines: 1, overflow: TextOverflow.ellipsis),
            if (str(r['user']).isNotEmpty) Text(str(r['user']), style: const TextStyle(fontSize: 11, color: C.text2)),
          ]),
        ),
        Text('${pos ? '+' : ''}${fmt2(q)} ${isMat ? t('كغ') : t('قطعة')}',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: pos ? C.success : C.error)),
      ]),
    );
  }
}

// ====================================================================== ITEM DETAIL
class ItemDetailPage extends StatelessWidget {
  final String itemType;
  final int id;
  const ItemDetailPage({super.key, required this.itemType, required this.id});

  @override
  Widget build(BuildContext context) {
    final isProduct = itemType == 'product';
    final table = isProduct ? 'products' : 'materials';
    return PageScaffold(
      title: isProduct ? 'تفاصيل المنتج' : 'تفاصيل المادة',
      actions: [
        if (AppState.i.can(isProduct ? 'catalog' : 'inventory'))
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: () async {
              final r = await Db.one('SELECT * FROM $table WHERE id = ?', [id]);
              if (r != null && context.mounted) {
                await go(context, EntityForm(entity: isProduct ? productsEntity() : materialsEntity(), row: r));
              }
            },
          ),
      ],
      body: DataView<Rec>(
        load: () async {
          final item = await Db.one('SELECT * FROM $table WHERE id = ?', [id]);
          final moves = await Db.q(
              "SELECT m.*, '' AS item FROM stock_movements m WHERE m.item_type = ? AND m.item_id = ? ORDER BY m.id DESC LIMIT 40", [itemType, id]);
          return {'item': item, 'moves': moves};
        },
        builder: (ctx, d) {
          final item = d['item'] as Rec?;
          if (item == null) return const EmptyBox('العنصر غير موجود');
          final moves = d['moves'] as List<Rec>;
          final mn = dbl(isProduct ? item['min_stock'] : item['min_qty']);
          final st = stockStatus(dbl(item['qty']), mn);
          final can = AppState.i.can('inventory');
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              title: str(item['name']),
              icon: isProduct ? Icons.view_in_ar_rounded : Icons.layers_rounded,
              trailing: Tag(st.label, st.color),
              child: Column(children: [
                if (isProduct && str(item['image']).startsWith('assets/'))
                  Padding(padding: const EdgeInsets.only(bottom: 8), child: SizedBox(height: 110, child: Image.asset(str(item['image']), fit: BoxFit.contain))),
                KV('الرمز', str(item['code'])),
                if (isProduct) ...[
                  KV('الأبعاد (مم)', '${fmt2(dbl(item['length']))} × ${fmt2(dbl(item['width']))} × ${fmt2(dbl(item['height']))}'),
                  KV('وزن القطعة', '${fmt2(dbl(item['weight_g']))} ${t('غ')}'),
                  KV('سعر البيع', money(dbl(item['price']))),
                ] else ...[
                  KV('الفئة', str(item['category'])),
                  KV('سعر الشراء', '${money(dbl(item['unit_cost']))} / ${unitLabel(str(item['unit']))}'),
                ],
                KV('الكمية المتوفرة', '${fmt2(dbl(item['qty']))} ${isProduct ? t('قطعة') : unitLabel(str(item['unit']))}', bold: true),
                KV('الحد الأدنى', fmt2(mn)),
              ]),
            ),
            if (can)
              Row(children: [
                for (final a in const [
                  ['receipt', 'استلام', Icons.add_box_rounded],
                  ['withdraw', 'صرف', Icons.outbox_rounded],
                  ['adjust', 'تسوية', Icons.rule_rounded],
                ])
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: OutlinedButton.icon(
                        icon: Icon(a[2] as IconData, size: 18),
                        label: Text(t(a[1] as String)),
                        onPressed: () => go(context, StockEntryPage(itemType: itemType, itemId: id, action: a[0] as String)),
                      ),
                    ),
                  ),
              ]),
            gap(10),
            Panel(
              title: 'سجل الحركات',
              icon: Icons.history_rounded,
              padding: const EdgeInsets.all(8),
              child: moves.isEmpty
                  ? const EmptyBox('لا توجد حركات لهذا العنصر')
                  : Column(children: [for (final m in moves) MovementTile(r: {...m, 'item': str(item['name'])})]),
            ),
          ]);
        },
      ),
    );
  }
}

// ====================================================================== STOCK ENTRY
class StockEntryPage extends StatefulWidget {
  final String itemType;
  final int? itemId;
  final String action;
  const StockEntryPage({super.key, this.itemType = 'product', this.itemId, this.action = 'receipt'});
  @override
  State<StockEntryPage> createState() => _StockEntryPageState();
}

class _StockEntryPageState extends State<StockEntryPage> {
  late String type = widget.itemType;
  late String action = widget.action;
  int? itemId;
  final qty = TextEditingController();
  final cost = TextEditingController();
  final notes = TextEditingController();
  int? supplierId;
  bool recordPurchase = true;
  bool saving = false;
  List<Rec> items = [];
  List<Rec> suppliers = [];
  final _key = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    itemId = widget.itemId;
    _load();
  }

  Future<void> _load() async {
    items = await Db.q(type == 'product' ? 'SELECT * FROM products ORDER BY name' : 'SELECT * FROM materials ORDER BY name');
    suppliers = await Db.q('SELECT id, name FROM suppliers ORDER BY name');
    if (itemId != null) _onItem(itemId);
    if (mounted) setState(() {});
  }

  void _onItem(int? id) {
    itemId = id;
    final it = items.where((x) => x['id'] == id).toList();
    if (it.isNotEmpty && type == 'material') {
      cost.text = dbl(it.first['unit_cost']) > 0 ? numText(it.first['unit_cost']) : '';
      supplierId = it.first['supplier_id'] as int?;
    }
  }

  @override
  void dispose() {
    qty.dispose();
    cost.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (saving) return;
    if (itemId == null) {
      toast(context, 'اختر العنصر أولاً', error: true);
      return;
    }
    if (!_key.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      await Svc.stockAction(
        itemType: type,
        itemId: itemId!,
        action: action,
        qty: parseNum(qty.text) ?? 0,
        notes: notes.text.trim(),
        unitCost: parseNum(cost.text) ?? 0,
        supplierId: supplierId,
        recordPurchase: recordPurchase,
      );
      if (!mounted) return;
      toast(context, 'تم تسجيل الحركة بنجاح');
      Navigator.pop(context, true);
    } on AppErr catch (e) {
      if (mounted) toast(context, e.msg, error: true);
    } on DatabaseException {
      if (mounted) toast(context, 'تعذر حفظ الحركة', error: true);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cur = items.where((x) => x['id'] == itemId).toList();
    final curQty = cur.isEmpty ? null : dbl(cur.first['qty']);
    final isMat = type == 'material';
    return PageScaffold(
      title: 'حركة مخزون',
      body: Form(
        key: _key,
        child: ListView(padding: const EdgeInsets.all(14), children: [
          SelectField<String>(
            label: 'نوع العنصر',
            value: type,
            options: [Opt<String>('product', t('منتج نهائي')), Opt<String>('material', t('مادة أولية'))],
            onChanged: (v) {
              if (v == null || v == type) return;
              setState(() {
                type = v;
                itemId = null;
                items = [];
              });
              _load();
            },
          ),
          gap(12),
          SelectField<int>(
            label: 'العنصر',
            value: itemId,
            required: true,
            options: [for (final i in items) Opt<int>(i['id'] as int, '${str(i['name'])} (${str(i['code'])})')],
            onChanged: (v) => setState(() => _onItem(v)),
          ),
          if (curQty != null) Padding(padding: const EdgeInsets.only(top: 6), child: KV('الكمية الحالية', fmt2(curQty), bold: true)),
          gap(12),
          SelectField<String>(
            label: 'نوع الحركة',
            value: action,
            required: true,
            options: [Opt<String>('receipt', t('استلام / إضافة')), Opt<String>('withdraw', t('صرف / سحب')), Opt<String>('adjust', t('تسوية بعد الجرد'))],
            onChanged: (v) => setState(() => action = v ?? action),
          ),
          gap(12),
          tf(qty, action == 'adjust' ? 'الكمية الفعلية بعد الجرد' : 'الكمية', number: true, required: true, positive: action != 'adjust'),
          if (isMat && action == 'receipt') ...[
            gap(12),
            tf(cost, 'سعر الشراء للوحدة', number: true, suffix: 'دج'),
            gap(12),
            SelectField<int>(
              label: 'المورد',
              value: supplierId,
              allowClear: true,
              options: [for (final s in suppliers) Opt<int>(s['id'] as int, str(s['name']))],
              onChanged: (v) => setState(() => supplierId = v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(t('تسجيل الشراء في المصاريف والمعاملات')),
              value: recordPurchase,
              onChanged: (v) => setState(() => recordPurchase = v),
            ),
          ],
          gap(12),
          tf(notes, 'ملاحظات', maxLines: 2),
          gap(18),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: saving ? null : () => Navigator.pop(context), child: Text(t('إلغاء')))),
            const SizedBox(width: 10),
            Expanded(flex: 2, child: PrimaryButton('حفظ الحركة', onPressed: saving ? null : _save)),
          ]),
        ]),
      ),
    );
  }
}
