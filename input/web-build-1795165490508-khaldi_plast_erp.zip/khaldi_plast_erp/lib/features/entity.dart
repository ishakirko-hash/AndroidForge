import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';

enum FT { text, multiline, integer, decimal, date, select, toggle, file }

class F {
  final String key;
  final String label;
  final FT type;
  final bool required;
  final Object? def;
  final String? suffix;
  final List<Opt<Object>>? options;
  final Future<List<Opt<Object>>> Function(Rec cur)? loader;
  final String? dependsOn;
  final bool positive;
  const F(this.key, this.label, this.type,
      {this.required = false, this.def, this.suffix, this.options, this.loader, this.dependsOn, this.positive = false});
}

class Entity {
  final String table;
  final String title;
  final String single;
  final String icon;
  final String perm;
  final List<F> fields;
  final String Function(Rec) titleOf;
  final String? Function(Rec)? subOf;
  final Widget Function(BuildContext, Rec)? leading;
  final Widget Function(BuildContext, Rec)? trailing;
  final String? sql;
  final List<String> searchKeys;
  final Future<String?> Function(Rec values, Rec? old)? validate;
  final Future<void> Function(Rec values)? beforeInsert;
  final Future<void> Function(int id, Rec values)? after;
  final Future<void> Function(BuildContext, Rec)? onOpen;
  final bool canDelete;
  final bool createdAt;
  const Entity({
    required this.table,
    required this.title,
    required this.single,
    required this.icon,
    required this.perm,
    required this.fields,
    required this.titleOf,
    this.subOf,
    this.leading,
    this.trailing,
    this.sql,
    this.searchKeys = const ['name'],
    this.validate,
    this.beforeInsert,
    this.after,
    this.onOpen,
    this.canDelete = true,
    this.createdAt = true,
  });
}

Future<List<Opt<Object>>> optsFrom(String table, String labelExpr, {String? where, List<Object?>? args}) async {
  final rows = await Db.q('SELECT id, $labelExpr AS l FROM $table ${where ?? ''} ORDER BY l', args);
  return rows.map((r) => Opt<Object>(r['id'] as int, str(r['l']))).toList();
}

String numText(Object? v) {
  if (v == null) return '';
  if (v is num) {
    if (v == v.roundToDouble()) return v.toInt().toString();
    return v.toString();
  }
  return v.toString();
}

Future<String> keepFile(String src) async {
  final docs = await getApplicationDocumentsDirectory();
  final dir = Directory(p.join(docs.path, 'attachments'));
  await dir.create(recursive: true);
  final dest = p.join(dir.path, '${DateTime.now().millisecondsSinceEpoch}_${p.basename(src)}');
  await File(src).copy(dest);
  return dest;
}

// ====================================================================== FORM
class EntityForm extends StatefulWidget {
  final Entity entity;
  final Rec? row;
  final Rec? preset;
  const EntityForm({super.key, required this.entity, this.row, this.preset});
  @override
  State<EntityForm> createState() => _EntityFormState();
}

class _EntityFormState extends State<EntityForm> {
  final _key = GlobalKey<FormState>();
  final Map<String, TextEditingController> _c = {};
  final Rec _v = {};
  final Map<String, List<Opt<Object>>> _opts = {};
  bool _saving = false;

  Entity get e => widget.entity;

  @override
  void initState() {
    super.initState();
    for (final f in e.fields) {
      Object? init;
      if (widget.row != null) {
        init = widget.row![f.key];
      } else {
        init = widget.preset != null && widget.preset!.containsKey(f.key) ? widget.preset![f.key] : f.def;
      }
      if (f.type == FT.date && init == 'today') init = today();
      switch (f.type) {
        case FT.text:
        case FT.multiline:
        case FT.integer:
        case FT.decimal:
          _c[f.key] = TextEditingController(text: numText(init));
          break;
        case FT.toggle:
          _v[f.key] = init == 1 || init == true;
          break;
        default:
          _v[f.key] = init;
      }
      if (f.options != null) _opts[f.key] = f.options!;
    }
    for (final f in e.fields) {
      if (f.loader != null) _load(f);
    }
  }

  Future<void> _load(F f) async {
    final o = await f.loader!(_v);
    if (!mounted) return;
    setState(() => _opts[f.key] = o);
  }

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving) return;
    if (!_key.currentState!.validate()) return;
    final out = <String, Object?>{};
    for (final f in e.fields) {
      switch (f.type) {
        case FT.text:
        case FT.multiline:
          out[f.key] = _c[f.key]!.text.trim();
          break;
        case FT.integer:
        case FT.decimal:
          out[f.key] = parseNum(_c[f.key]!.text) ?? 0;
          break;
        case FT.toggle:
          out[f.key] = _v[f.key] == true ? 1 : 0;
          break;
        case FT.date:
        case FT.select:
        case FT.file:
          final v = _v[f.key];
          if (f.required && (v == null || v.toString().isEmpty)) {
            toast(context, '${t('يرجى تعبئة الحقل')}: ${t(f.label)}', error: true);
            return;
          }
          out[f.key] = v;
          break;
      }
    }
    if (e.validate != null) {
      final err = await e.validate!(out, widget.row);
      if (err != null) {
        if (mounted) toast(context, err, error: true);
        return;
      }
    }
    setState(() => _saving = true);
    try {
      int id;
      if (widget.row == null) {
        if (e.createdAt) out['created_at'] = Svc.nowIso();
        if (e.beforeInsert != null) await e.beforeInsert!(out);
        id = await Db.insert(e.table, out);
        await Svc.auditDb('create', e.table, id, e.titleOf(out));
      } else {
        id = intv(widget.row!['id']);
        await Db.update(e.table, out, id);
        await Svc.auditDb('update', e.table, id, e.titleOf(out));
      }
      if (e.after != null) await e.after!(id, out);
      if (!mounted) return;
      toast(context, 'تم الحفظ بنجاح');
      Navigator.pop(context, true);
    } on DatabaseException catch (ex) {
      if (mounted) {
        toast(context, ex.toString().contains('UNIQUE') ? 'القيمة موجودة مسبقًا (رمز أو رقم مكرر)' : 'تعذر الحفظ', error: true);
      }
    } on AppErr catch (ex) {
      if (mounted) toast(context, ex.msg, error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _field(F f) {
    switch (f.type) {
      case FT.text:
        return tf(_c[f.key]!, f.label, required: f.required, suffix: f.suffix);
      case FT.multiline:
        return tf(_c[f.key]!, f.label, required: f.required, maxLines: 3);
      case FT.integer:
        return tf(_c[f.key]!, f.label, required: f.required, integer: true, suffix: f.suffix, positive: f.positive);
      case FT.decimal:
        return tf(_c[f.key]!, f.label, required: f.required, number: true, suffix: f.suffix, positive: f.positive);
      case FT.date:
        return DateField(
          label: f.label,
          value: _v[f.key] as String?,
          required: f.required,
          allowClear: !f.required,
          onChanged: (x) => setState(() => _v[f.key] = x),
        );
      case FT.select:
        final list = (_opts[f.key] ?? const <Opt<Object>>[]).map((o) => Opt<Object>(o.value, t(o.label))).toList();
        return SelectField<Object>(
          label: f.label,
          value: _v[f.key],
          options: list,
          required: f.required,
          allowClear: !f.required,
          onChanged: (x) {
            setState(() {
              _v[f.key] = x;
              for (final d in e.fields) {
                if (d.dependsOn == f.key) {
                  _v[d.key] = null;
                  _opts[d.key] = const <Opt<Object>>[];
                }
              }
            });
            for (final d in e.fields) {
              if (d.dependsOn == f.key && d.loader != null) _load(d);
            }
          },
        );
      case FT.toggle:
        return Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
          child: SwitchListTile(
            title: Text(t(f.label)),
            value: _v[f.key] == true,
            onChanged: (x) => setState(() => _v[f.key] = x),
          ),
        );
      case FT.file:
        final path = _v[f.key] as String?;
        return Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
          child: Row(children: [
            Expanded(
              child: Text(path == null || path.isEmpty ? t(f.label) : p.basename(path), maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
            TextButton.icon(
              icon: const Icon(Icons.attach_file_rounded),
              label: Text(t('إرفاق')),
              onPressed: () async {
                final r = await FilePicker.platform.pickFiles();
                if (r == null || r.files.isEmpty || r.files.first.path == null) return;
                final kept = await keepFile(r.files.first.path!);
                if (mounted) setState(() => _v[f.key] = kept);
              },
            ),
            if (path != null && path.isNotEmpty)
              IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => _v[f.key] = null)),
          ]),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.row != null;
    return PageScaffold(
      title: '${t(editing ? 'تعديل' : 'إضافة')} ${t(e.single)}',
      body: Form(
        key: _key,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            for (final f in e.fields) ...[_field(f), gap(12)],
            gap(4),
            Row(children: [
              Expanded(
                child: OutlinedButton(onPressed: _saving ? null : () => Navigator.pop(context, false), child: Text(t('إلغاء'))),
              ),
              const SizedBox(width: 10),
              Expanded(flex: 2, child: PrimaryButton('حفظ', onPressed: _saving ? null : _save)),
            ]),
            gap(20),
          ],
        ),
      ),
    );
  }
}

// ====================================================================== LIST
Future<void> deleteRow(BuildContext context, Entity e, Rec r) async {
  final ok = await confirm(context, 'هل تريد حذف هذا السجل نهائيًا؟', title: 'تأكيد الحذف', yes: 'حذف');
  if (!ok) return;
  try {
    final id = intv(r['id']);
    await Db.delete(e.table, id);
    await Svc.auditDb('delete', e.table, id, e.titleOf(r));
    if (context.mounted) toast(context, 'تم الحذف');
  } on DatabaseException {
    if (context.mounted) toast(context, 'لا يمكن الحذف لأن السجل مرتبط بعمليات أخرى', error: true);
  }
}

class EntityBody extends StatefulWidget {
  final Entity entity;
  final Widget? header;
  const EntityBody({super.key, required this.entity, this.header});
  @override
  State<EntityBody> createState() => _EntityBodyState();
}

class _EntityBodyState extends State<EntityBody> {
  String q = '';
  Entity get e => widget.entity;

  Future<void> _open(Rec r) async {
    if (e.onOpen != null) {
      await e.onOpen!(context, r);
    } else if (AppState.i.can(e.perm)) {
      await go(context, EntityForm(entity: e, row: r));
    }
  }

  @override
  Widget build(BuildContext context) {
    final canEdit = AppState.i.can(e.perm);
    final canDel = canEdit && AppState.i.can('delete') && e.canDelete;
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 6), child: SearchField(onChanged: (v) => setState(() => q = v))),
      if (widget.header != null) widget.header!,
      Expanded(
        child: DataView<List<Rec>>(
          load: () => Db.q(e.sql ?? 'SELECT * FROM ${e.table} ORDER BY id DESC'),
          builder: (c, rows) {
            final ql = q.trim().toLowerCase();
            final list = rows.where((r) {
              if (ql.isEmpty) return true;
              return e.searchKeys.any((k) => str(r[k]).toLowerCase().contains(ql));
            }).toList();
            if (list.isEmpty) return EmptyBox(rows.isEmpty ? 'لا توجد سجلات بعد' : 'لا توجد نتائج مطابقة');
            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
              itemCount: list.length,
              itemBuilder: (c, i) {
                final r = list[i];
                final sub = e.subOf?.call(r);
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(8),
                      onTap: () => _open(r),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Row(children: [
                          if (e.leading != null) ...[e.leading!(context, r), const SizedBox(width: 10)],
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(e.titleOf(r), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700), maxLines: 2, overflow: TextOverflow.ellipsis),
                              if (sub != null && sub.isNotEmpty)
                                Text(sub, style: const TextStyle(fontSize: 13, color: C.text2), maxLines: 2, overflow: TextOverflow.ellipsis),
                            ]),
                          ),
                          if (e.trailing != null) ...[const SizedBox(width: 8), e.trailing!(context, r)],
                          if (canDel)
                            IconButton(
                              tooltip: t('حذف'),
                              icon: const Icon(Icons.delete_outline_rounded, color: C.error),
                              onPressed: () => deleteRow(context, e, r),
                            ),
                        ]),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    ]);
  }
}

class EntityPage extends StatelessWidget {
  final Entity entity;
  final Widget? header;
  const EntityPage({super.key, required this.entity, this.header});
  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: entity.title,
      body: EntityBody(entity: entity, header: header),
      fab: AppState.i.can(entity.perm)
          ? FloatingActionButton.extended(
              backgroundColor: C.primary,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: Text('${t('إضافة')} ${t(entity.single)}'),
              onPressed: () => go(context, EntityForm(entity: entity)),
            )
          : null,
    );
  }
}
