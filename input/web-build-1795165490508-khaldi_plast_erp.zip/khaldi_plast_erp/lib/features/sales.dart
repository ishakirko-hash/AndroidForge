import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../core/app_state.dart';
import '../core/charts.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import '../pdf/pdf_service.dart';
import 'entities.dart';
import 'entity.dart';

class SalesPage extends StatefulWidget {
  const SalesPage({super.key});
  @override
  State<SalesPage> createState() => _SalesPageState();
}

class _SalesPageState extends State<SalesPage> {
  int tab = 0;
  String pKey = 'month';
  String from = periodRange('month')[0];
  String to = periodRange('month')[1];
  String q = '';
  String status = 'all';
  String? invFrom;
  String? invTo;

  @override
  Widget build(BuildContext context) {
    final canSell = AppState.i.can('sales');
    Widget? fab;
    if (canSell) {
      fab = tab == 2
          ? FloatingActionButton.extended(
              backgroundColor: C.primary,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.person_add_alt_1_rounded),
              label: Text(t('إضافة عميل')),
              onPressed: () => go(context, EntityForm(entity: customersEntity())),
            )
          : FloatingActionButton.extended(
              backgroundColor: C.primary,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: Text(t('إضافة فاتورة جديدة')),
              onPressed: () => go(context, const InvoiceForm()),
            );
    }
    return PageScaffold(
      title: 'المبيعات',
      logo: true,
      fab: fab,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(50),
        child: SegTabs(labels: const ['نظرة عامة', 'الفواتير', 'العملاء'], index: tab, onChanged: (i) => setState(() => tab = i)),
      ),
      body: tab == 0 ? _overview() : (tab == 1 ? _invoices() : EntityBody(entity: customersEntity())),
    );
  }

  Widget _overview() {
    return DataView<Rec>(
      load: () => Svc.salesOverview(from, to),
      builder: (c, d) {
        final monthly = d['monthly'] as List<Rec>;
        final byProduct = d['by_product'] as List<Rec>;
        final methods = d['methods'] as List<Rec>;
        final recent = d['recent'] as List<Rec>;
        final totalMethods = methods.fold<double>(0, (s, e) => s + dbl(e['amount']));
        final segs = <Seg>[
          for (var i = 0; i < byProduct.length; i++) Seg(dbl(byProduct[i]['amount']), segColors[i % segColors.length], str(byProduct[i]['name'])),
        ];
        return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
          PeriodBar(
            value: pKey,
            from: from,
            to: to,
            onChanged: (k, f, tt) => setState(() {
              pKey = k;
              from = f;
              to = tt;
            }),
          ),
          gap(10),
          kpiRow(
            KpiTile(icon: Icons.shopping_cart_rounded, color: C.success, title: 'إجمالي المبيعات', value: fmt(dbl(d['total'])), unit: 'دج'),
            KpiTile(icon: Icons.receipt_long_rounded, color: C.primary, title: 'عدد الفواتير', value: fmt(dbl(d['count']))),
          ),
          kpiRow(
            KpiTile(icon: Icons.view_in_ar_rounded, color: C.warning, title: 'الكمية المباعة', value: fmt(dbl(d['qty'])), unit: 'قطعة'),
            KpiTile(icon: Icons.savings_rounded, color: C.purple, title: 'المبلغ غير المحصل', value: fmt(dbl(d['unpaid'])), unit: 'دج'),
          ),
          Panel(
            title: 'تطور المبيعات الشهرية (دج)',
            icon: Icons.show_chart_rounded,
            child: LineChart(values: [for (final m in monthly) dbl(m['value'])], labels: [for (final m in monthly) str(m['label'])]),
          ),
          Panel(
            title: 'المبيعات حسب المنتج',
            icon: Icons.view_in_ar_rounded,
            child: segs.isEmpty
                ? const EmptyBox('لا توجد مبيعات في هذه الفترة')
                : DonutLegend(segs: segs, center: compact(dbl(d['total'])), sub: 'دج'),
          ),
          Panel(
            title: 'طرق الدفع',
            icon: Icons.credit_card_rounded,
            child: methods.isEmpty
                ? const EmptyBox('لا توجد مدفوعات في هذه الفترة')
                : Column(children: [
                    for (var i = 0; i < methods.length; i++)
                      HBar(methodLabel(str(methods[i]['m'])), totalMethods <= 0 ? 0 : dbl(methods[i]['amount']) / totalMethods,
                          segColors[i % segColors.length], '${totalMethods <= 0 ? 0 : (dbl(methods[i]['amount']) / totalMethods * 100).round()}%'),
                  ]),
          ),
          Panel(
            title: 'آخر الفواتير',
            icon: Icons.description_rounded,
            trailing: TextButton(onPressed: () => setState(() => tab = 1), child: Text(t('عرض الكل'))),
            padding: const EdgeInsets.all(6),
            child: recent.isEmpty
                ? const EmptyBox('لا توجد فواتير في هذه الفترة')
                : InkWell(
                    child: simpleTable(
                      ['رقم الفاتورة', 'العميل', 'التاريخ', 'المبلغ (دج)', 'الحالة'],
                      [
                        for (final r in recent)
                          [
                            '#${str(r['number'])}',
                            str(r['customer_name']),
                            showDate(str(r['date'])),
                            fmt(dbl(r['total'])),
                            invoiceStatus(str(r['status'])).label,
                          ],
                      ],
                      flex: const [1.3, 1.5, 1.3, 1.3, 1.1],
                    ),
                  ),
          ),
        ]);
      },
    );
  }

  Widget _invoices() {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
        child: Row(children: [
          Expanded(child: SearchField(onChanged: (v) => setState(() => q = v), hint: 'بحث برقم الفاتورة أو العميل')),
          const SizedBox(width: 8),
          Material(
            color: invFrom == null ? Colors.white : C.light,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8), side: const BorderSide(color: C.border)),
            child: InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () async {
                if (invFrom != null) {
                  setState(() {
                    invFrom = null;
                    invTo = null;
                  });
                  return;
                }
                final r = await showDateRangePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100));
                if (r != null) {
                  setState(() {
                    invFrom = ymd(r.start);
                    invTo = ymd(r.end);
                  });
                }
              },
              child: SizedBox(width: 48, height: 48, child: Icon(invFrom == null ? Icons.filter_alt_outlined : Icons.filter_alt_off_rounded, color: C.primary)),
            ),
          ),
        ]),
      ),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(children: [
          for (final s in const ['all', 'paid', 'partial', 'unpaid', 'cancelled'])
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 6),
              child: ChoiceChip(
                label: Text(s == 'all' ? t('الكل') : invoiceStatus(s).label),
                selected: status == s,
                onSelected: (_) => setState(() => status = s),
              ),
            ),
        ]),
      ),
      Expanded(
        child: DataView<List<Rec>>(
          load: () => Db.q('SELECT * FROM invoices ORDER BY date DESC, id DESC'),
          builder: (c, rows) {
            final ql = q.trim().toLowerCase();
            final list = rows.where((r) {
              if (status != 'all' && r['status'] != status) return false;
              if (invFrom != null && str(r['date']).compareTo(invFrom!) < 0) return false;
              if (invTo != null && str(r['date']).compareTo(invTo!) > 0) return false;
              if (ql.isEmpty) return true;
              return str(r['number']).toLowerCase().contains(ql) || str(r['customer_name']).toLowerCase().contains(ql);
            }).toList();
            if (list.isEmpty) return const EmptyBox('لا توجد فواتير مطابقة');
            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
              itemCount: list.length,
              itemBuilder: (c, i) {
                final r = list[i];
                final st = invoiceStatus(str(r['status']));
                final rem = dbl(r['total']) - dbl(r['paid']);
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(8),
                      onTap: () => go(context, InvoiceView(id: intv(r['id']))),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Row(children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('#${str(r['number'])}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                              Text(str(r['customer_name']).isEmpty ? t('عميل عابر') : str(r['customer_name']),
                                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, color: C.text2)),
                              Text(showDate(str(r['date'])), style: const TextStyle(fontSize: 12, color: C.text2)),
                            ]),
                          ),
                          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(money(dbl(r['total'])), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                            if (r['status'] != 'cancelled' && rem > 0.005)
                              Text('${t('المتبقي')}: ${money(rem)}', style: const TextStyle(fontSize: 12, color: C.error, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 3),
                            Tag(st.label, st.color),
                          ]),
                        ]),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    ]);
  }
}

// ====================================================================== INVOICE FORM
class _Line {
  int? productId;
  String name = '';
  double stock = 0;
  final TextEditingController qty = TextEditingController();
  final TextEditingController price = TextEditingController();
  double get total => (parseNum(qty.text) ?? 0) * (parseNum(price.text) ?? 0);
}

class InvoiceForm extends StatefulWidget {
  final int? id;
  final int? customerId;
  const InvoiceForm({super.key, this.id, this.customerId});
  @override
  State<InvoiceForm> createState() => _InvoiceFormState();
}

class _InvoiceFormState extends State<InvoiceForm> {
  final _key = GlobalKey<FormState>();
  bool _loading = true;
  bool _saving = false;
  String number = '';
  String date = today();
  int? customerId;
  final customerName = TextEditingController();
  final discount = TextEditingController(text: '0');
  final taxRate = TextEditingController(text: '0');
  final paid = TextEditingController(text: '0');
  final notes = TextEditingController();
  String method = 'cash';
  final List<_Line> lines = [];
  List<Rec> products = [];
  List<Rec> customers = [];
  double _oldPaid = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    products = await Db.q('SELECT id, name, price, qty FROM products WHERE active = 1 ORDER BY name');
    customers = await Db.q('SELECT id, name FROM customers ORDER BY name');
    taxRate.text = AppState.i.get('tax_rate', '0');
    if (widget.id != null) {
      final inv = await Db.one('SELECT * FROM invoices WHERE id = ?', [widget.id]);
      final items = await Db.q('SELECT * FROM invoice_items WHERE invoice_id = ?', [widget.id]);
      if (inv != null) {
        number = str(inv['number']);
        date = str(inv['date']);
        customerId = inv['customer_id'] as int?;
        customerName.text = str(inv['customer_name']);
        discount.text = numText(inv['discount']);
        taxRate.text = numText(inv['tax_rate']);
        paid.text = numText(inv['paid']);
        _oldPaid = dbl(inv['paid']);
        notes.text = str(inv['notes']);
        method = str(inv['method']).isEmpty ? 'cash' : str(inv['method']);
        for (final it in items) {
          final l = _Line();
          l.productId = it['product_id'] as int?;
          l.name = str(it['name']);
          l.qty.text = numText(it['qty']);
          l.price.text = numText(it['unit_price']);
          final pr = products.where((p) => p['id'] == l.productId).toList();
          // available stock for this invoice = current stock + what this invoice already took
          l.stock = (pr.isEmpty ? 0 : dbl(pr.first['qty'])) + dbl(it['qty']);
          lines.add(l);
        }
      }
    } else {
      number = await Svc.nextInvoiceNumber();
      if (widget.customerId != null) customerId = widget.customerId;
      lines.add(_Line());
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  void dispose() {
    customerName.dispose();
    discount.dispose();
    taxRate.dispose();
    paid.dispose();
    notes.dispose();
    for (final l in lines) {
      l.qty.dispose();
      l.price.dispose();
    }
    super.dispose();
  }

  double get subtotal => r2(lines.fold<double>(0, (s, l) => s + l.total));
  double get disc => r2(parseNum(discount.text) ?? 0);
  double get tax => r2(((subtotal - disc) > 0 ? (subtotal - disc) : 0) * (parseNum(taxRate.text) ?? 0) / 100);
  double get total => r2(subtotal - disc + tax);
  double get paidV => r2(parseNum(paid.text) ?? 0);

  Future<void> _save() async {
    if (_saving) return;
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      String cname = customerName.text.trim();
      if (customerId != null) {
        final c = customers.where((x) => x['id'] == customerId).toList();
        if (c.isNotEmpty) cname = str(c.first['name']);
      }
      final id = await Svc.saveInvoice(
        id: widget.id,
        head: {
          'number': number,
          'date': date,
          'customer_id': customerId,
          'customer_name': cname,
          'discount': disc,
          'tax_rate': parseNum(taxRate.text) ?? 0,
          'paid': paidV,
          'method': method,
          'notes': notes.text.trim(),
        },
        items: [
          for (final l in lines)
            {'product_id': l.productId, 'name': l.name, 'qty': parseNum(l.qty.text) ?? 0, 'unit_price': parseNum(l.price.text) ?? 0},
        ],
      );
      if (!mounted) return;
      toast(context, 'تم حفظ الفاتورة بنجاح');
      if (widget.id == null) {
        Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => InvoiceView(id: id)));
      } else {
        Navigator.pop(context, true);
      }
    } on AppErr catch (e) {
      if (mounted) toast(context, e.msg, error: true);
    } on DatabaseException {
      if (mounted) toast(context, 'تعذر حفظ الفاتورة', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return PageScaffold(title: widget.id == null ? 'فاتورة جديدة' : 'تعديل الفاتورة', body: const Center(child: CircularProgressIndicator()));
    }
    final remaining = total - paidV;
    return PageScaffold(
      title: widget.id == null ? 'فاتورة جديدة' : 'تعديل الفاتورة',
      body: Form(
        key: _key,
        child: ListView(padding: const EdgeInsets.all(12), children: [
          Panel(
            title: 'بيانات الفاتورة',
            icon: Icons.receipt_long_rounded,
            child: Column(children: [
              KV('رقم الفاتورة', '#$number', bold: true),
              gap(6),
              DateField(label: 'تاريخ الفاتورة', value: date, required: true, onChanged: (v) => setState(() => date = v ?? date)),
              gap(10),
              SelectField<int>(
                label: 'العميل',
                value: customerId,
                allowClear: true,
                options: [for (final c in customers) Opt<int>(c['id'] as int, str(c['name']))],
                onChanged: (v) => setState(() => customerId = v),
              ),
              if (customerId == null) ...[
                gap(10),
                tf(customerName, 'اسم العميل (اختياري)'),
              ],
            ]),
          ),
          for (var i = 0; i < lines.length; i++) _lineCard(i),
          OutlinedButton.icon(
            onPressed: () => setState(() => lines.add(_Line())),
            icon: const Icon(Icons.add_rounded),
            label: Text(t('إضافة منتج')),
          ),
          gap(10),
          Panel(
            title: 'الحساب والدفع',
            icon: Icons.calculate_rounded,
            child: Column(children: [
              Row(children: [
                Expanded(child: tf(discount, 'الخصم', number: true, suffix: 'دج', onChanged: (_) => setState(() {}))),
                const SizedBox(width: 8),
                Expanded(child: tf(taxRate, 'الضريبة %', number: true, onChanged: (_) => setState(() {}))),
              ]),
              gap(10),
              tf(paid, 'المبلغ المدفوع', number: true, suffix: 'دج', onChanged: (_) => setState(() {})),
              gap(10),
              SelectField<String>(
                label: 'طريقة الدفع',
                value: method,
                options: [for (final k in methodLabels.keys) Opt<String>(k, t(methodLabels[k]!))],
                onChanged: (v) => setState(() => method = v ?? 'cash'),
              ),
              gap(10),
              tf(notes, 'ملاحظات', maxLines: 2),
              const Divider(height: 24),
              KV('المجموع الفرعي', money(subtotal)),
              KV('الخصم', money(disc)),
              KV('الضريبة', money(tax)),
              KV('الإجمالي', money(total), bold: true),
              KV('المدفوع', money(paidV), vColor: C.success),
              KV('المتبقي', money(remaining < 0 ? 0 : remaining), vColor: remaining > 0.005 ? C.error : C.success, bold: true),
              if (widget.id != null && _oldPaid > 0) Text(t('الدفعات السابقة محفوظة، ويمكنك زيادة المبلغ المدفوع فقط'), style: const TextStyle(fontSize: 12, color: C.text2)),
            ]),
          ),
          gap(4),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: _saving ? null : () => Navigator.pop(context), child: Text(t('إلغاء')))),
            const SizedBox(width: 10),
            Expanded(flex: 2, child: PrimaryButton('حفظ الفاتورة', onPressed: _saving ? null : _save)),
          ]),
          gap(24),
        ]),
      ),
    );
  }

  Widget _lineCard(int i) {
    final l = lines[i];
    return Panel(
      title: '${t('المنتج')} ${i + 1}',
      icon: Icons.view_in_ar_rounded,
      trailing: lines.length > 1
          ? IconButton(
              icon: const Icon(Icons.delete_outline_rounded, color: C.error),
              onPressed: () => setState(() => lines.removeAt(i)),
            )
          : null,
      child: Column(children: [
        SelectField<int>(
          label: 'المنتج',
          value: l.productId,
          required: true,
          options: [for (final p in products) Opt<int>(p['id'] as int, '${str(p['name'])}  (${fmt(dbl(p['qty']))})')],
          onChanged: (v) => setState(() {
            l.productId = v;
            final pr = products.where((p) => p['id'] == v).toList();
            if (pr.isNotEmpty) {
              l.name = str(pr.first['name']);
              l.stock = dbl(pr.first['qty']);
              if (l.price.text.isEmpty || (parseNum(l.price.text) ?? 0) == 0) l.price.text = numText(pr.first['price']);
            }
          }),
        ),
        gap(10),
        Row(children: [
          Expanded(child: tf(l.qty, 'الكمية', integer: true, required: true, positive: true, onChanged: (_) => setState(() {}))),
          const SizedBox(width: 8),
          Expanded(child: tf(l.price, 'سعر الوحدة', number: true, required: true, suffix: 'دج', onChanged: (_) => setState(() {}))),
        ]),
        gap(6),
        KV('إجمالي السطر', money(r2(l.total)), bold: true),
        if (l.productId != null)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: Text('${t('المتوفر في المخزون')}: ${fmt(l.stock)}',
                style: TextStyle(fontSize: 12, color: (parseNum(l.qty.text) ?? 0) > l.stock ? C.error : C.text2)),
          ),
      ]),
    );
  }
}

// ====================================================================== INVOICE VIEW
class InvoiceView extends StatelessWidget {
  final int id;
  const InvoiceView({super.key, required this.id});

  Future<void> _pay(BuildContext context, Rec inv) async {
    final remaining = dbl(inv['total']) - dbl(inv['paid']);
    final amount = TextEditingController(text: numText(r2(remaining)));
    final notes = TextEditingController();
    String method = 'cash';
    String date = today();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.fromLTRB(14, 14, 14, MediaQuery.of(ctx).viewInsets.bottom + 14),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(t('إضافة دفعة'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            gap(12),
            tf(amount, 'المبلغ', number: true, positive: true, suffix: 'دج'),
            gap(10),
            DateField(label: 'التاريخ', value: date, onChanged: (v) => setS(() => date = v ?? date)),
            gap(10),
            SelectField<String>(
              label: 'طريقة الدفع',
              value: method,
              options: [for (final k in methodLabels.keys) Opt<String>(k, t(methodLabels[k]!))],
              onChanged: (v) => setS(() => method = v ?? 'cash'),
            ),
            gap(10),
            tf(notes, 'ملاحظات'),
            gap(12),
            PrimaryButton('حفظ الدفعة', onPressed: () async {
              try {
                await Svc.addPayment(id, parseNum(amount.text) ?? 0, method, date, notes.text.trim());
                if (ctx.mounted) Navigator.pop(ctx);
                if (context.mounted) toast(context, 'تم تسجيل الدفعة');
              } on AppErr catch (e) {
                if (ctx.mounted) toast(ctx, e.msg, error: true);
              }
            }),
          ]),
        ),
      ),
    );
    amount.dispose();
    notes.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'تفاصيل الفاتورة',
      body: DataView<Rec>(
        load: () async {
          final inv = await Db.one('SELECT * FROM invoices WHERE id = ?', [id]);
          final items = await Db.q('SELECT * FROM invoice_items WHERE invoice_id = ?', [id]);
          final pays = await Db.q('SELECT * FROM payments WHERE invoice_id = ? ORDER BY date DESC, id DESC', [id]);
          return {'inv': inv, 'items': items, 'pays': pays};
        },
        builder: (ctx, d) {
          final inv = d['inv'] as Rec?;
          if (inv == null) return const EmptyBox('الفاتورة غير موجودة');
          final items = d['items'] as List<Rec>;
          final pays = d['pays'] as List<Rec>;
          final st = invoiceStatus(str(inv['status']));
          final cancelled = inv['status'] == 'cancelled';
          final remaining = dbl(inv['total']) - dbl(inv['paid']);
          final canSell = AppState.i.can('sales');
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              title: '#${str(inv['number'])}',
              icon: Icons.receipt_long_rounded,
              trailing: Tag(st.label, st.color),
              child: Column(children: [
                KV('التاريخ', showDate(str(inv['date']))),
                KV('العميل', str(inv['customer_name']).isEmpty ? t('عميل عابر') : str(inv['customer_name'])),
                KV('طريقة الدفع', methodLabel(str(inv['method']))),
                if (str(inv['notes']).isNotEmpty) KV('ملاحظات', str(inv['notes'])),
              ]),
            ),
            Panel(
              title: 'المنتجات',
              icon: Icons.view_in_ar_rounded,
              padding: const EdgeInsets.all(6),
              child: simpleTable(
                ['المنتج', 'الكمية', 'السعر', 'الإجمالي'],
                [for (final i in items) [str(i['name']), fmt(dbl(i['qty'])), fmt(dbl(i['unit_price'])), fmt(dbl(i['total']))]],
                flex: const [2, 1, 1.2, 1.4],
              ),
            ),
            Panel(
              title: 'الإجماليات',
              icon: Icons.calculate_rounded,
              child: Column(children: [
                KV('المجموع الفرعي', money(dbl(inv['subtotal']))),
                KV('الخصم', money(dbl(inv['discount']))),
                KV('الضريبة (${fmt2(dbl(inv['tax_rate']))}%)', money(dbl(inv['tax']))),
                KV('الإجمالي', money(dbl(inv['total'])), bold: true),
                KV('المدفوع', money(dbl(inv['paid'])), vColor: C.success),
                KV('المتبقي', money(cancelled ? 0 : remaining), vColor: remaining > 0.005 && !cancelled ? C.error : C.success, bold: true),
              ]),
            ),
            if (pays.isNotEmpty)
              Panel(
                title: 'سجل الدفعات',
                icon: Icons.payments_rounded,
                child: Column(children: [
                  for (final p in pays) KV('${showDate(str(p['date']))} • ${methodLabel(str(p['method']))}', money(dbl(p['amount']))),
                ]),
              ),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.print_rounded),
                  label: Text(t('طباعة')),
                  onPressed: () async {
                    try {
                      await PdfService.printBytes(await PdfService.invoice(id), 'invoice_${inv['number']}');
                    } catch (e) {
                      if (context.mounted) toast(context, 'تعذر إنشاء ملف PDF', error: true);
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.picture_as_pdf_rounded),
                  label: Text(t('تصدير PDF')),
                  onPressed: () async {
                    try {
                      await PdfService.shareBytes(await PdfService.invoice(id), 'invoice_${inv['number']}.pdf');
                    } catch (e) {
                      if (context.mounted) toast(context, 'تعذر إنشاء ملف PDF', error: true);
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.share_rounded),
                  label: Text(t('مشاركة')),
                  onPressed: () async {
                    try {
                      await PdfService.shareBytes(await PdfService.invoice(id), 'invoice_${inv['number']}.pdf');
                    } catch (e) {
                      if (context.mounted) toast(context, 'تعذر إنشاء ملف PDF', error: true);
                    }
                  },
                ),
              ),
            ]),
            gap(8),
            if (canSell && !cancelled) ...[
              if (remaining > 0.005) PrimaryButton('إضافة دفعة', icon: Icons.payments_rounded, onPressed: () => _pay(context, inv)),
              gap(8),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.edit_rounded),
                    label: Text(t('تعديل')),
                    onPressed: () => go(context, InvoiceForm(id: id)),
                  ),
                ),
                const SizedBox(width: 8),
                if (AppState.i.can('delete'))
                  Expanded(
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(foregroundColor: C.error, side: const BorderSide(color: C.error)),
                      icon: const Icon(Icons.cancel_rounded),
                      label: Text(t('إلغاء الفاتورة')),
                      onPressed: () async {
                        final ok = await confirm(context, 'سيتم إلغاء الفاتورة وإرجاع الكميات إلى المخزون. هل تريد المتابعة؟',
                            title: 'إلغاء الفاتورة', yes: 'إلغاء الفاتورة');
                        if (!ok) return;
                        try {
                          await Svc.cancelInvoice(id);
                          if (context.mounted) toast(context, 'تم إلغاء الفاتورة');
                        } on AppErr catch (e) {
                          if (context.mounted) toast(context, e.msg, error: true);
                        }
                      },
                    ),
                  ),
              ]),
            ],
            gap(24),
          ]);
        },
      ),
    );
  }
}
