import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../core/app_state.dart';
import '../core/charts.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import 'entities.dart';
import 'entity.dart';
import 'machines.dart';
import 'reports.dart';

String _shortDay(DateTime d) {
  final n = weekdayName(d);
  return S.ar ? n : n.substring(0, 3);
}

class ProductionPage extends StatefulWidget {
  const ProductionPage({super.key});
  @override
  State<ProductionPage> createState() => _ProductionPageState();
}

class _ProductionPageState extends State<ProductionPage> {
  String pKey = 'today';
  String from = today();
  String to = today();

  Future<Rec> _data() async {
    final a = [from, to];
    const base = "status = 'done' AND date BETWEEN ? AND ?";
    final accepted = await Db.sum('SELECT COALESCE(SUM(accepted),0) FROM production WHERE $base', a);
    final actual = await Db.sum('SELECT COALESCE(SUM(actual),0) FROM production WHERE $base', a);
    final defective = await Db.sum('SELECT COALESCE(SUM(defective),0) FROM production WHERE $base', a);
    final target = await Db.sum('SELECT COALESCE(SUM(target),0) FROM production WHERE $base', a);
    final duration = await Db.sum('SELECT COALESCE(SUM(duration_min),0) FROM production WHERE $base', a);
    final downtime = await Db.sum('SELECT COALESCE(SUM(downtime_min),0) FROM production WHERE $base', a);
    final byProduct = await Db.q(
        "SELECT p.name AS name, SUM(pr.accepted) AS made FROM production pr JOIN products p ON p.id = pr.product_id WHERE pr.status = 'done' AND pr.date BETWEEN ? AND ? GROUP BY p.id ORDER BY made DESC",
        a);
    final consumption = await Db.q(
        "SELECT m.name AS name, m.unit AS unit, SUM(c.actual) AS kg FROM consumption c JOIN production pr ON pr.id = c.production_id JOIN materials m ON m.id = c.material_id WHERE pr.status = 'done' AND pr.date BETWEEN ? AND ? GROUP BY m.id ORDER BY kg DESC",
        a);
    final machines = await Db.q(
        "SELECT m.*, COALESCE((SELECT SUM(accepted) FROM production pr WHERE pr.machine_id = m.id AND pr.status = 'done' AND pr.date BETWEEN ? AND ?),0) AS output FROM machines m ORDER BY m.name",
        a);
    final records = await Db.q(
        'SELECT pr.*, p.name AS product, m.name AS machine, e.name AS employee FROM production pr JOIN products p ON p.id = pr.product_id LEFT JOIN machines m ON m.id = pr.machine_id LEFT JOIN employees e ON e.id = pr.employee_id WHERE pr.date BETWEEN ? AND ? ORDER BY pr.date DESC, pr.id DESC LIMIT 60',
        a);
    final now = DateTime.now();
    final days = <Rec>[];
    for (var i = 6; i >= 0; i--) {
      final d = DateTime(now.year, now.month, now.day - i);
      final k = ymd(d);
      final tg = await Db.sum("SELECT COALESCE(SUM(target),0) FROM production WHERE status = 'done' AND date = ?", [k]);
      final ac = await Db.sum("SELECT COALESCE(SUM(accepted),0) FROM production WHERE status = 'done' AND date = ?", [k]);
      days.add({'label': _shortDay(d), 'target': tg, 'actual': ac});
    }
    return {
      'accepted': accepted,
      'actual': actual,
      'defective': defective,
      'target': target,
      'duration': duration,
      'downtime': downtime,
      'by_product': byProduct,
      'consumption': consumption,
      'machines': machines,
      'records': records,
      'days': days,
    };
  }

  @override
  Widget build(BuildContext context) {
    final can = AppState.i.can('production');
    return PageScaffold(
      title: 'الإنتاج',
      logo: true,
      fab: can
          ? FloatingActionButton.extended(
              backgroundColor: C.primary,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: Text(t('تسجيل إنتاج جديد')),
              onPressed: () => go(context, const ProductionForm()),
            )
          : null,
      body: DataView<Rec>(
        load: _data,
        builder: (c, d) {
          final accepted = dbl(d['accepted']);
          final actual = dbl(d['actual']);
          final defective = dbl(d['defective']);
          final target = dbl(d['target']);
          final duration = dbl(d['duration']);
          final downtime = dbl(d['downtime']);
          final completion = target > 0 ? accepted / target * 100 : 0.0;
          final remaining = target > accepted ? target - accepted : 0.0;
          final speed = duration > 0 ? accepted / (duration / 60) : 0.0;
          final byProduct = d['by_product'] as List<Rec>;
          final cons = d['consumption'] as List<Rec>;
          final machines = d['machines'] as List<Rec>;
          final records = d['records'] as List<Rec>;
          final days = d['days'] as List<Rec>;
          final segs = <Seg>[
            for (var i = 0; i < byProduct.length; i++) Seg(dbl(byProduct[i]['made']), segColors[i % segColors.length], str(byProduct[i]['name'])),
          ];
          return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
            PeriodBar(
              value: pKey,
              from: from,
              to: to,
              onChanged: (k, f, tt) => setState(() {
                pKey = k;
                from = f;
                to = tt;
              }),
            ),
            gap(10),
            kpiRow(
              KpiTile(icon: Icons.bar_chart_rounded, color: C.success, title: 'الإنتاج الفعلي', value: fmt(accepted), unit: 'قطعة'),
              KpiTile(icon: Icons.track_changes_rounded, color: C.primary, title: 'الهدف', value: fmt(target), unit: 'قطعة'),
            ),
            kpiRow(
              KpiTile(
                  icon: Icons.inventory_2_rounded,
                  color: C.error,
                  title: 'المنتج المعيب',
                  value: fmt(defective),
                  unit: actual > 0 ? '${(defective / actual * 100).toStringAsFixed(1)}%' : 'قطعة'),
              KpiTile(icon: Icons.hourglass_bottom_rounded, color: C.warning, title: 'المتبقي من الهدف', value: fmt(remaining), unit: 'قطعة'),
            ),
            Panel(
              title: 'نسبة الإنجاز',
              icon: Icons.donut_large_rounded,
              child: Row(children: [
                Donut(
                  size: 112,
                  center: '${completion.toStringAsFixed(1)}%',
                  sub: 'نسبة الإنجاز',
                  segs: [Seg(accepted, C.success, ''), Seg(remaining, C.warning, '')],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(children: [
                    KV('سرعة الإنتاج', '${fmt(speed)} ${t('قطعة/ساعة')}'),
                    KV('وقت التشغيل', '${fmt2(duration / 60)} ${t('ساعة')}'),
                    KV('التوقفات', '${fmt(downtime)} ${t('دقيقة')}'),
                  ]),
                ),
              ]),
            ),
            Panel(
              title: 'تطور الإنتاج اليومي (آخر 7 أيام)',
              icon: Icons.bar_chart_rounded,
              child: Column(children: [
                BarChart(
                  target: [for (final x in days) dbl(x['target'])],
                  actual: [for (final x in days) dbl(x['actual'])],
                  labels: [for (final x in days) str(x['label'])],
                ),
                const SizedBox(height: 6),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(width: 10, height: 10, color: C.primary),
                  const SizedBox(width: 4),
                  Text(t('الإنتاج الفعلي'), style: const TextStyle(fontSize: 12)),
                  const SizedBox(width: 14),
                  Container(width: 10, height: 10, color: tint(C.secondary, 0.35)),
                  const SizedBox(width: 4),
                  Text(t('الهدف'), style: const TextStyle(fontSize: 12)),
                ]),
              ]),
            ),
            Panel(
              title: 'الإنتاج حسب المنتج',
              icon: Icons.view_in_ar_rounded,
              child: segs.isEmpty ? const EmptyBox('لا يوجد إنتاج في هذه الفترة') : DonutLegend(segs: segs, center: fmt(accepted), sub: 'قطعة'),
            ),
            Panel(
              title: 'استهلاك المواد',
              icon: Icons.layers_rounded,
              child: cons.isEmpty
                  ? const EmptyBox('لا يوجد استهلاك مسجل في هذه الفترة')
                  : Column(children: [for (final x in cons) KV(str(x['name']), '${fmt2(dbl(x['kg']))} ${unitLabel(str(x['unit']))}')]),
            ),
            Panel(
              title: 'حالة الآلات',
              icon: Icons.settings_suggest_rounded,
              trailing: TextButton(onPressed: () => go(context, const MachinesPage()), child: Text(t('عرض الكل'))),
              child: machines.isEmpty
                  ? const EmptyBox('لا توجد آلات')
                  : SizedBox(
                      height: 150,
                      child: ListView(scrollDirection: Axis.horizontal, children: [
                        for (final m in machines) _machineCard(m),
                      ]),
                    ),
            ),
            Panel(
              title: 'سجلات الإنتاج',
              icon: Icons.assignment_rounded,
              padding: const EdgeInsets.all(8),
              child: records.isEmpty
                  ? const EmptyBox('لا توجد سجلات إنتاج في هذه الفترة')
                  : Column(children: [for (final r in records) _recordTile(r)]),
            ),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.calculate_rounded),
                  label: Text(t('حاسبة الوزن')),
                  onPressed: () => go(context, const WeightCalcPage()),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.analytics_rounded),
                  label: Text(t('تقارير الإنتاج')),
                  onPressed: () => go(context, const ReportsPage(initial: 'production')),
                ),
              ),
            ]),
          ]);
        },
      ),
    );
  }

  Widget _machineCard(Rec m) {
    final st = machineStatus(str(m['status']));
    return Container(
      width: 130,
      margin: const EdgeInsetsDirectional.only(end: 8),
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () => go(context, MachineDetail(id: intv(m['id']))),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Column(children: [
              machineThumb(m['image'] as String?),
              const SizedBox(height: 4),
              Text(str(m['name']), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              Tag(st.label, st.color),
              const SizedBox(height: 3),
              Text('${fmt(dbl(m['output']))} ${t('قطعة')}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _recordTile(Rec r) {
    final st = productionStatus(str(r['status']));
    final target = dbl(r['target']);
    return InkWell(
      onTap: () => go(context, ProductionView(id: intv(r['id']))),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.border))),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('#${str(r['code'])} • ${str(r['product'])}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              Text(
                  '${showDate(str(r['date']))} ${str(r['time'])} • ${shiftLabel(str(r['shift_kind']))}${str(r['machine']).isEmpty ? '' : ' • ${str(r['machine'])}'}',
                  style: const TextStyle(fontSize: 12, color: C.text2)),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('${fmt(dbl(r['accepted']))}${target > 0 ? ' / ${fmt(target)}' : ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
            Tag(st.label, st.color),
          ]),
        ]),
      ),
    );
  }
}

// ====================================================================== FORM
class _Cons {
  int? materialId;
  String unit = 'kg';
  double stock = 0;
  final TextEditingController perPiece = TextEditingController();
  final TextEditingController actual = TextEditingController();
}

class ProductionForm extends StatefulWidget {
  final int? id;
  const ProductionForm({super.key, this.id});
  @override
  State<ProductionForm> createState() => _ProductionFormState();
}

class _ProductionFormState extends State<ProductionForm> {
  final _key = GlobalKey<FormState>();
  bool loading = true;
  bool saving = false;
  String date = today();
  final time = TextEditingController(text: hm(DateTime.now()));
  String shift = currentShiftKind();
  int? machineId;
  int? productId;
  int? employeeId;
  final target = TextEditingController();
  final actual = TextEditingController();
  final defective = TextEditingController(text: '0');
  final duration = TextEditingController();
  final downtime = TextEditingController(text: '0');
  final notes = TextEditingController();
  final List<_Cons> cons = [];
  List<Rec> products = [];
  List<Rec> machines = [];
  List<Rec> employees = [];
  List<Rec> materials = [];
  String code = '';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    products = await Db.q('SELECT id, name, weight_g FROM products WHERE active = 1 ORDER BY name');
    machines = await Db.q('SELECT id, name FROM machines ORDER BY name');
    employees = await Db.q("SELECT id, name FROM employees WHERE status = 'active' ORDER BY name");
    materials = await Db.q('SELECT id, name, unit, qty FROM materials ORDER BY name');
    if (widget.id != null) {
      final r = await Db.one('SELECT * FROM production WHERE id = ?', [widget.id]);
      final cs = await Db.q('SELECT * FROM consumption WHERE production_id = ?', [widget.id]);
      if (r != null) {
        code = str(r['code']);
        date = str(r['date']);
        time.text = str(r['time']);
        shift = str(r['shift_kind']).isEmpty ? shift : str(r['shift_kind']);
        machineId = r['machine_id'] as int?;
        productId = r['product_id'] as int?;
        employeeId = r['employee_id'] as int?;
        target.text = numText(r['target']);
        actual.text = numText(r['actual']);
        defective.text = numText(r['defective']);
        duration.text = numText(r['duration_min']);
        downtime.text = numText(r['downtime_min']);
        notes.text = str(r['notes']);
        for (final c in cs) {
          final x = _Cons();
          x.materialId = c['material_id'] as int?;
          x.perPiece.text = numText(c['per_piece_g']);
          x.actual.text = numText(c['actual']);
          _syncMat(x);
          cons.add(x);
        }
      }
    } else {
      cons.add(_Cons());
    }
    if (mounted) setState(() => loading = false);
  }

  void _syncMat(_Cons x) {
    final m = materials.where((e) => e['id'] == x.materialId).toList();
    if (m.isNotEmpty) {
      x.unit = str(m.first['unit']);
      x.stock = dbl(m.first['qty']);
    }
  }

  @override
  void dispose() {
    time.dispose();
    target.dispose();
    actual.dispose();
    defective.dispose();
    duration.dispose();
    downtime.dispose();
    notes.dispose();
    for (final c in cons) {
      c.perPiece.dispose();
      c.actual.dispose();
    }
    super.dispose();
  }

  double get act => parseNum(actual.text) ?? 0;
  double get def => parseNum(defective.text) ?? 0;
  double get accepted => act - def;
  double planned(_Cons c) => r2((parseNum(c.perPiece.text) ?? 0) * act / 1000);

  Future<void> _save() async {
    if (saving) return;
    if (!_key.currentState!.validate()) return;
    if (productId == null) {
      toast(context, 'اختر المنتج', error: true);
      return;
    }
    final consRows = <Rec>[
      for (final c in cons)
        {
          'material_id': c.materialId,
          'per_piece_g': parseNum(c.perPiece.text) ?? 0,
          'planned': planned(c),
          'actual': parseNum(c.actual.text) ?? 0,
        },
    ];
    final short = await Svc.materialShortages(consRows, editingProductionId: widget.id);
    if (short.isNotEmpty && mounted) {
      final ok = await confirm(context, '${t('المخزون غير كافٍ للمواد التالية')}:\n${short.join('\n')}\n${t('هل تريد المتابعة؟')}',
          title: 'تنبيه المخزون', yes: 'متابعة', danger: false);
      if (!ok) return;
    }
    setState(() => saving = true);
    try {
      await Svc.saveProduction(
        id: widget.id,
        head: {
          'date': date,
          'time': time.text.trim(),
          'shift_kind': shift,
          'machine_id': machineId,
          'product_id': productId,
          'employee_id': employeeId,
          'target': parseNum(target.text) ?? 0,
          'actual': act,
          'defective': def,
          'duration_min': parseNum(duration.text) ?? 0,
          'downtime_min': parseNum(downtime.text) ?? 0,
          'notes': notes.text.trim(),
        },
        cons: consRows,
      );
      if (!mounted) return;
      toast(context, 'تم حفظ سجل الإنتاج');
      Navigator.pop(context, true);
    } on AppErr catch (e) {
      if (mounted) toast(context, e.msg, error: true);
    } on DatabaseException {
      if (mounted) toast(context, 'تعذر حفظ السجل', error: true);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.id == null ? 'تسجيل إنتاج جديد' : 'تعديل سجل الإنتاج';
    if (loading) return PageScaffold(title: title, body: const Center(child: CircularProgressIndicator()));
    return PageScaffold(
      title: title,
      body: Form(
        key: _key,
        child: ListView(padding: const EdgeInsets.all(12), children: [
          Panel(
            title: 'بيانات الدفعة',
            icon: Icons.precision_manufacturing_rounded,
            child: Column(children: [
              if (code.isNotEmpty) KV('رقم السجل', '#$code', bold: true),
              Row(children: [
                Expanded(child: DateField(label: 'التاريخ', value: date, required: true, onChanged: (v) => setState(() => date = v ?? date))),
                const SizedBox(width: 8),
                Expanded(child: tf(time, 'الوقت')),
              ]),
              gap(10),
              SelectField<String>(
                label: 'المناوبة',
                value: shift,
                required: true,
                options: [for (final k in shiftLabels.keys) Opt<String>(k, t(shiftLabels[k]!))],
                onChanged: (v) => setState(() => shift = v ?? shift),
              ),
              gap(10),
              SelectField<int>(
                label: 'الآلة',
                value: machineId,
                allowClear: true,
                options: [for (final m in machines) Opt<int>(m['id'] as int, str(m['name']))],
                onChanged: (v) => setState(() => machineId = v),
              ),
              gap(10),
              SelectField<int>(
                label: 'المنتج',
                value: productId,
                required: true,
                options: [for (final p in products) Opt<int>(p['id'] as int, str(p['name']))],
                onChanged: (v) => setState(() {
                  productId = v;
                  final pr = products.where((e) => e['id'] == v).toList();
                  if (pr.isNotEmpty && dbl(pr.first['weight_g']) > 0 && cons.isNotEmpty && cons.first.perPiece.text.isEmpty) {
                    cons.first.perPiece.text = numText(pr.first['weight_g']);
                  }
                }),
              ),
              gap(10),
              SelectField<int>(
                label: 'العامل / المسؤول',
                value: employeeId,
                allowClear: true,
                options: [for (final e in employees) Opt<int>(e['id'] as int, str(e['name']))],
                onChanged: (v) => setState(() => employeeId = v),
              ),
            ]),
          ),
          Panel(
            title: 'الكميات',
            icon: Icons.numbers_rounded,
            child: Column(children: [
              Row(children: [
                Expanded(child: tf(target, 'الكمية المستهدفة', integer: true, suffix: 'قطعة')),
                const SizedBox(width: 8),
                Expanded(child: tf(actual, 'الكمية الفعلية', integer: true, required: true, suffix: 'قطعة', onChanged: (_) => setState(() {}))),
              ]),
              gap(10),
              Row(children: [
                Expanded(child: tf(defective, 'الكمية المعيبة', integer: true, suffix: 'قطعة', onChanged: (_) => setState(() {}))),
                const SizedBox(width: 8),
                Expanded(child: KV('المقبولة', fmt(accepted < 0 ? 0 : accepted), vColor: accepted < 0 ? C.error : C.success, bold: true)),
              ]),
              gap(10),
              Row(children: [
                Expanded(child: tf(duration, 'مدة التشغيل', integer: true, suffix: 'دقيقة')),
                const SizedBox(width: 8),
                Expanded(child: tf(downtime, 'مدة التوقف', integer: true, suffix: 'دقيقة')),
              ]),
              gap(10),
              tf(notes, 'ملاحظات', maxLines: 2),
            ]),
          ),
          for (var i = 0; i < cons.length; i++) _consCard(i),
          OutlinedButton.icon(
            onPressed: () => setState(() => cons.add(_Cons())),
            icon: const Icon(Icons.add_rounded),
            label: Text(t('إضافة مادة مستهلكة')),
          ),
          gap(14),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: saving ? null : () => Navigator.pop(context), child: Text(t('إلغاء')))),
            const SizedBox(width: 10),
            Expanded(flex: 2, child: PrimaryButton('حفظ السجل', onPressed: saving ? null : _save)),
          ]),
          gap(24),
        ]),
      ),
    );
  }

  Widget _consCard(int i) {
    final c = cons[i];
    final pl = planned(c);
    final ac = parseNum(c.actual.text) ?? 0;
    final variance = ac - pl;
    return Panel(
      title: '${t('استهلاك المادة')} ${i + 1}',
      icon: Icons.layers_rounded,
      trailing: IconButton(
        icon: const Icon(Icons.delete_outline_rounded, color: C.error),
        onPressed: () => setState(() => cons.removeAt(i)),
      ),
      child: Column(children: [
        SelectField<int>(
          label: 'المادة الأولية',
          value: c.materialId,
          required: true,
          options: [for (final m in materials) Opt<int>(m['id'] as int, '${str(m['name'])}  (${fmt2(dbl(m['qty']))} ${unitLabel(str(m['unit']))})')],
          onChanged: (v) => setState(() {
            c.materialId = v;
            _syncMat(c);
          }),
        ),
        gap(10),
        Row(children: [
          Expanded(child: tf(c.perPiece, 'الاستهلاك لكل قطعة', number: true, suffix: 'غ', onChanged: (_) => setState(() {}))),
          const SizedBox(width: 8),
          Expanded(child: tf(c.actual, 'الاستهلاك الفعلي', number: true, suffix: 'كغ', onChanged: (_) => setState(() {}))),
        ]),
        gap(6),
        KV('المطلوب نظريًا', '${fmt2(pl)} ${t('كغ')}'),
        if (c.actual.text.isNotEmpty) KV('الفرق (الفعلي - المخطط)', '${variance >= 0 ? '+' : ''}${fmt2(variance)} ${t('كغ')}', vColor: variance > 0.0001 ? C.error : C.success),
      ]),
    );
  }
}

// ====================================================================== VIEW
class ProductionView extends StatelessWidget {
  final int id;
  const ProductionView({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'تفاصيل سجل الإنتاج',
      body: DataView<Rec>(
        load: () async {
          final r = await Db.one(
              'SELECT pr.*, p.name AS product, m.name AS machine, e.name AS employee FROM production pr JOIN products p ON p.id = pr.product_id LEFT JOIN machines m ON m.id = pr.machine_id LEFT JOIN employees e ON e.id = pr.employee_id WHERE pr.id = ?',
              [id]);
          final cons = await Db.q(
              'SELECT c.*, mt.name AS material, mt.unit AS unit FROM consumption c JOIN materials mt ON mt.id = c.material_id WHERE c.production_id = ?', [id]);
          final hist = await Db.q('SELECT * FROM production_history WHERE production_id = ? ORDER BY id DESC', [id]);
          return {'r': r, 'cons': cons, 'hist': hist};
        },
        builder: (ctx, d) {
          final r = d['r'] as Rec?;
          if (r == null) return const EmptyBox('السجل غير موجود');
          final cons = d['cons'] as List<Rec>;
          final hist = d['hist'] as List<Rec>;
          final st = productionStatus(str(r['status']));
          final cancelled = r['status'] == 'cancelled';
          final can = AppState.i.can('production');
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              title: '#${str(r['code'])}',
              icon: Icons.assignment_rounded,
              trailing: Tag(st.label, st.color),
              child: Column(children: [
                KV('التاريخ', '${showDate(str(r['date']))} ${str(r['time'])}'),
                KV('المناوبة', shiftLabel(str(r['shift_kind']))),
                KV('الآلة', str(r['machine']).isEmpty ? '-' : str(r['machine'])),
                KV('المنتج', str(r['product']), bold: true),
                KV('العامل / المسؤول', str(r['employee']).isEmpty ? '-' : str(r['employee'])),
                KV('الكمية المستهدفة', fmt(dbl(r['target']))),
                KV('الكمية الفعلية', fmt(dbl(r['actual']))),
                KV('المقبولة', fmt(dbl(r['accepted'])), vColor: C.success, bold: true),
                KV('المعيبة', fmt(dbl(r['defective'])), vColor: dbl(r['defective']) > 0 ? C.error : null),
                KV('مدة التشغيل', '${fmt(dbl(r['duration_min']))} ${t('دقيقة')}'),
                KV('مدة التوقف', '${fmt(dbl(r['downtime_min']))} ${t('دقيقة')}'),
                if (str(r['notes']).isNotEmpty) KV('ملاحظات', str(r['notes'])),
              ]),
            ),
            Panel(
              title: 'المواد المستهلكة',
              icon: Icons.layers_rounded,
              padding: const EdgeInsets.all(6),
              child: cons.isEmpty
                  ? const EmptyBox('لم تُسجل مواد مستهلكة')
                  : simpleTable(
                      ['المادة', 'المخطط', 'الفعلي', 'الفرق'],
                      [
                        for (final c in cons)
                          [
                            str(c['material']),
                            fmt2(dbl(c['planned'])),
                            fmt2(dbl(c['actual'])),
                            fmt2(dbl(c['actual']) - dbl(c['planned'])),
                          ],
                      ],
                      flex: const [2, 1, 1, 1],
                    ),
            ),
            Panel(
              title: 'سجل التعديلات',
              icon: Icons.history_rounded,
              child: hist.isEmpty
                  ? const EmptyBox('لا يوجد سجل')
                  : Column(children: [
                      for (final h in hist)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Icon(h['action'] == 'cancel' ? Icons.cancel_rounded : (h['action'] == 'edit' ? Icons.edit_rounded : Icons.add_circle_rounded),
                                size: 18, color: h['action'] == 'cancel' ? C.error : C.primary),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(
                                    '${h['action'] == 'create' ? t('إنشاء') : (h['action'] == 'edit' ? t('تعديل') : t('إلغاء'))} • ${showDate(str(h['at']))} ${str(h['at']).length >= 16 ? str(h['at']).substring(11, 16) : ''}',
                                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                                Text(str(h['details']), style: const TextStyle(fontSize: 12, color: C.text2)),
                              ]),
                            ),
                          ]),
                        ),
                    ]),
            ),
            if (can && !cancelled)
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.edit_rounded),
                    label: Text(t('تعديل')),
                    onPressed: () => go(context, ProductionForm(id: id)),
                  ),
                ),
                const SizedBox(width: 8),
                if (AppState.i.can('delete'))
                  Expanded(
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(foregroundColor: C.error, side: const BorderSide(color: C.error)),
                      icon: const Icon(Icons.delete_rounded),
                      label: Text(t('حذف السجل')),
                      onPressed: () async {
                        final ok = await confirm(context, 'سيتم إلغاء السجل وعكس أثره على المخزون مع حفظ أثره في السجل. هل تريد المتابعة؟',
                            title: 'حذف سجل الإنتاج', yes: 'حذف');
                        if (!ok) return;
                        try {
                          await Svc.cancelProduction(id);
                          if (context.mounted) toast(context, 'تم حذف السجل وعكس أثره');
                        } on AppErr catch (e) {
                          if (context.mounted) toast(context, e.msg, error: true);
                        }
                      },
                    ),
                  ),
              ]),
            gap(24),
          ]);
        },
      ),
    );
  }
}

// ====================================================================== WEIGHT CALCULATOR
class WeightCalcPage extends StatefulWidget {
  const WeightCalcPage({super.key});
  @override
  State<WeightCalcPage> createState() => _WeightCalcPageState();
}

class _WeightCalcPageState extends State<WeightCalcPage> {
  final w = TextEditingController();
  final n = TextEditingController();
  final perPiece = TextEditingController();
  final pieces = TextEditingController();
  final pricePerKg = TextEditingController();
  int? productId;
  List<Rec> products = [];

  @override
  void initState() {
    super.initState();
    Db.q('SELECT id, name, weight_g FROM products ORDER BY name').then((r) {
      if (mounted) setState(() => products = r);
    });
  }

  @override
  void dispose() {
    w.dispose();
    n.dispose();
    perPiece.dispose();
    pieces.dispose();
    pricePerKg.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wv = parseNum(w.text) ?? 0;
    final nv = parseNum(n.text) ?? 0;
    final totalKg = wv * nv / 1000;
    final ppv = parseNum(perPiece.text) ?? 0;
    final pcs = parseNum(pieces.text) ?? 0;
    final needKg = ppv * pcs / 1000;
    final price = parseNum(pricePerKg.text) ?? 0;
    return PageScaffold(
      title: 'حاسبة الوزن والمواد',
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Panel(
          title: 'حاسبة وزن الصناديق',
          icon: Icons.scale_rounded,
          child: Column(children: [
            SelectField<int>(
              label: 'نوع المنتج',
              value: productId,
              allowClear: true,
              options: [for (final p in products) Opt<int>(p['id'] as int, str(p['name']))],
              onChanged: (v) => setState(() {
                productId = v;
                final pr = products.where((e) => e['id'] == v).toList();
                if (pr.isNotEmpty) {
                  w.text = numText(pr.first['weight_g']);
                  perPiece.text = numText(pr.first['weight_g']);
                }
              }),
            ),
            gap(10),
            Row(children: [
              Expanded(child: tf(w, 'وزن الصندوق', number: true, suffix: 'غ', onChanged: (_) => setState(() {}))),
              const SizedBox(width: 8),
              Expanded(child: tf(n, 'عدد الصناديق', integer: true, onChanged: (_) => setState(() {}))),
            ]),
            gap(8),
            KV('الوزن الكلي', '${fmt2(totalKg)} ${t('كغ')}', bold: true, vColor: C.primary),
            KV('بالغرام', '${fmt2(wv * nv)} ${t('غ')}'),
            if (productId != null && AppState.i.can('catalog'))
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: TextButton.icon(
                  icon: const Icon(Icons.save_rounded),
                  label: Text(t('حفظ الوزن كمواصفة للمنتج')),
                  onPressed: () async {
                    if (wv <= 0) {
                      toast(context, 'أدخل وزنًا صحيحًا', error: true);
                      return;
                    }
                    await Db.update('products', {'weight_g': wv}, productId!);
                    await Svc.auditDb('update', 'products', productId, 'weight_g=$wv');
                    if (context.mounted) toast(context, 'تم تحديث وزن المنتج');
                  },
                ),
              ),
          ]),
        ),
        Panel(
          title: 'حاسبة المادة المطلوبة للإنتاج',
          icon: Icons.layers_rounded,
          child: Column(children: [
            Row(children: [
              Expanded(child: tf(perPiece, 'المادة لكل قطعة', number: true, suffix: 'غ', onChanged: (_) => setState(() {}))),
              const SizedBox(width: 8),
              Expanded(child: tf(pieces, 'كمية الإنتاج', integer: true, suffix: 'قطعة', onChanged: (_) => setState(() {}))),
            ]),
            gap(10),
            tf(pricePerKg, 'سعر الكيلوغرام (اختياري)', number: true, suffix: 'دج', onChanged: (_) => setState(() {})),
            gap(8),
            KV('إجمالي المادة المطلوبة', '${fmt2(needKg)} ${t('كغ')}', bold: true, vColor: C.primary),
            if (price > 0) KV('التكلفة التقديرية', money(r2(needKg * price))),
          ]),
        ),
      ]),
    );
  }
}
