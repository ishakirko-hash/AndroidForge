import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import 'entities.dart';
import 'entity.dart';
import 'sales.dart';

class CustomerDetail extends StatelessWidget {
  final Rec row;
  const CustomerDetail({super.key, required this.row});

  @override
  Widget build(BuildContext context) {
    final id = intv(row['id']);
    return PageScaffold(
      title: 'تفاصيل العميل',
      actions: [
        if (AppState.i.can('sales'))
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: () async {
              final r = await Db.one('SELECT * FROM customers WHERE id = ?', [id]);
              if (r != null && context.mounted) await go(context, EntityForm(entity: customersEntity(), row: r));
            },
          ),
      ],
      body: DataView<Map<String, Object?>>(
        load: () async {
          final c = await Db.one('SELECT * FROM customers WHERE id = ?', [id]);
          final inv = await Db.q('SELECT * FROM invoices WHERE customer_id = ? ORDER BY date DESC, id DESC', [id]);
          return {'c': c ?? row, 'inv': inv};
        },
        builder: (ctx, d) {
          final c = d['c'] as Rec;
          final inv = d['inv'] as List<Rec>;
          var total = 0.0, paid = 0.0;
          for (final i in inv) {
            if (i['status'] == 'cancelled') continue;
            total += dbl(i['total']);
            paid += dbl(i['paid']);
          }
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              title: str(c['name']),
              icon: Icons.person_rounded,
              child: Column(children: [
                KV('الهاتف', str(c['phone']).isEmpty ? '-' : str(c['phone'])),
                KV('العنوان', str(c['address']).isEmpty ? '-' : str(c['address'])),
                if (str(c['notes']).isNotEmpty) KV('ملاحظات', str(c['notes'])),
              ]),
            ),
            Panel(
              title: 'الملخص المالي',
              icon: Icons.account_balance_wallet_rounded,
              child: Column(children: [
                KV('إجمالي المبيعات', money(total)),
                KV('المدفوع', money(paid), vColor: C.success),
                KV('المتبقي', money(total - paid), vColor: total - paid > 0 ? C.error : C.success, bold: true),
              ]),
            ),
            if (AppState.i.can('sales')) PrimaryButton('فاتورة جديدة لهذا العميل', icon: Icons.add_rounded, onPressed: () => go(context, InvoiceForm(customerId: id))),
            gap(10),
            Panel(
              title: 'الفواتير السابقة',
              icon: Icons.receipt_long_rounded,
              padding: EdgeInsets.zero,
              child: inv.isEmpty
                  ? const EmptyBox('لا توجد فواتير لهذا العميل')
                  : Column(children: [
                      for (final i in inv)
                        ListTile(
                          onTap: () => go(context, InvoiceView(id: intv(i['id']))),
                          title: Text('#${str(i['number'])}', style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(showDate(str(i['date']))),
                          trailing: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(money(dbl(i['total'])), style: const TextStyle(fontWeight: FontWeight.w800)),
                            Tag(invoiceStatus(str(i['status'])).label, invoiceStatus(str(i['status'])).color),
                          ]),
                        ),
                    ]),
            ),
          ]);
        },
      ),
    );
  }
}

class SupplierDetail extends StatelessWidget {
  final Rec row;
  const SupplierDetail({super.key, required this.row});

  @override
  Widget build(BuildContext context) {
    final id = intv(row['id']);
    return PageScaffold(
      title: 'تفاصيل المورد',
      actions: [
        if (AppState.i.can('inventory'))
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: () async {
              final r = await Db.one('SELECT * FROM suppliers WHERE id = ?', [id]);
              if (r != null && context.mounted) await go(context, EntityForm(entity: suppliersEntity(), row: r));
            },
          ),
      ],
      body: DataView<Map<String, Object?>>(
        load: () async {
          final s = await Db.one('SELECT * FROM suppliers WHERE id = ?', [id]);
          final mats = await Db.q('SELECT * FROM materials WHERE supplier_id = ?', [id]);
          final tx = await Db.q("SELECT * FROM transactions WHERE ref_type = 'supplier' AND ref_id = ? ORDER BY date DESC, id DESC", [id]);
          return {'s': s ?? row, 'mats': mats, 'tx': tx};
        },
        builder: (ctx, d) {
          final s = d['s'] as Rec;
          final mats = d['mats'] as List<Rec>;
          final tx = d['tx'] as List<Rec>;
          var total = 0.0;
          for (final x in tx) {
            total += dbl(x['amount']);
          }
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              title: str(s['name']),
              icon: Icons.local_shipping_rounded,
              child: Column(children: [
                KV('الهاتف', str(s['phone']).isEmpty ? '-' : str(s['phone'])),
                KV('العنوان', str(s['address']).isEmpty ? '-' : str(s['address'])),
                KV('إجمالي المشتريات', money(total), bold: true),
              ]),
            ),
            Panel(
              title: 'المواد الموردة',
              icon: Icons.layers_rounded,
              child: mats.isEmpty
                  ? const EmptyBox('لا توجد مواد مرتبطة بهذا المورد')
                  : Column(children: [for (final m in mats) KV(str(m['name']), '${fmt2(dbl(m['qty']))} ${unitLabel(str(m['unit']))}')]),
            ),
            Panel(
              title: 'سجل المشتريات',
              icon: Icons.history_rounded,
              child: tx.isEmpty
                  ? const EmptyBox('لا توجد مشتريات مسجلة')
                  : Column(children: [
                      for (final x in tx) KV('${showDate(str(x['date']))} • ${str(x['description'])}', money(dbl(x['amount']))),
                    ]),
            ),
          ]);
        },
      ),
    );
  }
}
