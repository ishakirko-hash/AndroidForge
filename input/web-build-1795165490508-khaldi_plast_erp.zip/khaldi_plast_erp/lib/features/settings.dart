import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/services.dart';
import 'notifications.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'الإعدادات',
      body: ListenableBuilder(
        listenable: AppState.i,
        builder: (c, _) {
          final app = AppState.i;
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              child: Row(children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(color: tint(C.primary), shape: BoxShape.circle),
                  child: const Icon(Icons.person_rounded, color: C.primary, size: 28),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(t(app.roleName), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    Text(app.company, style: const TextStyle(color: C.text2)),
                  ]),
                ),
              ]),
            ),
            Panel(
              padding: EdgeInsets.zero,
              child: Column(children: [
                _tile(Icons.business_rounded, 'بيانات الشركة والفاتورة', () => go(context, const CompanyPage())),
                const Divider(height: 1),
                SwitchListTile(
                  secondary: const Icon(Icons.translate_rounded, color: C.primary),
                  title: Text(t('اللغة: English')),
                  subtitle: Text(t('التبديل بين العربية والإنجليزية')),
                  value: !app.ar,
                  onChanged: (v) => app.set('lang', v ? 'en' : 'ar'),
                ),
                const Divider(height: 1),
                _tile(Icons.shield_rounded, 'الصلاحيات والمستخدم', () => go(context, const RolesPage())),
                const Divider(height: 1),
                _tile(Icons.cloud_download_rounded, 'النسخ الاحتياطي والاستعادة', () => go(context, const BackupPage())),
                const Divider(height: 1),
                _tile(Icons.notifications_rounded, 'التنبيهات', () => go(context, const NotificationsPage())),
              ]),
            ),
            Panel(
              title: 'حول التطبيق',
              icon: Icons.info_rounded,
              child: Column(children: [
                Image.asset('assets/images/logo_color.png', height: 64),
                gap(6),
                const KV('الإصدار', 'v1.0.0'),
                const KV('قاعدة البيانات', 'محلية (بدون إنترنت)'),
              ]),
            ),
          ]);
        },
      ),
    );
  }

  Widget _tile(IconData i, String title, VoidCallback onTap) => ListTile(
        leading: Icon(i, color: C.primary),
        title: Text(t(title), style: const TextStyle(fontWeight: FontWeight.w700)),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      );
}

class CompanyPage extends StatefulWidget {
  const CompanyPage({super.key});
  @override
  State<CompanyPage> createState() => _CompanyPageState();
}

class _CompanyPageState extends State<CompanyPage> {
  final _name = TextEditingController(text: AppState.i.get('company_name', 'KHALDI PLAST'));
  final _phone = TextEditingController(text: AppState.i.get('company_phone'));
  final _addr = TextEditingController(text: AppState.i.get('company_address'));
  final _tax = TextEditingController(text: AppState.i.get('company_taxid'));
  final _rate = TextEditingController(text: AppState.i.get('tax_rate', '0'));
  final _footer = TextEditingController(text: AppState.i.get('invoice_footer'));

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _addr.dispose();
    _tax.dispose();
    _rate.dispose();
    _footer.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!AppState.i.can('settings')) {
      toast(context, 'هذا الإجراء متاح لمدير النظام فقط', error: true);
      return;
    }
    final app = AppState.i;
    await app.set('company_name', _name.text.trim().isEmpty ? 'KHALDI PLAST' : _name.text.trim());
    await app.set('company_phone', _phone.text.trim());
    await app.set('company_address', _addr.text.trim());
    await app.set('company_taxid', _tax.text.trim());
    await app.set('tax_rate', numTextSafe(parseNum(_rate.text) ?? 0));
    await app.set('invoice_footer', _footer.text.trim());
    if (mounted) {
      toast(context, 'تم حفظ بيانات الشركة');
      Navigator.pop(context);
    }
  }

  String numTextSafe(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toString();

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'بيانات الشركة والفاتورة',
      body: ListView(padding: const EdgeInsets.all(14), children: [
        Center(child: Image.asset('assets/images/logo_color.png', height: 70)),
        gap(12),
        tf(_name, 'اسم الشركة', required: true),
        gap(12),
        tf(_phone, 'الهاتف'),
        gap(12),
        tf(_addr, 'العنوان'),
        gap(12),
        tf(_tax, 'الرقم الجبائي / السجل التجاري'),
        gap(12),
        tf(_rate, 'نسبة الضريبة الافتراضية %', number: true),
        gap(12),
        tf(_footer, 'نص أسفل الفاتورة', maxLines: 2),
        gap(18),
        PrimaryButton('حفظ', onPressed: _save),
      ]),
    );
  }
}

class RolesPage extends StatefulWidget {
  const RolesPage({super.key});
  @override
  State<RolesPage> createState() => _RolesPageState();
}

class _RolesPageState extends State<RolesPage> {
  final pin = TextEditingController();

  @override
  void dispose() {
    pin.dispose();
    super.dispose();
  }

  Future<void> _switch(String role) async {
    final app = AppState.i;
    if (role == app.role) return;
    final adminPin = app.get('admin_pin');
    if (role == 'admin' && adminPin.isNotEmpty) {
      final c = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(t('أدخل رمز مدير النظام')),
          content: TextField(controller: c, obscureText: true, keyboardType: TextInputType.number),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t('إلغاء'))),
            TextButton(onPressed: () => Navigator.pop(ctx, c.text == adminPin), child: Text(t('تأكيد'))),
          ],
        ),
      );
      c.dispose();
      if (ok != true) {
        if (mounted) toast(context, 'الرمز غير صحيح', error: true);
        return;
      }
    }
    await app.set('role', role);
    if (mounted) toast(context, 'تم تغيير المستخدم');
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'الصلاحيات والمستخدم',
      body: ListenableBuilder(
        listenable: AppState.i,
        builder: (c, _) {
          final app = AppState.i;
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              title: 'الدور الحالي',
              icon: Icons.shield_rounded,
              child: Column(children: [
                for (final e in roles.entries)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(e.key == app.role ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: C.primary),
                    title: Text(t(e.value), style: TextStyle(fontWeight: e.key == app.role ? FontWeight.w800 : FontWeight.w600)),
                    onTap: () => _switch(e.key),
                  ),
              ]),
            ),
            if (app.role == 'admin')
              Panel(
                title: 'رمز مدير النظام (اختياري)',
                icon: Icons.lock_rounded,
                child: Column(children: [
                  tf(pin, 'رمز جديد (أرقام)', type: TextInputType.number),
                  gap(8),
                  Row(children: [
                    Expanded(
                      child: PrimaryButton('حفظ الرمز', onPressed: () async {
                        await app.set('admin_pin', pin.text.trim());
                        pin.clear();
                        if (context.mounted) toast(context, pin.text.isEmpty ? 'تم حفظ الرمز' : 'تم حفظ الرمز');
                      }),
                    ),
                  ]),
                  Text(t('يُطلب الرمز عند العودة إلى دور مدير النظام. اتركه فارغًا لإلغائه.'), style: const TextStyle(fontSize: 12, color: C.text2)),
                ]),
              ),
            Panel(
              title: 'ملاحظة',
              icon: Icons.info_rounded,
              child: Text(
                t('المدير والمدير العام لهما كل الصلاحيات؛ بقية الأدوار تقتصر على أقسامها. الحذف والإعدادات متاحة للمدير فقط.'),
                style: const TextStyle(fontSize: 13, color: C.text2, height: 1.5),
              ),
            ),
          ]);
        },
      ),
    );
  }
}

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  Future<List<FileSystemEntity>> _files = Svc.listBackups();
  bool busy = false;

  void _refresh() => setState(() => _files = Svc.listBackups());

  bool _admin() {
    if (!AppState.i.can('settings')) {
      toast(context, 'هذا الإجراء متاح لمدير النظام فقط', error: true);
      return false;
    }
    return true;
  }

  Future<void> _create() async {
    if (!_admin()) return;
    setState(() => busy = true);
    try {
      final path = await Svc.backup();
      if (mounted) toast(context, '${t('تم إنشاء النسخة')}: ${p.basename(path)}');
      _refresh();
    } catch (e) {
      if (mounted) toast(context, 'تعذر إنشاء النسخة الاحتياطية', error: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _restore(String path) async {
    if (!_admin()) return;
    final ok = await confirm(context, 'سيتم استبدال كل البيانات الحالية ببيانات النسخة المختارة (مع حفظ نسخة أمان تلقائية). هل تريد المتابعة؟',
        title: 'استعادة نسخة احتياطية', yes: 'استعادة');
    if (!ok) return;
    setState(() => busy = true);
    try {
      await Svc.restore(path);
      if (!mounted) return;
      toast(context, 'تمت استعادة البيانات بنجاح');
      Navigator.of(context).popUntil((r) => r.isFirst);
    } on AppErr catch (e) {
      if (mounted) toast(context, e.msg, error: true);
    } catch (e) {
      if (mounted) toast(context, 'تعذرت الاستعادة', error: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _pick() async {
    if (!_admin()) return;
    final r = await FilePicker.platform.pickFiles();
    if (r == null || r.files.isEmpty || r.files.first.path == null) return;
    await _restore(r.files.first.path!);
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'النسخ الاحتياطي والاستعادة',
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Panel(
          title: 'النسخ الاحتياطي',
          icon: Icons.cloud_download_rounded,
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(t('تُحفظ النسخة على الهاتف ويمكنك مشاركتها (واتساب، بريد، Drive) لحفظها خارج الجهاز.'), style: const TextStyle(fontSize: 13, color: C.text2)),
            gap(10),
            PrimaryButton('إنشاء نسخة احتياطية الآن', icon: Icons.backup_rounded, onPressed: busy ? null : _create),
            gap(8),
            OutlinedButton.icon(
              icon: const Icon(Icons.upload_file_rounded),
              label: Text(t('استعادة من ملف')),
              onPressed: busy ? null : _pick,
            ),
          ]),
        ),
        Panel(
          title: 'النسخ المحفوظة',
          icon: Icons.history_rounded,
          padding: const EdgeInsets.all(6),
          child: FutureBuilder<List<FileSystemEntity>>(
            future: _files,
            builder: (c, s) {
              if (!s.hasData) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
              final list = s.data!;
              if (list.isEmpty) return const EmptyBox('لا توجد نسخ محفوظة');
              return Column(children: [
                for (final f in list)
                  ListTile(
                    dense: true,
                    title: Text(p.basename(f.path), style: const TextStyle(fontSize: 13)),
                    subtitle: Text('${(File(f.path).lengthSync() / 1024).toStringAsFixed(0)} KB'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.share_rounded), onPressed: () => Share.shareXFiles([XFile(f.path)])),
                      IconButton(icon: const Icon(Icons.restore_rounded, color: C.primary), onPressed: busy ? null : () => _restore(f.path)),
                    ]),
                  ),
              ]);
            },
          ),
        ),
      ]),
    );
  }
}
