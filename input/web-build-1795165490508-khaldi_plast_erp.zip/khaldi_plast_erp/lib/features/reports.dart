import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../core/app_state.dart';
import '../core/charts.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import '../pdf/pdf_service.dart';
import 'finance.dart';

class ReportData {
  final List<String> heads;
  final List<List<String>> rows;
  final List<String>? totals;
  final List<double>? chartValues;
  final List<String>? chartLabels;
  const ReportData(this.heads, this.rows, {this.totals, this.chartValues, this.chartLabels});
}

class ReportDef {
  final String id;
  final String title;
  final IconData icon;
  final Color color;
  final bool ranged;
  final Future<ReportData> Function(String from, String to) build;
  const ReportDef(this.id, this.title, this.icon, this.color, this.build, {this.ranged = true});
}

String _pct(double a, double b) => b > 0 ? '${(a / b * 100).toStringAsFixed(1)}%' : '-';

ReportData _byDayChart(List<Rec> rows, String dateKey, String valueKey, List<String> heads, List<List<String>> table, List<String>? totals) {
  final m = <String, double>{};
  for (final r in rows) {
    final d = str(r[dateKey]);
    m[d] = (m[d] ?? 0) + dbl(r[valueKey]);
  }
  final keys = m.keys.toList()..sort();
  return ReportData(heads, table,
      totals: totals,
      chartValues: [for (final k in keys) m[k]!],
      chartLabels: [for (final k in keys) k.length >= 10 ? k.substring(8, 10) : k]);
}

final List<ReportDef> reportDefs = [
  ReportDef('sales', 'تقرير المبيعات', Icons.shopping_cart_rounded, C.success, (from, to) async {
    final rows = await Db.q("SELECT * FROM invoices WHERE status != 'cancelled' AND date BETWEEN ? AND ? ORDER BY date, id", [from, to]);
    var tot = 0.0, paid = 0.0;
    final table = <List<String>>[];
    for (final r in rows) {
      tot += dbl(r['total']);
      paid += dbl(r['paid']);
      table.add([
        '#${str(r['number'])}',
        showDate(str(r['date'])),
        str(r['customer_name']),
        fmt(dbl(r['total'])),
        fmt(dbl(r['paid'])),
        fmt(dbl(r['total']) - dbl(r['paid'])),
        invoiceStatus(str(r['status'])).label,
      ]);
    }
    return _byDayChart(rows, 'date', 'total', ['رقم الفاتورة', 'التاريخ', 'العميل', 'الإجمالي (دج)', 'المدفوع', 'المتبقي', 'الحالة'], table,
        ['', '', 'الإجمالي', fmt(tot), fmt(paid), fmt(tot - paid), '']);
  }),
  ReportDef('production', 'تقرير الإنتاج', Icons.precision_manufacturing_rounded, C.primary, (from, to) async {
    final rows = await Db.q(
        "SELECT pr.*, p.name AS product, m.name AS machine FROM production pr JOIN products p ON p.id = pr.product_id LEFT JOIN machines m ON m.id = pr.machine_id WHERE pr.status = 'done' AND pr.date BETWEEN ? AND ? ORDER BY pr.date, pr.id",
        [from, to]);
    var act = 0.0, acc = 0.0, def = 0.0;
    final table = <List<String>>[];
    for (final r in rows) {
      act += dbl(r['actual']);
      acc += dbl(r['accepted']);
      def += dbl(r['defective']);
      table.add([
        showDate(str(r['date'])),
        str(r['code']),
        str(r['product']),
        str(r['machine']),
        shiftLabel(str(r['shift_kind'])),
        fmt(dbl(r['actual'])),
        fmt(dbl(r['accepted'])),
        fmt(dbl(r['defective'])),
      ]);
    }
    return _byDayChart(rows, 'date', 'accepted', ['التاريخ', 'الرقم', 'المنتج', 'الآلة', 'المناوبة', 'الفعلي', 'المقبول', 'المعيب'], table,
        ['', '', '', '', 'الإجمالي', fmt(act), fmt(acc), '${fmt(def)} (${_pct(def, act)})']);
  }),
  ReportDef('inventory', 'تقرير المخزون', Icons.inventory_2_rounded, C.warning, (from, to) async {
    final prods = await Db.q('SELECT * FROM products ORDER BY name');
    final mats = await Db.q('SELECT * FROM materials ORDER BY name');
    final table = <List<String>>[];
    var value = 0.0;
    for (final p in prods) {
      final v = dbl(p['qty']) * dbl(p['price']);
      value += v;
      table.add(['منتج', str(p['name']), '${fmt(dbl(p['qty']))} ${t('قطعة')}', fmt(dbl(p['min_stock'])), _stockLabel(dbl(p['qty']), dbl(p['min_stock'])), fmt(v)]);
    }
    for (final m in mats) {
      final v = dbl(m['qty']) * dbl(m['unit_cost']);
      value += v;
      table.add(['مادة', str(m['name']), '${fmt2(dbl(m['qty']))} ${unitLabel(str(m['unit']))}', fmt2(dbl(m['min_qty'])), _stockLabel(dbl(m['qty']), dbl(m['min_qty'])), fmt(v)]);
    }
    return ReportData(['النوع', 'الاسم', 'الكمية', 'الحد الأدنى', 'الحالة', 'القيمة (دج)'], table.map((r) => [t(r[0]), ...r.sublist(1)]).toList(),
        totals: ['', '', '', '', 'إجمالي القيمة', fmt(value)]);
  }, ranged: false),
  ReportDef('consumption', 'تقرير استهلاك المواد', Icons.layers_rounded, C.purple, (from, to) async {
    final rows = await Db.q(
        "SELECT m.name AS name, m.unit AS unit, SUM(c.planned) AS pl, SUM(c.actual) AS ac, SUM(c.actual * c.unit_cost) AS cost FROM consumption c JOIN production pr ON pr.id = c.production_id JOIN materials m ON m.id = c.material_id WHERE pr.status = 'done' AND pr.date BETWEEN ? AND ? GROUP BY m.id ORDER BY ac DESC",
        [from, to]);
    var cost = 0.0, ac = 0.0, pl = 0.0;
    final table = <List<String>>[];
    for (final r in rows) {
      cost += dbl(r['cost']);
      ac += dbl(r['ac']);
      pl += dbl(r['pl']);
      table.add([
        str(r['name']),
        unitLabel(str(r['unit'])),
        fmt2(dbl(r['pl'])),
        fmt2(dbl(r['ac'])),
        fmt2(dbl(r['ac']) - dbl(r['pl'])),
        fmt(dbl(r['cost'])),
      ]);
    }
    return ReportData(['المادة', 'الوحدة', 'المخطط', 'الفعلي', 'الفرق', 'التكلفة (دج)'], table,
        totals: ['الإجمالي', '', fmt2(pl), fmt2(ac), fmt2(ac - pl), fmt(cost)],
        chartValues: [for (final r in rows) dbl(r['ac'])],
        chartLabels: [for (final r in rows) str(r['name'])]);
  }),
  ReportDef('machines', 'تقرير أداء الآلات', Icons.settings_suggest_rounded, C.success, (from, to) async {
    final rows = await Db.q(
        "SELECT m.name AS name, m.status AS status, COALESCE(SUM(pr.accepted),0) AS acc, COALESCE(SUM(pr.actual),0) AS act, COALESCE(SUM(pr.defective),0) AS def, COALESCE(SUM(pr.duration_min),0) AS dur, COALESCE(SUM(pr.downtime_min),0) AS down, COALESCE(SUM(pr.target),0) AS tg FROM machines m LEFT JOIN production pr ON pr.machine_id = m.id AND pr.status = 'done' AND pr.date BETWEEN ? AND ? GROUP BY m.id ORDER BY m.name",
        [from, to]);
    final table = <List<String>>[
      for (final r in rows)
        [
          str(r['name']),
          machineStatus(str(r['status'])).label,
          fmt(dbl(r['acc'])),
          _pct(dbl(r['acc']), dbl(r['tg'])),
          _pct(dbl(r['def']), dbl(r['act'])),
          fmt2(dbl(r['dur']) / 60),
          fmt(dbl(r['down'])),
        ],
    ];
    return ReportData(['الآلة', 'الحالة', 'الإنتاج', 'الكفاءة', 'المعيب %', 'ساعات التشغيل', 'التوقف (د)'], table,
        chartValues: [for (final r in rows) dbl(r['acc'])], chartLabels: [for (final r in rows) str(r['name'])]);
  }),
  ReportDef('employees', 'تقرير الموظفين', Icons.badge_rounded, C.primary, (from, to) async {
    final rows = await Db.q(
        "SELECT e.name AS name, e.role AS role, (SELECT COUNT(*) FROM production pr WHERE pr.employee_id = e.id AND pr.status = 'done' AND pr.date BETWEEN ? AND ?) AS recs, (SELECT COALESCE(SUM(accepted),0) FROM production pr WHERE pr.employee_id = e.id AND pr.status = 'done' AND pr.date BETWEEN ? AND ?) AS acc, (SELECT COUNT(*) FROM shift_employees se JOIN shifts s ON s.id = se.shift_id WHERE se.employee_id = e.id AND se.attendance = 'present' AND s.date BETWEEN ? AND ?) AS pres, (SELECT COUNT(*) FROM shift_employees se JOIN shifts s ON s.id = se.shift_id WHERE se.employee_id = e.id AND se.attendance = 'absent' AND s.date BETWEEN ? AND ?) AS abs FROM employees e ORDER BY e.name",
        [from, to, from, to, from, to, from, to]);
    return ReportData(['الموظف', 'الوظيفة', 'سجلات الإنتاج', 'الكمية المقبولة', 'أيام الحضور', 'أيام الغياب'], [
      for (final r in rows) [str(r['name']), str(r['role']), fmt(dbl(r['recs'])), fmt(dbl(r['acc'])), fmt(dbl(r['pres'])), fmt(dbl(r['abs']))],
    ]);
  }),
  ReportDef('shifts', 'تقرير المناوبات', Icons.calendar_month_rounded, C.warning, (from, to) async {
    final att = await Db.q(
        "SELECT s.kind AS kind, COUNT(DISTINCT s.id) AS n, SUM(CASE WHEN se.attendance = 'present' THEN 1 ELSE 0 END) AS pres, SUM(CASE WHEN se.attendance = 'absent' THEN 1 ELSE 0 END) AS abs FROM shifts s LEFT JOIN shift_employees se ON se.shift_id = s.id WHERE s.date BETWEEN ? AND ? GROUP BY s.kind",
        [from, to]);
    final prod = await Db.q(
        "SELECT shift_kind AS kind, COUNT(*) AS n, COALESCE(SUM(accepted),0) AS acc, COALESCE(SUM(defective),0) AS def FROM production WHERE status = 'done' AND date BETWEEN ? AND ? GROUP BY shift_kind",
        [from, to]);
    final table = <List<String>>[];
    for (final k in const ['morning', 'afternoon', 'night']) {
      final a = att.where((x) => x['kind'] == k).toList();
      final p = prod.where((x) => x['kind'] == k).toList();
      table.add([
        shiftLabel(k),
        a.isEmpty ? '0' : fmt(dbl(a.first['n'])),
        p.isEmpty ? '0' : fmt(dbl(p.first['n'])),
        p.isEmpty ? '0' : fmt(dbl(p.first['acc'])),
        p.isEmpty ? '0' : fmt(dbl(p.first['def'])),
        a.isEmpty ? '0' : fmt(dbl(a.first['pres'])),
        a.isEmpty ? '0' : fmt(dbl(a.first['abs'])),
      ]);
    }
    return ReportData(['المناوبة', 'عدد المناوبات', 'سجلات الإنتاج', 'المقبول', 'المعيب', 'الحضور', 'الغياب'], table);
  }),
  ReportDef('expenses', 'تقرير المصاريف', Icons.account_balance_wallet_rounded, C.error, (from, to) async {
    final rows = await Db.q("SELECT * FROM transactions WHERE kind = 'expense' AND date BETWEEN ? AND ? ORDER BY date, id", [from, to]);
    var tot = 0.0;
    final table = <List<String>>[];
    for (final r in rows) {
      tot += dbl(r['amount']);
      table.add([showDate(str(r['date'])), str(r['category']), str(r['description']), str(r['party']), fmt(dbl(r['amount']))]);
    }
    return _byDayChart(rows, 'date', 'amount', ['التاريخ', 'التصنيف', 'الوصف', 'الطرف', 'المبلغ (دج)'], table, ['', '', '', 'الإجمالي', fmt(tot)]);
  }),
  ReportDef('customers', 'تقرير العملاء', Icons.groups_rounded, C.purple, (from, to) async {
    final rows = await Db.q(
        "SELECT c.name AS name, COUNT(i.id) AS n, COALESCE(SUM(i.total),0) AS tot, COALESCE(SUM(i.paid),0) AS pd FROM customers c LEFT JOIN invoices i ON i.customer_id = c.id AND i.status != 'cancelled' AND i.date BETWEEN ? AND ? GROUP BY c.id ORDER BY tot DESC",
        [from, to]);
    var tot = 0.0, pd = 0.0;
    for (final r in rows) {
      tot += dbl(r['tot']);
      pd += dbl(r['pd']);
    }
    return ReportData(['العميل', 'عدد الفواتير', 'إجمالي المبيعات', 'المدفوع', 'المتبقي'], [
      for (final r in rows) [str(r['name']), fmt(dbl(r['n'])), fmt(dbl(r['tot'])), fmt(dbl(r['pd'])), fmt(dbl(r['tot']) - dbl(r['pd']))],
    ], totals: ['الإجمالي', '', fmt(tot), fmt(pd), fmt(tot - pd)]);
  }),
  ReportDef('orders', 'تقرير الطلبات', Icons.assignment_turned_in_rounded, C.primary, (from, to) async {
    final rows = await Db.q(
        'SELECT o.*, c.name AS customer, p.name AS product FROM orders o LEFT JOIN customers c ON c.id = o.customer_id LEFT JOIN products p ON p.id = o.product_id WHERE o.order_date BETWEEN ? AND ? ORDER BY o.order_date, o.id',
        [from, to]);
    return ReportData(['رقم الطلب', 'العميل', 'المنتج', 'الكمية', 'التسليم', 'الحالة'], [
      for (final r in rows)
        [
          '#${str(r['number'])}',
          str(r['customer']),
          str(r['product']),
          fmt(dbl(r['qty'])),
          showDate(str(r['delivery_date'])),
          orderStatus(str(r['status'])).label,
        ],
    ]);
  }),
];

String _stockLabel(double q, double mn) {
  if (mn > 0 && q <= 0) return t('نفد');
  if (mn > 0 && q <= mn) return t('قريب من النفاد');
  return t('متوفر');
}

// ====================================================================== CENTER
class ReportsPage extends StatelessWidget {
  final String? initial;
  const ReportsPage({super.key, this.initial});

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'التقارير',
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Panel(
          title: 'الأرباح والتكاليف',
          icon: Icons.trending_up_rounded,
          iconColor: C.success,
          onTap: () => go(context, const ProfitPage()),
          child: Text(t('صافي الربح وتكلفة الإنتاج لأي فترة'), style: const TextStyle(color: C.text2, fontSize: 13)),
        ),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 2.2,
          children: [
            for (final d in reportDefs)
              Material(
                color: C.card,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: d.id == initial ? C.primary : C.border, width: d.id == initial ? 2 : 1),
                ),
                child: InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => go(context, ReportView(def: d)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(children: [
                      Icon(d.icon, color: d.color, size: 26),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(t(d.title), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
                      ),
                    ]),
                  ),
                ),
              ),
          ],
        ),
      ]),
    );
  }
}

class ReportView extends StatefulWidget {
  final ReportDef def;
  const ReportView({super.key, required this.def});
  @override
  State<ReportView> createState() => _ReportViewState();
}

class _ReportViewState extends State<ReportView> {
  String pKey = 'month';
  String from = periodRange('month')[0];
  String to = periodRange('month')[1];
  String q = '';
  ReportData? last;

  String get periodText => widget.def.ranged ? '${showDate(from)} - ${showDate(to)}' : showDate(today());

  Future<void> _pdf(bool print) async {
    final d = last;
    if (d == null) return;
    try {
      final bytes = await PdfService.report(t(widget.def.title), periodText, d.heads.map(t).toList(), d.rows, d.totals?.map(t).toList());
      if (print) {
        await PdfService.printBytes(bytes, 'report_${widget.def.id}');
      } else {
        await PdfService.shareBytes(bytes, 'report_${widget.def.id}_${today()}.pdf');
      }
    } catch (e) {
      if (mounted) toast(context, 'تعذر إنشاء ملف PDF', error: true);
    }
  }

  Future<void> _csv() async {
    final d = last;
    if (d == null) return;
    try {
      final rows = <List<String>>[...d.rows];
      if (d.totals != null) rows.add(d.totals!.map(t).toList());
      final path = await Svc.writeCsv('report_${widget.def.id}_${today()}.csv', d.heads.map(t).toList(), rows);
      await Share.shareXFiles([XFile(path)]);
    } catch (e) {
      if (mounted) toast(context, 'تعذر تصدير الملف', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: widget.def.title,
      actions: [
        IconButton(tooltip: 'PDF', icon: const Icon(Icons.picture_as_pdf_rounded), onPressed: () => _pdf(false)),
        IconButton(tooltip: 'CSV', icon: const Icon(Icons.table_view_rounded), onPressed: _csv),
        IconButton(tooltip: t('طباعة'), icon: const Icon(Icons.print_rounded), onPressed: () => _pdf(true)),
      ],
      body: DataView<ReportData>(
        load: () async {
          final d = await widget.def.build(from, to);
          last = d;
          return d;
        },
        builder: (c, d) {
          final ql = q.trim().toLowerCase();
          final rows = d.rows.where((r) => ql.isEmpty || r.any((x) => x.toLowerCase().contains(ql))).toList();
          return ListView(padding: const EdgeInsets.all(12), children: [
            if (widget.def.ranged) ...[
              PeriodBar(
                value: pKey,
                from: from,
                to: to,
                onChanged: (k, f, tt) => setState(() {
                  pKey = k;
                  from = f;
                  to = tt;
                }),
              ),
              gap(8),
            ],
            Text(periodText, style: const TextStyle(color: C.text2, fontSize: 13)),
            gap(8),
            if (d.chartValues != null && d.chartValues!.length > 1)
              Panel(
                title: 'الرسم البياني',
                icon: Icons.show_chart_rounded,
                child: LineChart(values: d.chartValues!, labels: d.chartLabels ?? const []),
              ),
            SearchField(onChanged: (v) => setState(() => q = v)),
            gap(8),
            if (rows.isEmpty)
              const EmptyBox('لا توجد بيانات في هذه الفترة')
            else
              Container(
                decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columnSpacing: 18,
                    headingTextStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: C.text),
                    dataTextStyle: const TextStyle(fontSize: 13, color: C.text),
                    columns: [for (final h in d.heads) DataColumn(label: Text(t(h)))],
                    rows: [
                      for (final r in rows) DataRow(cells: [for (final x in r) DataCell(Text(x))]),
                      if (d.totals != null)
                        DataRow(
                          cells: [for (final x in d.totals!) DataCell(Text(t(x), style: const TextStyle(fontWeight: FontWeight.w800, color: C.primary)))],
                        ),
                    ],
                  ),
                ),
              ),
            gap(10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.picture_as_pdf_rounded), label: const Text('PDF'), onPressed: () => _pdf(false))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.table_view_rounded), label: const Text('CSV'), onPressed: _csv)),
            ]),
            gap(24),
          ]);
        },
      ),
    );
  }
}
