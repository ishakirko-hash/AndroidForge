import 'package:flutter/material.dart';
import '../core/format.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/services.dart';
import 'entities.dart';
import 'entity.dart';
import 'inventory.dart';
import 'machines.dart';
import 'production.dart';
import 'sales.dart';

Color _sevColor(String s) => s == 'critical' ? C.error : (s == 'warning' ? C.warning : C.primary);
IconData _sevIcon(String s) => s == 'critical' ? Icons.error_rounded : (s == 'warning' ? Icons.warning_amber_rounded : Icons.info_rounded);

Future<void> openAlert(BuildContext context, AlertItem a) async {
  await Svc.markRead(a.key);
  if (!context.mounted) return;
  switch (a.module) {
    case 'inventory':
      if (a.refId != null) await go(context, ItemDetailPage(itemType: 'product', id: a.refId!));
      break;
    case 'materials':
      if (a.refId != null) await go(context, ItemDetailPage(itemType: 'material', id: a.refId!));
      break;
    case 'machines':
      if (a.refId != null) await go(context, MachineDetail(id: a.refId!));
      break;
    case 'orders':
      await go(context, EntityPage(entity: ordersEntityFull()));
      break;
    case 'sales':
      if (a.refId != null) await go(context, InvoiceView(id: a.refId!));
      break;
    case 'production':
      await go(context, const ProductionPage());
      break;
  }
}

class AlertTile extends StatelessWidget {
  final AlertItem a;
  const AlertTile({super.key, required this.a});

  @override
  Widget build(BuildContext context) {
    final c = _sevColor(a.severity);
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(color: tint(c, 0.1), borderRadius: BorderRadius.circular(8)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () => openAlert(context, a),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Icon(_sevIcon(a.severity), color: c),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(a.title, style: TextStyle(fontWeight: a.read ? FontWeight.w600 : FontWeight.w800, fontSize: 14)),
                  if (a.desc.isNotEmpty) Text(a.desc, style: const TextStyle(fontSize: 12, color: C.text2)),
                ]),
              ),
              if (!a.read) Container(width: 9, height: 9, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
            ]),
          ),
        ),
      ),
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: 'التنبيهات',
      body: DataView<List<AlertItem>>(
        load: Svc.alerts,
        builder: (c, list) {
          if (list.isEmpty) return const EmptyBox('لا توجد تنبيهات حالياً', icon: Icons.notifications_none_rounded);
          final unread = list.where((a) => !a.read).length;
          return ListView(padding: const EdgeInsets.all(12), children: [
            Row(children: [
              Expanded(child: Text('${t('غير مقروءة')}: $unread / ${list.length}', style: const TextStyle(fontWeight: FontWeight.w700))),
              TextButton.icon(
                icon: const Icon(Icons.done_all_rounded),
                label: Text(t('تعليم الكل كمقروء')),
                onPressed: () => Svc.markAllRead(list),
              ),
            ]),
            for (final a in list)
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                AlertTile(a: a),
                Padding(
                  padding: const EdgeInsetsDirectional.only(start: 6, bottom: 6),
                  child: Text(showDate(a.date), style: const TextStyle(fontSize: 11, color: C.text2)),
                ),
              ]),
          ]);
        },
      ),
    );
  }
}
