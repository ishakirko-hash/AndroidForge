import 'package:flutter/material.dart';
import '../core/icons.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import 'dashboard.dart';
import 'inventory.dart';
import 'more.dart';
import 'production.dart';
import 'sales.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;

  void _go(int i) => setState(() => index = i);

  @override
  Widget build(BuildContext context) {
    const items = <List<String>>[
      ['app_home', 'الرئيسية'],
      ['app_sales', 'المبيعات'],
      ['app_inventory', 'المخزون'],
      ['app_production', 'الإنتاج'],
      ['app_more', 'المزيد'],
    ];
    return Scaffold(
      body: IndexedStack(index: index, children: [
        DashboardPage(goTab: _go),
        const SalesPage(),
        const InventoryPage(),
        const ProductionPage(),
        const MorePage(),
      ]),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: C.border))),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 62,
            child: Row(children: [
              for (var i = 0; i < items.length; i++)
                Expanded(
                  child: InkWell(
                    onTap: () => _go(i),
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: i == index ? C.light : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          AppIcon(items[i][0], size: 25, color: i == index ? C.primary : C.text2),
                          const SizedBox(height: 2),
                          Text(t(items[i][1]),
                              maxLines: 1,
                              style: TextStyle(fontSize: 11.5, fontWeight: i == index ? FontWeight.w800 : FontWeight.w600, color: i == index ? C.primary : C.text2)),
                        ]),
                      ),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}
