import 'package:flutter/material.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import 'details.dart';
import 'entity.dart';

Widget _thumb(String? asset, {double w = 56, double h = 44, IconData icon = Icons.view_in_ar_rounded}) {
  if (asset != null && asset.startsWith('assets/')) {
    return SizedBox(width: w, height: h, child: Image.asset(asset, fit: BoxFit.contain));
  }
  return Container(
    width: w,
    height: h,
    decoration: BoxDecoration(color: C.light, borderRadius: BorderRadius.circular(8)),
    child: Icon(icon, color: C.primary),
  );
}

Widget productThumb(String? asset) => _thumb(asset);
Widget machineThumb(String? asset) => _thumb(asset ?? 'assets/images/machine.png', w: 64, h: 44, icon: Icons.settings_suggest_rounded);

String? _productImageFor(String code) {
  final c = code.toUpperCase().replaceAll(' ', '');
  switch (c) {
    case 'CP9':
      return 'assets/images/products/cp9.png';
    case 'CP14':
      return 'assets/images/products/cp14.png';
    case 'SIPORA14':
      return 'assets/images/products/sipora14.png';
    case 'SIPORA20':
      return 'assets/images/products/sipora20.png';
  }
  return null;
}

Widget _col2(String top, String bottom, {Color? bottomColor}) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(top, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
        Text(bottom, style: TextStyle(fontSize: 12, color: bottomColor ?? C.text2, fontWeight: FontWeight.w600)),
      ],
    );

// ------------------------------------------------------------------ customers
Entity customersEntity() => Entity(
      table: 'customers',
      title: 'العملاء',
      single: 'عميل',
      icon: 'app_customers',
      perm: 'sales',
      fields: const [
        F('name', 'الاسم', FT.text, required: true),
        F('phone', 'الهاتف', FT.text),
        F('address', 'العنوان', FT.text),
        F('notes', 'ملاحظات', FT.multiline),
      ],
      sql:
          "SELECT c.*, COALESCE((SELECT SUM(total) FROM invoices i WHERE i.customer_id = c.id AND i.status != 'cancelled'),0) AS sales, COALESCE((SELECT SUM(total - paid) FROM invoices i WHERE i.customer_id = c.id AND i.status != 'cancelled'),0) AS balance FROM customers c ORDER BY c.name",
      searchKeys: const ['name', 'phone', 'address'],
      titleOf: (r) => str(r['name']),
      subOf: (r) => [str(r['phone']), str(r['address'])].where((s) => s.isNotEmpty).join(' • '),
      trailing: (c, r) => _col2(money(dbl(r['sales'])), dbl(r['balance']) > 0 ? '${t('المتبقي')}: ${money(dbl(r['balance']))}' : t('لا مستحقات'),
          bottomColor: dbl(r['balance']) > 0 ? C.error : C.success),
      onOpen: (ctx, r) => go(ctx, CustomerDetail(row: r)),
    );

// ------------------------------------------------------------------ suppliers
Entity suppliersEntity() => Entity(
      table: 'suppliers',
      title: 'الموردون',
      single: 'مورد',
      icon: 'app_suppliers',
      perm: 'inventory',
      fields: const [
        F('name', 'الاسم', FT.text, required: true),
        F('phone', 'الهاتف', FT.text),
        F('address', 'العنوان', FT.text),
        F('notes', 'ملاحظات', FT.multiline),
      ],
      sql:
          "SELECT s.*, COALESCE((SELECT SUM(amount) FROM transactions t WHERE t.kind = 'purchase' AND t.ref_type = 'supplier' AND t.ref_id = s.id),0) AS purchases, (SELECT GROUP_CONCAT(name, '، ') FROM materials m WHERE m.supplier_id = s.id) AS mats FROM suppliers s ORDER BY s.name",
      searchKeys: const ['name', 'phone', 'mats'],
      titleOf: (r) => str(r['name']),
      subOf: (r) => [str(r['phone']), str(r['mats'])].where((s) => s.isNotEmpty).join(' • '),
      trailing: (c, r) => _col2(money(dbl(r['purchases'])), t('المشتريات')),
      onOpen: (ctx, r) => go(ctx, SupplierDetail(row: r)),
    );

// ------------------------------------------------------------------ employees
Entity employeesEntity() => Entity(
      table: 'employees',
      title: 'الموظفون',
      single: 'موظف',
      icon: 'app_employees',
      perm: 'hr',
      fields: [
        const F('code', 'الرقم الوظيفي', FT.text),
        const F('name', 'الاسم الكامل', FT.text, required: true),
        const F('phone', 'الهاتف', FT.text),
        const F('role', 'الوظيفة', FT.text),
        F('status', 'حالة العمل', FT.select, required: true, def: 'active', options: const [
          Opt<Object>('active', 'نشط'),
          Opt<Object>('leave', 'في إجازة'),
          Opt<Object>('inactive', 'غير نشط'),
        ]),
        F('shift', 'المناوبة المعيّنة', FT.select, options: const [
          Opt<Object>('morning', 'الصباحية'),
          Opt<Object>('afternoon', 'المسائية'),
          Opt<Object>('night', 'الليلية'),
        ]),
        const F('notes', 'ملاحظات', FT.multiline),
      ],
      sql: 'SELECT * FROM employees ORDER BY name',
      searchKeys: const ['name', 'code', 'phone', 'role'],
      titleOf: (r) => str(r['name']),
      subOf: (r) => [str(r['role']), str(r['phone'])].where((s) => s.isNotEmpty).join(' • '),
      trailing: (c, r) {
        final s = str(r['status']);
        final info = s == 'active'
            ? StatusInfo(t('نشط'), C.success)
            : (s == 'leave' ? StatusInfo(t('في إجازة'), C.warning) : StatusInfo(t('غير نشط'), C.text2));
        return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Tag(info.label, info.color),
          if (str(r['shift']).isNotEmpty) Text(shiftLabel(str(r['shift'])), style: const TextStyle(fontSize: 12, color: C.text2)),
        ]);
      },
    );

// ------------------------------------------------------------------ machines (form only; list is a custom page)
Entity machinesEntity() => Entity(
      table: 'machines',
      title: 'الآلات',
      single: 'آلة',
      icon: 'app_machines',
      perm: 'production',
      fields: [
        const F('code', 'رمز الآلة', FT.text, required: true),
        const F('name', 'اسم الآلة', FT.text, required: true),
        F('status', 'الحالة', FT.select, required: true, def: 'working', options: const [
          Opt<Object>('working', 'تعمل'),
          Opt<Object>('stopped', 'متوقفة'),
          Opt<Object>('maintenance', 'صيانة'),
        ]),
        const F('notes', 'ملاحظات', FT.multiline),
      ],
      titleOf: (r) => str(r['name']),
      searchKeys: const ['name', 'code'],
      beforeInsert: (v) async {
        v['image'] = 'assets/images/machine.png';
      },
    );

// ------------------------------------------------------------------ products
Entity productsEntity() => Entity(
      table: 'products',
      title: 'المنتجات',
      single: 'منتج',
      icon: 'app_products',
      perm: 'catalog',
      fields: const [
        F('code', 'رمز المنتج', FT.text, required: true),
        F('name', 'اسم المنتج', FT.text, required: true),
        F('length', 'الطول', FT.decimal, suffix: 'مم'),
        F('width', 'العرض', FT.decimal, suffix: 'مم'),
        F('height', 'الارتفاع', FT.decimal, suffix: 'مم'),
        F('weight_g', 'وزن القطعة', FT.decimal, suffix: 'غ'),
        F('price', 'سعر البيع', FT.decimal, suffix: 'دج'),
        F('min_stock', 'الحد الأدنى للمخزون', FT.decimal, suffix: 'قطعة'),
      ],
      sql: 'SELECT * FROM products ORDER BY name',
      searchKeys: const ['name', 'code'],
      titleOf: (r) => '${str(r['name'])}  (${str(r['code'])})',
      subOf: (r) =>
          '${fmt2(dbl(r['length']))} × ${fmt2(dbl(r['width']))} × ${fmt2(dbl(r['height']))} ${t('مم')} • ${fmt2(dbl(r['weight_g']))} ${t('غ')}',
      leading: (c, r) => productThumb(r['image'] as String?),
      trailing: (c, r) => _col2('${fmt(dbl(r['qty']))} ${t('قطعة')}', money(dbl(r['price']))),
      beforeInsert: (v) async {
        v['image'] = _productImageFor(str(v['code']));
      },
    );

// ------------------------------------------------------------------ materials
const unitOptions = <Opt<Object>>[
  Opt<Object>('kg', 'كغ'),
  Opt<Object>('g', 'غ'),
  Opt<Object>('pcs', 'قطعة'),
  Opt<Object>('l', 'لتر'),
];

Entity materialsEntity() => Entity(
      table: 'materials',
      title: 'المواد الأولية',
      single: 'مادة',
      icon: 'app_raw_materials',
      perm: 'inventory',
      fields: [
        const F('code', 'رمز المادة', FT.text, required: true),
        const F('name', 'اسم المادة', FT.text, required: true),
        const F('category', 'الفئة', FT.text),
        F('unit', 'الوحدة', FT.select, required: true, def: 'kg', options: unitOptions),
        const F('unit_cost', 'سعر الشراء للوحدة', FT.decimal, suffix: 'دج'),
        const F('min_qty', 'الحد الأدنى للمخزون', FT.decimal),
        F('supplier_id', 'المورد', FT.select, loader: (cur) => optsFrom('suppliers', 'name')),
      ],
      sql: 'SELECT m.*, s.name AS supplier FROM materials m LEFT JOIN suppliers s ON s.id = m.supplier_id ORDER BY m.name',
      searchKeys: const ['name', 'code', 'category', 'supplier'],
      titleOf: (r) => '${str(r['name'])}  (${str(r['code'])})',
      subOf: (r) => [str(r['category']), str(r['supplier'])].where((s) => s.isNotEmpty).join(' • '),
      trailing: (c, r) {
        final q = dbl(r['qty']);
        final mn = dbl(r['min_qty']);
        final low = mn > 0 && q <= mn;
        return _col2('${fmt2(q)} ${unitLabel(str(r['unit']))}', low ? t('مخزون منخفض') : money(dbl(r['unit_cost'])),
            bottomColor: low ? C.warning : C.text2);
      },
    );

// ------------------------------------------------------------------ maintenance
Entity maintenanceEntity({int? machineId}) => Entity(
      table: 'maintenance',
      title: 'الصيانة',
      single: 'عملية صيانة',
      icon: 'app_maintenance',
      perm: 'production',
      createdAt: false,
      fields: [
        F('machine_id', 'الآلة', FT.select, required: true, def: machineId, loader: (cur) => optsFrom('machines', 'name')),
        const F('date', 'تاريخ الصيانة', FT.date, required: true, def: 'today'),
        const F('description', 'وصف العملية', FT.multiline),
        const F('technician', 'الفني المسؤول', FT.text),
        const F('parts', 'القطع المطلوبة', FT.text),
        const F('cost', 'التكلفة', FT.decimal, suffix: 'دج'),
        F('status', 'الحالة', FT.select, required: true, def: 'pending', options: const [
          Opt<Object>('pending', 'مجدولة'),
          Opt<Object>('done', 'منتهية'),
        ]),
        const F('notes', 'ملاحظات', FT.multiline),
      ],
      sql:
          'SELECT mt.*, m.name AS machine FROM maintenance mt JOIN machines m ON m.id = mt.machine_id ${machineId == null ? '' : 'WHERE mt.machine_id = $machineId '}ORDER BY mt.date DESC',
      searchKeys: const ['machine', 'description', 'technician'],
      titleOf: (r) => '${str(r['machine'])} - ${showDate(str(r['date']))}',
      subOf: (r) => str(r['description']),
      trailing: (c, r) {
        final done = str(r['status']) == 'done';
        return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Tag(done ? t('منتهية') : t('مجدولة'), done ? C.success : C.warning),
          if (dbl(r['cost']) > 0) Text(money(dbl(r['cost'])), style: const TextStyle(fontSize: 12, color: C.text2)),
        ]);
      },
      after: (id, v) async {
        await Svc.syncMachineAfterMaintenance(intv(v['machine_id']));
      },
    );

// ------------------------------------------------------------------ orders
Entity ordersEntity() => Entity(
      table: 'orders',
      title: 'الطلبات القادمة',
      single: 'طلب',
      icon: 'app_orders',
      perm: 'sales',
      createdAt: false,
      fields: [
        const F('customer_id', 'العميل', FT.select, required: true, loader: null),
        const F('product_id', 'المنتج', FT.select, required: true),
        const F('qty', 'الكمية المطلوبة', FT.integer, required: true, suffix: 'قطعة', positive: true),
        const F('order_date', 'تاريخ الطلب', FT.date, required: true, def: 'today'),
        const F('delivery_date', 'تاريخ التسليم المطلوب', FT.date),
        F('status', 'الحالة', FT.select, required: true, def: 'new', options: [
          for (final k in orderStatusLabels.keys) Opt<Object>(k, orderStatusLabels[k]!),
        ]),
        const F('notes', 'ملاحظات', FT.multiline),
      ],
      sql:
          'SELECT o.*, c.name AS customer, p.name AS product FROM orders o LEFT JOIN customers c ON c.id = o.customer_id LEFT JOIN products p ON p.id = o.product_id ORDER BY CASE WHEN o.status IN (\'delivered\',\'cancelled\') THEN 1 ELSE 0 END, o.delivery_date ASC',
      searchKeys: const ['number', 'customer', 'product'],
      titleOf: (r) => '#${str(r['number'])} • ${str(r['customer'])}',
      subOf: (r) =>
          '${str(r['product'])} • ${fmt(dbl(r['qty']))} ${t('قطعة')}${str(r['delivery_date']).isEmpty ? '' : ' • ${t('التسليم')}: ${showDate(str(r['delivery_date']))}'}',
      trailing: (c, r) {
        final s = orderStatus(str(r['status']));
        return Tag(s.label, s.color);
      },
      beforeInsert: (v) async {
        v['number'] = await Svc.nextOrderNumber();
      },
    );

/// Orders need loader-based selects, so we build them with this helper.
Entity ordersEntityFull() {
  final base = ordersEntity();
  return Entity(
    table: base.table,
    title: base.title,
    single: base.single,
    icon: base.icon,
    perm: base.perm,
    createdAt: false,
    fields: [
      F('customer_id', 'العميل', FT.select, required: true, loader: (cur) => optsFrom('customers', 'name')),
      F('product_id', 'المنتج', FT.select, required: true, loader: (cur) => optsFrom('products', 'name')),
      ...base.fields.sublist(2),
    ],
    sql: base.sql,
    searchKeys: base.searchKeys,
    titleOf: base.titleOf,
    subOf: base.subOf,
    trailing: base.trailing,
    beforeInsert: base.beforeInsert,
  );
}

// ------------------------------------------------------------------ notes
Entity notesEntity() => Entity(
      table: 'notes',
      title: 'الملاحظات',
      single: 'ملاحظة',
      icon: 'app_notes',
      perm: 'reports',
      createdAt: false,
      searchKeys: const ['title', 'body'],
      fields: [
        const F('title', 'العنوان', FT.text, required: true),
        const F('body', 'نص الملاحظة', FT.multiline),
        const F('date', 'التاريخ', FT.date, required: true, def: 'today'),
        const F('reminder', 'تاريخ التذكير', FT.date),
        const F('important', 'ملاحظة مهمة', FT.toggle),
        const F('done', 'مكتملة', FT.toggle),
        F('link_type', 'ربط بـ', FT.select, options: const [
          Opt<Object>('customer', 'عميل'),
          Opt<Object>('machine', 'آلة'),
          Opt<Object>('order', 'طلب'),
          Opt<Object>('invoice', 'فاتورة'),
          Opt<Object>('production', 'دفعة إنتاج'),
        ]),
        F('link_id', 'العنصر المرتبط', FT.select, dependsOn: 'link_type', loader: (cur) async {
          switch (cur['link_type']) {
            case 'customer':
              return optsFrom('customers', 'name');
            case 'machine':
              return optsFrom('machines', 'name');
            case 'order':
              return optsFrom('orders', 'number');
            case 'invoice':
              return optsFrom('invoices', 'number');
            case 'production':
              return optsFrom('production', 'code');
          }
          return <Opt<Object>>[];
        }),
      ],
      sql: 'SELECT * FROM notes ORDER BY done ASC, important DESC, date DESC, id DESC',
      titleOf: (r) => str(r['title']),
      subOf: (r) {
        final parts = <String>[showDate(str(r['date']))];
        if (str(r['reminder']).isNotEmpty) parts.add('${t('تذكير')}: ${showDate(str(r['reminder']))}');
        if (str(r['body']).isNotEmpty) parts.add(str(r['body']).split('\n').first);
        return parts.join(' • ');
      },
      trailing: (c, r) => Row(mainAxisSize: MainAxisSize.min, children: [
        if (intv(r['important']) == 1) const Icon(Icons.star_rounded, color: C.warning),
        if (intv(r['done']) == 1) const Icon(Icons.check_circle_rounded, color: C.success),
      ]),
    );

// ------------------------------------------------------------------ transactions (expenses & income)
Entity transactionEntity() => Entity(
      table: 'transactions',
      title: 'المصاريف والمعاملات',
      single: 'معاملة',
      icon: 'app_expenses',
      perm: 'finance',
      searchKeys: const ['description', 'category', 'party'],
      fields: [
        const F('date', 'التاريخ', FT.date, required: true, def: 'today'),
        F('kind', 'نوع المعاملة', FT.select, required: true, def: 'expense', options: [
          for (final k in kindLabels.keys) Opt<Object>(k, kindLabels[k]!),
        ]),
        F('category', 'التصنيف', FT.select, options: [
          for (final c in expenseCategories) Opt<Object>(c, c),
        ]),
        const F('description', 'الوصف', FT.text),
        const F('amount', 'المبلغ', FT.decimal, required: true, positive: true, suffix: 'دج'),
        F('method', 'طريقة الدفع', FT.select, def: 'cash', options: [
          for (final k in methodLabels.keys) Opt<Object>(k, methodLabels[k]!),
        ]),
        const F('party', 'الطرف المعني', FT.text),
        const F('attachment', 'مرفق', FT.file),
        const F('notes', 'ملاحظات', FT.multiline),
      ],
      titleOf: (r) => str(r['description']).isEmpty ? str(r['category']) : str(r['description']),
      beforeInsert: (v) async {
        v['user'] = 'app';
      },
    );
