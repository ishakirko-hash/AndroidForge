import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/labels.dart';
import '../core/i18n.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import '../data/db.dart';
import '../data/services.dart';
import 'entities.dart';
import 'entity.dart';
import 'production.dart';

class MachinesPage extends StatelessWidget {
  const MachinesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final can = AppState.i.can('production');
    return PageScaffold(
      title: 'الآلات',
      fab: can
          ? FloatingActionButton.extended(
              backgroundColor: C.primary,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: Text(t('إضافة آلة')),
              onPressed: () => go(context, EntityForm(entity: machinesEntity())),
            )
          : null,
      body: DataView<List<Rec>>(
        load: () => Db.q(
            "SELECT m.*, COALESCE((SELECT SUM(accepted) FROM production pr WHERE pr.machine_id = m.id AND pr.status = 'done'),0) AS output, COALESCE((SELECT SUM(target) FROM production pr WHERE pr.machine_id = m.id AND pr.status = 'done'),0) AS target, COALESCE((SELECT SUM(downtime_min) FROM production pr WHERE pr.machine_id = m.id AND pr.status = 'done'),0) AS downtime, (SELECT COUNT(*) FROM maintenance mt WHERE mt.machine_id = m.id AND mt.status = 'pending') AS pending FROM machines m ORDER BY m.name"),
        builder: (c, rows) {
          if (rows.isEmpty) return const EmptyBox('لا توجد آلات');
          var working = 0, stopped = 0, maint = 0;
          for (final r in rows) {
            switch (r['status']) {
              case 'stopped':
                stopped++;
                break;
              case 'maintenance':
                maint++;
                break;
              default:
                working++;
            }
          }
          return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
            kpiRow(
              KpiTile(icon: Icons.settings_suggest_rounded, color: C.primary, title: 'إجمالي الآلات', value: '${rows.length}'),
              KpiTile(icon: Icons.play_arrow_rounded, color: C.success, title: 'تعمل', value: '$working'),
            ),
            kpiRow(
              KpiTile(icon: Icons.stop_rounded, color: C.error, title: 'متوقفة', value: '$stopped'),
              KpiTile(icon: Icons.build_rounded, color: C.warning, title: 'صيانة', value: '$maint'),
            ),
            for (final m in rows) _card(context, m),
          ]);
        },
      ),
    );
  }

  Widget _card(BuildContext context, Rec m) {
    final st = machineStatus(str(m['status']));
    final target = dbl(m['target']);
    final eff = target > 0 ? '${(dbl(m['output']) / target * 100).toStringAsFixed(0)}%' : '-';
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: C.border)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () => go(context, MachineDetail(id: intv(m['id']))),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              machineThumb(m['image'] as String?),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${str(m['name'])}  (${str(m['code'])})', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                  Text('${t('الإنتاج')}: ${fmt(dbl(m['output']))} • ${t('الكفاءة')}: $eff', style: const TextStyle(fontSize: 12, color: C.text2)),
                  Text('${t('ساعات التشغيل')}: ${fmt2(dbl(m['hours']))} • ${t('التوقفات')}: ${fmt(dbl(m['downtime']))} ${t('د')}',
                      style: const TextStyle(fontSize: 12, color: C.text2)),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Tag(st.label, st.color),
                if (intv(m['pending']) > 0) ...[
                  const SizedBox(height: 3),
                  Text('${intv(m['pending'])} ${t('صيانة مجدولة')}', style: const TextStyle(fontSize: 11, color: C.warning, fontWeight: FontWeight.w700)),
                ],
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

class MachineDetail extends StatelessWidget {
  final int id;
  const MachineDetail({super.key, required this.id});

  Future<void> _setStatus(BuildContext context, String s) async {
    await Db.update('machines', {'status': s}, id);
    await Svc.auditDb('status', 'machines', id, s);
    if (context.mounted) toast(context, 'تم تحديث حالة الآلة');
  }

  @override
  Widget build(BuildContext context) {
    final can = AppState.i.can('production');
    return PageScaffold(
      title: 'تفاصيل الآلة',
      actions: [
        if (can)
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: () async {
              final r = await Db.one('SELECT * FROM machines WHERE id = ?', [id]);
              if (r != null && context.mounted) await go(context, EntityForm(entity: machinesEntity(), row: r));
            },
          ),
      ],
      body: DataView<Rec>(
        load: () async {
          final m = await Db.one('SELECT * FROM machines WHERE id = ?', [id]);
          final prod = await Db.q(
              "SELECT pr.*, p.name AS product FROM production pr JOIN products p ON p.id = pr.product_id WHERE pr.machine_id = ? ORDER BY pr.date DESC, pr.id DESC LIMIT 15",
              [id]);
          final maint = await Db.q('SELECT * FROM maintenance WHERE machine_id = ? ORDER BY date DESC', [id]);
          final output = await Db.sum("SELECT COALESCE(SUM(accepted),0) FROM production WHERE machine_id = ? AND status = 'done'", [id]);
          final target = await Db.sum("SELECT COALESCE(SUM(target),0) FROM production WHERE machine_id = ? AND status = 'done'", [id]);
          final actual = await Db.sum("SELECT COALESCE(SUM(actual),0) FROM production WHERE machine_id = ? AND status = 'done'", [id]);
          final defective = await Db.sum("SELECT COALESCE(SUM(defective),0) FROM production WHERE machine_id = ? AND status = 'done'", [id]);
          final downtime = await Db.sum("SELECT COALESCE(SUM(downtime_min),0) FROM production WHERE machine_id = ? AND status = 'done'", [id]);
          return {'m': m, 'prod': prod, 'maint': maint, 'output': output, 'target': target, 'actual': actual, 'defective': defective, 'downtime': downtime};
        },
        builder: (ctx, d) {
          final m = d['m'] as Rec?;
          if (m == null) return const EmptyBox('الآلة غير موجودة');
          final prod = d['prod'] as List<Rec>;
          final maint = d['maint'] as List<Rec>;
          final target = dbl(d['target']);
          final actual = dbl(d['actual']);
          final st = machineStatus(str(m['status']));
          return ListView(padding: const EdgeInsets.all(12), children: [
            Panel(
              title: str(m['name']),
              icon: Icons.settings_suggest_rounded,
              trailing: Tag(st.label, st.color),
              child: Column(children: [
                SizedBox(height: 110, child: Image.asset(str(m['image']).isEmpty ? 'assets/images/machine.png' : str(m['image']), fit: BoxFit.contain)),
                KV('الرمز', str(m['code'])),
                KV('ساعات التشغيل', '${fmt2(dbl(m['hours']))} ${t('ساعة')}'),
                if (str(m['notes']).isNotEmpty) KV('ملاحظات', str(m['notes'])),
              ]),
            ),
            if (can)
              Row(children: [
                for (final s in const [
                  ['working', 'تشغيل', Icons.play_arrow_rounded],
                  ['stopped', 'إيقاف', Icons.stop_rounded],
                  ['maintenance', 'صيانة', Icons.build_rounded],
                ])
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: OutlinedButton.icon(
                        icon: Icon(s[2] as IconData, size: 18),
                        label: Text(t(s[1] as String)),
                        onPressed: () => _setStatus(context, s[0] as String),
                      ),
                    ),
                  ),
              ]),
            gap(10),
            Panel(
              title: 'إحصائيات الأداء',
              icon: Icons.speed_rounded,
              child: Column(children: [
                KV('إجمالي الإنتاج المقبول', '${fmt(dbl(d['output']))} ${t('قطعة')}', bold: true),
                KV('الكفاءة (الفعلي / الهدف)', target > 0 ? '${(dbl(d['output']) / target * 100).toStringAsFixed(1)}%' : '-'),
                KV('نسبة المعيب', actual > 0 ? '${(dbl(d['defective']) / actual * 100).toStringAsFixed(1)}%' : '-'),
                KV('إجمالي التوقفات', '${fmt(dbl(d['downtime']))} ${t('دقيقة')}'),
              ]),
            ),
            Panel(
              title: 'سجل الإنتاج',
              icon: Icons.assignment_rounded,
              padding: const EdgeInsets.all(8),
              child: prod.isEmpty
                  ? const EmptyBox('لا يوجد إنتاج مسجل لهذه الآلة')
                  : Column(children: [
                      for (final r in prod)
                        ListTile(
                          dense: true,
                          onTap: () => go(context, ProductionView(id: intv(r['id']))),
                          title: Text('#${str(r['code'])} • ${str(r['product'])}'),
                          subtitle: Text(showDate(str(r['date']))),
                          trailing: Text(fmt(dbl(r['accepted'])), style: const TextStyle(fontWeight: FontWeight.w800)),
                        ),
                    ]),
            ),
            Panel(
              title: 'سجل الصيانة',
              icon: Icons.build_rounded,
              trailing: can
                  ? TextButton.icon(
                      icon: const Icon(Icons.add_rounded, size: 18),
                      label: Text(t('إضافة')),
                      onPressed: () => go(context, EntityForm(entity: maintenanceEntity(machineId: id))),
                    )
                  : null,
              child: maint.isEmpty
                  ? const EmptyBox('لا توجد عمليات صيانة')
                  : Column(children: [
                      for (final x in maint)
                        ListTile(
                          dense: true,
                          onTap: can ? () => go(context, EntityForm(entity: maintenanceEntity(machineId: id), row: x)) : null,
                          title: Text('${showDate(str(x['date']))} • ${str(x['description'])}'),
                          subtitle: Text(str(x['technician'])),
                          trailing: Tag(x['status'] == 'done' ? t('منتهية') : t('مجدولة'), x['status'] == 'done' ? C.success : C.warning),
                        ),
                    ]),
            ),
          ]);
        },
      ),
    );
  }
}

// ====================================================================== SHIFTS
class ShiftsPage extends StatefulWidget {
  const ShiftsPage({super.key});
  @override
  State<ShiftsPage> createState() => _ShiftsPageState();
}

class _ShiftsPageState extends State<ShiftsPage> {
  String date = today();

  Future<List<Rec>> _load() async {
    final out = <Rec>[];
    for (final k in const ['morning', 'afternoon', 'night']) {
      final s = await Db.one('SELECT * FROM shifts WHERE date = ? AND kind = ?', [date, k]);
      List<Rec> emps = [];
      if (s != null) {
        emps = await Db.q(
            'SELECT se.id AS se_id, se.attendance, e.id AS emp_id, e.name, e.role FROM shift_employees se JOIN employees e ON e.id = se.employee_id WHERE se.shift_id = ? ORDER BY e.name',
            [s['id']]);
      }
      out.add({'kind': k, 'shift': s, 'emps': emps});
    }
    return out;
  }

  void _moveDay(int delta) {
    final d = parseYmd(date) ?? DateTime.now();
    setState(() => date = ymd(d.add(Duration(days: delta))));
  }

  Future<void> _addEmployees(String kind, Rec? shift, List<Rec> current) async {
    final all = await Db.q("SELECT id, name, role FROM employees WHERE status = 'active' ORDER BY name");
    final assigned = current.map((e) => e['emp_id']).toSet();
    final avail = all.where((e) => !assigned.contains(e['id'])).toList();
    if (!mounted) return;
    if (avail.isEmpty) {
      toast(context, 'لا يوجد موظفون متاحون للإضافة', error: true);
      return;
    }
    final chosen = <int>{};
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.7,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text('${t('إضافة موظفين إلى المناوبة')} ${shiftLabel(kind)}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            ),
            Expanded(
              child: ListView(children: [
                for (final e in avail)
                  CheckboxListTile(
                    value: chosen.contains(e['id']),
                    title: Text(str(e['name'])),
                    subtitle: Text(str(e['role'])),
                    onChanged: (v) => setS(() {
                      if (v == true) {
                        chosen.add(e['id'] as int);
                      } else {
                        chosen.remove(e['id']);
                      }
                    }),
                  ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: PrimaryButton('إضافة المحددين', onPressed: () async {
                if (chosen.isEmpty) return;
                final sid = await Svc.ensureShift(date, kind);
                for (final id in chosen) {
                  await Db.d.insert('shift_employees', {'shift_id': sid, 'employee_id': id, 'attendance': 'present'},
                      conflictAlgorithm: ConflictAlgorithm.ignore);
                }
                Db.notify();
                if (ctx.mounted) Navigator.pop(ctx);
              }),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final can = AppState.i.can('hr');
    final d = parseYmd(date) ?? DateTime.now();
    return PageScaffold(
      title: 'المناوبات',
      body: Column(children: [
        Container(
          color: C.card,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          child: Row(children: [
            IconButton(icon: const Icon(Icons.chevron_left_rounded), onPressed: () => _moveDay(S.ar ? 1 : -1)),
            Expanded(
              child: InkWell(
                onTap: () async {
                  final r = await showDatePicker(context: context, initialDate: d, firstDate: DateTime(2020), lastDate: DateTime(2100));
                  if (r != null) setState(() => date = ymd(r));
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(fullDate(d), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                ),
              ),
            ),
            IconButton(icon: const Icon(Icons.chevron_right_rounded), onPressed: () => _moveDay(S.ar ? -1 : 1)),
          ]),
        ),
        Expanded(
          child: DataView<List<Rec>>(
            load: _load,
            builder: (c, shifts) {
              var present = 0, absent = 0;
              for (final s in shifts) {
                for (final e in s['emps'] as List<Rec>) {
                  if (e['attendance'] == 'absent') {
                    absent++;
                  } else {
                    present++;
                  }
                }
              }
              return ListView(padding: const EdgeInsets.all(12), children: [
                kpiRow(
                  KpiTile(icon: Icons.how_to_reg_rounded, color: C.success, title: 'الحضور', value: '$present'),
                  KpiTile(icon: Icons.person_off_rounded, color: C.error, title: 'الغياب', value: '$absent'),
                ),
                for (final s in shifts) _shiftCard(s, can),
              ]);
            },
          ),
        ),
      ]),
    );
  }

  Widget _shiftCard(Rec s, bool can) {
    final kind = s['kind'] as String;
    final shift = s['shift'] as Rec?;
    final emps = s['emps'] as List<Rec>;
    final times = shift != null ? [str(shift['start_time']), str(shift['end_time'])] : Svc.shiftTimesFor(kind);
    final closed = shift != null && shift['status'] == 'closed';
    return Panel(
      title: '${t('المناوبة')} ${shiftLabel(kind)}',
      icon: kind == 'night' ? Icons.nights_stay_rounded : Icons.wb_sunny_rounded,
      iconColor: kind == 'night' ? C.purple : C.warning,
      trailing: Tag(closed ? t('مغلقة') : t('مفتوحة'), closed ? C.text2 : C.success),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('${times[0]} - ${times[1]}', style: const TextStyle(color: C.text2, fontSize: 13)),
        gap(6),
        if (emps.isEmpty) const EmptyBox('لم يُضف موظفون إلى هذه المناوبة'),
        for (final e in emps)
          Container(
            margin: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(
              color: e['attendance'] == 'absent' ? tint(C.error, 0.08) : tint(C.success, 0.08),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: can && !closed
                    ? () async {
                        await Db.d.update('shift_employees', {'attendance': e['attendance'] == 'absent' ? 'present' : 'absent'},
                            where: 'id = ?', whereArgs: [e['se_id']]);
                        Db.notify();
                      }
                    : null,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  child: Row(children: [
                    Icon(e['attendance'] == 'absent' ? Icons.cancel_rounded : Icons.check_circle_rounded,
                        color: e['attendance'] == 'absent' ? C.error : C.success),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(str(e['name']), style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(e['attendance'] == 'absent' ? t('غائب') : t('حاضر'), style: const TextStyle(fontSize: 12, color: C.text2)),
                      ]),
                    ),
                    if (can && !closed)
                      IconButton(
                        icon: const Icon(Icons.person_remove_rounded, color: C.error),
                        onPressed: () async {
                          final ok = await confirm(context, 'إزالة الموظف من المناوبة؟', yes: 'إزالة');
                          if (!ok) return;
                          await Db.d.delete('shift_employees', where: 'id = ?', whereArgs: [e['se_id']]);
                          Db.notify();
                        },
                      ),
                  ]),
                ),
              ),
            ),
          ),
        if (can && !closed)
          OutlinedButton.icon(
            icon: const Icon(Icons.person_add_alt_1_rounded),
            label: Text(t('إضافة موظفين')),
            onPressed: () => _addEmployees(kind, shift, emps),
          ),
        if (can && shift != null)
          TextButton(
            onPressed: () async {
              await Db.update('shifts', {'status': closed ? 'open' : 'closed'}, intv(shift['id']));
            },
            child: Text(t(closed ? 'إعادة فتح المناوبة' : 'إغلاق المناوبة')),
          ),
      ]),
    );
  }
}
