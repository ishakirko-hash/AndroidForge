import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/i18n.dart';
import '../core/labels.dart';
import '../data/db.dart';

class PdfService {
  static pw.Font? _font;
  static pw.Font? _bold;
  static pw.MemoryImage? _logo;

  static const PdfColor navy = PdfColor.fromInt(0xFF123C70);
  static const PdfColor light = PdfColor.fromInt(0xFFE8F2FC);
  static const PdfColor border = PdfColor.fromInt(0xFFDCE4EF);

  static Future<void> _init() async {
    if (_font != null) return;
    final f = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final b = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
    final l = await rootBundle.load('assets/images/logo_color.png');
    _font = pw.Font.ttf(f);
    _bold = pw.Font.ttf(b);
    _logo = pw.MemoryImage(l.buffer.asUint8List());
  }

  static List<T> _ord<T>(List<T> l) => S.ar ? l.reversed.toList() : l;

  static pw.Widget _t(String s, {double size = 10, bool bold = false, PdfColor? color, pw.TextAlign? align}) {
    return pw.Text(
      s,
      textDirection: S.ar ? pw.TextDirection.rtl : pw.TextDirection.ltr,
      textAlign: align ?? (S.ar ? pw.TextAlign.right : pw.TextAlign.left),
      style: pw.TextStyle(fontSize: size, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal, color: color),
    );
  }

  static pw.Widget _cell(String s, {bool bold = false, PdfColor? color, double size = 9.5}) =>
      pw.Padding(padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 5), child: _t(s, size: size, bold: bold, color: color));

  static pw.Widget _header() {
    final app = AppState.i;
    final info = <String>[
      if (app.get('company_phone').isNotEmpty) app.get('company_phone'),
      if (app.get('company_address').isNotEmpty) app.get('company_address'),
      if (app.get('company_taxid').isNotEmpty) app.get('company_taxid'),
    ];
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      crossAxisAlignment: pw.CrossAxisAlignment.center,
      children: _ord<pw.Widget>([
        pw.Image(_logo!, height: 52),
        pw.Column(
          crossAxisAlignment: S.ar ? pw.CrossAxisAlignment.start : pw.CrossAxisAlignment.end,
          children: [
            _t(app.company, size: 15, bold: true, color: navy),
            for (final i in info) _t(i, size: 9),
          ],
        ),
      ]),
    );
  }

  static Future<Uint8List> invoice(int id) async {
    await _init();
    final inv = await Db.one('SELECT * FROM invoices WHERE id = ?', [id]);
    if (inv == null) throw StateError('invoice not found');
    final items = await Db.q('SELECT * FROM invoice_items WHERE invoice_id = ?', [id]);
    final total = dbl(inv['total']);
    final paid = dbl(inv['paid']);
    final footer = AppState.i.get('invoice_footer');

    pw.Widget kv(String k, String v, {bool bold = false}) => pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 2),
          child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: _ord<pw.Widget>([
            _t(k, bold: bold),
            _t(v, bold: bold),
          ])),
        );

    final widths = _ord<double>([3, 1, 1.4, 1.6]);
    final table = pw.Table(
      border: pw.TableBorder.all(color: border, width: 0.6),
      columnWidths: {for (var i = 0; i < widths.length; i++) i: pw.FlexColumnWidth(widths[i])},
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: light),
          children: _ord<pw.Widget>([
            _cell(t('المنتج'), bold: true),
            _cell(t('الكمية'), bold: true),
            _cell(t('سعر الوحدة'), bold: true),
            _cell(t('الإجمالي'), bold: true),
          ]),
        ),
        for (final it in items)
          pw.TableRow(
            children: _ord<pw.Widget>([
              _cell(str(it['name'])),
              _cell(fmt(dbl(it['qty']))),
              _cell(fmt(dbl(it['unit_price']))),
              _cell(fmt(dbl(it['total']))),
            ]),
          ),
      ],
    );

    final doc = pw.Document(theme: pw.ThemeData.withFont(base: _font!, bold: _bold!));
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(30),
      build: (ctx) => [
        _header(),
        pw.SizedBox(height: 8),
        pw.Divider(color: navy, thickness: 1.5),
        pw.SizedBox(height: 6),
        pw.Align(
          alignment: S.ar ? pw.Alignment.centerRight : pw.Alignment.centerLeft,
          child: _t('${t('فاتورة')} #${str(inv['number'])}', size: 18, bold: true, color: navy),
        ),
        pw.SizedBox(height: 8),
        kv(t('التاريخ'), showDate(str(inv['date']))),
        kv(t('العميل'), str(inv['customer_name']).isEmpty ? t('عميل عابر') : str(inv['customer_name'])),
        kv(t('طريقة الدفع'), methodLabel(str(inv['method']))),
        kv(t('الحالة'), invoiceStatus(str(inv['status'])).label),
        pw.SizedBox(height: 12),
        table,
        pw.SizedBox(height: 12),
        pw.Align(
          alignment: S.ar ? pw.Alignment.centerLeft : pw.Alignment.centerRight,
          child: pw.SizedBox(
            width: 240,
            child: pw.Column(children: [
              kv(t('المجموع الفرعي'), money(dbl(inv['subtotal']))),
              kv(t('الخصم'), money(dbl(inv['discount']))),
              kv('${t('الضريبة')} (${fmt2(dbl(inv['tax_rate']))}%)', money(dbl(inv['tax']))),
              pw.Divider(color: border),
              kv(t('الإجمالي'), money(total), bold: true),
              kv(t('المدفوع'), money(paid)),
              kv(t('المتبقي'), money(inv['status'] == 'cancelled' ? 0 : total - paid), bold: true),
            ]),
          ),
        ),
        if (str(inv['notes']).isNotEmpty) ...[
          pw.SizedBox(height: 10),
          _t('${t('ملاحظات')}: ${str(inv['notes'])}', size: 9),
        ],
        if (footer.isNotEmpty) ...[
          pw.SizedBox(height: 18),
          pw.Center(child: _t(footer, size: 9, align: pw.TextAlign.center)),
        ],
      ],
    ));
    return doc.save();
  }

  static Future<Uint8List> report(String title, String period, List<String> heads, List<List<String>> rows, List<String>? totals) async {
    await _init();
    final n = heads.length;
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: _font!, bold: _bold!));
    final widths = _ord<double>(List<double>.filled(n, 1));
    final table = pw.Table(
      border: pw.TableBorder.all(color: border, width: 0.5),
      columnWidths: {for (var i = 0; i < n; i++) i: pw.FlexColumnWidth(widths[i])},
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: light),
          repeat: true,
          children: _ord<pw.Widget>([for (final h in heads) _cell(h, bold: true, size: 9)]),
        ),
        for (final r in rows) pw.TableRow(children: _ord<pw.Widget>([for (final c in r) _cell(c, size: 9)])),
        if (totals != null)
          pw.TableRow(
            decoration: const pw.BoxDecoration(color: light),
            children: _ord<pw.Widget>([for (final c in totals) _cell(c, bold: true, size: 9, color: navy)]),
          ),
      ],
    );
    doc.addPage(pw.MultiPage(
      pageFormat: n > 6 ? PdfPageFormat.a4.landscape : PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      build: (ctx) => [
        _header(),
        pw.SizedBox(height: 6),
        pw.Divider(color: navy, thickness: 1.5),
        pw.Align(alignment: S.ar ? pw.Alignment.centerRight : pw.Alignment.centerLeft, child: _t(title, size: 16, bold: true, color: navy)),
        _t(period, size: 10),
        pw.SizedBox(height: 10),
        table,
      ],
    ));
    return doc.save();
  }

  static Future<void> printBytes(Uint8List bytes, String name) async {
    await Printing.layoutPdf(onLayout: (format) async => bytes, name: name);
  }

  static Future<void> shareBytes(Uint8List bytes, String filename) async {
    await Printing.sharePdf(bytes: bytes, filename: filename);
  }
}
