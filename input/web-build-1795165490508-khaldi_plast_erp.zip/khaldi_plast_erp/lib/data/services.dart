import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../core/app_state.dart';
import '../core/format.dart';
import '../core/i18n.dart';
import 'db.dart';

class AppErr implements Exception {
  final String msg;
  AppErr(this.msg);
  @override
  String toString() => msg;
}

class AlertItem {
  final String key;
  final String title;
  final String desc;
  final String severity; // critical, warning, info
  final String module; // inventory, production, sales, orders, machines, materials
  final String date;
  final int? refId;
  bool read;
  AlertItem(this.key, this.title, this.desc, this.severity, this.module, this.date, {this.refId, this.read = false});
}

class Svc {
  static String nowIso() => DateTime.now().toIso8601String();

  static Future<void> audit(DatabaseExecutor ex, String action, String entity, int? id, [String details = '']) async {
    await ex.insert('audit_log', {
      'at': nowIso(),
      'user': AppState.i.roleName,
      'action': action,
      'entity': entity,
      'entity_id': id,
      'details': details,
    });
  }

  static Future<void> auditDb(String action, String entity, int? id, [String details = '']) async {
    await audit(Db.d, action, entity, id, details);
  }

  static Future<String> nextNumber(DatabaseExecutor ex, String table, String column, String prefix) async {
    final year = DateTime.now().year;
    final rows = await ex.rawQuery('SELECT $column AS c FROM $table WHERE $column LIKE ?', ['$prefix$year-%']);
    var mx = 0;
    for (final r in rows) {
      final s = (r['c'] as String?) ?? '';
      final n = int.tryParse(s.split('-').last) ?? 0;
      if (n > mx) mx = n;
    }
    return '$prefix$year-${(mx + 1).toString().padLeft(4, '0')}';
  }

  static Future<String> nextInvoiceNumber() => nextNumber(Db.d, 'invoices', 'number', '');
  static Future<String> nextOrderNumber() => nextNumber(Db.d, 'orders', 'number', '');

  // ---------------------------------------------------------------- stock helpers
  static Future<void> _moveProduct(DatabaseExecutor ex, int pid, double delta, String kind, String? refType, int? refId, String notes) async {
    await ex.rawUpdate('UPDATE products SET qty = ROUND(qty + ?, 3) WHERE id = ?', [delta, pid]);
    await ex.insert('stock_movements', {
      'date': today(),
      'kind': kind,
      'item_type': 'product',
      'item_id': pid,
      'qty': delta,
      'ref_type': refType,
      'ref_id': refId,
      'user': AppState.i.roleName,
      'notes': notes,
      'created_at': nowIso(),
    });
  }

  static Future<void> _moveMaterial(DatabaseExecutor ex, int mid, double delta, String kind, String? refType, int? refId, String notes) async {
    await ex.rawUpdate('UPDATE materials SET qty = ROUND(qty + ?, 3) WHERE id = ?', [delta, mid]);
    await ex.insert('stock_movements', {
      'date': today(),
      'kind': kind,
      'item_type': 'material',
      'item_id': mid,
      'qty': delta,
      'ref_type': refType,
      'ref_id': refId,
      'user': AppState.i.roleName,
      'notes': notes,
      'created_at': nowIso(),
    });
  }

  // ---------------------------------------------------------------- invoices
  static String invoiceStatusFor(double total, double paid) {
    if (total > 0 && paid >= total - 0.005) return 'paid';
    if (paid > 0.005) return 'partial';
    return 'unpaid';
  }

  /// Creates or edits an invoice inside ONE database transaction:
  /// invoice + items + payment + stock withdrawal movements.
  static Future<int> saveInvoice({int? id, required Rec head, required List<Rec> items}) async {
    if (items.isEmpty) throw AppErr('أضف منتجًا واحدًا على الأقل');
    var subtotal = 0.0;
    for (final it in items) {
      final q = dbl(it['qty']);
      final pr = dbl(it['unit_price']);
      if (intv(it['product_id']) == 0) throw AppErr('اختر المنتج');
      if (q <= 0) throw AppErr('الكمية يجب أن تكون أكبر من صفر');
      if (pr < 0) throw AppErr('السعر غير صالح');
      it['total'] = r2(q * pr);
      subtotal += dbl(it['total']);
    }
    subtotal = r2(subtotal);
    final discount = r2(dbl(head['discount']));
    if (discount < 0 || discount > subtotal) throw AppErr('الخصم غير صالح');
    final taxRate = dbl(head['tax_rate']);
    if (taxRate < 0) throw AppErr('نسبة الضريبة غير صالحة');
    final tax = r2((subtotal - discount) * taxRate / 100);
    final total = r2(subtotal - discount + tax);
    final paidNew = r2(dbl(head['paid']));
    if (paidNew < 0 || paidNew > total + 0.005) throw AppErr('المبلغ المدفوع أكبر من إجمالي الفاتورة');

    try {
      final invId = await Db.d.transaction<int>((txn) async {
        final now = nowIso();
        var existingPaid = 0.0;
        if (id != null) {
          final old = await txn.rawQuery('SELECT * FROM invoices WHERE id = ?', [id]);
          if (old.isEmpty) throw AppErr('الفاتورة غير موجودة');
          if (old.first['status'] == 'cancelled') throw AppErr('لا يمكن تعديل فاتورة ملغاة');
          existingPaid = dbl(old.first['paid']);
          if (paidNew < existingPaid - 0.005) throw AppErr('لا يمكن تخفيض المبلغ المدفوع من هنا');
          final olds = await txn.rawQuery('SELECT * FROM invoice_items WHERE invoice_id = ?', [id]);
          for (final o in olds) {
            await _moveProduct(txn, intv(o['product_id']), dbl(o['qty']), 'return', 'invoice', id, 'تعديل الفاتورة');
          }
          await txn.delete('invoice_items', where: 'invoice_id = ?', whereArgs: [id]);
        }
        final need = <int, double>{};
        for (final it in items) {
          final pid = intv(it['product_id']);
          need[pid] = (need[pid] ?? 0) + dbl(it['qty']);
        }
        for (final e in need.entries) {
          final pr = await txn.rawQuery('SELECT name, qty FROM products WHERE id = ?', [e.key]);
          if (pr.isEmpty) throw AppErr('منتج غير موجود');
          if (dbl(pr.first['qty']) < e.value - 0.0001) {
            throw AppErr('المخزون غير كافٍ للمنتج ${pr.first['name']} (المتوفر: ${fmt(dbl(pr.first['qty']))})');
          }
        }
        final row = <String, Object?>{
          'number': head['number'],
          'date': head['date'],
          'customer_id': head['customer_id'],
          'customer_name': head['customer_name'],
          'subtotal': subtotal,
          'discount': discount,
          'tax_rate': taxRate,
          'tax': tax,
          'total': total,
          'paid': paidNew,
          'method': head['method'],
          'status': invoiceStatusFor(total, paidNew),
          'notes': head['notes'],
          'updated_at': now,
        };
        int invoiceId;
        if (id == null) {
          row['created_at'] = now;
          invoiceId = await txn.insert('invoices', row);
        } else {
          await txn.update('invoices', row, where: 'id = ?', whereArgs: [id]);
          invoiceId = id;
        }
        for (final it in items) {
          await txn.insert('invoice_items', {
            'invoice_id': invoiceId,
            'product_id': it['product_id'],
            'name': it['name'],
            'qty': dbl(it['qty']),
            'unit_price': dbl(it['unit_price']),
            'total': it['total'],
          });
          await _moveProduct(txn, intv(it['product_id']), -dbl(it['qty']), 'sale_out', 'invoice', invoiceId, '');
        }
        final diff = r2(paidNew - existingPaid);
        if (diff > 0) {
          await txn.insert('payments', {
            'invoice_id': invoiceId,
            'date': head['date'],
            'amount': diff,
            'method': head['method'],
            'notes': '',
          });
        }
        await audit(txn, id == null ? 'create' : 'update', 'invoice', invoiceId, 'number=${head['number']} total=$total');
        return invoiceId;
      });
      Db.notify();
      return invId;
    } on DatabaseException catch (e) {
      if (e.toString().contains('UNIQUE')) throw AppErr('رقم الفاتورة مستخدم مسبقًا');
      rethrow;
    }
  }

  static Future<void> cancelInvoice(int id) async {
    await Db.d.transaction<void>((txn) async {
      final inv = await txn.rawQuery('SELECT * FROM invoices WHERE id = ?', [id]);
      if (inv.isEmpty) throw AppErr('الفاتورة غير موجودة');
      if (inv.first['status'] == 'cancelled') throw AppErr('الفاتورة ملغاة مسبقًا');
      final items = await txn.rawQuery('SELECT * FROM invoice_items WHERE invoice_id = ?', [id]);
      for (final o in items) {
        await _moveProduct(txn, intv(o['product_id']), dbl(o['qty']), 'return', 'invoice', id, 'إلغاء الفاتورة');
      }
      await txn.update('invoices', {'status': 'cancelled', 'updated_at': nowIso()}, where: 'id = ?', whereArgs: [id]);
      await audit(txn, 'cancel', 'invoice', id, 'number=${inv.first['number']}');
    });
    Db.notify();
  }

  static Future<void> addPayment(int invoiceId, double amount, String method, String date, String notes) async {
    amount = r2(amount);
    if (amount <= 0) throw AppErr('المبلغ يجب أن يكون أكبر من صفر');
    await Db.d.transaction<void>((txn) async {
      final inv = await txn.rawQuery('SELECT * FROM invoices WHERE id = ?', [invoiceId]);
      if (inv.isEmpty) throw AppErr('الفاتورة غير موجودة');
      if (inv.first['status'] == 'cancelled') throw AppErr('الفاتورة ملغاة');
      final total = dbl(inv.first['total']);
      final paid = dbl(inv.first['paid']);
      if (amount > total - paid + 0.005) throw AppErr('المبلغ أكبر من المتبقي');
      await txn.insert('payments', {
        'invoice_id': invoiceId,
        'date': date,
        'amount': amount,
        'method': method,
        'notes': notes,
      });
      final np = r2(paid + amount);
      await txn.update('invoices', {'paid': np, 'status': invoiceStatusFor(total, np), 'updated_at': nowIso()},
          where: 'id = ?', whereArgs: [invoiceId]);
      await audit(txn, 'payment', 'invoice', invoiceId, 'amount=$amount');
    });
    Db.notify();
  }

  // ---------------------------------------------------------------- production
  static Future<void> _reverseProduction(DatabaseExecutor txn, int id, String why) async {
    final pr = await txn.rawQuery('SELECT * FROM production WHERE id = ?', [id]);
    if (pr.isEmpty) return;
    final r = pr.first;
    final pid = intv(r['product_id']);
    final accepted = dbl(r['accepted']);
    final cur = await txn.rawQuery('SELECT qty, name FROM products WHERE id = ?', [pid]);
    if (cur.isNotEmpty && dbl(cur.first['qty']) - accepted < -0.0001) {
      throw AppErr('لا يمكن تعديل أو إلغاء هذا السجل لأن جزءًا من الكمية المنتجة قد بيع أو صُرف');
    }
    await _moveProduct(txn, pid, -accepted, 'reversal', 'production', id, why);
    final cons = await txn.rawQuery('SELECT * FROM consumption WHERE production_id = ?', [id]);
    for (final c in cons) {
      await _moveMaterial(txn, intv(c['material_id']), dbl(c['actual']), 'reversal', 'production', id, why);
    }
    final mid = r['machine_id'];
    if (mid != null) {
      await txn.rawUpdate('UPDATE machines SET hours = MAX(0, ROUND(hours - ?, 2)) WHERE id = ?', [dbl(r['duration_min']) / 60, mid]);
    }
  }

  static Future<List<String>> materialShortages(List<Rec> cons, {int? editingProductionId}) async {
    final need = <int, double>{};
    for (final c in cons) {
      final m = intv(c['material_id']);
      need[m] = (need[m] ?? 0) + dbl(c['actual']);
    }
    final back = <int, double>{};
    if (editingProductionId != null) {
      final old = await Db.q('SELECT material_id, actual FROM consumption WHERE production_id = ?', [editingProductionId]);
      for (final o in old) {
        back[intv(o['material_id'])] = (back[intv(o['material_id'])] ?? 0) + dbl(o['actual']);
      }
    }
    final out = <String>[];
    for (final e in need.entries) {
      final m = await Db.one('SELECT name, qty FROM materials WHERE id = ?', [e.key]);
      if (m == null) continue;
      final avail = dbl(m['qty']) + (back[e.key] ?? 0);
      if (avail < e.value - 0.0001) out.add('${m['name']} (${t('المتوفر')}: ${fmt2(avail)})');
    }
    return out;
  }

  static Future<int> saveProduction({int? id, required Rec head, required List<Rec> cons}) async {
    final actual = dbl(head['actual']);
    final defective = dbl(head['defective']);
    if (intv(head['product_id']) == 0) throw AppErr('اختر المنتج');
    if (actual < 0 || defective < 0 || dbl(head['target']) < 0) throw AppErr('القيم لا يمكن أن تكون سالبة');
    if (dbl(head['duration_min']) < 0 || dbl(head['downtime_min']) < 0) throw AppErr('القيم لا يمكن أن تكون سالبة');
    if (defective > actual) throw AppErr('عدد المعيب أكبر من الإنتاج الفعلي');
    final accepted = actual - defective;
    for (final c in cons) {
      if (intv(c['material_id']) == 0) throw AppErr('اختر المادة الأولية في كل سطر استهلاك');
      if (dbl(c['actual']) < 0) throw AppErr('كمية الاستهلاك لا يمكن أن تكون سالبة');
    }
    try {
      final pid = await Db.d.transaction<int>((txn) async {
        final now = nowIso();
        String code;
        String history;
        if (id != null) {
          final old = await txn.rawQuery('SELECT * FROM production WHERE id = ?', [id]);
          if (old.isEmpty) throw AppErr('السجل غير موجود');
          if (old.first['status'] == 'cancelled') throw AppErr('لا يمكن تعديل سجل ملغى');
          code = old.first['code'] as String;
          await _reverseProduction(txn, id, 'تعديل سجل الإنتاج $code');
          await txn.delete('consumption', where: 'production_id = ?', whereArgs: [id]);
          history = 'الكمية: ${fmt(dbl(old.first['actual']))} → ${fmt(actual)} | المعيب: ${fmt(dbl(old.first['defective']))} → ${fmt(defective)}';
        } else {
          code = await nextNumber(txn, 'production', 'code', 'P-');
          history = 'الكمية: ${fmt(actual)} | المعيب: ${fmt(defective)}';
        }
        final row = <String, Object?>{
          'code': code,
          'date': head['date'],
          'time': head['time'],
          'shift_kind': head['shift_kind'],
          'machine_id': head['machine_id'],
          'product_id': head['product_id'],
          'employee_id': head['employee_id'],
          'target': dbl(head['target']),
          'actual': actual,
          'accepted': accepted,
          'defective': defective,
          'duration_min': dbl(head['duration_min']),
          'downtime_min': dbl(head['downtime_min']),
          'notes': head['notes'],
          'status': 'done',
          'updated_at': now,
        };
        int prodId;
        if (id == null) {
          row['created_at'] = now;
          prodId = await txn.insert('production', row);
        } else {
          await txn.update('production', row, where: 'id = ?', whereArgs: [id]);
          prodId = id;
        }
        await _moveProduct(txn, intv(head['product_id']), accepted, 'production_in', 'production', prodId, code);
        for (final c in cons) {
          final mid = intv(c['material_id']);
          final m = await txn.rawQuery('SELECT unit_cost FROM materials WHERE id = ?', [mid]);
          final cost = m.isEmpty ? 0.0 : dbl(m.first['unit_cost']);
          await txn.insert('consumption', {
            'production_id': prodId,
            'material_id': mid,
            'per_piece_g': dbl(c['per_piece_g']),
            'planned': dbl(c['planned']),
            'actual': dbl(c['actual']),
            'unit_cost': cost,
            'date': head['date'],
          });
          await _moveMaterial(txn, mid, -dbl(c['actual']), 'material_use', 'production', prodId, code);
        }
        if (head['machine_id'] != null) {
          await txn.rawUpdate('UPDATE machines SET hours = ROUND(hours + ?, 2) WHERE id = ?',
              [dbl(head['duration_min']) / 60, head['machine_id']]);
        }
        await txn.insert('production_history', {
          'production_id': prodId,
          'at': now,
          'action': id == null ? 'create' : 'edit',
          'details': history,
        });
        await audit(txn, id == null ? 'create' : 'update', 'production', prodId, code);
        return prodId;
      });
      Db.notify();
      return pid;
    } on DatabaseException catch (e) {
      if (e.toString().contains('UNIQUE')) throw AppErr('رمز السجل مستخدم مسبقًا');
      rethrow;
    }
  }

  static Future<void> cancelProduction(int id) async {
    await Db.d.transaction<void>((txn) async {
      final pr = await txn.rawQuery('SELECT * FROM production WHERE id = ?', [id]);
      if (pr.isEmpty) throw AppErr('السجل غير موجود');
      if (pr.first['status'] == 'cancelled') throw AppErr('السجل ملغى مسبقًا');
      await _reverseProduction(txn, id, 'إلغاء سجل الإنتاج ${pr.first['code']}');
      await txn.update('production', {'status': 'cancelled', 'updated_at': nowIso()}, where: 'id = ?', whereArgs: [id]);
      await txn.insert('production_history', {
        'production_id': id,
        'at': nowIso(),
        'action': 'cancel',
        'details': 'إلغاء السجل وعكس المخزون',
      });
      await audit(txn, 'cancel', 'production', id, '${pr.first['code']}');
    });
    Db.notify();
  }

  // ---------------------------------------------------------------- manual stock
  /// action: receipt | withdraw | adjust.  For adjust, [qty] is the new counted quantity.
  static Future<void> stockAction({
    required String itemType,
    required int itemId,
    required String action,
    required double qty,
    String notes = '',
    double unitCost = 0,
    int? supplierId,
    bool recordPurchase = false,
  }) async {
    if (qty < 0) throw AppErr('الكمية لا يمكن أن تكون سالبة');
    if (action != 'adjust' && qty <= 0) throw AppErr('الكمية يجب أن تكون أكبر من صفر');
    final isProduct = itemType == 'product';
    final table = isProduct ? 'products' : 'materials';
    await Db.d.transaction<void>((txn) async {
      final row = await txn.rawQuery('SELECT * FROM $table WHERE id = ?', [itemId]);
      if (row.isEmpty) throw AppErr('العنصر غير موجود');
      final cur = dbl(row.first['qty']);
      double delta;
      String kind;
      if (action == 'receipt') {
        delta = qty;
        kind = isProduct ? 'product_receipt' : 'material_receipt';
      } else if (action == 'withdraw') {
        if (qty > cur + 0.0001) throw AppErr('الكمية المطلوبة أكبر من المتوفر (${fmt2(cur)})');
        delta = -qty;
        kind = isProduct ? 'product_withdraw' : 'material_withdraw';
      } else {
        delta = qty - cur;
        kind = 'adjust';
      }
      if (delta.abs() < 0.0001) throw AppErr('لا يوجد تغيير في الكمية');
      if (isProduct) {
        await _moveProduct(txn, itemId, delta, kind, 'manual', null, notes);
      } else {
        await _moveMaterial(txn, itemId, delta, kind, 'manual', null, notes);
        if (action == 'receipt') {
          final upd = <String, Object?>{};
          if (unitCost > 0) upd['unit_cost'] = unitCost;
          if (supplierId != null) upd['supplier_id'] = supplierId;
          if (upd.isNotEmpty) await txn.update('materials', upd, where: 'id = ?', whereArgs: [itemId]);
          if (recordPurchase && unitCost > 0) {
            String party = '';
            if (supplierId != null) {
              final s = await txn.rawQuery('SELECT name FROM suppliers WHERE id = ?', [supplierId]);
              if (s.isNotEmpty) party = str(s.first['name']);
            }
            await txn.insert('transactions', {
              'date': today(),
              'kind': 'purchase',
              'category': 'مواد',
              'description': 'شراء ${row.first['name']} (${fmt2(qty)})',
              'amount': r2(qty * unitCost),
              'method': 'cash',
              'party': party,
              'user': AppState.i.roleName,
              'ref_type': supplierId == null ? 'material' : 'supplier',
              'ref_id': supplierId ?? itemId,
              'created_at': nowIso(),
            });
          }
        }
      }
      await audit(txn, 'stock_$action', itemType, itemId, 'qty=$qty');
    });
    Db.notify();
  }

  // ---------------------------------------------------------------- shifts
  static Future<int> ensureShift(String date, String kind) async {
    final ex = await Db.one('SELECT id FROM shifts WHERE date = ? AND kind = ?', [date, kind]);
    if (ex != null) return intv(ex['id']);
    final times = shiftTimesFor(kind);
    return Db.d.insert('shifts', {'date': date, 'kind': kind, 'start_time': times[0], 'end_time': times[1], 'status': 'open'});
  }

  static List<String> shiftTimesFor(String kind) {
    switch (kind) {
      case 'afternoon':
        return ['14:00', '22:00'];
      case 'night':
        return ['22:00', '06:00'];
      default:
        return ['06:00', '14:00'];
    }
  }

  // ---------------------------------------------------------------- maintenance → machine status
  static Future<void> syncMachineAfterMaintenance(int machineId) async {
    final m = await Db.one('SELECT status FROM machines WHERE id = ?', [machineId]);
    if (m == null) return;
    final open = await Db.sum(
        "SELECT COUNT(*) FROM maintenance WHERE machine_id = ? AND status = 'pending' AND date <= ?", [machineId, today()]);
    if (open > 0) {
      await Db.update('machines', {'status': 'maintenance'}, machineId);
    } else if (m['status'] == 'maintenance') {
      await Db.update('machines', {'status': 'working'}, machineId);
    }
  }

  // ---------------------------------------------------------------- profit
  static Future<Rec> profit(String from, String to, {Set<String> excludeCats = const {}}) async {
    final sales = await Db.sum(
        "SELECT COALESCE(SUM(total),0) FROM invoices WHERE status != 'cancelled' AND date BETWEEN ? AND ?", [from, to]);
    final collected = await Db.sum(
        "SELECT COALESCE(SUM(p.amount),0) FROM payments p JOIN invoices i ON i.id = p.invoice_id WHERE i.status != 'cancelled' AND p.date BETWEEN ? AND ?",
        [from, to]);
    final materialCost = await Db.sum(
        "SELECT COALESCE(SUM(c.actual * c.unit_cost),0) FROM consumption c JOIN production pr ON pr.id = c.production_id WHERE pr.status = 'done' AND pr.date BETWEEN ? AND ?",
        [from, to]);
    final otherIncome = await Db.sum(
        "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind = 'income' AND date BETWEEN ? AND ?", [from, to]);
    final cats = await Db.q(
        "SELECT COALESCE(NULLIF(category,''),'أخرى') AS cat, SUM(amount) AS amount FROM transactions WHERE kind = 'expense' AND date BETWEEN ? AND ? GROUP BY cat ORDER BY amount DESC",
        [from, to]);
    var expenses = 0.0;
    var allExpenses = 0.0;
    for (final c in cats) {
      allExpenses += dbl(c['amount']);
      if (!excludeCats.contains(c['cat'])) expenses += dbl(c['amount']);
    }
    final maintenance = await Db.sum(
        "SELECT COALESCE(SUM(cost),0) FROM maintenance WHERE status = 'done' AND date BETWEEN ? AND ?", [from, to]);
    final produced = await Db.sum(
        "SELECT COALESCE(SUM(accepted),0) FROM production WHERE status = 'done' AND date BETWEEN ? AND ?", [from, to]);
    final totalCost = materialCost + expenses + maintenance;
    final net = sales + otherIncome - totalCost;
    return {
      'sales': sales,
      'collected': collected,
      'material_cost': materialCost,
      'other_income': otherIncome,
      'expenses': expenses,
      'all_expenses': allExpenses,
      'maintenance': maintenance,
      'produced': produced,
      'cost_per_piece': produced > 0 ? totalCost / produced : 0.0,
      'total_cost': totalCost,
      'gross': sales - materialCost,
      'net': net,
      'cats': cats,
    };
  }

  // ---------------------------------------------------------------- dashboards
  static Future<List<Rec>> monthlySales(int months) async {
    final now = DateTime.now();
    final out = <Rec>[];
    for (var i = months - 1; i >= 0; i--) {
      final s = DateTime(now.year, now.month - i, 1);
      final e = DateTime(now.year, now.month - i + 1, 0);
      final v = await Db.sum(
          "SELECT COALESCE(SUM(total),0) FROM invoices WHERE status != 'cancelled' AND date BETWEEN ? AND ?",
          [ymd(s), ymd(e)]);
      out.add({'label': monthName(s.month), 'value': v});
    }
    return out;
  }

  static double? pct(double now, double prev) {
    if (prev <= 0) return null;
    return (now - prev) / prev * 100;
  }

  static Future<Rec> dashboard(int months) async {
    final now = DateTime.now();
    final t0 = today();
    final ms = ymd(DateTime(now.year, now.month, 1));
    final prevStart = DateTime(now.year, now.month - 1, 1);
    final prevLast = DateTime(now.year, now.month, 0);
    final prevDay = now.day > prevLast.day ? prevLast.day : now.day;
    final ps = ymd(prevStart);
    final pe = ymd(DateTime(prevStart.year, prevStart.month, prevDay));

    Future<double> salesIn(String a, String b) => Db.sum(
        "SELECT COALESCE(SUM(total),0) FROM invoices WHERE status != 'cancelled' AND date BETWEEN ? AND ?", [a, b]);
    Future<double> expIn(String a, String b) => Db.sum(
        "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind = 'expense' AND date BETWEEN ? AND ?", [a, b]);
    Future<double> prodIn(String a, String b) => Db.sum(
        "SELECT COALESCE(SUM(accepted),0) FROM production WHERE status = 'done' AND date BETWEEN ? AND ?", [a, b]);

    final salesM = await salesIn(ms, t0);
    final salesP = await salesIn(ps, pe);
    final expM = await expIn(ms, t0);
    final expP = await expIn(ps, pe);
    final prodToday = await prodIn(t0, t0);
    final yesterday = ymd(now.subtract(const Duration(days: 1)));
    final prodY = await prodIn(yesterday, yesterday);
    final targetToday = await Db.sum(
        "SELECT COALESCE(SUM(target),0) FROM production WHERE status = 'done' AND date = ?", [t0]);
    final stockPieces = await Db.sum('SELECT COALESCE(SUM(qty),0) FROM products');
    final rawKg = await Db.sum("SELECT COALESCE(SUM(qty),0) FROM materials WHERE unit = 'kg'");
    final receivables = await Db.sum(
        "SELECT COALESCE(SUM(total - paid),0) FROM invoices WHERE status IN ('unpaid','partial')");
    final pf = await profit(ms, t0);

    final monthly = await monthlySales(months);
    final fromChart = ymd(DateTime(now.year, now.month - months + 1, 1));
    final byProduct = await Db.q(
        "SELECT ii.name AS name, SUM(ii.total) AS amount FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id WHERE i.status != 'cancelled' AND i.date BETWEEN ? AND ? GROUP BY ii.product_id ORDER BY amount DESC",
        [fromChart, t0]);
    final machines = await Db.q('SELECT status, COUNT(*) AS n FROM machines GROUP BY status');
    final prodByProduct = await Db.q(
        "SELECT p.name AS name, SUM(pr.accepted) AS made, SUM(pr.target) AS target FROM production pr JOIN products p ON p.id = pr.product_id WHERE pr.status = 'done' AND pr.date = ? GROUP BY p.id",
        [t0]);
    final orders = await Db.q(
        "SELECT o.*, c.name AS customer, p.name AS product FROM orders o LEFT JOIN customers c ON c.id = o.customer_id LEFT JOIN products p ON p.id = o.product_id WHERE o.status NOT IN ('delivered','cancelled') ORDER BY o.delivery_date ASC LIMIT 3");
    final lowProducts = await Db.sum('SELECT COUNT(*) FROM products WHERE min_stock > 0 AND qty <= min_stock');
    final lowMaterials = await Db.sum('SELECT COUNT(*) FROM materials WHERE min_qty > 0 AND qty <= min_qty');
    final alertList = await alerts();
    final movements = await Db.q(
        'SELECT m.*, COALESCE(p.name, mt.name) AS item FROM stock_movements m LEFT JOIN products p ON (m.item_type = \'product\' AND p.id = m.item_id) LEFT JOIN materials mt ON (m.item_type = \'material\' AND mt.id = m.item_id) ORDER BY m.id DESC LIMIT 4');
    return {
      'sales': salesM,
      'sales_trend': pct(salesM, salesP),
      'expenses': expM,
      'expenses_trend': pct(expM, expP),
      'prod_today': prodToday,
      'prod_trend': pct(prodToday, prodY),
      'target_today': targetToday,
      'stock_pieces': stockPieces,
      'raw_kg': rawKg,
      'receivables': receivables,
      'net': pf['net'],
      'monthly': monthly,
      'by_product': byProduct,
      'machines': machines,
      'prod_by_product': prodByProduct,
      'orders': orders,
      'low': lowProducts + lowMaterials,
      'alerts': alertList,
      'movements': movements,
    };
  }

  static Future<Rec> salesOverview(String from, String to) async {
    final total = await Db.sum(
        "SELECT COALESCE(SUM(total),0) FROM invoices WHERE status != 'cancelled' AND date BETWEEN ? AND ?", [from, to]);
    final count = await Db.sum(
        "SELECT COUNT(*) FROM invoices WHERE status != 'cancelled' AND date BETWEEN ? AND ?", [from, to]);
    final qty = await Db.sum(
        "SELECT COALESCE(SUM(ii.qty),0) FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id WHERE i.status != 'cancelled' AND i.date BETWEEN ? AND ?",
        [from, to]);
    final unpaid = await Db.sum(
        "SELECT COALESCE(SUM(total - paid),0) FROM invoices WHERE status IN ('unpaid','partial') AND date BETWEEN ? AND ?",
        [from, to]);
    final byProduct = await Db.q(
        "SELECT ii.name AS name, SUM(ii.total) AS amount FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id WHERE i.status != 'cancelled' AND i.date BETWEEN ? AND ? GROUP BY ii.product_id ORDER BY amount DESC",
        [from, to]);
    final methods = await Db.q(
        "SELECT COALESCE(p.method,'other') AS m, SUM(p.amount) AS amount FROM payments p JOIN invoices i ON i.id = p.invoice_id WHERE i.status != 'cancelled' AND p.date BETWEEN ? AND ? GROUP BY p.method ORDER BY amount DESC",
        [from, to]);
    final recent = await Db.q(
        "SELECT i.*, (SELECT SUM(qty) FROM invoice_items WHERE invoice_id = i.id) AS qty FROM invoices i WHERE i.date BETWEEN ? AND ? ORDER BY i.date DESC, i.id DESC LIMIT 6",
        [from, to]);
    final monthly = await monthlySales(6);
    return {
      'total': total,
      'count': count,
      'qty': qty,
      'unpaid': unpaid,
      'by_product': byProduct,
      'methods': methods,
      'recent': recent,
      'monthly': monthly,
    };
  }

  // ---------------------------------------------------------------- alerts
  static Future<List<AlertItem>> alerts() async {
    final out = <AlertItem>[];
    final t0 = today();
    final nowD = DateTime.now();
    final mats = await Db.q('SELECT * FROM materials');
    for (final m in mats) {
      final q = dbl(m['qty']);
      final mn = dbl(m['min_qty']);
      if (q <= 0 && mn > 0) {
        out.add(AlertItem('mat_crit_${m['id']}', '${t('نقص حرج في المادة')}: ${m['name']}',
            '${t('الرصيد')}: ${fmt2(q)} ${unitLabelRaw(m['unit'])}', 'critical', 'materials', t0, refId: intv(m['id'])));
      } else if (mn > 0 && q <= mn) {
        out.add(AlertItem('mat_low_${m['id']}', '${t('مخزون مادة أولية منخفض')}: ${m['name']}',
            '${t('الرصيد')}: ${fmt2(q)} / ${t('الحد الأدنى')}: ${fmt2(mn)}', 'warning', 'materials', t0, refId: intv(m['id'])));
      }
    }
    final prods = await Db.q('SELECT * FROM products WHERE active = 1');
    for (final pr in prods) {
      final q = dbl(pr['qty']);
      final mn = dbl(pr['min_stock']);
      if (mn > 0 && q <= 0) {
        out.add(AlertItem('prod_crit_${pr['id']}', '${t('نفاد المنتج')}: ${pr['name']}', '${t('الرصيد')}: ${fmt2(q)}', 'critical', 'inventory', t0,
            refId: intv(pr['id'])));
      } else if (mn > 0 && q < mn) {
        out.add(AlertItem('prod_low_${pr['id']}', '${t('منتج تحت الحد الأدنى')}: ${pr['name']}',
            '${t('الرصيد')}: ${fmt2(q)} / ${t('الحد الأدنى')}: ${fmt2(mn)}', 'warning', 'inventory', t0, refId: intv(pr['id'])));
      }
    }
    final soon = ymd(nowD.add(const Duration(days: 7)));
    final maint = await Db.q(
        "SELECT mt.*, m.name AS machine FROM maintenance mt JOIN machines m ON m.id = mt.machine_id WHERE mt.status = 'pending' AND mt.date <= ?",
        [soon]);
    for (final mt in maint) {
      final late = str(mt['date']).compareTo(t0) < 0;
      out.add(AlertItem('maint_${mt['id']}', '${late ? t('صيانة متأخرة') : t('صيانة قادمة')}: ${mt['machine']}',
          '${showDate(str(mt['date']))} - ${str(mt['description'])}', late ? 'critical' : 'warning', 'machines', str(mt['date']),
          refId: intv(mt['machine_id'])));
    }
    final stopped = await Db.q("SELECT * FROM machines WHERE status = 'stopped'");
    for (final m in stopped) {
      out.add(AlertItem('mach_stop_${m['id']}', '${t('آلة متوقفة')}: ${m['name']}', t('الحالة الحالية: متوقفة'), 'info', 'machines', t0,
          refId: intv(m['id'])));
    }
    final orders = await Db.q(
        "SELECT o.*, c.name AS customer FROM orders o LEFT JOIN customers c ON c.id = o.customer_id WHERE o.status NOT IN ('delivered','cancelled') AND o.delivery_date IS NOT NULL AND o.delivery_date != ''");
    final in3 = ymd(nowD.add(const Duration(days: 3)));
    for (final o in orders) {
      final d = str(o['delivery_date']);
      if (d.compareTo(t0) < 0) {
        out.add(AlertItem('order_late_${o['id']}', '${t('طلب متأخر')} #${o['number']}', '${str(o['customer'])} - ${showDate(d)}', 'critical',
            'orders', d, refId: intv(o['id'])));
      } else if (d.compareTo(in3) <= 0) {
        out.add(AlertItem('order_soon_${o['id']}', '${t('موعد تسليم الطلب')} #${o['number']}', '${str(o['customer'])} - ${showDate(d)}', 'info',
            'orders', d, refId: intv(o['id'])));
      }
    }
    final unpaid = await Db.q(
        "SELECT * FROM invoices WHERE status IN ('unpaid','partial') ORDER BY date ASC LIMIT 30");
    for (final i in unpaid) {
      final rem = dbl(i['total']) - dbl(i['paid']);
      final old = parseYmd(str(i['date']));
      final days = old == null ? 0 : nowD.difference(old).inDays;
      out.add(AlertItem('inv_${i['id']}', '${t('فاتورة غير مسددة')} #${i['number']}', '${str(i['customer_name'])} - ${t('المتبقي')}: ${money(rem)}',
          days > 30 ? 'warning' : 'info', 'sales', str(i['date']), refId: intv(i['id'])));
    }
    final tgt = await Db.sum("SELECT COALESCE(SUM(target),0) FROM production WHERE status = 'done' AND date = ?", [t0]);
    final act = await Db.sum("SELECT COALESCE(SUM(accepted),0) FROM production WHERE status = 'done' AND date = ?", [t0]);
    if (tgt > 0 && act < tgt) {
      out.add(AlertItem('prod_target_$t0', t('الإنتاج أقل من الهدف'), '${fmt(act)} / ${fmt(tgt)} ${t('قطعة')}', 'warning', 'production', t0));
    }
    final states = await Db.q('SELECT key, read FROM notif_state');
    final readKeys = <String>{};
    for (final s in states) {
      if (intv(s['read']) == 1) readKeys.add(s['key'] as String);
    }
    for (final a in out) {
      a.read = readKeys.contains(a.key);
    }
    const rank = {'critical': 0, 'warning': 1, 'info': 2};
    out.sort((a, b) => (rank[a.severity] ?? 3).compareTo(rank[b.severity] ?? 3));
    return out;
  }

  static String unitLabelRaw(Object? u) {
    switch (u) {
      case 'g':
        return t('غ');
      case 'pcs':
        return t('قطعة');
      case 'l':
        return t('لتر');
      default:
        return t('كغ');
    }
  }

  static Future<void> markRead(String key) async {
    await Db.d.rawInsert('INSERT OR REPLACE INTO notif_state(key, read) VALUES(?, 1)', [key]);
    Db.notify();
  }

  static Future<void> markAllRead(List<AlertItem> items) async {
    for (final a in items) {
      await Db.d.rawInsert('INSERT OR REPLACE INTO notif_state(key, read) VALUES(?, 1)', [a.key]);
    }
    Db.notify();
  }

  static Future<int> unreadCount() async {
    final a = await alerts();
    return a.where((x) => !x.read).length;
  }

  // ---------------------------------------------------------------- files: backup / restore / csv
  static Future<String> backup() async {
    final src = await Db.dbPath();
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'backups'));
    await dir.create(recursive: true);
    final n = DateTime.now();
    final name = 'khaldi_backup_${n.year}${two(n.month)}${two(n.day)}_${two(n.hour)}${two(n.minute)}${two(n.second)}.db';
    final out = await File(src).copy(p.join(dir.path, name));
    return out.path;
  }

  static Future<List<FileSystemEntity>> listBackups() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'backups'));
    if (!await dir.exists()) return [];
    final l = await dir.list().where((e) => e is File && e.path.endsWith('.db')).toList();
    l.sort((a, b) => b.path.compareTo(a.path));
    return l;
  }

  static Future<void> restore(String filePath) async {
    try {
      final test = await openDatabase(filePath, readOnly: true);
      try {
        final r = await test.rawQuery("SELECT name FROM sqlite_master WHERE name = 'invoices'");
        if (r.isEmpty) throw AppErr('ملف النسخة الاحتياطية غير صالح');
      } finally {
        await test.close();
      }
    } on DatabaseException {
      throw AppErr('ملف النسخة الاحتياطية غير صالح');
    }
    await backup(); // safety copy of the current data
    await Db.close();
    await File(filePath).copy(await Db.dbPath());
    await Db.open();
    await AppState.i.load();
    Db.notify();
  }

  static String _csvCell(String s) {
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      return '"${s.replaceAll('"', '""')}"';
    }
    return s;
  }

  static Future<String> writeCsv(String name, List<String> headers, List<List<String>> rows) async {
    final dir = await getTemporaryDirectory();
    final sb = StringBuffer('﻿');
    sb.writeln(headers.map(_csvCell).join(','));
    for (final r in rows) {
      sb.writeln(r.map(_csvCell).join(','));
    }
    final f = File(p.join(dir.path, name));
    await f.writeAsString(sb.toString());
    return f.path;
  }
}
