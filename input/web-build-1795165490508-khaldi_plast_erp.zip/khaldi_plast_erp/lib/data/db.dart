import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../core/format.dart';

class Db {
  static Database? _db;
  static final ValueNotifier<int> changes = ValueNotifier<int>(0);

  static Database get d {
    final x = _db;
    if (x == null) throw StateError('Database not open');
    return x;
  }

  static Future<String> dbPath() async => p.join(await getDatabasesPath(), 'khaldi_plast.db');

  static Future<void> open() async {
    final path = await dbPath();
    _db = await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, v) async {
        for (final s in _schema) {
          await db.execute(s);
        }
        await _seed(db);
      },
    );
  }

  static Future<void> close() async {
    await _db?.close();
    _db = null;
  }

  static void notify() {
    changes.value = changes.value + 1;
  }

  static Future<List<Rec>> q(String sql, [List<Object?>? args]) async {
    final r = await d.rawQuery(sql, args);
    return r.map((e) => Map<String, Object?>.from(e)).toList();
  }

  static Future<Rec?> one(String sql, [List<Object?>? args]) async {
    final r = await q(sql, args);
    return r.isEmpty ? null : r.first;
  }

  static Future<double> sum(String sql, [List<Object?>? args]) async {
    final r = await d.rawQuery(sql, args);
    if (r.isEmpty) return 0;
    final v = r.first.values.first;
    return v is num ? v.toDouble() : 0;
  }

  static Future<int> insert(String table, Rec values) async {
    final id = await d.insert(table, values);
    notify();
    return id;
  }

  static Future<void> update(String table, Rec values, int id) async {
    await d.update(table, values, where: 'id = ?', whereArgs: [id]);
    notify();
  }

  static Future<void> delete(String table, int id) async {
    await d.delete(table, where: 'id = ?', whereArgs: [id]);
    notify();
  }

  static const List<String> _schema = [
    'CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)',
    '''CREATE TABLE products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      length REAL DEFAULT 0, width REAL DEFAULT 0, height REAL DEFAULT 0,
      weight_g REAL DEFAULT 0,
      price REAL DEFAULT 0,
      min_stock REAL DEFAULT 0,
      qty REAL DEFAULT 0,
      image TEXT,
      active INTEGER DEFAULT 1,
      created_at TEXT)''',
    '''CREATE TABLE suppliers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, phone TEXT, address TEXT, notes TEXT, created_at TEXT)''',
    '''CREATE TABLE customers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, phone TEXT, address TEXT, notes TEXT, created_at TEXT)''',
    '''CREATE TABLE materials(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT,
      unit TEXT DEFAULT 'kg',
      unit_cost REAL DEFAULT 0,
      qty REAL DEFAULT 0,
      min_qty REAL DEFAULT 0,
      supplier_id INTEGER REFERENCES suppliers(id),
      created_at TEXT)''',
    '''CREATE TABLE machines(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      status TEXT DEFAULT 'working',
      hours REAL DEFAULT 0,
      notes TEXT,
      image TEXT,
      created_at TEXT)''',
    '''CREATE TABLE employees(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT, name TEXT NOT NULL, phone TEXT, role TEXT,
      status TEXT DEFAULT 'active', shift TEXT, notes TEXT, created_at TEXT)''',
    '''CREATE TABLE shifts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL, kind TEXT NOT NULL,
      start_time TEXT, end_time TEXT, status TEXT DEFAULT 'open', notes TEXT,
      UNIQUE(date, kind))''',
    '''CREATE TABLE shift_employees(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shift_id INTEGER NOT NULL REFERENCES shifts(id) ON DELETE CASCADE,
      employee_id INTEGER NOT NULL REFERENCES employees(id),
      attendance TEXT DEFAULT 'present',
      UNIQUE(shift_id, employee_id))''',
    '''CREATE TABLE invoices(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      customer_id INTEGER REFERENCES customers(id),
      customer_name TEXT,
      subtotal REAL DEFAULT 0, discount REAL DEFAULT 0,
      tax_rate REAL DEFAULT 0, tax REAL DEFAULT 0,
      total REAL DEFAULT 0, paid REAL DEFAULT 0,
      method TEXT, status TEXT DEFAULT 'unpaid', notes TEXT,
      created_at TEXT, updated_at TEXT)''',
    '''CREATE TABLE invoice_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
      product_id INTEGER NOT NULL REFERENCES products(id),
      name TEXT, qty REAL, unit_price REAL, total REAL)''',
    '''CREATE TABLE payments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
      date TEXT, amount REAL, method TEXT, notes TEXT)''',
    '''CREATE TABLE stock_movements(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL, kind TEXT NOT NULL,
      item_type TEXT NOT NULL, item_id INTEGER NOT NULL,
      qty REAL NOT NULL, ref_type TEXT, ref_id INTEGER,
      user TEXT, notes TEXT, created_at TEXT)''',
    '''CREATE TABLE production(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL, time TEXT, shift_kind TEXT,
      machine_id INTEGER REFERENCES machines(id),
      product_id INTEGER NOT NULL REFERENCES products(id),
      employee_id INTEGER REFERENCES employees(id),
      target REAL DEFAULT 0, actual REAL DEFAULT 0,
      accepted REAL DEFAULT 0, defective REAL DEFAULT 0,
      duration_min REAL DEFAULT 0, downtime_min REAL DEFAULT 0,
      notes TEXT, status TEXT DEFAULT 'done',
      created_at TEXT, updated_at TEXT)''',
    '''CREATE TABLE production_history(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      production_id INTEGER NOT NULL REFERENCES production(id) ON DELETE CASCADE,
      at TEXT, action TEXT, details TEXT)''',
    '''CREATE TABLE consumption(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      production_id INTEGER NOT NULL REFERENCES production(id) ON DELETE CASCADE,
      material_id INTEGER NOT NULL REFERENCES materials(id),
      per_piece_g REAL DEFAULT 0,
      planned REAL DEFAULT 0, actual REAL DEFAULT 0,
      unit_cost REAL DEFAULT 0, date TEXT)''',
    '''CREATE TABLE maintenance(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      machine_id INTEGER NOT NULL REFERENCES machines(id),
      date TEXT NOT NULL, description TEXT, technician TEXT, parts TEXT,
      cost REAL DEFAULT 0, status TEXT DEFAULT 'pending', notes TEXT)''',
    '''CREATE TABLE orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      number TEXT NOT NULL UNIQUE,
      customer_id INTEGER REFERENCES customers(id),
      product_id INTEGER REFERENCES products(id),
      qty REAL DEFAULT 0, order_date TEXT, delivery_date TEXT,
      status TEXT DEFAULT 'new', notes TEXT)''',
    '''CREATE TABLE notes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL, body TEXT, date TEXT, reminder TEXT,
      important INTEGER DEFAULT 0, done INTEGER DEFAULT 0,
      link_type TEXT, link_id INTEGER)''',
    '''CREATE TABLE transactions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL, kind TEXT NOT NULL,
      category TEXT, description TEXT, amount REAL DEFAULT 0,
      method TEXT, party TEXT, user TEXT, notes TEXT, attachment TEXT,
      ref_type TEXT, ref_id INTEGER, created_at TEXT)''',
    'CREATE TABLE notif_state(key TEXT PRIMARY KEY, read INTEGER DEFAULT 0)',
    '''CREATE TABLE audit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      at TEXT, user TEXT, action TEXT, entity TEXT, entity_id INTEGER, details TEXT)''',
    'CREATE INDEX idx_inv_date ON invoices(date)',
    'CREATE INDEX idx_prod_date ON production(date)',
    'CREATE INDEX idx_mov_item ON stock_movements(item_type, item_id)',
    'CREATE INDEX idx_tx_date ON transactions(date)',
  ];

  static Future<void> _seed(Database db) async {
    final now = DateTime.now().toIso8601String();
    final defaults = <String, String>{
      'lang': 'ar',
      'company_name': 'KHALDI PLAST',
      'company_phone': '',
      'company_address': '',
      'company_taxid': '',
      'tax_rate': '0',
      'invoice_footer': '',
      'role': 'admin',
    };
    for (final e in defaults.entries) {
      await db.insert('settings', {'key': e.key, 'value': e.value});
    }
    // Product families (official reference specifications, editable in the app)
    final products = <Rec>[
      {'code': 'CP9', 'name': 'CP9', 'length': 90, 'width': 300, 'height': 500, 'weight_g': 250, 'image': 'assets/images/products/cp9.png'},
      {'code': 'CP14', 'name': 'CP14', 'length': 140, 'width': 300, 'height': 500, 'weight_g': 350, 'image': 'assets/images/products/cp14.png'},
      {'code': 'SIPORA14', 'name': 'Sipora 14', 'length': 140, 'width': 300, 'height': 400, 'weight_g': 0, 'image': 'assets/images/products/sipora14.png'},
      {'code': 'SIPORA20', 'name': 'Sipora 20', 'length': 200, 'width': 300, 'height': 400, 'weight_g': 0, 'image': 'assets/images/products/sipora20.png'},
    ];
    for (final pr in products) {
      await db.insert('products', {...pr, 'created_at': now});
    }
    final mats = <List<String>>[
      ['PE', 'PE', 'بوليمر'],
      ['PP', 'PP', 'بوليمر'],
      ['MB', 'Masterbatch', 'ملوّن'],
      ['ADD', 'إضافات أخرى', 'إضافات'],
    ];
    for (final m in mats) {
      await db.insert('materials', {'code': m[0], 'name': m[1], 'category': m[2], 'unit': 'kg', 'created_at': now});
    }
    for (var i = 1; i <= 4; i++) {
      await db.insert('machines', {
        'code': 'PL00$i',
        'name': 'آلة $i',
        'status': 'working',
        'image': 'assets/images/machine.png',
        'created_at': now,
      });
    }
  }
}
