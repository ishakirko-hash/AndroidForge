# KHALDI PLAST ERP (Android / Flutter)

Offline-first factory management app (Arabic RTL + English, DZD).

## Build
- **Android Forge**: upload the zip as is and build the APK.
- **Locally**: `flutter pub get` then `flutter build apk --release`
  (APK: `build/app/outputs/flutter-apk/app-release.apk`).
- If the builder complains about a missing Android scaffold, run `flutter create --platforms=android .` inside the project, then build again.

## Tajawal font (optional)
Put `Tajawal-Regular.ttf` / `Tajawal-Bold.ttf` in `assets/fonts/` and declare them under `flutter: fonts:` in `pubspec.yaml`, then set `fontFamily: 'Tajawal'` in `lib/core/theme.dart`.

## Notes
- Project was written without compiling in the authoring environment; small compile errors may need fixing.
- Logo/product images were cropped from screenshots; replace files in `assets/images/` with originals.
- Data is stored locally (SQLite). Use Settings > Backup to export/restore.
