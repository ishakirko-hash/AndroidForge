package com.khaldiplast.erp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
