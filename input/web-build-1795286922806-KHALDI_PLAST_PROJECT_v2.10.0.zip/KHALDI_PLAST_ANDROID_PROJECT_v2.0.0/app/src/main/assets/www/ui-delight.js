/* KHALDI PLAST - v2.10 "delight pack": time-aware greeting, smart briefing chips, number count-up,
   staggered entrance, press feedback + light haptics, goal celebrations. Everything respects reduced-motion
   and is skipped under automation (navigator.webdriver) so tests read final numbers. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, S = U.S, X = U.extraActions;
  function T(ar, fr, en) { var l = U.lang(); return l === 'fr' ? fr : l === 'en' ? en : ar; }
  var calm = (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) || navigator.webdriver;

  function greeting() {
    var h = new Date().getHours();
    if (h >= 5 && h < 12) return T('صباح الخير ☀️', 'Bonjour ☀️', 'Good morning ☀️');
    if (h >= 12 && h < 18) return T('مساء الخير 🌤️', 'Bon après-midi 🌤️', 'Good afternoon 🌤️');
    return T('مساء النور 🌙', 'Bonsoir 🌙', 'Good evening 🌙');
  }

  /* ---- smart briefing: only chips that have real data ---- */
  U.briefing = function () {
    var D = U.D, d = K.dashboard(D, K.today()), c = [];
    function chip(cls, ic, txt, route) { c.push('<button class="bf-c ' + cls + '" data-act="bf_go" data-id="' + route + '"><span>' + ic + '</span>' + txt + '</button>'); }
    var lowN = d.lowMaterials.length + d.lowProducts.length;
    if (lowN) chip('o', '⚠️', T(lowN + ' أصناف قاربت على النفاد', lowN + ' articles bas', lowN + ' items running low'), 'stock');
    try {
      var ms = U.act(D.machines), st = (D.settings.mon && D.settings.mon.stops || []).filter(function (x) { return x.to == null && ms.some(function (m) { return m.id === x.m; }); }).length;
      if (st) chip('r', '🛑', T(st + ' آلة متوقفة الآن', st + ' machine(s) arrêtée(s)', st + ' machine(s) stopped'), 'machmon');
      var go = (D.settings.dist && D.settings.dist.trips || []).filter(function (x) { return x.status === 'go'; }).length;
      if (go) chip('b', '🚚', T(go + ' شاحنة قيد التوزيع', go + ' camion(s) en route', go + ' truck(s) on route'), 'distribution');
    } catch (e) { }
    if (d.todayProduction > 0) chip('g', '🏭', T('إنتاج اليوم ' + K.groupInt(d.todayProduction) + ' صندوق', 'Production: ' + K.groupInt(d.todayProduction), 'Produced today: ' + K.groupInt(d.todayProduction)), 'production');
    if (d.todaySalesCount > 0) chip('g', '💰', T(d.todaySalesCount + ' فاتورة اليوم', d.todaySalesCount + ' facture(s) aujourd\'hui', d.todaySalesCount + ' invoice(s) today'), 'sales');
    if (!c.length) return '';
    return '<div class="bf-row">' + c.join('') + '</div>';
  };
  X.bf_go = function (el) { var r = el.dataset.id; if (r === 'stock' || r === 'sales' || r === 'production') { U.stack = []; U.route = r; U.arg = null; U.render(); var m = U.$('#main'); if (m) m.scrollTop = 0; } else U.go(r); };

  /* ---- count-up ---- */
  function countUp(el) {
    var orig = el.textContent, digits = orig.replace(/\D/g, ''); if (!digits || digits.length > 9 || /[a-zA-Z؀-ۿ%]/.test(orig.replace(/[٠-٩]/g, ''))) return;
    var target = parseInt(digits, 10); if (target < 10) return; var n = digits.length, t0 = performance.now(), dur = 650;
    function frame(now) {
      var p = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - p, 3), cur = String(Math.round(target * e)); while (cur.length < n) cur = '0' + cur;
      var i = 0, out = '', started = false;
      for (var k = 0; k < orig.length; k++) { var ch = orig[k]; if (/\d/.test(ch)) { var dg = cur[i++]; if (dg !== '0') started = true; if (started || i === n) out += dg; } else if (started) out += ch; }
      el.textContent = p >= 1 ? orig : out; if (p < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }
  var lastKey = '';
  var prev = U.afterRender;
  U.afterRender = function (R) {
    if (prev) prev(R);
    var main = U.$('#main'); if (!main) return;
    if (R === 'home') { var w = main.querySelector('.hwel'); if (w && w.textContent === t('home_welcome')) w.textContent = greeting(); }
    if (R === 'machmon') { var p = document.getElementById('mm_pct'), pb = main.querySelector('.mm-pct'); if (p && pb && parseFloat(p.textContent) >= 100 && !pb.querySelector('.party')) pb.insertAdjacentHTML('beforeend', '<div class="party">🎉 ' + T('حققت هدف الإنتاج المتوقع!', 'Objectif atteint !', 'Expected output reached!') + '</div>'); }
    if (R === 'distribution') { var ef = main.querySelector('.dv-eff .ds-dw b'); if (ef && /100/.test(ef.textContent) && !main.querySelector('.dv-eff .party')) main.querySelector('.dv-eff').insertAdjacentHTML('beforeend', '<div class="party">🎉 ' + T('أنجزت كل رحلات اليوم', 'Tous les trajets livrés', 'All trips done today') + '</div>'); }
    var key = R + '|' + (U.arg && typeof U.arg !== 'object' ? U.arg : '');
    if (key !== lastKey) { lastKey = key; if (!calm) { main.classList.remove('enter'); void main.offsetWidth; main.classList.add('enter'); [].forEach.call(main.querySelectorAll('.dc-in .num, .dbig .num, .tk b .num, .kpi .num, .ds-v .num, .dv-sc b .num'), countUp); } }
  };

  /* ---- light haptics on primary actions ---- */
  document.addEventListener('click', function (e) {
    if (calm || !navigator.vibrate || !e.target.closest) return;
    if (e.target.closest('.btn.primary, .dk-b, #nav .nb, .lib-add, .mm-pb, .ds-start')) { try { navigator.vibrate(8); } catch (x) { } }
  }, true);
})();
