/* KHALDI PLAST - sync core (pure, no DOM). Used by the app (phone + Windows), by the tests and nowhere else.
   Model: every record has a unique id; a record changed on a device gets _m (a logical clock). Merging two copies =
   union of records, the newer _m wins per record; deletions are tombstones (_del). Stock is NOT merged as a number:
   it is recomputed from the (immutable) movement ledger, so two devices selling the last crates offline cannot "lose" stock.
   Invoice/quote numbers that collide are renumbered deterministically (the older document keeps its number).
   Data leaves a device only as AES-GCM ciphertext; the relay server never sees clear data. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(); else root.KPSync = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var LOCAL_KEYS = ['layout', 'theme', 'lang', 'pin'];   // per-device settings, never synchronised
  var NUMBERED = [['sales', 'invoice'], ['quotes', 'quote']];
  var SALT = 'khaldi-sync-v1';

  function isArr(x) { return Array.isArray(x); }
  function js(o) { return JSON.stringify(o); }
  function mOf(r) { return (r && r._m) || 0; }
  function round3(x) { return Math.round(x * 1000) / 1000; }
  function arrayKeys(d) { return Object.keys(d || {}).filter(function (k) { return isArr(d[k]); }); }
  function union(a, b) { var o = {}, r = []; a.concat(b).forEach(function (k) { if (!o[k]) { o[k] = 1; r.push(k); } }); return r; }
  function mapById(arr) { var m = {}; (arr || []).forEach(function (r) { if (r && r.id != null) m[r.id] = r; }); return m; }
  function shareable(k) { return k !== '_m' && LOCAL_KEYS.indexOf(k) < 0; }

  /* ---------- stamping (called by the app after every local change) ---------- */
  function stamp(od, nd, now) {
    var changed = 0; nd._del = nd._del || {};
    union(arrayKeys(nd), arrayKeys(od)).forEach(function (k) {
      var oldS = {}; (od[k] || []).forEach(function (r) { oldS[r.id] = js(r); });
      var seen = {};
      (nd[k] || []).forEach(function (r) { seen[r.id] = 1; if (oldS[r.id] !== js(r)) { r._m = now; changed++; } });
      Object.keys(oldS).forEach(function (id) { if (!seen[id]) { nd._del[id] = now; changed++; } });
    });
    var os = od.settings || {}, ns = nd.settings = nd.settings || {}; ns._m = ns._m || {};
    union(Object.keys(os), Object.keys(ns)).forEach(function (k) {
      if (!shareable(k)) return;
      if (js(os[k]) !== js(ns[k])) { ns._m[k] = now; changed++; }
    });
    return changed;
  }
  function stampAll(d, now) {      // used after a manual restore: this device's copy must win everywhere
    d._del = d._del || {};
    arrayKeys(d).forEach(function (k) { d[k].forEach(function (r) { r._m = now; }); });
    var s = d.settings = d.settings || {}; s._m = s._m || {};
    Object.keys(s).forEach(function (k) { if (shareable(k)) s._m[k] = now; });
    return d;
  }
  function maxClock(d) {
    var m = 0; arrayKeys(d).forEach(function (k) { d[k].forEach(function (r) { if (mOf(r) > m) m = mOf(r); }); });
    Object.keys(d._del || {}).forEach(function (id) { if (d._del[id] > m) m = d._del[id]; });
    Object.keys((d.settings || {})._m || {}).forEach(function (k) { if (d.settings._m[k] > m) m = d.settings._m[k]; });
    return m;
  }

  /* ---------- merge ---------- */
  function pick(ra, rb) {          // deterministic and symmetric
    if (!ra) return rb; if (!rb) return ra;
    var x = mOf(ra), y = mOf(rb); if (x !== y) return x > y ? ra : rb;
    return js(ra) >= js(rb) ? ra : rb;
  }
  function offsets(d) {            // stock minus the sum of its movements = the opening quantity (constant)
    var sums = {};
    (d.movements || []).forEach(function (m) { var k = m.kind + ':' + m.itemId; sums[k] = round3((sums[k] || 0) + m.qty); });
    var o = {};
    (d.products || []).forEach(function (p) { o['product:' + p.id] = round3((p.stock || 0) - (sums['product:' + p.id] || 0)); });
    (d.materials || []).forEach(function (p) { o['material:' + p.id] = round3((p.stock || 0) - (sums['material:' + p.id] || 0)); });
    return o;
  }

  function merge(a, b) {
    a = JSON.parse(js(a)); b = JSON.parse(js(b));   // never touch the callers' objects
    var out = {}, stats = { fromB: 0, fromA: 0, renumbered: 0 };
    Object.keys(a).forEach(function (k) { if (!isArr(a[k]) && k !== 'settings' && k !== '_del') out[k] = a[k]; });
    Object.keys(b).forEach(function (k) { if (!isArr(b[k]) && k !== 'settings' && k !== '_del' && !(k in out)) out[k] = b[k]; });
    var del = {}; [a._del || {}, b._del || {}].forEach(function (m) { Object.keys(m).forEach(function (id) { if (!(id in del) || m[id] > del[id]) del[id] = m[id]; }); });
    out._del = del;
    var offA = offsets(a), offB = offsets(b), offPick = {};

    union(arrayKeys(a), arrayKeys(b)).forEach(function (k) {
      var ma = mapById(a[k]), mb = mapById(b[k]), ids = union((a[k] || []).map(function (r) { return r.id; }), (b[k] || []).map(function (r) { return r.id; })), res = [];
      ids.forEach(function (id) {
        var ra = ma[id], rb = mb[id], r = pick(ra, rb);
        if (del[id] !== undefined && del[id] >= mOf(r)) { if (ra && !rb) stats.fromB++; return; }
        if (ra && rb) { if (js(ra) !== js(rb)) { if (r === rb) stats.fromB++; else stats.fromA++; } }
        else if (rb) stats.fromB++; else stats.fromA++;
        if (k === 'products' || k === 'materials') { var kind = k === 'products' ? 'product' : 'material'; offPick[kind + ':' + id] = (r === ra ? offA : offB)[kind + ':' + id]; }
        res.push(r);
      });
      if (res.length && res.every(function (r) { return typeof r.ts === 'string'; })) res.sort(function (x, y) { return x.ts < y.ts ? -1 : x.ts > y.ts ? 1 : x.id < y.id ? -1 : 1; });
      out[k] = res;
    });

    // attendance: a roster saved on two devices for the same day/shift/worker must not double count
    if (out.attendance) {
      var seen = {}; out.attendance.slice().sort(function (x, y) { return mOf(y) - mOf(x) || (x.id < y.id ? -1 : 1); }).forEach(function (r) {
        var key = r.date + '|' + r.shift + '|' + r.workerId; if (seen[key]) seen[key].dup = true; else seen[key] = r;
      });
      out.attendance = out.attendance.filter(function (r) { return !r.dup; }); out.attendance.forEach(function (r) { delete r.dup; });
    }

    // settings: per key, newest wins; per-device keys stay as they are on THIS device (a)
    var sa = a.settings || {}, sb = b.settings || {}, so = {}, ma2 = sa._m || {}, mb2 = sb._m || {}, mo = {};
    union(Object.keys(sa), Object.keys(sb)).forEach(function (k) {
      if (k === '_m') return;
      if (!shareable(k)) { if (k in sa) so[k] = sa[k]; return; }
      var x = ma2[k] || 0, y = mb2[k] || 0, fromBside = y > x || (y === x && k in sb && !(k in sa)) || (y === x && k in sa && k in sb && js(sb[k]) > js(sa[k]));
      var src = fromBside ? sb : sa; if (k in src) so[k] = src[k]; mo[k] = Math.max(x, y);
      if (fromBside && js(sb[k]) !== js(sa[k])) stats.fromB++;
    });
    so._m = mo; out.settings = so;

    // derived data
    var sums = {}; (out.movements || []).forEach(function (m) { var kk = m.kind + ':' + m.itemId; sums[kk] = round3((sums[kk] || 0) + m.qty); });
    [['products', 'product'], ['materials', 'material']].forEach(function (pr) {
      (out[pr[0]] || []).forEach(function (it) { var kk = pr[1] + ':' + it.id; if (kk in offPick) it.stock = round3(offPick[kk] + (sums[kk] || 0)); });
    });
    out.counters = out.counters || {};
    NUMBERED.forEach(function (nk) {
      var arr = out[nk[0]]; if (!arr) return;
      var max = 0; arr.forEach(function (r) { if (r.no > max) max = r.no; });
      var by = {}; arr.forEach(function (r) { (by[r.no] = by[r.no] || []).push(r); });
      Object.keys(by).forEach(function (no) {
        var g = by[no]; if (g.length < 2) return;
        g.sort(function (x, y) { return (x.ts || '') < (y.ts || '') ? -1 : (x.ts || '') > (y.ts || '') ? 1 : x.id < y.id ? -1 : 1; });
        g.slice(1).forEach(function (r) { r.noWas = r.noWas || r.no; r.no = ++max; r._m = mOf(r) + 1; stats.renumbered++; });
      });
      out.counters[nk[1]] = Math.max(max, (a.counters && a.counters[nk[1]]) || 0, (b.counters && b.counters[nk[1]]) || 0);
    });
    return { data: out, stats: stats };
  }

  /* canonical form used by tests and by "did anything change" checks (order-insensitive, per-device keys removed) */
  function canon(d) {
    var o = {}, keys = Object.keys(d).sort();
    keys.forEach(function (k) {
      if (isArr(d[k])) o[k] = d[k].slice().sort(function (x, y) { return x.id < y.id ? -1 : x.id > y.id ? 1 : 0; });
      else if (k === 'settings') { var s = {}; Object.keys(d.settings).sort().forEach(function (q) { if (shareable(q)) s[q] = d.settings[q]; }); o.settings = s; }
      else o[k] = d[k];
    });
    return js(o);
  }

  /* ---------- end-to-end encryption (WebCrypto: browser, Electron, Node 18+) ---------- */
  function subtle() { var c = (typeof crypto !== 'undefined' && crypto.subtle) ? crypto : (typeof require === 'function' ? require('crypto').webcrypto : null); if (!c || !c.subtle) throw new Error('no_crypto'); return c; }
  function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
  function enc(s) { return new TextEncoder().encode(s); }
  function b64u(bytes) { var s = ''; bytes = new Uint8Array(bytes); for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64u(str) { str = str.replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '='; var s = atob(str), a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
  function newSecret() { var a = new Uint8Array(32); subtle().getRandomValues(a); return b64u(a); }
  function newDeviceId() { var a = new Uint8Array(6); subtle().getRandomValues(a); return hex(a); }
  function deriveKeys(secret) {
    var c = subtle(), s = c.subtle;
    return Promise.all([s.digest('SHA-256', enc('ws:' + secret)), s.digest('SHA-256', enc('auth:' + secret)), s.importKey('raw', enc(secret), 'PBKDF2', false, ['deriveKey'])]).then(function (r) {
      return s.deriveKey({ name: 'PBKDF2', salt: enc(SALT), iterations: 150000, hash: 'SHA-256' }, r[2], { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']).then(function (key) {
        return { ws: hex(r[0]).slice(0, 32), token: hex(r[1]), key: key };
      });
    });
  }
  function pipe(bytes, Ctor, fmt) { return new Response(new Blob([bytes]).stream().pipeThrough(new Ctor(fmt))).arrayBuffer().then(function (b) { return new Uint8Array(b); }); }
  function seal(obj, key) {
    var raw = enc(js(obj)), c = subtle(), gz = typeof CompressionStream !== 'undefined';
    return (gz ? pipe(raw, CompressionStream, 'gzip') : Promise.resolve(raw)).then(function (body) {
      var iv = new Uint8Array(12); c.getRandomValues(iv);
      return c.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, body).then(function (ct) {
        var out = new Uint8Array(14 + ct.byteLength); out[0] = 1; out[1] = gz ? 1 : 0; out.set(iv, 2); out.set(new Uint8Array(ct), 14); return out;
      });
    });
  }
  function open(bytes, key) {
    bytes = new Uint8Array(bytes); if (bytes[0] !== 1) return Promise.reject(new Error('bad_blob'));
    return subtle().subtle.decrypt({ name: 'AES-GCM', iv: bytes.slice(2, 14) }, key, bytes.slice(14)).then(function (pt) {
      pt = new Uint8Array(pt); return bytes[1] === 1 ? pipe(pt, DecompressionStream, 'gzip') : pt;
    }).then(function (raw) { return JSON.parse(new TextDecoder().decode(raw)); });
  }
  function makeCode(url, secret) { return 'KP1|' + b64u(enc(js({ u: url, s: secret }))); }
  function parseCode(text) {
    try { text = String(text || '').trim(); if (text.indexOf('KP1|') !== 0) return null; var o = JSON.parse(new TextDecoder().decode(unb64u(text.slice(4)))); if (!/^https:\/\/[^\s]+$/.test(o.u) || typeof o.s !== 'string' || o.s.length < 20) return null; return { url: o.u.replace(/\/+$/, ''), secret: o.s }; } catch (e) { return null; }
  }

  return { LOCAL_KEYS: LOCAL_KEYS, stamp: stamp, stampAll: stampAll, maxClock: maxClock, merge: merge, canon: canon, deriveKeys: deriveKeys, seal: seal, open: open, newSecret: newSecret, newDeviceId: newDeviceId, makeCode: makeCode, parseCode: parseCode };
});
