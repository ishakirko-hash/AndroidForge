/* KHALDI PLAST v2.1 - live sync between devices (phone + Windows). Data is encrypted on the device before it is uploaded
   to the relay (see sync-server/). Merge rules live in sync-core.js. Works offline: changes queue and merge when back online. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, X = U.extraActions, C = window.KPSync;
  var S = U.sync = { cfg: null, status: 'off', last: 0, err: '', serverRev: null, dirty: false, clock: 0, keys: null, ws: null, busy: null, retry: 0 };

  function loadCfg() { try { var s = localStorage.getItem('kp_sync'); S.cfg = s ? JSON.parse(s) : null; } catch (e) { S.cfg = null; } }
  function saveCfg() { try { if (S.cfg) localStorage.setItem('kp_sync', JSON.stringify(S.cfg)); else localStorage.removeItem('kp_sync'); } catch (e) {} }
  function setStatus(s, err) { S.status = s; S.err = err || ''; dot(); if (U.route === 'settings' && !U.modalOpen) { try { U.render(true); } catch (e) {} } }
  function dot() {
    var el = document.getElementById('syncdot');
    if (!S.cfg) { if (el) el.remove(); return; }
    if (!el) { el = document.createElement('button'); el.id = 'syncdot'; el.setAttribute('aria-label', 'sync'); el.onclick = function () { U.stack = []; U.route = 'settings'; U.render(); }; document.body.appendChild(el); }
    el.className = 's-' + S.status; el.title = t('sync_st_' + S.status);
  }
  function ready() { return S.keys ? Promise.resolve(S.keys) : C.deriveKeys(S.cfg.secret).then(function (k) { S.keys = k; return k; }); }
  function base() { return S.cfg.url + '/v1/' + S.keys.ws; }
  function hdr(extra) { var h = { Authorization: 'Bearer ' + S.keys.token }; for (var k in extra) h[k] = extra[k]; return h; }

  /* ---- called by the app on every local change ---- */
  S.stamp = function (old, nd) { if (!S.cfg) return; S.clock = Math.max(Date.now(), S.clock + 1); C.stamp(old, nd, S.clock); };
  S.prepRestore = function (nd) { if (!S.cfg) return; S.clock = Math.max(Date.now(), S.clock + 1); C.stampAll(nd, S.clock); };
  S.changed = function () { if (!S.cfg) return; S.dirty = true; clearTimeout(S.tm); S.tm = setTimeout(S.syncNow, 350); };

  function applyLocal(data) {
    var cur = U.D.settings || {}; data.settings = data.settings || {};
    C.LOCAL_KEYS.forEach(function (k) { if (k in cur) data.settings[k] = cur[k]; });
    U.persist(data); U.D = data; S.clock = Math.max(S.clock, C.maxClock(data));
    (function later() { if (U.modalOpen || U.pinLocked) return setTimeout(later, 1500); try { U.render(true); } catch (e) {} })();
  }

  function fetchState() {
    return fetch(base() + '/state', { headers: hdr(), cache: 'no-store' }).then(function (r) {
      if (r.status === 404) return { rev: 0, remote: null };
      if (r.status === 403) throw new Error('forbidden');
      if (!r.ok) throw new Error('http_' + r.status);
      var rev = Number(r.headers.get('X-Rev') || 0);
      return r.arrayBuffer().then(function (b) { return C.open(b, S.keys.key); }).then(function (remote) { return { rev: rev, remote: remote }; });
    });
  }
  function putState(data, rev) {
    return C.seal(data, S.keys.key).then(function (blob) {
      return fetch(base() + '/state', { method: 'PUT', headers: hdr({ 'If-Match': String(rev), 'Content-Type': 'application/octet-stream' }), body: blob });
    });
  }

  function cycle() {
    var tries = 0, needPush = S.dirty;
    function step() {
      if (++tries > 6) throw new Error('busy');
      var pull = S.serverRev === null || S.serverRev !== S.cfg.rev || tries > 1;
      var p = pull ? fetchState().then(function (st) {
        S.serverRev = st.rev;
        if (st.remote && st.rev !== S.cfg.rev) {
          var res = C.merge(U.D, st.remote);
          if (res.stats.fromB > 0 || res.stats.renumbered > 0) { applyLocal(res.data); if (res.stats.renumbered) U.toast(t('sync_renumbered', { n: res.stats.renumbered }), 'ok'); }
          if (res.stats.fromA > 0 || res.stats.renumbered > 0) needPush = true;
        } else if (!st.remote) needPush = true;
        S.cfg.rev = st.rev; saveCfg();
      }) : Promise.resolve();
      return p.then(function () {
        if (!needPush && !S.dirty) return;
        S.dirty = false;
        return putState(U.D, S.cfg.rev).then(function (r) {
          if (r.status === 409) { S.serverRev = null; S.dirty = true; needPush = true; return step(); }
          if (r.status === 403) throw new Error('forbidden');
          if (!r.ok) { S.dirty = true; throw new Error('http_' + r.status); }
          return r.json().then(function (j) { S.cfg.rev = j.rev; S.serverRev = j.rev; saveCfg(); needPush = false; });
        });
      });
    }
    return step();
  }

  S.syncNow = function () {
    if (!S.cfg) return Promise.resolve();
    if (S.busy) { S.again = true; return S.busy; }
    setStatus('syncing');
    S.busy = ready().then(cycle).then(function () { S.last = Date.now(); S.retry = 0; setStatus(S.dirty ? 'syncing' : 'idle'); connect(); }).catch(function (e) {
      var m = String(e && e.message || e);
      if (m === 'forbidden') setStatus('error', 'forbidden'); else setStatus(navigator.onLine === false || /fetch|network|Failed|Load/i.test(m) ? 'offline' : 'error', m);
      S.dirty = true; clearTimeout(S.tm); S.retry = Math.min(60000, (S.retry || 1000) * 2); if (m !== 'forbidden') S.tm = setTimeout(S.syncNow, S.retry);
    }).then(function () { S.busy = null; if (S.again) { S.again = false; S.syncNow(); } });
    return S.busy;
  };

  /* ---- live channel ---- */
  function connect() {
    if (!S.cfg || !S.keys || S.ws || typeof WebSocket === 'undefined') return;
    var ws;
    try { ws = new WebSocket(base().replace(/^http/, 'ws') + '/ws?t=' + S.keys.token); } catch (e) { return; }
    S.ws = ws;
    ws.onmessage = function (ev) { try { var m = JSON.parse(ev.data); if (typeof m.rev === 'number') { S.serverRev = m.rev; if (m.rev !== S.cfg.rev) S.syncNow(); } } catch (e) {} };
    ws.onclose = ws.onerror = function () { if (S.ws !== ws) return; S.ws = null; clearInterval(S.ping); if (S.cfg) { S.wsTm = setTimeout(connect, 4000); } };
    ws.onopen = function () { clearInterval(S.ping); S.ping = setInterval(function () { try { ws.send('ping'); } catch (e) {} }, 25000); };
  }
  function poll() { if (S.cfg && !S.busy && (!S.ws || S.ws.readyState !== 1)) S.syncNow(); }
  window.addEventListener('online', function () { S.retry = 0; S.syncNow(); });
  window.addEventListener('offline', function () { if (S.cfg) setStatus('offline'); });
  document.addEventListener('visibilitychange', function () { if (!document.hidden && S.cfg) { S.serverRev = null; S.syncNow(); } });
  setInterval(poll, 20000);

  /* ---- pairing ---- */
  S.create = function (url) {
    url = String(url || '').trim().replace(/\/+$/, '');
    if (!/^https:\/\/[^\s/]+\.[^\s/]+/.test(url)) return Promise.reject(K.E('sync_bad_url'));
    var secret = C.newSecret(), cfg = { url: url, secret: secret, dev: C.newDeviceId(), rev: 0 };
    S.keys = null; S.cfg = cfg;
    return ready().then(function () {
      S.prepRestore(U.D); U.persist(U.D);
      return putState(U.D, 0);
    }).then(function (r) {
      if (!r.ok) throw K.E(r.status === 403 ? 'sync_forbidden' : 'sync_server');
      return r.json();
    }).then(function (j) { S.cfg.rev = j.rev; S.serverRev = j.rev; saveCfg(); S.last = Date.now(); setStatus('idle'); connect(); return C.makeCode(url, secret); }).catch(function (e) { S.cfg = null; S.keys = null; if (e && e.code) throw e; throw K.E('sync_unreachable'); });
  };
  S.join = function (code) {
    var pc = C.parseCode(code); if (!pc) return Promise.reject(K.E('sync_bad_code'));
    S.keys = null; S.cfg = { url: pc.url, secret: pc.secret, dev: C.newDeviceId(), rev: 0 };
    return ready().then(fetchState).then(function (st) {
      if (!st.remote) throw K.E('sync_empty_group');
      U.sideSave('before_import.json', JSON.stringify(K.makeBackup(U.D)));
      var ck = K.validateBackup({ app: 'KHALDI_PLAST_BACKUP', schema: st.remote.schema, data: st.remote });
      if (!ck.ok) throw K.E('sync_bad_data');
      applyLocal(ck.data); S.cfg.rev = st.rev; S.serverRev = st.rev; saveCfg(); S.last = Date.now(); setStatus('idle'); connect();
    }).catch(function (e) { S.cfg = null; S.keys = null; if (e && e.code) throw e; throw K.E(/forbidden/.test(String(e && e.message)) ? 'sync_forbidden' : 'sync_unreachable'); });
  };
  S.unpair = function () { clearTimeout(S.tm); clearTimeout(S.wsTm); clearInterval(S.ping); try { if (S.ws) { var w = S.ws; S.ws = null; w.close(); } } catch (e) {} S.cfg = null; S.keys = null; S.status = 'off'; saveCfg(); dot(); };
  S.code = function () { return S.cfg ? C.makeCode(S.cfg.url, S.cfg.secret) : ''; };

  /* ---- Settings card ---- */
  function ago(ms) { if (!ms) return '—'; var s = Math.round((Date.now() - ms) / 1000); return s < 10 ? t('sync_now') : s < 90 ? t('sync_secs', { n: s }) : s < 5400 ? t('sync_mins', { n: Math.round(s / 60) }) : U.dt(new Date(ms).toISOString().slice(0, 10)); }
  U.syncCard = function () {
    var h = '<div class="card"><h3>' + V.icon('cloud', 18) + ' ' + t('sync_title') + '</h3>';
    if (!S.cfg) {
      return h + '<div class="muted" style="margin-bottom:10px">' + esc(t('sync_help')) + '</div><div class="btns"><button class="btn sm primary" data-act="sync_create">' + t('sync_create') + '</button><button class="btn sm" data-act="sync_join">' + t('sync_join') + '</button></div></div>';
    }
    h += '<div style="margin-bottom:8px">' + U.badge(t('sync_st_' + S.status), { idle: 'green', syncing: 'amber', offline: 'gray', error: 'red' }[S.status] || 'gray') + '</div>' +
      U.kv('clock', t('sync_last'), '<bdi class="num">' + esc(ago(S.last)) + '</bdi>') + U.kv('phone', t('sync_device'), '<bdi class="num" dir="ltr">' + esc(S.cfg.dev) + '</bdi>') + (S.err ? '<div class="alert red" style="margin:8px 0">' + esc(S.err === 'forbidden' ? t('err_sync_forbidden') : S.err) + '</div>' : '') +
      '<div class="btns" style="margin-top:10px"><button class="btn sm primary" data-act="sync_now">' + t('sync_now_btn') + '</button><button class="btn sm" data-act="sync_show">' + t('sync_show_code') + '</button><button class="btn sm danger-o" data-act="sync_off">' + t('sync_off') + '</button></div></div>';
    return h;
  };
  function codeModal(code) {
    var qr = ''; try { qr = window.KPQR ? window.KPQR.svg(code, { level: 'L' }) : ''; } catch (e) {}
    U.showModal('<div class="sync-code"><h3>' + esc(t('sync_code_title')) + '</h3><p class="muted">' + esc(t('sync_code_help')) + '</p><div class="qrwrap">' + qr + '</div><textarea readonly rows="4" id="syncCodeTx" dir="ltr">' + esc(code) + '</textarea><div class="btns"><button class="btn primary" data-act="sync_copy">' + esc(t('copy')) + '</button><button class="btn" data-act="sync_share_code">' + esc(t('share')) + '</button><button class="btn ghost" data-act="close">' + esc(t('close')) + '</button></div><div class="alert red" style="margin-top:10px">' + esc(t('sync_code_warn')) + '</div></div>');
  }
  X.sync_create = function () {
    var last = ''; try { last = localStorage.getItem('kp_sync_url') || ''; } catch (e) {}
    U.openForm({ title: t('sync_create'), intro: esc(t('sync_create_help')), submit: t('sync_create'), fields: [{ name: 'url', label: t('sync_server'), type: 'text', value: last, ph: 'https://khaldi-sync.xxxx.workers.dev' }],
      onSubmit: function (v) { try { localStorage.setItem('kp_sync_url', v.url.trim()); } catch (e) {} return S.create(v.url).then(function (code) { U.closeModal(); U.toast(t('sync_ready'), 'ok'); U.render(true); codeModal(code); }); } });
  };
  S.joinFlow = function (code) {
    U.openForm({ title: t('sync_join'), intro: '<div class="alert red">' + esc(t('sync_join_warn')) + '</div>', submit: t('sync_join_do'), danger: true,
      fields: [{ name: 'code', label: t('sync_code_label'), type: 'textarea', value: code || '', ph: 'KP1|...' }],
      extra: (U.AND && U.AND.scanQR) ? [{ label: t('sync_scan'), run: function () { U.closeModal(); U.AND.scanQR(); } }] : [],
      onSubmit: function (v) { return S.join(v.code).then(function () { U.closeModal(); U.toast(t('sync_joined'), 'ok'); U.stack = []; U.route = 'home'; U.render(); }); } });
  };
  X.sync_join = function () { S.joinFlow(''); };
  X.sync_now = function () { S.serverRev = null; S.syncNow(); };
  X.sync_show = function () { codeModal(S.code()); };
  X.sync_copy = function () { var tx = document.getElementById('syncCodeTx'); try { tx.select(); } catch (e) {} if (navigator.clipboard) navigator.clipboard.writeText(tx.value).then(function () { U.toast(t('copied'), 'ok'); }, function () { try { document.execCommand('copy'); U.toast(t('copied'), 'ok'); } catch (e) {} }); else { try { document.execCommand('copy'); U.toast(t('copied'), 'ok'); } catch (e) {} } };
  X.sync_share_code = function () { var c = S.code(); if (U.AND && U.AND.shareText) U.AND.shareText(c); else X.sync_copy(); };
  X.sync_off = function () { U.confirmBox(t('sync_off'), t('sync_off_q'), t('sync_off'), function () { S.unpair(); U.toast(t('sync_off_done'), 'ok'); U.render(true); }, true); };

  // scanning a pairing QR with the existing scanner
  var prevScan = U.handleScan;
  U.handleScan = function (text) { if (String(text || '').indexOf('KP1|') === 0) { U.closeModal(); S.joinFlow(text); return; } if (prevScan) prevScan(text); };

  loadCfg();
  U.syncBoot = function () { if (S.cfg) { S.clock = Math.max(Date.now(), C.maxClock(U.D)); dot(); S.syncNow(); } };
})();
