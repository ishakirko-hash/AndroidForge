/* KHALDI PLAST v2.2 - "navy glass" dashboard: header, KPI tiles with real day-over-day trends, machine status, utilisation donut,
   7-day production line, crate types. Every number comes from the app's own data (no invented figures). */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, X = U.extraActions, S = U.S;
  var D = U.dash = {};
  function B(v) { return '<bdi class="num" dir="ltr">' + v + '</bdi>'; }
  function today() { return K.today(); }
  function liveSum(arr, day, f) { return K.sum(K.live(arr).filter(function (r) { return r.date === day; }), f); }
  function pct(cur, prev) { return prev > 0 ? Math.round((cur - prev) * 100 / prev) : null; }
  function trendHtml(p) {
    if (p === null) return '<span class="gx-tr nil">—</span>';
    return '<span class="gx-tr ' + (p >= 0 ? 'up' : 'dn') + '">' + V.icon(p >= 0 ? 'up' : 'down', 14) + '<bdi dir="ltr">' + (p >= 0 ? '+' : '') + p + '%</bdi></span>';
  }
  var KIC = { prod: 'cubeI', sales: 'trendI', stock: 'layersI', orders: 'usersI' };
  var ICO = {
    cubeI: '<path d="M12 3 4 7.5v9L12 21l8-4.5v-9z"/><path d="M4 7.5 12 12l8-4.5M12 12v9"/>',
    trendI: '<path d="M3 17l6-6 4 4 8-9"/><path d="M15 6h6v6"/>',
    layersI: '<path d="M12 3 3 8l9 5 9-5z"/><path d="M3 13l9 5 9-5"/>',
    usersI: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17.5" cy="9" r="2.4"/><path d="M17 14.3c2.4.2 4 2.1 4 4.7"/>',
    gearI: '<circle cx="12" cy="12" r="3"/><path d="M19.4 13.5a7.5 7.5 0 0 0 0-3l2-1.5-2-3.5-2.4 1a7.5 7.5 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.5A7.5 7.5 0 0 0 7 6.5l-2.4-1-2 3.5 2 1.5a7.5 7.5 0 0 0 0 3l-2 1.5 2 3.5 2.4-1a7.5 7.5 0 0 0 2.6 1.5l.4 2.5h4l.4-2.5a7.5 7.5 0 0 0 2.6-1.5l2.4 1 2-3.5z"/>',
    gridI: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/>',
    chartI: '<path d="M3 20h18"/><path d="M5 16l4-5 3 3 5-7"/><circle cx="17" cy="7" r="1.3"/>',
    boxI: '<path d="M3 8l9-5 9 5v8l-9 5-9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
    gaugeI: '<rect x="5" y="9" width="14" height="10" rx="2"/><path d="M9 9V6h6v3M9 14h6"/>'
  };
  function ic(name, s) { return '<svg class="ic" width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICO[name] + '</svg>'; }
  function secHead(icon, title, go) { return '<div class="gx-h"><h3>' + esc(title) + '</h3>' + (go ? '<button class="gx-hb" data-act="dash_go" data-id="' + go + '" aria-label="' + esc(title) + '">' + ic(icon, 22) + '</button>' : '<span class="gx-hb">' + ic(icon, 22) + '</span>') + '</div>'; }
  X.dash_go = function (el) { var id = el.dataset.id; if (id === 'orders') { S.noteF = 'pending'; U.go('notes'); } else X.sc({ dataset: { id: id } }); };

  /* ---------- header ---------- */
  D.header = function (ed) {
    var day = today(), hasAl = U.alerts().length > 0, q = S.homeQ || '';
    var h = '<section class="gx-top"><div class="gx-bar"><button class="gx-ib" data-act="bell" aria-label="' + esc(t('alerts')) + '">' + V.icon('bell', 22) + (hasAl ? '<i class="gx-dot"></i>' : '') + '</button>' +
      '<div class="gx-brand"><img src="img/logo_mark.png" alt=""><span class="gx-bn"><b>KHALDI PLAST</b><i>ERP</i></span></div>' +
      '<button class="gx-ib av" data-act="sc" data-id="settings" aria-label="' + esc(t('v_settings')) + '">' + V.icon('user', 22) + '</button></div>' +
      '<div class="gx-title"><div class="gx-tt"><h1>' + esc(t('d_title')) + '</h1><p>' + esc(t('d_sub')) + '</p></div><button class="gx-grid" data-act="' + (ed ? 'wd_done' : 'quick') + '" aria-label="' + esc(t('new_btn')) + '">' + ic('gridI', 26) + '</button></div>' +
      '<div class="gx-datebar"><span class="gx-date">' + V.icon('calendar', 18) + '<bdi>' + esc(U.longDate(day)) + '</bdi></span><span class="gx-mini">' +
      (ed ? '' : '<button class="gx-ib sm" data-act="scan_qr" aria-label="' + esc(t('tile_scan')) + '">' + V.icon('scan', 18) + '</button><button class="gx-ib sm" data-act="dash_search" aria-label="' + esc(t('search_home')) + '">' + V.icon('search', 18) + '</button><button class="gx-ib sm" data-act="wd_edit" aria-label="' + esc(t('edit_home')) + '">' + V.icon('sliders', 18) + '</button><button class="gx-ib sm" data-act="theme_toggle" aria-label="' + esc(t('theme')) + '">' + V.icon(U.theme() === 'dark' ? 'sun' : 'moon', 18) + '</button>') + '</span></div>';
    if (S.homeSearch || q) h += '<div class="gx-search"><span>' + V.icon('search', 20) + '</span><input type="search" id="homeq" data-bind="homeQ" value="' + esc(q) + '" placeholder="' + esc(t('search_home')) + '" autocomplete="off"></div>';
    return h + '</section>';
  };
  X.dash_search = function () { S.homeSearch = !S.homeSearch; if (!S.homeSearch) S.homeQ = ''; U.render(true); var el = document.getElementById('homeq'); if (el) el.focus(); };

  /* ---------- KPI tiles ---------- */
  function stockTrend(Dt, day) {
    var now = K.sum(Dt.products, function (p) { return p.stock; }), moved = K.sum(Dt.movements.filter(function (m) { return m.kind === 'product' && m.date === day; }), function (m) { return m.qty; });
    return pct(now, now - moved);
  }
  D.kpi = function () {
    var Dt = U.D, day = today(), yd = K.addDays(day, -1), d = K.dashboard(Dt, day);
    var pr = d.todayProduction, pry = liveSum(Dt.production, yd, function (r) { return r.good; });
    var sl = d.todaySales, sly = liveSum(Dt.sales, yd, function (s) { return s.total; });
    var orders = U.pendingOrders ? U.pendingOrders().length : 0;
    function tile(cls, icon, title, val, unit, tr, act, arg) { return '<button class="gx-k ' + cls + '" data-act="' + act + '"' + (arg ? ' data-id="' + arg + '"' : '') + '><span class="gx-ki">' + ic(icon, 26) + '</span><span class="gx-kt">' + esc(title) + '</span><span class="gx-kv">' + val + (unit ? '<small>' + esc(unit) + '</small>' : '') + '</span>' + (tr || '<span class="gx-tr nil"></span>') + '</button>'; }
    return '<section class="gx-kgrid">' +
      tile('k-blue', KIC.prod, t('d_k_prod'), B(K.groupInt(pr)), t('d_crate'), trendHtml(pct(pr, pry)), 'dash_go', 'production') +
      tile('k-green', KIC.sales, t('d_k_sales'), B(K.groupInt(Math.round(sl / 100))), t('dzd'), trendHtml(pct(sl, sly)), 'dash_go', 'sales') +
      tile('k-purple', KIC.stock, t('d_k_stock'), B(K.groupInt(d.finishedStock)), t('d_crate'), trendHtml(stockTrend(Dt, day)), 'dash_go', 'stock') +
      tile('k-amber', KIC.orders, t('d_k_orders'), B(orders), t('d_order'), '<span class="gx-tr nil"></span>', 'dash_go', 'orders') + '</section>';
  };

  /* ---------- machines ---------- */
  function machineInfo(day) {
    var Dt = U.D, ms = K.maintenanceStatus ? K.maintenanceStatus(Dt, day) : [], mst = {};
    ms.forEach(function (x) { mst[x.machine.id] = x; });
    return U.act(Dt.machines).map(function (m) {
      var workers = {}, days = {};
      Dt.attendance.forEach(function (a) { if (a.machineId === m.id && a.worked) { if (a.date === day) workers[a.workerId] = 1; if (a.date > K.addDays(day, -7) && a.date <= day) days[a.date] = 1; } });
      var nw = Object.keys(workers).length, nd = Object.keys(days).length, mt = mst[m.id], inMaint = mt && mt.status === 'overdue';
      return { m: m, workers: nw, days: nd, status: inMaint ? 'maint' : nw > 0 ? 'run' : 'stop', maint: mt };
    });
  }
  function machineSvg() {
    return '<svg class="gx-ms" viewBox="0 0 120 56" aria-hidden="true"><defs><linearGradient id="gxm1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EAF3FF"/><stop offset="1" stop-color="#9CB8DE"/></linearGradient><linearGradient id="gxm2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2F8CFF"/><stop offset="1" stop-color="#0F4FB8"/></linearGradient></defs>' +
      '<rect x="3" y="44" width="114" height="7" rx="3" fill="#5C7399"/><rect x="8" y="36" width="104" height="9" rx="2" fill="url(#gxm1)"/>' +
      '<rect x="8" y="20" width="34" height="17" rx="3" fill="url(#gxm2)"/><rect x="42" y="25" width="24" height="12" fill="#C7D6EE"/><rect x="48" y="12" width="12" height="13" rx="2" fill="#D9E5F7"/><path d="M45 12h18l-3 -6h-12z" fill="#9CB8DE"/>' +
      '<rect x="66" y="16" width="44" height="21" rx="3" fill="url(#gxm1)"/><rect x="72" y="21" width="14" height="9" rx="1.5" fill="#1E3A66"/><circle cx="96" cy="24" r="2.2" fill="#38D39F"/><rect x="90" y="28" width="16" height="3" rx="1.5" fill="#7B92B8"/></svg>';
  }
  D.machines = function () {
    var info = machineInfo(today()), h = '<section class="gx-card gx-mach">' + secHead('gearI', t('d_machines'), 'maintenance');
    if (!info.length) return h + '<div class="gx-empty">' + esc(t('d_no_machines')) + '<button class="btn sm primary" data-act="dash_add_machine">' + esc(t('d_add_machine')) + '</button></div></section>';
    h += '<div class="gx-car"><button class="gx-ar l" data-act="dash_scroll" data-d="-1" aria-label="prev">' + V.icon('chevL', 20) + '</button><div class="gx-track" id="gxTrack">' +
      info.map(function (x) {
        var pctv = Math.round(x.days * 100 / 7), lab = x.status === 'run' ? t('d_run') : x.status === 'maint' ? t('d_maint') : t('d_stop');
        return '<div class="gx-mc st-' + x.status + '"><div class="gx-mn"><b>' + esc(x.m.name) + '</b><span class="gx-pill">' + lab + '<i></i></span></div>' + machineSvg() +
          '<div class="gx-mr"><span>' + esc(t('d_workers_today')) + '</span><b>' + B(x.workers) + '</b></div><div class="gx-mr"><span>' + esc(t('d_days7')) + '</span><b>' + B(x.days + '/7') + '</b></div>' +
          '<div class="gx-pb"><span>' + B(pctv + '%') + '</span><div class="gx-bar2"><i style="width:' + pctv + '%"></i></div></div></div>';
      }).join('') + '</div><button class="gx-ar r" data-act="dash_scroll" data-d="1" aria-label="next">' + V.icon('chevR', 20) + '</button></div><div class="gx-dots" id="gxDots">' + info.map(function (_, i) { return '<i class="' + (i === 0 ? 'on' : '') + '"></i>'; }).join('') + '</div></section>';
    return h;
  };
  X.dash_add_machine = function () { if (U.forms.machine) U.forms.machine(); else U.go('workers'); };
  X.dash_scroll = function (el) { var tr = document.getElementById('gxTrack'); if (!tr) return; var rtl = U.lang() === 'ar'; tr.scrollBy({ left: Number(el.dataset.d) * tr.clientWidth * 0.7 * (rtl ? -1 : 1), behavior: 'smooth' }); };

  /* ---------- utilisation donut ---------- */
  D.util = function () {
    var info = machineInfo(today()), n = info.length, c = { run: 0, stop: 0, maint: 0 };
    info.forEach(function (x) { c[x.status]++; });
    var p = n ? { run: Math.round(c.run * 100 / n), stop: Math.round(c.stop * 100 / n), maint: Math.round(c.maint * 100 / n) } : { run: 0, stop: 0, maint: 0 };
    var R = 40, C = 2 * Math.PI * R, off = 0, segs = '';
    [['run', '#22D17B'], ['stop', '#F5B031'], ['maint', '#F2554B']].forEach(function (s) {
      var len = n ? C * c[s[0]] / n : 0; if (len > 0) { segs += '<circle cx="55" cy="55" r="' + R + '" fill="none" stroke="' + s[1] + '" stroke-width="13" stroke-dasharray="' + Math.max(0, len - 2) + ' ' + C + '" stroke-dashoffset="' + (-off) + '" transform="rotate(-90 55 55)"/>'; off += len; }
    });
    if (!n) segs = '<circle cx="55" cy="55" r="' + R + '" fill="none" stroke="rgba(160,190,240,.25)" stroke-width="13"/>';
    var leg = function (cls, label, v) { return '<div class="gx-lg"><i class="' + cls + '"></i><span>' + esc(label) + '</span><b>' + B(v + '%') + '</b></div>'; };
    return '<section class="gx-card gx-util">' + secHead('gaugeI', t('d_util')) + '<div class="gx-donut"><svg viewBox="0 0 110 110" aria-hidden="true">' + segs + '</svg><div class="gx-dc"><b>' + B(p.run + '%') + '</b><span>' + esc(t('d_run')) + '</span></div></div>' +
      '<div class="gx-legend">' + leg('g', t('d_run'), p.run) + leg('a', t('d_stop'), p.stop) + leg('r', t('d_maint'), p.maint) + '</div></section>';
  };

  /* ---------- 7-day production line ---------- */
  D.trend = function () {
    var day = today(), pts = [], i;
    for (i = 6; i >= 0; i--) { var dd = K.addDays(day, -i); pts.push({ d: dd, v: liveSum(U.D.production, dd, function (r) { return r.good; }) }); }
    var max = Math.max.apply(null, pts.map(function (p) { return p.v; }).concat([1])), step = max <= 10 ? 5 : Math.pow(10, Math.floor(Math.log10(max))) / (max / Math.pow(10, Math.floor(Math.log10(max))) > 5 ? 1 : 2), top = Math.ceil(max / step) * step || step;
    var W = 200, H = 118, L = 30, Rr = 6, T = 8, Bt = 20, iw = W - L - Rr, ih = H - T - Bt, grid = '', line = [], area, dots = '', labs = '';
    for (i = 0; i <= 4; i++) { var gy = T + ih - ih * i / 4; grid += '<line x1="' + L + '" x2="' + (W - Rr) + '" y1="' + gy + '" y2="' + gy + '" class="gx-gl"/><text x="' + (L - 4) + '" y="' + (gy + 3) + '" text-anchor="end" class="gx-gt">' + K.groupInt(Math.round(top * i / 4)) + '</text>'; }
    pts.forEach(function (p, k) { var x = L + iw * k / 6, y = T + ih - ih * p.v / top; line.push(x.toFixed(1) + ',' + y.toFixed(1)); dots += '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="2.6" class="gx-pt"/>'; labs += '<text x="' + x.toFixed(1) + '" y="' + (H - 5) + '" text-anchor="middle" class="gx-gt">' + Number(p.d.slice(8)) + '</text>'; });
    area = 'M' + line[0] + ' L' + line.join(' L') + ' L' + (L + iw) + ',' + (T + ih) + ' L' + L + ',' + (T + ih) + ' Z';
    var tot = K.sum(pts, function (p) { return p.v; });
    return '<section class="gx-card gx-trend">' + secHead('chartI', t('d_trend')) + '<svg viewBox="0 0 ' + W + ' ' + H + '" dir="ltr" class="gx-chart" role="img" aria-label="' + esc(t('d_trend')) + ' ' + tot + '"><defs><linearGradient id="gxa" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#27C6F2" stop-opacity=".55"/><stop offset="1" stop-color="#27C6F2" stop-opacity="0"/></linearGradient></defs>' +
      grid + '<path d="' + area + '" fill="url(#gxa)"/><polyline points="' + line.join(' ') + '" fill="none" class="gx-ln"/>' + dots + labs + '</svg></section>';
  };

  /* ---------- crate types ---------- */
  D.crates = function () {
    var list = U.act(U.D.products);
    if (!list.length) return '';
    return '<section class="gx-card gx-crates">' + secHead('boxI', t('d_crates'), 'stock') + '<div class="gx-cr">' +
      list.map(function (p) { return '<button class="gx-c" data-act="dash_go" data-id="stock"><span class="gx-cv">' + V.crate(p.color || 'gray', 70) + '</span><b>' + esc(p.name) + '</b><small>' + B(K.groupInt(p.stock)) + ' ' + esc(t('d_crate')) + '</small></button>'; }).join('') + '</div></section>';
  };

  /* machine carousel dots follow the scroll position */
  var prevAfter = U.afterRender;
  U.afterRender = function (R) {
    if (prevAfter) prevAfter(R);
    var tr = document.getElementById('gxTrack'), dots = document.getElementById('gxDots');
    if (tr && dots) tr.onscroll = function () {
      var cards = tr.children, best = 0, bd = 1e9, mid = tr.scrollLeft + tr.clientWidth / 2;
      for (var i = 0; i < cards.length; i++) { var c = cards[i], d = Math.abs(c.offsetLeft + c.offsetWidth / 2 - mid); if (d < bd) { bd = d; best = i; } }
      [].forEach.call(dots.children, function (e, i) { e.className = i === best ? 'on' : ''; });
    };
  };
})();
