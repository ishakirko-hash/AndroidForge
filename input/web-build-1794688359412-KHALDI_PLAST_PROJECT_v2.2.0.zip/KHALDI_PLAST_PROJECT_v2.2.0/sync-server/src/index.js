// KHALDI PLAST sync relay (Cloudflare Worker + Durable Object).
// It stores ONE opaque encrypted blob per workspace and tells connected devices when it changes.
// It cannot read your data: encryption/decryption happens only inside the app (phone / Windows).
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Authorization, If-Match, Content-Type',
  'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS',
  'Access-Control-Expose-Headers': 'X-Rev',
  'Access-Control-Max-Age': '86400'
};
const CHUNK = 900 * 1024;           // Durable Object values are limited to 2 MB: store the blob in pieces
const MAX = 24 * 1024 * 1024;       // refuse blobs bigger than 24 MB

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const u = new URL(req.url), m = u.pathname.match(/^\/v1\/([0-9a-f]{32})\/(state|ws)$/);
    if (!m) return new Response('KHALDI PLAST sync relay - OK', { headers: { ...CORS, 'content-type': 'text/plain; charset=utf-8' } });
    return env.ROOM.get(env.ROOM.idFromName(m[1])).fetch(req);
  }
};

async function sha(s) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); }
function same(a, b) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
function res(body, status, extra) { return new Response(body, { status, headers: { ...CORS, ...(extra || {}) } }); }

export class Room {
  constructor(ctx) {
    this.ctx = ctx;
    this.ctx.setWebSocketAutoResponse(new WebSocketRequestResponsePair('ping', 'pong'));
  }

  async fetch(req) {
    const u = new URL(req.url), kind = u.pathname.endsWith('/ws') ? 'ws' : 'state';
    const bearer = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '') || u.searchParams.get('t') || '';
    const meta = (await this.ctx.storage.get('meta')) || { rev: 0, auth: null, n: 0 };
    const claimed = !!meta.auth;
    if (claimed) { if (!bearer || !same(await sha(bearer), meta.auth)) return res('forbidden', 403); }

    if (kind === 'ws') {
      if (!claimed) return res('empty', 404);
      if (req.headers.get('Upgrade') !== 'websocket') return res('expected websocket', 426);
      const pair = new WebSocketPair();
      this.ctx.acceptWebSocket(pair[1]);
      pair[1].send(JSON.stringify({ rev: meta.rev }));
      return new Response(null, { status: 101, webSocket: pair[0] });
    }

    if (req.method === 'GET') {
      if (!claimed) return res('empty', 404, { 'X-Rev': '0' });
      const keys = []; for (let i = 0; i < meta.n; i++) keys.push('c' + i);
      const got = keys.length ? await this.ctx.storage.get(keys) : new Map();
      const out = new Uint8Array(meta.size || 0); let off = 0;
      for (const k of keys) { const c = new Uint8Array(got.get(k)); out.set(c, off); off += c.length; }
      return res(out, 200, { 'X-Rev': String(meta.rev), 'content-type': 'application/octet-stream', 'cache-control': 'no-store' });
    }

    if (req.method === 'PUT') {
      if (!bearer || bearer.length < 32) return res('token required', 401);
      const len = Number(req.headers.get('content-length') || 0);
      if (len > MAX) return res('too large', 413);
      const body = new Uint8Array(await req.arrayBuffer());
      if (body.length > MAX || body.length < 20) return res('bad size', 413);
      const fresh = (await this.ctx.storage.get('meta')) || { rev: 0, auth: null, n: 0 };   // re-read after the await
      if (String(fresh.rev) !== (req.headers.get('If-Match') || '0')) return res('stale', 409, { 'X-Rev': String(fresh.rev) });
      const n = Math.ceil(body.length / CHUNK), put = {};
      for (let i = 0; i < n; i++) put['c' + i] = body.slice(i * CHUNK, (i + 1) * CHUNK).buffer;
      const next = { rev: fresh.rev + 1, auth: fresh.auth || await sha(bearer), n, size: body.length, at: Date.now() };
      put.meta = next;
      await this.ctx.storage.put(put);
      if (fresh.n > n) { const del = []; for (let i = n; i < fresh.n; i++) del.push('c' + i); await this.ctx.storage.delete(del); }
      const msg = JSON.stringify({ rev: next.rev });
      for (const ws of this.ctx.getWebSockets()) { try { ws.send(msg); } catch (e) {} }
      return res(JSON.stringify({ rev: next.rev }), 200, { 'X-Rev': String(next.rev), 'content-type': 'application/json' });
    }
    return res('method not allowed', 405);
  }

  webSocketMessage() { /* keep-alive pings are answered automatically; nothing else is accepted */ }
  webSocketClose(ws) { try { ws.close(); } catch (e) {} }
}
