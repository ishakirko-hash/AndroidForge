// v2.2 navy-glass dashboard: real numbers only, machine states, navigation, theme, languages, overflow, migration
const L=require('./lib.js');
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2],360); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 await p.addStyleTag({content:'.wd{animation:none!important}'});
 const home=async()=>{ await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.arg=null;window.KPU.render();}); await p.waitForTimeout(80); };
 const txt=sel=>p.locator(sel).first().innerText();
 const ovf=()=>p.evaluate(()=>{const m=document.getElementById('main'); return [m.scrollWidth-m.clientWidth, document.documentElement.scrollWidth-window.innerWidth];});
 const keys=()=>p.evaluate(()=>[].map.call(document.querySelectorAll('.wgrid .wd'),e=>e.dataset.k));
 // empty data: honest empty states
 await home();
 ok((await keys()).join()==='dkpi,dmach,dutil,dtrend,dcrates','default widgets: dkpi,dmach,dutil,dtrend,dcrates');
 ok((await p.locator('.gx-k').count())===4 && (await p.locator('.gx-k .gx-tr.up,.gx-k .gx-tr.dn').count())===0,'4 KPI tiles, no invented trend on empty data');
 ok((await p.locator('.gx-mach .gx-empty').count())===1 && (await p.locator('.gx-mc').count())===0,'no machines: empty state, no fake machines');
 ok((await txt('.gx-dc b')).includes('0%'),'utilisation 0% without machines');
 // seed
 await p.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ const td=K.today();
  const m1=K.addMachine(d,{name:'M-One'}), m2=K.addMachine(d,{name:'M-Two'}), m3=K.addMachine(d,{name:'M-Three'});
  const w1=K.addWorker(d,{name:'W1',role:'op',rate:200000,hireDate:'2025-03-01'});
  const sup=K.addSupplier(d,{name:'S'}); K.recordPurchase(d,{date:K.addDays(td,-3),supplierId:sup.id,materialId:d.materials[0].id,qty:2000,unitCost:20000,paid:0,method:'cash'});
  const g={}; g[d.materials[0].id]=100; const pr=d.products[0];
  K.recordProduction(d,{date:K.addDays(td,-1),shift:1,productId:pr.id,good:100,defective:0,grams:g});
  K.recordProduction(d,{date:td,shift:1,productId:pr.id,good:150,defective:0,grams:g});
  K.setShiftRoster(d,{date:td,shift:1,entries:[{workerId:w1.id,worked:true,machineId:m1.id}]});
 }); U.render(); }); await home();
 ok((await txt('.gx-k.k-blue .gx-kv')).replace(/\D/g,'').startsWith('150') && (await txt('.gx-k.k-blue .gx-tr')).includes('+50%'),'production tile = 150 crates, +50% vs yesterday (100)');
 ok((await p.locator('.gx-mc').count())===3 && (await p.locator('.gx-mc.st-run').count())===1 && (await p.locator('.gx-mc.st-stop').count())===2,'3 machines: 1 running (worked today), 2 stopped');
 ok((await txt('.gx-dc b')).includes('33%'),'utilisation donut = 33% running');
 ok((await p.locator('.gx-chart polyline').count())===1 && (await p.locator('.gx-chart .gx-pt').count())===7,'7-day production line with 7 points');
 ok((await p.locator('.gx-c').count())===(await p.evaluate(()=>window.KPU.D.products.filter(x=>!x.archived).length)),'one card per crate type');
 // navigation
 await p.click('.gx-k.k-blue'); ok((await p.evaluate(()=>window.KPU.route))==='production','production tile opens Production');
 await home(); await p.click('.gx-k.k-purple'); ok((await p.evaluate(()=>window.KPU.route))==='stock','stock tile opens Stock');
 await home(); await p.click('.gx-k.k-amber'); ok((await p.evaluate(()=>window.KPU.route))==='notes','orders tile opens pending orders');
 await home(); await p.click('.gx-mach .gx-hb'); ok((await p.evaluate(()=>window.KPU.route))==='maintenance','machine gear opens Maintenance');
 await home(); await p.click('.gx-grid'); ok((await p.locator('[data-act="new_purchase"]').count())===1,'grid button opens the quick-create sheet'); await p.evaluate(()=>window.KPU.closeModal&&window.KPU.closeModal());
 const nav=await p.evaluate(()=>[].map.call(document.querySelectorAll('#nav .nb'),b=>b.dataset.id)); ok(nav.join()==='home,stock,production,workers,more','bottom nav: home, stock, production, workers, more');
 await home(); await p.click('#nav [data-id="workers"]'); ok((await p.evaluate(()=>window.KPU.route))==='workers' && (await p.locator('#nav .nb.on').getAttribute('data-id'))==='workers','workers tab opens and is highlighted');
 // overflow, themes, languages
 for(const vw of [360,390,412]){ await p.setViewportSize({width:vw,height:800}); for(const th of ['dark','light']){ await p.evaluate(t=>{window.KPU.commit(d=>{d.settings.theme=t});},th); await home(); const o=await ovf(); ok(o[0]<=0&&o[1]<=0,'no horizontal overflow '+vw+' '+th+' '+o); } }
 for(const lg of [1,2,0]){ await p.evaluate(i=>{window.KPU.commit(d=>{d.settings.lang=['ar','fr','en'][i]});},lg); await home(); const h=await p.locator('.gx-top').innerText()+await p.locator('.wgrid').innerText(); ok(!/\b(d_|sec_|tile_)\w+/.test(h),'no raw i18n keys in '+['ar','fr','en'][lg]); const o=await ovf(); ok(o[0]<=0,'no overflow '+['ar','fr','en'][lg]); }
 await p.evaluate(()=>{window.KPU.commit(d=>{d.settings.lang='ar'});});
 // migration: customised v2 layouts get the dashboard once
 await p.evaluate(()=>{ const U=window.KPU; U.commit(d=>{ d.settings.layout={v:1,hv:2,v2:1,hidden:[],order:[],icons:{},secOrder:[],secHidden:[],shown:['today'],wOrder:['kpis','sc:sales'],sizes:{kpis:'m'}}; }); U.migrateDash(); U.render(); });
 const k2=await keys(); ok(k2.join()==='dkpi,dmach,dutil,dtrend,dcrates','migration shows only the dashboard widgets: '+k2);
 await p.evaluate(()=>{ window.KPU.commit(d=>{ d.settings.layout.hidden=d.settings.layout.hidden.filter(x=>x!=='sales'); d.settings.layout.wOrder=['sc:sales','dkpi']; }); window.KPU.migrateDash(); window.KPU.render(); });
 ok((await keys())[0]==='sc:sales','migration runs only once (user edits afterwards are kept)');
 console.log('errors:',s.errors.join('|')||'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
