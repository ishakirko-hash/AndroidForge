const fs=require('fs'),os=require('os'),path=require('path'); const mk=require('../desktop/store.js'); let p=0,f=0; const ok=(c,n)=>{c?p++:(f++,console.log('FAIL',n));};
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'kp-')); const s=mk(path.join(dir,'data'));
ok(s.loadData()==='' ,'empty at first'); ok(s.saveData('{"a":1}')&&s.loadData()==='{"a":1}','save/load'); ok(s.loadPrev()==='','no prev yet');
ok(s.saveData('{"a":2}')&&s.loadPrev()==='{"a":1}'&&s.loadData()==='{"a":2}','previous copy kept'); ok(!s.saveData('')&&!s.saveData(null)&&s.loadData()==='{"a":2}','empty/invalid refused, data intact');
ok(s.saveSide('before_import.json','x')&&s.loadSide('before_import.json')==='x','side file'); ok(!s.saveSide('../evil.json','x')&&!s.saveSide('other.json','x')&&s.loadSide('../x')==='','only allow-listed side names');
ok(!fs.readdirSync(path.join(dir,'data')).some(n=>n.endsWith('.tmp')),'no temp files left'); console.log('pass',p,'fail',f); process.exit(f?1:0);
