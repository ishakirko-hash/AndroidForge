const {createRelay}=require('./relay_emu.js'); let pass=0,fail=0; const ok=(c,n)=>{c?pass++:(fail++,console.log('FAIL',n));};
(async()=>{ const R=await createRelay(); const ws='a'.repeat(32), T='t'.repeat(64), U='http://x/v1/'+ws+'/state'; const H=(x,extra)=>({Authorization:'Bearer '+x,...(extra||{})});
 let r=await R.fetch(U,{headers:H(T)}); ok(r.status===404&&r.headers.get('X-Rev')==='0','empty workspace -> 404');
 r=await R.fetch('http://x/'); ok(r.status===200,'health page');
 r=await R.fetch(U,{method:'OPTIONS'}); ok(r.status===204&&r.headers.get('Access-Control-Allow-Origin')==='*','CORS preflight');
 const blob=new Uint8Array(2300000).map((_,i)=>i%251);   // > 2 chunks, forces chunking
 r=await R.fetch(U,{method:'PUT',headers:H(T,{'If-Match':'0'}),body:blob}); ok(r.status===200&&r.headers.get('X-Rev')==='1','first PUT claims workspace, rev 1');
 r=await R.fetch(U,{method:'GET',headers:H(T)}); const got=new Uint8Array(await r.arrayBuffer()); ok(r.status===200&&got.length===blob.length&&got.every((v,i)=>v===blob[i]),'GET returns identical bytes after chunking');
 r=await R.fetch(U,{method:'GET',headers:H('x'.repeat(64))}); ok(r.status===403,'wrong token refused'); r=await R.fetch(U,{method:'GET'}); ok(r.status===403,'no token refused');
 r=await R.fetch(U,{method:'PUT',headers:H('x'.repeat(64),{'If-Match':'1'}),body:blob.slice(0,100)}); ok(r.status===403,'wrong token cannot overwrite');
 r=await R.fetch(U,{method:'PUT',headers:H(T,{'If-Match':'0'}),body:blob.slice(0,100)}); ok(r.status===409&&r.headers.get('X-Rev')==='1','stale If-Match -> 409 with current rev');
 // websocket
 r=await R.fetch('http://x/v1/'+ws+'/ws?t='+T,{headers:{Upgrade:'websocket'}}); ok(r.status===101&&r.webSocket,'websocket accepted with token in query'); const sock=r.webSocket; ok(JSON.parse(R.rooms[ws].socks[0].sent[0]).rev===1,'socket gets current rev on connect');
 r=await R.fetch('http://x/v1/'+ws+'/ws?t=bad',{headers:{Upgrade:'websocket'}}); ok(r.status===403,'websocket without valid token refused');
 r=await R.fetch(U,{method:'PUT',headers:H(T,{'If-Match':'1'}),body:blob.slice(0,500000)}); ok(r.status===200&&r.headers.get('X-Rev')==='2','PUT with right rev -> rev 2');
 ok(R.rooms[ws].socks[0].sent.map(x=>JSON.parse(x).rev).join()==='1,2','connected device is notified of rev 2'); ok(!R.rooms[ws].store.has('c1'),'old chunks removed when blob shrinks');
 r=await R.fetch(U,{method:'GET',headers:H(T)}); ok((await r.arrayBuffer()).byteLength===500000,'shrunk blob read back correctly');
 r=await R.fetch('http://x/v1/'+'b'.repeat(32)+'/state',{headers:H(T)}); ok(r.status===404,'workspaces are isolated');
 r=await R.fetch(U,{method:'PUT',headers:H(T,{'If-Match':'2','content-length':String(30*1024*1024)}),body:new Uint8Array(10)}); ok(r.status===413,'oversize refused');
 console.log('pass',pass,'fail',fail); process.exit(fail?1:0); })();
