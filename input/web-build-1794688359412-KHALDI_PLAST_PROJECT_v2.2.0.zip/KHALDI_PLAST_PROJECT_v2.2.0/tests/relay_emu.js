// Minimal emulation of the Cloudflare runtime pieces the relay uses (DO storage, WebSocketPair), so the REAL relay code
// (sync-server/src/index.js) can be exercised in Node. This is an emulation, not Cloudflare itself.
const path=require('path');
async function createRelay(){
  const mod=await import(path.resolve(__dirname,'../sync-server/src/index.js'));
  class Sock{ constructor(){this.sent=[];this.peer=null;this.listeners=[];} send(m){ this.sent.push(m); this.listeners.forEach(f=>f(m)); } close(){} }
  global.WebSocketPair=function(){ const a=new Sock(),b=new Sock(); this[0]=a; this[1]=b; };
  global.WebSocketRequestResponsePair=class{ constructor(a,b){this.a=a;this.b=b;} };
  const RealResponse=global.Response; // undici rejects status 101: emulate it
  global.Response=class extends RealResponse{ constructor(body,init){ if(init&&init.status===101){ super(null,{status:200}); Object.defineProperty(this,'status',{value:101}); this.webSocket=init.webSocket; } else super(body,init); } };
  const rooms={};
  const env={ ROOM:{ idFromName:n=>n, get:n=>({ fetch:req=>{
    if(!rooms[n]){ const store=new Map(); const socks=[]; const ctx={ storage:{ get:async k=>Array.isArray(k)?new Map(k.map(x=>[x,store.get(x)])):store.get(k), put:async o=>{ for(const [k,v] of Object.entries(o)) store.set(k,v);}, delete:async ks=>{ (Array.isArray(ks)?ks:[ks]).forEach(k=>store.delete(k)); } }, setWebSocketAutoResponse(){}, acceptWebSocket(s){ socks.push(s); }, getWebSockets:()=>socks }; rooms[n]={ room:new mod.Room(ctx,env), socks, store }; }
    return rooms[n].room.fetch(req); } }) } };
  return { mod, env, rooms, fetch:(url,init)=>mod.default.fetch(new Request(url,init),env) };
}
module.exports={createRelay};
