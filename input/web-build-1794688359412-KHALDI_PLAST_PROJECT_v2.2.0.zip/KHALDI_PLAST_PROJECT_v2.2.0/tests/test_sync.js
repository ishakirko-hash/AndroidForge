// Sync core: convergence, stock recompute, deletes, numbering, settings, crypto. node tests/test_sync.js
const K=require('../app/src/main/assets/www/core.js'); require('../app/src/main/assets/www/core2.js'); const S=require('../app/src/main/assets/www/sync-core.js');
let pass=0,fail=0; const ok=(c,n)=>{c?pass++:(fail++,console.log('FAIL',n));};
let clock=1000; const now=()=>++clock;
// a "device": apply a change with stamping like U.commit does
const dev=(d)=>({d, do(fn){ const nd=K.tx(this.d,fn); S.stamp(this.d,nd,now()); this.d=nd; return this; }});
const clone=o=>JSON.parse(JSON.stringify(o)); const td=K.today();
const sync=(x,y)=>{ const m1=S.merge(x.d,y.d).data, m2=S.merge(y.d,x.d).data; ok(S.canon(m1)===S.canon(m2),'merge is commutative'); x.d=m1; y.d=clone(m2); return m1; };
// base data shared by both devices
let base=K.emptyData();
base=K.tx(base,d=>{ d.customers.push({id:'c1',name:'A',phone:'1'}); K.recordProduction(d,{date:td,shift:1,productId:'prod_large',good:100,defective:0}); });
const P=dev(clone(base)), Q=dev(clone(base));
// 1 independent offline work on both devices
P.do(d=>K.recordSale(d,{date:td,customerId:'c1',items:[{productId:'prod_large',qty:30,unitPrice:20000,weightG:0}],paid:0,method:'cash'}));
Q.do(d=>K.recordSale(d,{date:td,customerId:null,items:[{productId:'prod_large',qty:20,unitPrice:20000,weightG:0}],paid:400000,method:'cash'}));
Q.do(d=>K.recordExpense(d,{date:td,categoryId:'cat_other',amount:5000,description:'x',method:'cash'}));
const m=sync(P,Q);
ok(m.sales.length===2,'both sales kept'); ok(m.sales.map(s=>s.no).sort().join()==='1,2' ,'colliding invoice numbers renumbered 1,2: '+m.sales.map(s=>s.no));
ok(m.products.find(p=>p.id==='prod_large').stock===50,'stock recomputed from ledger (100-30-20=50), got '+m.products.find(p=>p.id==='prod_large').stock);
ok(m.counters.invoice===2,'counter = max number'); ok(m.expenses.length===1,'expense carried over');
ok(S.canon(P.d)===S.canon(Q.d),'devices converge to identical data');
const vb=K.validateBackup(clone(K.makeBackup(m))); ok(vb && (vb.ok===true||vb.errors===undefined||vb.errors.length===0),'merged data passes validateBackup '+JSON.stringify(vb).slice(0,150));
// 2 idempotent
ok(S.canon(S.merge(m,m).data)===S.canon(m),'merge(x,x)=x'); ok(S.merge(m,m).stats.fromB===0,'no phantom changes');
// 3 same record edited on both: newest wins
P.do(d=>{ d.customers[0].name='Old'; }); Q.do(d=>{ d.customers[0].name='Newer'; });
const m3=sync(P,Q); ok(m3.customers[0].name==='Newer','later edit wins (logical clock)');
// 4 void on one side, payment on other
const sid=P.d.sales[0].id;
P.do(d=>K.voidSale(d,sid)); Q.do(d=>K.recordSale(d,{date:td,customerId:null,items:[{productId:'prod_large',qty:5,unitPrice:20000,weightG:0}],paid:100000,method:'cash'}));
const m4=sync(P,Q); ok(m4.sales.find(s=>s.id===sid).voided===true,'void propagates'); ok(m4.products.find(p=>p.id==='prod_large').stock===100-20-5,'void restores stock + new sale deducts ('+m4.products.find(p=>p.id==='prod_large').stock+')');
// 5 deletions (tombstones) and no resurrection
const id0=P.d.expenses[0].id; P.do(d=>{ d.expenses=d.expenses.filter(e=>e.id!==id0); });
sync(P,Q); ok(!Q.d.expenses.some(e=>e.id===id0),'delete propagates'); sync(P,Q); ok(!P.d.expenses.some(e=>e.id===id0),'deleted record does not come back');
Q.do(d=>{}); // a later re-create with same id would win by clock
// 6 per-device settings are not overwritten, shared ones are
P.do(d=>{ d.settings.lang='fr'; d.settings.theme='dark'; d.settings.company='NEW NAME'; }); Q.do(d=>{ d.settings.lang='en'; });
sync(P,Q); ok(P.d.settings.lang==='fr' && Q.d.settings.lang==='en' && P.d.settings.theme==='dark' && Q.d.settings.theme!=='dark','language/theme/layout stay per device'); ok(Q.d.settings.company==='NEW NAME','shared settings sync');
// 7 three devices, random order -> same result
const R=dev(clone(base)); R.do(d=>K.recordPurchase(d,{date:td,supplierId:K.addSupplier(d,{name:'S'}).id,materialId:'mat_granule',qty:100,unitCost:10000,paid:0,method:'cash'}));
const a=S.merge(S.merge(P.d,Q.d).data,R.d).data, b=S.merge(R.d,S.merge(Q.d,P.d).data).data, c=S.merge(S.merge(R.d,P.d).data,Q.d).data;
ok(S.canon(a)===S.canon(b)&&S.canon(b)===S.canon(c),'3 devices: any merge order gives the same data'); ok(a.materials.find(x=>x.id==='mat_granule').stock===100,'material stock from ledger');
// 8 clock
ok(S.maxClock(P.d)>0,'maxClock'); const w=clone(P.d); S.stampAll(w,99999); ok(w.sales.every(s=>s._m===99999),'stampAll');
// 9 quotes numbering
const A=dev(clone(base)),B=dev(clone(base)); const prod=[{productId:'prod_large',qty:1,unitPrice:100}];
A.do(d=>K.addQuote(d,{date:td,customerId:null,items:prod,discount:0,validUntil:td})); B.do(d=>K.addQuote(d,{date:td,customerId:null,items:prod,discount:0,validUntil:td}));
const mq=sync(A,B); ok(mq.quotes.length===2 && mq.quotes.map(q=>q.no).sort().join()==='1,2' && mq.counters.quote===2,'quote numbers renumbered');
// 10 attendance de-dup
// 11 crypto
(async()=>{ const k=await S.deriveKeys('s3cret-s3cret-s3cret-s3cret'); const k2=await S.deriveKeys('other-other-other-other-other');
  ok(k.ws.length===32 && k.token.length===64 && k.ws!==k2.ws,'derived ids');
  const blob=await S.seal(m,k.key); ok(blob.length>20 && Buffer.from(blob).toString('latin1').indexOf('KHALDI')<0,'ciphertext does not contain clear text ('+blob.length+' bytes)');
  const back=await S.open(blob,k.key); ok(S.canon(back)===S.canon(m),'decrypts to identical data');
  let bad=false; try{ await S.open(blob,k2.key);}catch(e){bad=true;} ok(bad,'wrong key cannot open'); const t=Buffer.from(blob); t[40]^=1; bad=false; try{ await S.open(new Uint8Array(t),k.key);}catch(e){bad=true;} ok(bad,'tampered blob rejected');
  const code=S.makeCode('https://x.workers.dev/','a'.repeat(43)); const pc=S.parseCode(code); ok(pc&&pc.url==='https://x.workers.dev'&&pc.secret.length===43,'pairing code round trip'); ok(S.parseCode('KP1|zzzz')===null && S.parseCode('http://a')===null,'bad codes rejected');
  console.log('pass',pass,'fail',fail); process.exit(fail?1:0); })();
