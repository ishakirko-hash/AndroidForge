// v2.1 live sync end-to-end: two separate browsers ("phone" and "PC") + the REAL relay code (emulated Cloudflare runtime).
const L=require('./lib.js'); const {createRelay}=require('./relay_emu.js'); const S=require('../app/src/main/assets/www/sync-core.js');
let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n);};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ const R=await createRelay(); const root=process.argv[2];
 const A=await L.start(root,390), B=await L.start(root,1100); const pa=A.page, pb=B.page; for(const p of [pa,pb]) await p.waitForSelector('#splash.hidden',{state:'attached'});
 const net={ A:true, B:true, up:true };
 async function wire(ctx,key){ await ctx.route('https://relay.test/**',async route=>{ const req=route.request();
     if(!net[key]||!net.up) return route.abort('failed');
     const h=req.headers(); const body=req.postDataBuffer(); const r=await R.fetch(req.url(),{method:req.method(),headers:h,body:body&&body.length?body:undefined});
     const buf=Buffer.from(await r.arrayBuffer()); const hh={}; r.headers.forEach((v,k)=>hh[k]=v); route.fulfill({status:r.status,headers:hh,body:buf}); });
   await ctx.routeWebSocket(/^wss:\/\/relay\.test\// ,async ws=>{ if(!net[key]||!net.up){ ws.close(); return; } const u=ws.url().replace('wss://','https://'); const r=await R.fetch(u,{headers:{Upgrade:'websocket'}}); if(r.status!==101){ ws.close(); return; }
     const room=R.rooms[u.match(/v1\/([0-9a-f]+)\//)[1]]; const sock=room.socks[room.socks.length-1]; sock.listeners.push(m=>{ try{ if(net[key]&&net.up) ws.send(m); }catch(e){} }); ws.send(sock.sent[0]); ws.onMessage(()=>{}); ws.onClose(()=>{ const i=room.socks.indexOf(sock); if(i>=0) room.socks.splice(i,1); }); }); }
 await wire(pa,'A'); await wire(pb,'B'); for(const p of [pa,pb]){ await p.reload(); await p.waitForSelector('#splash.hidden',{state:'attached'}); }   // WebSocket routing is injected at document start
 const D=p=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const until=async(f,ms)=>{ const t0=Date.now(); while(Date.now()-t0<(ms||6000)){ if(await f()) return true; await sleep(100); } return false; };
 // ---------- phone A has real data
 await pa.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(); U.commit(d=>{ const c=K.addCustomer(d,{name:'Client Un',phone:'055'}); K.recordProduction(d,{date:td,shift:1,productId:d.products[0].id,good:200,defective:0}); K.recordSale(d,{date:td,customerId:c.id,items:[{productId:d.products[0].id,qty:30,unitPrice:20000,weightG:0}],paid:100000,method:'cash'}); }); });
 await pa.evaluate(()=>{ window.KPU.stack=[]; window.KPU.route='settings'; window.KPU.render(); }); ok(/المزامنة بين الأجهزة/.test(await pa.locator('#main').innerText()),'settings shows the Sync card');
 await pa.click('[data-act="sync_create"]'); await pa.waitForSelector('#f'); await pa.fill('#f_url','http://insecure'); await pa.click('#f button[type=submit]'); await sleep(150); ok(/https/.test(await pa.locator('#ferr').innerText()),'plain http address refused');
 await pa.fill('#f_url','https://relay.test'); await pa.click('#f button[type=submit]'); await pa.waitForSelector('#syncCodeTx'); const code=await pa.inputValue('#syncCodeTx'); ok(code.startsWith('KP1|') && await pa.locator('.sync-code svg').count()===1,'group created: pairing code + QR shown');
 const wsId=Object.keys(R.rooms)[0]; ok(!!wsId && R.rooms[wsId].store.has('meta'),'encrypted blob stored on the relay (rev 1)'); const raw=Buffer.concat([...R.rooms[wsId].store.keys()].filter(k=>/^c\d/.test(k)).map(k=>Buffer.from(R.rooms[wsId].store.get(k)))).toString('latin1'); ok(raw.indexOf('Client Un')<0 && raw.indexOf('KHALDI')<0,'relay holds ciphertext only (customer name not visible)');
 await pa.click('.sync-code [data-act="close"]'); ok(await pa.locator('#syncdot.s-idle').count()===1,'status dot is green after creating');
 // ---------- PC B joins
 await pb.evaluate(()=>{ window.KPU.stack=[]; window.KPU.route='settings'; window.KPU.render(); }); await pb.click('[data-act="sync_join"]'); await pb.waitForSelector('#f'); await pb.fill('#f_code','KP1|garbage'); await pb.click('#f button[type=submit]'); await sleep(200); ok((await pb.locator('#ferr').innerText()).length>3,'bad pairing code rejected');
 await pb.fill('#f_code',code); await pb.click('#f button[type=submit]'); ok(await until(async()=>(await D(pb)).sales.length===1),'PC joined: invoice from the phone arrived'); let db=await D(pb); ok(db.customers.some(c=>c.name==='Client Un') && db.products[0].stock===170,'PC has the customer and the same stock (170)');
 ok(await pb.locator('#syncdot.s-idle').count()===1,'PC dot green'); ok(db.settings.lang==='ar','device language kept');
 // ---------- live propagation both ways
 await pa.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ K.recordSale(d,{date:K.today(),customerId:null,items:[{productId:d.products[0].id,qty:10,unitPrice:20000,weightG:0}],paid:200000,method:'cash'}); }); });
 let t0=Date.now(); ok(await until(async()=>(await D(pb)).sales.length===2,5000),'phone sale appears on the PC within seconds ('+(Date.now()-t0)+' ms)');
 await pb.evaluate(()=>{ const U=window.KPU; U.commit(d=>{ d.customers[0].name='Client Renamed'; }); }); ok(await until(async()=>(await D(pa)).customers[0].name==='Client Renamed',5000),'PC edit appears on the phone');
 ok((await D(pa)).products[0].stock===160 && (await D(pb)).products[0].stock===160,'stock identical on both (160)');
 // the open screen refreshes by itself
 await pa.evaluate(()=>{ window.KPU.stack=[]; window.KPU.route='sales'; window.KPU.render(); }); const before=await pa.locator('#main').innerText();
 await pb.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ K.recordSale(d,{date:K.today(),customerId:null,items:[{productId:d.products[0].id,qty:5,unitPrice:20000,weightG:0}],paid:100000,method:'cash'}); }); });
 ok(await until(async()=>(await pa.locator('#main').innerText())!==before,5000),'the phone screen refreshes by itself when the PC records a sale');
 // ---------- both offline, work independently, reconnect
 net.A=false; net.B=false; await pa.evaluate(()=>window.dispatchEvent(new Event('offline'))); await sleep(200);
 await pa.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ K.recordSale(d,{date:K.today(),customerId:null,items:[{productId:d.products[0].id,qty:7,unitPrice:20000,weightG:0}],paid:140000,method:'cash'}); K.recordExpense(d,{date:K.today(),categoryId:d.expenseCats[0].id,amount:9000,description:'phone exp',method:'cash'}); }); });
 await pb.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ K.recordSale(d,{date:K.today(),customerId:null,items:[{productId:d.products[0].id,qty:3,unitPrice:20000,weightG:0}],paid:60000,method:'cash'}); }); });
 await sleep(500); ok(await pa.locator('#syncdot.s-offline,#syncdot.s-error').count()===1,'offline: dot turns grey, app keeps working'); ok((await D(pa)).sales.length===4 && (await D(pb)).sales.length===4,'each device recorded its sale locally');
 net.A=true; net.B=true; await pa.evaluate(()=>window.dispatchEvent(new Event('online'))); await pb.evaluate(()=>window.dispatchEvent(new Event('online')));
 ok(await until(async()=>{ const a=await D(pa),b=await D(pb); return a.sales.length===5 && b.sales.length===5 && S.canon(a)===S.canon(b); },15000),'after reconnect both devices converge to identical data (5 invoices)');
 const a=await D(pa); const nos=a.sales.map(s=>s.no).sort((x,y)=>x-y); ok(new Set(nos).size===5,'invoice numbers unique after the collision: '+nos.join(',')); ok(a.products[0].stock===200-30-10-5-7-3,'stock = 200-30-10-5-7-3 = '+a.products[0].stock); ok(a.expenses.length===1,'offline expense kept');
 // ---------- persistence: reload PC, state survives and stays synced
 await pb.reload(); await pb.waitForSelector('#splash.hidden',{state:'attached'}); await sleep(500); const b2=await D(pb); ok(b2.sales.length===5 && b2.sales.every(s=>s._m!==undefined || true) && !!await pb.evaluate(()=>localStorage.getItem('kp_sync')),'PC reload keeps data and pairing'); ok(await until(async()=>await pb.locator('#syncdot.s-idle').count()===1,6000),'PC reconnects by itself after reload');
 await pb.evaluate(()=>{ const U=window.KPU; U.commit(d=>{ d.customers[0].phone='0770'; }); }); ok(await until(async()=>(await D(pa)).customers[0].phone==='0770',5000),'live sync still works after reload');
 // ---------- per-device settings
 await pa.evaluate(()=>{ window.KPU.commit(d=>{ d.settings.theme='dark'; d.settings.lang='fr'; }); }); await sleep(800); ok((await D(pb)).settings.lang==='ar' && (await D(pb)).settings.theme!=='dark','language/theme are per device (not synced)');
 // ---------- wrong group / server down
 await pb.evaluate(()=>window.KPU.sync.unpair()); ok(await pb.locator('#syncdot').count()===0 && !(await pb.evaluate(()=>localStorage.getItem('kp_sync'))),'disconnect removes pairing and the dot'); ok((await D(pb)).sales.length===5,'data stays on the device after disconnect');
 net.up=false; const e1=await pb.evaluate(c=>window.KPU.sync.join(c).then(()=>'ok',e=>e.code),code); ok(e1==='sync_unreachable','join with server down -> clear error'); net.up=true;
 const bad=S.makeCode('https://relay.test',S.newSecret?'x'.repeat(43):''); const e2=await pb.evaluate(c=>window.KPU.sync.join(c).then(()=>'ok',e=>e.code),bad); ok(e2==='sync_empty_group','unknown group -> "group is empty" error');
 const wrongKey=S.makeCode('https://relay.test','y'.repeat(43)); ok((await D(pb)).sales.length===5,'failed joins never touch local data');
 console.log('A errs',A.errors.length,'B errs',B.errors.length); console.log('errors:',[...A.errors,...B.errors].filter(x=>!/Failed to load resource|net::ERR_FAILED/.test(x)).join(' | ')||'none'); console.log('pass',pass,'fail',fail); await A.close(); await B.close(); process.exit(fail?1:0); })();
