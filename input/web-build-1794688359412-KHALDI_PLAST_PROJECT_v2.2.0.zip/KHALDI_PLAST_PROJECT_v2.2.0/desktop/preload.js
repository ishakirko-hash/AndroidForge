// Exposes the same bridge the Android app has (window.KPAndroid) so the web app runs unchanged.
const { contextBridge, ipcRenderer, webFrame } = require('electron');
const call = (ch, ...a) => ipcRenderer.sendSync(ch, ...a);
const js = code => { try { webFrame.executeJavaScript(code); } catch (e) {} };
contextBridge.exposeInMainWorld('KPAndroid', {
  loadData: () => call('kp:load'),
  loadPrevData: () => call('kp:loadPrev'),
  saveData: json => call('kp:save', json),
  saveSideFile: (n, c) => call('kp:saveSide', n, c),
  loadSideFile: n => call('kp:loadSide', n),
  printPage: name => { ipcRenderer.send('kp:print', String(name || 'KHALDI PLAST')); },
  shareText: text => { call('kp:copy', String(text || '')); js("window.KPU && KPU.toast(KPU.t('copied'), 'ok')"); },
  exportFile: (name, mime, content) => { const r = call('kp:export', String(name), String(content)); js('window.KPExportDone && window.KPExportDone(' + (r === 'ok') + ',' + (r === 'cancel') + ')'); }
  // no scanQR on the desktop: the app falls back to typing the invoice number
});
