const { app, BrowserWindow, ipcMain, dialog, clipboard, protocol, net, Menu, shell } = require('electron');
const path = require('path'), fs = require('fs'), { pathToFileURL } = require('url');
const makeStore = require('./store.js');

protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }]);
if (!app.requestSingleInstanceLock()) { app.quit(); }

let win = null, store = null;
const WWW = path.join(__dirname, 'www');

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 900, minHeight: 600, backgroundColor: '#F3F7FC', title: 'KHALDI PLAST', autoHideMenuBar: true,
    icon: path.join(__dirname, 'build', 'icon.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false, spellcheck: false }
  });
  Menu.setApplicationMenu(null);
  win.loadURL('app://khaldi/index.html');
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('app://khaldi/')) e.preventDefault(); });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    else if (input.key === 'Escape' || (input.alt && input.key === 'ArrowLeft')) { win.webContents.executeJavaScript('window.KPBack && window.KPBack()').catch(() => {}); }
    else if (input.control && (input.key === '+' || input.key === '=')) { win.webContents.setZoomLevel(Math.min(3, win.webContents.getZoomLevel() + 0.5)); e.preventDefault(); }
    else if (input.control && input.key === '-') { win.webContents.setZoomLevel(Math.max(-2, win.webContents.getZoomLevel() - 0.5)); e.preventDefault(); }
    else if (input.control && input.key === '0') { win.webContents.setZoomLevel(0); e.preventDefault(); }
  });
  win.on('closed', () => { win = null; });
}

app.whenReady().then(() => {
  store = makeStore(path.join(app.getPath('userData'), 'data'));
  protocol.handle('app', req => {
    const u = new URL(req.url); let rel = decodeURIComponent(u.pathname); if (rel === '/' || rel === '') rel = '/index.html';
    const file = path.normalize(path.join(WWW, rel));
    if (!file.startsWith(WWW + path.sep)) return new Response('forbidden', { status: 403 });
    return net.fetch(pathToFileURL(file).toString());
  });
  ipcMain.on('kp:load', e => { e.returnValue = store.loadData(); });
  ipcMain.on('kp:loadPrev', e => { e.returnValue = store.loadPrev(); });
  ipcMain.on('kp:save', (e, json) => { e.returnValue = store.saveData(json); });
  ipcMain.on('kp:saveSide', (e, n, c) => { e.returnValue = store.saveSide(n, c); });
  ipcMain.on('kp:loadSide', (e, n) => { e.returnValue = store.loadSide(n); });
  ipcMain.on('kp:copy', (e, text) => { clipboard.writeText(text); e.returnValue = true; });
  ipcMain.on('kp:export', (e, name, content) => {
    const r = dialog.showSaveDialogSync(win, { defaultPath: path.join(app.getPath('documents'), String(name).replace(/[\\/:*?"<>|]/g, '_')) });
    if (!r) { e.returnValue = 'cancel'; return; }
    try { fs.writeFileSync(r, content, 'utf8'); e.returnValue = 'ok'; } catch (err) { e.returnValue = 'fail'; }
  });
  ipcMain.on('kp:print', (e, name) => { if (win) win.webContents.print({ silent: false, printBackground: true, pageSize: 'A4', deviceName: '' }); });
  createWindow();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => { app.quit(); });
