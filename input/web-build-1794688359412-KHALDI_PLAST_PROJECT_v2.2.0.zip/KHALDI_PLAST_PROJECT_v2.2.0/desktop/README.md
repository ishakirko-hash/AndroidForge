Windows desktop build of KHALDI PLAST (Electron). Built by the GitHub workflow "Build KHALDI PLAST for Windows"
(it copies app/src/main/assets/www into desktop/www, then runs electron-builder). Not run locally by the author.
