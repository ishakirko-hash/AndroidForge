// Data files of the desktop app (same contract as the Android bridge): atomic write, one previous copy, allow-listed side files.
const fs = require('fs'), path = require('path');
const SIDE = /^(premigration_v[0-9]+|before_import)\.json$/;
module.exports = function (dir) {
  fs.mkdirSync(dir, { recursive: true });
  const f = n => path.join(dir, n), read = p => { try { return fs.readFileSync(p, 'utf8'); } catch (e) { return ''; } };
  function write(p, content) { const tmp = p + '.tmp', fd = fs.openSync(tmp, 'w'); try { fs.writeSync(fd, content); fs.fsyncSync(fd); } finally { fs.closeSync(fd); } return tmp; }
  return {
    loadData: () => read(f('khaldi_data.json')),
    loadPrev: () => read(f('khaldi_data.prev.json')),
    saveData(json) {
      if (typeof json !== 'string' || json.length < 2) return false;
      try {
        const data = f('khaldi_data.json'), prev = f('khaldi_data.prev.json'), tmp = write(data, json);
        if (fs.existsSync(data)) { try { fs.rmSync(prev, { force: true }); } catch (e) {} fs.renameSync(data, prev); }
        try { fs.renameSync(tmp, data); } catch (e) { if (!fs.existsSync(data) && fs.existsSync(prev)) fs.renameSync(prev, data); return false; }
        return true;
      } catch (e) { return false; }
    },
    saveSide(name, content) { if (!SIDE.test(name || '') || typeof content !== 'string') return false; try { const tmp = write(f(name), content); fs.renameSync(tmp, f(name)); return true; } catch (e) { return false; } },
    loadSide(name) { return SIDE.test(name || '') ? read(f(name)) : ''; }
  };
};
