// DEV/PREVIEW ONLY. Serves the project and exposes a local SQLite (Node built-in) over /__sql so the real UI + real core
// can run in a desktop browser. Never shipped in the APK (Android uses @capacitor-community/sqlite). Binds to 127.0.0.1.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.json': 'application/json', '.svg': 'image/svg+xml' };

export function startDevServer({ port = 8765, dbPath = ':memory:' } = {}) {
  const raw = new DatabaseSync(dbPath); raw.exec('PRAGMA foreign_keys = ON;');
  const decode = (text) => JSON.parse(text, (k, v) => (v && typeof v === 'object' && '$big' in v ? BigInt(v.$big) : v));
  let chain = Promise.resolve();
  const server = http.createServer((req, res) => {
    const send = (code, body, type = 'application/json') => { res.writeHead(code, { 'Content-Type': type }); res.end(body); };
    if (req.method === 'POST' && req.url === '/__sql') {
      let body = ''; req.on('data', (c) => { body += c; });
      req.on('end', () => { chain = chain.then(() => {
        try {
          const { op, sql, params = [] } = decode(body);
          if (op === 'exec') raw.exec(sql);
          else if (op === 'begin') raw.exec('BEGIN IMMEDIATE');
          else if (op === 'commit') raw.exec('COMMIT');
          else if (op === 'rollback') { try { raw.exec('ROLLBACK'); } catch { /* none open */ } }
          else if (op === 'run') { const r = raw.prepare(sql).run(...params); return send(200, JSON.stringify({ changes: Number(r.changes), lastId: Number(r.lastInsertRowid) })); }
          else if (op === 'all') return send(200, JSON.stringify(raw.prepare(sql).all(...params).map((r) => ({ ...r }))));
          else if (op === 'get') { const r = raw.prepare(sql).get(...params); return send(200, JSON.stringify(r ? { ...r } : null)); }
          else if (op === 'ping') return send(200, '{"ok":true}');
          else return send(400, JSON.stringify({ error: 'unknown op' }));
          return send(200, '{"ok":true}');
        } catch (e) { return send(400, JSON.stringify({ error: e.message })); }
      }); });
      return;
    }
    const rel = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    const file = path.resolve(root, '.' + (rel === '/' ? '/index.html' : rel));
    if (!file.startsWith(root + path.sep) || /(^|[\\/])(\.|node_modules|tests|tools)/.test(path.relative(root, file)) ) return send(404, 'not found', 'text/plain');
    fs.readFile(file, (err, data) => (err ? send(404, 'not found', 'text/plain') : send(200, data, MIME[path.extname(file)] ?? 'application/octet-stream')));
  });
  return new Promise((resolve) => server.listen(port, '127.0.0.1', () => resolve({ server, raw, port, close: () => new Promise((r) => { server.close(r); raw.close(); }) })));
}
if (import.meta.url === `file://${process.argv[1]}`) {
  const s = await startDevServer({ port: Number(process.env.PORT ?? 8765), dbPath: process.env.DB ?? ':memory:' });
  console.log(`KHALDI PLAST ERP preview on http://127.0.0.1:${s.port}/  (db: ${process.env.DB ?? 'memory'})`);
}
