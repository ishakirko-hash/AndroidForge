// Dependency-free "build": copies the static app into www/ (Capacitor webDir). No bundler involved.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
const copy = (from, to, skip = () => false) => {
  const st = fs.statSync(from);
  if (st.isDirectory()) { fs.mkdirSync(to, { recursive: true }); for (const f of fs.readdirSync(from)) if (!skip(path.join(from, f))) copy(path.join(from, f), path.join(to, f), skip); }
  else { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); }
};
copy(path.join(root, 'index.html'), path.join(out, 'index.html'));
copy(path.join(root, 'src'), path.join(out, 'src'), (p) => p.endsWith('node-driver.js')); // node-only test driver is not shipped
copy(path.join(root, 'assets/brand/logo-official.png'), path.join(out, 'assets/brand/logo-official.png'));
console.log('web app written to', out);
