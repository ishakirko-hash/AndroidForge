KHALDI PLAST ERP — حزمة Android Forge

المحتويات:
- KHALDI_PLAST_ERP_Android_Forge_Master_Prompt.md: المواصفات الكاملة التي ترفعها إلى Android Forge أو تنسخها إلى تعليمات المشروع.

ملاحظة:
هذه حزمة مواصفات لتوليد التطبيق وليست APK جاهزًا. أرفق داخل Android Forge صور الواجهات المرجعية وملف الشعار الأصلي بشكل منفصل إذا كانت الأداة تسمح بذلك.
