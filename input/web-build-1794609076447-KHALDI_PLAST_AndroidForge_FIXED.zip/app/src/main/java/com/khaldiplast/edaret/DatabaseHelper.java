package com.khaldiplast.edaret;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "khaldi_factory.db";
    private static final int DB_VERSION = 2;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) { createSchema(db); seedProducts(db); }

    private void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,dimensions TEXT,weight_g REAL,price_dzd REAL DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS production(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,product TEXT,quantity REAL,machine TEXT,worker TEXT,material_name TEXT,material_qty REAL DEFAULT 0,notes TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,unit TEXT,quantity REAL DEFAULT 0,min_qty REAL DEFAULT 0,price_dzd REAL DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_moves(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,material TEXT,direction TEXT,quantity REAL,reason TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS finished_stock(id INTEGER PRIMARY KEY AUTOINCREMENT,product TEXT UNIQUE,quantity REAL DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,customer TEXT,product TEXT,quantity REAL,unit_price REAL,discount REAL DEFAULT 0,tax_rate REAL DEFAULT 0,paid REAL DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,category TEXT,amount REAL,party TEXT,payment_method TEXT,notes TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,body TEXT,link_type TEXT,link_id INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,action TEXT,details TEXT)");
    }

    private void seedProducts(SQLiteDatabase db) {
        db.execSQL("INSERT OR IGNORE INTO products(name,dimensions,weight_g,price_dzd) VALUES('CP9','90 × 300 × 500 مم',250,0)");
        db.execSQL("INSERT OR IGNORE INTO products(name,dimensions,weight_g,price_dzd) VALUES('CP14','140 × 300 × 500 مم',350,0)");
        db.execSQL("INSERT OR IGNORE INTO products(name,dimensions,weight_g,price_dzd) VALUES('Sipora 14','140 × 300 × 400 مم',NULL,0)");
        db.execSQL("INSERT OR IGNORE INTO products(name,dimensions,weight_g,price_dzd) VALUES('Sipora 20','200 × 300 × 400 مم',NULL,0)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        createSchema(db);
        if (oldVersion < 2) {
            // Migrate earlier prototype column names without discarding existing local data.
            addColumnIfMissing(db,"production","quantity","REAL DEFAULT 0");
            addColumnIfMissing(db,"production","material_name","TEXT");
            addColumnIfMissing(db,"production","material_qty","REAL DEFAULT 0");
            addColumnIfMissing(db,"stock","quantity","REAL DEFAULT 0");
            addColumnIfMissing(db,"stock","price_dzd","REAL DEFAULT 0");
            addColumnIfMissing(db,"sales","quantity","REAL DEFAULT 0");
            addColumnIfMissing(db,"sales","tax_rate","REAL DEFAULT 0");
            addColumnIfMissing(db,"products","weight_g","REAL");
            addColumnIfMissing(db,"products","price_dzd","REAL DEFAULT 0");
            addColumnIfMissing(db,"expenses","payment_method","TEXT");
            addColumnIfMissing(db,"notes","link_type","TEXT");
            addColumnIfMissing(db,"notes","link_id","INTEGER DEFAULT 0");
            copyLegacyColumn(db,"production","qty","quantity");
            copyLegacyColumn(db,"stock","qty","quantity");
            copyLegacyColumn(db,"stock","price","price_dzd");
            copyLegacyColumn(db,"sales","qty","quantity");
            copyLegacyColumn(db,"products","weight","weight_g");
            copyLegacyColumn(db,"products","price","price_dzd");
            seedProducts(db);
        }
    }
    private void addColumnIfMissing(SQLiteDatabase db,String table,String column,String type) {
        boolean found=false; Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null);
        while(c.moveToNext()) if(column.equals(c.getString(1))) found=true;
        c.close(); if(!found) db.execSQL("ALTER TABLE "+table+" ADD COLUMN "+column+" "+type);
    }
    private void copyLegacyColumn(SQLiteDatabase db,String table,String oldColumn,String newColumn) {
        boolean oldFound=false,newFound=false; Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null);
        while(c.moveToNext()){String name=c.getString(1);if(oldColumn.equals(name))oldFound=true;if(newColumn.equals(name))newFound=true;}
        c.close(); if(oldFound && newFound) db.execSQL("UPDATE "+table+" SET "+newColumn+" = "+oldColumn+" WHERE "+oldColumn+" IS NOT NULL");
    }

    public static String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
    }
    private void audit(SQLiteDatabase db,String action,String details) {
        ContentValues v=new ContentValues(); v.put("created_at",now()); v.put("action",action); v.put("details",details);
        db.insert("audit",null,v);
    }

    public long addProduction(String product,double quantity,String machine,String worker,String material,double materialQty,String notes) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try {
            if (material != null && !material.trim().isEmpty() && materialQty > 0) {
                Cursor c=db.rawQuery("SELECT quantity FROM stock WHERE name=?",new String[]{material});
                if (!c.moveToFirst()) { c.close(); throw new IllegalArgumentException("المادة غير موجودة في المخزون"); }
                double available=c.getDouble(0); c.close();
                if (available < materialQty) throw new IllegalArgumentException("الكمية المتوفرة من المادة غير كافية");
                ContentValues s=new ContentValues(); s.put("quantity",available-materialQty);
                db.update("stock",s,"name=?",new String[]{material});
                ContentValues m=new ContentValues(); m.put("created_at",now());m.put("material",material);m.put("direction","صرف للإنتاج");m.put("quantity",materialQty);m.put("reason","دفعة إنتاج "+product);
                db.insert("stock_moves",null,m);
            }
            ContentValues v=new ContentValues();v.put("created_at",now());v.put("product",product);v.put("quantity",quantity);
            v.put("machine",machine);v.put("worker",worker);v.put("material_name",material);v.put("material_qty",materialQty);v.put("notes",notes);
            long id=db.insertOrThrow("production",null,v);
            Cursor f=db.rawQuery("SELECT quantity FROM finished_stock WHERE product=?",new String[]{product});
            if(f.moveToFirst()){double current=f.getDouble(0);f.close();ContentValues fv=new ContentValues();fv.put("quantity",current+quantity);db.update("finished_stock",fv,"product=?",new String[]{product});}
            else {f.close();ContentValues fv=new ContentValues();fv.put("product",product);fv.put("quantity",quantity);db.insert("finished_stock",null,fv);}
            audit(db,"إضافة دفعة إنتاج",product+" — "+quantity+" قطعة");
            db.setTransactionSuccessful(); return id;
        } finally { db.endTransaction(); }
    }
    public long addStock(String name,String unit,double quantity,double min,double price) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            ContentValues v=new ContentValues();v.put("name",name);v.put("unit",unit);v.put("quantity",quantity);v.put("min_qty",min);v.put("price_dzd",price);
            long id=db.insertWithOnConflict("stock",null,v,SQLiteDatabase.CONFLICT_REPLACE);
            ContentValues m=new ContentValues();m.put("created_at",now());m.put("material",name);m.put("direction","رصيد افتتاحي / تحديث");m.put("quantity",quantity);m.put("reason","إدخال من شاشة المخزون");db.insert("stock_moves",null,m);
            audit(db,"إضافة أو تحديث مادة",name+" — "+quantity+" "+unit);db.setTransactionSuccessful();return id;
        } finally {db.endTransaction();}
    }
    public long addSale(String customer,String product,double qty,double price,double discount,double tax,double paid) {
        if(qty<=0 || price<0 || discount<0 || tax<0 || tax>100 || paid<0) throw new IllegalArgumentException("راجع الكمية والسعر والخصم والضريبة والمدفوع");
        double net=Math.max(0,qty*price-discount);double total=net+(net*tax/100.0);
        if(paid>total+0.0001) throw new IllegalArgumentException("المبلغ المدفوع أكبر من إجمالي العملية");
        SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("created_at",now());v.put("customer",customer);v.put("product",product);
        v.put("quantity",qty);v.put("unit_price",price);v.put("discount",discount);v.put("tax_rate",tax);v.put("paid",paid);
        db.beginTransaction();
        try {
            Cursor f=db.rawQuery("SELECT quantity FROM finished_stock WHERE product=?",new String[]{product});
            if(f.moveToFirst()) {
                double available=f.getDouble(0);f.close();
                if(available<qty)throw new IllegalArgumentException("رصيد المنتج النهائي غير كافٍ. راجع مخزون المنتجات.");
                ContentValues fv=new ContentValues();fv.put("quantity",available-qty);db.update("finished_stock",fv,"product=?",new String[]{product});
                ContentValues mv=new ContentValues();mv.put("created_at",now());mv.put("material",product);mv.put("direction","صرف للبيع");mv.put("quantity",qty);mv.put("reason","عملية بيع للعميل "+customer);db.insert("stock_moves",null,mv);
            } else f.close();
            long id=db.insert("sales",null,v);audit(db,"تسجيل عملية بيع",customer+" — "+product+" — "+total+" دج");db.setTransactionSuccessful();return id;
        } finally {db.endTransaction();}
    }
    public long addExpense(String category,double amount,String party,String method,String notes) {
        if(amount<=0) throw new IllegalArgumentException("أدخل مبلغاً أكبر من صفر");
        ContentValues v=new ContentValues();v.put("created_at",now());v.put("category",category);v.put("amount",amount);v.put("party",party);v.put("payment_method",method);v.put("notes",notes);
        long id=getWritableDatabase().insert("expenses",null,v);audit(getWritableDatabase(),"تسجيل مصروف",category+" — "+amount+" دج");return id;
    }
    public long addFinishedStock(String product,double quantity) {
        if(quantity<=0)throw new IllegalArgumentException("أدخل كمية أكبر من صفر");
        SQLiteDatabase db=getWritableDatabase();Cursor c=db.rawQuery("SELECT quantity FROM finished_stock WHERE product=?",new String[]{product});
        double current=0;boolean found=c.moveToFirst();if(found)current=c.getDouble(0);c.close();
        ContentValues v=new ContentValues();v.put("product",product);v.put("quantity",current+quantity);
        if(found)db.update("finished_stock",v,"product=?",new String[]{product});else db.insert("finished_stock",null,v);
        ContentValues mv=new ContentValues();mv.put("created_at",now());mv.put("material",product);mv.put("direction","رصيد افتتاحي للمنتج");mv.put("quantity",quantity);mv.put("reason","إضافة رصيد يدوي");db.insert("stock_moves",null,mv);
        audit(db,"إضافة رصيد منتج نهائي",product+" — "+quantity+" قطعة");return 1;
    }
    public double finishedQty(String product) {
        Cursor c=getReadableDatabase().rawQuery("SELECT quantity FROM finished_stock WHERE product=?",new String[]{product});
        double n=0;if(c.moveToFirst())n=c.getDouble(0);c.close();return n;
    }
    public long addNote(String body,String linkType) {
        ContentValues v=new ContentValues();v.put("created_at",now());v.put("body",body);v.put("link_type",linkType);
        long id=getWritableDatabase().insert("notes",null,v);audit(getWritableDatabase(),"إضافة ملاحظة",body);return id;
    }
    public long addProduct(String name,String dimensions,Double weight,double price) {
        ContentValues v=new ContentValues();v.put("name",name);v.put("dimensions",dimensions);
        if(weight==null)v.putNull("weight_g");else v.put("weight_g",weight);v.put("price_dzd",price);
        long id=getWritableDatabase().insertWithOnConflict("products",null,v,SQLiteDatabase.CONFLICT_REPLACE);
        audit(getWritableDatabase(),"تحديث بيانات منتج",name);return id;
    }
    public boolean delete(String table,long id) {
        if(!Arrays.asList("production","stock","sales","expenses","notes","products").contains(table)) return false;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            if("production".equals(table)) {
                Cursor c=db.rawQuery("SELECT product,quantity,material_name,material_qty FROM production WHERE id=?",new String[]{String.valueOf(id)});
                if(!c.moveToFirst()){c.close();return false;}
                String product=c.getString(0),material=c.getString(2);double qty=c.getDouble(1),used=c.getDouble(3);c.close();
                Cursor f=db.rawQuery("SELECT quantity FROM finished_stock WHERE product=?",new String[]{product});
                if(f.moveToFirst()){double stock=f.getDouble(0);f.close();if(stock<qty)throw new IllegalArgumentException("لا يمكن حذف الدفعة بعد بيع جزء من إنتاجها. استخدم تسوية مخزون بدلاً من ذلك.");ContentValues fv=new ContentValues();fv.put("quantity",stock-qty);db.update("finished_stock",fv,"product=?",new String[]{product});}else f.close();
                if(material!=null && !material.isEmpty() && used>0){Cursor s=db.rawQuery("SELECT quantity FROM stock WHERE name=?",new String[]{material});if(s.moveToFirst()){double stock=s.getDouble(0);s.close();ContentValues sv=new ContentValues();sv.put("quantity",stock+used);db.update("stock",sv,"name=?",new String[]{material});ContentValues mv=new ContentValues();mv.put("created_at",now());mv.put("material",material);mv.put("direction","استرجاع بعد حذف دفعة");mv.put("quantity",used);mv.put("reason","حذف دفعة إنتاج "+product);db.insert("stock_moves",null,mv);}else s.close();}
            }
            int n=db.delete(table,"id=?",new String[]{String.valueOf(id)});
            if(n>0)audit(db,"حذف سجل",table+" #"+id);
            db.setTransactionSuccessful();return n>0;
        } finally {db.endTransaction();}
    }
    public double sum(String table,String expression) {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM("+expression+"),0) FROM "+table,null);
        double n=0;if(c.moveToFirst())n=c.getDouble(0);c.close();return n;
    }
    public int count(String table) {
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;
    }
    public int lowStockCount() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM stock WHERE quantity<=min_qty",null);int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;
    }
    public List<String[]> list(String table) {
        ArrayList<String[]> out=new ArrayList<>();
        String sql;
        switch(table) {
            case "production": sql="SELECT id,created_at,product,quantity,machine,worker FROM production ORDER BY id DESC LIMIT 100";break;
            case "stock": sql="SELECT id,name,unit,quantity,min_qty,price_dzd FROM stock ORDER BY name";break;
            case "sales": sql="SELECT id,created_at,customer,product,quantity,unit_price,discount,tax_rate,paid FROM sales ORDER BY id DESC LIMIT 100";break;
            case "expenses": sql="SELECT id,created_at,category,amount,party,payment_method FROM expenses ORDER BY id DESC LIMIT 100";break;
            case "notes": sql="SELECT id,created_at,body FROM notes ORDER BY id DESC LIMIT 100";break;
            case "products": sql="SELECT id,name,dimensions,weight_g,price_dzd FROM products ORDER BY name";break;
            case "stock_moves": sql="SELECT id,created_at,material,direction,quantity,reason FROM stock_moves ORDER BY id DESC LIMIT 100";break;
            case "finished_stock": sql="SELECT id,product,quantity FROM finished_stock ORDER BY product";break;
            default: sql="SELECT id,created_at,action,details FROM audit ORDER BY id DESC LIMIT 100";
        }
        Cursor c=getReadableDatabase().rawQuery(sql,null);
        while(c.moveToNext()){String[] row=new String[c.getColumnCount()];for(int i=0;i<row.length;i++)row[i]=c.isNull(i)?"":c.getString(i);out.add(row);}c.close();return out;
    }
    public List<String> names(String table,String column) {
        ArrayList<String> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT "+column+" FROM "+table+" ORDER BY "+column,null);
        while(c.moveToNext())a.add(c.getString(0));c.close();return a;
    }
}
