package com.khaldiplast.edaret;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.text.*;
import android.text.InputType;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    private DatabaseHelper db;
    private LinearLayout root, body, topArea, bottomNav;
    private ScrollView scroll;
    private String screen="الرئيسية";
    private final int navy=Color.rgb(12,34,58), blue=Color.rgb(18,103,190), cyan=Color.rgb(0,174,232);
    private final int text=Color.rgb(22,38,55), secondary=Color.rgb(112,130,148), bg=Color.rgb(244,248,252), line=Color.rgb(226,234,242);
    private boolean busy=false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(247,250,253));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        db=new DatabaseHelper(this);
        show("الرئيسية");
    }

    private GradientDrawable shape(int color,float radius,int strokeColor,int strokeWidth) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));
        if(strokeWidth>0)d.setStroke(dp(strokeWidth),strokeColor);return d;
    }
    private GradientDrawable gradient(int a,int b,float radius) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(dp(radius));return d;
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    private TextView label(String s,float size,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        t.setFontFeatureSettings("kern"); return t;
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void margin(View v,int top,int bottom){LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)v.getLayoutParams();p.topMargin=dp(top);p.bottomMargin=dp(bottom);v.setLayoutParams(p);}
    private void show(String name) {
        screen=name;
        root=vertical();root.setBackgroundColor(bg);
        topArea=vertical();topArea.setPadding(dp(20),dp(8),dp(20),dp(12));
        buildHeader();root.addView(topArea,lp(-1,-2));
        scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);scroll.setVerticalScrollBarEnabled(false);
        body=vertical();body.setPadding(dp(18),dp(5),dp(18),dp(28));scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        buildBottomNav();root.addView(bottomNav,lp(-1,72));
        setContentView(root);
        populate();
        animateIn(body);
        installPullToRefresh();
    }
    private void buildHeader() {
        LinearLayout row=horizontal();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.khaldi_logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(logo,lp(62,62));
        LinearLayout titles=vertical();titles.setPadding(dp(10),0,dp(4),0);
        titles.addView(label("إدارة المصنع",18,text,true));
        titles.addView(label("KHALDI PLAST  •  نظام إدارة الإنتاج",10,secondary,false));
        row.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        TextView bell=label("♧",22,blue,true);bell.setGravity(Gravity.CENTER);bell.setBackground(shape(Color.WHITE,18,line,1));
        bell.setElevation(dp(2));row.addView(bell,lp(44,44));
        bell.setOnClickListener(v->{v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);openMore("التنبيهات");});
        topArea.addView(row);
        TextView page=label(nameForHeader(screen),25,navy,true);page.setPadding(0,dp(13),0,0);topArea.addView(page);
        TextView date=label(new SimpleDateFormat("EEEE، d MMMM yyyy",new Locale("ar")).format(new Date()),11,secondary,false);
        date.setPadding(0,dp(3),0,0);topArea.addView(date);
    }
    private String nameForHeader(String s){return s.equals("الرئيسية")?"نظرة عامة":s;}
    private void buildBottomNav() {
        bottomNav=horizontal();bottomNav.setBackgroundColor(Color.WHITE);bottomNav.setElevation(dp(14));
        String[][] tabs={{"الرئيسية","⌂"},{"الإنتاج","▦"},{"المخزون","▤"},{"المبيعات","↗"},{"المزيد","•••"}};
        for(String[] tab:tabs) {
            LinearLayout item=vertical();item.setGravity(Gravity.CENTER);
            boolean selected=screen.equals(tab[0]);
            TextView icon=label(tab[1],21,selected?blue:secondary,true);icon.setGravity(Gravity.CENTER);
            TextView title=label(tab[0],10,selected?blue:secondary,selected);title.setGravity(Gravity.CENTER);
            item.addView(icon);item.addView(title);
            if(selected){View dot=new View(this);dot.setBackground(shape(cyan,5,0,0));LinearLayout.LayoutParams p=lp(5,5);p.topMargin=dp(3);item.addView(dot,p);}
            bottomNav.addView(item,new LinearLayout.LayoutParams(0,-1,1));
            item.setOnClickListener(v->{v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);show(tab[0]);});
        }
    }
    private void animateIn(View v) {
        v.setAlpha(0f);v.setTranslationY(dp(12));
        v.animate().alpha(1f).translationY(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
    }
    private void installPullToRefresh() {
        scroll.setOnTouchListener(new View.OnTouchListener(){
            float y;
            @Override public boolean onTouch(View v,MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN)y=e.getY();
                else if(e.getAction()==MotionEvent.ACTION_UP && scroll.getScrollY()==0 && e.getY()-y>dp(85)) {
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);show(screen);return true;
                }
                return false;
            }
        });
    }
    private void populate() {
        switch(screen) {
            case "الرئيسية": home();break;
            case "الإنتاج": production();break;
            case "المخزون": stock();break;
            case "المبيعات": sales();break;
            case "المزيد": more();break;
            case "تسجيل دفعة إنتاج": case "إضافة مادة": case "إضافة رصيد منتج نهائي":
            case "عملية بيع": case "إضافة مصروف": case "ملاحظة جديدة": case "إضافة منتج":
                break;
            default: generic(screen);
        }
    }
    private void section(String title,String action,Runnable r) {
        LinearLayout row=horizontal();TextView t=label(title,16,text,true);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        if(action!=null){TextView a=label(action,12,blue,true);row.addView(a);a.setOnClickListener(v->r.run());}
        LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(18);p.bottomMargin=dp(10);body.addView(row,p);
    }
    private void cardBase(LinearLayout card) {
        card.setPadding(dp(16),dp(15),dp(16),dp(15));card.setBackground(shape(Color.WHITE,22,line,1));
        card.setElevation(dp(2));card.setClipToOutline(true);
        if(android.os.Build.VERSION.SDK_INT>=23) {
            android.graphics.drawable.Drawable mask=shape(Color.WHITE,22,0,0);
            card.setForeground(new RippleDrawable(android.content.res.ColorStateList.valueOf(Color.rgb(225,241,252)),null,mask));
        }
    }
    private void metric(String title,String value,String sub,String glyph,int color,Runnable click) {
        LinearLayout card=vertical();cardBase(card);
        LinearLayout row=horizontal();
        TextView icon=label(glyph,19,color,true);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(withAlpha(color,22),13,0,0));row.addView(icon,lp(40,40));
        TextView t=label(title,12,secondary,true);t.setPadding(dp(9),0,0,0);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=label("‹",22,secondary,false);row.addView(arrow);
        card.addView(row);
        TextView v=label(value,23,text,true);v.setPadding(0,dp(13),0,dp(2));card.addView(v);
        card.addView(label(sub,10,secondary,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(4),dp(4),dp(4),dp(4));
        card.setOnClickListener(view->{view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);click.run();});
        tempGrid.addView(card,p);
    }
    private int withAlpha(int c,int alpha){return Color.argb(alpha,Color.red(c),Color.green(c),Color.blue(c));}
    private LinearLayout tempGrid;
    private void home() {
        LinearLayout hero=vertical();hero.setPadding(dp(18),dp(18),dp(18),dp(18));hero.setBackground(gradient(Color.rgb(10,49,91),Color.rgb(18,116,193),24));
        hero.addView(label("ملخص نشاط المصنع",14,Color.WHITE,true));
        TextView today=label("ابدأ يومك بمراجعة الإنتاج والمبيعات",11,Color.rgb(210,233,249),false);today.setPadding(0,dp(4),0,dp(15));hero.addView(today);
        LinearLayout h=horizontal();
        h.addView(label("الإنتاج المسجل",12,Color.WHITE,false),new LinearLayout.LayoutParams(0,-2,1));
        h.addView(label(String.format(Locale.US,"%.0f قطعة",db.sum("production","quantity")),24,Color.WHITE,true));
        hero.addView(h);body.addView(hero);
        section("المؤشرات الرئيسية",null,null);
        LinearLayout row1=horizontal();body.addView(row1);
        tempGrid=row1;
        metric("المبيعات",money(db.sum("sales","MAX(0,quantity*unit_price-discount)*(1+tax_rate/100)")),"إجمالي قيمة المبيعات","↗",blue,()->show("المبيعات"));
        metric("المصاريف",money(db.sum("expenses","amount")),"المصروفات المسجلة","−",Color.rgb(224,143,49),()->show("المصاريف"));
        LinearLayout row2=horizontal();LinearLayout.LayoutParams r2=lp(-1,-2);r2.topMargin=dp(4);body.addView(row2,r2);
        tempGrid=row2;
        metric("المستحقات",money(db.sum("sales","MAX(0,quantity*unit_price-discount)*(1+tax_rate/100)-paid")),"مبالغ لم تُحصّل بعد","◷",Color.rgb(123,103,190),()->show("المبيعات"));
        metric("صافي نقدي",money(db.sum("sales","paid")-db.sum("expenses","amount")),"المقبوضات ناقص المصاريف المسجلة","＝",Color.rgb(25,153,115),()->show("التقارير"));
        tempGrid=null;
        section("إجراءات سريعة",null,null);
        LinearLayout quick=horizontal();body.addView(quick);
        quickButton(quick,"＋","دفعة إنتاج",blue,()->show("الإنتاج"));
        quickButton(quick,"＋","عملية بيع",cyan,()->show("المبيعات"));
        quickButton(quick,"＋","مصروف",Color.rgb(205,135,47),()->openExpense());
        quickButton(quick,"＋","مادة",Color.rgb(89,133,177),()->openStock());
        section("تنبيهات المخزون","التفاصيل",()->show("المخزون"));
        if(db.lowStockCount()==0) {
            infoCard("المخزون مستقر حالياً","لا توجد مواد مسجلة تحت حد التنبيه.", "✓",Color.rgb(24,153,112));
        } else infoCard("مواد تحتاج إلى إعادة الطلب",db.lowStockCount()+" مادة وصلت إلى حد التنبيه أو أقل.","!",Color.rgb(214,132,42));
        section("آخر النشاطات","عرض السجل",()->openMore("سجل النشاط"));
        addSimpleRows("audit","لا توجد حركات مسجلة بعد.");
        TextView hint=label("اسحب الصفحة إلى الأسفل لتحديث الملخص",10,secondary,false);hint.setGravity(Gravity.CENTER);hint.setPadding(0,dp(20),0,dp(6));body.addView(hint);
    }
    private void quickButton(LinearLayout row,String symbol,String title,int color,Runnable action) {
        LinearLayout b=vertical();b.setGravity(Gravity.CENTER);b.setPadding(dp(6),dp(12),dp(6),dp(12));b.setBackground(shape(Color.WHITE,18,line,1));
        TextView plus=label(symbol,21,color,true);plus.setGravity(Gravity.CENTER);b.addView(plus);
        TextView name=label(title,10,text,true);name.setGravity(Gravity.CENTER);b.addView(name);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(3),0,dp(3),0);row.addView(b,p);
        b.setOnClickListener(v->{v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);action.run();});
    }
    private void infoCard(String title,String subtitle,String glyph,int color) {
        LinearLayout c=horizontal();cardBase(c);
        TextView ic=label(glyph,21,color,true);ic.setGravity(Gravity.CENTER);ic.setBackground(shape(withAlpha(color,24),14,0,0));c.addView(ic,lp(42,42));
        LinearLayout tx=vertical();tx.setPadding(dp(10),0,0,0);tx.addView(label(title,13,text,true));tx.addView(label(subtitle,10,secondary,false));c.addView(tx,new LinearLayout.LayoutParams(0,-2,1));body.addView(c);
    }

    private void production() {
        section("الإنتاج","＋ تسجيل دفعة",()->openProduction());
        infoCard("كل دورة قالب = صندوق واحد","الزمن المرجعي 10–20 ثانية ويمكن تعديله حسب الآلة.", "▦",blue);
        section("سجل دفعات الإنتاج",null,null);
        addRecordCards("production","لا توجد دفعات إنتاج حتى الآن.");
    }
    private void stock() {
        section("المواد الأولية","＋ إضافة مادة",()->openStock());
        LinearLayout c=vertical();cardBase(c);c.addView(label("تنبيه المخزون",13,secondary,true));
        c.addView(label(db.lowStockCount()+" مادة تحتاج مراجعة",23, db.lowStockCount()>0?Color.rgb(207,128,38):Color.rgb(25,153,115),true));
        body.addView(c);
        section("المواد الخام","＋ إضافة مادة",()->openStock());
        addRecordCards("stock","لم تتم إضافة مواد أولية بعد.");
        section("المنتجات النهائية","＋ إضافة رصيد",()->openFinishedStock());
        addRecordCards("finished_stock","لم يتم تسجيل أرصدة المنتجات النهائية بعد.");
        section("حركات المخزون","عرض السجل",()->openMore("حركات المخزون"));
        addRecordCards("stock_moves","لا توجد حركات للمخزون.");
    }
    private void sales() {
        section("المبيعات والفواتير","＋ عملية بيع",()->openSale());
        metricSingle("إجمالي المبيعات",money(db.sum("sales","MAX(0,quantity*unit_price-discount)*(1+tax_rate/100)")));
        metricSingle("المبالغ المستحقة",money(db.sum("sales","MAX(0,quantity*unit_price-discount)*(1+tax_rate/100)-paid")));
        section("سجل المبيعات","إنشاء فاتورة",()->openSale());
        addRecordCards("sales","لا توجد مبيعات مسجلة بعد.");
    }
    private void metricSingle(String a,String b){LinearLayout c=vertical();cardBase(c);c.addView(label(a,12,secondary,true));c.addView(label(b,22,text,true));LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(6);body.addView(c,p);}
    private void more() {
        String[][] items={{"المصاريف","مصروفات وإيرادات","↔"},{"التقارير","تقارير الأداء والأرباح","▥"},{"الملاحظات","ملاحظات المصنع والطلبات القادمة","✎"},{"المنتجات","الأصناف والأوزان والأسعار","□"},{"حركات المخزون","الوارد والصادر من المواد","⇄"},{"سجل النشاط","تاريخ العمليات والتعديلات","◷"},{"الإعدادات","بيانات الشركة والنسخ الاحتياطي","⚙"}};
        for(String[] it:items) {
            LinearLayout c=horizontal();cardBase(c);
            TextView ic=label(it[2],20,blue,true);ic.setGravity(Gravity.CENTER);ic.setBackground(shape(Color.rgb(235,246,253),14,0,0));c.addView(ic,lp(42,42));
            LinearLayout tx=vertical();tx.setPadding(dp(10),0,0,0);tx.addView(label(it[0],14,text,true));tx.addView(label(it[1],10,secondary,false));c.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
            c.addView(label("‹",24,secondary,false));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(9);body.addView(c,p);
            c.setOnClickListener(v->openMore(it[0]));
        }
    }
    private void generic(String s) {
        section(s,"＋ إضافة",()->{
            if(s.equals("المصاريف"))openExpense();else if(s.equals("الملاحظات"))openNote();else if(s.equals("المنتجات"))openProduct();else openProduction();
        });
        if(s.equals("التقارير")) reportContent();
        else if(s.equals("الإعدادات")) settingsContent();
        else if(s.equals("المصاريف"))addRecordCards("expenses","لا توجد مصاريف مسجلة.");
        else if(s.equals("الملاحظات"))addRecordCards("notes","لا توجد ملاحظات.");
        else if(s.equals("المنتجات"))addRecordCards("products","لا توجد منتجات.");
        else if(s.equals("حركات المخزون"))addRecordCards("stock_moves","لا توجد حركات للمخزون.");
        else if(s.equals("سجل النشاط")||s.equals("التنبيهات"))addRecordCards("audit","لا توجد نشاطات.");
        else addRecordCards("audit","لا توجد سجلات.");
    }
    private void openMore(String name){show(name);}
    private void reportContent() {
        metricSingle("الإنتاج الكلي",String.format(Locale.US,"%.0f قطعة",db.sum("production","quantity")));
        metricSingle("المبيعات",money(db.sum("sales","MAX(0,quantity*unit_price-discount)*(1+tax_rate/100)")));
        metricSingle("المصاريف",money(db.sum("expenses","amount")));
        metricSingle("المقبوضات",money(db.sum("sales","paid")));
        infoCard("تنبيه حول صافي الربح","لا يُحسب صافي الربح قبل تسجيل تكاليف المواد والطاقة والأجور والمصاريف المرتبطة بالإنتاج.","i",blue);
        Button csv=button("تصدير ملخص CSV");csv.setOnClickListener(v->exportCsv());
    }
    private void settingsContent() {
        infoCard("حفظ محلي","تُحفظ السجلات في قاعدة بيانات SQLite على هذا الهاتف.","✓",Color.rgb(24,153,112));
        TextView t=label("العملة: الدينار الجزائري (دج)\nاللغة: العربية\nاتجاه الواجهة: من اليمين إلى اليسار\n\nالمنتجات المهيأة:\nCP9 — 90 × 300 × 500 مم — 250 غ تقريباً\nCP14 — 140 × 300 × 500 مم — 350 غ تقريباً\nSipora 14 — 140 × 300 × 400 مم\nSipora 20 — 200 × 300 × 400 مم\n\nلم يتم تحديد وزن Sipora 14 أو Sipora 20.",13,text,false);
        t.setPadding(dp(14),dp(14),dp(14),dp(14));t.setBackground(shape(Color.WHITE,18,line,1));body.addView(t);
        section("حماية البيانات",null,null);
        button("إنشاء نسخة احتياطية",()->backupDatabase());
        button("استعادة نسخة احتياطية",()->confirmRestore());
        button("تصدير ملخص CSV",()->exportCsv());
    }

    private void addRecordCards(String table,String empty) {
        List<String[]> rows=db.list(table);
        if(rows.isEmpty()){infoCard(empty,"استخدم زر الإضافة لتسجيل أول عملية.","＋",blue);return;}
        for(String[] row:rows) {
            LinearLayout c=vertical();c.setPadding(dp(14),dp(12),dp(14),dp(12));c.setBackground(shape(Color.WHITE,18,line,1));
            String title="",desc="";
            switch(table) {
                case "production": title=row[2]+" — "+fmt(row[3])+" قطعة";desc=row[1]+" • "+row[4]+" • "+row[5];break;
                case "stock": title=row[1];desc="الرصيد "+fmt(row[3])+" "+row[2]+" • حد التنبيه "+fmt(row[4]);break;
                case "sales": title=row[2]+" — "+row[3];desc=fmt(row[4])+" × "+money(parse(row[5]))+" • مدفوع "+money(parse(row[8]));break;
                case "expenses": title=row[2]+" — "+money(parse(row[3]));desc=row[1]+" • "+row[4]+" • "+row[5];break;
                case "notes": title=row[2];desc=row[1];break;
                case "products": title=row[1];desc=row[2]+" • "+(row[3].isEmpty()?"الوزن غير محدد":row[3]+" غ")+" • "+money(parse(row[4]));break;
                case "finished_stock": title=row[1];desc="الرصيد المتاح للبيع: "+fmt(row[2])+" قطعة";break;
                case "stock_moves": title=row[2]+" — "+row[3];desc=row[1]+" • "+fmt(row[4])+" • "+row[5];break;
                default: title=row.length>2?row[2]:"سجل";desc=row.length>3?row[3]:"";
            }
            c.addView(label(title,14,text,true));TextView d=label(desc,10,secondary,false);d.setPadding(0,dp(4),0,0);c.addView(d);
            if(table.equals("stock") && parse(row[3])<=parse(row[4])) {
                TextView warn=label("المخزون عند حد التنبيه أو أقل",10,Color.rgb(203,123,35),true);warn.setPadding(0,dp(5),0,0);c.addView(warn);
            }
            c.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("حذف السجل؟").setMessage("سيتم حذف السجل المحدد. لا يمكن التراجع عن الحذف.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d1,w)->{db.delete(table,Long.parseLong(row[0]));show(screen);}).show();return true;});
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(8);body.addView(c,p);
            c.setOnClickListener(v->{v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);if(table.equals("sales"))invoicePreview(row);else new AlertDialog.Builder(this).setTitle(title).setMessage(desc+"\n\nاضغط مطولاً على البطاقة لحذف السجل.").setPositiveButton("حسناً",null).show();});
        }
    }
    // عرض سجل التدقيق في لوحة التحكم؛ هذه الدالة كانت مستدعاة من home()
    // لكنها غير معرّفة، وهو ما تسبب في فشل Java compilation.
    private void addSimpleRows(String table, String emptyMessage) {
        List<String[]> rows = db.list(table);
        if (rows == null || rows.isEmpty()) {
            infoCard(emptyMessage, "ستظهر هنا آخر العمليات المسجلة تلقائياً.", "◷", secondary);
            return;
        }
        for (String[] row : rows) {
            LinearLayout card = vertical();
            cardBase(card);
            String action = row.length > 2 ? row[2] : "عملية";
            String details = row.length > 3 ? row[3] : "";
            String date = row.length > 1 ? row[1] : "";
            card.addView(label(action, 13, text, true));
            TextView detailView = label(details, 11, secondary, false);
            detailView.setPadding(0, dp(4), 0, 0);
            card.addView(detailView);
            TextView dateView = label(date, 10, secondary, false);
            dateView.setPadding(0, dp(5), 0, 0);
            card.addView(dateView);
            LinearLayout.LayoutParams params = lp(-1, -2);
            params.bottomMargin = dp(8);
            body.addView(card, params);
        }
    }

    private String fmt(String s){try{return String.format(Locale.US,"%,.0f",Double.parseDouble(s));}catch(Exception e){return s;}}
    private double parse(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
    private String money(double v){return String.format(Locale.US,"%,.2f دج",v);}

    private EditText input(String hint,int type) {
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(14);e.setTextColor(text);e.setHintTextColor(Color.rgb(145,160,174));
        e.setPadding(dp(13),dp(10),dp(13),dp(10));e.setBackground(shape(Color.rgb(246,249,252),13,line,1));e.setInputType(type);
        LinearLayout.LayoutParams p=lp(-1,50);p.bottomMargin=dp(9);body.addView(e,p);return e;
    }
    private EditText number(String hint){return input(hint,InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);}
    private void formHeader(String title,String description){body.addView(label(title,20,text,true));TextView d=label(description,11,secondary,false);d.setPadding(0,dp(4),0,dp(12));body.addView(d);}
    private Button button(String title) {
        Button b=new Button(this);b.setText(title);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTextSize(14);b.setBackground(gradient(blue,cyan,16));b.setElevation(dp(2));
        LinearLayout.LayoutParams p=lp(-1,52);p.topMargin=dp(5);p.bottomMargin=dp(9);body.addView(b,p);
        return b;
    }
    private void button(String title,Runnable action) {
        Button b=button(title);
        b.setOnClickListener(v->{v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);action.run();});
    }
    private void openProduction() {
        show("تسجيل دفعة إنتاج");formHeader("دفعة إنتاج جديدة","سجّل الكمية والمسؤول واستهلاك المادة لهذه الدفعة.");
        EditText product=input("نوع الصندوق (CP9 / CP14 / Sipora...)",InputType.TYPE_CLASS_TEXT);
        EditText qty=number("عدد القطع المنتجة");
        EditText machine=input("الآلة أو خط الإنتاج",InputType.TYPE_CLASS_TEXT);
        EditText worker=input("العامل أو المسؤول",InputType.TYPE_CLASS_TEXT);
        EditText material=input("اسم المادة المستهلكة (اختياري)",InputType.TYPE_CLASS_TEXT);
        EditText used=number("كمية المادة المستهلكة");
        EditText notes=input("ملاحظات",InputType.TYPE_CLASS_TEXT);
        TextView calc=label("إجمالي المادة المستهلكة: 0",12,blue,true);body.addView(calc);
        used.addTextChangedListener(watch(()->calc.setText("إجمالي المادة المستهلكة: "+used.getText()+" (حسب الوحدة المدخلة في المخزون)")));
        button("حفظ دفعة الإنتاج",()->{
            if(product.getText().length()==0||parse(qty.getText().toString())<=0){toast("أدخل نوع الصندوق وعدداً صحيحاً أكبر من صفر");return;}
            try {db.addProduction(product.getText().toString(),parse(qty.getText().toString()),machine.getText().toString(),worker.getText().toString(),material.getText().toString(),parse(used.getText().toString()),notes.getText().toString());toast("تم حفظ دفعة الإنتاج وتحديث المخزون إن تم تحديد المادة");show("الإنتاج");}
            catch(Exception ex){toast(ex.getMessage());}
        });
    }
    private void openStock() {
        show("إضافة مادة");formHeader("مادة أولية جديدة","أدخل الرصيد الحالي وحد التنبيه وسعر الشراء.");
        EditText name=input("اسم المادة",InputType.TYPE_CLASS_TEXT),unit=input("الوحدة (كغ، غ، قطعة...)",InputType.TYPE_CLASS_TEXT);
        EditText qty=number("الكمية الحالية"),min=number("حد التنبيه"),price=number("سعر الوحدة بالدج");
        button("حفظ المادة",()->{if(name.getText().length()==0||unit.getText().length()==0){toast("أدخل اسم المادة ووحدتها");return;}try{db.addStock(name.getText().toString(),unit.getText().toString(),parse(qty.getText().toString()),parse(min.getText().toString()),parse(price.getText().toString()));toast("تم حفظ المادة");show("المخزون");}catch(Exception e){toast(e.getMessage());}});
    }
    private void openFinishedStock() {
        show("إضافة رصيد منتج نهائي");formHeader("رصيد افتتاحي للمنتج","أدخل كمية المنتجات الموجودة فعلياً في المخزن.");
        EditText product=input("اسم المنتج (CP9 / CP14 / Sipora 14 / Sipora 20)",InputType.TYPE_CLASS_TEXT);
        EditText qty=number("الكمية الموجودة");
        button("إضافة الرصيد",()->{if(product.getText().length()==0||parse(qty.getText().toString())<=0){toast("أدخل اسم المنتج والكمية");return;}try{db.addFinishedStock(product.getText().toString(),parse(qty.getText().toString()));toast("تم تحديث رصيد المنتج");show("المخزون");}catch(Exception e){toast(e.getMessage());}});
    }
    private void openSale() {
        show("عملية بيع");formHeader("عملية بيع جديدة","تُحسب القيمة والضريبة والمتبقي فور تغيير الأرقام.");
        EditText customer=input("اسم العميل",InputType.TYPE_CLASS_TEXT),product=input("نوع الصندوق",InputType.TYPE_CLASS_TEXT);
        EditText qty=number("الكمية"),price=number("سعر القطعة بالدج"),discount=number("الخصم بالدج"),tax=number("الضريبة ٪ (اختياري)"),paid=number("المبلغ المدفوع بالدج");
        TextView result=label("الإجمالي: 0 دج\nالمتبقي: 0 دج",15,blue,true);result.setPadding(dp(12),dp(12),dp(12),dp(12));result.setBackground(shape(Color.rgb(235,246,253),16,0,0));body.addView(result);
        Runnable update=()->{double net=Math.max(0,parse(qty.getText().toString())*parse(price.getText().toString())-parse(discount.getText().toString()));double total=net*(1+parse(tax.getText().toString())/100);result.setText("الإجمالي: "+money(total)+"\nالمتبقي: "+money(Math.max(0,total-parse(paid.getText().toString()))));};
        for(EditText e:new EditText[]{qty,price,discount,tax,paid})e.addTextChangedListener(watch(update));
        button("حفظ عملية البيع",()->{if(customer.getText().length()==0||product.getText().length()==0||parse(qty.getText().toString())<=0){toast("أدخل العميل والمنتج والكمية");return;}try{db.addSale(customer.getText().toString(),product.getText().toString(),parse(qty.getText().toString()),parse(price.getText().toString()),parse(discount.getText().toString()),parse(tax.getText().toString()),parse(paid.getText().toString()));toast("تم تسجيل البيع");show("المبيعات");}catch(Exception ex){toast(ex.getMessage());}});
    }
    private void openExpense() {
        show("إضافة مصروف");formHeader("تسجيل مصروف","سجّل المصاريف والمشتريات والمدفوعات.");
        EditText cat=input("التصنيف (كهرباء، نقل، صيانة...)",InputType.TYPE_CLASS_TEXT),amount=number("المبلغ بالدج"),party=input("الطرف المعني",InputType.TYPE_CLASS_TEXT),method=input("طريقة الدفع",InputType.TYPE_CLASS_TEXT),notes=input("ملاحظات",InputType.TYPE_CLASS_TEXT);
        button("حفظ المصروف",()->{if(cat.getText().length()==0||parse(amount.getText().toString())<=0){toast("أدخل التصنيف والمبلغ");return;}try{db.addExpense(cat.getText().toString(),parse(amount.getText().toString()),party.getText().toString(),method.getText().toString(),notes.getText().toString());toast("تم حفظ المصروف");show("المصاريف");}catch(Exception e){toast(e.getMessage());}});
    }
    private void openNote() {
        show("ملاحظة جديدة");formHeader("إضافة ملاحظة","يمكن ربطها لاحقاً بعميل أو دفعة إنتاج أو فاتورة.");
        EditText note=input("اكتب الملاحظة...",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        button("حفظ الملاحظة",()->{if(note.getText().length()==0){toast("اكتب نص الملاحظة");return;}db.addNote(note.getText().toString(),"عام");toast("تم حفظ الملاحظة");show("الملاحظات");});
    }
    private void openProduct() {
        show("إضافة منتج");formHeader("تعريف منتج","يمكن تعديل الاسم والأبعاد والوزن والسعر.");
        EditText name=input("اسم المنتج",InputType.TYPE_CLASS_TEXT),dims=input("الأبعاد (مم)",InputType.TYPE_CLASS_TEXT),weight=number("وزن القطعة بالغرام (اختياري)"),price=number("سعر البيع بالدج");
        button("حفظ المنتج",()->{if(name.getText().length()==0){toast("أدخل اسم المنتج");return;}Double w=weight.getText().length()==0?null:parse(weight.getText().toString());db.addProduct(name.getText().toString(),dims.getText().toString(),w,parse(price.getText().toString()));toast("تم حفظ المنتج");show("المنتجات");});
    }
    private TextWatcher watch(Runnable r){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){r.run();}public void afterTextChanged(Editable e){}};}
    private void invoicePreview(String[] row) {
        double qty=parse(row[4]),unit=parse(row[5]),discount=parse(row[6]),tax=parse(row[7]),paid=parse(row[8]);double net=Math.max(0,qty*unit-discount),total=net*(1+tax/100);
        new AlertDialog.Builder(this).setTitle("تفاصيل عملية البيع").setMessage("العميل: "+row[2]+"\nالمنتج: "+row[3]+"\nالكمية: "+fmt(row[4])+"\nسعر الوحدة: "+money(unit)+"\nالخصم: "+money(discount)+"\nالضريبة: "+fmt(row[7])+"%\nالإجمالي: "+money(total)+"\nالمدفوع: "+money(paid)+"\nالمتبقي: "+money(total-paid)).setPositiveButton("حسناً",null).show();
    }
    private void exportCsv() {
        String csv="القسم,الإجمالي\\nالإنتاج,"+db.sum("production","quantity")+"\\nالمبيعات,"+
                db.sum("sales","MAX(0,quantity*unit_price-discount)*(1+tax_rate/100)")+"\\nالمصاريف,"+
                db.sum("expenses","amount")+"\\nالمقبوضات,"+db.sum("sales","paid")+"\\n";
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE,"KHALDI_PLAST_Report.csv");
        pendingCsv=csv;
        try { startActivityForResult(intent,410); }
        catch(Exception e) { toast("تعذر فتح نافذة حفظ الملف"); }
    }
    private String pendingCsv="";
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        if(requestCode==410) {
            try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if(out==null)throw new java.io.IOException("تعذر فتح الملف");
                out.write(pendingCsv.getBytes("UTF-8"));out.flush();toast("تم تصدير التقرير بنجاح");
            } catch(Exception e){toast("تعذر حفظ التقرير: "+e.getMessage());}
        } else if(requestCode==411) {
            try(java.io.InputStream in=new java.io.FileInputStream(getDatabasePath("khaldi_factory.db"));
                java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if(out==null)throw new java.io.IOException("تعذر فتح ملف النسخ");
                byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))>0)out.write(buffer,0,n);out.flush();toast("تم إنشاء النسخة الاحتياطية");
            } catch(Exception e){toast("تعذر إنشاء النسخة: "+e.getMessage());}
        } else if(requestCode==412) {
            try(java.io.InputStream in=getContentResolver().openInputStream(data.getData())) {
                if(in==null)throw new java.io.IOException("تعذر قراءة الملف");
                db.close();java.io.File target=getDatabasePath("khaldi_factory.db");
                java.io.File parent=target.getParentFile();if(parent!=null)parent.mkdirs();
                try(java.io.OutputStream out=new java.io.FileOutputStream(target,false)){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))>0)out.write(buffer,0,n);out.flush();}
                db=new DatabaseHelper(this);db.getReadableDatabase();toast("تمت استعادة النسخة الاحتياطية");show("الرئيسية");
            } catch(Exception e){db=new DatabaseHelper(this);toast("تعذرت الاستعادة: "+e.getMessage());}
        }
    }
    private void backupDatabase() {
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");intent.putExtra(Intent.EXTRA_TITLE,"KHALDI_PLAST_Backup.db");
        try{startActivityForResult(intent,411);}catch(Exception e){toast("تعذر فتح نافذة النسخ الاحتياطي");}
    }
    private void confirmRestore() {
        new AlertDialog.Builder(this).setTitle("استعادة نسخة احتياطية")
                .setMessage("سيتم استبدال قاعدة البيانات الحالية بالنسخة المختارة. يُنصح بإنشاء نسخة احتياطية أولاً.")
                .setNegativeButton("إلغاء",null).setPositiveButton("اختيار ملف",(d,w)->{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
                    try{startActivityForResult(i,412);}catch(Exception e){toast("تعذر فتح مستعرض الملفات");}
                }).show();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
