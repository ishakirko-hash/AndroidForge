# KHALDI PLAST — إدارة المصنع

مشروع Android أصلي بلغة Java، بواجهة عربية RTL وقاعدة بيانات SQLite محلية.

## إصلاحات نسخة AndroidForge

- إضافة الدالة `addSimpleRows()` التي كانت مستدعاة في لوحة التحكم وغير معرّفة، وهي سبب خطأ `cannot find symbol` في البناء السابق.
- إضافة نسخة `button(String)` التي كانت مطلوبة في شاشة التقارير.
- منع إضافة زر تصدير CSV مرتين إلى نفس الحاوية.
- تصحيح صيغة رابط Gradle Wrapper.

## البناء

- افتح مجلد المشروع الذي يحتوي على `settings.gradle`.
- يستخدم المشروع Android Gradle Plugin 8.6.1 وGradle 8.7 وJava 17.
- `compileSdk` هو 35 و`minSdk` هو 23.
- عند استخدام AndroidForge، ارفع ملف ZIP كما هو واختر `debug` أو `auto`.

## ملاحظات

يحتوي المشروع على مصدر Java وملفات الموارد والشعار. يلزم تنفيذ بناء فعلي على Android SDK/Gradle للتحقق النهائي من توافق البيئة وإنتاج APK.
