// v2.4: reference-style widgets, action shortcuts, flexible edit sheet (name/colour/size/move/hide), undo, home texts
const L=require('./lib.js'); let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
(async()=>{ const s=await L.start(process.argv[2],390); const p=s.page; await p.waitForTimeout(600);
 const W10=['tgtw','dayperf','machst','rawtot','prodrank','ordstat','sales30','alertsw','qualw','bestcust'];
 await p.evaluate((W10)=>{const U=window.KPU,K=U.K; U.commit(d=>{const td=K.today(),pr=d.products; K.addMachine(d,{name:'M1'}); const c=K.addCustomer(d,{name:'Zed',phone:'0550'});
  K.recordProduction(d,{date:td,shift:1,productId:pr[0].id,good:500,defective:10}); K.recordSale(d,{date:td,customerId:c.id,items:[{productId:pr[0].id,qty:5,unitPrice:30000,weightG:0}],paid:0,method:'cash'});
  d.settings.monthlyTarget=1000;
  d.settings.layout={hidden:['sales'],order:[],icons:{},secOrder:[],secHidden:['today','quick','perf','lines','kpis','alerts','chart','products','shortcuts','recent'],hv:2,v:1,v2:1,v22:1,v24:1,shown:W10.slice(),wOrder:W10.concat(['sc:a_sale','sc:a_prod','sc:a_exp','sc:a_purch','sc:a_cust','sc:a_note','sc:materials','sc:orders']),sizes:{},colors:{},titles:{}};}); U.render(); },W10);
 await p.waitForTimeout(400);
 const keys=()=>p.evaluate(()=>[].map.call(document.querySelectorAll('.wgrid .wd'),e=>e.dataset.k));
 let ks=await keys(); ok(W10.every(k=>ks.includes(k)),'all 10 new widgets render');
 ok((await p.locator('.w2').count())===10,'10 .w2 cards');
 ok((await p.locator('.wd[data-k="tgtw"]').innerText()).includes('50%'),'target widget = real 500/1000 = 50%');
 ok((await p.locator('.wd[data-k="qualw"]').innerText()).includes('98'),'quality widget = real 500/510');
 ok((await p.locator('.wd[data-k="ordstat"] .dn2').count())===1,'orders donut');
 ok(['a_sale','a_prod','a_exp','a_purch','a_cust','a_note','materials','orders'].every(i=>ks.includes('sc:'+i)),'8 new shortcuts present');
 // action shortcut opens the real form
 await p.evaluate(()=>window.KPU.extraActions.sc({dataset:{id:'a_sale'}})); await p.waitForTimeout(300); ok(await p.locator('#modal *').count()>0,'sale shortcut opens the sale form'); await p.evaluate(()=>window.KPU.closeModal());
 await p.evaluate(()=>window.KPU.extraActions.sc({dataset:{id:'orders'}})); await p.waitForTimeout(300); ok((await p.evaluate(()=>window.KPU.route))==='notes','orders shortcut → notes');
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.render();}); await p.waitForTimeout(200);
 // edit mode
 await p.evaluate(()=>window.KPU.extraActions.wd_edit()); await p.waitForTimeout(300);
 ok(await p.locator('.wd-dock').count()===1,'bottom dock in edit mode');
 await p.evaluate(()=>window.KPU.extraActions.wd_cfg({dataset:{k:'tgtw'}})); await p.waitForTimeout(250);
 ok(await p.locator('#cfg_t').count()===1,'tap opens edit sheet');
 await p.fill('#cfg_t','هدف الشهر'); await p.click('[data-act="wd_cfg_save"]'); await p.waitForTimeout(400);
 ok((await p.locator('.wd[data-k="tgtw"] h3').innerText()).trim()==='هدف الشهر','custom name applied');
 await p.evaluate(()=>window.KPU.extraActions.wd_color({dataset:{k:'tgtw',c:'#34A853'}})); await p.waitForTimeout(300);
 ok(await p.locator('.wd.acc[data-k="tgtw"]').count()===1,'accent colour applied');
 await p.evaluate(()=>window.KPU.extraActions.wd_move({dataset:{k:'tgtw',d:'bottom'}})); await p.waitForTimeout(300); ks=await keys(); const vis=ks; ok(vis[vis.length-1]==='tgtw','move to last');
 await p.evaluate(()=>window.KPU.extraActions.wd_move({dataset:{k:'tgtw',d:'top'}})); await p.waitForTimeout(300); ks=await keys(); ok(ks[0]==='tgtw','move to first');
 await p.evaluate(()=>window.KPU.extraActions.wd_undo()); await p.waitForTimeout(300); ks=await keys(); ok(ks[ks.length-1]==='tgtw','undo restores the previous order');
 await p.evaluate(()=>window.KPU.extraActions.wd_hide({dataset:{k:'sc:a_note'}})); await p.waitForTimeout(300); ok(!(await keys()).includes('sc:a_note'),'hide shortcut');
 await p.evaluate(()=>window.KPU.extraActions.home_cfg()); await p.fill('#hc_t','أهلاً'); await p.uncheck('#hc_q'); await p.click('[data-act="home_cfg_save"]'); await p.waitForTimeout(300);
 ok((await p.locator('.hwel').innerText()).trim()==='أهلاً' && (await p.locator('.hsearch').count())===0,'home title edited + search hidden');
 await p.evaluate(()=>window.KPU.extraActions.wd_done()); await p.waitForTimeout(300);
 const lay=await p.evaluate(()=>JSON.stringify(window.KPU.D.settings.layout)); ok(lay.includes('هدف الشهر')&&lay.includes('أهلاً'),'saved in settings');
 ok(s.errors.length===0,'no JS errors '+JSON.stringify(s.errors)); console.log('pass',pass,'fail',fail); await s.close(); })();
