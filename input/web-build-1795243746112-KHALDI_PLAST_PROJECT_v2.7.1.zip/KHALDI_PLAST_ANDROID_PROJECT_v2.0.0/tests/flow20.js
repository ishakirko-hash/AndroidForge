// v2.6: distribution monitor
const L=require('./lib.js'); let pass=0,fail=0; const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
(async()=>{ const s=await L.start(process.argv[2],390); const p=s.page; await p.waitForTimeout(600);
 const go=async(r)=>{await p.evaluate((r)=>{const U=window.KPU;U.stack=[];U.route=r;U.arg=null;U.render();},r||'distribution');await p.waitForTimeout(300)};
 const A=(n,d)=>p.evaluate(([n,d])=>window.KPU.extraActions[n]({dataset:d||{}}),[n,d]);
 const sub=async()=>{await p.click('#f button[type=submit]');await p.waitForTimeout(300)};
 await go(); ok((await p.locator('[data-act="ds_truck"]').count())>=1,'empty state: add truck');
 await A('ds_truck'); await p.fill('#f_no','شاحنة 01'); await p.fill('#f_plate','DZ-3145-KP'); await p.fill('#f_driver','عمار'); await p.fill('#f_phone','0550000000'); await sub();
 await A('ds_truck'); await p.fill('#f_no','شاحنة 02'); await p.selectOption('#f_state','maint'); await sub();
 ok(await p.locator('.ds-tr').count()===2,'2 trucks listed'); ok((await p.locator('.ds-sum').innerText()).includes('1'),'summary counts');
 const tid=await p.evaluate(()=>window.KPU.D.settings.dist.trucks[0].id);
 await A('ds_pick',{id:tid}); await A('ds_trip_new',{id:tid}); await p.fill('#f_dest','مؤسسة النور'); await p.fill('#f_km','120'); await p.fill('#f_q0','50');
 await p.selectOption('#f_l0',{index:1}); await p.fill('#f_fuel','1500'); await sub();
 ok(await p.locator('.ds-ct').count()===1,'trip card for truck');
 ok((await p.locator('.ds-ct').innerText()).includes('مؤسسة النور'),'destination shown');
 const trid=await p.evaluate(()=>window.KPU.D.settings.dist.trips[0].id);
 await A('ds_start',{id:trid}); await p.waitForTimeout(300); ok((await p.locator('.ds-sum .ds-sc.b b').innerText()).trim()==='1','truck on route counted');
 await A('ds_prog',{id:trid,p:'75'}); await p.waitForTimeout(250); ok((await p.locator('.ds-tr .ds-pb').innerText()).includes('75'),'progress 75% in list');
 await A('ds_finish',{id:trid}); await p.waitForTimeout(300);
 ok((await p.locator('.ds-eff').innerText()).includes('100'),'efficiency 100%'); ok((await p.locator('.ds-km').first().innerText()).includes('120'),'km today 120');
 // raw materials trip
 await A('ds_trip_new',{id:tid}); await p.selectOption('#f_type','in'); await p.fill('#f_dest','مورد المواد'); await p.selectOption('#f_l0','__new__'); await p.fill('input[name=l0_new]','حبيبات PP'); await p.fill('#f_q0','2000'); await sub();
 await A('ds_trip',{id:await p.evaluate(()=>window.KPU.D.settings.dist.trips[1].id)}); await p.waitForTimeout(200);
 ok((await p.locator('#sheet').innerText()).includes('حبيبات PP'),'raw-material trip detail'); await p.evaluate(()=>window.KPU.closeModal());
 // maintenance truck cannot start
 const t2=await p.evaluate(()=>window.KPU.D.settings.dist.trucks[1].id); await A('ds_trip_new',{id:t2}); await p.fill('#f_dest','X'); await sub();
 const id3=await p.evaluate(()=>window.KPU.D.settings.dist.trips[2].id); await A('ds_start',{id:id3}); ok((await p.evaluate((i)=>window.KPU.D.settings.dist.trips[2].status,id3))==='plan','maintenance truck cannot start');
 await A('ds_late',{id:id3}); ok((await p.evaluate(()=>window.KPU.D.settings.dist.trips[2].status))==='late','postpone');
 await p.reload(); await p.waitForTimeout(900); ok((await p.evaluate(()=>window.KPU.D.settings.dist.trips.length))===3,'persists after reload');
 await go('more'); ok(await p.locator('[data-id="distribution"]').count()>=1,'tile in More');
 await p.evaluate(()=>window.KPU.extraActions.sc({dataset:{id:'distribution'}})); await p.waitForTimeout(300); ok((await p.evaluate(()=>window.KPU.route))==='distribution','tile opens page');
 await p.setViewportSize({width:390,height:2100}); await p.evaluate(()=>{const U=window.KPU,d=U.D.settings.dist;U.commit(x=>{x.settings.dist.trips[1].status='go';x.settings.dist.trips[1].prog=60;});U.render(true);}); await p.waitForTimeout(400); await p.screenshot({path:'/tmp/ds_shot.png'});
 ok(s.errors.length===0,'no JS errors '+JSON.stringify(s.errors)); console.log('pass',pass,'fail',fail); await s.close(); })();
