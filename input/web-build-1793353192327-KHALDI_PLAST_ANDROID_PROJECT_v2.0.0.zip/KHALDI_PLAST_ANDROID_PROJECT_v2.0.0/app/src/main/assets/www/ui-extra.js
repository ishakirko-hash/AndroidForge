/* KHALDI PLAST - v0.7 screens: glass home/sales/stock/production, production-by-days table, shifts overview, workers,
   customers, suppliers, order notes, offline assistant, customisation. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, F = U.forms, S = U.S, X = U.extraActions = {};
  var PAL = ['#00B0F0', '#0077C8', '#1F2D49', '#34A853', '#F59E2C', '#7B4FD0', '#E5493A', '#12907F'];
  S.workTab = S.workTab || 'today'; S.salesP = S.salesP || 'month'; S.salesF = S.salesF || 'all'; S.stockF = S.stockF || 'all'; S.ptAll = S.ptAll || '0';
  S.custF = 'all'; S.suppF = 'all'; S.noteF = 'all'; S.noteSort = 'added'; S.chat = [];
  function B(n) { return '<bdi class="num">' + n + '</bdi>'; }
  function kpi(cls, icon, label, val, note, delta, inv, act) {
    var dl = delta == null ? '' : '<span class="dl ' + ((inv ? delta <= 0 : delta >= 0) ? 'up' : 'dn') + '">' + (delta >= 0 ? '▲' : '▼') + ' <bdi class="num" dir="ltr">' + Math.abs(delta) + '%</bdi></span>';
    return '<div class="kpi bg-' + cls + (act ? ' tap' : '') + '"' + (act ? ' data-act="kpi_go" data-id="' + act + '" role="button"' : '') + '><div class="kt"><span class="ki">' + V.icon(icon, 22) + '</span><span class="kl">' + esc(label) + '</span></div><div class="kv2">' + val + '</div><div class="kn">' + dl + (note ? '<span>' + note + '</span>' : '') + '</div><i class="sp">' + V.icon(act ? (U.lang() === 'ar' ? 'chevL' : 'chevR') : 'bars', 16) + '</i></div>';
  }
  function linkPanel(h, act) { return h.replace('<div class="panel">', '<div class="panel tap" data-act="kpi_go" data-id="' + act + '">'); }
  function pct(cur, prev) { if (cur == null || prev == null || prev === 0) return null; return Math.round((cur - prev) * 1000 / Math.abs(prev)) / 10; }
  function panel(icon, title, body, link) { return '<div class="panel"><div class="ph2"><span class="pi2">' + V.icon(icon, 19) + '</span><h3>' + esc(title) + '</h3>' + (link || '') + '</div>' + body + '</div>'; }
  function lnk(act, id, label) { return '<button class="lnk" data-act="' + act + '"' + (id ? ' data-id="' + id + '"' : '') + '>' + esc(label) + '</button>'; }
  function pcs(n) { return B(K.groupInt(n)) + ' <small>' + t('pcs') + '</small>'; }
  function csv(name, rows) { U.saveFile(name, 'text/csv', '﻿' + rows.map(function (r) { return r.map(U.csvEscape).join(','); }).join('\r\n')); }
  function printNow(name) { if (U.AND && U.AND.printPage) U.AND.printPage(name); else window.print(); }
  function money0(c) { return K.fmtMoney(c); }
  function legend(parts) { return '<div class="legend">' + parts.map(function (p) { return '<div class="li"><span class="sw" style="background:' + p.color + '"></span><span class="nm">' + esc(p.name) + '</span><b>' + p.val + '</b></div>'; }).join('') + '</div>'; }
  function noData() { return '<div class="muted" style="text-align:center;padding:14px 0">' + t('no_records') + '</div>'; }

  /* ================= customisation (layout) ================= */
  var CAT = ['production', 'purchases', 'sales', 'expenses', 'debts', 'stock', 'invoices', 'reports', 'workers', 'customers', 'suppliers', 'notes', 'prodtable', 'assistant', 'transactions', 'shifts', 'payroll', 'profit', 'scan', 'backup', 'settings', 'customize', 'quotes', 'collect', 'dailyclose', 'cashbook', 'forecast', 'stocktake', 'maintenance', 'insights'];
  var NEWCAT = ['quotes', 'collect', 'dailyclose', 'cashbook', 'forecast', 'stocktake', 'maintenance', 'insights'];
  var DEF_HOME = ['sales', 'invoices', 'production', 'prodtable', 'stock', 'purchases', 'expenses', 'debts', 'customers', 'suppliers', 'workers', 'assistant'];
  var LBL = { production: 'tile_production', purchases: 'tile_purchases', sales: 'tile_sales', expenses: 'tile_expenses', debts: 'tile_debts', stock: 'tile_stock', invoices: 'tile_invoices', reports: 'tile_reports', workers: 'tile_workers',
    customers: 'tile_customers', suppliers: 'tile_suppliers', notes: 'v_notes', prodtable: 'tile_prodtable', assistant: 'tile_assistant', transactions: 'v_transactions', shifts: 'tile_shifts', payroll: 'tile_payroll', profit: 'tile_profit', scan: 'tile_scan', backup: 'v_backup', settings: 'v_settings', customize: 'tile_customize', quotes: 'tile_quotes', collect: 'tile_collect', dailyclose: 'tile_dailyclose', cashbook: 'tile_cashbook', forecast: 'tile_forecast', stocktake: 'tile_stocktake', maintenance: 'tile_maintenance', insights: 'tile_insights' };
  var SEC = ['kpis', 'alerts', 'chart', 'products', 'shortcuts', 'recent'], NEWSEC = ['today', 'quick', 'perf', 'lines'];
  var SECL = { qadd: 'quick_add', debts: 'sec_debts', collected: 'sec_collected', expenses: 'month_expenses', profit: 'sec_profit', orders: 'tile_orders', lowstock: 'sec_lowstock', rawstock: 'sec_rawstock', workers: 'sec_workers', shiftnow: 'sec_shiftnow', topdebt: 'sec_topdebt', topprod: 'sec_topprod', backup: 'sec_backup', insightsw: 'tile_insights', ageing: 'tile_collect', today: 'sec_today', quick: 'sec_quick', perf: 'sec_perf', lines: 'sec_lines', kpis: 'sec_kpis', alerts: 'sec_alerts', chart: 'sec_chart', products: 'sec_products', shortcuts: 'sec_shortcuts', recent: 'sec_recent' };
  function L() { var l = U.D.settings.layout || {}; return { shown: l.shown || [], v: l.v, hv: l.hv, order: l.order || [], hidden: l.hidden || [], icons: l.icons || {}, secOrder: l.secOrder || [], secHidden: l.secHidden || [], wOrder: l.wOrder || [], sizes: l.sizes || {} }; }
  function order(list, saved) { var o = []; saved.forEach(function (x) { if (list.indexOf(x) >= 0 && o.indexOf(x) < 0) o.push(x); }); list.forEach(function (x) { if (o.indexOf(x) < 0) o.push(x); }); return o; }
  function scOrdered() { return order(CAT, L().order); }
  function scHidden(id) { var l = L(); return l.hv ? l.hidden.indexOf(id) >= 0 : true; }
  // layouts saved before v2.0 do not know the new tiles: hide them once (they stay available in More and in the gallery)
  U.migrateLayout = function () {
    var l = U.D && U.D.settings.layout; if (!l || !l.hv || l.v2) return;
    try { U.commit(function (d) { var ly = d.settings.layout; NEWCAT.forEach(function (id) { if (ly.hidden.indexOf(id) < 0) ly.hidden.push(id); }); ly.v2 = 1; }); } catch (e) {}
  };
  function secOrdered() { return order(SEC, L().secOrder); }
  function secHidden(id) { var l = L(); if (!l.hv) return NEWSEC.indexOf(id) < 0; if (EXTRAW.indexOf(id) >= 0) return l.shown.indexOf(id) < 0; return l.secHidden.indexOf(id) >= 0; }
  function iconOf(id) { var ic = L().icons[id], names = V.tileNames(); return names.indexOf(ic) >= 0 ? ic : id; }
  /* widget model: every home element (a section or a shortcut) is one widget with a key, a size and a place in one ordered list */
  var EXTRAW = ['qadd', 'debts', 'collected', 'expenses', 'profit', 'orders', 'lowstock', 'rawstock', 'workers', 'shiftnow', 'topdebt', 'topprod', 'backup', 'insightsw', 'ageing'], SECW = NEWSEC.concat(['kpis', 'alerts', 'chart', 'products', 'recent'], EXTRAW), SIZES = ['s', 'm', 'l'];
  var ALLW = SECW.concat(CAT.map(function (id) { return 'sc:' + id; }));
  function wDefault() { if (!L().hv) return NEWSEC.slice(); var r = []; secOrdered().forEach(function (id) { if (id === 'shortcuts') scOrdered().forEach(function (c) { if (!scHidden(c)) r.push('sc:' + c); }); else r.push(id); }); return r; }
  function wOrdered() { var s = L().hv ? L().wOrder : []; return order(ALLW, s.length ? s : wDefault()); }
  function wHidden(k) { if (!L().hv) return NEWSEC.indexOf(k) < 0; return k.indexOf('sc:') === 0 ? scHidden(k.slice(3)) : secHidden(k); }
  function wSize(k) { var z = L().sizes[k]; return SIZES.indexOf(z) >= 0 ? z : (k.indexOf('sc:') === 0 ? 's' : (WSZ[k] || 'm')); }
  function wLabel(k) { return k.indexOf('sc:') === 0 ? t(LBL[k.slice(3)]) : t(SECL[k]); }
  function persistLayout(fn) {
    var wo = wOrdered(), sz = Object.assign({}, L().sizes), fresh = !L().hv, o = scOrdered(), so = secOrdered(), hid = fresh ? CAT.slice() : CAT.filter(scHidden), sh = fresh ? SECW.filter(function (k) { return NEWSEC.indexOf(k) < 0; }) : L().secHidden.slice();
    U.commit(function (d) {
      var l = d.settings.layout = Object.assign({ hidden: [], order: [], icons: {}, secOrder: [], secHidden: [] }, d.settings.layout);
      if (fresh || !l.hv) { l.order = o; l.hidden = hid; l.secOrder = so; l.secHidden = sh; l.wOrder = wo; l.sizes = fresh ? {} : sz; l.v = 1; l.hv = 2; }
      if (!l.icons) l.icons = {}; if (!l.secOrder.length) l.secOrder = so; if (!l.secHidden) l.secHidden = [];
      if (!l.wOrder || !l.wOrder.length) l.wOrder = wo; if (!l.sizes) l.sizes = sz;
      fn(l);
    });
  }
  function saveLayout(fn) { persistLayout(fn); if (U.flipRender && U.route === 'home') U.flipRender(function () { U.render(true); }); else U.render(true); }
  function move(arr, id, dir) { var i = arr.indexOf(id), j = i + dir; if (i < 0 || j < 0 || j >= arr.length) return; var x = arr[i]; arr[i] = arr[j]; arr[j] = x; }
  function toggle(arr, id) { var i = arr.indexOf(id); if (i >= 0) arr.splice(i, 1); else arr.push(id); }
  function openSC(id) {
    if (id === 'scan') { U.scan(); return; }
    if (id === 'sales' || id === 'stock' || id === 'production') { U.stack = []; U.route = id; U.arg = null; U.render(); U.$('#main').scrollTop = 0; return; }
    if (id === 'shifts') { S.workTab = 'today'; id = 'workers'; } else if (id === 'workers') S.workTab = 'list';
    U.go(id);
  }
  function tileBtn(id) { var ic = iconOf(id), c = V.tileColor(ic); return '<button class="tilebtn" data-act="sc" data-id="' + id + '"><span class="tic" style="background:linear-gradient(135deg,' + c + '33,' + c + '14)">' + V.tile(ic, 34) + '</span><span>' + esc(t(LBL[id])) + '</span></button>'; }
  X.sc = function (el) { openSC(el.dataset.id); };
  // home cards -> the screen that explains the number (always on the current month)
  X.kpi_go = function (el) {
    var id = el.dataset.id; S.ym = K.today().slice(0, 7);
    if (id === 'salesmonth') { S.salesP = 'month'; S.salesF = 'all'; openSC('sales'); }
    else if (id === 'prodmonth') { S.ptAll = '0'; U.go('prodtable'); }
    else if (id === 'stock') openSC('stock');
    else if (id === 'expmonth') U.go('expenses');
    else if (id === 'reports') { S.repTab = 'month'; U.go('reports'); }
    else if (id === 'salestoday') { S.salesP = 'today'; S.salesF = 'all'; openSC('sales'); }
    else if (id === 'prodtoday') openSC('production');
  };

  /* ================= theme (light / dark / follow device) ================= */
  U.theme = function () { var m = (U.D && U.D.settings.theme) || 'light'; if (m === 'auto') { try { return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; } catch (e) { return 'light'; } } return m === 'dark' ? 'dark' : 'light'; };
  U.applyTheme = function () { var th = U.theme(); document.documentElement.setAttribute('data-theme', th); var mc = document.querySelector('meta[name=color-scheme]'); if (mc) mc.setAttribute('content', th); };
  try { var mq = window.matchMedia('(prefers-color-scheme: dark)'), onq = function () { if (U.D && U.D.settings.theme === 'auto') { U.applyTheme(); U.render(true); } }; if (mq.addEventListener) mq.addEventListener('change', onq); else if (mq.addListener) mq.addListener(onq); } catch (e) { }
  X.setheme = function (el) { var v = el.dataset.id; U.commit(function (d) { d.settings.theme = (v === 'dark' || v === 'auto') ? v : 'light'; }); U.render(true); };
  X.theme_toggle = function () { var next = U.theme() === 'dark' ? 'light' : 'dark'; U.commit(function (d) { d.settings.theme = next; }); U.render(true); };

  /* ================= home ================= */
  function todayByProduct() {
    var D = U.D, day = K.today(), m = {};
    K.live(D.production).filter(function (r) { return r.date === day; }).forEach(function (r) { m[r.productId] = (m[r.productId] || 0) + r.good; });
    return U.act(D.products).map(function (p) { return { p: p, q: m[p.id] || 0 }; });
  }
  function stat(id, d) {
    var D = U.D, ym = K.today().slice(0, 7), cur = function () { return K.monthlyReport(D, ym); };
    if (id === 'sales') return U.money(cur().sales);
    if (id === 'expenses') return U.money(cur().expenses);
    if (id === 'production') return pcs(cur().good);
    if (id === 'stock') return pcs(d.finishedStock);
    if (id === 'customers') return B(U.act(D.customers).length);
    if (id === 'suppliers') return B(U.act(D.suppliers).length);
    if (id === 'workers') return B(U.act(D.workers).filter(function (w) { return (w.status || 'active') === 'active'; }).length);
    if (id === 'notes') return B(K.live(D.notes).length);
    return '';
  }
  /* ---- v1.2 home (reference design): today cards, quick access, trend + target, production lines ---- */
  function dzdBig(c) { var v = c / 100; return v >= 1e6 ? [B((Math.round(v / 1e5) / 10).toFixed(1)), t('million_dzd')] : [B(K.groupInt(Math.round(v))), t('dzd')]; }
  function deltaHtml(kind, v) {
    if (v == null) return '';
    var up = v >= 0, txt = kind === 'pct' ? (up ? '+' : '−') + Math.abs(v) + '%' : (up ? '+' : '−') + Math.abs(v);
    return '<span class="tdl ' + (up ? 'up' : 'dn') + '"><b>' + (kind === 'abs' ? V.icon(up ? 'up' : 'down', 15) : '') + '<bdi class="num" dir="ltr">' + txt + '</bdi></b><em>' + t('vs_yesterday') + '</em></span>';
  }
  function todayCard(cls, icon, label, big, unit, dl, act) {
    return '<div class="tk ' + cls + ' tap" data-act="kpi_go" data-id="' + act + '" role="button"><span class="tki">' + icon + '</span><span class="tkl">' + esc(label) + '</span><div class="tkv">' + big + '</div><div class="tkf"><span class="tku">' + unit + '</span>' + (dl || '') + '</div></div>';
  }
  function todayStats() {
    var D = U.D, day = K.today(), yd = K.addDays(day, -1), lv = K.live;
    function sl(dd) { return lv(D.sales).filter(function (x) { return x.date === dd; }); }
    function pr(dd) { return K.sum(lv(D.production).filter(function (x) { return x.date === dd; }), function (x) { return x.good; }); }
    var s1 = sl(day), s0 = sl(yd), py = pr(yd);
    return { sales: K.sum(s1, function (x) { return x.total; }), salesY: K.sum(s0, function (x) { return x.total; }), prod: pr(day), prodY: py, orders: s1.length, ordersY: s0.length };
  }
  function monthTarget() { var n = Number(U.D.settings.monthlyTarget); return n > 0 ? Math.floor(n) : 0; }
  function curShift() { var h = new Date().getHours(); return h >= 8 && h < 16 ? 1 : h >= 16 ? 2 : 3; }
  function lineStatus(m) {
    var D = U.D, day = K.today(), cs = curShift(), cov = 0, now = 0;
    [1, 2, 3].forEach(function (n) { var r = K.rosterFor(D, day, n).filter(function (a) { return a.machineId === m.id && a.worked; }); if (r.length) cov++; if (n === cs) now = r.length; });
    return { cov: cov, now: now };
  }
  function trendSvg(vals, labs, z) {
    var W_ = 230, H_ = z === 'l' ? 200 : 170, pl = 8, pr = 12, pt = 36, pb = 24, n = vals.length, mx = Math.max.apply(null, vals.concat([1])), cw = W_ - pl - pr, ch = H_ - pt - pb;
    var pts = vals.map(function (v, i) { return [pl + (n > 1 ? i * cw / (n - 1) : cw / 2), pt + ch - v / mx * ch]; });
    var line = pts.map(function (p, i) { return (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' '), area = line + ' L' + pts[n - 1][0].toFixed(1) + ' ' + (pt + ch) + ' L' + pts[0][0].toFixed(1) + ' ' + (pt + ch) + ' Z';
    var id = 'tg' + Math.random().toString(36).slice(2, 6), last = pts[n - 1], bx = Math.max(2, Math.min(W_ - 62, last[0] - 31));
    var g = [0, 1, 2].map(function (i) { var y = pt + ch * i / 2; return '<line class="tgrid" x1="' + pl + '" x2="' + (W_ - pr) + '" y1="' + y + '" y2="' + y + '"/>'; }).join('');
    var dots = pts.map(function (p) { return '<circle class="tdot" cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="3.6"/>'; }).join('');
    var xl = pts.map(function (p, i) { return '<text class="tlab" x="' + p[0].toFixed(1) + '" y="' + (H_ - 5) + '" text-anchor="middle">' + labs[i] + '</text>'; }).join('');
    return '<svg class="trend" viewBox="0 0 ' + W_ + ' ' + H_ + '" role="img"><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="ts1"/><stop offset="1" class="ts2"/></linearGradient></defs>' + g +
      '<path d="' + area + '" fill="url(#' + id + ')"/><path class="tline" d="' + line + '"/>' + dots +
      '<g><rect class="tbub" x="' + bx + '" y="2" width="60" height="26" rx="8"/><path class="tbub" d="M' + (last[0] - 5) + ' 27 L' + last[0] + ' 33 L' + (last[0] + 5) + ' 27z"/><text class="tbt" x="' + (bx + 30) + '" y="14" text-anchor="middle">' + K.groupInt(vals[n - 1]) + '</text><text class="tbs" x="' + (bx + 30) + '" y="24" text-anchor="middle">' + esc(t('crate')) + '</text></g>' + xl + '</svg>';
  }
  function ringSvg(p) {
    var r = 38, c = 2 * Math.PI * r, f = Math.max(0, Math.min(1, p / 100)) * c;
    return '<svg class="ring" viewBox="0 0 100 100"><circle class="rbg" cx="50" cy="50" r="' + r + '"/><circle class="rfg" cx="50" cy="50" r="' + r + '" stroke-dasharray="' + f.toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 50 50)"/></svg>';
  }
  var QK = [['materials', 'tile_materials'], ['stock', 'tile_stock'], ['production', 'tile_production'], ['sales', 'tile_sales'], ['more', 'v_more'], ['reports', 'tile_reports'], ['workers', 'q_workers'], ['orders', 'tile_orders']];
  X.qk = function (el) {
    var id = el.dataset.id; S.ym = K.today().slice(0, 7);
    if (id === 'materials') { S.stockTab = 'raw'; openSC('stock'); }
    else if (id === 'stock') { S.stockTab = 'finished'; openSC('stock'); }
    else if (id === 'production' || id === 'sales') openSC(id);
    else if (id === 'more') { U.stack = []; U.route = 'more'; U.arg = null; U.render(); U.$('#main').scrollTop = 0; }
    else if (id === 'reports') { S.repTab = 'month'; U.go('reports'); }
    else if (id === 'workers') openSC('shifts');
    else if (id === 'orders') { S.noteF = 'pending'; U.go('notes'); }
  };
  X.set_target = function () {
    var cur = monthTarget();
    U.showModal('<h3>' + t('set_target') + '</h3><div class="muted" style="margin-bottom:8px">' + t('target_help') + '</div><input id="tgtin" type="number" inputmode="numeric" min="0" step="1" dir="ltr" placeholder="' + esc(t('target_ph')) + '" value="' + (cur || '') + '" style="width:100%">' +
      '<div class="btns"><button class="btn ghost" data-act="close">' + t('cancel') + '</button><button class="btn primary" data-act="save_target">' + t('save') + '</button></div>');
  };
  X.save_target = function () {
    var el = document.getElementById('tgtin'), n = el ? Math.floor(Number(el.value)) : 0; if (!isFinite(n) || n < 0 || n > 1e9) n = 0;
    U.commit(function (d) { if (n > 0) d.settings.monthlyTarget = n; else delete d.settings.monthlyTarget; }); U.closeModal(); U.render(true);
  };
  function searchResults(q) {
    var D = U.D, k = q.trim().toLowerCase();
    if (!k) return '';
    function sec(title, rows) { return rows.length ? '<div class="sr-h">' + esc(title) + '</div>' + rows.join('') : ''; }
    function row(icon, main, sub, act, attrs) { return '<div class="row tap sr-row" data-act="' + act + '" ' + attrs + '><div class="ibox">' + V.icon(icon, 18) + '</div><div class="main"><div class="t">' + esc(main) + '</div>' + (sub ? '<div class="s">' + sub + '</div>' : '') + '</div></div>'; }
    var inv = U.newest(D.sales).filter(function (x) { return (U.invNo(x.no) + ' ' + U.invFull(x) + ' ' + U.custName(x.customerId) + ' ' + K.fmtDate(x.date)).toLowerCase().indexOf(k) >= 0; }).slice(0, 4).map(function (x) { return row('note', U.invFull(x), esc(U.custName(x.customerId)) + ' · ' + U.moneyTxt(x.total), 'tx', 'data-kind="sale" data-id="' + x.id + '"'); });
    var cus = U.act(D.customers).filter(function (c) { return (c.name + ' ' + (c.phone || '')).toLowerCase().indexOf(k) >= 0; }).slice(0, 4).map(function (c) { return row('user', c.name, c.phone ? '<bdi class="num">' + esc(c.phone) + '</bdi>' : '', 'party', 'data-kind="customer" data-id="' + c.id + '"'); });
    var prd = U.act(D.products).filter(function (p) { return (p.name + ' ' + (p.code || '')).toLowerCase().indexOf(k) >= 0; }).slice(0, 4).map(function (p) { return row('box', p.name, t('available_qty') + ': ' + B(K.groupInt(p.stock)), 'sc', 'data-id="stock"'); });
    var ord = D.notes.filter(function (x) { return x.isOrder && ((x.customerName || '') + ' ' + (x.title || '') + ' ' + (x.productId ? U.prodName(x.productId) : '')).toLowerCase().indexOf(k) >= 0; }).slice(0, 4).map(function (x) { return row('list', x.customerName || x.title || U.prodName(x.productId), x.productId ? esc(U.prodName(x.productId)) + ' × ' + B(x.qty) : '', 'edit_note', 'data-id="' + x.id + '"'); });
    var out = sec(t('res_invoices'), inv) + sec(t('res_customers'), cus) + sec(t('res_products'), prd) + sec(t('res_orders'), ord);
    return '<div class="panel sr">' + (out || noData()) + '</div>';
  }
  /* ---- v1.3 widget library: small, real-data cards ---- */
  var WSZ = { debts: 's', collected: 's', expenses: 's', profit: 's', rawstock: 's', lowstock: 's', workers: 's', shiftnow: 's', backup: 's', topdebt: 'm', topprod: 'm', orders: 'm', qadd: 'm', insightsw: 'm', ageing: 's' };
  var WICON = { today: 'calendar', quick: 'menu', perf: 'bars', lines: 'factory', kpis: 'wallet', alerts: 'alert', chart: 'bars', products: 'box', recent: 'list', debts: 'wallet', collected: 'download', expenses: 'wallet', profit: 'bars', rawstock: 'scale', lowstock: 'alert', orders: 'note', workers: 'users', shiftnow: 'clock', topdebt: 'user', topprod: 'tag', backup: 'save', qadd: 'plus', insightsw: 'bulb', ageing: 'wallet' };
  function sw(cls, icon, label, big, sub, act) {
    return '<div class="sw ' + cls + (act ? ' tap' : '') + '"' + (act ? ' data-act="wgo" data-id="' + act + '" role="button"' : '') + '><div class="swt"><span class="swi">' + V.icon(icon, 20) + '</span><span class="swl">' + esc(label) + '</span></div><div class="swv">' + big + '</div>' + (sub ? '<div class="sws">' + sub + '</div>' : '') + '</div>';
  }
  function swList(cls, icon, label, rows, act, empty) {
    return '<div class="sw swl-list ' + cls + '"><div class="swt"' + (act ? ' data-act="wgo" data-id="' + act + '"' : '') + '><span class="swi">' + V.icon(icon, 20) + '</span><span class="swl">' + esc(label) + '</span>' + (act ? '<i class="swc">' + V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 16) + '</i>' : '') + '</div>' + (rows.length ? rows.join('') : '<div class="swe">' + empty + '</div>') + '</div>';
  }
  X.wgo = function (el) {
    var id = el.dataset.id; S.ym = K.today().slice(0, 7);
    if (id === 'debts') U.go('debts'); else if (id === 'sales' || id === 'stock') openSC(id);
    else if (id === 'expenses') U.go('expenses'); else if (id === 'reports') { S.repTab = 'month'; U.go('reports'); }
    else if (id === 'workers') openSC('shifts'); else if (id === 'backup') U.go('backup'); else if (id === 'collect' || id === 'insights') U.go(id);
    else if (id === 'orders') { S.noteF = 'pending'; U.go('notes'); } else if (id === 'rawstock') { S.stockTab = 'raw'; openSC('stock'); }
  };
  function lowItems() { var D = U.D; return D.products.concat(D.materials).filter(function (x) { return !x.archived && x.minStock > 0 && x.stock <= x.minStock; }); }
  function workedToday() { var D = U.D, day = K.today(), ids = {}; [1, 2, 3].forEach(function (n) { K.rosterFor(D, day, n).forEach(function (a) { if (a.worked) ids[a.workerId] = 1; }); }); return Object.keys(ids).length; }
  function monthTopProducts() { var D = U.D, r = K.monthRange(K.today().slice(0, 7)), m = {}; K.live(D.sales).filter(function (s) { return s.date >= r.from && s.date <= r.to; }).forEach(function (s) { s.items.forEach(function (i) { m[i.productId] = (m[i.productId] || 0) + i.qty; }); }); return Object.keys(m).map(function (k) { return { p: K.byId(D.products, k), q: m[k] }; }).filter(function (x) { return x.p; }).sort(function (a, b) { return b.q - a.q; }); }
  var HOME = {
    debts: function (d, z) {
      var c = sw('wr', 'wallet', t('w_debts_c'), U.money(d.customerDebt), z === 's' ? '' : t('w_debts_hint'), 'debts');
      if (z === 's') return c;
      return '<div class="swgrid">' + c + sw('wa', 'truck', t('w_debts_s'), U.money(d.supplierDebt), '', 'debts') + '</div>';
    },
    collected: function (d, z) { return sw('wg', 'download', t('sec_collected'), U.money(d.todayCollected), z === 's' ? '' : t('today_sales') + ': ' + U.moneyTxt(d.todaySales), 'sales'); },
    expenses: function (d, z) {
      var ym = K.today().slice(0, 7), cur = K.monthlyReport(U.D, ym), prev = K.monthlyReport(U.D, K.addMonths(ym, -1)), p = pct(cur.expenses, prev.expenses);
      return sw('wr', 'wallet', t('month_expenses'), U.money(cur.expenses), p == null ? '' : '<span class="dl ' + (p <= 0 ? 'up' : 'dn') + '">' + (p >= 0 ? '▲' : '▼') + ' <bdi class="num" dir="ltr">' + Math.abs(p) + '%</bdi></span>', 'expenses');
    },
    profit: function (d, z) {
      var p = d.monthProfit;
      return sw(p == null || p >= 0 ? 'wg' : 'wr', 'bars', t('sec_profit'), p == null ? '<bdi class="num">—</bdi>' : U.money(p), p == null ? t('profit_unavailable') : t('estimate'), 'reports');
    },
    rawstock: function (d, z) {
      var ms = U.act(U.D.materials), low = ms.filter(function (x) { return x.minStock > 0 && x.stock <= x.minStock; }).length;
      if (z === 's') return sw(low ? 'wr' : 'wa', 'scale', t('sec_rawstock'), B(K.fmtQty(d.rawStock)) + ' <small>' + t('kg') + '</small>', low ? t('low_stock') + ': ' + B(low) : '', 'rawstock');
      return swList('wa', 'scale', t('sec_rawstock'), ms.slice(0, z === 'l' ? 8 : 4).map(function (x) { var lw = x.minStock > 0 && x.stock <= x.minStock; return '<div class="swr"><span>' + esc(x.name) + '</span><b class="' + (lw ? 'dn' : '') + '">' + B(K.fmtQty(x.stock)) + ' <small>' + t('kg') + '</small></b></div>'; }), 'rawstock', t('no_records'));
    },
    lowstock: function (d, z) {
      var l = lowItems();
      if (z === 's') return sw(l.length ? 'wr' : 'wg', 'alert', t('sec_lowstock'), B(l.length), l.length ? esc(l[0].name) : t('w_none_low'), 'stock');
      return swList(l.length ? 'wr' : 'wg', 'alert', t('sec_lowstock'), l.slice(0, z === 'l' ? 8 : 4).map(function (x) { return '<div class="swr"><span>' + esc(x.name) + '</span><b class="dn">' + B(K.fmtQty(x.stock)) + '</b></div>'; }), 'stock', t('w_none_low'));
    },
    orders: function (d, z) {
      var td = K.today(), o = pendingOrders().slice(0, z === 's' ? 2 : z === 'l' ? 8 : 4);
      return swList('wb', 'note', t('tile_orders'), o.map(function (n) {
        var late = n.expectedDate && n.expectedDate < td;
        return '<div class="swr tap" data-act="edit_note" data-id="' + n.id + '"><span>' + esc(n.customerName || n.title || U.prodName(n.productId)) + '<small>' + esc(U.prodName(n.productId)) + ' × ' + B(n.qty) + '</small></span><b class="' + (late ? 'dn' : '') + '">' + (n.expectedDate ? U.dt(n.expectedDate) : '') + (late ? ' · ' + t('w_late') : '') + '</b></div>';
      }), 'orders', t('w_no_orders'));
    },
    workers: function (d, z) {
      var n = workedToday(), all = U.act(U.D.workers).filter(function (w) { return (w.status || 'active') === 'active'; }).length;
      return sw('wb', 'users', t('sec_workers'), B(n), t('w_of') + ' ' + B(all) + ' ' + t('sec_workers_unit'), 'workers');
    },
    shiftnow: function (d, z) {
      var n = curShift(), sh = K.SHIFTS[n - 1], cnt = K.rosterFor(U.D, K.today(), n).filter(function (a) { return a.worked; }).length;
      return sw('wb', 'clock', t('sec_shiftnow'), t('shift') + ' <bdi class="num">' + n + '</bdi>', '<bdi class="num" dir="ltr">' + sh.start + ' - ' + sh.end + '</bdi> · ' + B(cnt) + ' ' + t('ln_workers'), 'workers');
    },
    topdebt: function (d, z) {
      var D = U.D, l = D.customers.map(function (c) { return { c: c, b: K.customerBalance(D, c.id) }; }).filter(function (x) { return x.b > 0; }).sort(function (a, b) { return b.b - a.b; }).slice(0, z === 's' ? 2 : z === 'l' ? 8 : 4);
      return swList('wr', 'user', t('sec_topdebt'), l.map(function (x) { return '<div class="swr tap" data-act="party" data-kind="customer" data-id="' + x.c.id + '"><span>' + esc(x.c.name) + '</span><b class="dn">' + U.moneyTxt(x.b) + '</b></div>'; }), 'debts', t('w_none_debt'));
    },
    topprod: function (d, z) {
      var l = monthTopProducts().slice(0, z === 's' ? 2 : z === 'l' ? 8 : 4), mx = l.length ? l[0].q : 1;
      return swList('wp', 'tag', t('sec_topprod'), l.map(function (x) { return '<div class="swr"><span>' + esc(x.p.name) + '<i class="swbar"><u style="width:' + Math.round(x.q * 100 / mx) + '%"></u></i></span><b>' + B(K.groupInt(x.q)) + '</b></div>'; }), 'sales', t('no_records'));
    },
    insightsw: function (d, z) {
      var l = (K.insights ? K.insights(U.D, K.today()) : []).slice(0, z === 's' ? 1 : z === 'l' ? 6 : 3);
      return swList('wp', 'bulb', t('tile_insights'), l.map(function (x) { return '<div class="swr ins-' + x.tone + '"><span>' + esc(U.insightText(x)) + '</span></div>'; }), 'insights', t('ins_none'));
    },
    ageing: function (d, z) {
      var a = K.ageingReport ? K.ageingReport(U.D, K.today()) : { overdue: 0, total: 0 };
      return sw(a.overdue > 0 ? 'wr' : 'wg', 'wallet', t('tile_collect'), U.money(a.overdue), t('col_overdue_hint'), 'collect');
    },
    backup: function (d, z) {
      var lb = U.D.settings.lastBackup, days = lb ? Math.floor((Date.now() - new Date(lb).getTime()) / 86400000) : null, old = days == null || days > 7;
      return sw(old ? 'wa' : 'wg', 'save', t('sec_backup'), days == null ? t('w_backup_never') : days === 0 ? t('w_today') : B(days) + ' <small>' + t('w_days_ago') + '</small>', lb ? K.fmtDate(lb.slice(0, 10)) : t('backup_never'), 'backup');
    },
    qadd: function (d, z) {
      var b = [['new_sale', 'note', 'new_sale'], ['new_production', 'machine', 'new_production'], ['new_expense', 'wallet', 'new_expense'], ['new_purchase', 'truck', 'new_purchase']];
      return '<div class="sw wb"><div class="swt"><span class="swi">' + V.icon('plus', 20) + '</span><span class="swl">' + t('quick_add') + '</span></div><div class="qaddg' + (z === 's' ? ' two' : '') + '">' + b.slice(0, z === 's' ? 2 : 4).map(function (x) { return '<button class="qab" data-act="' + x[0] + '">' + V.icon(x[1], 20) + '<span>' + esc(t(x[2])) + '</span></button>'; }).join('') + '</div></div>';
    },
    today: function (d, z) {
      var st = todayStats(), hasY = st.salesY > 0 || st.prodY > 0 || st.ordersY > 0, sp = dzdBig(st.sales);
      function nd(x) { return z === 's' ? null : x; }
      var dS = hasY ? pct(st.sales, st.salesY) : null, dP = hasY ? pct(st.prod, st.prodY) : null, dO = st.ordersY > 0 ? st.orders - st.ordersY : null;
      return '<div class="tks">' +
        todayCard('tk-sales', V.qtile('coins', 30), t('k_sales_today'), sp[0], sp[1], deltaHtml('pct', nd(dS)), 'salestoday') +
        todayCard('tk-prod', V.qtile('production', 30), t('k_prod_today'), B(K.groupInt(st.prod)), esc(t('crate')), deltaHtml('pct', nd(dP)), 'prodtoday') +
        todayCard('tk-ord', V.qtile('clip', 30), t('k_orders_today'), B(st.orders), '', deltaHtml('abs', nd(dO)), 'salestoday') + '</div>';
    },
    quick: function (d, z) {
      var list = z === 's' ? QK.slice(0, 4) : QK;
      return '<div class="qsec"><div class="qh"><h3>' + t('quick_access') + '</h3><button class="lnk" data-act="qk" data-id="more">' + t('show_all') + '</button></div><div class="qgrid' + (z === 'l' ? ' ql' : '') + '">' + list.map(function (q) {
        return '<button class="qt" data-act="qk" data-id="' + q[0] + '"><span class="qi" style="background:' + V.qtileBg(q[0]) + '">' + V.qtile(q[0], z === 'l' ? 46 : 38) + '</span><span class="ql2">' + esc(t(q[1])) + '</span></button>';
      }).join('') + '</div></div>';
    },
    perf: function (d, z) {
      var D = U.D, td = K.today(), vals = [], labs = [], i;
      for (i = 6; i >= 0; i--) { var dd = K.addDays(td, -i); labs.push(dd.slice(8)); vals.push(K.sum(K.live(D.production).filter(function (x) { return x.date === dd; }), function (x) { return x.good; })); }
      var tgt = monthTarget(), good = K.monthlyReport(D, td.slice(0, 7)).good, p = tgt ? Math.round(good * 100 / tgt) : 0;
      var trend = '<div class="pf pf-trend tap" data-act="kpi_go" data-id="prodmonth"><div class="pfh"><span class="pfi">' + V.icon('bars', 22) + '</span><h3>' + t('prod_trend') + '</h3></div>' + trendSvg(vals, labs, z) + '</div>';
      if (z === 's') return '<div class="perf one">' + trend + '</div>';
      var tg = '<div class="pf pf-target"><h3>' + t('target_progress') + '</h3><div class="ringw">' + ringSvg(tgt ? p : 0) + '<b class="rc">' + (tgt ? '<bdi class="num" dir="ltr">' + p + '%</bdi>' : '—') + '</b></div>' +
        (tgt ? '<div class="rleg"><div><i class="rd a"></i><span>' + t('produced_lbl') + ': <bdi class="num" dir="ltr">' + K.groupInt(good) + '</bdi></span></div><div><i class="rd b"></i><span>' + t('target_lbl') + ': <bdi class="num" dir="ltr">' + K.groupInt(tgt) + '</bdi></span></div></div><button class="lnk" data-act="set_target">' + t('edit_target') + '</button>' : '<button class="btn primary sm" data-act="set_target">' + t('set_target') + '</button>') + '</div>';
      return '<div class="perf' + (z === 'l' ? ' tall' : '') + '">' + tg + trend + '</div>';
    },
    lines: function (d, z) {
      var ms = U.act(U.D.machines), cap = z === 's' ? 2 : z === 'l' ? 12 : 4;
      var body = ms.length ? ms.slice(0, cap).map(function (m) {
        var s = lineStatus(m), pc = Math.round(s.cov * 100 / 3), st = s.now ? ['ok', t('ln_running')] : ['wait', t('ln_nobody')];
        return '<div class="ln tap" data-act="sc" data-id="shifts"><img class="lnimg" src="img/machine_line.jpg" alt=""><div class="lnm"><b>' + esc(m.name) + '</b><span class="lns ' + st[0] + '"><i></i>' + esc(st[1]) + (s.now ? ' · <bdi class="num">' + s.now + '</bdi> ' + t('ln_workers') : '') + '</span></div><div class="lnb"><span class="' + (s.cov === 3 ? 'full' : s.cov ? 'part' : '') + '" style="width:' + pc + '%"></span></div><div class="lnc"><b><bdi class="num" dir="ltr">' + s.cov + ' / 3</bdi></b><small>' + t('ln_shifts_today') + '</small></div><span class="lnch">' + V.icon('chevR', 18) + '</span></div>';
      }).join('') : '<div class="muted" style="padding:10px;text-align:center">' + t('ln_none') + '</div>';
      return '<div class="lnsec"><div class="qh"><h3><span class="pfi">' + V.icon('factory', 20) + '</span>' + t('lines_title') + '</h3><button class="lnk" data-act="sc" data-id="shifts">' + t('show_all') + '</button></div>' + body + '</div>';
    },
    kpis: function (d, z) {
      var D = U.D, ym = K.today().slice(0, 7), cur = K.monthlyReport(D, ym), prev = K.monthlyReport(D, K.addMonths(ym, -1)), c = K.compareMonths(cur, prev);
      var a = kpi('green', 'wallet', t('month_sales'), U.money(cur.sales), '', c.sales, false, 'salesmonth'), b = kpi('blue', 'machine', t('month_production'), pcs(cur.good), '', c.good, false, 'prodmonth');
      if (z === 's') return '<div class="kpis kpis1">' + a + b + '</div>';
      return '<div class="kpis">' + a + b + kpi('amber', 'box', t('finished_stock'), pcs(d.finishedStock), t('raw_stock') + ': ' + B(K.fmtQty(d.rawStock)) + ' ' + t('kg'), null, false, 'stock') + kpi('red', 'wallet', t('month_expenses'), U.money(cur.expenses), '', c.expenses, true, 'expmonth') + '</div>';
    },
    alerts: function (d, z) {
      var a = U.alerts(); if (!a.length) return '';
      return panel('alert', t('alerts'), a.slice(0, z === 's' ? 2 : z === 'l' ? 8 : 5).map(function (x) { return '<div class="row"><div class="ibox ' + x.cls + '">' + V.icon(x.icon, 20) + '</div><div class="main"><div class="t" style="font-weight:600">' + esc(x.text) + '</div></div></div>'; }).join(''));
    },
    chart: function (d, z) {
      var ser = K.monthSeries(U.D, K.today().slice(0, 7), z === 's' ? 4 : 6);
      return linkPanel(panel('bars', t('monthly_sales'), V.area([{ values: ser.map(function (x) { return x.sales / 100; }), color: '#0077C8' }], ser.map(function (x) { return U.monthLabel(x.ym).split(' ')[0]; }), z === 's' ? 100 : z === 'l' ? 240 : 160), z === 's' ? '' : '<span class="badge">' + t('sales_6m') + '</span>'), 'reports');
    },
    products: function (d, z) {
      var l = todayByProduct(); if (!l.length) return '';
      var tot = K.sum(l, function (x) { return x.q; });
      return '<div class="pcards' + (z === 's' ? ' pc1' : '') + '">' + l.slice(0, z === 's' ? 3 : 6).map(function (x) {
        var pc = tot ? Math.round(x.q * 100 / tot) : 0;
        return '<div class="pcard tap" data-act="kpi_go" data-id="prodmonth"><div class="pbody"><div class="pn">' + esc(x.p.name) + '</div><div class="pu">' + t('today_production') + '</div><div class="pq">' + B(K.groupInt(x.q)) + ' <small class="pu">' + t('pcs') + '</small></div></div><div><div class="thumb" style="width:54px;height:40px">' + V.crate(x.p.color, 50) + '</div></div><span class="pring" style="background:conic-gradient(#0077C8 ' + pc + '%,rgba(11,26,46,.1) 0)"><b>' + pc + '%</b></span></div>';
      }).join('') + '</div>';
    },
    recent: function (d, z) {
      var r = K.feed(U.D).slice(0, z === 's' ? 3 : z === 'l' ? 10 : 5);
      return panel('list', t('recent_tx'), r.length ? r.map(function (f) { return U.txRow(f); }).join('') : noData(), lnk('goto', 'transactions', t('show_all')));
    }
  };
  function scWidget(id, z, d) {
    var ic = iconOf(id), c = V.tileColor(ic), st = z === 's' ? '' : stat(id, d);
    return '<button class="tilebtn wsc z-' + z + '" data-act="sc" data-id="' + id + '"><span class="tic" style="background:linear-gradient(135deg,' + c + '33,' + c + '14)">' + V.tile(ic, z === 'l' ? 52 : 34) + '</span><span class="wl">' + esc(t(LBL[id])) + '</span>' + (st ? '<span class="wv">' + st + '</span>' : '') + '</button>';
  }
  function editOverlay(k, z) {
    return '<div class="wd-ed"><button class="wd-x" data-act="wd_hide" data-k="' + k + '" aria-label="' + t('hide') + '">' + V.icon('x', 16) + '</button><span class="wd-drag" data-drag="1" aria-label="' + t('drag_hint') + '">' + V.icon('move', 18) + '</span>' +
      '<div class="wd-sz">' + SIZES.map(function (s) { return '<button class="' + (s === z ? 'on' : '') + '" data-act="wd_size" data-k="' + k + '" data-s="' + s + '">' + t('size_' + s) + '</button>'; }).join('') + '</div><span class="wd-rs" data-rs="1" aria-label="' + t('resize') + '">' + V.icon('resize', 16) + '</span></div>';
  }
  function widget(k, d) {
    var z = wSize(k), sc = k.indexOf('sc:') === 0, inner = sc ? scWidget(k.slice(3), z, d) : HOME[k](d, z);
    if (!inner) { if (!S.homeEdit) return ''; inner = '<div class="panel wempty">' + esc(wLabel(k)) + '<br><small>' + t('widget_empty') + '</small></div>'; }
    return '<div class="wd ' + (sc ? 'w-sc' : 'w-sec') + ' sz-' + z + '" data-k="' + k + '"><div class="wd-in">' + inner + '</div>' + (S.homeEdit ? editOverlay(k, z) : '') + '</div>';
  }
  function hero(ed) {
    var day = K.today(), hasAl = U.alerts().length > 0, q = S.homeQ || '';
    return '<section class="hhero"><div class="hero-ph" style="background-image:url(img/hero_home.jpg)"></div><div class="hero-in">' +
      '<div class="hrow"><img class="hlogo" src="img/logo_full.png" alt="KHALDI PLAST"><div class="hacts"><button class="hbell" data-act="bell" aria-label="' + esc(t('alerts')) + '">' + V.icon('bell', 24) + (hasAl ? '<span class="hdot"></span>' : '') + '</button><button class="havatar" data-act="sc" data-id="settings" aria-label="' + esc(t('v_settings')) + '">' + V.icon('user', 26) + '</button></div></div>' +
      '<h1 class="hwel">' + t('home_welcome') + '</h1><p class="hsub">' + t('home_sub') + '</p>' +
      '<div class="hdate"><span>' + V.icon('calendar', 18) + '<bdi>' + esc(U.longDate(day)) + '</bdi></span>' + (ed ? '' : '<button class="hchip" data-act="quick">' + t('new_btn') + '</button><button class="hedit" data-act="theme_toggle" aria-label="' + t('theme') + '">' + V.icon(U.theme() === 'dark' ? 'sun' : 'moon', 18) + '</button><button class="hedit" data-act="wd_edit" aria-label="' + t('edit_home') + '">' + V.icon('sliders', 18) + '</button>') + '</div></div>' +
      '<div class="hsearch"><span class="hs-i">' + V.icon('search', 22) + '</span><input type="search" id="homeq" data-bind="homeQ" value="' + esc(q) + '" placeholder="' + esc(t('search_home')) + '" autocomplete="off"><button class="hs-s" data-act="scan_qr" aria-label="' + esc(t('tile_scan')) + '">' + V.icon('scan', 24) + '</button></div></section>';
  }
  W.home = function () {
    var D = U.D, d = K.dashboard(D, K.today()), h = '', ed = !!S.homeEdit;
    if (U.loadWarning) h += '<div class="alert red">' + t('warn_' + U.loadWarning) + '</div>';
    if (U.migratedNow) h += '<div class="alert blue">' + t('migrated_note') + '</div>';
    h += hero(ed) + searchResults(S.homeQ || '');
    if (ed) h += '<div class="wd-bar"><div class="wd-help">' + t('edit_home_help') + '</div><div class="wd-btns"><button class="btn" data-act="wd_add">' + V.icon('plus', 18) + ' ' + t('add_widget') + '</button><button class="btn ghost" data-act="cz_reset">' + V.icon('undo', 18) + ' ' + t('reset') + '</button><button class="btn" data-act="wd_done">' + V.icon('check', 18) + ' ' + t('done') + '</button></div></div>';
    var w = wOrdered().filter(function (k) { return !wHidden(k); }).map(function (k) { return widget(k, d); }).join('');
    h += '<div class="wgrid' + (ed ? ' editing' : '') + '">' + w + '</div>';
    if (!w) h += '<div class="card muted">' + t('no_shortcuts') + '</div>';
    return h;
  };
  /* edit-mode actions */
  X.wd_edit = function () { S.homeEdit = true; U.render(true); };
  X.wd_done = function () { S.homeEdit = false; U.render(true); };
  X.wd_hide = function (el) { var k = el.dataset.k; saveLayout(function (l) { if (k.indexOf('sc:') === 0) { if (l.hidden.indexOf(k.slice(3)) < 0) l.hidden.push(k.slice(3)); } else { if (l.secHidden.indexOf(k) < 0) l.secHidden.push(k); l.shown = (l.shown || []).filter(function (x) { return x !== k; }); } }); };
  X.wd_size = function (el) { var k = el.dataset.k, z = el.dataset.s; S.popKey = k; saveLayout(function (l) { l.sizes[k] = z; }); };
  X.wd_add = function () {
    var hid = wOrdered().filter(wHidden), sec = hid.filter(function (k) { return k.indexOf('sc:') !== 0; }), scs = hid.filter(function (k) { return k.indexOf('sc:') === 0; });
    function row(k) {
      var ic = k.indexOf('sc:') === 0 ? V.tile(iconOf(k.slice(3)), 30) : V.icon(WICON[k] || 'box', 26);
      return '<button class="cz-row" data-act="wd_show" data-k="' + k + '"><span class="tl">' + ic + '</span><span class="nm">' + esc(wLabel(k)) + '</span><span class="mb">' + V.icon('plus', 20) + '</span></button>';
    }
    var body = hid.length ? (sec.length ? '<div class="gal-h">' + t('gal_smart') + '</div><div class="addlist">' + sec.map(row).join('') + '</div>' : '') + (scs.length ? '<div class="gal-h">' + t('gal_shortcuts') + '</div><div class="addlist">' + scs.map(row).join('') + '</div>' : '') : '<div class="muted" style="padding:14px 0;text-align:center">' + t('all_shown') + '</div>';
    U.showModal('<h3>' + t('add_widget') + '</h3>' + body + '<div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
  };
  X.wd_show = function (el) {
    var k = el.dataset.k; U.closeModal();
    saveLayout(function (l) { if (k.indexOf('sc:') === 0) { var i = l.hidden.indexOf(k.slice(3)); if (i >= 0) l.hidden.splice(i, 1); } else { var j = l.secHidden.indexOf(k); if (j >= 0) l.secHidden.splice(j, 1); if (EXTRAW.indexOf(k) >= 0) { l.shown = l.shown || []; if (l.shown.indexOf(k) < 0) l.shown.push(k); } } var o = l.wOrder.indexOf(k); if (o >= 0) { l.wOrder.splice(o, 1); l.wOrder.unshift(k); } });
    setTimeout(function () { var n = document.querySelector('.wgrid .wd[data-k="' + k + '"]'); if (n && n.scrollIntoView) try { n.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) { } }, 60);
  };
  /* drag to move / drag the corner to resize (pointer events: works with finger and mouse) */
  /* ---- v1.3 drag / resize engine: live reorder with FLIP animation (others glide out of the way), edge auto-scroll, snap-back ---- */
  var drag = null, EASE = 'cubic-bezier(.2,.8,.2,1)';
  function wdEls() { return [].slice.call(document.querySelectorAll('.wgrid .wd')); }
  function rectsOf(els) { var m = new Map(); els.forEach(function (e) { m.set(e, e.getBoundingClientRect()); }); return m; }
  function glide(e, dx, dy, ms) {
    e.style.transition = 'none'; e.style.transform = 'translate(' + dx + 'px,' + dy + 'px)'; void e.offsetWidth;
    e.style.transition = 'transform ' + (ms || 260) + 'ms ' + EASE; e.style.transform = '';
    var fin = function () { e.style.transition = ''; e.removeEventListener('transitionend', fin); }; e.addEventListener('transitionend', fin);
  }
  function flipFrom(before, skip) {
    wdEls().forEach(function (e) { if (e === skip) return; var a = before.get(e); if (!a) return; var b = e.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top; if (Math.abs(dx) > .5 || Math.abs(dy) > .5) glide(e, dx, dy); });
  }
  // re-render with the same glide (used by hide / size / add / reset)
  U.flipRender = function (fn) {
    var before = {}; wdEls().forEach(function (e) { before[e.dataset.k] = e.getBoundingClientRect(); });
    fn();
    wdEls().forEach(function (e) {
      var a = before[e.dataset.k];
      if (!a) { e.classList.add('wd-new'); return; }
      var b = e.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
      if (e.dataset.k === S.popKey) { e.classList.add('wd-pop'); }
      else if (Math.abs(dx) > .5 || Math.abs(dy) > .5) glide(e, dx, dy);
    });
    S.popKey = null;
  };
  function buzz(ms) { if (navigator.vibrate) try { navigator.vibrate(ms); } catch (_) { } }
  function beginDrag(w, x, y, mode, pid, handle) {
    var r = w.getBoundingClientRect();
    drag = { mode: mode, el: w, k: w.dataset.k, cx: x, cy: y, x: x, y: y, gx: x - r.left, gy: y - r.top, moved: false, z: wSize(w.dataset.k), swapAt: 0 }; drag.steps = SIZES.indexOf(drag.z);
    if (mode === 'mv') { w.classList.add('dragging'); document.querySelector('.wgrid').classList.add('is-dragging'); buzz(12); drag.raf = requestAnimationFrame(tick); }
    try { (handle || w).setPointerCapture(pid); } catch (_) { }
  }
  function place() {
    var el = drag.el; el.style.transition = 'none'; el.style.transform = 'none'; var r = el.getBoundingClientRect();
    el.style.transform = 'translate(' + (drag.cx - drag.gx - r.left) + 'px,' + (drag.cy - drag.gy - r.top) + 'px) scale(1.045)';
  }
  // layout rectangle of a widget ignoring any running glide transform (stable hit-testing while others animate)
  function natRect(e) { var op = e.offsetParent || document.body, o = op.getBoundingClientRect(), l = o.left + op.clientLeft + e.offsetLeft - op.scrollLeft, t = o.top + op.clientTop + e.offsetTop - op.scrollTop; return { left: l, top: t, right: l + e.offsetWidth, bottom: t + e.offsetHeight }; }
  function reorder(force) {
    if (!force && Date.now() - drag.swapAt < 60) return;
    var els = wdEls(), el = drag.el, t = null, i;
    var me = natRect(el); if (drag.cx >= me.left && drag.cx <= me.right && drag.cy >= me.top && drag.cy <= me.bottom) return;
    for (i = 0; i < els.length; i++) { if (els[i] === el) continue; var r = natRect(els[i]); if (drag.cx >= r.left && drag.cx <= r.right && drag.cy >= r.top && drag.cy <= r.bottom) { t = els[i]; break; } }
    if (!t) return;
    var before = rectsOf(els), si = els.indexOf(el), ti = els.indexOf(t);
    if (si < ti) t.parentNode.insertBefore(el, t.nextSibling); else t.parentNode.insertBefore(el, t);
    drag.swapAt = Date.now(); drag.reordered = true; flipFrom(before, el); place(); buzz(6);
  }
  function tick() {
    if (!drag || drag.mode !== 'mv') return;
    var m = U.$('#main'), r = m.getBoundingClientRect(), sp = 0;
    if (drag.cy < r.top + 90) sp = -Math.min(20, (r.top + 90 - drag.cy) / 3.5); else if (drag.cy > r.bottom - 110) sp = Math.min(20, (drag.cy - (r.bottom - 110)) / 3.5);
    if (sp) { m.scrollTop += sp; place(); reorder(); }
    drag.raf = requestAnimationFrame(tick);
  }
  document.addEventListener('pointerdown', function (e) {
    if (!S.homeEdit || !e.target.closest) return;
    if (e.target.closest('.wd-x,.wd-sz')) return;
    var h = e.target.closest('.wd-drag,.wd-rs'), w = e.target.closest('.wd');
    if (h) { e.preventDefault(); beginDrag(h.closest('.wd'), e.clientX, e.clientY, h.classList.contains('wd-rs') ? 'rs' : 'mv', e.pointerId, h); return; }
    if (!w) return;
    // press and hold anywhere on a widget (finger stays still) to pick it up
    var x = e.clientX, y = e.clientY, id = e.pointerId, done = false;
    var cancel = function (ev) { if (ev.type === 'pointermove' && Math.abs(ev.clientX - x) + Math.abs(ev.clientY - y) < 9) return; if (!done) { clearTimeout(tm); } off(); };
    var off = function () { document.removeEventListener('pointermove', cancel); document.removeEventListener('pointerup', cancel); document.removeEventListener('pointercancel', cancel); };
    var tm = setTimeout(function () { done = true; off(); if (!drag && S.homeEdit) beginDrag(w, x, y, 'mv', id); }, 240);
    document.addEventListener('pointermove', cancel); document.addEventListener('pointerup', cancel); document.addEventListener('pointercancel', cancel);
  });
  document.addEventListener('touchmove', function (e) { if (drag) e.preventDefault(); }, { passive: false });
  document.addEventListener('pointermove', function (e) {
    if (!drag) return; e.preventDefault();
    drag.cx = e.clientX; drag.cy = e.clientY;
    if (Math.abs(e.clientX - drag.x) + Math.abs(e.clientY - drag.y) > 6) drag.moved = true;
    if (drag.mode === 'mv') { place(); reorder(); }
    else {
      var dx = e.clientX - drag.x, dy = e.clientY - drag.y, sc = (U.lang() === 'ar' ? -dx : dx) + dy, i = Math.max(0, Math.min(2, SIZES.indexOf(drag.z) + Math.max(-2, Math.min(2, Math.round(sc / 70)))));
      if (i !== drag.steps) { var before = rectsOf(wdEls()); drag.steps = i; drag.el.className = drag.el.className.replace(/sz-\w/, 'sz-' + SIZES[i]); flipFrom(before, drag.el); buzz(8); }
    }
  });
  function orderFromDom() {
    var dom = wdEls().map(function (e) { return e.dataset.k; }), cur = wOrdered(), out = [], j = 0, set = {}; dom.forEach(function (k) { set[k] = 1; });
    cur.forEach(function (k) { out.push(set[k] ? dom[j++] : k); }); return out;
  }
  function endDrag(e) {
    if (!drag) return; var g = drag; drag = null; cancelAnimationFrame(g.raf);
    var el = g.el; el.classList.remove('dragging'); var gr = document.querySelector('.wgrid'); if (gr) gr.classList.remove('is-dragging');
    if (e.type === 'pointercancel') { U.render(true); return; }
    if (g.mode === 'mv') {
      drag = g; reorder(true); drag = null;
      var cur = el.getBoundingClientRect(); el.style.transition = 'none'; el.style.transform = 'none'; var nat = el.getBoundingClientRect();
      var dx = cur.left - nat.left, dy = cur.top - nat.top; el.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(1.045)'; void el.offsetWidth;
      el.style.transition = 'transform .3s ' + EASE; el.style.transform = ''; setTimeout(function () { el.style.transition = ''; }, 320);
      if (g.reordered) { var no = orderFromDom(); persistLayout(function (l) { l.wOrder = no; }); buzz(10); }
    } else if (SIZES[g.steps] !== g.z) { var nz = SIZES[g.steps]; S.popKey = g.k; saveLayout(function (l) { l.sizes[g.k] = nz; }); }
    else if (!g.moved) { var nz2 = SIZES[(SIZES.indexOf(g.z) + 1) % 3]; S.popKey = g.k; saveLayout(function (l) { l.sizes[g.k] = nz2; }); }
    else U.render(true);
  }
  document.addEventListener('pointerup', endDrag); document.addEventListener('pointercancel', endDrag);
  /* long-press a widget to start editing (like a phone home screen) */
  var lp = null;
  document.addEventListener('pointerdown', function (e) {
    S.lpGuard = false;
    if (S.homeEdit || U.route !== 'home' || !e.target.closest) return;
    var w = e.target.closest('.wd'); if (!w) return;
    var x = e.clientX, y = e.clientY; clearTimeout(lp);
    lp = setTimeout(function () { lp = null; S.homeEdit = true; S.lpGuard = true; U.render(true); if (navigator.vibrate) try { navigator.vibrate(15); } catch (_) { } }, 600);
    var cancel = function (ev) { if (ev.type === 'pointermove' && Math.abs(ev.clientX - x) + Math.abs(ev.clientY - y) < 8) return; clearTimeout(lp); lp = null; document.removeEventListener('pointermove', cancel); document.removeEventListener('pointerup', cancel); };
    document.addEventListener('pointermove', cancel); document.addEventListener('pointerup', cancel);
  });
  document.addEventListener('click', function (e) { if (S.lpGuard) { e.stopPropagation(); e.preventDefault(); S.lpGuard = 0; } }, true);

  /* ================= sales ================= */
  function range(p) {
    var td = K.today();
    if (p === 'today') return { from: td, to: td }; if (p === 'week') return { from: K.addDays(td, -6), to: td };
    if (p === 'year') return { from: td.slice(0, 4) + '-01-01', to: td.slice(0, 4) + '-12-31' };
    return K.monthRange(S.ym);
  }
  function salesIn(r) { return K.live(U.D.sales).filter(function (s) { return s.date >= r.from && s.date <= r.to; }); }
  function prevRange(p, r) {
    if (p === 'today') { var y = K.addDays(r.from, -1); return { from: y, to: y }; }
    if (p === 'week') return { from: K.addDays(r.from, -7), to: K.addDays(r.to, -7) };
    if (p === 'year') { var yy = String(Number(r.from.slice(0, 4)) - 1); return { from: yy + '-01-01', to: yy + '-12-31' }; }
    return K.monthRange(K.addMonths(S.ym, -1));
  }
  W.sales = function () {
    var D = U.D, p = S.salesP, r = range(p), rep = K.periodReport(D, r.from, r.to), pr = prevRange(p, r), prep = K.periodReport(D, pr.from, pr.to), list = salesIn(r), h = '';
    h += U.seg([['today', t('p_today')], ['week', t('p_week')], ['month', t('p_month')], ['year', t('p_year')]], p, 'salesp');
    if (p === 'month') h += U.monthbar();
    h += '<div class="kpis3">' + kpi('green', 'wallet', t('total_sales'), U.money(rep.sales), '', pct(rep.sales, prep.sales)) + kpi('blue', 'note', t('invoice_count'), B(rep.salesCount), '', pct(rep.salesCount, prep.salesCount)) + kpi('purple', 'box', t('crates_sold'), B(K.groupInt(rep.cratesSold)), '', pct(rep.cratesSold, prep.cratesSold)) + '</div>';
    var vals = [], labs = [];
    if (p === 'year') { for (var m = 1; m <= 12; m++) { var ym = r.from.slice(0, 4) + '-' + K.pad2(m), mr = K.monthRange(ym); vals.push(K.sum(salesIn(mr), function (x) { return x.total; }) / 100); labs.push(String(m)); } }
    else { var dd = r.from; while (dd <= r.to) { vals.push(K.sum(list.filter(function (x) { return x.date === dd; }), function (x) { return x.total; }) / 100); labs.push(dd.slice(8)); dd = K.addDays(dd, 1); } }
    h += panel('bars', t('sales_analysis'), V.area([{ values: vals, color: '#00A6E8' }], labs, 170), '<span class="badge green">' + t('amount_collected') + ': ' + U.moneyTxt(rep.collected) + '</span>');
    var byP = {}; list.forEach(function (x) { x.items.forEach(function (i) { var o = byP[i.productId] || (byP[i.productId] = { q: 0, v: 0 }); o.q += i.qty; o.v += i.qty * i.unitPrice; }); });
    var pk = Object.keys(byP).sort(function (a, b) { return byP[b].v - byP[a].v; }), tot = K.sum(pk, function (k) { return byP[k].v; });
    var pparts = pk.map(function (k, i) { var pp = K.byId(D.products, k); return { value: byP[k].v, color: PAL[i % PAL.length], name: pp ? pp.name : '?', val: B(Math.round(byP[k].v * 100 / (tot || 1)) + '%') }; });
    var pm = {}; K.live(D.payments).filter(function (x) { return x.date >= r.from && x.date <= r.to; }).forEach(function (x) { pm[x.method || 'cash'] = (pm[x.method || 'cash'] || 0) + x.amount; });
    var mk = Object.keys(pm), mtot = K.sum(mk, function (k) { return pm[k]; }), mparts = mk.map(function (k, i) { return { value: pm[k], color: PAL[(i + 3) % PAL.length], name: U.methodLabel(k), val: B(Math.round(pm[k] * 100 / (mtot || 1)) + '%') }; });
    function dn(parts, center, sub) { return parts.length ? '<div class="donutrow">' + V.donut(parts, center, sub) + legend(parts) + '</div>' : noData(); }
    h += '<div class="twocol">' + panel('box', t('by_product'), dn(pparts, B(compactM(tot)), t('dzd'))) + panel('wallet', t('by_method'), dn(mparts, B(compactM(mtot)), t('dzd'))) + '</div>';
    var q = (S.salesQ || '').trim().toLowerCase();
    var inv = U.newest(D.sales.filter(function (x) { return x.date >= r.from && x.date <= r.to; })).filter(function (x) {
      var out = K.saleOutstanding(D, x.id);
      if (S.salesF === 'paid' && (x.voided || out > 0)) return false; if (S.salesF === 'unpaid' && (x.voided || out <= 0)) return false;
      return !q || (U.invNo(x.no) + ' ' + U.invFull(x) + ' ' + U.custName(x.customerId) + ' ' + K.fmtDate(x.date)).toLowerCase().indexOf(q) >= 0;
    });
    h += '<div class="filterrow">' + U.searchbox('salesq', S.salesQ || '', t('search_invoice')).replace('id="salesq"', 'id="salesq" data-bind="salesQ"') + '</div>';
    h += U.chips([['all', t('all')], ['paid', t('paid')], ['unpaid', t('unpaid')]], S.salesF, 'salesf');
    var rows = U.limit(inv, 'sal', 8);
    h += panel('note', t('latest_invoices'), rows.length ? '<div style="overflow-x:auto"><table class="itable"><thead><tr><th>' + t('invoice_no') + '</th><th class="l">' + t('customer') + '</th><th>' + t('date') + '</th><th>' + t('quantity') + '</th><th>' + t('total') + '</th><th>' + t('inv_status') + '</th></tr></thead><tbody>' + rows.map(function (x) {
      var out = K.saleOutstanding(D, x.id), st = x.voided ? ['bad', 'inv_st_void'] : out <= 0 ? ['green', 'inv_st_paid'] : K.salePaid(D, x.id) > 0 ? ['amber', 'inv_st_partial'] : ['amber', 'inv_st_unpaid'];
      return '<tr class="tap" data-act="tx" data-kind="sale" data-id="' + x.id + '"><td>' + B(('00000' + x.no).slice(-5)) + '</td><td class="l">' + esc(U.custName(x.customerId)) + '</td><td>' + B(K.fmtDate(x.date).slice(0, 5)) + '</td><td>' + B(K.fmtQty(K.sum(x.items, function (i) { return i.qty; }))) + '</td><td>' + B(K.fmtMoney(x.total)) + '</td><td>' + U.badge(t(st[1]), st[0] === 'bad' ? 'red' : st[0]) + '</td></tr>';
    }).join('') + '</tbody></table></div>' + U.moreBtn('sal', 8, inv.length) : '<div class="muted" style="text-align:center;padding:12px">' + t('no_results') + '</div>', lnk('goto', 'invoices', t('show_all')));
    h += '<div class="btns"><button class="btn" data-act="export_sales">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_sales">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_sale">+ ' + t('new_invoice') + '</button></div>';
  };
  function compactM(c) { var v = c / 100; return v >= 1e6 ? (Math.round(v / 1e5) / 10) + 'M' : v >= 1e3 ? (Math.round(v / 100) / 10) + 'K' : String(Math.round(v)); }
  X.salesp = function (el) { S.salesP = el.dataset.id; S.showAll.sal = false; U.render(true); };
  X.salesf = function (el) { S.salesF = el.dataset.id; U.render(true); };
  X.export_sales = function () {
    var r = range(S.salesP), rows = [[t('invoice_no'), t('date'), t('customer'), t('total'), t('paid'), t('remaining')]];
    U.newest(U.D.sales.filter(function (s) { return !s.voided && s.date >= r.from && s.date <= r.to; })).forEach(function (s) { rows.push([U.invFull(s), s.date, U.custName(s.customerId), money0(s.total), money0(K.salePaid(U.D, s.id)), money0(s.total - K.salePaid(U.D, s.id))]); });
    csv('khaldi_sales_' + r.from + '_' + r.to + '.csv', rows);
  };
  X.print_sales = function () { printNow('KHALDI_PLAST_sales'); };

  /* ================= stock ================= */
  W.stock = function () {
    var D = U.D, tab = S.stockTab || 'finished', h = '', fin = K.sum(D.products, function (p) { return p.stock; }), raw = K.round3(K.sum(D.materials, function (p) { return p.stock; }));
    var low = D.products.concat(D.materials).filter(function (x) { return !x.archived && x.minStock > 0 && x.stock <= x.minStock; });
    var types = U.act(D.products).length + U.act(D.materials).length, isP = tab !== 'raw';
    h += '<div class="kpis4">' + kpi('blue', 'box', t('items_count'), B(types)) + kpi('green', 'box', t('finished_stock'), B(K.groupInt(fin))) + kpi('amber', 'scale', t('raw_stock'), B(K.fmtQty(raw))) + kpi(low.length ? 'red' : 'purple', 'alert', t('low_stock'), B(low.length)) + '</div>';
    var td = K.today(), labs = [], inn = [], out = [], i;
    for (i = 13; i >= 0; i--) { var dd = K.addDays(td, -i), ms = D.movements.filter(function (m) { return m.kind === (isP ? 'product' : 'material') && m.date === dd; }); labs.push(dd.slice(8)); inn.push(K.sum(ms.filter(function (m) { return m.qty > 0; }), function (m) { return m.qty; })); out.push(K.sum(ms.filter(function (m) { return m.qty < 0; }), function (m) { return -m.qty; })); }
    var items = U.act(isP ? D.products : D.materials);
    var parts = items.filter(function (x) { return x.stock > 0; }).map(function (x, k) { return { value: x.stock, color: PAL[k % PAL.length], name: x.name, val: B(Math.round(x.stock * 100 / ((isP ? fin : raw) || 1)) + '%') }; });
    h += '<div class="twocol">' + panel('bars', t('movement_chart'), V.area([{ values: inn, color: '#12804A' }, { values: out, color: '#E5493A' }], labs, 150) + '<div class="legend"><div class="li"><span class="sw" style="background:#12804A"></span><span class="nm">' + t('stock_in') + '</span></div><div class="li"><span class="sw" style="background:#E5493A"></span><span class="nm">' + t('stock_out') + '</span></div></div>') +
      panel('box', t('distribution'), parts.length ? '<div class="donutrow">' + V.donut(parts, B(K.fmtQty(isP ? fin : raw)), t(isP ? 'pcs' : 'kg')) + legend(parts) + '</div>' : noData()) + '</div>';
    h += U.seg([['finished', t('tab_products')], ['raw', t('tab_materials')], ['moves', t('tab_movements')]], tab, 'stocktab');
    if (tab !== 'moves') {
      var q = (S.stockQ || '').trim().toLowerCase();
      h += '<div class="filterrow">' + U.searchbox('stockq', S.stockQ || '', t('search')).replace('id="stockq"', 'id="stockq" data-bind="stockQ"') + '</div>';
      h += U.chips([['all', t('all')], ['low', t('low_stock')], ['ok', t('stock_ok')]], S.stockF, 'stockf');
      items = items.filter(function (x) { var lw = x.minStock > 0 && x.stock <= x.minStock; return (S.stockF === 'all' || (S.stockF === 'low' ? lw : !lw)) && (!q || x.name.toLowerCase().indexOf(q) >= 0); });
      h += items.length ? '<div class="card">' + items.map(function (x) {
        var lw = x.minStock > 0 && x.stock <= x.minStock, avg = isP ? null : K.avgMaterialCost(D, x.id), kind = isP ? 'product' : 'material';
        return '<div class="row"><div class="' + (isP ? 'thumb' : 'ibox amber') + '">' + (isP ? V.crate(x.color, 48) : V.icon('scale', 22)) + '</div><div class="main"><div class="t">' + esc(x.name) + '</div><div class="s">' + (x.code ? esc(x.code) + ' · ' : '') + (isP ? (x.price ? U.moneyTxt(x.price) : '-') + (x.weightG ? ' · ' + B(x.weightG) + ' ' + t('gram') : '') : t('avg_cost') + ': ' + (avg == null ? '-' : U.moneyTxt(Math.round(avg)) + ' / ' + t('kg'))) + '</div>' + (lw ? '<div>' + U.badge(t('low_stock'), 'red') + '</div>' : '') + '</div>' +
          '<div class="r"><small class="muted">' + t('available_qty') + '</small><br>' + U.qty(x.stock) + ' <span class="u muted">' + t(isP ? 'pcs' : 'kg') + '</span></div><div style="display:flex;flex-direction:column;gap:6px"><button class="iconbtn" data-act="adjust" data-kind="' + kind + '" data-id="' + x.id + '" aria-label="' + t('adjust') + '">' + V.icon('bars', 18) + '</button><button class="iconbtn" data-act="edit_item" data-kind="' + kind + '" data-id="' + x.id + '" aria-label="' + t('edit') + '">' + V.icon('edit', 18) + '</button></div></div>';
      }).join('') + '</div>' : '<div class="card">' + U.empty(t('no_results'), 'search') + '</div>';
      h += '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_item" data-kind="' + (isP ? 'product' : 'material') + '">+ ' + t(isP ? 'new_product' : 'new_material') + '</button></div>';
    } else {
      var list = D.movements.slice().reverse();
      h += list.length ? '<div class="card">' + U.limit(list, 'mv', 50).map(function (m) {
        return '<div class="row"><div class="main"><div class="t">' + esc(m.kind === 'product' ? U.prodName(m.itemId) : U.matName(m.itemId)) + '</div><div class="s">' + U.dt(m.date) + ' · ' + t('mv_' + m.type) + (m.note ? ' · ' + esc(m.note) : '') + '</div></div><div class="r ' + (m.qty >= 0 ? 'up' : 'down') + '">' + (m.qty > 0 ? '+' : '') + B(K.fmtQty(m.qty)) + '</div></div>';
      }).join('') + '</div>' + U.moreBtn('mv', 50, list.length) : '<div class="card">' + U.empty(t('no_records')) + '</div>';
    }
    return h;
  };
  X.stockf = function (el) { S.stockF = el.dataset.id; U.render(true); };

  /* ================= production ================= */
  function pendingOrders() { return U.D.notes.filter(function (n) { return n.isOrder && n.productId && (n.status === 'pending' || n.status === 'confirmed'); }).sort(function (a, b) { return (a.expectedDate || '9999') < (b.expectedDate || '9999') ? -1 : 1; }); }
  W.production = function () {
    var D = U.D, ym = S.ym, r = K.monthRange(ym), m = K.periodReport(D, r.from, r.to), tb = K.productionTable(D, r.from, r.to), total = m.good + m.defective, h = U.monthbar();
    var pmr = K.monthRange(K.addMonths(ym, -1)), pm0 = K.periodReport(D, pmr.from, pmr.to), dGood = pct(m.good, pm0.good), dTot = pct(total, pm0.good + pm0.defective);
    var pc = total ? Math.round(m.defective * 1000 / total) / 10 : 0, ord = pendingOrders();
    h += '<div class="kpis">' + kpi('blue', 'machine', t('production_total'), pcs(total), '', dTot) + kpi('green', 'check', t('good_crates'), pcs(m.good), '', dGood) + kpi('red', 'alert', t('defective_crates'), pcs(m.defective), t('defect_rate') + ': ' + B(pc + '%')) + kpi('amber', 'note', t('pending_orders'), B(ord.length)) + '</div>';
    h += '<div class="kpis">' + kpi('purple', 'scale', t('materials_consumed'), B(K.fmtQty(tb.totalKg)) + ' <small>' + t('kg') + '</small>') + kpi('blue', 'wallet', t('est_cost'), m.materialsCost == null ? '—' : U.money(m.materialsCost), m.materialsCost == null ? t('profit_unavailable') : t('estimate')) + '</div>';
    var td = K.today(), labs = [], vals = [], i; for (i = 6; i >= 0; i--) { var dd = K.addDays(td, -i); labs.push(dd.slice(8)); vals.push(K.sum(K.live(D.production).filter(function (x) { return x.date === dd; }), function (x) { return x.good; })); }
    h += panel('bars', t('last7'), V.area([{ values: vals, color: '#0077C8' }], labs, 150), lnk('goto', 'prodtable', t('tile_prodtable')));
    var byProd = {}; K.live(D.production).filter(function (x) { return x.date >= r.from && x.date <= r.to; }).forEach(function (x) { byProd[x.productId] = (byProd[x.productId] || 0) + x.good; });
    var ks = Object.keys(byProd), parts = ks.map(function (k, j) { var p = K.byId(D.products, k); return { value: byProd[k], color: PAL[j % PAL.length], name: p ? p.name : '?', val: B(K.groupInt(byProd[k])) }; });
    h += panel('box', t('crate_types'), parts.length ? '<div class="donutrow">' + V.donut(parts, B(K.groupInt(m.good)), t('good_crates')) + legend(parts) + '</div>' : noData());
    if (ord.length) h += panel('note', t('pending_orders'), ord.slice(0, 3).map(function (n) { return '<div class="row tap" data-act="edit_note" data-id="' + n.id + '"><div class="ibox amber">' + V.icon('note', 20) + '</div><div class="main"><div class="t">' + esc(n.customerName || n.title || U.prodName(n.productId)) + '</div><div class="s">' + esc(U.prodName(n.productId)) + ' × ' + B(n.qty) + (n.expectedDate ? ' · ' + U.dt(n.expectedDate) : '') + '</div></div></div>'; }).join(''), lnk('goto', 'notes', t('show_all')));
    var list = U.newest(D.production.filter(function (x) { return x.date >= r.from && x.date <= r.to; }));
    h += U.sec(t('production_log'));
    h += list.length ? '<div class="card">' + U.limit(list, 'prd', 8).map(function (x) { return U.txRow({ kind: 'production', id: x.id, date: x.date, rec: x, voided: x.voided }); }).join('') + '</div>' + U.moreBtn('prd', 8, list.length) : '<div class="card">' + U.empty(t('no_records')) + '</div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_production">+ ' + t('new_production') + '</button></div>';
  };

  /* ================= production by days (smart table) ================= */
  W.prodtable = function () {
    var D = U.D, r = K.monthRange(S.ym), tb = K.productionTable(D, r.from, r.to), h = U.monthbar();
    var ids = {}; tb.rows.forEach(function (x) { Object.keys(x.byProduct).forEach(function (k) { ids[k] = 1; }); });
    var prods = D.products.filter(function (p) { return ids[p.id] || (!p.archived); }).filter(function (p) { return ids[p.id] || tb.rows.length === 0 || true; });
    var all = S.ptAll === '1', byDate = {}; tb.rows.forEach(function (x) { byDate[x.date] = x; });
    var days = []; if (all) { for (var i = 1; i <= Number(r.to.slice(8)); i++) days.push(S.ym + '-' + K.pad2(i)); } else days = tb.rows.map(function (x) { return x.date; });
    var tot = tb.totalGood + tb.totalDefective, avg = tb.rows.length ? Math.round(tb.totalGood / tb.rows.length) : 0;
    h += '<div class="kpis">' + kpi('green', 'check', t('good_crates'), pcs(tb.totalGood)) + kpi('red', 'alert', t('defective_crates'), pcs(tb.totalDefective), t('defect_rate') + ': ' + B((tot ? Math.round(tb.totalDefective * 1000 / tot) / 10 : 0) + '%')) + kpi('blue', 'calendar', t('prod_days'), B(tb.rows.length), t('daily_avg') + ': ' + B(K.groupInt(avg))) + kpi('amber', 'scale', t('materials_consumed'), B(K.fmtQty(tb.totalKg)) + ' <small>' + t('kg') + '</small>') + '</div>';
    h += U.seg([['0', t('only_prod_days')], ['1', t('all_days')]], S.ptAll, 'ptall');
    if (!tb.rows.length && !all) return h + '<div class="card">' + U.empty(t('no_records'), 'box') + '</div><div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_production">+ ' + t('new_production') + '</button></div>';
    var th = '<tr><th>' + t('date') + '</th>' + prods.map(function (p) { return '<th>' + esc(p.name) + '</th>'; }).join('') + '<th>' + t('good_crates') + '</th><th>' + t('defective_crates') + '</th>' + K.SHIFTS.map(function (s) { return '<th>' + t('shift') + ' ' + s.n + '</th>'; }).join('') + '<th>' + t('shift_unspecified_short') + '</th><th>' + t('kg') + '</th></tr>';
    var body = days.map(function (dd) {
      var x = byDate[dd];
      if (!x) return '<tr class="zero"><td>' + esc(U.dayName(dd, true)) + ' ' + B(dd.slice(8) + '/' + dd.slice(5, 7)) + '</td>' + prods.map(function () { return '<td>·</td>'; }).join('') + '<td>·</td><td>·</td><td>·</td><td>·</td><td>·</td><td>·</td><td>·</td></tr>';
      return '<tr class="tap" data-act="pt_day" data-date="' + dd + '"><td>' + esc(U.dayName(dd, true)) + ' ' + B(dd.slice(8) + '/' + dd.slice(5, 7)) + '</td>' + prods.map(function (p) { var b = x.byProduct[p.id]; return '<td>' + (b ? B(K.groupInt(b.good)) + (b.defective ? ' <small class="muted">(' + b.defective + ')</small>' : '') : '·') + '</td>'; }).join('') +
        '<td><b>' + B(K.groupInt(x.good)) + '</b></td><td class="' + (x.defective ? 'bad' : '') + '">' + B(x.defective) + '</td>' + [1, 2, 3, 0].map(function (n) { return '<td>' + (x.shifts[n] ? B(K.groupInt(x.shifts[n])) : '·') + '</td>'; }).join('') + '<td>' + (x.kg ? B(K.fmtQty(x.kg)) : '·') + '</td></tr>';
    }).join('');
    var sh = { 0: 0, 1: 0, 2: 0, 3: 0 }, pt = {}; tb.rows.forEach(function (x) { [0, 1, 2, 3].forEach(function (n) { sh[n] += x.shifts[n]; }); Object.keys(x.byProduct).forEach(function (k) { pt[k] = (pt[k] || 0) + x.byProduct[k].good; }); });
    var foot = '<tr><td>' + t('total') + '</td>' + prods.map(function (p) { return '<td>' + B(K.groupInt(pt[p.id] || 0)) + '</td>'; }).join('') + '<td>' + B(K.groupInt(tb.totalGood)) + '</td><td>' + B(K.groupInt(tb.totalDefective)) + '</td>' + [1, 2, 3, 0].map(function (n) { return '<td>' + B(K.groupInt(sh[n])) + '</td>'; }).join('') + '<td>' + B(K.fmtQty(tb.totalKg)) + '</td></tr>';
    h += '<div class="ptable-wrap"><table class="ptable"><thead>' + th + '</thead><tbody>' + body + '</tbody><tfoot>' + foot + '</tfoot></table></div><div class="muted" style="margin-bottom:10px">' + t('ptable_note') + '</div>';
    h += '<div class="btns"><button class="btn" data-act="export_ptable">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_sales">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_production">+ ' + t('new_production') + '</button></div>';
  };
  X.ptall = function (el) { S.ptAll = el.dataset.id; U.render(true); };
  X.pt_day = function (el) {
    var day = el.dataset.date, recs = U.newest(U.D.production.filter(function (x) { return x.date === day; }));
    U.showModal('<h3>' + esc(U.longDate(day)) + '</h3><div class="card" style="box-shadow:none">' + recs.map(function (x) { return U.txRow({ kind: 'production', id: x.id, date: x.date, rec: x, voided: x.voided }).replace('data-act="tx"', 'data-act="pt_rec"'); }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
  };
  X.pt_rec = function (el) { U.closeModal(); U.go('tx', { kind: el.dataset.kind, id: el.dataset.id }); };
  X.export_ptable = function () {
    var r = K.monthRange(S.ym), tb = K.productionTable(U.D, r.from, r.to), ps = U.D.products;
    var rows = [[t('date')].concat(ps.map(function (p) { return p.name; }), [t('good_crates'), t('defective_crates'), t('shift') + ' 1', t('shift') + ' 2', t('shift') + ' 3', t('shift_unspecified_short'), t('kg')])];
    tb.rows.forEach(function (x) { rows.push([x.date].concat(ps.map(function (p) { return x.byProduct[p.id] ? x.byProduct[p.id].good : 0; }), [x.good, x.defective, x.shifts[1], x.shifts[2], x.shifts[3], x.shifts[0], x.kg])); });
    csv('khaldi_production_' + S.ym + '.csv', rows);
  };

  /* ================= workers: today overview, weekly grid, directory ================= */
  function shiftState(n) {
    var h = new Date().getHours(), sh = K.SHIFTS[n - 1], s = parseInt(sh.start, 10), e = parseInt(sh.end, 10) || 24;
    return h >= s && h < e ? 'current' : h < s ? 'upcoming' : 'ended';
  }
  function wstat(w) { return w.status || (w.active === false ? 'stopped' : 'active'); }
  function wbadge(w) { var s = wstat(w); return U.badge(t('ws_' + s), s === 'active' ? 'green' : s === 'leave' ? 'amber' : 'gray'); }
  function tenure(w) {
    if (!w.hireDate) return t('hire_date_none');
    var a = new Date(w.hireDate + 'T00:00:00'), b = new Date((w.endDate || K.today()) + 'T00:00:00'), days = Math.max(0, Math.round((b - a) / 86400000)), y = Math.floor(days / 365), m = Math.floor((days % 365) / 30);
    return (y ? y + ' ' + t('years') + ' ' : '') + (m || !y ? m + ' ' + t('months') : '') + ' (' + days + ' ' + t('days') + ')';
  }
  function todayView() {
    var D = U.D, day = K.today(), active = D.workers.filter(function (w) { return !w.archived && wstat(w) === 'active'; }).length, h = '';
    var workedToday = {}; D.attendance.forEach(function (a) { if (a.date === day && a.worked) workedToday[a.workerId] = 1; });
    h += '<div class="kpis4">' + kpi('blue', 'users', t('workers'), B(U.act(D.workers).length)) + kpi('green', 'check', t('worked_today'), B(Object.keys(workedToday).length)) + kpi('amber', 'clock', t('ws_leave'), B(D.workers.filter(function (w) { return !w.archived && wstat(w) === 'leave'; }).length)) + kpi('red', 'x', t('ws_stopped'), B(D.workers.filter(function (w) { return !w.archived && wstat(w) === 'stopped'; }).length)) + '</div>';
    var recs = K.live(D.production).filter(function (r) { return r.date === day; });
    var info = K.SHIFTS.map(function (s) {
      var worked = K.rosterFor(D, day, s.n).filter(function (a) { return a.worked; }), rr = recs.filter(function (r) { return r.shift === s.n; });
      return { s: s, st: shiftState(s.n), worked: worked, good: K.sum(rr, function (r) { return r.good; }), bad: K.sum(rr, function (r) { return r.defective; }), n: rr.length };
    });
    h += '<div class="shcards">' + info.map(function (x) {
      var pct = active ? Math.min(100, Math.round(x.worked.length * 100 / active)) : 0, col = x.st === 'current' ? '#12804A' : x.st === 'upcoming' ? '#F59E2C' : '#8A94A6';
      return '<div class="shc"><div class="sn">' + t('shift') + ' ' + x.s.n + '</div><div class="st"><bdi dir="ltr">' + x.s.start + ' - ' + x.s.end + '</bdi></div><div class="ring" style="background:conic-gradient(' + col + ' ' + pct + '%,rgba(11,26,46,.1) 0)"><b>' + x.worked.length + '</b></div>' + U.badge(t('st_' + x.st), x.st === 'current' ? 'green' : x.st === 'upcoming' ? 'amber' : 'gray') + '</div>';
    }).join('') + '</div>';
    info.forEach(function (x) {
      h += '<div class="shrow"><div class="shh"><span class="ci2">' + V.icon('clock', 20) + '</span><b>' + t('shift') + ' ' + x.s.n + ' · <bdi dir="ltr">' + x.s.start + ' - ' + x.s.end + '</bdi></b><button class="btn sm" data-act="roster" data-date="' + day + '" data-shift="' + x.s.n + '">' + t('edit') + '</button></div>' +
        '<div class="mini"><div><small>' + t('workers') + '</small><b>' + x.worked.length + '</b></div><div><small>' + t('good_crates') + '</small><b>' + K.groupInt(x.good) + '</b></div><div><small>' + t('defective_crates') + '</small><b>' + K.groupInt(x.bad) + '</b></div><div><small>' + t('production') + '</small><b>' + x.n + '</b></div></div>' +
        '<div style="margin-top:8px">' + (x.worked.length ? x.worked.map(function (a) { return '<span class="chipbtn" data-act="open_worker" data-id="' + a.workerId + '">' + esc(U.workerName(a.workerId)) + '</span>'; }).join(' ') : '<span class="muted">' + t('no_workers_shift') + '</span>') + '</div></div>';
    });
    var un = recs.filter(function (r) { return !r.shift; });
    if (un.length) h += '<div class="alert blue">' + t('unassigned_prod') + ': <b>' + K.groupInt(K.sum(un, function (r) { return r.good; })) + '</b> ' + t('pcs') + '</div>';
    return h + '<div class="muted" style="text-align:center;margin:6px 0 10px">' + t('shifts_fixed_note').replace(/(\d\d:\d\d)-(\d\d:\d\d)/g, '<bdi dir="ltr">$1 - $2</bdi>') + '</div>';
  }
  function weekView() {
    var D = U.D, mon = S.week, days = K.weekDates(mon), cur = K.startOfWeek(K.today()) === mon, ar = U.lang() === 'ar', h = '';
    h += '<div class="shiftwrap"><div class="weekhead"><button class="arrow" data-act="week_prev">' + V.icon(ar ? 'chevR' : 'chevL', 20) + '</button><div class="mid">' + (cur ? t('current_week') : t('week')) + '<div class="muted">' + t('from') + ' <bdi class="num">' + K.fmtDate(days[0]) + '</bdi> ' + t('to') + ' <bdi class="num">' + K.fmtDate(days[6]) + '</bdi></div></div><button class="arrow" data-act="week_next">' + V.icon(ar ? 'chevL' : 'chevR', 20) + '</button></div>';
    h += '<div class="sg"><div class="h">' + t('workers_col') + '</div>' + K.SHIFTS.map(function (s) { return '<div class="h">' + t('shift') + ' ' + s.n + '<small><bdi dir="ltr">' + s.start + ' - ' + s.end + '</bdi></small></div>'; }).join('');
    days.forEach(function (day) {
      h += '<div class="day">' + esc(U.dayName(day)) + '<small><bdi class="num">' + day.slice(8) + '/' + day.slice(5, 7) + '</bdi></small></div>';
      K.SHIFTS.forEach(function (s) {
        var r = K.rosterFor(D, day, s.n), inner = r.length ? r.map(function (a) { return '<span class="wc ' + (a.worked ? 'w' : 'n') + '">' + (a.worked ? '✓ ' : '✗ ') + esc(U.workerName(a.workerId)) + '</span>'; }).join('') : '<span class="wc e">+</span>';
        h += '<button class="cell ' + (r.some(function (a) { return a.worked; }) ? 'w' : (r.length ? 'n' : 'e')) + '" data-act="roster" data-date="' + day + '" data-shift="' + s.n + '">' + inner + '</button>';
      });
    });
    h += '</div><div class="keyline"><span><i style="background:#CFEBD8"></i>' + t('worked') + '</span><span><i style="background:#F9D3CF"></i>' + t('did_not_work') + '</span></div></div>';
    var st = K.workerStats(D, days[0], days[6]).filter(function (x) { return wstat(x.worker) === 'active' || x.shifts; });
    h += st.length ? U.sec(t('week_summary')) + '<div class="card">' + st.map(function (x) { return '<div class="row tap" data-act="open_worker" data-id="' + x.worker.id + '"><div class="ibox">' + V.icon('user', 20) + '</div><div class="main"><div class="t">' + esc(x.worker.name) + '</div></div><div class="r">' + B(x.shifts) + ' ' + t('shifts') + ' · ' + B(x.hours) + ' ' + t('hours') + '</div></div>'; }).join('') + '</div>' : '<div class="alert blue">' + t('add_workers_first') + '</div>';
    return h;
  }
  function listView() {
    var D = U.D, q = (S.workQ || '').trim().toLowerCase(), r = K.monthRange(K.today().slice(0, 7)), h = '';
    var all = U.act(D.workers), act = all.filter(function (w) { return wstat(w) === 'active'; }).length;
    var owed = K.sum(all, function (w) { return Math.max(0, K.workerLedger(D, w.id).balance); });
    h += '<div class="kpis">' + kpi('blue', 'users', t('workers'), B(all.length), B(act) + ' ' + t('ws_active')) + kpi('amber', 'wallet', t('workers_owed'), U.money(owed)) + '</div>';
    h += '<button class="btn block" data-act="goto" data-id="payroll" style="margin-bottom:10px">' + V.icon('wallet', 18) + ' ' + t('tile_payroll') + '</button>';
    h += U.searchbox('workq', S.workQ || '', t('search')).replace('id="workq"', 'id="workq" data-bind="workQ"');
    var list = all.filter(function (w) { return !q || (w.name + ' ' + (w.role || '') + ' ' + (w.phone || '')).toLowerCase().indexOf(q) >= 0; });
    h += '<div class="card">' + (list.length ? list.map(function (w) {
      var m = K.workerLedger(D, w.id, r.from, r.to), a = K.workerLedger(D, w.id);
      return '<div class="row tap" data-act="open_worker" data-id="' + w.id + '"><div class="ibox ' + (wstat(w) === 'active' ? '' : 'red') + '">' + V.icon('user', 22) + '</div><div class="main"><div class="t">' + esc(w.name) + '</div><div class="s">' + (w.role ? esc(w.role) + ' · ' : '') + B(m.shifts) + ' ' + t('shifts') + ' / ' + B(m.hours) + ' ' + t('hours') + ' (' + t('this_month') + ')</div><div class="s">' + t('balance') + ': <b class="' + (a.balance > 0 ? 'down' : '') + '">' + U.moneyTxt(a.balance) + '</b></div></div>' + wbadge(w) + '</div>';
    }).join('') : U.empty(t('no_records'), 'users')) + '</div>';
    h += U.sec(t('machines')) + '<div class="card">' + (U.act(D.machines).length ? U.act(D.machines).map(function (m) { return '<div class="row tap" data-act="edit_machine" data-id="' + m.id + '"><div class="ibox amber">' + V.icon('machine', 22) + '</div><div class="main"><div class="t">' + esc(m.name) + '</div></div>' + V.icon('edit', 18) + '</div>'; }).join('') : '<div class="muted">' + t('no_machines') + '</div>') + '<button class="btn sm block" data-act="new_machine">+ ' + t('new_machine') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_worker">+ ' + t('new_worker') + '</button></div>';
  }
  W.workers = function () {
    var tab = S.workTab, h = U.seg([['today', t('tab_today')], ['week', t('tab_week')], ['list', t('tab_workers')]], tab, 'worktab');
    return h + (tab === 'today' ? todayView() : tab === 'week' ? weekView() : listView());
  };
  X.open_worker = function (el) { U.closeModal(); U.go('worker', el.dataset.id); };

  W.worker = function (id) {
    var D = U.D, w = K.byId(D.workers, id); if (!w) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    var r = K.monthRange(S.ym), m = K.workerLedger(D, id, r.from, r.to), a = K.workerLedger(D, id), h = '';
    h += '<div class="wk-head"><div class="ibox ' + (wstat(w) === 'active' ? '' : 'red') + '">' + V.icon('user', 28) + '</div><div style="flex:1;min-width:0"><div class="big">' + esc(w.name) + '</div><div class="muted">' + esc(w.role || t('noinfo')) + '</div><div style="margin-top:4px">' + wbadge(w) + '</div></div><button class="btn sm ghost" data-act="edit_worker" data-id="' + id + '">' + t('edit') + '</button></div>';
    h += '<div class="card">' + U.kv('calendar', t('hire_date'), w.hireDate ? U.dt(w.hireDate) : '<span class="muted">' + t('hire_date_none') + '</span>') + U.kv('clock', t('tenure'), esc(tenure(w))) + (w.endDate ? U.kv('calendar', t('end_date'), U.dt(w.endDate)) : '') +
      U.kv('phone', t('phone'), w.phone ? B(esc(w.phone)) : '—') + U.kv('pin', t('place_address'), esc(w.address || '—')) + U.kv('wallet', t('rate_per_shift'), w.rate ? U.money(w.rate) : '—') + (w.notes ? U.kv('note', t('notes'), esc(w.notes)) : '') + '</div>';
    h += panel('wallet', t('worker_account'), '<div class="statgrid"><div><small>' + t('earned') + '</small><b>' + U.money(a.earned) + '</b></div><div><small>' + t('paid') + '</small><b>' + U.money(a.paid) + '</b></div><div><small>' + t('balance') + '</small><b class="' + (a.balance > 0 ? 'down' : 'up') + '">' + U.money(a.balance) + '</b></div></div><div class="muted">' + t('worker_balance_note') + '</div>' +
      '<div class="statgrid" style="margin-top:8px"><div><small>' + t('shifts') + ' (' + t('all_time') + ')</small><b>' + a.shifts + '</b></div><div><small>' + t('hours') + '</small><b>' + a.hours + '</b></div><div><small>' + t('absences') + '</small><b>' + a.absent + '</b></div></div>' + '<button class="btn primary block" data-act="pay_worker" data-id="' + id + '">' + V.icon('wallet', 18) + ' ' + t('pay_worker') + '</button>');
    h += U.monthbar() + '<div class="statgrid"><div><small>' + t('shifts') + '</small><b>' + m.shifts + '</b></div><div><small>' + t('hours') + '</small><b>' + m.hours + '</b></div><div><small>' + t('absences') + '</small><b>' + m.absent + '</b></div><div><small>' + t('earned') + '</small><b>' + U.money(m.earned) + '</b></div><div><small>' + t('paid') + '</small><b>' + U.money(m.paid) + '</b></div><div><small>' + t('last_worked') + '</small><b>' + (a.lastWorked ? U.dt(a.lastWorked) : '—') + '</b></div></div>';
    var att = D.attendance.filter(function (x) { return x.workerId === id && x.date >= r.from && x.date <= r.to; }).sort(function (x, y) { return x.date < y.date ? 1 : -1; });
    h += U.sec(t('attendance_log')) + '<div class="card">' + (att.length ? att.map(function (x) { var mc = x.machineId ? K.byId(D.machines, x.machineId) : null; return '<div class="row"><div class="ibox ' + (x.worked ? 'green' : 'red') + '">' + V.icon(x.worked ? 'check' : 'x', 20) + '</div><div class="main"><div class="t">' + U.dt(x.date) + ' · ' + t('shift') + ' ' + x.shift + '</div><div class="s">' + (x.worked ? t('worked') : t('did_not_work')) + (mc ? ' · ' + esc(mc.name) : '') + '</div></div></div>'; }).join('') : '<div class="muted">' + t('no_records') + '</div>') + '</div>';
    var pays = a.payments.slice().sort(function (x, y) { return x.date < y.date ? 1 : -1; });
    h += U.sec(t('worker_payments')) + '<div class="card">' + (pays.length ? pays.map(function (p) { return '<div class="row tap" data-act="edit_wpay" data-id="' + p.id + '"><div class="ibox amber">' + V.icon('upload', 20) + '</div><div class="main"><div class="t">' + t('wpay_' + p.kind) + '</div><div class="s">' + U.dt(p.date) + ' · ' + U.methodLabel(p.method) + '</div></div><div class="r">' + U.money(p.amount) + '</div>' + V.icon('edit', 18) + '</div>'; }).join('') : '<div class="muted">' + t('none') + '</div>') + '</div>';
    return h;
  };
  X.pay_worker = function (el) { F.wpay(el.dataset.id); };
  X.edit_wpay = function (el) { F.wpay(null, el.dataset.id); };
  X.new_worker = function () { F.worker(); };

  /* ================= customers & suppliers ================= */
  function directory(kind) {
    var D = U.D, isC = kind === 'customer', qk = isC ? 'custQ' : 'suppQ', fk = isC ? 'custF' : 'suppF', q = (S[qk] || '').trim().toLowerCase(), h = '';
    var all = U.act(isC ? D.customers : D.suppliers).map(function (p) { return { p: p, b: isC ? K.customerBalance(D, p.id) : K.supplierBalance(D, p.id) }; });
    var debt = K.sum(all, function (x) { return x.b > 0 ? x.b : 0; });
    h += '<div class="kpis">' + kpi(isC ? 'blue' : 'amber', 'users', t(isC ? 'customers' : 'suppliers'), B(all.length)) + kpi('red', 'wallet', t(isC ? 'customer_debts' : 'supplier_debts'), U.money(debt), B(all.filter(function (x) { return x.b > 0; }).length) + ' ' + t('with_balance')) + '</div>';
    h += U.searchbox(qk, S[qk] || '', t('search')).replace('id="' + qk + '"', 'id="' + qk + '" data-bind="' + qk + '"');
    h += U.chips([['all', t('all')], ['debt', t('with_balance')], ['clear', t('no_balance')]], S[fk], 'partyf' + (isC ? 'c' : 's'));
    var list = all.filter(function (x) {
      if (S[fk] === 'debt' && x.b <= 0) return false; if (S[fk] === 'clear' && x.b > 0) return false;
      return !q || (x.p.name + ' ' + (x.p.phone || '') + ' ' + (x.p.address || '') + ' ' + (x.p.activity || '') + ' ' + (x.p.email || '')).toLowerCase().indexOf(q) >= 0;
    }).sort(function (a, b) { return b.b - a.b; });
    h += list.length ? '<div class="card">' + list.map(function (x) {
      return '<div class="row tap" data-act="party" data-kind="' + kind + '" data-id="' + x.p.id + '"><div class="ibox ' + (x.b > 0 ? 'red' : 'green') + '">' + V.icon(isC ? 'user' : 'truck', 22) + '</div><div class="main"><div class="t">' + esc(x.p.name) + '</div>' + (x.p.phone ? '<div class="s">' + V.icon('phone', 13) + ' ' + B(esc(x.p.phone)) + '</div>' : '') + (x.p.address ? '<div class="s">' + V.icon('pin', 13) + ' ' + esc(x.p.address) + '</div>' : '') + (x.p.activity ? '<div class="s">' + esc(x.p.activity) + '</div>' : '') + '</div><div class="r ' + (x.b > 0 ? 'down' : 'up') + '">' + U.money(x.b) + '</div></div>';
    }).join('') + '</div>' : '<div class="card">' + U.empty(t('no_results'), 'search') + '</div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_party" data-kind="' + kind + '">+ ' + t(isC ? 'new_customer' : 'new_supplier') + '</button></div>';
  }
  W.customers = function () { return directory('customer'); };
  W.suppliers = function () { return directory('supplier'); };
  X.partyfc = function (el) { S.custF = el.dataset.id; U.render(true); };
  X.partyfs = function (el) { S.suppF = el.dataset.id; U.render(true); };
  W.party = function (arg) {
    var D = U.D, isC = arg.kind === 'customer', p = K.byId(isC ? D.customers : D.suppliers, arg.id); if (!p) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    var P = K.partyProfile(D, arg.kind, p.id), h = '';
    h += '<div class="wk-head"><div class="ibox ' + (P.balance > 0 ? 'red' : 'green') + '">' + V.icon(isC ? 'user' : 'truck', 28) + '</div><div style="flex:1;min-width:0"><div class="big">' + esc(p.name) + '</div><div class="muted">' + esc(p.activity || t(isC ? 'customer' : 'supplier')) + '</div></div><button class="btn sm ghost" data-act="edit_party" data-kind="' + arg.kind + '" data-id="' + p.id + '">' + t('edit') + '</button></div>';
    h += '<div class="card">' + U.kv('phone', t('phone'), p.phone ? B(esc(p.phone)) : '—') + U.kv('pin', t('place_address'), esc(p.address || '—')) + U.kv('mail', t('email'), p.email ? '<bdi>' + esc(p.email) + '</bdi>' : '—') + (p.notes ? U.kv('note', t('notes'), esc(p.notes)) : '') +
      U.kv('calendar', t('first_deal'), P.first ? U.dt(P.first) : '—') + U.kv('calendar', t('last_deal'), P.last ? U.dt(P.last) : '—') + '</div>';
    h += '<div class="statgrid"><div><small>' + t(isC ? 'invoice_count' : 'purchase_count') + '</small><b>' + B(P.count) + '</b></div><div><small>' + t('total') + '</small><b>' + U.money(P.total) + '</b></div><div><small>' + t('paid') + '</small><b>' + U.money(P.paid) + '</b></div><div><small>' + t('balance') + '</small><b class="' + (P.balance > 0 ? 'down' : 'up') + '">' + U.money(P.balance) + '</b></div><div><small>' + t(isC ? 'crates_sold' : 'kg') + '</small><b>' + B(K.fmtQty(P.qty)) + '</b></div><div><small>' + t('avg_invoice') + '</small><b>' + U.money(P.avg) + '</b></div></div>';
    h += '<div class="btns"><button class="btn primary" data-act="pay_party" data-kind="' + arg.kind + '" data-id="' + p.id + '">' + t(isC ? 'receive_payment' : 'pay_supplier') + '</button>' + (isC ? '<button class="btn" data-act="new_sale_for" data-id="' + p.id + '">+ ' + t('new_invoice') + '</button>' + '<button class="btn" data-act="go_statement" data-id="' + p.id + '">' + t('p_statement') + '</button>' : '<button class="btn" data-act="new_purchase">+ ' + t('new_purchase') + '</button>') + '</div>';
    var docs = U.newest(isC ? D.sales.filter(function (s) { return s.customerId === p.id; }) : D.purchases.filter(function (x) { return x.supplierId === p.id; }));
    h += U.sec(t(isC ? 'sales' : 'purchases')) + (docs.length ? '<div class="card">' + docs.slice(0, 20).map(function (x) { return U.txRow({ kind: isC ? 'sale' : 'purchase', id: x.id, date: x.date, rec: x, voided: x.voided }); }).join('') + '</div>' : '<div class="card">' + U.empty(t('no_records')) + '</div>');
    var pays = U.newest(isC ? D.payments.filter(function (x) { return x.customerId === p.id; }) : D.supplierPayments.filter(function (x) { return x.supplierId === p.id; }));
    return h + U.sec(t('payments')) + (pays.length ? '<div class="card">' + pays.slice(0, 30).map(function (x) { return U.payRow(arg.kind, x); }).join('') + '</div>' : '<div class="card">' + U.empty(t('none')) + '</div>');
  };
  X.new_sale_for = function (el) { F.sale(null, { customerId: el.dataset.id }); };

  /* ================= notes / upcoming orders ================= */
  function nbadge(n) { var c = { pending: 'amber', confirmed: '', completed: 'green', cancelled: 'gray' }[n.status]; return U.badge(t('ns_' + n.status), c); }
  W.notes = function () {
    var D = U.D, td = K.today(), q = (S.noteQ || '').trim().toLowerCase(), h = '';
    var orders = D.notes.filter(function (n) { return n.isOrder; });
    var over = orders.filter(function (n) { return (n.status === 'pending' || n.status === 'confirmed') && n.expectedDate && n.expectedDate < td; }).length;
    var thisM = D.notes.filter(function (n) { return n.date.slice(0, 7) === td.slice(0, 7); }).length;
    h += '<div class="kpis4">' + kpi('blue', 'note', t('total_orders'), B(orders.length)) + kpi('amber', 'clock', t('ns_pending'), B(orders.filter(function (n) { return n.status === 'pending'; }).length)) + kpi('green', 'check', t('ns_confirmed'), B(orders.filter(function (n) { return n.status === 'confirmed'; }).length)) + kpi(over ? 'red' : 'purple', 'calendar', over ? t('overdue') : t('this_month'), B(over || thisM)) + '</div>';
    h += '<div class="filterrow">' + U.searchbox('noteq', S.noteQ || '', t('search')).replace('id="noteq"', 'id="noteq" data-bind="noteQ"') + '</div>';
    h += U.chips([['all', t('all')], ['pending', t('ns_pending')], ['confirmed', t('ns_confirmed')], ['completed', t('ns_completed')], ['cancelled', t('ns_cancelled')], ['plain', t('plain_notes')]], S.noteF, 'notef');
    h += U.seg([['added', t('sort_added')], ['expected', t('sort_expected')]], S.noteSort, 'notesort');
    var list = D.notes.filter(function (n) { return S.noteF === 'all' || (S.noteF === 'plain' ? !n.isOrder : n.status === S.noteF && n.isOrder); }).filter(function (n) {
      return !q || ((n.title || '') + ' ' + (n.text || '') + ' ' + (n.customerName || '') + ' ' + (n.phone || '') + ' ' + (n.productId ? U.prodName(n.productId) : '')).toLowerCase().indexOf(q) >= 0;
    });
    list = S.noteSort === 'expected' ? list.slice().sort(function (a, b) { return (a.expectedDate || '9999') < (b.expectedDate || '9999') ? -1 : 1; }) : U.newest(list);
    h += list.length ? list.map(function (n) {
      var late = n.isOrder && (n.status === 'pending' || n.status === 'confirmed') && n.expectedDate && n.expectedDate < td, sale = n.saleId ? K.byId(D.sales, n.saleId) : null, pr = n.productId ? K.byId(D.products, n.productId) : null;
      var acts = '<div class="nact"><button class="iconbtn" data-act="edit_note" data-id="' + n.id + '" aria-label="' + t('edit') + '">' + V.icon('edit', 18) + '</button><button class="iconbtn dg" data-act="del_note" data-id="' + n.id + '" aria-label="' + t('delete') + '">' + V.icon('trash', 18) + '</button></div>';
      if (!n.isOrder) return '<div class="ncard"><div class="nth"><span class="ibox amber">' + V.icon('note', 22) + '</span></div><div class="nb2"><div class="t">' + esc(n.title || (n.text || '').slice(0, 40)) + '</div><div class="s" style="white-space:pre-wrap">' + esc((n.text || '').length > 200 ? n.text.slice(0, 200) + '…' : n.text) + '</div><div class="s">' + U.dt(n.date) + '</div></div>' + acts + '</div>';
      return '<div class="ncard"><div class="nth">' + (pr ? '<div class="thumb" style="width:64px;height:50px">' + V.crate(pr.color, 56) + '</div><span class="muted">' + esc(pr.code || '') + '</span>' : '<span class="ibox amber">' + V.icon('truck', 22) + '</span>') + '</div><div class="nb2"><div class="t">' + esc(n.customerName || n.title || U.prodName(n.productId)) + '</div><div class="s">' + (n.phone ? V.icon('phone', 12) + ' ' + B(esc(n.phone)) + ' · ' : '') + (pr ? esc(pr.name) + ' × ' + B(K.groupInt(n.qty)) : '') + '</div>' +
        (n.expectedDate ? '<div class="s">' + V.icon('calendar', 12) + ' ' + t('expected_date') + ': ' + U.dt(n.expectedDate) + '</div>' : '') + (n.text ? '<div class="s">' + esc(n.text) + '</div>' : '') +
        '<div style="margin-top:5px">' + nbadge(n) + (late ? ' ' + U.badge(t('overdue'), 'red') : '') + (sale ? ' ' + U.badge(t('invoiced') + ' ' + U.invNo(sale.no), 'green') : '') + '</div>' +
        (n.productId && n.qty && !n.saleId && n.status !== 'cancelled' ? '<button class="btn sm" style="margin-top:6px" data-act="note_invoice" data-id="' + n.id + '">' + t('convert_to_invoice') + '</button>' : sale ? '<button class="btn sm ghost" style="margin-top:6px" data-act="note_view_invoice" data-id="' + sale.id + '">' + t('view_invoice') + '</button>' : '') + '</div>' + acts + '</div>';
    }).join('') : '<div class="card">' + U.empty(t('no_notes'), 'note') + '</div>';
    h += '<div class="btns"><button class="btn" data-act="export_notes">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_sales">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_note">+ ' + t('new_note') + '</button></div>';
  };
  X.del_note = function (el) { var n = K.byId(U.D.notes, el.dataset.id); F.remove('note', el.dataset.id, n ? (n.title || n.customerName || n.date) : '', function () { U.render(true); }); };
  X.export_notes = function () {
    var D = U.D, rows = [[t('date'), t('order_customer'), t('phone'), t('product'), t('quantity'), t('expected_date'), t('order_status'), t('note_text')]];
    D.notes.forEach(function (n) { rows.push([n.date, n.customerName || n.title || '', n.phone || '', n.productId ? U.prodName(n.productId) : '', n.qty || '', n.expectedDate || '', n.isOrder ? t('ns_' + n.status) : '', n.text || '']); });
    csv('khaldi_notes_' + K.today() + '.csv', rows);
  };
  X.notef = function (el) { S.noteF = el.dataset.id; U.render(true); };
  X.notesort = function (el) { S.noteSort = el.dataset.id; U.render(true); };
  X.note_invoice = function (el) { F.noteToInvoice(el.dataset.id); };
  X.note_view_invoice = function (el) { U.go('invoice', el.dataset.id); };

  /* ================= assistant (offline, rule-based, real data only) ================= */
  function actx() { return { K: K, lang: U.lang(), money: U.moneyTxt, qty: K.fmtQty, date: K.fmtDate, catName: function (c) { return U.catName(c.id); } }; }
  function bubbleA(m) {
    return '<div class="chatbubble a">' + m.blocks.map(function (b) {
      return (b.h ? '<h4>' + esc(b.h) + '</h4>' : '') + b.rows.map(function (r) { return '<div class="cr"><span>' + esc(r[0]) + '</span><b><bdi dir="auto">' + esc(r[1]) + '</bdi></b></div>'; }).join('') + (b.text ? '<div class="' + (b.h || b.rows.length ? 'muted' : '') + '" style="margin-top:4px">' + esc(b.text) + '</div>' : '');
    }).join('') + '</div>';
  }
  W.assistant = function () {
    var A = window.KPAssistant, h = '<div class="chat">';
    h += '<div class="chatbubble a">' + esc(A.hello(U.lang())) + '</div>';
    S.chat.forEach(function (m) { h += m.role === 'u' ? '<div class="chatbubble u">' + esc(m.text) + '</div>' : bubbleA(m); });
    h += '</div><div class="chips">' + A.suggestions(U.lang()).map(function (q) { return '<button class="chip" data-act="chat_chip" data-q="' + esc(q) + '">' + esc(q) + '</button>'; }).join('') + '</div>';
    if (S.chat.length) h += '<button class="btn sm ghost block" data-act="chat_clear">' + t('chat_clear') + '</button>';
    h += '<div class="chatbar"><input id="chatq" type="text" autocomplete="off" placeholder="' + esc(t('chat_ph')) + '"><button data-act="chat_send" aria-label="' + esc(t('send')) + '">' + V.icon('send', 22) + '</button></div><div class="muted" style="text-align:center;margin-top:8px">' + t('chat_note') + '</div>';
    return h;
  };
  function ask(q) {
    q = String(q || '').trim(); if (!q) return;
    var r; try { r = window.KPAssistant.ask(U.D, q, actx()); } catch (e) { r = { blocks: [{ h: '', rows: [], text: t('chat_error') }] }; }
    S.chat.push({ role: 'u', text: q }); S.chat.push({ role: 'a', blocks: r.blocks }); S.chatScroll = true; U.render();
  }
  X.chat_send = function () { var el = U.$('#chatq'); if (el) ask(el.value); };
  X.chat_chip = function (el) { ask(el.dataset.q); };
  X.chat_clear = function () { S.chat = []; U.render(true); };
  U.afterRender = function (R) {
    if (R !== 'assistant') return;
    var el = U.$('#chatq'); if (el) el.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); X.chat_send(); } };
    if (S.chatScroll) { S.chatScroll = false; var m = U.$('#main'); m.scrollTop = m.scrollHeight; }
  };

  /* ================= customise: shortcuts, icons, window (section) order ================= */
  W.customize = function () {
    var h = '<div class="alert blue">' + t('customize_help') + '</div>';
    h += '<button class="btn block" data-act="wd_edit_go" style="margin-bottom:12px">' + V.icon('edit', 18) + ' ' + t('edit_home_btn') + '</button>';
    var gon = !(U.D.settings.gestures === false);
    h += '<div class="cz-row' + (gon ? '' : ' off') + '"><button class="tl" data-act="cz_gest" aria-label="' + t('gestures') + '">' + V.icon(gon ? 'eye' : 'eyeoff', 20) + '</button><div class="nm">' + esc(t('gestures')) + '<div class="muted" style="font-size:12px;font-weight:400">' + t('gestures_help') + '</div></div></div>';
    h += U.sec(t('home_sections'));
    h += SECW.map(function (id) { var off = secHidden(id); return '<div class="cz-row' + (off ? ' off' : '') + '"><button class="tl" data-act="cz_sec_toggle" data-id="' + id + '" aria-label="' + t('show_hide') + '">' + V.icon(off ? 'eyeoff' : 'eye', 20) + '</button><div class="nm">' + esc(t(SECL[id])) + '</div></div>'; }).join('');
    h += U.sec(t('shortcuts_title')) + '<div class="muted" style="margin:0 2px 8px">' + t('shortcuts_help') + '</div>';
    var o = scOrdered();
    h += o.map(function (id, i) {
      var off = scHidden(id);
      return '<div class="cz-row' + (off ? ' off' : '') + '"><button class="tl" data-act="cz_toggle" data-id="' + id + '" aria-label="' + t('show_hide') + '">' + V.icon(off ? 'eyeoff' : 'eye', 20) + '</button><button class="tl" data-act="cz_icon" data-id="' + id + '" aria-label="' + t('change_icon') + '">' + V.tile(iconOf(id), 30) + '</button><div class="nm">' + esc(t(LBL[id])) + '</div><button class="mb" data-act="cz_up" data-id="' + id + '"' + (i === 0 ? ' disabled' : '') + '>' + V.icon('up', 20) + '</button><button class="mb" data-act="cz_down" data-id="' + id + '"' + (i === o.length - 1 ? ' disabled' : '') + '>' + V.icon('down', 20) + '</button></div>';
    }).join('');
    return h + '<button class="btn danger-o block" data-act="cz_reset">' + V.icon('undo', 18) + ' ' + t('reset_layout') + '</button>';
  };
  X.wd_edit_go = function () { S.homeEdit = true; U.stack = []; U.route = 'home'; U.arg = null; U.render(); U.$('#main').scrollTop = 0; };
  X.cz_gest = function () { U.commit(function (d) { d.settings.gestures = d.settings.gestures === false; }); U.render(true); };
  X.cz_up = function (el) { saveLayout(function (l) { move(l.order, el.dataset.id, -1); }); };
  X.cz_down = function (el) { saveLayout(function (l) { move(l.order, el.dataset.id, 1); }); };
  X.cz_toggle = function (el) { saveLayout(function (l) { toggle(l.hidden, el.dataset.id); }); };
  X.cz_sec_up = function (el) { saveLayout(function (l) { move(l.secOrder, el.dataset.id, -1); }); };
  X.cz_sec_down = function (el) { saveLayout(function (l) { move(l.secOrder, el.dataset.id, 1); }); };
  X.cz_sec_toggle = function (el) { saveLayout(function (l) { toggle(l.secHidden, el.dataset.id); }); };
  X.cz_icon = function (el) {
    var id = el.dataset.id, cur = iconOf(id);
    U.showModal('<h3>' + t('change_icon') + ': ' + esc(t(LBL[id])) + '</h3><div class="iconpick">' + V.tileNames().map(function (n) { return '<button class="' + (n === cur ? 'on' : '') + '" data-act="cz_seticon" data-id="' + id + '" data-icon="' + n + '">' + V.tile(n, 34) + '<span>' + esc(LBL[n] ? t(LBL[n]) : n) + '</span></button>'; }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
  };
  X.cz_seticon = function (el) { var id = el.dataset.id, ic = el.dataset.icon; U.closeModal(); saveLayout(function (l) { if (ic === id) delete l.icons[id]; else l.icons[id] = ic; }); };
  X.cz_reset = function () { U.confirmBox(t('reset_layout'), t('reset_layout_q'), t('reset'), function () { U.commit(function (d) { d.settings.layout = { hidden: [], order: [], icons: {}, secOrder: [], secHidden: [], wOrder: [], sizes: {} }; }); U.render(true); U.toast(t('saved_ok'), 'ok'); }, true); };

  /* ================= more: every section, in the user's order ================= */
  W.more = function () {
    var h = '<div class="tiles">' + scOrdered().map(tileBtn).join('') + '</div>';
    return h + '<div class="card" style="margin-top:14px"><div class="row tap" data-act="goto" data-id="settings"><div class="ibox">' + V.icon('settings', 22) + '</div><div class="main"><div class="t">' + t('v_settings') + '</div></div>' + V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 20) + '</div></div>';
  };
})();
