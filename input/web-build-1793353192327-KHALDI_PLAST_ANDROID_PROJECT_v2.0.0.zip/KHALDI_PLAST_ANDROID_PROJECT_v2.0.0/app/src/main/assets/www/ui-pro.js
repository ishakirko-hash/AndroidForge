/* KHALDI PLAST v2.0 - professional modules: quotes, customer statement, collection centre, daily close, cash book,
   raw-material forecast, stocktake, machine maintenance, smart insights, PIN lock. Pure UI over core2.js (all numbers come from real data). */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, $ = U.$, W = U.views, F = U.forms, X = U.extraActions, S = U.S;
  function B(v) { return '<bdi class="num" dir="ltr">' + v + '</bdi>'; }
  function today() { return K.today(); }
  function chev() { return V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 20); }
  function share(txt) {
    if (U.AND && U.AND.shareText) U.AND.shareText(txt);
    else if (navigator.share) navigator.share({ text: txt }).catch(function () {});
    else if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { U.toast(t('copied'), 'ok'); });
  }
  function printNow(name) { setTimeout(function () { if (U.AND && U.AND.printPage) U.AND.printPage(name); else window.print(); }, 150); }
  function csvFile(name, rows) { U.saveFile(name, 'text/csv', '﻿' + rows.map(function (r) { return r.map(U.csvEscape).join(','); }).join('\r\n')); }
  function plain(c) { return K.fmtMoney(c) + ' ' + t('dzd'); }
  function safe(s) { return String(s || '').replace(/[^\w؀-ۿ-]+/g, '_').slice(0, 40); }
  function head(title, sub) {
    var st = U.D.settings;
    return '<div class="rpt-h"><img src="img/logo_full.png" alt="KHALDI PLAST"><div class="rpt-t"><b>' + esc(title) + '</b><span>' + sub + '</span></div></div><div class="rpt-co">' + esc(st.address) + ' · <bdi class="num">' + esc(st.phone) + '</bdi></div>';
  }
  function tbl(cols, rows, foot) {
    return '<div class="tablewrap"><table class="rpt-tb"><thead><tr>' + cols.map(function (c) { return '<th' + (c[1] ? ' class="' + c[1] + '"' : '') + '>' + esc(c[0]) + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody>' + (foot ? '<tfoot>' + foot + '</tfoot>' : '') + '</table></div>';
  }
  function stat(label, val, cls) { return '<div><small>' + esc(label) + '</small><b class="' + (cls || '') + '">' + val + '</b></div>'; }
  function bar(btn, label, act, id, cls, ic) { return '<button class="btn ' + (cls || '') + '" data-act="' + act + '"' + (id != null ? ' data-id="' + id + '"' : '') + '>' + (ic ? V.icon(ic, 18) + ' ' : '') + esc(label) + '</button>'; }
  function dateBar(act, value) { return '<div class="datebar noprint"><label>' + esc(t('date')) + '</label><input type="date" id="proDate" data-for="' + act + '" value="' + esc(value) + '"></div>'; }

  /* ================= smart insights ================= */
  var ROUTE_OK = { reports: 1, customers: 1, sales: 1, collect: 1, forecast: 1, production: 1, prodtable: 1, maintenance: 1, stock: 1, backup: 1, quotes: 1 };
  U.insightText = function (x) {
    var p = {}; Object.keys(x.params || {}).forEach(function (k) { p[k] = x.params[k]; });
    if (x.id === 'best_day') p.day = t('p_dow' + p.dow);
    if (p.amount != null) p.amount = plain(p.amount);
    return t('ins_' + x.id, p);
  };
  W.insights = function () {
    var list = K.insights(U.D, today()), h = '';
    h += '<div class="muted" style="margin:0 2px 10px">' + esc(t('ins_help')) + '</div>';
    if (!list.length) return h + '<div class="card">' + U.empty(t('ins_none'), 'bulb') + '</div>';
    return h + '<div class="card">' + list.map(function (x) {
      var go = ROUTE_OK[x.route] ? ' tap" data-act="ins_go" data-id="' + x.route : '';
      return '<div class="row' + go + '"><div class="ibox ' + (x.tone === 'red' ? 'red' : x.tone === 'green' ? 'green' : x.tone === 'amber' ? 'amber' : '') + '">' + V.icon(x.icon, 22) + '</div><div class="main"><div class="t">' + esc(U.insightText(x)) + '</div></div>' + (go ? chev() : '') + '</div>';
    }).join('') + '</div>';
  };
  X.ins_go = function (el) { var r = el.dataset.id; if (r === 'sales' || r === 'stock' || r === 'production') { U.stack = []; U.route = r; U.arg = null; U.render(); } else { if (r === 'reports') S.repTab = 'month'; U.go(r); } };

  /* ================= quotations ================= */
  function qNo(q) { return 'DV-' + String(q.date).slice(0, 4) + '-' + ('000000' + q.no).slice(-6); }
  function qWho(q) { if (q.customerId) { var c = K.byId(U.D.customers, q.customerId); return c ? c.name : t('walkin'); } return q.customerName || t('walkin'); }
  function qSale(q) { return { id: 'quote:' + q.id, no: q.no, date: q.date, customerId: q.customerId, items: q.items, subtotal: q.subtotal, discount: q.discount, total: q.total, notes: q.notes || '', voided: false, delivery: {} }; }
  function qState(q) { return K.quoteState(q, today()); }
  function qBadge(st) { return U.badge(t('qs_' + st), { open: '', expired: 'amber', converted: 'green', 'void': 'gray' }[st]); }
  W.quotes = function () {
    var D = U.D, f = S.qF || 'open', all = U.newest((D.quotes || []).filter(function (q) { return !q.voided; })), n = { open: 0, expired: 0, converted: 0 };
    all.forEach(function (q) { n[qState(q)]++; });
    var list = all.filter(function (q) { return f === 'all' || qState(q) === f; }), h = '';
    h += '<div class="btns"><button class="btn primary" data-act="quote_new">' + V.icon('plus', 18) + ' ' + t('p_new_quote') + '</button></div>';
    h += U.chips([['open', t('qs_open') + ' (' + n.open + ')'], ['expired', t('qs_expired') + ' (' + n.expired + ')'], ['converted', t('qs_converted') + ' (' + n.converted + ')'], ['all', t('p_all')]], f, 'quote_f');
    if (!list.length) return h + '<div class="card">' + U.empty(t('p_no_quotes'), 'note') + '</div>';
    return h + '<div class="card">' + list.map(function (q) {
      var st = qState(q);
      return '<div class="row tap" data-act="goto" data-id="quote" data-arg="' + q.id + '"><div class="ibox">' + V.icon('note', 22) + '</div><div class="main"><div class="t">' + esc(qWho(q)) + '</div><div class="s">' + B(qNo(q)) + ' · ' + U.dt(q.date) + '</div><div style="margin-top:3px">' + qBadge(st) + '</div></div><div class="r">' + U.money(q.total) + '</div></div>';
    }).join('') + '</div>';
  };
  X.quote_f = function (el) { S.qF = el.dataset.id; U.render(true); };
  W.quote = function (id) {
    var q = K.byId(U.D.quotes || [], id); if (!q) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    var st = qState(q), vu = q.validUntil ? '<div class="mr"><span>' + t('p_valid_until') + ' :</span><bdi class="num">' + esc(K.fmtDate(q.validUntil)) + '</bdi><i class="mi">' + V.icon('clock', 15) + '</i></div>' : '';
    var meta = vu + '<div class="mr"><span>' + t('p_status') + ' :</span><em class="pill ' + (st === 'converted' ? 'ok' : st === 'expired' ? 'warn' : 'ok') + '">' + t('qs_' + st) + '</em><i class="mi ok">' + V.icon('check', 15) + '</i></div>';
    var h = U.invoiceHtml(qSale(q), { title: t('p_quote'), no: qNo(q), meta: meta, customer: qWho(q) });
    h += '<div class="btns noprint">';
    if (st !== 'converted') h += '<button class="btn primary" data-act="quote_convert" data-id="' + q.id + '">' + V.icon('check', 18) + ' ' + t('p_convert') + '</button><button class="btn" data-act="quote_edit" data-id="' + q.id + '">' + V.icon('edit', 18) + ' ' + t('edit') + '</button>';
    else h += '<button class="btn primary" data-act="goto" data-id="invoice" data-arg="' + q.saleId + '">' + V.icon('note', 18) + ' ' + t('p_open_invoice') + '</button>';
    h += '<button class="btn" data-act="print_quote">' + V.icon('print', 18) + ' ' + t('p_print') + '</button>';
    if (st !== 'converted') h += '<button class="btn danger-o" data-act="quote_void" data-id="' + q.id + '">' + V.icon('trash', 18) + ' ' + t('p_cancel_quote') + '</button>';
    return h + '</div>';
  };
  function quoteText(q) {
    var D = U.D, st = D.settings;
    return 'KHALDI PLAST\n' + t('p_quote') + ' ' + qNo(q) + '\n' + t('date') + ': ' + K.fmtDate(q.date) + (q.validUntil ? '\n' + t('p_valid_until') + ': ' + K.fmtDate(q.validUntil) : '') + '\n' + t('customer') + ': ' + qWho(q) + '\n' +
      q.items.map(function (i) { return '- ' + U.prodName(i.productId) + ' x' + i.qty + ' @ ' + K.fmtMoney(i.unitPrice) + ' = ' + K.fmtMoney(i.qty * i.unitPrice); }).join('\n') + '\n' +
      (q.discount ? t('discount') + ': ' + plain(q.discount) + '\n' : '') + t('grand_total') + ': ' + plain(q.total) + '\n' + st.address + ' - ' + st.phone;
  }
  X.share_quote = function () { var q = K.byId(U.D.quotes || [], U.arg); if (q) share(quoteText(q)); };
  X.print_quote = function () { var q = K.byId(U.D.quotes || [], U.arg); if (q) printNow('KHALDI_PLAST_' + qNo(q)); };
  X.quote_new = function () { F.quote(); };
  X.quote_edit = function (el) { F.quote(el.dataset.id); };
  X.quote_void = function (el) {
    var id = el.dataset.id;
    U.confirmBox(t('p_cancel_quote'), t('p_cancel_quote_q'), t('p_cancel_quote'), function () { U.commit(function (d) { K.voidQuote(d, id); }); U.toast(t('saved_ok'), 'ok'); U.back(); }, true);
  };
  X.quote_convert = function (el) {
    var q = K.byId(U.D.quotes || [], el.dataset.id); if (!q) return;
    var fields = [{ name: 'date', label: t('date'), type: 'date', value: today() }, { name: 'paid', label: t('amount_paid'), type: 'money', optional: true }, { name: 'method', label: t('pay_method'), type: 'select', options: U.methodOptions() }];
    U.openForm({
      title: t('p_convert') + ' ' + qNo(q), intro: esc(t('p_convert_help')) + '<br><b>' + U.moneyTxt(q.total) + '</b>', submit: t('p_convert'), fields: fields,
      extra: [{ label: t('paid_full'), run: function (f) { f.elements.paid.value = U.forInput(q.total); } }, { label: t('paid_none'), run: function (f) { f.elements.paid.value = ''; } }],
      onSubmit: function (v) {
        var paid = U.parseM(v.paid, false), sid = null;
        U.commit(function (d) { sid = K.convertQuote(d, q.id, { date: v.date, paid: paid, method: v.method }).id; });
        U.closeModal(); U.toast(t('saved_ok'), 'ok'); U.go('invoice', sid, true);
      }
    });
  };
  F.quote = function (editId) {
    var D = U.D, q = editId ? K.byId(D.quotes, editId) : null, prods = D.products.filter(function (p) { return !p.archived || (q && q.items.some(function (i) { return i.productId === p.id; })); });
    if (!prods.length) { U.toast(t('err_no_product'), 'bad'); return; }
    var rows = q ? q.items.map(function (it) { return { product: it.productId, qty: String(it.qty), price: U.forInput(it.unitPrice), weight: '' }; }) : [{ product: prods[0].id, qty: '', price: U.forInput(prods[0].price), weight: '' }];
    var opts = [{ v: '', l: t('walkin') }].concat(U.act(D.customers, q && q.customerId).map(function (c) { return { v: c.id, l: c.name + (c.phone ? ' - ' + c.phone : '') }; }));
    var fields = [
      { name: 'date', label: t('date'), type: 'date', value: q ? q.date : today() },
      { name: 'customer', label: t('customer'), type: 'select', options: opts, value: q ? (q.customerId || '') : '' },
      { name: 'cname', label: t('p_prospect_name'), type: 'text', optional: true, value: q ? q.customerName : '' },
      { name: 'valid', label: t('p_valid_until'), type: 'date', optional: true, value: q ? q.validUntil : K.addDays(today(), 15) },
      { name: 'items', label: t('invoice_items'), type: 'items', rows: rows, products: prods },
      { name: 'discount', label: t('discount'), type: 'money', optional: true, value: q ? U.forInput(q.discount) : '' },
      { name: 'notes', label: t('notes'), type: 'textarea', optional: true, value: q ? q.notes : '' }
    ];
    function items(v) { return v.items.map(function (r) { return { productId: r.product, qty: U.parseQ(r.qty, false, true), unitPrice: U.parseM(r.price, true), weightG: 0 }; }); }
    U.openForm({
      title: q ? t('edit') + ' ' + qNo(q) : t('p_new_quote'), submit: q ? t('save_changes') : t('save'), fields: fields,
      calc: function (v) {
        try { var it = items(v), sub = K.sum(it, function (x) { return x.qty * x.unitPrice; }), ds = U.parseM(v.discount, false); return t('subtotal') + ': <b>' + U.money(sub) + '</b><br>' + t('grand_total') + ': <b>' + U.money(sub - ds) + '</b>'; } catch (e) { return ''; }
      },
      onSubmit: function (v) {
        var o = { date: v.date, customerId: v.customer || null, customerName: v.cname, items: items(v), discount: U.parseM(v.discount, false), validUntil: v.valid, notes: v.notes }, nid = null;
        U.commit(function (d) { if (q) K.editQuote(d, q.id, o); else nid = K.addQuote(d, o).id; });
        U.closeModal(); U.toast(t('saved_ok'), 'ok');
        if (nid) U.go('quote', nid); else U.render(true);
      }
    });
  };

  /* ================= customer statement ================= */
  function stRange() { var to = today(), p = S.stP || '90'; return { from: p === 'all' ? '2000-01-01' : K.addDays(to, -Number(p)), to: to }; }
  function stDesc(l) { return l.type === 'sale' ? t('sale_invoice') + ' ' + U.invNo(l.no) : t('p_payment') + ' (' + U.methodLabel(l.method) + ')'; }
  function stData(id) { var r = stRange(); return K.customerStatement(U.D, id, r.from, r.to); }
  W.statement = function (id) {
    var st; try { st = stData(id); } catch (e) { return '<div class="card">' + U.empty(U.errMsg(e)) + '</div>'; }
    var c = st.customer, p = S.stP || '90', h = '';
    h += U.chips([['30', t('p_30d')], ['90', t('p_90d')], ['365', t('p_1y')], ['all', t('p_all')]], p, 'st_p');
    h += '<div class="rpt">' + head(t('p_statement'), esc(c.name) + (p === 'all' ? '' : ' · ' + B(K.fmtDate(st.from) + ' → ' + K.fmtDate(st.to)))) +
      '<div class="rpt-kv"><span>' + t('phone') + '</span><b>' + (c.phone ? B(esc(c.phone)) : '—') + '</b></div>' +
      '<div class="rpt-kv"><span>' + t('p_opening') + '</span><b>' + U.money(st.opening) + '</b></div>' +
      tbl([[t('date')], [t('description')], [t('p_debit'), 'n'], [t('p_credit'), 'n'], [t('balance'), 'n']],
        st.lines.map(function (l) { return '<tr><td>' + U.dt(l.date) + '</td><td>' + esc(stDesc(l)) + '</td><td class="n">' + (l.debit ? B(K.fmtMoney(l.debit)) : '') + '</td><td class="n">' + (l.credit ? B(K.fmtMoney(l.credit)) : '') + '</td><td class="n"><b>' + B(K.fmtMoney(l.balance)) + '</b></td></tr>'; }),
        '<tr><td colspan="2"><b>' + t('total') + '</b></td><td class="n"><b>' + B(K.fmtMoney(st.totalDebit)) + '</b></td><td class="n"><b>' + B(K.fmtMoney(st.totalCredit)) + '</b></td><td></td></tr>') +
      '<div class="rpt-sum ' + (st.closing > 0 ? 'bad' : 'ok') + '"><span>' + t('p_closing') + '</span><b>' + U.money(st.closing) + '</b></div></div>';
    if (!st.lines.length) h += '<div class="card noprint">' + U.empty(t('no_records')) + '</div>';
    h += '<div class="btns noprint"><button class="btn primary" data-act="st_print">' + V.icon('print', 18) + ' ' + t('p_print') + '</button><button class="btn" data-act="st_share">' + V.icon('share', 18) + ' ' + t('share') + '</button><button class="btn" data-act="st_csv">' + V.icon('download', 18) + ' CSV</button></div>';
    if (st.closing > 0) h += '<div class="btns noprint"><button class="btn" data-act="remind" data-id="' + c.id + '">' + V.icon('send', 18) + ' ' + t('p_remind') + '</button><button class="btn" data-act="pay_party" data-kind="customer" data-id="' + c.id + '">' + t('receive_payment') + '</button></div>';
    return h;
  };
  X.go_statement = function (el) { U.go('statement', el.dataset.id); };
  X.st_p = function (el) { S.stP = el.dataset.id; U.render(true); };
  X.st_print = function () { var c = K.byId(U.D.customers, U.arg); printNow('KHALDI_PLAST_STATEMENT_' + safe(c && c.name)); };
  X.st_share = function () {
    U.run(function () {
      var st = stData(U.arg), txt = 'KHALDI PLAST - ' + t('p_statement') + '\n' + st.customer.name + '\n' + K.fmtDate(st.from) + ' → ' + K.fmtDate(st.to) + '\n' + t('p_opening') + ': ' + plain(st.opening) + '\n' +
        st.lines.map(function (l) { return K.fmtDate(l.date) + ' | ' + stDesc(l) + ' | ' + (l.debit ? '+' + K.fmtMoney(l.debit) : '-' + K.fmtMoney(l.credit)) + ' | ' + K.fmtMoney(l.balance); }).join('\n') + '\n' + t('p_closing') + ': ' + plain(st.closing) + '\n' + U.D.settings.phone;
      share(txt);
    });
  };
  X.st_csv = function () {
    U.run(function () {
      var st = stData(U.arg), rows = [[t('date'), t('description'), t('p_debit'), t('p_credit'), t('balance')], [K.fmtDate(st.from), t('p_opening'), '', '', K.fmtMoney(st.opening)]];
      st.lines.forEach(function (l) { rows.push([K.fmtDate(l.date), stDesc(l), l.debit ? K.fmtMoney(l.debit) : '', l.credit ? K.fmtMoney(l.credit) : '', K.fmtMoney(l.balance)]); });
      rows.push([K.fmtDate(st.to), t('p_closing'), K.fmtMoney(st.totalDebit), K.fmtMoney(st.totalCredit), K.fmtMoney(st.closing)]);
      csvFile('statement_' + safe(st.customer.name) + '_' + st.to + '.csv', rows);
    });
  };

  /* ================= collection centre ================= */
  var BCLS = ['b0', 'b1', 'b2', 'b3'];
  W.collect = function () {
    var ag = K.ageingReport(U.D, today()), f = S.colF || 'all', rows = ag.rows.filter(function (r) { return f === 'all' || r.buckets[1] + r.buckets[2] + r.buckets[3] > 0; }), h = '';
    h += '<div class="statgrid">' + stat(t('p_b0'), U.money(ag.totals[0])) + stat(t('p_b1'), U.money(ag.totals[1]), ag.totals[1] ? 'down' : '') + stat(t('p_b2'), U.money(ag.totals[2]), ag.totals[2] ? 'down' : '') + stat(t('p_b3'), U.money(ag.totals[3]), ag.totals[3] ? 'down' : '') + stat(t('p_total_due'), U.money(ag.total), 'down') + stat(t('col_overdue'), U.money(ag.overdue), ag.overdue ? 'down' : 'up') + '</div>';
    h += U.chips([['all', t('p_all')], ['over', t('col_overdue')]], f, 'col_f');
    if (!rows.length) return h + '<div class="card">' + U.empty(t('col_none'), 'check') + '</div>';
    return h + rows.map(function (r) {
      var tot = r.balance || 1;
      return '<div class="card cc"><div class="cc-top"><div class="cc-n"><b>' + esc(r.customer.name) + '</b><span>' + (r.customer.phone ? B(esc(r.customer.phone)) : '') + '</span></div><div class="cc-a">' + U.money(r.balance) + '</div></div>' +
        '<div class="cc-bar">' + r.buckets.map(function (v, i) { return v ? '<i class="' + BCLS[i] + '" style="width:' + Math.max(3, Math.round(v * 100 / tot)) + '%"></i>' : ''; }).join('') + '</div>' +
        '<div class="cc-meta">' + (r.oldest ? U.badge(t('col_oldest', { n: r.oldest }), r.oldest > 60 ? 'red' : r.oldest > 30 ? 'amber' : '') : '') + '<span>' + t('col_last_pay') + ': ' + (r.lastPayment ? U.dt(r.lastPayment) : '—') + '</span></div>' +
        '<div class="btns"><button class="btn sm primary" data-act="remind" data-id="' + r.customer.id + '">' + V.icon('send', 16) + ' ' + t('p_remind') + '</button><button class="btn sm" data-act="pay_party" data-kind="customer" data-id="' + r.customer.id + '">' + t('receive_payment') + '</button><button class="btn sm ghost" data-act="go_statement" data-id="' + r.customer.id + '">' + t('p_statement') + '</button></div></div>';
    }).join('');
  };
  X.col_f = function (el) { S.colF = el.dataset.id; U.render(true); };
  X.remind = function (el) {
    var c = K.byId(U.D.customers, el.dataset.id); if (!c) return;
    var bal = K.customerBalance(U.D, c.id), msg = t('p_remind_msg', { name: c.name, amount: plain(bal), phone: U.D.settings.phone });
    U.openForm({ title: t('p_remind'), intro: esc(t('p_remind_help')), fields: [{ name: 'msg', label: t('p_message'), type: 'textarea', value: msg }], submit: t('share'), onSubmit: function (v) { share(v.msg); U.closeModal(); } });
    var ta = document.querySelector('#f textarea'); if (ta) ta.rows = 7;
  };

  /* ================= daily close ================= */
  function dcText(c) {
    var lines = ['KHALDI PLAST - ' + t('tile_dailyclose') + ' ' + K.fmtDate(c.day), '', t('p_sales') + ': ' + c.salesCount + ' · ' + plain(c.salesTotal), t('p_collected') + ': ' + plain(c.collected)];
    Object.keys(c.byMethod).forEach(function (m) { lines.push('  ' + U.methodLabel(m) + ': ' + plain(c.byMethod[m])); });
    lines.push(t('p_unpaid_today') + ': ' + plain(c.unpaidToday), t('expenses') + ': ' + plain(c.expenses), t('purchases') + ': ' + plain(c.purchases), t('p_supplier_paid') + ': ' + plain(c.supplierPaid),
      t('p_good') + ': ' + K.groupInt(c.good) + ' · ' + t('p_defect') + ': ' + K.groupInt(c.defective), t('p_cash_net') + ': ' + plain(c.cashNet));
    return lines.join('\n');
  }
  W.dailyclose = function () {
    var day = S.dcDay || today(), c; try { c = K.dailyClose(U.D, day); } catch (e) { return '<div class="card">' + U.empty(U.errMsg(e)) + '</div>'; }
    var h = U.chips([['t', t('p_today')], ['y', t('p_yesterday')]], day === today() ? 't' : day === K.addDays(today(), -1) ? 'y' : '', 'dc_set') + dateBar('dc', day);
    var prodRows = Object.keys(c.production).map(function (pid) { return '<div class="rpt-kv"><span>' + esc(U.prodName(pid)) + '</span><b>' + B(K.groupInt(c.production[pid].good)) + (c.production[pid].defective ? ' <small class="down">(' + t('p_defect') + ' ' + B(K.groupInt(c.production[pid].defective)) + ')</small>' : '') + '</b></div>'; }).join('');
    h += '<div class="rpt">' + head(t('tile_dailyclose'), B(K.fmtDate(day))) +
      '<div class="rpt-blk"><h4>' + t('p_sales') + '</h4><div class="rpt-kv"><span>' + t('p_invoices') + '</span><b>' + B(c.salesCount) + '</b></div><div class="rpt-kv"><span>' + t('p_crates') + '</span><b>' + B(K.groupInt(c.crates)) + '</b></div><div class="rpt-kv"><span>' + t('total') + '</span><b>' + U.money(c.salesTotal) + '</b></div><div class="rpt-kv"><span>' + t('p_unpaid_today') + '</span><b>' + U.money(c.unpaidToday) + '</b></div></div>' +
      '<div class="rpt-blk"><h4>' + t('p_collected') + '</h4>' + (Object.keys(c.byMethod).map(function (m) { return '<div class="rpt-kv"><span>' + U.methodLabel(m) + '</span><b>' + U.money(c.byMethod[m]) + '</b></div>'; }).join('') || '<div class="rpt-kv"><span>—</span></div>') + '<div class="rpt-kv"><span>' + t('total') + '</span><b>' + U.money(c.collected) + '</b></div></div>' +
      '<div class="rpt-blk"><h4>' + t('p_outflow') + '</h4><div class="rpt-kv"><span>' + t('expenses') + ' (' + c.expenseCount + ')</span><b>' + U.money(c.expenses) + '</b></div><div class="rpt-kv"><span>' + t('purchases') + '</span><b>' + U.money(c.purchases) + '</b></div><div class="rpt-kv"><span>' + t('p_supplier_paid') + '</span><b>' + U.money(c.supplierPaid) + '</b></div></div>' +
      '<div class="rpt-blk"><h4>' + t('tile_production') + '</h4>' + (prodRows || '<div class="rpt-kv"><span>—</span></div>') + '</div>' +
      '<div class="rpt-sum ' + (c.cashNet >= 0 ? 'ok' : 'bad') + '"><span>' + t('p_cash_net') + '</span><b>' + U.money(c.cashNet) + '</b></div><div class="rpt-note">' + t('p_cash_note') + '</div></div>';
    h += '<div class="btns noprint"><button class="btn primary" data-act="dc_print">' + V.icon('print', 18) + ' ' + t('p_print') + '</button><button class="btn" data-act="dc_share">' + V.icon('share', 18) + ' ' + t('share') + '</button></div>';
    return h;
  };
  X.dc_set = function (el) { S.dcDay = el.dataset.id === 'y' ? K.addDays(today(), -1) : today(); U.render(true); };
  X.dc_print = function () { printNow('KHALDI_PLAST_CLOSE_' + (S.dcDay || today())); };
  X.dc_share = function () { U.run(function () { share(dcText(K.dailyClose(U.D, S.dcDay || today()))); }); };

  /* ================= cash book ================= */
  var CBK = { in_customer: 'p_cb_in_customer', out_expense: 'p_cb_out_expense', out_supplier: 'p_cb_out_supplier' };
  function cbWho(l) {
    var D = U.D;
    if (l.type === 'in_customer') return U.custName(l.who);
    if (l.type === 'out_supplier') { var s = K.byId(D.suppliers, l.who); return s ? s.name : ''; }
    return l.text || '';
  }
  W.cashbook = function () {
    var r = K.monthRange(S.ym), cb = K.cashBook(U.D, r.from, r.to), h = U.monthbar();
    h += '<div class="statgrid">' + stat(t('p_opening'), U.money(cb.opening)) + stat(t('p_cash_in'), U.money(cb.totalIn), 'up') + stat(t('p_cash_out'), U.money(cb.totalOut), 'down') + stat(t('p_closing'), U.money(cb.closing)) + '</div>';
    if (!cb.lines.length) return h + '<div class="card">' + U.empty(t('no_records'), 'wallet') + '</div>' + '<div class="rpt-note">' + t('p_cash_note') + '</div>';
    h += '<div class="rpt">' + head(t('tile_cashbook'), B(K.fmtDate(r.from) + ' → ' + K.fmtDate(r.to))) +
      tbl([[t('date')], [t('description')], [t('p_cash_in'), 'n'], [t('p_cash_out'), 'n'], [t('balance'), 'n']],
        cb.lines.map(function (l) { return '<tr><td>' + U.dt(l.date) + '</td><td>' + esc(t(CBK[l.type])) + (cbWho(l) ? ' · ' + esc(cbWho(l)) : '') + '</td><td class="n">' + (l.in ? B(K.fmtMoney(l.in)) : '') + '</td><td class="n">' + (l.out ? B(K.fmtMoney(l.out)) : '') + '</td><td class="n"><b>' + B(K.fmtMoney(l.balance)) + '</b></td></tr>'; }),
        '<tr><td colspan="2"><b>' + t('total') + '</b></td><td class="n"><b>' + B(K.fmtMoney(cb.totalIn)) + '</b></td><td class="n"><b>' + B(K.fmtMoney(cb.totalOut)) + '</b></td><td></td></tr>') +
      '<div class="rpt-note">' + t('p_cash_note') + '</div></div>';
    return h + '<div class="btns noprint"><button class="btn primary" data-act="cb_print">' + V.icon('print', 18) + ' ' + t('p_print') + '</button><button class="btn" data-act="cb_csv">' + V.icon('download', 18) + ' CSV</button></div>';
  };
  X.cb_print = function () { printNow('KHALDI_PLAST_CASHBOOK_' + S.ym); };
  X.cb_csv = function () {
    var r = K.monthRange(S.ym), cb = K.cashBook(U.D, r.from, r.to), rows = [[t('date'), t('description'), t('p_cash_in'), t('p_cash_out'), t('balance')], [K.fmtDate(r.from), t('p_opening'), '', '', K.fmtMoney(cb.opening)]];
    cb.lines.forEach(function (l) { rows.push([K.fmtDate(l.date), t(CBK[l.type]) + (cbWho(l) ? ' - ' + cbWho(l) : ''), l.in ? K.fmtMoney(l.in) : '', l.out ? K.fmtMoney(l.out) : '', K.fmtMoney(l.balance)]); });
    csvFile('cashbook_' + S.ym + '.csv', rows);
  };

  /* ================= raw-material forecast ================= */
  W.forecast = function () {
    var fc = K.materialForecast(U.D, today()), h = '<div class="muted" style="margin:0 2px 10px">' + esc(t('fc_help')) + '</div>';
    if (!fc.length) return h + '<div class="card">' + U.empty(t('no_records'), 'scale') + '</div>';
    var est = K.sum(fc, function (x) { return x.est || 0; }), need = fc.filter(function (x) { return x.suggested > 0; });
    if (need.length) h += '<div class="statgrid">' + stat(t('fc_to_buy'), B(need.length)) + stat(t('fc_est_cost'), U.money(est)) + '</div>';
    h += fc.map(function (x) {
      var m = x.material, cls = { critical: 'red', soon: 'amber', ok: 'green', nodata: 'gray' }[x.status];
      return '<div class="card fcc"><div class="cc-top"><div class="cc-n"><b>' + esc(m.name) + '</b><span>' + t('fc_stock') + ': ' + B(K.fmtQty(m.stock)) + ' ' + t('kg') + '</span></div>' + U.badge(x.cover == null ? t('fc_nodata') : t('fc_days', { n: Math.floor(x.cover) }), cls) + '</div>' +
        (x.cover == null ? '' : '<div class="rpt-kv"><span>' + t('fc_daily') + '</span><b>' + B(K.fmtQty(x.daily)) + ' ' + t('kg') + '</b></div><div class="rpt-kv"><span>' + t('fc_runout') + '</span><b>' + U.dt(x.runOut) + '</b></div>') +
        (x.suggested > 0 ? '<div class="rpt-kv"><span>' + t('fc_suggest') + '</span><b>' + B(K.groupInt(x.suggested)) + ' ' + t('kg') + (x.est != null ? ' · ' + U.money(x.est) : '') + '</b></div>' : '') + '</div>';
    }).join('');
    if (need.length) h += '<div class="btns"><button class="btn primary" data-act="fc_share">' + V.icon('share', 18) + ' ' + t('fc_share') + '</button></div>';
    return h;
  };
  X.fc_share = function () {
    var fc = K.materialForecast(U.D, today()).filter(function (x) { return x.suggested > 0; });
    share('KHALDI PLAST - ' + t('fc_list_title') + ' ' + K.fmtDate(today()) + '\n' + fc.map(function (x) { return '- ' + x.material.name + ': ' + K.groupInt(x.suggested) + ' ' + t('kg') + (x.est != null ? ' (~' + plain(x.est) + ')' : ''); }).join('\n'));
  };

  /* ================= stocktake ================= */
  W.stocktake = function () {
    var kind = S.stKind || 'material', D = U.D, list = U.act(kind === 'product' ? D.products : D.materials), h = '';
    h += '<div class="muted" style="margin:0 2px 10px">' + esc(t('stk_help')) + '</div>' + U.seg([['material', t('stk_materials')], ['product', t('stk_products')]], kind, 'stk_kind');
    if (!list.length) return h + '<div class="card">' + U.empty(t('no_records'), 'box') + '</div>';
    h += '<div class="card">' + list.map(function (x) {
      return '<div class="row stk"><div class="main"><div class="t">' + esc(x.name) + '</div><div class="s">' + t('stk_system') + ': ' + B(K.fmtQty(x.stock)) + '</div></div><input class="stk-in" inputmode="decimal" data-cnt="' + x.id + '" data-sys="' + x.stock + '" placeholder="' + esc(t('stk_counted')) + '"><span class="stk-d" data-d="' + x.id + '"></span></div>';
    }).join('') + '</div>';
    return h + '<div class="btns"><button class="btn primary" data-act="stk_apply">' + V.icon('check', 18) + ' ' + t('stk_apply') + '</button></div>';
  };
  X.stk_kind = function (el) { S.stKind = el.dataset.id; U.render(true); };
  function stkCounts() {
    var counts = {}, bad = false;
    [].forEach.call(document.querySelectorAll('input[data-cnt]'), function (el) {
      var v = el.value.trim(); if (!v) return;
      var r = K.parseQty(v, true); if (!r.ok) { bad = true; el.classList.add('bad'); return; }
      counts[el.getAttribute('data-cnt')] = String(r.q);
    });
    return bad ? null : counts;
  }
  X.stk_apply = function () {
    var counts = stkCounts(); if (!counts) { U.toast(t('err_bad_qty'), 'bad'); return; }
    if (!Object.keys(counts).length) { U.toast(t('stk_nothing'), 'bad'); return; }
    var kind = S.stKind || 'material';
    U.confirmBox(t('stk_apply'), t('stk_confirm', { n: Object.keys(counts).length }), t('stk_apply'), function () {
      var ch = [];
      try { U.commit(function (d) { ch = K.applyStocktake(d, { date: today(), kind: kind, counts: counts, note: t('stk_note') }); }); } catch (e) { U.toast(U.errMsg(e), 'bad'); return; }
      U.toast(t('stk_done', { n: ch.length }), 'ok'); U.render(true);
    });
  };

  /* ================= machine maintenance ================= */
  var MST = { overdue: 'red', soon: 'amber', never: 'gray', ok: 'green' };
  W.maintenance = function () {
    var ms = K.maintenanceStatus(U.D, today()), h = '<div class="muted" style="margin:0 2px 10px">' + esc(t('mnt_help')) + '</div>';
    if (!ms.length) return h + '<div class="card">' + U.empty(t('mnt_no_machines'), 'machine') + '</div>';
    h += ms.map(function (x) {
      return '<div class="card fcc"><div class="cc-top"><div class="cc-n"><b>' + esc(x.machine.name) + '</b><span>' + (x.last ? t('mnt_last') + ': ' + U.dt(x.last.date) : t('mnt_never')) + '</span></div>' + U.badge(t('mnt_s_' + x.status), MST[x.status]) + '</div>' +
        (x.nextDue ? '<div class="rpt-kv"><span>' + t('mnt_next') + '</span><b>' + U.dt(x.nextDue) + (x.daysTo != null ? ' <small>(' + (x.daysTo < 0 ? t('mnt_late', { n: -x.daysTo }) : t('mnt_in', { n: x.daysTo })) + ')</small>' : '') + '</b></div>' : '') +
        '<div class="btns"><button class="btn sm primary" data-act="mnt_add" data-id="' + x.machine.id + '">' + V.icon('plus', 16) + ' ' + t('mnt_log') + '</button></div></div>';
    }).join('');
    var recs = U.newest((U.D.maintenance || []).filter(function (r) { return !r.voided; })).slice(0, 15);
    if (recs.length) h += U.sec(t('mnt_history')) + '<div class="card">' + recs.map(function (r) {
      var m = K.byId(U.D.machines, r.machineId);
      return '<div class="row tap" data-act="mnt_rec" data-id="' + r.id + '"><div class="ibox ' + (r.kind === 'repair' ? 'red' : 'green') + '">' + V.icon('machine', 22) + '</div><div class="main"><div class="t">' + esc(m ? m.name : '') + ' · ' + t('mnt_k_' + r.kind) + '</div><div class="s">' + U.dt(r.date) + (r.note ? ' · ' + esc(r.note) : '') + '</div></div></div>';
    }).join('') + '</div>';
    return h;
  };
  X.mnt_add = function (el) {
    var mid = el.dataset.id, m = K.byId(U.D.machines, mid); if (!m) return;
    U.openForm({
      title: t('mnt_log') + ' - ' + m.name, submit: t('save'),
      fields: [{ name: 'date', label: t('date'), type: 'date', value: today() }, { name: 'kind', label: t('mnt_kind'), type: 'select', options: [{ v: 'preventive', l: t('mnt_k_preventive') }, { v: 'repair', l: t('mnt_k_repair') }] },
        { name: 'note', label: t('notes'), type: 'text', optional: true }, { name: 'next', label: t('mnt_next'), type: 'date', optional: true, value: K.addDays(today(), 30) }],
      onSubmit: function (v) { U.commit(function (d) { K.addMaintenance(d, { date: v.date, machineId: mid, kind: v.kind, note: v.note, nextDue: v.next }); }); U.closeModal(); U.toast(t('saved_ok'), 'ok'); U.render(true); }
    });
  };
  X.mnt_rec = function (el) {
    var id = el.dataset.id;
    U.confirmBox(t('mnt_void'), t('mnt_void_q'), t('mnt_void'), function () { U.commit(function (d) { K.voidMaintenance(d, id); }); U.toast(t('saved_ok'), 'ok'); U.render(true); }, true);
  };

  /* ================= PIN lock ================= */
  function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }
  var K256 = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
  function utf8(s) { return unescape(encodeURIComponent(s)); }
  function sha256(msg) {
    msg = utf8(msg); var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19], l = msg.length, w = new Array(64), i, j, words = [];
    for (i = 0; i < l; i++) words[i >> 2] |= msg.charCodeAt(i) << (24 - (i % 4) * 8);
    words[l >> 2] |= 0x80 << (24 - (l % 4) * 8); words[(((l + 8) >> 6) + 1) * 16 - 1] = l * 8;
    for (j = 0; j < words.length; j += 16) {
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (i = 0; i < 64; i++) {
        if (i < 16) w[i] = words[j + i] | 0; else { var s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0; }
        var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K256[i] + w[i]) | 0, S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = (S0 + mj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0; H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    return H.map(function (x) { return ('00000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
  }
  U.sha256 = sha256;
  function hashPin(pin, salt) { var h = salt + ':' + pin; for (var i = 0; i < 2000; i++) h = sha256(h + salt); return h; }
  function rnd(n) {
    var out = '', a;
    try { a = new Uint8Array(n); (window.crypto || window.msCrypto).getRandomValues(a); } catch (e) { a = null; }
    for (var i = 0; i < n; i++) out += (a ? a[i] % 10 : Math.floor(Math.random() * 10));
    return out;
  }
  function makePin(pin) { var salt = rnd(16), rc = rnd(10), rs = rnd(16); return { pin: { len: pin.length, salt: salt, hash: hashPin(pin, salt), rsalt: rs, rhash: hashPin(rc, rs) }, code: rc }; }
  function pinOk(pin) { var p = U.D.settings.pin; return !!p && hashPin(String(pin), p.salt) === p.hash; }
  var lockState = { buf: '', fails: 0, until: 0, mode: 'pin' };
  function lockEl() { return document.getElementById('lock'); }
  function lockDraw() {
    var el = lockEl(), p = U.D && U.D.settings.pin; if (!el || !p) return;
    var now = Date.now(), wait = lockState.until > now ? Math.ceil((lockState.until - now) / 1000) : 0, h = '<div class="lk-box"><img src="img/logo_full.png" alt="KHALDI PLAST">';
    if (lockState.mode === 'rec') {
      h += '<h2>' + esc(t('pin_recover')) + '</h2><p>' + esc(t('pin_recover_help')) + '</p><input id="lkRec" class="lk-rec" inputmode="numeric" autocomplete="off" placeholder="0000000000"><div class="lk-err" id="lkErr"></div>' +
        '<button class="btn primary block" data-lk="rec_ok">' + esc(t('pin_recover_do')) + '</button><button class="btn ghost block" data-lk="back">' + esc(t('cancel')) + '</button>';
    } else {
      var dots = ''; for (var i = 0; i < p.len; i++) dots += '<i class="' + (i < lockState.buf.length ? 'on' : '') + '"></i>';
      h += '<h2>' + esc(t('pin_enter')) + '</h2><div class="lk-dots" id="lkDots">' + dots + '</div><div class="lk-err" id="lkErr">' + (wait ? esc(t('pin_wait', { n: wait })) : '') + '</div><div class="lk-pad">';
      [1, 2, 3, 4, 5, 6, 7, 8, 9].forEach(function (n) { h += '<button data-lk="d" data-n="' + n + '"' + (wait ? ' disabled' : '') + '>' + n + '</button>'; });
      h += '<button class="lk-s" data-lk="rec">' + esc(t('pin_forgot')) + '</button><button data-lk="d" data-n="0"' + (wait ? ' disabled' : '') + '>0</button><button class="lk-s" data-lk="del" aria-label="del">⌫</button></div>';
    }
    el.innerHTML = h + '</div>';
  }
  function showLock() {
    if (!U.D || !U.D.settings.pin) return;
    var el = lockEl(); if (!el) { el = document.createElement('div'); el.id = 'lock'; document.body.appendChild(el); el.addEventListener('click', lockClick); }
    lockState.buf = ''; lockState.mode = 'pin'; U.pinLocked = true; el.classList.remove('hidden'); lockDraw();
    document.documentElement.setAttribute('data-theme', U.theme ? U.theme() : 'light');
    if (U.modalOpen) U.closeModal();
  }
  function unlock() { var el = lockEl(); if (el) el.classList.add('hidden'); U.pinLocked = false; lockState.buf = ''; lockState.fails = 0; }
  function lockClick(e) {
    var b = e.target.closest('[data-lk]'); if (!b || b.disabled) return; var a = b.getAttribute('data-lk'), p = U.D.settings.pin;
    if (a === 'd') {
      if (Date.now() < lockState.until) return;
      lockState.buf += b.getAttribute('data-n'); lockDraw();
      if (lockState.buf.length >= p.len) {
        if (pinOk(lockState.buf)) { unlock(); return; }
        lockState.fails++; lockState.buf = '';
        if (lockState.fails >= 5) { lockState.until = Date.now() + 30000 * Math.min(4, lockState.fails - 4); var tm = setInterval(function () { if (Date.now() >= lockState.until) { clearInterval(tm); } lockDraw(); }, 1000); }
        lockDraw(); var er = document.getElementById('lkErr'); if (er && !(Date.now() < lockState.until)) er.textContent = t('pin_wrong');
        var box = document.querySelector('#lock .lk-dots'); if (box) { box.classList.add('shake'); }
      }
    } else if (a === 'del') { lockState.buf = lockState.buf.slice(0, -1); lockDraw(); }
    else if (a === 'rec') { lockState.mode = 'rec'; lockDraw(); }
    else if (a === 'back') { lockState.mode = 'pin'; lockDraw(); }
    else if (a === 'rec_ok') {
      var v = (document.getElementById('lkRec').value || '').replace(/\D/g, '');
      if (hashPin(v, p.rsalt) === p.rhash) { try { U.commit(function (d) { d.settings.pin = null; }); } catch (er2) {} unlock(); U.toast(t('pin_removed'), 'ok'); U.render(true); }
      else document.getElementById('lkErr').textContent = t('pin_rec_wrong');
    }
  }
  U.lockInit = function () {
    showLock();
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) U.hiddenAt = Date.now();
      else if (U.D && U.D.settings.pin && !U.pinLocked && U.hiddenAt && Date.now() - U.hiddenAt > 60000) showLock();
    });
  };
  U.pinCard = function () {
    var p = U.D.settings.pin, h = '<div class="card"><h3>' + V.icon('lock', 18) + ' ' + t('pin_title') + '</h3><div class="muted" style="margin-bottom:10px">' + esc(t('pin_help')) + '</div>';
    h += '<div style="margin-bottom:10px">' + U.badge(p ? t('pin_on') : t('pin_off'), p ? 'green' : 'gray') + '</div><div class="btns">';
    h += p ? '<button class="btn sm" data-act="pin_lock_now">' + t('pin_lock_now') + '</button><button class="btn sm" data-act="pin_change">' + t('pin_change') + '</button><button class="btn sm danger-o" data-act="pin_remove">' + t('pin_remove') + '</button>' : '<button class="btn sm primary" data-act="pin_set">' + t('pin_set') + '</button>';
    return h + '</div></div>';
  };
  function pinField(name, label) { return { name: name, label: label, type: 'pin', value: '' }; }
  function checkNew(v) { if (!/^\d{4,6}$/.test(v.p1)) throw K.E('pin_bad_format'); if (v.p1 !== v.p2) throw K.E('pin_mismatch'); }
  function showCode(code) {
    U.showModal('<div class="pin-code"><h3>' + esc(t('pin_code_title')) + '</h3><p>' + esc(t('pin_code_help')) + '</p><div class="code" dir="ltr">' + esc(code.slice(0, 5) + '-' + code.slice(5)) + '</div><div class="btns"><button class="btn primary block" data-act="close">' + esc(t('pin_code_ok')) + '</button></div></div>');
  }
  function submitNew(v) {
    checkNew(v); var r = makePin(v.p1); U.commit(function (d) { d.settings.pin = r.pin; }); U.closeModal(); U.render(true); showCode(r.code);
  }
  X.pin_set = function () { U.openForm({ title: t('pin_set'), intro: esc(t('pin_format')), submit: t('save'), fields: [pinField('p1', t('pin_new')), pinField('p2', t('pin_new2'))], onSubmit: function (v) { submitNew(v); } }); };
  X.pin_change = function () {
    U.openForm({ title: t('pin_change'), submit: t('save'), fields: [pinField('cur', t('pin_current')), pinField('p1', t('pin_new')), pinField('p2', t('pin_new2'))], onSubmit: function (v) { if (!pinOk(v.cur)) throw K.E('pin_wrong'); submitNew(v); } });
  };
  X.pin_remove = function () {
    U.openForm({ title: t('pin_remove'), submit: t('pin_remove'), danger: true, fields: [pinField('cur', t('pin_current'))], onSubmit: function (v) { if (!pinOk(v.cur)) throw K.E('pin_wrong'); U.commit(function (d) { d.settings.pin = null; }); U.closeModal(); U.toast(t('pin_removed'), 'ok'); U.render(true); } });
  };
  X.pin_lock_now = function () { showLock(); };

  /* ================= wiring: date input, error boundary ================= */
  var prevAfter = U.afterRender;
  U.afterRender = function (R) {
    if (prevAfter) prevAfter(R);
    var el = document.getElementById('proDate');
    if (el) el.onchange = function () { if (!/^\d{4}-\d{2}-\d{2}$/.test(el.value)) return; if (el.getAttribute('data-for') === 'dc') S.dcDay = el.value; U.render(true); };
    [].forEach.call(document.querySelectorAll('input[data-cnt]'), function (inp) {
      inp.oninput = function () {
        var d = document.querySelector('[data-d="' + inp.getAttribute('data-cnt') + '"]'), r = K.parseQty(inp.value.trim(), true), sys = Number(inp.getAttribute('data-sys'));
        if (!inp.value.trim() || !r.ok) { d.textContent = ''; d.className = 'stk-d'; return; }
        var df = K.round3(r.q - sys); d.textContent = df === 0 ? '=' : (df > 0 ? '+' : '') + K.fmtQty(df); d.className = 'stk-d ' + (df === 0 ? '' : df > 0 ? 'up' : 'down');
      };
    });
  };
  var lastErr = 0;
  window.addEventListener('error', function (e) {
    if (Date.now() - lastErr < 4000) return; lastErr = Date.now();
    try { U.toast(t('err_unknown') + ' (' + String(e && e.message || '?').slice(0, 60) + ')', 'bad'); } catch (x) {}
  });
})();
