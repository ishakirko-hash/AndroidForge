/* KHALDI PLAST - in-app assistant. Works fully offline: it reads the real saved data and answers
   questions in Arabic / French / English with rule-based understanding (it is NOT a cloud AI).
   ask(D, question, ctx) -> { blocks:[{h, rows:[[label,value]], text}], matched:boolean } */
(function (root) {
  'use strict';
  var TX = {
    ar: { today: 'اليوم', yesterday: 'أمس', week: 'آخر 7 أيام', month: 'هذا الشهر', lastmonth: 'الشهر الماضي', year: 'هذه السنة', all: 'كل الفترات',
      sales: 'المبيعات', invoices: 'عدد الفواتير', crates: 'الصناديق المباعة', collected: 'المحصَّل', purchases: 'المشتريات', expenses: 'المصاريف', profit: 'الربح التشغيلي التقديري',
      profit_na: 'غير متاح (بيانات الإنتاج/التكلفة ناقصة)', good: 'إنتاج سليم', bad: 'إنتاج معيب', defect: 'نسبة المعيب', kg: 'المواد المستهلكة', prod_days: 'أيام الإنتاج',
      stock_fin: 'المنتجات الجاهزة', stock_raw: 'المواد الخام', low: 'مخزون منخفض', none: 'لا يوجد', cdebt: 'ديون الزبائن', sdebt: 'ديون الموردين', top_debtors: 'أكبر المدينين',
      workers: 'العمال', active: 'نشطون', leave: 'في إجازة', stopped: 'متوقفون', shifts: 'شفتات', hours: 'ساعات', balance: 'الرصيد', earned: 'المستحق', paid: 'المدفوع', absent: 'غياب',
      role: 'الوظيفة', start: 'تاريخ البدء', phone: 'الهاتف', address: 'العنوان', last: 'آخر نشاط', total: 'الإجمالي', count: 'العدد', avg: 'متوسط الفاتورة', orders: 'الطلبات المنتظرة', pending: 'بانتظار التنفيذ', confirmed: 'مؤكدة',
      backup: 'آخر نسخة احتياطية', never: 'لم تُنشأ بعد', overview: 'ملخص شامل', period: 'الفترة', top_prod: 'الأكثر إنتاجاً', top_cust: 'أفضل الزبائن', stockof: 'المخزون', min: 'الحد الأدنى', unit_pcs: 'قطعة', unit_kg: 'كغ',
      shift_today: 'شفتات اليوم', worked_n: 'عمل', dzd: 'دج', est: 'تقديري', cust: 'الزبون', supp: 'المورد', owes: 'عليه', for_us: 'له عندنا', clean: 'لا ديون مستحقة', noinfo: 'غير مسجل',
      hello: 'أنا المساعد الذكي لشركتك. أجيب من بياناتك الحقيقية المحفوظة في هاتفك فقط. جرّب أحد الأسئلة أدناه أو اكتب سؤالك.',
      unknown: 'لم أفهم السؤال تماماً. اسألني مثلاً عن: المبيعات، الإنتاج، المخزون، الديون، العمال، الشفتات، الطلبات، الأرباح، أو اذكر اسم زبون/مورد/عامل/منتج.',
      note_est: 'الربح تقدير: المبيعات − المواد الخام المستهلكة فعلاً − المصاريف المسجلة.', empty: 'لا توجد بيانات مسجلة لهذه الفترة.' },
    fr: { today: "aujourd'hui", yesterday: 'hier', week: '7 derniers jours', month: 'ce mois', lastmonth: 'mois dernier', year: 'cette année', all: 'toute la période',
      sales: 'Ventes', invoices: 'Factures', crates: 'Caisses vendues', collected: 'Encaissé', purchases: 'Achats', expenses: 'Dépenses', profit: "Bénéfice d'exploitation estimé",
      profit_na: 'indisponible (données de production/coût manquantes)', good: 'Production bonne', bad: 'Production défectueuse', defect: 'Taux de défauts', kg: 'Matières consommées', prod_days: 'Jours de production',
      stock_fin: 'Produits finis', stock_raw: 'Matières premières', low: 'Stock bas', none: 'Aucun', cdebt: 'Dettes clients', sdebt: 'Dettes fournisseurs', top_debtors: 'Principaux débiteurs',
      workers: 'Ouvriers', active: 'actifs', leave: 'en congé', stopped: 'arrêtés', shifts: 'équipes', hours: 'heures', balance: 'Solde', earned: 'Dû', paid: 'Payé', absent: 'Absences',
      role: 'Poste', start: 'Début', phone: 'Téléphone', address: 'Adresse', last: 'Dernière activité', total: 'Total', count: 'Nombre', avg: 'Facture moyenne', orders: 'Commandes en attente', pending: 'en attente', confirmed: 'confirmées',
      backup: 'Dernière sauvegarde', never: 'Jamais', overview: "Résumé complet", period: 'Période', top_prod: 'Production par produit', top_cust: 'Meilleurs clients', stockof: 'Stock', min: 'Minimum', unit_pcs: 'pcs', unit_kg: 'kg',
      shift_today: "Équipes d'aujourd'hui", worked_n: 'ont travaillé', dzd: 'DA', est: 'estimation', cust: 'Client', supp: 'Fournisseur', owes: 'doit', for_us: 'nous doit', clean: 'aucune dette', noinfo: 'non renseigné',
      hello: "Je suis l'assistant de votre entreprise. Je réponds uniquement à partir de vos données réelles enregistrées sur ce téléphone. Essayez une question ci-dessous ou écrivez la vôtre.",
      unknown: "Je n'ai pas bien compris. Demandez par exemple : ventes, production, stock, dettes, ouvriers, équipes, commandes, bénéfice, ou citez un client/fournisseur/ouvrier/produit.",
      note_est: 'Bénéfice estimé : ventes − matières réellement consommées − dépenses enregistrées.', empty: 'Aucune donnée enregistrée pour cette période.' },
    en: { today: 'today', yesterday: 'yesterday', week: 'last 7 days', month: 'this month', lastmonth: 'last month', year: 'this year', all: 'all time',
      sales: 'Sales', invoices: 'Invoices', crates: 'Crates sold', collected: 'Collected', purchases: 'Purchases', expenses: 'Expenses', profit: 'Estimated operating profit',
      profit_na: 'not available (production/cost data missing)', good: 'Good production', bad: 'Defective production', defect: 'Defect rate', kg: 'Materials consumed', prod_days: 'Production days',
      stock_fin: 'Finished products', stock_raw: 'Raw materials', low: 'Low stock', none: 'None', cdebt: 'Customer debts', sdebt: 'Supplier debts', top_debtors: 'Top debtors',
      workers: 'Workers', active: 'active', leave: 'on leave', stopped: 'stopped', shifts: 'shifts', hours: 'hours', balance: 'Balance', earned: 'Earned', paid: 'Paid', absent: 'Absences',
      role: 'Role', start: 'Start date', phone: 'Phone', address: 'Address', last: 'Last activity', total: 'Total', count: 'Count', avg: 'Average invoice', orders: 'Pending orders', pending: 'pending', confirmed: 'confirmed',
      backup: 'Last backup', never: 'Never', overview: 'Full overview', period: 'Period', top_prod: 'Production by product', top_cust: 'Top customers', stockof: 'Stock', min: 'Minimum', unit_pcs: 'pcs', unit_kg: 'kg',
      shift_today: "Today's shifts", worked_n: 'worked', dzd: 'DZD', est: 'estimate', cust: 'Customer', supp: 'Supplier', owes: 'owes', for_us: 'is owed', clean: 'no outstanding debt', noinfo: 'not set',
      hello: 'I am your company assistant. I answer only from the real data saved on this phone. Try a question below or type your own.',
      unknown: 'I did not fully understand. Ask about: sales, production, stock, debts, workers, shifts, orders, profit, or mention a customer/supplier/worker/product name.',
      note_est: 'Profit is an estimate: sales − raw materials actually consumed − recorded expenses.', empty: 'No data recorded for this period.' }
  };

  function norm(s) {
    return String(s || '').toLowerCase()
      .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); })
      .replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
      .replace(/[éèêë]/g, 'e').replace(/[àâä]/g, 'a').replace(/[îï]/g, 'i').replace(/[ôö]/g, 'o').replace(/[ùûü]/g, 'u').replace(/ç/g, 'c')
      .replace(/[^a-z0-9؀-ۿ\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  var KW = {
    summary: ['ملخص', 'كل شي', 'كل شيء', 'كل البيانات', 'احصائيات', 'احصاءات', 'احصاءات', 'تقرير شامل', 'نظره عامه', 'وضع الشركه', 'situation', 'resume', 'bilan', 'summary', 'overview', 'statistiques', 'statistics', 'everything', 'all data', 'tout'],
    sales: ['مبيعات', 'مبيع', 'بيع', 'بعنا', 'ventes', 'vente', 'sales', 'sold', 'chiffre'], purchases: ['مشتريات', 'شراء', 'اشترينا', 'achats', 'achat', 'purchase', 'bought'],
    expenses: ['مصاريف', 'مصروف', 'نفقات', 'depenses', 'depense', 'expense', 'spending'], profit: ['ربح', 'ارباح', 'خساره', 'benefice', 'profit', 'margin', 'marge'],
    prod: ['انتاج', 'نصنع', 'صنعنا', 'production', 'fabrique', 'produced', 'manufactur'], defect: ['معيب', 'تالف', 'عيوب', 'defect', 'rebut', 'defaut'],
    stock: ['مخزون', 'مخزن', 'stock', 'inventaire', 'inventory'], low: ['منخفض', 'ينقص', 'نفد', 'bas', 'low', 'rupture', 'shortage'],
    debt: ['ديون', 'دين', 'مستحق', 'باقي', 'متبقي', 'dette', 'dettes', 'debt', 'owe', 'impaye', 'creance', 'reste'], cust: ['زبائن', 'زبون', 'عملاء', 'عميل', 'client', 'customer'], supp: ['موردين', 'مورد', 'fournisseur', 'supplier', 'vendor'],
    work: ['عمال', 'عامل', 'موظف', 'ouvrier', 'worker', 'employe', 'staff'], shift: ['شفت', 'شفتات', 'وردي', 'equipe', 'shift', 'poste'],
    orders: ['طلبات', 'طلبيه', 'طلبيات', 'ملاحظات', 'ملاحظه', 'commande', 'order', 'notes', 'note'], inv: ['فاتوره', 'فواتير', 'facture', 'invoice'], backup: ['نسخه احتياطي', 'نسخ احتياطي', 'نسخه', 'backup', 'sauvegarde'],
    help: ['مساعده', 'ماذا تستطيع', 'help', 'aide'], pay: ['راتب', 'رواتب', 'اجر', 'اجور', 'سلفه', 'سلف', 'salaire', 'avance', 'salary', 'wage', 'advance']
  };
  function has(q, key) { var list = KW[key]; for (var i = 0; i < list.length; i++) if (q.indexOf(norm(list[i])) >= 0) return true; return false; }

  function periodOf(q, K) {
    var today = K.today(), ym = today.slice(0, 7);
    if (/(الشهر الماضي|الشهر السابق|mois dernier|last month|mois precedent)/.test(q)) { var pm = K.addMonths(ym, -1), r = K.monthRange(pm); return { key: 'lastmonth', from: r.from, to: r.to }; }
    if (/(امس|hier|yesterday)/.test(q)) { var y = K.addDays(today, -1); return { key: 'yesterday', from: y, to: y }; }
    if (/(اليوم|aujourd|today)/.test(q)) return { key: 'today', from: today, to: today };
    if (/(الاسبوع|اسبوع|semaine|week|7 jours|7 days)/.test(q)) return { key: 'week', from: K.addDays(today, -6), to: today };
    if (/(السنه|سنه|annee|year|this year|cette annee)/.test(q)) return { key: 'year', from: today.slice(0, 4) + '-01-01', to: today.slice(0, 4) + '-12-31' };
    if (/(كل الفترات|كل الوقت|toute la periode|all time|depuis le debut)/.test(q)) return { key: 'all', from: '0000-01-01', to: '9999-12-31' };
    var r2 = K.monthRange(ym); return { key: 'month', from: r2.from, to: r2.to };
  }

  function ask(D, question, ctx) {
    var K = ctx.K, lang = ctx.lang || 'ar', T = TX[lang] || TX.ar, money = ctx.money, qty = ctx.qty, date = ctx.date;
    var q = norm(question), blocks = [], matched = false;
    var P = periodOf(q, K), plabel = T[P.key] + (P.key === 'all' ? '' : '  (' + date(P.from) + (P.from === P.to ? '' : ' → ' + date(P.to)) + ')');
    function B(h, rows, text) { blocks.push({ h: h, rows: rows || [], text: text || '' }); matched = true; }
    function R(label, value) { return [label, value]; }
    var rep = K.periodReport(D, P.from, P.to);

    /* ---- entity lookups (names in the question) ---- */
    function findNames(list) { return list.filter(function (x) { var n = norm(x.name); return n.length > 1 && q.indexOf(n) >= 0; }); }
    var custs = findNames(D.customers), supps = findNames(D.suppliers), works = findNames(D.workers), prods = findNames(D.products), mats = findNames(D.materials);

    custs.forEach(function (c) {
      var p = K.partyProfile(D, 'customer', c.id);
      B(T.cust + ': ' + c.name, [R(T.phone, c.phone || T.noinfo), R(T.address, c.address || T.noinfo), R(T.invoices, String(p.count)), R(T.total, money(p.total)), R(T.paid, money(p.paid)),
        R(T.balance + ' (' + (p.balance > 0 ? T.owes : T.clean) + ')', money(p.balance)), R(T.crates, qty(p.qty)), R(T.avg, money(p.avg)), R(T.last, p.last ? date(p.last) : T.noinfo)]);
    });
    supps.forEach(function (s) {
      var p = K.partyProfile(D, 'supplier', s.id);
      B(T.supp + ': ' + s.name, [R(T.phone, s.phone || T.noinfo), R(T.address, s.address || T.noinfo), R(T.purchases, String(p.count)), R(T.total, money(p.total)), R(T.paid, money(p.paid)),
        R(T.balance, money(p.balance)), R(T.unit_kg, qty(p.qty)), R(T.last, p.last ? date(p.last) : T.noinfo)]);
    });
    works.forEach(function (w) {
      var explicit = /(الشهر|اليوم|امس|اسبوع|الاسبوع|السنه|month|mois|today|aujourd|hier|yesterday|week|semaine|year|annee)/.test(q), L = K.workerLedger(D, w.id, explicit ? P.from : '', explicit ? P.to : '');
      B(T.workers + ': ' + w.name, [R(T.role, w.role || T.noinfo), R(T.start, w.hireDate ? date(w.hireDate) : T.noinfo), R(T.phone, w.phone || T.noinfo), R(T.shifts, String(L.shifts)), R(T.hours, String(L.hours)), R(T.absent, String(L.absent)),
        R(T.earned, money(L.earned)), R(T.paid, money(L.paid)), R(T.balance, money(L.balance)), R(T.last, L.lastWorked ? date(L.lastWorked) : T.noinfo)]);
    });
    prods.forEach(function (p) {
      var T2 = K.productionTable(D, P.from, P.to), g = 0, df = 0; T2.rows.forEach(function (r) { var b = r.byProduct[p.id]; if (b) { g += b.good; df += b.defective; } });
      var sold = 0, rev = 0; K.live(D.sales).filter(function (s) { return s.date >= P.from && s.date <= P.to; }).forEach(function (s) { s.items.forEach(function (i) { if (i.productId === p.id) { sold += i.qty; rev += i.qty * i.unitPrice; } }); });
      B(p.name + ' - ' + plabel, [R(T.stockof, qty(p.stock) + ' ' + T.unit_pcs), R(T.min, p.minStock ? String(p.minStock) : T.noinfo), R(T.good, qty(g)), R(T.bad, qty(df)), R(T.crates, qty(sold)), R(T.sales, money(rev))]);
    });
    mats.forEach(function (m) {
      var avg = K.avgMaterialCost(D, m.id);
      B(m.name, [R(T.stockof, qty(m.stock) + ' ' + T.unit_kg), R(T.min, m.minStock ? String(m.minStock) : T.noinfo), R(T.est + ' / ' + T.unit_kg, avg == null ? T.noinfo : money(Math.round(avg)))]);
    });
    var named = blocks.length > 0;

    /* ---- topic answers (skipped when the user only named an entity) ---- */
    var any = false;
    function topic(key) { if (has(q, key)) { any = true; return true; } return false; }
    var anyKey = Object.keys(KW).some(function (k) { return has(q, k); }), perWord = /(الشهر|اليوم|امس|الاسبوع|السنه|month|mois|today|aujourd|hier|yesterday|week|semaine|year|annee)/.test(q);
    var wantSummary = topic('summary') || (!named && (/^(\s*)$/.test(q) || (perWord && !anyKey)));
    if (wantSummary) {
      var cur = K.periodReport(D, P.from, P.to), d = K.dashboard(D, K.today());
      var lows = d.lowProducts.concat(d.lowMaterials).map(function (x) { return x.name; });
      var wk = { a: 0, l: 0, s: 0 }; D.workers.forEach(function (w) { if (w.archived) return; if (w.status === 'leave') wk.l++; else if (w.status === 'stopped' || w.active === false) wk.s++; else wk.a++; });
      var pend = D.notes.filter(function (n) { return n.isOrder && (n.status === 'pending' || n.status === 'confirmed'); }).length;
      B(T.overview + ' - ' + plabel, [R(T.sales, money(cur.sales)), R(T.invoices, String(cur.salesCount)), R(T.crates, qty(cur.cratesSold)), R(T.collected, money(cur.collected)), R(T.purchases, money(cur.purchases)), R(T.expenses, money(cur.expenses)),
        R(T.profit, cur.operatingProfit == null ? T.profit_na : money(cur.operatingProfit)), R(T.good, qty(cur.good)), R(T.bad, qty(cur.defective)),
        R(T.stock_fin, qty(d.finishedStock) + ' ' + T.unit_pcs), R(T.stock_raw, qty(d.rawStock) + ' ' + T.unit_kg), R(T.low, lows.length ? lows.join('، ') : T.none),
        R(T.cdebt, money(d.customerDebt)), R(T.sdebt, money(d.supplierDebt)), R(T.workers, wk.a + ' ' + T.active + ' · ' + wk.l + ' ' + T.leave + ' · ' + wk.s + ' ' + T.stopped), R(T.orders, String(pend)),
        R(T.backup, D.settings.lastBackup ? date(String(D.settings.lastBackup).slice(0, 10)) : T.never)], T.note_est);
    }
    if (!wantSummary && !named) {
      if (topic('profit')) B(T.profit + ' - ' + plabel, [R(T.sales, money(rep.sales)), R(T.kg + ' (' + T.est + ')', rep.materialsCost == null ? T.profit_na : money(rep.materialsCost)), R(T.expenses, money(rep.expenses)), R(T.profit, rep.operatingProfit == null ? T.profit_na : money(rep.operatingProfit))], T.note_est);
      else if (topic('sales') || topic('inv')) {
        var byP = {}; K.live(D.sales).filter(function (s) { return s.date >= P.from && s.date <= P.to; }).forEach(function (s) { s.items.forEach(function (i) { byP[i.productId] = (byP[i.productId] || 0) + i.qty * i.unitPrice; }); });
        var rows = [R(T.sales, money(rep.sales)), R(T.invoices, String(rep.salesCount)), R(T.crates, qty(rep.cratesSold)), R(T.collected, money(rep.collected))];
        Object.keys(byP).forEach(function (pid) { var pr = K.byId(D.products, pid); rows.push(R('· ' + (pr ? pr.name : '?'), money(byP[pid]))); });
        B(T.sales + ' - ' + plabel, rows);
      } else if (topic('purchases')) B(T.purchases + ' - ' + plabel, [R(T.purchases, money(rep.purchases)), R(T.sdebt, money(rep.supplierDebt))]);
      else if (topic('expenses') || topic('pay')) { var er = [R(T.expenses, money(rep.expenses))]; rep.expensesByCat.forEach(function (c) { var cc = K.byId(D.expenseCats, c.categoryId); if (c.amount) er.push(R('· ' + (cc ? (cc.key && ctx.catName ? ctx.catName(cc) : cc.name) : '?'), money(c.amount))); }); B(T.expenses + ' - ' + plabel, er); }
      else if (topic('defect') || topic('prod')) {
        var tb = K.productionTable(D, P.from, P.to), tot = tb.totalGood + tb.totalDefective, rows2 = [R(T.good, qty(tb.totalGood)), R(T.bad, qty(tb.totalDefective)), R(T.defect, tot ? (Math.round(tb.totalDefective * 1000 / tot) / 10) + '%' : T.noinfo), R(T.kg, qty(tb.totalKg) + ' ' + T.unit_kg), R(T.prod_days, String(tb.rows.length))];
        var per = {}; tb.rows.forEach(function (r) { Object.keys(r.byProduct).forEach(function (pid) { per[pid] = (per[pid] || 0) + r.byProduct[pid].good; }); });
        Object.keys(per).forEach(function (pid) { var pr = K.byId(D.products, pid); rows2.push(R('· ' + (pr ? pr.name : '?'), qty(per[pid]))); });
        B(T.good + ' - ' + plabel, rows2);
      } else if (topic('low')) {
        var lo = D.products.concat(D.materials).filter(function (x) { return !x.archived && x.minStock > 0 && x.stock <= x.minStock; });
        B(T.low, lo.length ? lo.map(function (x) { return R(x.name, qty(x.stock) + ' / ' + x.minStock); }) : [R(T.low, T.none)]);
      } else if (topic('stock')) {
        B(T.stock_fin, D.products.filter(function (p) { return !p.archived; }).map(function (p) { return R(p.name, qty(p.stock) + ' ' + T.unit_pcs); }));
        B(T.stock_raw, D.materials.filter(function (p) { return !p.archived; }).map(function (m) { return R(m.name, qty(m.stock) + ' ' + T.unit_kg); }));
      } else if (topic('debt') || topic('cust') && !has(q, 'work') || topic('supp')) {
        var wantSup = has(q, 'supp') && !has(q, 'cust'), list = (wantSup ? D.suppliers : D.customers).filter(function (x) { return !x.archived; }).map(function (x) { return { x: x, b: wantSup ? K.supplierBalance(D, x.id) : K.customerBalance(D, x.id) }; }).filter(function (r) { return r.b !== 0; }).sort(function (a, b) { return b.b - a.b; });
        B((wantSup ? T.sdebt : T.cdebt), [R(T.total, money(list.reduce(function (a, r) { return a + (r.b > 0 ? r.b : 0); }, 0)))].concat(list.slice(0, 10).map(function (r) { return R(r.x.name + (r.x.phone ? ' · ' + r.x.phone : ''), money(r.b)); })));
        if (has(q, 'cust') && has(q, 'supp')) { var sl = D.suppliers.map(function (x) { return { x: x, b: K.supplierBalance(D, x.id) }; }).filter(function (r) { return r.b > 0; }); B(T.sdebt, sl.length ? sl.map(function (r) { return R(r.x.name, money(r.b)); }) : [R(T.sdebt, T.none)]); }
      } else if (topic('shift')) {
        var day = K.today(), rows3 = [];
        K.SHIFTS.forEach(function (s) { var r = K.rosterFor(D, day, s.n), w = r.filter(function (a) { return a.worked; }); rows3.push(R(s.n + ' · ' + s.start + '–' + s.end, w.length + ' ' + T.worked_n + (w.length ? ' (' + w.map(function (a) { var x = K.byId(D.workers, a.workerId); return x ? x.name : '?'; }).join('، ') + ')' : ''))); });
        B(T.shift_today, rows3);
      } else if (topic('work')) {
        var rows4 = D.workers.filter(function (w) { return !w.archived; }).map(function (w) { var L = K.workerLedger(D, w.id, P.from, P.to); return R(w.name + (w.role ? ' · ' + w.role : ''), L.shifts + ' ' + T.shifts + ' · ' + L.hours + ' ' + T.hours + ' · ' + T.balance + ' ' + money(K.workerLedger(D, w.id).balance)); });
        B(T.workers + ' - ' + plabel, rows4.length ? rows4 : [R(T.workers, T.none)]);
      } else if (topic('orders')) {
        var os = D.notes.filter(function (n) { return n.isOrder && n.status !== 'completed' && n.status !== 'cancelled'; }).sort(function (a, b) { return (a.expectedDate || '9999') < (b.expectedDate || '9999') ? -1 : 1; });
        B(T.orders, os.length ? os.slice(0, 10).map(function (n) { var p = K.byId(D.products, n.productId); return R((n.customerName || n.title || '?') + (p ? ' · ' + p.name : '') + (n.qty ? ' × ' + n.qty : ''), (n.expectedDate ? date(n.expectedDate) : T.noinfo) + ' (' + (T[n.status] || n.status) + ')'); }) : [R(T.orders, T.none)]);
      } else if (topic('backup')) B(T.backup, [R(T.backup, D.settings.lastBackup ? date(String(D.settings.lastBackup).slice(0, 10)) : T.never)]);
      else if (topic('help')) { blocks.push({ h: '', rows: [], text: T.hello }); matched = true; }
    }
    if (!matched) blocks.push({ h: '', rows: [], text: T.unknown });
    return { blocks: blocks, matched: matched, hello: T.hello };
  }

  function suggestions(lang) {
    return { ar: ['ملخص شامل', 'مبيعات هذا الشهر', 'الإنتاج هذا الشهر', 'الربح هذا الشهر', 'المخزون', 'ديون الزبائن', 'ديون الموردين', 'العمال', 'شفتات اليوم', 'الطلبات المنتظرة', 'المصاريف هذا الشهر', 'مبيعات اليوم'],
      fr: ['Résumé complet', 'Ventes ce mois', 'Production ce mois', 'Bénéfice ce mois', 'Stock', 'Dettes clients', 'Dettes fournisseurs', 'Ouvriers', "Équipes d'aujourd'hui", 'Commandes en attente', 'Dépenses ce mois', "Ventes aujourd'hui"],
      en: ['Full overview', 'Sales this month', 'Production this month', 'Profit this month', 'Stock', 'Customer debts', 'Supplier debts', 'Workers', "Today's shifts", 'Pending orders', 'Expenses this month', "Today's sales"] }[lang] || [];
  }
  var API = { hello: function (l) { return (TX[l] || TX.ar).hello; }, ask: ask, suggestions: suggestions, norm: norm };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.KPAssistant = API;
})(typeof window !== 'undefined' ? window : this);
