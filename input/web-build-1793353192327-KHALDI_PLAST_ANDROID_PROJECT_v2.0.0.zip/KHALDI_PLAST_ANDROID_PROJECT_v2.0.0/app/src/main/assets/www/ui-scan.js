/* KHALDI PLAST v1.1 - open a printed invoice by scanning its QR code.
   On the phone the camera scanner is native (offline); the decoded text returns through window.KPScanResult(text).
   Without the native scanner (browser) the same screen accepts an invoice number or the pasted QR text. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, X = U.extraActions;
  function pad6(n) { return ('000000' + n).slice(-6); }
  function parse(text) {
    var s = String(text == null ? '' : text), m = /FV-(\d{4})-(\d{6})/.exec(s);
    if (!m) return { kind: 'foreign', raw: s };
    var no = parseInt(m[2], 10), sale = null, i;
    for (i = 0; i < U.D.sales.length; i++) if (U.D.sales[i].no === no) { sale = U.D.sales[i]; break; }   // the number never changes, the date can
    var info = {}; s.split(/\r?\n/).forEach(function (l) { var x = /^(TOTAL|PAID|DUE)\s+([0-9.]+)/.exec(l.trim()); if (x) info[x[1]] = x[2]; if (/^\d{4}-\d{2}-\d{2}$/.test(l.trim())) info.date = l.trim(); });
    return sale ? { kind: 'sale', sale: sale } : { kind: 'missing', code: m[0], info: info };
  }
  function money(txt) { var n = Math.round(parseFloat(txt) * 100); return isFinite(n) ? U.money(n) : esc(txt); }
  U.handleScan = function (text) {
    var r = parse(text); U.closeModal();
    if (r.kind === 'sale') { U.go('invoice', r.sale.id); U.toast(t('scan_found') + ' ' + U.invFull(r.sale), 'ok'); return; }
    var body;
    if (r.kind === 'missing') {
      body = '<h3>' + t('scan_missing') + '</h3><div class="muted" style="margin-bottom:8px">' + t('scan_missing_help') + '</div><div class="card" style="box-shadow:none">' +
        U.kv('note', t('invoice_no'), '<bdi class="num" dir="ltr">' + esc(r.code) + '</bdi>') + (r.info.date ? U.kv('calendar', t('date'), '<bdi class="num">' + esc(K.fmtDate(r.info.date)) + '</bdi>') : '') +
        (r.info.TOTAL ? U.kv('wallet', t('grand_total'), money(r.info.TOTAL)) : '') + (r.info.PAID ? U.kv('check', t('paid'), money(r.info.PAID)) : '') + (r.info.DUE ? U.kv('alert', t('remaining'), money(r.info.DUE)) : '') + '</div>';
    } else body = '<h3>' + t('scan_foreign') + '</h3><div class="card" style="box-shadow:none;word-break:break-all;direction:ltr;text-align:left;font-size:12px">' + esc(r.raw.slice(0, 300)) + '</div>';
    U.showModal(body + '<div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button><button class="btn primary" data-act="scan_qr">' + V.icon('scan', 18) + ' ' + t('scan_again') + '</button></div>');
  };
  window.KPScanResult = function (text) { U.handleScan(text); };
  function manual() {
    U.showModal('<h3>' + t('scan_title') + '</h3><div class="muted" style="margin-bottom:8px">' + t('scan_manual_hint') + '</div><input id="scanin" type="text" inputmode="text" dir="ltr" placeholder="' + esc(t('scan_input_ph')) + '" style="width:100%">' +
      '<div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button><button class="btn primary" data-act="scan_manual">' + t('scan_open') + '</button></div>');
    var el = document.getElementById('scanin'); if (el) { el.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); X.scan_manual(); } }; try { el.focus(); } catch (_) { } }
  }
  U.scan = function () {
    if (U.AND && U.AND.scanQR) { try { U.AND.scanQR(); return; } catch (e) { /* fall through to manual entry */ } }
    manual();
  };
  X.scan_qr = function () { U.closeModal(); U.scan(); };
  X.scan_manual = function () {
    var el = document.getElementById('scanin'), v = el ? String(el.value).trim() : ''; if (!v) return;
    if (/^\d+$/.test(v)) v = 'FV-0000-' + pad6(parseInt(v, 10));
    U.handleScan(v);
  };
})();
