/* KHALDI PLAST - tiny offline QR code generator (byte mode, UTF-8, error correction L/M/Q/H, versions 1-20).
   Written for this app following ISO/IEC 18004 (same structure as the public-domain-style reference algorithms). No network, no library. */
(function (root) {
  'use strict';
  var ECC = { L: 0, M: 1, Q: 2, H: 3 }, FMT = { L: 1, M: 0, Q: 3, H: 2 };
  var EPB = { L: [0, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28], M: [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26],
    Q: [0, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30], H: [0, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28] };
  var NB = { L: [0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8], M: [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16],
    Q: [0, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20], H: [0, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25] };
  function utf8(s) {
    var out = [], i, c;
    for (i = 0; i < s.length; i++) {
      c = s.charCodeAt(i);
      if (c >= 0xD800 && c < 0xDC00 && i + 1 < s.length) { c = 0x10000 + ((c - 0xD800) << 10) + (s.charCodeAt(++i) - 0xDC00); }
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xC0 | c >> 6, 0x80 | c & 63);
      else if (c < 0x10000) out.push(0xE0 | c >> 12, 0x80 | c >> 6 & 63, 0x80 | c & 63);
      else out.push(0xF0 | c >> 18, 0x80 | c >> 12 & 63, 0x80 | c >> 6 & 63, 0x80 | c & 63);
    }
    return out;
  }
  function rawModules(v) { var r = (16 * v + 128) * v + 64; if (v >= 2) { var n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; }
  function dataWords(v, e) { return Math.floor(rawModules(v) / 8) - EPB[e][v] * NB[e][v]; }
  function gmul(x, y) { var z = 0, i; for (i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z; }
  function rsDiv(deg) { var r = [], i, j, root = 1; for (i = 0; i < deg - 1; i++) r.push(0); r.push(1); for (i = 0; i < deg; i++) { for (j = 0; j < r.length; j++) { r[j] = gmul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = gmul(root, 2); } return r; }
  function rsRem(data, div) { var r = div.map(function () { return 0; }); data.forEach(function (b) { var f = b ^ r.shift(); r.push(0); div.forEach(function (c, i) { r[i] ^= gmul(c, f); }); }); return r; }
  function bit(x, i) { return ((x >>> i) & 1) !== 0; }

  function make(text, level) {
    level = level && ECC[level] != null ? level : 'M';
    var bytes = utf8(String(text)), ver, cap, used;
    for (ver = 1; ver <= 20; ver++) { cap = dataWords(ver, level) * 8; used = 4 + (ver <= 9 ? 8 : 16) + bytes.length * 8; if (used <= cap) break; }
    if (ver > 20) throw new Error('qr_too_long');
    var bits = [];
    function put(val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); }
    put(4, 4); put(bytes.length, ver <= 9 ? 8 : 16); bytes.forEach(function (b) { put(b, 8); });
    put(0, Math.min(4, cap - bits.length)); while (bits.length % 8) bits.push(0);
    for (var pad = 0xEC; bits.length < cap; pad ^= 0xEC ^ 0x11) put(pad, 8);
    var data = []; for (var i = 0; i < bits.length; i += 8) { var b = 0; for (var k = 0; k < 8; k++) b = (b << 1) | bits[i + k]; data.push(b); }
    // error correction + interleave
    var nb = NB[level][ver], eccLen = EPB[level][ver], raw = Math.floor(rawModules(ver) / 8), nShort = nb - raw % nb, shortLen = Math.floor(raw / nb), blocks = [], div = rsDiv(eccLen), p = 0;
    for (i = 0; i < nb; i++) { var d = data.slice(p, p + shortLen - eccLen + (i < nShort ? 0 : 1)); p += d.length; var e = rsRem(d, div); if (i < nShort) d.push(0); blocks.push(d.concat(e)); }
    var all = []; for (i = 0; i < blocks[0].length; i++) blocks.forEach(function (bl, j) { if (i !== shortLen - eccLen || j >= nShort) all.push(bl[i]); });
    // matrix
    var size = ver * 4 + 17, m = [], fn = [], x, y;
    for (y = 0; y < size; y++) { m.push(new Array(size).fill(false)); fn.push(new Array(size).fill(false)); }
    function setF(x, y, v) { m[y][x] = v; fn[y][x] = true; }
    for (i = 0; i < size; i++) { setF(6, i, i % 2 === 0); setF(i, 6, i % 2 === 0); }
    function finder(cx, cy) { for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) { var dist = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy; if (xx >= 0 && xx < size && yy >= 0 && yy < size) setF(xx, yy, dist !== 2 && dist !== 4); } }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var pos = []; if (ver > 1) { var na = Math.floor(ver / 7) + 2, step = Math.ceil((ver * 4 + 4) / (na * 2 - 2)) * 2; pos = [6]; for (var ps = size - 7; pos.length < na; ps -= step) pos.splice(1, 0, ps); }
    pos.forEach(function (ax, ia) { pos.forEach(function (ay, ib) { if ((ia === 0 && ib === 0) || (ia === 0 && ib === pos.length - 1) || (ia === pos.length - 1 && ib === 0)) return; for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) setF(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }); });
    function formatBits(mask) {
      var dd = (FMT[level] << 3) | mask, r = dd, k; for (k = 0; k < 10; k++) r = (r << 1) ^ ((r >>> 9) * 0x537); var bs = ((dd << 10) | r) ^ 0x5412;
      for (k = 0; k <= 5; k++) setF(8, k, bit(bs, k)); setF(8, 7, bit(bs, 6)); setF(8, 8, bit(bs, 7)); setF(7, 8, bit(bs, 8)); for (k = 9; k < 15; k++) setF(14 - k, 8, bit(bs, k));
      for (k = 0; k < 8; k++) setF(size - 1 - k, 8, bit(bs, k)); for (k = 8; k < 15; k++) setF(8, size - 15 + k, bit(bs, k)); setF(8, size - 8, true);
    }
    formatBits(0);
    if (ver >= 7) { var r2 = ver, k2; for (k2 = 0; k2 < 12; k2++) r2 = (r2 << 1) ^ ((r2 >>> 11) * 0x1F25); var vb = (ver << 12) | r2; for (k2 = 0; k2 < 18; k2++) { var col = bit(vb, k2), a = size - 11 + k2 % 3, bb = Math.floor(k2 / 3); setF(a, bb, col); setF(bb, a, col); } }
    // codewords, zig-zag
    var n = 0; for (var right = size - 1; right >= 1; right -= 2) { if (right === 6) right = 5; for (var vert = 0; vert < size; vert++) for (var j = 0; j < 2; j++) { x = right - j; y = ((right + 1) & 2) === 0 ? size - 1 - vert : vert; if (!fn[y][x] && n < all.length * 8) { m[y][x] = bit(all[n >>> 3], 7 - (n & 7)); n++; } } }
    function mask(mk) { for (var yy = 0; yy < size; yy++) for (var xx = 0; xx < size; xx++) { var inv; switch (mk) { case 0: inv = (xx + yy) % 2 === 0; break; case 1: inv = yy % 2 === 0; break; case 2: inv = xx % 3 === 0; break; case 3: inv = (xx + yy) % 3 === 0; break;
      case 4: inv = (Math.floor(xx / 3) + Math.floor(yy / 2)) % 2 === 0; break; case 5: inv = xx * yy % 2 + xx * yy % 3 === 0; break; case 6: inv = (xx * yy % 2 + xx * yy % 3) % 2 === 0; break; default: inv = ((xx + yy) % 2 + xx * yy % 3) % 2 === 0; } if (!fn[yy][xx] && inv) m[yy][xx] = !m[yy][xx]; } }
    function penalty() {
      var s = 0, yy, xx, run, dark = 0, line, q;
      for (yy = 0; yy < size; yy++) for (q = 0; q < 2; q++) { run = 1; for (xx = 1; xx <= size; xx++) { var a = xx < size ? (q ? m[xx][yy] : m[yy][xx]) : null, pr = q ? m[xx - 1][yy] : m[yy][xx - 1]; if (a === pr) run++; else { if (run >= 5) s += 3 + run - 5; run = 1; } } }
      for (yy = 0; yy < size - 1; yy++) for (xx = 0; xx < size - 1; xx++) if (m[yy][xx] === m[yy][xx + 1] && m[yy][xx] === m[yy + 1][xx] && m[yy][xx] === m[yy + 1][xx + 1]) s += 3;
      for (yy = 0; yy < size; yy++) for (xx = 0; xx < size; xx++) if (m[yy][xx]) dark++;
      s += 10 * (Math.ceil(Math.abs(dark * 20 - size * size * 10) / (size * size)) - 1);
      return s;
    }
    var best = 0, bestP = Infinity;
    for (var mk = 0; mk < 8; mk++) { mask(mk); formatBits(mk); var pn = penalty(); if (pn < bestP) { bestP = pn; best = mk; } mask(mk); }
    mask(best); formatBits(best);
    return { size: size, version: ver, level: level, mask: best, get: function (x, y) { return x >= 0 && y >= 0 && x < size && y < size && m[y][x]; } };
  }
  // SVG string: dark modules as one path, 4-module quiet zone.
  function svg(text, o) {
    o = o || {}; var q = make(text, o.level), s = q.size, quiet = o.quiet == null ? 4 : o.quiet, d = '', x, y;
    for (y = 0; y < s; y++) { x = 0; while (x < s) { if (q.get(x, y)) { var st = x; while (x < s && q.get(x, y)) x++; d += 'M' + (st + quiet) + ' ' + (y + quiet) + 'h' + (x - st) + 'v1h-' + (x - st) + 'z'; } else x++; } }
    var tot = s + quiet * 2;
    return '<svg class="qr" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + tot + ' ' + tot + '" shape-rendering="crispEdges" role="img" aria-label="QR"><rect width="' + tot + '" height="' + tot + '" fill="#fff"/><path d="' + d + '" fill="' + (o.color || '#0B1A2E') + '"/></svg>';
  }
  var api = { make: make, svg: svg };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.KPQR = api;
})(typeof window !== 'undefined' ? window : this);
