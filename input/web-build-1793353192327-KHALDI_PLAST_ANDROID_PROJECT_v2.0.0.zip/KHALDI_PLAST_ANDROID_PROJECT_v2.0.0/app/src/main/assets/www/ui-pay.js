/* KHALDI PLAST v1.0 - month-end payroll sheet and profitability per product. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, F = U.forms, S = U.S, X = U.extraActions;
  function B(n) { return '<bdi class="num">' + n + '</bdi>'; }
  function csv(name, rows) { U.saveFile(name, 'text/csv', '﻿' + rows.map(function (r) { return r.map(U.csvEscape).join(','); }).join('\r\n')); }
  function printNow(name) { if (U.AND && U.AND.printPage) U.AND.printPage(name); else window.print(); }
  function c2(v) { return v == null ? '' : (v / 100).toFixed(2); }
  function kpi(cls, icon, label, val, note) { return '<div class="kpi bg-' + cls + '"><div class="kt"><span class="ki">' + V.icon(icon, 22) + '</span><span class="kl">' + esc(label) + '</span></div><div class="kv2">' + val + '</div><div class="kn">' + (note ? '<span>' + note + '</span>' : '') + '</div></div>'; }
  S.profScope = S.profScope || 'month';

  /* ================= payroll ================= */
  W.payroll = function () {
    var D = U.D, pr = K.payroll(D, S.ym), h = U.monthbar();
    h += '<div class="kpis kpis3">' + kpi('blue', 'users', t('pr_earned'), U.money(pr.earned), B(pr.shifts) + ' ' + t('shifts')) + kpi('amber', 'wallet', t('pr_advances'), U.money(pr.paid)) + kpi('red', 'wallet', t('pr_due'), U.money(pr.dueTotal)) + '</div>';
    if (pr.noRate.length) h += '<div class="alert amber">' + t('pr_no_rate_warn') + ': <b>' + esc(pr.noRate.join('، ')) + '</b></div>';
    if (!pr.rows.length) return h + '<div class="card">' + U.empty(t('pr_nothing'), 'users') + '</div>';
    h += '<div class="paynote">' + esc(t('pr_sheet_title')) + ' - ' + esc(U.monthLabel(S.ym)) + '</div>';
    h += '<div class="tablewrap"><table class="paytable"><thead><tr><th>' + t('pr_worker') + '</th><th>' + t('shifts') + '</th><th class="c-x">' + t('pr_absent') + '</th><th class="c-x">' + t('pr_rate') + '</th><th>' + t('pr_earned') + '</th><th>' + t('pr_advances') + '</th><th class="c-x">' + t('pr_month_net') + '</th><th class="c-x">' + t('pr_carried') + '</th><th>' + t('pr_due') + '</th><th class="sg c-x">' + t('pr_sign') + '</th></tr></thead><tbody>' +
      pr.rows.map(function (r) {
        return '<tr class="tap" data-act="open_worker" data-id="' + r.worker.id + '"><td class="l"><b>' + esc(r.worker.name) + '</b>' + (r.worker.role ? '<small>' + esc(r.worker.role) + '</small>' : '') + '</td><td>' + B(r.shifts) + '</td><td class="c-x">' + (r.absent ? B(r.absent) : '·') + '</td><td class="c-x">' + B(K.fmtMoney(r.rate)) + '</td><td>' + B(K.fmtMoney(r.earned)) + '</td><td>' + (r.paid ? B(K.fmtMoney(r.paid)) : '·') + '</td><td class="c-x">' + B(K.fmtMoney(r.monthNet)) + '</td><td class="c-x">' + (r.carried ? B(K.fmtMoney(r.carried)) : '·') + '</td><td class="due' + (r.dueTotal > 0 ? ' pos' : '') + '"><b>' + B(K.fmtMoney(r.dueTotal)) + '</b></td><td class="sg c-x"></td></tr>';
      }).join('') + '</tbody><tfoot><tr><td class="l">' + t('total') + '</td><td>' + B(pr.shifts) + '</td><td class="c-x"></td><td class="c-x"></td><td>' + B(K.fmtMoney(pr.earned)) + '</td><td>' + B(K.fmtMoney(pr.paid)) + '</td><td class="c-x">' + B(K.fmtMoney(pr.earned - pr.paid)) + '</td><td class="c-x"></td><td><b>' + B(K.fmtMoney(pr.dueTotal)) + '</b></td><td class="sg c-x"></td></tr></tfoot></table></div>';
    h += '<div class="muted" style="margin:6px 2px 10px">' + t('pr_note') + '</div>';
    var due = pr.rows.filter(function (r) { return r.dueTotal > 0; });
    h += '<div class="noprint">' + (due.length ? U.sec(t('pr_settle')) + '<div class="card">' + due.map(function (r) {
      return '<div class="row"><div class="ibox">' + V.icon('user', 22) + '</div><div class="main"><div class="t">' + esc(r.worker.name) + '</div><div class="s">' + t('pr_due') + ': ' + U.money(r.dueTotal) + '</div></div><button class="btn primary sm" data-act="pay_due" data-id="' + r.worker.id + '">' + t('pr_pay_due') + '</button></div>';
    }).join('') + '</div>' : '') +
      '<div class="btns"><button class="btn" data-act="export_payroll">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_payroll">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div></div>';
    return h;
  };
  X.pay_due = function (el) {
    var L = K.workerLedger(U.D, el.dataset.id, '', K.monthRange(S.ym).to);
    F.wpay(el.dataset.id, null, { amount: Math.max(0, L.balance), kind: 'salary' });
  };
  X.print_payroll = function () { printNow('KHALDI_PLAST_payroll_' + S.ym); };
  X.export_payroll = function () {
    var pr = K.payroll(U.D, S.ym), rows = [[t('pr_worker'), t('shifts'), t('pr_absent'), t('pr_rate'), t('pr_earned'), t('pr_advances'), t('pr_month_net'), t('pr_carried'), t('pr_due')]];
    pr.rows.forEach(function (r) { rows.push([r.worker.name, r.shifts, r.absent, c2(r.rate), c2(r.earned), c2(r.paid), c2(r.monthNet), c2(r.carried), c2(r.dueTotal)]); });
    rows.push([t('total'), pr.shifts, '', '', c2(pr.earned), c2(pr.paid), c2(pr.earned - pr.paid), '', c2(pr.dueTotal)]);
    csv('khaldi_payroll_' + S.ym + '.csv', rows);
  };

  /* ================= profitability per product ================= */
  function range() {
    if (S.profScope === 'all') return { from: '', to: K.today() };
    if (S.profScope === 'year') return { from: S.ym.slice(0, 4) + '-01-01', to: S.ym.slice(0, 4) + '-12-31' };
    return K.monthRange(S.ym);
  }
  W.profit = function () {
    var D = U.D, r = range(), pf = K.productProfitability(D, r.from, r.to), h = U.seg([['month', t('monthly')], ['year', t('yearly')], ['all', t('pf_all')]], S.profScope, 'profscope');
    if (S.profScope !== 'all') h += U.monthbar();
    if (!pf.rows.length) return h + '<div class="card">' + U.empty(t('pf_no_sales'), 'bars') + '</div>';
    h += '<div class="kpis">' + kpi('green', 'wallet', t('pf_revenue'), U.money(pf.revenue)) + kpi('red', 'box', t('pf_cost'), pf.unknown === pf.rows.length ? '-' : U.money(pf.cost)) + kpi('blue', 'bars', t('pf_profit'), pf.unknown === pf.rows.length ? '-' : U.money(pf.profit)) +
      kpi('amber', 'check', t('pf_margin'), pf.margin == null ? '-' : B(pf.margin + '%')) + '</div>';
    if (pf.unknown) h += '<div class="alert amber">' + t('pf_unknown_warn') + '</div>';
    var best = pf.rows.filter(function (x) { return x.profit != null; })[0], bestPc = pf.rows.filter(function (x) { return x.perCrate != null; }).sort(function (a, b) { return b.perCrate - a.perCrate; })[0];
    if (best && pf.rows.length > 1) h += '<div class="alert blue">' + t('pf_best') + ': <b>' + esc(best.product ? best.product.name : '?') + '</b>' + (bestPc && bestPc !== best ? ' · ' + t('pf_best_crate') + ': <b>' + esc(bestPc.product.name) + '</b> (' + U.money(bestPc.perCrate) + ')' : '') + '</div>';
    var maxP = Math.max.apply(null, pf.rows.map(function (x) { return Math.abs(x.profit || 0); }).concat([1]));
    h += pf.rows.map(function (x) {
      var p = x.product || { name: '?', color: 'gray' }, neg = x.profit != null && x.profit < 0, w = x.profit == null ? 0 : Math.max(3, Math.round(Math.abs(x.profit) * 100 / maxP));
      var basis = x.basis === 'production' ? t('pf_basis_production') : x.basis === 'recipe' ? t('pf_basis_recipe') : t('pf_unknown') + (x.missing.length ? ' (' + t('pf_missing') + ': ' + esc(x.missing.join('، ')) + ')' : '');
      return '<div class="card pfcard"><div class="pfh"><div class="thumb">' + V.crate(p.color, 46) + '</div><div class="pfn"><b>' + esc(p.name) + '</b><small>' + B(K.fmtQty(x.qty)) + ' ' + t('pcs') + ' · ' + U.money(x.unitPrice) + ' / ' + t('crate') + '</small></div>' +
        '<span class="pfm ' + (x.margin == null ? 'na' : neg ? 'neg' : 'pos') + '">' + (x.margin == null ? '-' : B(x.margin + '%')) + '</span></div>' +
        '<div class="pfg"><div><span>' + t('pf_revenue') + '</span><b>' + U.money(x.revenue) + '</b></div><div><span>' + t('pf_cost') + '</span><b>' + (x.cost == null ? '-' : U.money(x.cost)) + '</b></div><div><span>' + t('pf_profit') + '</span><b class="' + (neg ? 'neg' : '') + '">' + (x.profit == null ? '-' : U.money(x.profit)) + '</b></div></div>' +
        '<div class="pfbar"><i class="' + (neg ? 'neg' : '') + '" style="width:' + w + '%"></i></div>' +
        '<div class="pff"><span class="chipinfo">' + basis + '</span>' + (x.perCrate != null ? '<span>' + t('pf_per_crate') + ': <b>' + U.money(x.perCrate) + '</b></span>' : '') + '</div></div>';
    }).join('');
    h += '<div class="alert blue">' + t('pf_method') + '</div>';
    return h + '<div class="btns noprint"><button class="btn" data-act="export_profit">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button><button class="btn" data-act="print_profit">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
  };
  X.profscope = function (el) { S.profScope = el.dataset.id; U.render(true); };
  X.print_profit = function () { printNow('KHALDI_PLAST_profit'); };
  X.export_profit = function () {
    var r = range(), pf = K.productProfitability(U.D, r.from, r.to), rows = [[t('product'), t('quantity'), t('pf_revenue'), t('pf_cost'), t('pf_profit'), t('pf_margin') + ' %', t('pf_per_crate')]];
    pf.rows.forEach(function (x) { rows.push([x.product ? x.product.name : '', x.qty, c2(x.revenue), c2(x.cost), c2(x.profit), x.margin == null ? '' : x.margin, c2(x.perCrate)]); });
    csv('khaldi_profit_' + (S.profScope === 'all' ? 'all' : S.profScope === 'year' ? S.ym.slice(0, 4) : S.ym) + '.csv', rows);
  };
})();
