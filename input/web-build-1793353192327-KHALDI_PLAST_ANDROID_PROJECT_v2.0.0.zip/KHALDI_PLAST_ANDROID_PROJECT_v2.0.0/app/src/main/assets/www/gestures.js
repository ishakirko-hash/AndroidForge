/* KHALDI PLAST v0.8 - touch gestures (offline, no library).
   - swipe sideways on a main page  -> next / previous tab (home, sales, stock, production, more)
   - swipe sideways on an inner page -> back
   - swipe down on a bottom sheet    -> close it
   Can be switched off from the customise page (settings.gestures === false). */
(function () {
  'use strict';
  var U = window.KPU; if (!U) return;
  var TABS = ['home', 'sales', 'stock', 'production', 'more'];
  var TABOF = { home: 'home', sales: 'sales', invoices: 'sales', invoice: 'sales', stock: 'stock', production: 'production', more: 'more' };
  var st = null;
  function on() { return !(U.D && U.D.settings && U.D.settings.gestures === false); }
  function rtl() { return document.documentElement.dir === 'rtl'; }
  function blocked(el) {
    for (var n = el; n && n !== document.body; n = n.parentElement) {
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(n.tagName) || n.isContentEditable) return true;
      if (n.classList && (n.classList.contains('wd-drag') || n.classList.contains('wd-rs') || n.classList.contains('ptable-wrap') || n.classList.contains('tablewrap') || n.classList.contains('shiftwrap'))) return true;
      if (n.scrollWidth > n.clientWidth + 4) { var ox = getComputedStyle(n).overflowX; if (ox === 'auto' || ox === 'scroll') return true; }
    }
    return false;
  }
  function slide(dir) { var m = document.getElementById('main'); if (!m || !m.animate) return; try { m.animate([{ transform: 'translateX(' + dir * 36 + 'px)', opacity: .35 }, { transform: 'none', opacity: 1 }], { duration: 200, easing: 'ease-out' }); } catch (_) { } }
  function tabGo(i) { var id = TABS[i]; U.closeModal(); U.stack = []; U.route = id; U.arg = null; U.render(); var m = document.getElementById('main'); if (m) m.scrollTop = 0; }
  document.addEventListener('touchstart', function (e) {
    st = null; if (e.touches.length !== 1 || !on()) return;
    var t = e.touches[0], sheet = e.target.closest && e.target.closest('#sheet');
    st = { x: t.clientX, y: t.clientY, t: Date.now(), sheet: sheet, sheetTop: sheet ? sheet.scrollTop : 0, bad: blocked(e.target) };
  }, { passive: true });
  document.addEventListener('touchend', function (e) {
    var s = st; st = null; if (!s || !on() || !e.changedTouches.length) return;
    var t = e.changedTouches[0], dx = t.clientX - s.x, dy = t.clientY - s.y, dt = Date.now() - s.t;
    if (dt > 700) return;
    if (U.modalOpen) { if (s.sheet && s.sheetTop === 0 && s.sheet.scrollTop === 0 && dy > 90 && Math.abs(dx) < dy * 0.6 && !s.bad) U.closeModal(); return; }
    if (s.bad || (U.S && U.S.homeEdit) || document.querySelector('#splash:not(.hidden)')) return;
    if (Math.abs(dx) < 80 || Math.abs(dy) > Math.abs(dx) * 0.5) return;
    var next = rtl() ? dx > 0 : dx < 0;       // finger moves toward where the next page is
    var tab = TABOF[U.route], isTabPage = U.route in { home: 1, sales: 1, stock: 1, production: 1, more: 1 } && !U.stack.length;
    if (isTabPage) { var i = TABS.indexOf(tab) + (next ? 1 : -1); if (i < 0 || i >= TABS.length) return; tabGo(i); slide(next ? (rtl() ? 1 : -1) : (rtl() ? -1 : 1)); }
    else if (!next && window.KPBack) { window.KPBack(); slide(rtl() ? -1 : 1); }   // back = the opposite direction
  }, { passive: true });
  document.addEventListener('touchcancel', function () { st = null; }, { passive: true });
  U.gestures = { on: on };
})();
