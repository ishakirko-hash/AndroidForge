/* KHALDI PLAST - v2.0 business logic (pure functions, same rules as core.js: integer centimes, void-never-delete,
 * everything derived from the records). Extends KP. New data arrays are additive and created lazily:
 * d.quotes, d.maintenance, d.counters.quote. */
(function (root) {
  'use strict';
  var K = (typeof module !== 'undefined' && module.exports) ? require('./core.js') : root.KP;
  var E = K.E, byId = K.byId, sum = K.sum, live = K.live;
  function dn(s) { return Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)) / 86400000; }
  function age(from, to) { return Math.round(dn(to) - dn(from)); }
  function str(v) { return v == null ? '' : String(v).trim(); }
  function okDate(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(dn(s)); }
  function needDate(s) { if (!okDate(s)) throw E('bad_date'); }
  function ensure(d) { d.quotes = d.quotes || []; d.maintenance = d.maintenance || []; d.counters = d.counters || { invoice: 0 }; return d; }
  function stampNow() { return new Date().toISOString(); }

  /* ---------- 1. receivables ageing (who owes, since when) ---------- */
  var BUCKETS = [30, 60, 90];   // 0-30, 31-60, 61-90, 90+
  function bucketOf(a) { return a <= 30 ? 0 : a <= 60 ? 1 : a <= 90 ? 2 : 3; }
  function ageingReport(d, asOf) {
    var rows = [], totals = [0, 0, 0, 0], total = 0;
    d.customers.forEach(function (c) {
      var bal = K.customerBalance(d, c.id), b = [0, 0, 0, 0], inv = [], sumSales = 0;
      live(d.sales).filter(function (s) { return s.customerId === c.id; }).forEach(function (s) {
        var o = K.saleOutstanding(d, s.id); if (o > 0) { var a = Math.max(0, age(s.date, asOf)); b[bucketOf(a)] += o; sumSales += o; inv.push({ sale: s, outstanding: o, age: a }); }
      });
      if (bal > sumSales) b[0] += bal - sumSales;           // opening / unallocated balance counts as current
      if (bal <= 0) return;
      var pays = live(d.payments).filter(function (p) { return p.customerId === c.id && !p.initial; }).sort(function (x, y) { return x.date < y.date ? 1 : -1; });
      inv.sort(function (x, y) { return y.age - x.age; });
      rows.push({ customer: c, balance: bal, buckets: b, invoices: inv, oldest: inv.length ? inv[0].age : 0, lastPayment: pays.length ? pays[0].date : '' });
      b.forEach(function (v, i) { totals[i] += v; }); total += bal;
    });
    rows.sort(function (x, y) { return y.buckets[3] - x.buckets[3] || y.oldest - x.oldest || y.balance - x.balance; });
    return { asOf: asOf, rows: rows, totals: totals, total: total, overdue: totals[1] + totals[2] + totals[3] };
  }

  /* ---------- 2. customer statement with running balance ---------- */
  function customerStatement(d, cid, from, to) {
    var c = byId(d.customers, cid); if (!c) throw E('no_customer');
    needDate(from); needDate(to); if (from > to) throw E('bad_range');
    var ev = [];
    live(d.sales).filter(function (s) { return s.customerId === cid; }).forEach(function (s) { ev.push({ date: s.date, ts: s.ts || '', type: 'sale', ref: s.id, no: s.no, debit: s.total, credit: 0 }); });
    live(d.payments).filter(function (p) { return p.customerId === cid; }).forEach(function (p) { ev.push({ date: p.date, ts: p.ts || '', type: 'payment', ref: p.id, saleId: p.saleId, method: p.method, debit: 0, credit: p.amount }); });
    ev.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : (a.type === 'sale' ? -1 : 1)); });
    var bal = 0, opening = 0, lines = [], td = 0, tc = 0;
    ev.forEach(function (e) {
      if (e.date < from) { bal += e.debit - e.credit; opening = bal; return; }
      if (e.date > to) return;
      bal += e.debit - e.credit; td += e.debit; tc += e.credit; e.balance = bal; lines.push(e);
    });
    return { customer: c, from: from, to: to, opening: opening, lines: lines, totalDebit: td, totalCredit: tc, closing: opening + td - tc };
  }

  /* ---------- 3. daily closing ---------- */
  function dailyClose(d, day) {
    needDate(day);
    var sales = live(d.sales).filter(function (s) { return s.date === day; }), pays = live(d.payments).filter(function (p) { return p.date === day; });
    var byMethod = {}; pays.forEach(function (p) { byMethod[p.method || 'cash'] = (byMethod[p.method || 'cash'] || 0) + p.amount; });
    var exps = live(d.expenses).filter(function (e) { return e.date === day; }), spays = live(d.supplierPayments).filter(function (p) { return p.date === day; }), purch = live(d.purchases).filter(function (p) { return p.date === day; });
    var prod = {}; live(d.production).filter(function (r) { return r.date === day; }).forEach(function (r) { var o = prod[r.productId] || (prod[r.productId] = { good: 0, defective: 0 }); o.good += r.good; o.defective += r.defective; });
    var cashIn = byMethod.cash || 0, cashOut = sum(exps.filter(function (e) { return (e.method || 'cash') === 'cash'; }), function (e) { return e.amount; }) + sum(spays.filter(function (p) { return (p.method || 'cash') === 'cash'; }), function (p) { return p.amount; });
    return { day: day, salesCount: sales.length, salesTotal: sum(sales, function (s) { return s.total; }), crates: sum(sales, function (s) { return sum(s.items, function (i) { return i.qty; }); }),
      collected: sum(pays, function (p) { return p.amount; }), byMethod: byMethod, expenses: sum(exps, function (e) { return e.amount; }), expenseCount: exps.length, purchases: sum(purch, function (p) { return p.total; }), supplierPaid: sum(spays, function (p) { return p.amount; }),
      production: prod, good: sum(Object.keys(prod), function (k) { return prod[k].good; }), defective: sum(Object.keys(prod), function (k) { return prod[k].defective; }),
      cashIn: cashIn, cashOut: cashOut, cashNet: cashIn - cashOut, unpaidToday: sum(sales, function (s) { return Math.max(0, K.saleOutstanding(d, s.id)); }) };
  }

  /* ---------- 4. cash book (cash method only) ---------- */
  function cashBook(d, from, to) {
    needDate(from); needDate(to); if (from > to) throw E('bad_range');
    var ev = [];
    live(d.payments).filter(function (p) { return (p.method || 'cash') === 'cash'; }).forEach(function (p) { ev.push({ date: p.date, ts: p.ts || '', type: 'in_customer', ref: p.id, who: p.customerId, in: p.amount, out: 0 }); });
    live(d.expenses).filter(function (e) { return (e.method || 'cash') === 'cash'; }).forEach(function (e) { ev.push({ date: e.date, ts: e.ts || '', type: 'out_expense', ref: e.id, who: e.categoryId, text: e.description, in: 0, out: e.amount }); });
    live(d.supplierPayments).filter(function (p) { return (p.method || 'cash') === 'cash'; }).forEach(function (p) { ev.push({ date: p.date, ts: p.ts || '', type: 'out_supplier', ref: p.id, who: p.supplierId, in: 0, out: p.amount }); });
    ev.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : 0); });
    var bal = 0, opening = 0, lines = [], ti = 0, to_ = 0;
    ev.forEach(function (e) { if (e.date < from) { bal += e.in - e.out; opening = bal; return; } if (e.date > to) return; bal += e.in - e.out; ti += e.in; to_ += e.out; e.balance = bal; lines.push(e); });
    return { from: from, to: to, opening: opening, lines: lines, totalIn: ti, totalOut: to_, closing: opening + ti - to_ };
  }

  /* ---------- 5. raw-material forecast ---------- */
  function materialForecast(d, today, windowDays, targetDays) {
    var w = windowDays || 30, tg = targetDays || 30, from = K.addDays(today, -(w - 1)), used = {};
    live(d.production).filter(function (r) { return r.date >= from && r.date <= today; }).forEach(function (r) { r.consumption.forEach(function (l) { used[l.materialId] = (used[l.materialId] || 0) + l.qty; }); });
    return d.materials.filter(function (m) { return !m.archived; }).map(function (m) {
      var u = K.round3(used[m.id] || 0), daily = u / w, cover = daily > 0 ? m.stock / daily : null, sug = daily > 0 ? Math.max(0, Math.ceil(K.round3(daily * tg - m.stock))) : 0, avg = K.avgMaterialCost(d, m.id);
      var status = cover == null ? 'nodata' : cover < 7 ? 'critical' : cover < 15 ? 'soon' : 'ok';
      return { material: m, used: u, daily: K.round3(daily), cover: cover == null ? null : Math.round(cover * 10) / 10, suggested: sug, est: avg == null ? null : Math.round(sug * avg), status: status, runOut: cover == null ? '' : K.addDays(today, Math.floor(cover)) };
    }).sort(function (a, b) { var r = { critical: 0, soon: 1, ok: 2, nodata: 3 }; return r[a.status] - r[b.status] || (a.cover || 1e9) - (b.cover || 1e9); });
  }

  /* ---------- 6. stocktake (counted quantities -> adjustments) ---------- */
  function applyStocktake(d, o) {
    needDate(o.date); var changes = [];
    Object.keys(o.counts || {}).forEach(function (id) {
      var it = byId(o.kind === 'product' ? d.products : d.materials, id); if (!it) throw E('no_item');
      var v = o.counts[id]; if (v === '' || v == null) return; var n = K.round3(Number(v)); if (!(n >= 0)) throw E('bad_qty');
      if (n === K.round3(it.stock)) return;
      changes.push({ itemId: id, name: it.name, before: it.stock, after: n });
      K.adjustStock(d, { date: o.date, kind: o.kind, itemId: id, newStock: n, note: 'STOCKTAKE ' + (str(o.note) || o.date) });
    });
    return changes;
  }

  /* ---------- 7. machine maintenance ---------- */
  function addMaintenance(d, o) {
    ensure(d); needDate(o.date); if (!byId(d.machines, o.machineId)) throw E('no_item');
    var kind = o.kind === 'repair' ? 'repair' : 'preventive', nd = str(o.nextDue); if (nd) { needDate(nd); if (nd < o.date) throw E('bad_range'); }
    var r = { id: K.uid('mnt'), ts: stampNow(), date: o.date, machineId: o.machineId, kind: kind, note: str(o.note), nextDue: nd, voided: false };
    d.maintenance.push(r); return r;
  }
  function voidMaintenance(d, id) { ensure(d); var r = byId(d.maintenance, id); if (!r || r.voided) throw E('no_item'); r.voided = true; }
  function maintenanceStatus(d, today) {
    ensure(d);
    return d.machines.filter(function (m) { return !m.archived; }).map(function (m) {
      var recs = live(d.maintenance).filter(function (r) { return r.machineId === m.id; }).sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : (a.ts < b.ts ? 1 : -1); });
      var last = recs[0] || null, nd = last ? last.nextDue : '', st = !last ? 'never' : !nd ? 'ok' : nd < today ? 'overdue' : age(today, nd) <= 7 ? 'soon' : 'ok';
      return { machine: m, last: last, nextDue: nd, daysTo: nd ? age(today, nd) : null, status: st, count: recs.length, records: recs };
    }).sort(function (a, b) { var r = { overdue: 0, soon: 1, never: 2, ok: 3 }; return r[a.status] - r[b.status]; });
  }

  /* ---------- 8. quotations ---------- */
  function cleanQItems(d, items) {
    if (!Array.isArray(items) || !items.length) throw E('items_required');
    return items.map(function (it) {
      if (!byId(d.products, it.productId)) throw E('no_product');
      if (!(it.qty > 0) || Math.floor(it.qty) !== it.qty) throw E('bad_qty');
      if (!(it.unitPrice > 0) || Math.floor(it.unitPrice) !== it.unitPrice) throw E('bad_amount');
      return { productId: it.productId, qty: it.qty, unitPrice: it.unitPrice, weightG: 0 };
    });
  }
  function qTotals(items, discount) {
    var sub = sum(items, function (i) { return i.qty * i.unitPrice; }), disc = discount || 0;
    if (!(disc >= 0) || Math.floor(disc) !== disc) throw E('bad_discount'); if (disc > sub) throw E('discount_exceeds');
    return { subtotal: sub, discount: disc, total: sub - disc };
  }
  function addQuote(d, o) {
    ensure(d); needDate(o.date); var items = cleanQItems(d, o.items), t = qTotals(items, o.discount), vu = str(o.validUntil); if (vu) { needDate(vu); if (vu < o.date) throw E('bad_range'); }
    var cust = o.customerId ? byId(d.customers, o.customerId) : null; if (o.customerId && !cust) throw E('no_customer');
    d.counters.quote = (d.counters.quote || 0) + 1;
    var q = { id: K.uid('qt'), ts: stampNow(), no: d.counters.quote, date: o.date, customerId: cust ? cust.id : null, customerName: cust ? '' : str(o.customerName), items: items, subtotal: t.subtotal, discount: t.discount, total: t.total, validUntil: vu, notes: str(o.notes), status: 'open', saleId: null, voided: false };
    d.quotes.push(q); return q;
  }
  function editQuote(d, id, o) {
    ensure(d); var q = byId(d.quotes, id); if (!q || q.voided) throw E('no_item'); if (q.status === 'converted') throw E('quote_converted');
    needDate(o.date); var items = cleanQItems(d, o.items), t = qTotals(items, o.discount), vu = str(o.validUntil); if (vu) { needDate(vu); if (vu < o.date) throw E('bad_range'); }
    var cust = o.customerId ? byId(d.customers, o.customerId) : null; if (o.customerId && !cust) throw E('no_customer');
    q.date = o.date; q.customerId = cust ? cust.id : null; q.customerName = cust ? '' : str(o.customerName); q.items = items; q.subtotal = t.subtotal; q.discount = t.discount; q.total = t.total; q.validUntil = vu; q.notes = str(o.notes);
  }
  function voidQuote(d, id) { ensure(d); var q = byId(d.quotes, id); if (!q || q.voided) throw E('no_item'); if (q.status === 'converted') throw E('quote_converted'); q.voided = true; q.status = 'void'; }
  function quoteState(q, today) { if (q.voided) return 'void'; if (q.status === 'converted') return 'converted'; return q.validUntil && q.validUntil < today ? 'expired' : 'open'; }
  // Turns an open quote into a real invoice (stock and balances move exactly like any sale; throws insufficient_stock if it cannot be delivered).
  function convertQuote(d, id, o) {
    ensure(d); var q = byId(d.quotes, id); if (!q || q.voided) throw E('no_item'); if (q.status === 'converted') throw E('quote_converted');
    if (!q.customerId && !(o.paid >= q.total)) throw E('customer_required_for_credit');
    var s = K.recordSale(d, { date: o.date, customerId: q.customerId, items: q.items.map(function (i) { return { productId: i.productId, qty: i.qty, unitPrice: i.unitPrice, weightG: 0 }; }), discount: q.discount, paid: o.paid || 0, method: o.method || 'cash', notes: q.notes });
    q.status = 'converted'; q.saleId = s.id; return s;
  }

  /* ---------- 9. smart insights (rules over the real data; nothing invented) ---------- */
  function insights(d, today) {
    var out = [], ym = today.slice(0, 7), pm = K.addMonths(ym, -1), cur = K.monthlyReport(d, ym), prev = K.monthlyReport(d, pm);
    function add(id, tone, icon, params, route) { out.push({ id: id, tone: tone, icon: icon, params: params || {}, route: route || '' }); }
    if (prev.sales > 0 && cur.sales > 0) { var pc = Math.round((cur.sales - prev.sales) * 100 / prev.sales); if (Math.abs(pc) >= 5) add(pc >= 0 ? 'sales_up' : 'sales_down', pc >= 0 ? 'green' : 'red', 'bars', { pct: Math.abs(pc) }, 'reports'); }
    var r = K.monthRange(ym), byC = {}; live(d.sales).filter(function (s) { return s.date >= r.from && s.date <= r.to && s.customerId; }).forEach(function (s) { byC[s.customerId] = (byC[s.customerId] || 0) + s.total; });
    var tk = Object.keys(byC).sort(function (a, b) { return byC[b] - byC[a]; });
    if (tk.length && cur.sales > 0) { var cc = byId(d.customers, tk[0]); add('top_customer', 'blue', 'user', { name: cc ? cc.name : '', pct: Math.round(byC[tk[0]] * 100 / cur.sales) }, 'customers'); }
    var wd = [0, 0, 0, 0, 0, 0, 0], from8 = K.addDays(today, -55); live(d.sales).filter(function (s) { return s.date >= from8 && s.date <= today; }).forEach(function (s) { wd[(new Date(dn(s.date) * 86400000)).getUTCDay()] += s.total; });
    var best = wd.indexOf(Math.max.apply(null, wd)); if (Math.max.apply(null, wd) > 0) add('best_day', 'blue', 'calendar', { dow: best }, 'sales');
    var ag = ageingReport(d, today); if (ag.overdue > 0) add('overdue', 'red', 'wallet', { amount: ag.overdue, n: ag.rows.filter(function (x) { return x.buckets[1] + x.buckets[2] + x.buckets[3] > 0; }).length }, 'collect');
    var fc = materialForecast(d, today).filter(function (x) { return x.status === 'critical'; }); if (fc.length) add('material_low', 'red', 'scale', { name: fc[0].material.name, days: Math.max(0, Math.floor(fc[0].cover)), n: fc.length }, 'forecast');
    var tot = cur.good + cur.defective; if (tot >= 100 && cur.defective * 100 / tot > 5) add('defect_high', 'amber', 'alert', { pct: Math.round(cur.defective * 1000 / tot) / 10 }, 'production');
    var w1 = K.sum(live(d.production).filter(function (x) { return x.date > K.addDays(today, -7) && x.date <= today; }), function (x) { return x.good; }), w0 = K.sum(live(d.production).filter(function (x) { return x.date > K.addDays(today, -14) && x.date <= K.addDays(today, -7); }), function (x) { return x.good; });
    if (w0 >= 100 && w1 < w0 * 0.8) add('prod_drop', 'amber', 'machine', { pct: Math.round((w0 - w1) * 100 / w0) }, 'prodtable');
    if (cur.sales > 0 && cur.collected * 2 < cur.sales) add('low_collect', 'amber', 'wallet', { pct: Math.round(cur.collected * 100 / cur.sales) }, 'collect');
    var ms = maintenanceStatus(d, today).filter(function (x) { return x.status === 'overdue'; }); if (ms.length) add('maint_due', 'amber', 'machine', { name: ms[0].machine.name, n: ms.length }, 'maintenance');
    var sold = {}; live(d.sales).filter(function (s) { return s.date > K.addDays(today, -30) && s.date <= today; }).forEach(function (s) { s.items.forEach(function (i) { sold[i.productId] = (sold[i.productId] || 0) + i.qty; }); });
    d.products.filter(function (p) { return !p.archived; }).forEach(function (p) { var dly = (sold[p.id] || 0) / 30; if (dly > 0 && p.stock / dly < 3) add('product_low', 'amber', 'box', { name: p.name, days: Math.floor(p.stock / dly) }, 'stock'); });
    var lb = d.settings && d.settings.lastBackup; if (!lb || Date.now() - new Date(lb).getTime() > 7 * 864e5) add('backup_old', 'amber', 'save', {}, 'backup');
    var q = (d.quotes || []).filter(function (x) { return quoteState(x, today) === 'open'; }); if (q.length) add('quotes_open', 'blue', 'note', { n: q.length }, 'quotes');
    return out;
  }

  var API = { ageingReport: ageingReport, customerStatement: customerStatement, dailyClose: dailyClose, cashBook: cashBook, materialForecast: materialForecast, applyStocktake: applyStocktake,
    addMaintenance: addMaintenance, voidMaintenance: voidMaintenance, maintenanceStatus: maintenanceStatus, addQuote: addQuote, editQuote: editQuote, voidQuote: voidQuote, convertQuote: convertQuote, quoteState: quoteState, insights: insights, ensure2: ensure, daysBetween: age };
  Object.keys(API).forEach(function (k) { K[k] = API[k]; });
  if (typeof module !== 'undefined' && module.exports) module.exports = K;
})(typeof window !== 'undefined' ? window : this);
