// v1.0: payroll sheet + profitability screens through the real UI.
const L=require('./lib.js'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const go=async(r,a)=>{ await p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.route=r;window.KPU.arg=a||null;window.KPU.render();},[r,a]); await p.waitForTimeout(80); };
 await p.setViewportSize({width:390,height:1600});
 const ids=await p.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(),ym=td.slice(0,7),r={};
  U.commit(d=>{ const w1=K.addWorker(d,{name:'Ali',role:'Operator',rate:200000}), w2=K.addWorker(d,{name:'Bob',rate:150000}); r.w1=w1.id;
   [ym+'-02',ym+'-03',ym+'-04'].forEach(dt=>{ K.setShiftRoster(d,{date:dt,shift:1,entries:[{workerId:w1.id,worked:true},{workerId:w2.id,worked:dt!==ym+'-04'}]}); });
   K.recordWorkerPayment(d,{date:ym+'-05',workerId:w1.id,amount:100000,kind:'advance',method:'cash'});
   const sp=K.addSupplier(d,{name:'S'}), c=K.addCustomer(d,{name:'C'});
   K.recordPurchase(d,{date:ym+'-01',supplierId:sp.id,materialId:d.materials[0].id,qty:1000,unitCost:15000,paid:15000000,method:'cash'});
   const g={}; g[d.materials[0].id]=800; K.recordProduction(d,{date:ym+'-02',productId:d.products[0].id,good:100,defective:10,grams:g});
   K.recordSale(d,{date:ym+'-10',customerId:c.id,items:[{productId:d.products[0].id,qty:50,unitPrice:30000}],paid:1500000,method:'cash'}); });
  return r; });
 // payroll
 await go('payroll'); let t=await p.locator('#main').innerText();
 ok(t.includes('Ali') && t.includes('Bob') && t.includes('كشف أجور'),'payroll sheet lists the workers');
 const rowA=await p.locator('table.paytable tbody tr',{hasText:'Ali'}).innerText(); ok(/3/.test(rowA) && rowA.includes('6,000') && rowA.includes('1,000') && rowA.includes('5,000'),'Ali: 3 shifts, earned 6,000, advance 1,000, due 5,000 :: '+rowA.replace(/\s+/g,' '));
 const rowB=await p.locator('table.paytable tbody tr',{hasText:'Bob'}).innerText(); ok(rowB.includes('3,000'),'Bob: earned 3,000');
 ok((await p.locator('table.paytable tfoot').innerText()).includes('9,000') ,'footer total earned 9,000');
 await p.screenshot({path:SH+'/pay_390.png',fullPage:true});
 // settle Ali's balance from the sheet
 await p.click('[data-act="pay_due"][data-id="'+ids.w1+'"]'); ok((await p.locator('#f_amount').inputValue()).replace(/[,\s]/g,'')==='5000' && (await p.locator('#f_kind').inputValue())==='salary','settle opens the payment form prefilled with the balance (salary)');
 await p.click('#f button[type="submit"]'); await p.waitForTimeout(150); let d=await D();
 ok(d.workerPayments.length===2 && d.workerPayments[1].amount===500000 && d.workerPayments[1].kind==='salary','payment recorded: 5,000 as salary');
 ok(!(await p.locator('[data-act="pay_due"][data-id="'+ids.w1+'"]').count()),'Ali no longer has a balance to settle');
 ok((await p.locator('table.paytable tbody tr',{hasText:'Ali'}).innerText()).includes('0'),'Ali due is 0 after settling');
 // previous month: nothing carried here
 await p.evaluate(()=>{ const U=window.KPU; U.S.ym=U.K.addMonths(U.S.ym,-1); }); await go('payroll'); t=await p.locator('#main').innerText(); ok(t.includes('Ali'),'previous month still lists active workers (zero shifts)');
 await p.evaluate(()=>{ const U=window.KPU; U.S.ym=U.K.today().slice(0,7); });
 // profitability
 await go('profit'); t=await p.locator('#main').innerText();
 ok(t.includes('15,000') && t.includes('6,600') && t.includes('8,400'),'profit: revenue 15,000, cost 6,600 (13,200 x50 /100), profit 8,400 :: '+t.replace(/\s+/g,' ').slice(0,220));
 ok(t.includes('56%') || t.includes('56'),'profit: margin 56%');
 ok(t.includes('التكلفة من الإنتاج الفعلي'),'profit: says the cost comes from real production');
 await p.screenshot({path:SH+'/profit_390.png',fullPage:true});
 await p.click('[data-act="profscope"][data-id="all"]'); ok((await p.locator('#main').innerText()).includes('15,000'),'scope: all time works');
 await p.click('[data-act="profscope"][data-id="year"]'); ok((await p.locator('#main').innerText()).includes('15,000'),'scope: year works');
 // honest: product with sales but no cost basis
 await p.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ const c=d.customers[0]; K.adjustStock(d,{date:K.today(),kind:'product',itemId:d.products[1].id,newStock:20,note:'t'}); K.recordSale(d,{date:K.today(),customerId:c.id,items:[{productId:d.products[1].id,qty:2,unitPrice:20000}],paid:40000,method:'cash'}); }); window.KPU.S.profScope='month'; }); await go('profit');
 t=await p.locator('#main').innerText(); ok(t.includes('التكلفة غير معروفة') && t.includes('لم تُحتسب'),'unknown cost is flagged, not invented');
 // tiles exist in More + reports link
 await go('more'); ok((await p.locator('.tilebtn[data-id="payroll"]').count())===1 && (await p.locator('.tilebtn[data-id="profit"]').count())===1,'More lists payroll + profit tiles');
 await go('reports'); ok((await p.locator('[data-act="goto"][data-id="profit"]').count())===1,'reports page links to profitability');
 await p.evaluate(()=>{window.KPU.S.workTab='list';}); await go('workers'); ok((await p.locator('[data-act="goto"][data-id="payroll"]').count())===1,'workers page links to payroll');
 // overflow
 for(const w of [360,390,412]){ await p.setViewportSize({width:w,height:1600}); for(const r of ['payroll','profit']){ await go(r); const o=await p.evaluate(()=>[document.documentElement.scrollWidth-document.documentElement.clientWidth,document.querySelector('#main').scrollWidth-document.querySelector('#main').clientWidth]); ok(o.every(x=>x<=1),'no page overflow '+r+' @'+w+' '+o); } }
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
