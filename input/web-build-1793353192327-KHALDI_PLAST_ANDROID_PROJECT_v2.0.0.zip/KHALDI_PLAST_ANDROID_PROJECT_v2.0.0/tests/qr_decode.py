# usage: python3 qr_decode.py image.png  -> prints decoded text (uses OpenCV's independent QR reader; tries several scales because its detector is scale-sensitive)
import sys, cv2
img = cv2.imread(sys.argv[1], cv2.IMREAD_GRAYSCALE)
img = cv2.copyMakeBorder(img, 30, 30, 30, 30, cv2.BORDER_CONSTANT, value=255)
val = ''
for sc in (1, 0.5, 0.25, 0.7, 0.35):
    im = img if sc == 1 else cv2.resize(img, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    val, _, _ = cv2.QRCodeDetector().detectAndDecode(im)
    if val: break
sys.stdout.write(val)
