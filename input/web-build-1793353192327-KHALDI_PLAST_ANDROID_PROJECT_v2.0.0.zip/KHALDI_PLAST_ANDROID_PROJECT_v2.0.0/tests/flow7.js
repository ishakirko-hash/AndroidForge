// v0.9 invoice design through the UI: delivery fields in the sale form, product spec, invoice content, settings notes, print layout.
const L=require('./lib.js');
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const go=async(r,a)=>{ await p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.route=r;window.KPU.arg=a||null;window.KPU.render();},[r,a]); await p.waitForTimeout(60); };
 await p.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ K.adjustStock(d,{date:K.today(),kind:'product',itemId:d.products[0].id,newStock:500,note:'t'}); K.addCustomer(d,{name:'Zed',phone:'0550 12 34 56',address:'Alger'}); }); });
 // product spec
 await go('stock'); await p.evaluate(()=>window.KPU.forms.item('product',window.KPU.D.products[0].id)); await p.fill('#f_spec','600 × 400 × 320 mm'); await p.fill('#f_code','PL001'); await p.click('#f button[type="submit"]'); await p.waitForTimeout(120);
 let d=await D(); ok(d.products[0].spec==='600 × 400 × 320 mm' && d.products[0].code==='PL001','product spec saved from the form');
 // sale with delivery
 await go('sales'); await p.evaluate(()=>window.KPU.forms.sale()); await p.selectOption('#f_customer',{index:1}).catch(()=>{});
 await p.fill('.itrow [data-k="qty"]','200'); await p.fill('.itrow [data-k="price"]','320'); await p.fill('#f_paid','64000');
 await p.fill('#f_dMethod','بواسطة الزبون'); await p.fill('#f_dNotes','صباحاً');
 const dd=await p.evaluate(()=>window.KPU.K.today()); await p.fill('#f_dDate',dd);
 await p.click('#f button[type="submit"]'); await p.waitForTimeout(150);
 d=await D(); const sale=d.sales[0]; ok(sale && sale.delivery.method==='بواسطة الزبون' && sale.delivery.date===dd && sale.delivery.notes==='صباحاً','delivery info saved with the sale: '+JSON.stringify(sale&&sale.delivery));
 const t=await p.locator('.paper').innerText();
 ok(t.includes('معلومات التسليم') && t.includes('بواسطة الزبون') && t.includes('صباحاً'),'invoice shows the delivery card');
 ok(t.includes('600 × 400 × 320 mm') && t.includes('PL001'),'invoice shows code + specs');
 ok(t.includes('FACTURE DE VENTE') && t.includes('المجموع الكلي') && t.includes('توقيع') && t.includes('ختم المؤسسة'),'invoice has title, grand total, signature + stamp');
 ok(!t.includes('الضريبة'),'no invented tax line');
 ok((await p.locator('.paper .iv-info').count())===1 && (await p.locator('.paper .iv-foot').count())===1 && (await p.locator('.paper .iv-hero').count())===1,'invoice layout blocks present');
 // old sale without delivery still renders
 await p.evaluate(()=>{ window.KPU.commit(dd=>{ delete dd.sales[0].delivery; }); }); await go('invoice',sale.id);
 ok((await p.locator('.paper').innerText()).includes('—'),'sale without delivery data renders dashes');
 // settings notes
 await go('settings'); await p.click('[data-act="edit_company"]').catch(async()=>{ await p.evaluate(()=>window.KPU.forms.company()); });
 await p.fill('#f_invNotes','ملاحظة أولى\nملاحظة ثانية'); await p.click('#f button[type="submit"]'); await p.waitForTimeout(100);
 await go('invoice',sale.id); const t2=await p.locator('.paper .nt').innerText(); ok(t2.includes('ملاحظة أولى') && t2.includes('ملاحظة ثانية') && !t2.includes('البضاعة سليمة'),'custom invoice notes replace the defaults');
 await p.evaluate(()=>{ window.KPU.commit(dd=>{ dd.settings.invoiceNotes=''; }); }); await go('invoice',sale.id); ok(!(await p.locator('.paper .nt li').count()),'empty notes setting shows no bullets');
 // widths: no horizontal overflow on the invoice
 for(const w of [360,390,412]){ await p.setViewportSize({width:w,height:1400}); await go('invoice',sale.id); const o=await p.evaluate(()=>{const m=document.querySelector('#main');return [document.documentElement.scrollWidth-document.documentElement.clientWidth,m.scrollWidth-m.clientWidth,document.querySelector('.paper').scrollWidth-document.querySelector('.paper').clientWidth];}); ok(o.every(x=>x<=1),'invoice no overflow at '+w+' '+o); }
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
