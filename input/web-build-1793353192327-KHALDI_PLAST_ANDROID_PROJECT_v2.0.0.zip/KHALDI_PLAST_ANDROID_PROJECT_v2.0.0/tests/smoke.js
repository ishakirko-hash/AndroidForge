// Visits every screen on a phone viewport, fails on JS errors / horizontal overflow, saves screenshots.
const L=require('./lib.js'), fs=require('fs');
(async()=>{ const vw=+process.argv[3]||390, out=process.argv[4]||'/tmp/shots'; fs.mkdirSync(out,{recursive:true});
 const s=await L.start(process.argv[2],vw), p=s.page; let bad=0;
 await p.waitForSelector('#splash.hidden',{state:'attached'});
 const routes=['home','sales','invoices','stock','production','prodtable','workers','customers','suppliers','notes','assistant','customize','more','payroll','profit','purchases','expenses','debts','reports','transactions','settings','backup','quotes','collect','dailyclose','cashbook','forecast','stocktake','maintenance','insights'];
 for(const r of routes){
  await p.evaluate(r=>{ window.KPU.stack=[]; window.KPU.route=r; window.KPU.arg=null; window.KPU.render(); },r);
  await p.waitForTimeout(80);
  const ov=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,m:document.getElementById('main').scrollWidth,mc:document.getElementById('main').clientWidth}));
  const flag=(ov.sw>ov.cw+1||ov.m>ov.mc+1)?' OVERFLOW '+JSON.stringify(ov):'';
  if(flag) bad++;
  console.log(r+flag); await p.screenshot({path:out+'/'+r+'_'+vw+'.png'});
 }
 for(const w of ['today','week','list']){ await p.evaluate(w=>{window.KPU.S.workTab=w;window.KPU.stack=[];window.KPU.route='workers';window.KPU.render();},w); await p.screenshot({path:out+'/workers_'+w+'_'+vw+'.png'}); }
 console.log('errors:',s.errors.length?s.errors:'none'); if(s.errors.length) bad++;
 await s.close(); process.exit(bad?1:0); })();
