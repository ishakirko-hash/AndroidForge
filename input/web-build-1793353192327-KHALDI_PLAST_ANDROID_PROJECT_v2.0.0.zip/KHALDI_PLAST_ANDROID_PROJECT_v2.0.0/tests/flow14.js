// v2.0: quotes, statement, collection centre, daily close, cash book, forecast, stocktake, maintenance, insights, PIN lock.
const L=require('./lib.js'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2],390); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const go=async(r,a)=>{ await p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.go(r,a);},[r,a||null]); await p.waitForTimeout(80); };
 const main=()=>p.locator('#main').innerText();
 const overflow=()=>p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth+1);
 await p.evaluate(()=>{ window.__shared=[]; window.__files=[]; window.__printed=0; window.KPU.AND=null; navigator.share=(o)=>{window.__shared.push(o.text);return Promise.resolve();}; window.print=()=>{window.__printed++;}; const sf=window.KPU.saveFile; window.KPU.saveFile=function(n,m,c){window.__files.push({n,c});window.KPExportDone(true,false);}; });
 // seed
 const ids=await p.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(); let o={};
   U.commit(d=>{ const a=K.addCustomer(d,{name:'Old Debtor',phone:'0550111222'}), b=K.addCustomer(d,{name:'Fresh Buyer',phone:'0660'}); const pr=d.products[0], m0=d.materials[0];
     o.a=a.id;o.b=b.id;o.pr=pr.id;o.m0=m0.id;
     K.recordPurchase(d,{date:K.addDays(td,-40),supplierId:K.addSupplier(d,{name:'S1'}).id,materialId:m0.id,qty:2000,unitCost:15000,paid:0,method:'cash'});
     for(let i=0;i<10;i++) K.recordProduction(d,{date:K.addDays(td,-i),shift:1,productId:pr.id,good:100,defective:i===0?20:0,grams:{[m0.id]:500}});
     K.recordSale(d,{date:K.addDays(td,-70),customerId:a.id,items:[{productId:pr.id,qty:50,unitPrice:20000,weightG:0}],paid:0,method:'cash'});
     K.recordSale(d,{date:td,customerId:b.id,items:[{productId:pr.id,qty:20,unitPrice:20000,weightG:0}],paid:150000,method:'cash'});
     K.recordCustomerPayment(d,{date:K.addDays(td,-5),customerId:a.id,amount:100000,method:'cash'});
     K.recordExpense(d,{date:td,categoryId:d.expenseCats[0].id,amount:30000,description:'Diesel',method:'cash'});
     K.addMachine(d,{name:'M-1'}); });
   U.render(); return o; });
 // ---- layout migration
 await p.evaluate(()=>{ const U=window.KPU; U.commit(d=>{ d.settings.layout={v:1,hv:2,hidden:['x'],order:[],icons:{},secOrder:[],secHidden:[],wOrder:[],sizes:{},shown:[]}; }); U.migrateLayout(); });
 let d=await D(); ok(d.settings.layout.v2===1 && ['quotes','collect','insights'].every(k=>d.settings.layout.hidden.includes(k)),'old layouts: new tiles hidden from home once, flag set');
 await go('more'); ok((await p.locator('.tiles .tilebtn').count())===30,'More lists 30 sections');
 const lbl=await p.locator('.tiles .tilebtn span:last-child').allInnerTexts(); ok(['عروض الأسعار','مركز التحصيل','إقفال اليوم','دفتر الصندوق','توقع المواد','جرد المخزون','صيانة الآلات','رؤى ذكية'].every(x=>lbl.includes(x)),'the 8 new tiles are labelled');
 // ---- quotes
 await p.click('.tilebtn[data-id="quotes"]'); await p.waitForTimeout(60); ok(/عرض سعر جديد/.test(await main()),'quotes screen opens from More');
 await p.click('[data-act="quote_new"]'); await p.waitForSelector('#f');
 await p.selectOption('#f_customer',ids.b); await p.fill('.itrow [data-k=qty]','30'); await p.fill('.itrow [data-k=price]','250');
 ok(/7[ ,. ]*500/.test((await p.locator('#calc').innerText()).replace(/\s/g,' ')),'quote form shows live total (30 x 250 = 7,500)');
 await p.click('#f button[type=submit]'); await p.waitForTimeout(120);
 ok(await p.evaluate(()=>window.KPU.route)==='quote','saving a quote opens it'); const qt=await main(); ok(/DV-\d{4}-000001/.test(qt) && qt.includes('Fresh Buyer') && /7[ ,. ]*500/.test(qt),'quote paper: DV number, customer, total');
 ok(!(await p.locator('#main .paper').innerHTML()).includes('FV-'),'quote is not numbered as an invoice');
 d=await D(); ok(d.quotes.length===1 && d.sales.length===2,'quote creates NO sale/stock movement'); const stock0=d.products[0].stock;
 await p.click('[data-act="share_quote"]'); await p.click('[data-act="print_quote"]'); await p.waitForTimeout(250);
 ok((await p.evaluate(()=>window.__shared)).some(x=>x.includes('DV-')) && (await p.evaluate(()=>window.__printed))===1,'quote can be shared and printed');
 await p.click('[data-act="quote_edit"]'); await p.waitForSelector('#f'); await p.fill('.itrow [data-k=qty]','40'); await p.click('#f button[type=submit]'); await p.waitForTimeout(100);
 d=await D(); ok(d.quotes[0].total===10000*100 && d.quotes[0].items[0].qty===40,'quote edit works (40 x 250 = 10,000)');
 await p.click('[data-act="quote_convert"]'); await p.waitForSelector('#f'); await p.fill('#f_paid','4000'); await p.click('#f button[type=submit]'); await p.waitForTimeout(150);
 d=await D(); ok(await p.evaluate(()=>window.KPU.route)==='invoice' && d.sales.length===3 && d.quotes[0].status==='converted' && d.quotes[0].saleId,'convert -> real invoice opened, quote marked converted');
 ok(d.products[0].stock===stock0-40,'conversion deducted the stock ('+stock0+' -> '+d.products[0].stock+')');
 await go('quote',d.quotes[0].id); ok(!(await p.locator('[data-act="quote_edit"]').count()) && (await p.locator('[data-act="goto"][data-id="invoice"]').count())===1,'converted quote cannot be edited, links to its invoice');
 await go('quotes'); await p.click('[data-act="quote_new"]'); await p.waitForSelector('#f'); await p.fill('.itrow [data-k=qty]','5'); await p.fill('.itrow [data-k=price]','100'); await p.click('#f button[type=submit]'); await p.waitForTimeout(100);
 await p.click('[data-act="quote_void"]'); await p.waitForSelector('#f'); await p.click('#f button[type=submit]'); await p.waitForTimeout(100);
 d=await D(); ok(d.quotes.filter(q=>q.voided).length===1 && (await p.evaluate(()=>window.KPU.route))==='quotes','quote can be cancelled (kept, never deleted)');
 ok(!(await overflow()),'quotes: no horizontal overflow');
 // ---- statement
 await go('party',{kind:'customer',id:ids.a}); await p.click('[data-act="go_statement"]'); await p.waitForTimeout(80);
 let st=await main(); ok(st.includes('Old Debtor') && /10[ ,. ]*000/.test(st),'statement screen shows the customer and the closing balance (10,000 = 50x200 - 1,000)'); 
 await p.click('[data-act="st_p"][data-id="30"]'); await p.waitForTimeout(60); st=await main(); ok(/(10[ ,. ]*000)/.test(st) && (await p.locator('.rpt-tb tbody tr').count())===1,'30-day view: opening balance carries the old invoice, 1 line (payment)');
 await p.click('[data-act="st_p"][data-id="all"]'); await p.waitForTimeout(60); ok((await p.locator('.rpt-tb tbody tr').count())===2,'all-time view: 2 lines (invoice + payment)');
 await p.click('[data-act="st_csv"]'); await p.click('[data-act="st_share"]'); await p.click('[data-act="st_print"]'); await p.waitForTimeout(250);
 const files=await p.evaluate(()=>window.__files); ok(files.length===1 && files[0].c.includes('Old Debtor')===false && files[0].c.split('\r\n').length>=4,'statement CSV exported ('+files[0].n+')');
 ok((await p.evaluate(()=>window.__shared)).some(x=>x.includes('Old Debtor')),'statement shared as text');
 const bal=await p.evaluate(id=>window.KPU.K.customerBalance(window.KPU.D,id),ids.a); ok((await p.locator('.rpt-sum').innerText()).replace(/\D/g,'').includes(String(bal/100)),'statement closing = customer balance ('+bal/100+')');
 ok(!(await overflow()),'statement: no horizontal overflow');
 // ---- collection centre
 await go('collect'); let cl=await main(); ok(cl.includes('Old Debtor') && !cl.includes('Fresh Buyer')===false,'collection centre lists debtors');
 ok(await p.locator('.cc').first().innerText().then(x=>x.includes('Old Debtor')),'oldest/biggest debt first');
 await p.click('[data-act="col_f"][data-id="over"]'); await p.waitForTimeout(60); ok((await p.locator('.cc').count())===1,'"overdue" filter keeps only >30-day debt');
 await p.click('.cc [data-act="remind"]'); await p.waitForSelector('#f textarea'); const msg=await p.inputValue('#f textarea'); ok(msg.includes('Old Debtor') && /9[ ,.\s]*000/.test(msg),'reminder message is pre-filled with name and amount');
 await p.click('#f button[type=submit]'); await p.waitForTimeout(120); ok((await p.evaluate(()=>window.__shared)).some(x=>x.includes('KHALDI PLAST') && x.includes('Old Debtor')),'reminder shared');
 ok(!(await overflow()),'collection: no horizontal overflow');
 // ---- daily close
 await go('dailyclose'); const dc=await main(); ok(/5[ ,.\s]*500/.test(dc),'daily close shows today collected 5,500');
 const c0=await p.evaluate(()=>window.KPU.K.dailyClose(window.KPU.D,window.KPU.K.today())); ok(c0.cashIn===550000 && c0.expenses===30000,'daily close numbers come from core (cash in / expenses)');
 await p.click('[data-act="dc_set"][data-id="y"]'); await p.waitForTimeout(60); ok((await p.locator('.chip.on').innerText())!=='' ,'yesterday chip works');
 await p.fill('#proDate',await p.evaluate(()=>window.KPU.K.addDays(window.KPU.K.today(),-5))); await p.dispatchEvent('#proDate','change'); await p.waitForTimeout(80); ok(/1[ ,. ]*000/.test(await main()),'date picker: 5 days ago shows the 1,000 payment');
 await p.click('[data-act="dc_share"]'); await p.click('[data-act="dc_print"]'); await p.waitForTimeout(250); ok((await p.evaluate(()=>window.__shared)).some(x=>x.includes('KHALDI PLAST')),'daily close shared');
 ok(!(await overflow()),'daily close: no horizontal overflow');
 // ---- cash book
 await go('cashbook'); const cbk=await main(); ok(/Diesel/.test(cbk) && cbk.length>50,'cash book lists the cash expense');
 const cb=await p.evaluate(()=>{const K=window.KPU.K,r=K.monthRange(window.KPU.S.ym);return K.cashBook(window.KPU.D,r.from,r.to);}); ok(cb.closing===cb.opening+cb.totalIn-cb.totalOut,'cash book balances (opening + in - out = closing)');
 await p.click('[data-act="cb_csv"]'); await p.waitForTimeout(100); ok((await p.evaluate(()=>window.__files)).length===2,'cash book CSV exported');
 ok(!(await overflow()),'cash book: no horizontal overflow');
 // ---- forecast
 await go('forecast'); const fc=await main(); ok(fc.length>30 && await p.locator('.fcc').count()>=1,'forecast lists materials');
 const f0=await p.evaluate(()=>window.KPU.K.materialForecast(window.KPU.D,window.KPU.K.today())); ok(f0.some(x=>x.used>0),'forecast uses real consumption ('+f0.filter(x=>x.used>0).length+' materials with usage)');
 if(f0.some(x=>x.suggested>0)){ await p.click('[data-act="fc_share"]'); await p.waitForTimeout(100); ok((await p.evaluate(()=>window.__shared)).some(x=>x.includes('-')),'purchase list shared'); } else ok(true,'(no purchase needed in this data)');
 ok(!(await overflow()),'forecast: no horizontal overflow');
 // ---- stocktake
 await go('stocktake'); const inp=p.locator('input[data-cnt]').first(); const id0=await inp.getAttribute('data-cnt'); const sys=Number(await inp.getAttribute('data-sys'));
 await inp.fill(String(sys+5)); await p.waitForTimeout(40); ok((await p.locator('.stk-d').first().innerText()).includes('+5'),'live difference shown (+5)');
 await p.click('[data-act="stk_apply"]'); await p.waitForSelector('#f'); await p.click('#f button[type=submit]'); await p.waitForTimeout(120);
 d=await D(); const mm=d.materials.find(m=>m.id===id0); ok(mm.stock===sys+5,'stocktake adjusted the stock ('+sys+' -> '+mm.stock+')'); ok(d.movements.some(m=>/STOCKTAKE|جرد/.test(m.note||'')||m.kind==='adjust'||m.type==='adjust')||d.movements.length>0,'adjustment recorded as a movement');
 ok(!(await overflow()),'stocktake: no horizontal overflow');
 // ---- maintenance
 await go('maintenance'); ok(/M-1/.test(await main()) && /لا|بلا|Jamais|No/.test(await main()),'machine without records shows "no record"');
 await p.click('[data-act="mnt_add"]'); await p.waitForSelector('#f'); await p.fill('#f_note','oil'); await p.fill('#f_next',await p.evaluate(()=>window.KPU.K.addDays(window.KPU.K.today(),3))); await p.click('#f button[type=submit]'); await p.waitForTimeout(100);
 let ms=await p.evaluate(()=>window.KPU.K.maintenanceStatus(window.KPU.D,window.KPU.K.today())); ok(ms[0].status==='soon','next due in 3 days -> "soon"');
 ok(/oil/.test(await main()),'history lists the record');
 await p.evaluate(()=>{const U=window.KPU;U.commit(d=>{d.maintenance[0].nextDue=U.K.addDays(U.K.today(),-1);d.maintenance[0].date=U.K.addDays(U.K.today(),-10);});U.render();}); ok((await p.evaluate(()=>window.KPU.K.maintenanceStatus(window.KPU.D,window.KPU.K.today())))[0].status==='overdue','past due date -> overdue');
 ok(!(await overflow()),'maintenance: no horizontal overflow');
 // ---- insights
 await go('insights'); const ins=await main(); ok(await p.locator('#main .row').count()>=2,'insights lists observations ('+(await p.locator('#main .row').count())+')'); ok(/متأخر|صيانة|الاحتياطية|عميل/.test(ins),'insight texts are real sentences (not keys)'); ok(!/ins_[a-z_]+/.test(ins),'no untranslated keys');
 await p.click('#main .row.tap'); await p.waitForTimeout(80); ok(await p.evaluate(()=>window.KPU.route)!=='insights','tapping an insight opens its screen');
 await go('home'); await p.click('[data-act="wd_edit"]'); await p.click('[data-act="wd_add"]'); await p.click('.addlist [data-k="insightsw"]'); await p.click('[data-act="wd_add"]'); await p.click('.addlist [data-k="ageing"]'); await p.click('[data-act="wd_done"]'); await p.waitForTimeout(100);
 ok((await p.locator('.wd[data-k="insightsw"]').count())===1 && (await p.locator('.wd[data-k="ageing"]').count())===1,'insights + collection widgets can be added to the home'); ok((await p.locator('.wd[data-k="ageing"]').innerText()).includes('0') ,'collection widget shows a value');
 // ---- PIN
 await go('settings'); ok(/قفل التطبيق/.test(await main()),'settings has the PIN card'); await p.click('[data-act="pin_set"]'); await p.waitForSelector('#f');
 await p.fill('#f_p1','12'); await p.fill('#f_p2','12'); await p.click('#f button[type=submit]'); ok(/4 إلى 6|4 to 6|4 à 6/.test(await p.locator('#ferr').innerText()),'too-short PIN rejected');
 await p.fill('#f_p1','1234'); await p.fill('#f_p2','1235'); await p.click('#f button[type=submit]'); ok((await p.locator('#ferr').innerText()).length>3,'mismatching PINs rejected');
 await p.fill('#f_p2','1234'); await p.click('#f button[type=submit]'); await p.waitForTimeout(150);
 const code=(await p.locator('.pin-code .code').innerText()).replace(/\D/g,''); ok(code.length===10,'one-time recovery code shown (10 digits)');
 d=await D(); ok(!!d.settings.pin && JSON.stringify(d.settings).indexOf('1234')<0 && JSON.stringify(d.settings).indexOf(code)<0,'PIN and recovery code are stored hashed, never in clear');
 await p.click('.pin-code [data-act="close"]'); await p.click('[data-act="pin_lock_now"]'); await p.waitForTimeout(100);
 ok(await p.locator('#lock:not(.hidden)').count()===1 && await p.evaluate(()=>window.KPU.pinLocked===true),'lock screen covers the app');
 ok(await p.evaluate(()=>window.KPBack())===true && await p.locator('#lock:not(.hidden)').count()===1,'Android back button cannot dismiss the lock');
 for(const n of '9999') await p.click('#lock [data-n="'+n+'"]'); await p.waitForTimeout(60); ok(await p.locator('#lock:not(.hidden)').count()===1 && /غير صحيح|Wrong|incorrect/i.test(await p.locator('#lkErr').innerText()),'wrong PIN stays locked with a message');
 for(const n of '1234') await p.click('#lock [data-n="'+n+'"]'); await p.waitForTimeout(60); ok(await p.locator('#lock:not(.hidden)').count()===0 && !(await p.evaluate(()=>window.KPU.pinLocked)),'correct PIN unlocks');
 for(let i=0;i<5;i++){ await p.click('[data-act="pin_lock_now"]'); await p.waitForTimeout(40); break; }
 for(let i=0;i<5;i++){ for(const n of '0000') await p.click('#lock [data-n="'+n+'"]'); await p.waitForTimeout(30); }
 ok(await p.locator('#lock [data-n]:disabled').count()===10,'5 wrong tries -> keypad disabled for a while');
 await p.evaluate(()=>{}); await p.click('#lock [data-lk="rec"]'); await p.fill('#lkRec','0000000000'); await p.click('#lock [data-lk="rec_ok"]'); ok(/غير صحيح|Wrong|incorrect/i.test(await p.locator('#lkErr').innerText()),'wrong recovery code rejected');
 await p.fill('#lkRec',code); await p.click('#lock [data-lk="rec_ok"]'); await p.waitForTimeout(100); d=await D(); ok(d.settings.pin===null && await p.locator('#lock:not(.hidden)').count()===0,'recovery code removes the lock and opens the app');
 // set again, change, remove through the UI
 await go('settings'); await p.click('[data-act="pin_set"]'); await p.waitForSelector('#f'); await p.fill('#f_p1','5555'); await p.fill('#f_p2','5555'); await p.click('#f button[type=submit]'); await p.waitForTimeout(100); await p.click('.pin-code [data-act="close"]');
 await p.click('[data-act="pin_change"]'); await p.waitForSelector('#f'); await p.fill('#f_cur','0000'); await p.fill('#f_p1','7777'); await p.fill('#f_p2','7777'); await p.click('#f button[type=submit]'); ok((await p.locator('#ferr').innerText()).length>3,'changing needs the current PIN');
 await p.fill('#f_cur','5555'); await p.click('#f button[type=submit]'); await p.waitForTimeout(100); await p.click('.pin-code [data-act="close"]');
 await p.click('[data-act="pin_remove"]'); await p.waitForSelector('#f'); await p.fill('#f_cur','7777'); await p.click('#f button[type=submit]'); await p.waitForTimeout(100); d=await D(); ok(d.settings.pin===null,'PIN changed then removed with the right current PIN');
 // ---- backup round trip keeps the new data
 const bk=await p.evaluate(()=>{const K=window.KPU.K; const b=K.makeBackup(window.KPU.D); const v=K.validateBackup(JSON.parse(JSON.stringify(b))); return {ok:!!v&&!v.error, q:(v.data||v).quotes? (v.data||v).quotes.length:-1, m:((v.data||v).maintenance||[]).length}; });
 ok(bk.ok && bk.q===2 && bk.m===1,'backup/restore keeps quotes and maintenance ('+JSON.stringify(bk)+')');
 // ---- dark mode + all languages render the new screens
 for(const lang of ['fr','en','ar']){ await p.evaluate(l=>{window.KPU.commit(d=>{d.settings.lang=l;d.settings.theme=l==='en'?'dark':'light';});},lang);
   for(const r of ['quotes','collect','dailyclose','cashbook','forecast','stocktake','maintenance','insights','statement']){ await go(r,r==='statement'?ids.a:null); const tx=await main(); if(/\b(p_|ins_|mnt_|stk_|fc_|col_|pin_|qs_|tile_|sub_)[a-z_0-9]+\b/.test(tx)) ok(false,lang+' '+r+' shows a raw key: '+tx.match(/\b(p_|ins_|mnt_|stk_|fc_|col_|pin_|qs_|tile_|sub_)[a-z_0-9]+\b/)[0]); }
 } ok(true,'3 languages x 9 screens render without raw keys');
 await p.evaluate(()=>{window.KPU.commit(d=>{d.settings.lang='ar';d.settings.theme='light';});window.KPU.render();});
 console.log('errors:',s.errors.length?s.errors:'none'); console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail||s.errors.length?1:0); })();
