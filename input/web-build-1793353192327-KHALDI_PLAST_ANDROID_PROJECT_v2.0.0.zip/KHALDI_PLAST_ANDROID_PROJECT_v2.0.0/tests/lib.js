const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const mime={js:'text/javascript',css:'text/css',html:'text/html',png:'image/png',jpg:'image/jpeg'};
exports.start = async function(root, vw){
  const srv = http.createServer((req, res) => { const u=req.url.split('?')[0]; const f = path.join(root, u === '/' ? 'index.html' : u);
    fs.readFile(f, (e, b) => { if (e) { res.writeHead(404); res.end(); } else { res.writeHead(200, { 'Content-Type': mime[f.split('.').pop()]||'application/octet-stream' }); res.end(b); } }); }).listen(0);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: vw||390, height: 800 } });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE ' + m.text()); });
  await page.goto('http://localhost:' + srv.address().port + '/');
  return { page, browser, srv, errors, close: async()=>{ await browser.close(); srv.close(); } };
};

// Old (v1.1) home arrangement: shortcut widgets + KPI/alerts/chart/products/recent sections, none of the v1.2 sections.
exports.legacyHome = async function(p){ await p.evaluate(()=>{ const U=window.KPU, DEF=['sales','invoices','production','prodtable','stock','purchases','expenses','debts','customers','suppliers','workers','assistant'], CAT=['production','purchases','sales','expenses','debts','stock','invoices','reports','workers','customers','suppliers','notes','prodtable','assistant','transactions','shifts','payroll','profit','scan','backup','settings','customize','quotes','collect','dailyclose','cashbook','forecast','stocktake','maintenance','insights'];
  U.commit(d=>{ d.settings.layout={v:1,hv:2,hidden:CAT.filter(c=>DEF.indexOf(c)<0),order:[],icons:{},secOrder:[],secHidden:['today','quick','perf','lines'],wOrder:[],sizes:{}}; }); U.render(); }); };
