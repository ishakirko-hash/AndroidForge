// v1.3: widget library (13 new real-data widgets), gallery, live drag reorder (handle + long-press), resize, persistence.
const L=require('./lib.js'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 await p.setViewportSize({width:390,height:844}); await p.addStyleTag({content:'.wd{animation:none!important}'});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const home=async()=>{ await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.arg=null;window.KPU.render();}); await p.waitForTimeout(80); };
 const keys=()=>p.evaluate(()=>[].map.call(document.querySelectorAll('.wgrid .wd'),e=>e.dataset.k));
 const txt=k=>p.locator('.wd[data-k="'+k+'"]').innerText();
 // data
 await p.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(); U.commit(d=>{ const c=K.addCustomer(d,{name:'Debtor One',phone:'0550'}), c2=K.addCustomer(d,{name:'Debtor Two',phone:'0551'}); const pr=d.products[0];
   K.recordProduction(d,{date:td,shift:1,productId:pr.id,good:100,defective:0});
   K.recordSale(d,{date:td,customerId:c.id,items:[{productId:pr.id,qty:30,unitPrice:30000,weightG:0}],paid:100000,method:'cash'});
   K.recordSale(d,{date:td,customerId:c2.id,items:[{productId:pr.id,qty:10,unitPrice:30000,weightG:0}],paid:0,method:'cash'});
   d.materials[0].minStock=999999; const sp=K.addSupplier(d,{name:'Sup'}); K.recordPurchase(d,{date:td,supplierId:sp.id,materialId:d.materials[1].id,qty:100,unitCost:10000,paid:0,method:'cash'});
   K.addNote(d,{date:td,customerName:'Late Buyer',phone:'0555',productId:pr.id,qty:7,expectedDate:K.addDays(td,-2),status:'pending',text:''});
   const w=K.addWorker(d,{name:'W1',role:'op',rate:100,hireDate:'2025-01-01'}); K.addWorker(d,{name:'W2',role:'op',rate:100,hireDate:'2025-01-01'});
   const h=new Date().getHours(), cs=h>=8&&h<16?1:h>=16?2:3; K.setShiftRoster(d,{date:td,shift:cs,entries:[{workerId:w.id,worked:true}]}); }); U.render(); });
 await home();
 const base=await keys(); ok(base.join()==='today,quick,perf,lines','extras are NOT forced onto the existing home');
 // gallery
 await p.click('[data-act="wd_edit"]'); await p.click('[data-act="wd_add"]');
 const smart=await p.locator('.addlist [data-k]').evaluateAll(a=>a.map(x=>x.dataset.k).filter(k=>k.indexOf('sc:')!==0));
 ok(smart.length>=17,'gallery offers all smart widgets ('+smart.length+')'); ok((await p.locator('.gal-h').count())===2,'gallery has smart + shortcuts groups');
 await p.click('[data-act="close"]');
 const EXTRA=['qadd','debts','collected','expenses','profit','orders','lowstock','rawstock','workers','shiftnow','topdebt','topprod','backup'];
 for(const k of EXTRA){ await p.click('[data-act="wd_add"]'); await p.click('.addlist [data-k="'+k+'"]'); await p.waitForTimeout(40); }
 const now=await keys(); ok(EXTRA.every(k=>now.includes(k)),'all 13 new widgets can be added: '+now.length+' widgets');
 const d=await D(); ok(d.settings.layout.hv===2 && EXTRA.every(k=>d.settings.layout.shown.includes(k)),'added widgets recorded in layout.shown');
 await p.click('[data-act="wd_done"]'); await p.waitForTimeout(100);
 // values
 const t=async k=>(await txt(k)).replace(/\s+/g,' ');
 const cd=await t('debts'); ok(/2,?000|3,?000|2000/.test(cd.replace(/,/g,'')) || cd.includes('ديون'),'debts widget: '+cd.slice(0,80));
 const debtVal=await p.evaluate(()=>window.KPU.K.dashboard(window.KPU.D,window.KPU.K.today()).customerDebt); const shown=(await t('debts')).replace(/[^\d]/g,'');
 ok(shown.includes(String(Math.round(debtVal/100))),'customer debt widget shows the real total ('+Math.round(debtVal/100)+')');
 ok((await t('lowstock')).includes('1'),'low-stock widget counts the item below its minimum: '+(await t('lowstock')).slice(0,40));
 ok((await t('orders')).includes('Late Buyer') && (await t('orders')).includes('متأخر'),'orders widget lists the overdue order');
 ok((await t('topdebt')).includes('Debtor'),'top debts lists the debtors');
 ok((await t('topprod')).replace(/\s/g,'').length>10 && /40/.test(await t('topprod')),'best sellers uses real quantities (30+10=40)');
 ok((await t('workers')).includes('1') && (await t('workers')).includes('2'),'workers today: 1 of 2: '+(await t('workers')).replace(/\n/g,' '));
 ok(/(08:00|16:00|00:00)/.test(await t('shiftnow')),'current shift widget shows the real shift time');
 ok((await t('backup')).includes('لم تؤخذ'),'backup widget says no backup was taken (honest)');
 ok((await p.locator('.wd[data-k="qadd"] .qab').count())===4,'quick-add widget has 4 actions'); await p.click('.wd[data-k="qadd"] .qab[data-act="new_sale"]'); ok((await p.locator('#f').count())===1,'quick-add opens the invoice form'); await p.click('[data-act="close"]').catch(()=>{}); await home();
 await p.click('.wd[data-k="lowstock"]'); ok(await p.evaluate(()=>window.KPU.route)==='stock','tapping low-stock opens Stock'); await home();
 // live drag with handle
 await p.setViewportSize({width:390,height:2900}); await home(); await p.click('[data-act="wd_edit"]'); await p.waitForTimeout(450);
 let ks=await keys(); const from=ks[ks.length-1], to=ks[2];
 const hb=await p.locator('.wd[data-k="'+from+'"] .wd-drag').boundingBox(); const tb=await p.locator('.wd[data-k="'+to+'"]').boundingBox();
 await p.mouse.move(hb.x+hb.width/2,hb.y+hb.height/2); await p.mouse.down();
 for(let i=1;i<=12;i++){ await p.mouse.move(hb.x+(tb.x+tb.width/2-hb.x)*i/12, hb.y+(tb.y+tb.height/2-hb.y)*i/12); await p.waitForTimeout(110); }
 ok((await p.locator('.wd.dragging').count())===1 && (await p.locator('.wgrid.is-dragging').count())===1,'dragging state is shown');
 ks=await keys(); ok(ks.indexOf(from)<=3,'others make room LIVE while dragging ('+from+' now at '+ks.indexOf(from)+')');
 const moving=await p.evaluate(()=>[].filter.call(document.querySelectorAll('.wgrid .wd:not(.dragging)'),e=>e.style.transition.indexOf('transform')>=0).length); ok(moving>0,'neighbours glide with a transition ('+moving+')');
 await p.mouse.up(); await p.waitForTimeout(400);
 let d2=(await D()); ok(d2.settings.layout.wOrder.indexOf(from)<=3,'new order saved'); ok((await p.locator('.wd.dragging').count())===0,'drag ends cleanly');
 const stuck=await p.evaluate(()=>[].filter.call(document.querySelectorAll('.wgrid .wd'),e=>e.style.transform&&e.style.transform!=='none'&&e.style.transform!=='').length); ok(stuck===0,'no widget left transformed after the drop ('+stuck+')');
 // long-press drag on the body
 ks=await keys(); const f2=ks[5], t2=ks[1]; const b2=await p.locator('.wd[data-k="'+f2+'"]').boundingBox(), c2=await p.locator('.wd[data-k="'+t2+'"]').boundingBox();
 await p.mouse.move(b2.x+b2.width/2,b2.y+b2.height/2); await p.mouse.down(); await p.waitForTimeout(330); ok((await p.locator('.wd.dragging').count())===1,'press-and-hold picks a widget up');
 await p.mouse.move(c2.x+c2.width/2,c2.y+c2.height/2,{steps:10}); await p.mouse.up(); await p.waitForTimeout(400); ks=await keys(); ok(ks.indexOf(f2)<=2,'long-press drag reorders ('+ks.indexOf(f2)+')');
 // quick tap/scroll-like movement does not pick up
 const b3=await p.locator('.wd[data-k="'+ks[4]+'"]').boundingBox(); await p.mouse.move(b3.x+b3.width/2,b3.y+b3.height/2); await p.mouse.down(); await p.mouse.move(b3.x+b3.width/2,b3.y+b3.height/2+60,{steps:4}); await p.waitForTimeout(330); ok((await p.locator('.wd.dragging').count())===0,'moving before the hold time does not start a drag (page can scroll)'); await p.mouse.up();
 // resize with live glide
 const rk=ks[3]; const sz0=await p.evaluate(k=>document.querySelector('.wd[data-k="'+k+'"]').className.match(/sz-\w/)[0],rk);
 const rb=await p.locator('.wd[data-k="'+rk+'"] .wd-rs').boundingBox(); await p.mouse.move(rb.x+rb.width/2,rb.y+rb.height/2); await p.mouse.down(); await p.mouse.move(rb.x+rb.width/2-90,rb.y+rb.height/2+90,{steps:8}); await p.mouse.up(); await p.waitForTimeout(400);
 const sz1=await p.evaluate(k=>document.querySelector('.wd[data-k="'+k+'"]').className.match(/sz-\w/)[0],rk); ok(sz0!==sz1,'corner handle resizes ('+sz0+' → '+sz1+')');
 await p.click('[data-act="wd_done"]');
 // persistence
 await p.reload(); await p.waitForSelector('#splash.hidden',{state:'attached'}); await p.waitForTimeout(100); const after=await keys(); ok(EXTRA.every(k=>after.includes(k)) && after.join()===(await keys()).join(),'layout (order, sizes, added widgets) survives restart');
 // hide an extra
 await p.click('[data-act="wd_edit"]'); await p.click('.wd[data-k="backup"] [data-act="wd_hide"]'); const d3=await D(); ok(!d3.settings.layout.shown.includes("backup") && !(await keys()).includes('backup'),'hiding removes it from shown');
 await p.screenshot({path:SH+'/widgets_edit.png',fullPage:false}); await p.click('[data-act="wd_done"]');
 await p.setViewportSize({width:390,height:2900}); await p.screenshot({path:SH+'/widgets_all.png'});
 for(const w of [360,412]){ await p.setViewportSize({width:w,height:844}); await home(); const ov=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,m:document.getElementById('main').scrollWidth,mc:document.getElementById('main').clientWidth})); ok(ov.sw<=ov.cw+1&&ov.m<=ov.mc+1,'no overflow with all widgets at '+w); }
 console.log('errors:',s.errors.length?s.errors:'none'); console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail||s.errors.length?1:0); })();
