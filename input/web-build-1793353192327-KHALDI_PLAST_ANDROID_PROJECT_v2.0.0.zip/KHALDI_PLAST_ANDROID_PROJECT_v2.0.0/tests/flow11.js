// v1.2 home (reference design): hero, today cards, quick access, trend + target, production lines, search, flat nav.
const L=require('./lib.js'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 await p.setViewportSize({width:390,height:844}); await p.addStyleTag({content:'.wd{animation:none!important}'});
 const route=()=>p.evaluate(()=>window.KPU.route), D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const home=async()=>{ await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.arg=null;window.KPU.render();}); await p.waitForTimeout(80); };
 const keys=()=>p.evaluate(()=>[].map.call(document.querySelectorAll('.wgrid .wd'),e=>e.dataset.k));
 await home();
 // --- structure on empty data (nothing invented)
 ok((await keys()).join()==='today,quick,perf,lines','default home = today, quick, perf, lines: '+(await keys()));
 ok((await p.locator('.hhero .hlogo').count())===1 && (await p.locator('.hhero .hwel').innerText()).includes('مرحباً') && (await p.locator('.hhero .hsub').innerText()).includes('خالدي بلاست'),'hero: logo, welcome, subtitle');
 ok((await p.evaluate(()=>getComputedStyle(document.getElementById('hdr')).display))==='none','old header hidden on Home');
 ok((await p.locator('.hsearch input').count())===1 && (await p.locator('.hsearch [data-act="scan_qr"]').count())===1 && (await p.locator('.hbell').count())===1 && (await p.locator('.havatar').count())===1,'search bar with scan button, bell, avatar');
 ok((await p.locator('.tdl').count())===0,'no yesterday comparison is invented when there is no yesterday data');
 ok((await p.locator('.rc').innerText()).trim()==='—' && (await p.locator('[data-act="set_target"]').count())===1,'no target set: ring shows — and a set-target button');
 ok((await p.locator('.ln').count())===0 && (await p.locator('.lnsec').innerText()).includes('آلات'),'no machines: honest empty state, no fake lines');
 const nav=await p.evaluate(()=>[].map.call(document.querySelectorAll('#nav .nb'),b=>b.dataset.id)); ok(nav.join()==='home,sales,production,stock,more','bottom nav order (RTL: right to left) '+nav);
 ok((await p.evaluate(()=>{const n=document.getElementById('nav').getBoundingClientRect(); return n.left===0 && Math.round(n.right)===window.innerWidth && Math.round(n.bottom)===window.innerHeight;})),'bottom navigation is flat and full width');
 // --- seed real data
 const ids=await p.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(),r={};
  U.commit(d=>{ const c=K.addCustomer(d,{name:'Zed Market',phone:'0550123456'}); r.c=c.id; const pr=d.products[0]; r.p=pr.name;
   K.recordProduction(d,{date:K.addDays(td,-1),shift:1,productId:pr.id,good:100,defective:0}); K.recordProduction(d,{date:td,shift:1,productId:pr.id,good:150,defective:0});
   const y=K.recordSale(d,{date:K.addDays(td,-1),customerId:c.id,items:[{productId:pr.id,qty:20,unitPrice:30000,weightG:0}],paid:0,method:'cash'});
   const t1=K.recordSale(d,{date:td,customerId:c.id,items:[{productId:pr.id,qty:30,unitPrice:30000,weightG:0}],paid:0,method:'cash'}); r.no=t1.no;
   K.addNote(d,{date:td,customerName:'Order Guy',phone:'0555',productId:pr.id,qty:10,expectedDate:K.addDays(td,2),status:'pending',text:''}); });
  U.render(); return r; });
 await p.waitForTimeout(80);
 const cards=await p.locator('.tk').evaluateAll(a=>a.map(e=>({v:e.querySelector('.tkv').innerText.trim(),d:(e.querySelector('.tdl b')||{}).innerText||'',cls:(e.querySelector('.tdl')||{className:''}).className})));
 ok(cards.length===3 && /9,?000/.test(cards[0].v.replace(/\s/g,'')) ,'sales today = real total (900 DZD x30 → 9,000 DZD): '+JSON.stringify(cards[0]));
 ok(cards[1].v==='150' && /50%/.test(cards[1].d) && /up/.test(cards[1].cls),'production today 150 vs 100 yesterday = +50%: '+JSON.stringify(cards[1]));
 ok(cards[2].v==='1' && /\+0/.test(cards[2].d.replace(/\s/g,'')),'orders (invoices) today 1 vs 1 yesterday: '+JSON.stringify(cards[2]));
 await p.click('.tk-prod'); ok(await route()==='production','production-today card opens Production'); await home();
 await p.click('.tk-sales'); ok(await route()==='sales' && (await p.evaluate(()=>window.KPU.S.salesP))==='today','sales-today card opens Sales on "today"'); await home();
 // --- quick access
 const q=await p.locator('.qt').evaluateAll(a=>a.map(b=>b.dataset.id)); ok(q.join()==='materials,stock,production,sales,more,reports,workers,orders','8 quick tiles in reference order: '+q);
 await p.click('.qt[data-id="materials"]'); ok(await route()==='stock' && (await p.evaluate(()=>window.KPU.S.stockTab))==='raw','Raw materials opens Stock on the materials tab'); await home();
 await p.click('.qt[data-id="orders"]'); ok(await route()==='notes' && (await p.evaluate(()=>window.KPU.S.noteF))==='pending','Upcoming orders opens pending orders'); await home();
 await p.click('.qt[data-id="workers"]'); ok(await route()==='workers' && (await p.evaluate(()=>window.KPU.S.workTab))==='today','Workers & shifts opens today shifts'); await home();
 await p.click('.qt[data-id="more"]'); ok(await route()==='more','More tile opens More'); await home();
 await p.click('.qt[data-id="reports"]'); ok(await route()==='reports','Reports tile opens Reports'); await home();
 // --- target
 await p.click('[data-act="set_target"]'); await p.fill('#tgtin','1000'); await p.click('[data-act="save_target"]'); await p.waitForTimeout(80);
 let d=await D(); ok(d.settings.monthlyTarget===1000,'target saved in settings (additive key)');
 const pc=(await p.locator('.rc').innerText()).replace(/\s/g,''); ok(pc==='25%','target 1000, month production 250 => 25% : '+pc);
 ok((await p.locator('.rleg').innerText()).includes('250') && (await p.locator('.rleg').innerText()).includes('1,000'),'legend shows real production and the target');
 await p.click('[data-act="set_target"]'); await p.fill('#tgtin','-5'); await p.click('[data-act="save_target"]'); d=await D(); ok(d.settings.monthlyTarget===undefined,'invalid target clears it (no NaN stored)');
 await p.click('[data-act="set_target"]'); await p.fill('#tgtin','1000'); await p.click('[data-act="save_target"]');
 // --- lines from the real roster
 const cs=await p.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(),h=new Date().getHours(),cs=h>=8&&h<16?1:h>=16?2:3,o=cs%3+1;
   U.commit(d=>{ const m=K.addMachine(d,{name:'Line A'}); K.addMachine(d,{name:'Line B'}); const w=K.addWorker(d,{name:'W1',role:'op',rate:100,hireDate:'2025-01-01'}),w2=K.addWorker(d,{name:'W2',role:'op',rate:100,hireDate:'2025-01-01'});
     K.setShiftRoster(d,{date:td,shift:cs,entries:[{workerId:w.id,worked:true,machineId:m.id}]}); K.setShiftRoster(d,{date:td,shift:o,entries:[{workerId:w2.id,worked:true,machineId:m.id}]}); }); U.render(); return cs; });
 await p.waitForTimeout(80);
 const lines=await p.locator('.ln').evaluateAll(a=>a.map(e=>({n:e.querySelector('.lnm b').innerText,st:e.querySelector('.lns').className,c:e.querySelector('.lnc b').innerText.replace(/\s/g,'')})));
 ok(lines.length===2 && lines[0].n==='Line A' && /ok/.test(lines[0].st) && lines[0].c==='2/3','Line A running now, 2 of 3 shifts covered (from the real roster): '+JSON.stringify(lines));
 ok(/wait/.test(lines[1].st) && lines[1].c==='0/3','Line B has nobody assigned: shown as waiting, 0/3 (no invented progress)');
 // --- search
 await p.fill('#homeq','Zed'); await p.waitForTimeout(100);
 ok((await p.locator('.sr .sr-row').count())>=2 && (await p.inputValue('#homeq'))==='Zed','typing searches customers and invoices and keeps focus/text');
 await p.fill('#homeq',String(ids.no)); await p.waitForTimeout(100); await p.click('.sr .sr-row[data-act="tx"]'); ok(await route()==='tx','tapping an invoice result opens it');
 await home(); await p.fill('#homeq','Order Guy'); await p.waitForTimeout(100); ok((await p.locator('.sr .sr-h').allInnerTexts()).join().includes('طلبات'),'orders are searchable');
 await p.fill('#homeq','zzzzqq'); await p.waitForTimeout(100); ok((await p.locator('.sr').innerText()).includes('لا'),'no match shows an empty message'); await p.fill('#homeq',''); await p.waitForTimeout(80);
 // --- edit mode keeps working with the new widgets
 await p.click('[data-act="wd_edit"]'); ok((await p.locator('.wgrid.editing .wd-ed').count())===4,'edit mode shows controls on the 4 new widgets');
 await p.click('.wd[data-k="lines"] [data-act="wd_hide"]'); d=await D(); ok(d.settings.layout.hv===2 && d.settings.layout.secHidden.includes('lines') && !d.settings.layout.secHidden.includes('quick'),'hide saved; the old sections stay hidden: '+JSON.stringify(d.settings.layout.secHidden));
 ok((await keys()).join()==='today,quick,perf','lines widget hidden');
 await p.click('[data-act="wd_add"]'); ok((await p.locator('.addlist .cz-row').count())>=5,'add-widget list offers lines + the old sections'); await p.click('.addlist [data-k="lines"]'); ok((await keys()).includes('lines'),'lines widget restored');
 await p.click('[data-act="wd_done"]');
 // old sections are still available as widgets
 await p.click('[data-act="wd_edit"]'); await p.click('[data-act="wd_add"]'); await p.click('.addlist [data-k="kpis"]'); ok((await keys()).includes('kpis') && (await p.locator('.kpi').count())>=2,'old month KPI section can be added back'); await p.click('[data-act="wd_done"]');
 // --- overflow + screenshots
 for(const w of [360,390,412]){ await p.setViewportSize({width:w,height:844}); await home(); const ov=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,m:document.getElementById('main').scrollWidth,mc:document.getElementById('main').clientWidth})); ok(ov.sw<=ov.cw+1 && ov.m<=ov.mc+1,'no horizontal overflow at '+w+' '+JSON.stringify(ov)); await p.screenshot({path:SH+'/home_v12_'+w+'.png'}); }
 console.log('errors:',s.errors.length?s.errors:'none'); console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail||s.errors.length?1:0); })();
