// Run with:  node tests/test_core2.js   (v2.0 business logic)
const K = require('../app/src/main/assets/www/core2.js');
let pass = 0, fail = 0;
function ok(c, n) { if (c) pass++; else { fail++; console.log('FAIL:', n); } }
function eq(a, b, n) { if (JSON.stringify(a) === JSON.stringify(b)) pass++; else { fail++; console.log('FAIL:', n, '\n  got', JSON.stringify(a), '\n  exp', JSON.stringify(b)); } }
function throws(fn, code, n) { try { fn(); fail++; console.log('FAIL (no error):', n); } catch (e) { if (e.code === code) pass++; else { fail++; console.log('FAIL', n, 'got', e.code || e.message); } } }
const T = '2026-10-30';
let d = K.emptyData();
const P = d.products[0].id, M = d.materials[0].id;
d = K.tx(d, x => { const s = K.addSupplier(x, { name: 'S' }); K.recordPurchase(x, { date: '2026-10-01', supplierId: s.id, materialId: M, qty: 1000, unitCost: 20000, paid: 0, method: 'cash' }); });
const g = {}; g[M] = 500;     // 500 g per crate
d = K.tx(d, x => { for (let i = 0; i < 10; i++) K.recordProduction(x, { date: K.addDays('2026-10-20', i), shift: 1, productId: P, good: 100, defective: 0, grams: g }); });
// ---- customers: A has an old unpaid invoice, B a recent one, C paid
let cA, cB, cC;
d = K.tx(d, x => { cA = K.addCustomer(x, { name: 'A' }).id; cB = K.addCustomer(x, { name: 'B' }).id; cC = K.addCustomer(x, { name: 'C' }).id; });
d = K.tx(d, x => {
  K.recordSale(x, { date: '2026-07-01', customerId: cA, items: [{ productId: P, qty: 10, unitPrice: 10000, weightG: 0 }], paid: 20000, method: 'cash' });   // 100000 total, 20000 paid, 80000 due, 121 days old
  K.recordSale(x, { date: '2026-10-25', customerId: cB, items: [{ productId: P, qty: 20, unitPrice: 10000, weightG: 0 }], paid: 0, method: 'cash' });     // 200000 due, 5 days
  K.recordSale(x, { date: '2026-10-26', customerId: cC, items: [{ productId: P, qty: 5, unitPrice: 10000, weightG: 0 }], paid: 50000, method: 'bank' });   // fully paid
});
// ---- ageing
const ag = K.ageingReport(d, T);
eq(ag.rows.map(r => r.customer.name), ['A', 'B'], 'ageing: only debtors, oldest first');
eq(ag.rows[0].buckets, [0, 0, 0, 80000], 'A is entirely 90+');
eq(ag.rows[1].buckets, [200000, 0, 0, 0], 'B is current');
eq(ag.total, 280000, 'ageing total = sum of balances'); eq(ag.total, ag.totals.reduce((a, b) => a + b, 0), 'buckets add up to the total');
eq(ag.overdue, 80000, 'overdue = beyond 30 days'); ok(ag.rows[0].oldest === 121, 'age in days');
d = K.tx(d, x => K.recordCustomerPayment(x, { date: '2026-10-28', customerId: cA, amount: 30000, method: 'cash' }));
const ag2 = K.ageingReport(d, T); eq(ag2.rows[0].buckets[3], 50000, 'a payment reduces the oldest invoice'); eq(ag2.rows[0].lastPayment, '2026-10-28', 'last payment date');
eq(ag2.total, K.customerBalance(d, cA) + K.customerBalance(d, cB), 'ageing equals the real balances');
// ---- statement
const st = K.customerStatement(d, cA, '2026-07-01', '2026-10-30');
eq(st.lines.map(l => l.type), ['sale', 'payment', 'payment'], 'statement lists sale and payments in order');
eq(st.closing, K.customerBalance(d, cA), 'statement closing equals the customer balance'); eq(st.opening, 0, 'opening 0');
eq(st.lines[st.lines.length - 1].balance, st.closing, 'running balance ends at closing');
const st2 = K.customerStatement(d, cA, '2026-10-01', '2026-10-30'); eq(st2.opening, 80000, 'opening balance carried into a later period'); eq(st2.lines.length, 1, 'only payments in range'); eq(st2.closing, 50000, 'closing after payment');
throws(() => K.customerStatement(d, cA, '2026-10-30', '2026-10-01'), 'bad_range', 'range order enforced'); throws(() => K.customerStatement(d, 'x', '2026-10-01', '2026-10-30'), 'no_customer', 'unknown customer');
d = K.tx(d, x => K.voidSale(x, x.sales[0].id, 'test'));
const st3 = K.customerStatement(d, cA, '2026-01-01', '2026-10-30'); ok(!st3.lines.some(l => l.type === 'sale'), 'voided invoices never appear'); eq(st3.closing, K.customerBalance(d, cA), 'still consistent after a void');
// ---- daily close
d = K.tx(d, x => { K.recordExpense(x, { date: '2026-10-26', categoryId: 'cat_electricity', description: 'e', amount: 12000, method: 'cash' }); const s = x.suppliers[0]; K.recordSupplierPayment(x, { date: '2026-10-26', supplierId: s.id, amount: 5000, method: 'cash' }); });
const dc = K.dailyClose(d, '2026-10-26');
eq(dc.salesCount, 1, 'close: invoices'); eq(dc.salesTotal, 50000, 'close: sales'); eq(dc.collected, 50000, 'close: collected'); eq(dc.byMethod, { bank: 50000 }, 'close: by method');
eq(dc.expenses, 12000, 'close: expenses'); eq(dc.cashIn, 0, 'bank is not cash'); eq(dc.cashOut, 17000, 'cash out = expenses + supplier payments in cash'); eq(dc.cashNet, -17000, 'net cash');
eq(dc.good, 100, 'close: production that day'); eq(K.dailyClose(d, '2026-01-01').salesTotal, 0, 'empty day is zeros');
// ---- cash book
d = K.tx(d, x => K.recordCustomerPayment(x, { date: '2026-10-27', customerId: cB, amount: 10000, method: 'cash' }));
const cb = K.cashBook(d, '2026-10-01', '2026-10-30');
eq(cb.totalIn, 10000, 'cash book: only cash receipts (voided invoice payments and bank excluded)'); 
eq(cb.closing, cb.totalIn - cb.totalOut + cb.opening, 'closing identity'); ok(cb.lines.every(l => l.in >= 0 && l.out >= 0), 'no negatives');
ok(!cb.lines.some(l => l.ref === d.payments.find(p => p.method === 'bank').id), 'bank payments are excluded');
eq(cb.lines[cb.lines.length - 1].balance, cb.closing, 'running balance ends at closing');
// ---- forecast  (window 30 days: 10 days x 100 crates x 0.5 kg = 500 kg used)
const fc = K.materialForecast(d, T, 30, 30)[0];
eq(fc.used, 500, 'forecast: consumption'); eq(fc.daily, 16.667, 'forecast: daily average'); eq(fc.material.stock, 500, 'stock'); eq(fc.cover, 30, 'cover days');
eq(fc.suggested, 0, 'no purchase needed at exactly 30 days of cover'); eq(fc.status, 'ok', 'status ok');
d = K.tx(d, x => K.adjustStock(x, { date: T, kind: 'material', itemId: M, newStock: 100, note: 't' }));
const fc2 = K.materialForecast(d, T, 30, 30)[0]; eq(fc2.status, 'critical', 'under a week = critical'); eq(fc2.suggested, 400, 'suggest enough for 30 days'); eq(fc2.est, 400 * 20000, 'estimated cost from the average purchase price'); eq(fc2.runOut, K.addDays(T, 6), 'run-out date');
eq(K.materialForecast(K.emptyData(), T)[0].status, 'nodata', 'no consumption = no invented forecast');
// ---- stocktake
const beforeMoves = d.movements.length;
let ch; d = K.tx(d, x => { ch = K.applyStocktake(x, { date: T, kind: 'material', counts: { [M]: '120', [d.materials[1].id]: '' }, note: 'oct' }); });
eq(ch.length, 1, 'only changed items adjusted'); eq(d.materials[0].stock, 120, 'stock follows the count'); ok(d.movements.length === beforeMoves + 1 && d.movements[d.movements.length - 1].type === 'adjust', 'recorded as an adjust movement (stock = sum of movements)');
eq(K.tx(d, x => { ch = K.applyStocktake(x, { date: T, kind: 'material', counts: { [M]: '120' } }); }).movements.length, d.movements.length, 'same count changes nothing');
throws(() => K.tx(d, x => K.applyStocktake(x, { date: T, kind: 'material', counts: { [M]: '-3' } })), 'bad_qty', 'negative count rejected');
// ---- maintenance
let mid; d = K.tx(d, x => { mid = K.addMachine(x, { name: 'Press 1' }).id; K.addMachine(x, { name: 'Press 2' }); });
eq(K.maintenanceStatus(d, T).map(x => x.status), ['never', 'never'], 'no record = never serviced');
d = K.tx(d, x => K.addMaintenance(x, { machineId: mid, date: '2026-09-01', kind: 'preventive', note: 'oil', nextDue: '2026-10-01' }));
eq(K.maintenanceStatus(d, T)[0].status, 'overdue', 'next due in the past = overdue'); eq(K.maintenanceStatus(d, T)[0].machine.id, mid, 'overdue first');
d = K.tx(d, x => K.addMaintenance(x, { machineId: mid, date: T, kind: 'repair', note: 'belt', nextDue: '2026-11-03' }));
const ms = K.maintenanceStatus(d, T).find(x => x.machine.id === mid); eq(ms.status, 'soon', 'due within 7 days'); eq(ms.daysTo, 4, 'days to due'); eq(ms.count, 2, 'history kept');
d = K.tx(d, x => K.voidMaintenance(x, x.maintenance[1].id)); eq(K.maintenanceStatus(d, T).find(x => x.machine.id === mid).status, 'overdue', 'voiding the latest record falls back to the previous one');
throws(() => K.tx(d, x => K.addMaintenance(x, { machineId: 'nope', date: T })), 'no_item', 'unknown machine'); throws(() => K.tx(d, x => K.addMaintenance(x, { machineId: mid, date: '2026-10-10', nextDue: '2026-10-01' })), 'bad_range', 'due before service');
// ---- quotations
let q; d = K.tx(d, x => { q = K.addQuote(x, { date: T, customerId: cC, items: [{ productId: P, qty: 10, unitPrice: 12000 }], discount: 5000, validUntil: '2026-11-15', notes: 'n' }); });
eq(q.no, 1, 'quote numbering is separate from invoices'); eq(q.total, 115000, 'quote total'); eq(d.sales.length, 3, 'a quote does not create an invoice'); eq(d.products[0].stock, K.tx(d, x => 0) && d.products[0].stock, 'stock untouched');
const stockBefore = d.products[0].stock;
eq(K.quoteState(d.quotes[0], T), 'open', 'open'); eq(K.quoteState(d.quotes[0], '2026-12-01'), 'expired', 'expired after its date');
d = K.tx(d, x => K.editQuote(x, x.quotes[0].id, { date: T, customerId: cC, items: [{ productId: P, qty: 20, unitPrice: 12000 }], discount: 0, validUntil: '' })); eq(d.quotes[0].total, 240000, 'quote edited');
let sale; d = K.tx(d, x => { sale = K.convertQuote(x, x.quotes[0].id, { date: T, paid: 40000, method: 'cash' }); });
eq(d.quotes[0].status, 'converted', 'converted'); eq(d.quotes[0].saleId, sale.id, 'linked to its invoice'); eq(sale.total, 240000, 'invoice has the quote total'); eq(d.products[0].stock, stockBefore - 20, 'stock moved by the invoice, not by the quote');
throws(() => K.tx(d, x => K.convertQuote(x, x.quotes[0].id, { date: T })), 'quote_converted', 'cannot convert twice'); throws(() => K.tx(d, x => K.editQuote(x, x.quotes[0].id, { date: T, items: [{ productId: P, qty: 1, unitPrice: 1 }] })), 'quote_converted', 'converted quote is locked'); throws(() => K.tx(d, x => K.voidQuote(x, x.quotes[0].id)), 'quote_converted', 'cannot void a converted quote');
d = K.tx(d, x => K.addQuote(x, { date: T, customerName: 'Walk-in', items: [{ productId: P, qty: 1, unitPrice: 100 }] }));
throws(() => K.tx(d, x => K.convertQuote(x, x.quotes[1].id, { date: T, paid: 0 })), 'customer_required_for_credit', 'anonymous credit sale refused');
d = K.tx(d, x => K.voidQuote(x, x.quotes[1].id)); eq(d.quotes[1].voided, true, 'void quote'); eq(d.counters.quote, 2, 'quote counter');
throws(() => K.tx(d, x => K.addQuote(x, { date: T, items: [] })), 'items_required', 'items required'); throws(() => K.tx(d, x => K.addQuote(x, { date: T, items: [{ productId: P, qty: 1.5, unitPrice: 100 }] })), 'bad_qty', 'integer qty'); throws(() => K.tx(d, x => K.addQuote(x, { date: T, items: [{ productId: P, qty: 1, unitPrice: 100 }], discount: 999 })), 'discount_exceeds', 'discount limit');
// ---- insights
d = K.tx(d, x => K.recordSale(x, { date: '2026-08-01', customerId: cA, items: [{ productId: P, qty: 2, unitPrice: 10000, weightG: 0 }], paid: 0, method: 'cash' }));
const ins = K.insights(d, T); ok(Array.isArray(ins) && ins.every(i => i.id && i.tone && i.icon), 'insights have id/tone/icon'); ok(ins.some(i => i.id === 'overdue'), 'flags overdue receivables'); ok(ins.some(i => i.id === 'maint_due'), 'flags overdue maintenance');
ok(ins.some(i => i.id === 'backup_old'), 'flags missing backup'); ok(K.insights(K.emptyData(), T).every(i => i.id === 'backup_old'), 'empty data: nothing invented except the backup reminder');
// ---- integrity: the whole thing still validates as a backup and stock = movements
const vb = K.validateBackup(K.makeBackup(d)); ok(vb.ok, 'data with quotes/maintenance still passes backup validation: ' + (vb.errors || []).join());
console.log(fail ? 'FAILED' : 'ALL OK', '- passed:', pass, 'failed:', fail); process.exit(fail ? 1 : 0);
