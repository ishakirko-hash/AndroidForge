// v1.0: the invoice QR code is real: render it, decode it with an independent reader (OpenCV) and compare with the invoice.
const L=require('./lib.js'), cp=require('child_process'), fs=require('fs'), path=require('path'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 await p.setViewportSize({width:390,height:1600});
 const id=await p.evaluate(()=>{const U=window.KPU,K=U.K;let r;U.commit(d=>{d.products.forEach(q=>K.adjustStock(d,{date:K.today(),kind:'product',itemId:q.id,newStock:1000,note:'t'}));const c=K.addCustomer(d,{name:'Zed',phone:'0550'});
  r=K.recordSale(d,{date:K.today(),customerId:c.id,items:[{productId:d.products[0].id,qty:200,unitPrice:32000,weightG:0},{productId:d.products[1].id,qty:300,unitPrice:22000,weightG:0}],discount:0,paid:1000000,method:'cash'}).id;});return r;});
 await p.evaluate(i=>{window.KPU.stack=[];window.KPU.route='invoice';window.KPU.arg=i;window.KPU.render();},id); await p.waitForTimeout(100);
 ok((await p.locator('.paper .qrbox svg').count())===1,'invoice shows a QR code');
 const expect=await p.evaluate(i=>{const U=window.KPU,K=U.K,s=K.byId(U.D.sales,i),paid=K.salePaid(U.D,i);return ['KHALDI PLAST',U.invFull(s),s.date,'TOTAL '+(s.total/100).toFixed(2)+' DZD','PAID '+(paid/100).toFixed(2)+' DZD','DUE '+((s.total-paid)/100).toFixed(2)+' DZD',U.D.settings.phone].join('\n');},id);
 const png=path.join(SH,'qr_invoice.png');
 // render the QR big and sharp (device scale 4) from the real page element
 const ctx=await s.browser.newContext({viewport:{width:390,height:1600},deviceScaleFactor:4}); const pg=await ctx.newPage(); await pg.setContent('<body style="margin:0;background:#fff">'+await p.locator('.paper .qrbox svg').evaluate(e=>{const n=+e.getAttribute('viewBox').split(' ')[2]*10; return e.outerHTML.replace('<svg','<svg width="'+n+'" height="'+n+'"');})+'</body>'); await pg.locator('svg').screenshot({path:png}); await ctx.close();
 const dec=cp.execFileSync('python3',['-I',path.join(__dirname,'qr_decode.py'),png]).toString();
 ok(dec===expect,'OpenCV reads the QR and it equals the invoice data :: '+JSON.stringify(dec));
 ok(dec.includes('TOTAL 130000.00 DZD') && dec.includes('PAID 10000.00 DZD') && dec.includes('DUE 120000.00 DZD'),'decoded text carries the total');
 // changing the payment changes the QR text (never stale)
 await p.evaluate(i=>{const U=window.KPU,K=U.K;U.commit(d=>{K.recordCustomerPayment(d,{date:K.today(),customerId:d.customers[0].id,saleId:i,amount:300000,method:'cash'});});window.KPU.render();},id);
 const svg2=await p.locator('.paper .qrbox svg').evaluate(e=>e.outerHTML); const ctx2=await s.browser.newContext({viewport:{width:390,height:1600},deviceScaleFactor:4}); const pg2=await ctx2.newPage(); await pg2.setContent('<body style="margin:0;background:#fff">'+svg2.replace('<svg','<svg width="'+(+svg2.match(/viewBox="0 0 (\d+)/)[1]*10)+'" height="'+(+svg2.match(/viewBox="0 0 (\d+)/)[1]*10)+'"')+'</body>'); const png2=path.join(SH,'qr_invoice2.png'); await pg2.locator('svg').screenshot({path:png2}); await ctx2.close();
 const dec2=cp.execFileSync('python3',['-I',path.join(__dirname,'qr_decode.py'),png2]).toString(); ok(dec2!==dec && dec2.includes('PAID 13000.00') && dec2.includes('DUE 117000.00'),'QR follows the invoice after a new payment :: '+JSON.stringify(dec2.split('\n').slice(3,6)));
 // voided invoice is marked
 await p.evaluate(i=>{const U=window.KPU,K=U.K;U.commit(d=>{K.voidSale(d,i,'t');});window.KPU.render();},id);
 ok((await p.locator('.paper .qrbox svg').count())===1,'voided invoice still renders');
 // widths
 for(const w of [360,412]){ await p.setViewportSize({width:w,height:1600}); await p.evaluate(()=>window.KPU.render()); const o=await p.evaluate(()=>[document.documentElement.scrollWidth-document.documentElement.clientWidth,document.querySelector('#main').scrollWidth-document.querySelector('#main').clientWidth]); ok(o.every(x=>x<=1),'invoice no overflow @'+w); }
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
