// v0.8 widget home: edit mode, size change, drag reorder, corner resize, hide/add, long-press, persistence, reset, overflow.
const L=require('./lib.js'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const keys=()=>p.evaluate(()=>[].map.call(document.querySelectorAll('.wgrid .wd'),e=>e.dataset.k));
 const home=async()=>{ await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.arg=null;window.KPU.render();}); await p.waitForTimeout(80); };
await p.setViewportSize({width:390,height:2600}); await p.addStyleTag({content:'.wd{animation:none!important}'}); await L.legacyHome(p); await home();
 ok((await keys()).includes('sc:sales') && (await keys()).includes('kpis'),'home renders widgets (sections + shortcuts)');
 ok((await p.locator('.wd-ed').count())===0,'no edit controls outside edit mode');
 await p.click('[data-act="wd_edit"]'); ok((await p.locator('.wgrid.editing').count())===1 && (await p.locator('.wd-ed').count())>3,'edit mode shows controls');
 // size buttons
 await p.click('.wd[data-k="sc:sales"] .wd-rs'); await p.click('.wd[data-k="sc:sales"] .wd-rs'); let d=await D();
 ok(d.settings.layout.sizes['sc:sales']==='l' && d.settings.layout.v===1,'tap on corner handle cycles size s→m→l, saved in layout');
 ok((await p.locator('.wd[data-k="sc:sales"].sz-l').count())===1,'widget re-rendered large');
 await p.click('.wd[data-k="sc:sales"] [data-act="wd_size"][data-s="m"]'); ok((await D()).settings.layout.sizes['sc:sales']==='m','size M saved');
 // section size
 await p.click('.wd[data-k="chart"] [data-act="wd_size"][data-s="s"]'); ok((await p.locator('.wd[data-k="chart"].sz-s').count())===1,'section small');
 // drag move: move sc:invoices onto sc:expenses position
 const before=await keys(); const bx=async k=>{ const b=await p.locator('.wd[data-k="'+k+'"]').boundingBox(); return b; };
 await p.evaluate(()=>{document.querySelector('#main').scrollTop=0;}); await p.waitForTimeout(450);
 const from='sc:stock', to='sc:sales'; const hb=await p.locator('.wd[data-k="'+from+'"] .wd-drag').boundingBox(); const tb=await bx(to);
 await p.mouse.move(hb.x+hb.width/2,hb.y+hb.height/2); await p.mouse.down(); await p.mouse.move(tb.x+tb.width/2,tb.y+tb.height/2,{steps:8}); await p.mouse.up(); await p.waitForTimeout(120);
 const after=await keys(); ok(after.indexOf(from)<after.indexOf(to) || after.indexOf(from)===after.indexOf(to)+1,'drag moved the widget ('+before.indexOf(from)+'→'+after.indexOf(from)+')');
 ok(JSON.stringify(after)!==JSON.stringify(before) && JSON.stringify((await D()).settings.layout.wOrder.filter(k=>after.includes(k)))===JSON.stringify(after),'new order persisted');
 // corner resize
 await p.evaluate(()=>{document.querySelector('#main').scrollTop=0;});
 const rk='sc:production'; const rb=await p.locator('.wd[data-k="'+rk+'"] .wd-rs').boundingBox(); const z0=(await D()).settings.layout.sizes[rk]||'s';
 await p.mouse.move(rb.x+rb.width/2,rb.y+rb.height/2); await p.mouse.down(); await p.mouse.move(rb.x-200,rb.y+rb.height/2+100,{steps:8}); await p.mouse.up(); await p.waitForTimeout(120);
 const z1=(await D()).settings.layout.sizes[rk]; ok(z1 && z1!==z0,'corner drag resized the widget ('+z0+'→'+z1+')');
 // hide + add
 await p.click('.wd[data-k="sc:debts"] [data-act="wd_hide"]'); ok(!(await keys()).includes('sc:debts') && (await D()).settings.layout.hidden.includes('debts'),'× hides a widget');
 await p.click('[data-act="wd_add"]'); ok((await p.locator('#sheet [data-act="wd_show"][data-k="sc:debts"]').count())===1,'add list offers the hidden widget');
 await p.click('#sheet [data-act="wd_show"][data-k="sc:debts"]'); await p.waitForTimeout(100); ok((await keys())[0]==='sc:debts' || (await keys()).includes('sc:debts'),'widget added back');
 await p.screenshot({path:SH+'/w_edit.png'});
 await p.click('[data-act="wd_done"]'); ok((await p.locator('.wd-ed').count())===0,'done leaves edit mode');
 await p.screenshot({path:SH+'/w_done.png'});
 // tap on widget still navigates
 await p.click('.wd[data-k="sc:customers"] .tilebtn'); await p.waitForTimeout(80); ok((await p.evaluate(()=>window.KPU.route))==='customers','tapping a widget opens its section');
 // persistence through reload of data
 const lay=(await D()).settings.layout; ok(lay.wOrder.length>10 && lay.sizes['sc:sales']==='m','layout kept additive (wOrder + sizes)');
 // long-press enters edit
 await home(); const tb2=await p.locator('.wd[data-k="sc:stock"]').boundingBox(); await p.mouse.move(tb2.x+10,tb2.y+10); await p.mouse.down(); await p.waitForTimeout(800); await p.mouse.up(); await p.waitForTimeout(100);
 ok((await p.locator('.wgrid.editing').count())===1 && (await p.evaluate(()=>window.KPU.route))==='home','long-press starts edit mode (no navigation)');
 // reset
 await p.click('[data-act="cz_reset"]'); await p.click('#f button[type="submit"]'); await p.waitForTimeout(150);
 const l2=(await D()).settings.layout; ok(!l2.v && (!l2.wOrder||!l2.wOrder.length),'reset restores defaults');
 await p.click('[data-act="wd_done"]').catch(()=>{});
 // old-style layout (no wOrder) still renders
 await p.evaluate(()=>{ window.KPU.commit(d=>{ d.settings.layout={hidden:['purchases'],order:['stock','sales'],icons:{},secOrder:['recent','kpis'],secHidden:['chart'],v:1}; }); }); await home();
 const k3=await keys(); ok(k3.join()==='today,quick,perf,lines','pre-v1.2 layouts (no hv) open the new default home: '+k3.slice(0,4));
 // customise page link
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='customize';window.KPU.render();}); await p.click('[data-act="wd_edit_go"]'); await p.waitForTimeout(80);
 ok((await p.evaluate(()=>window.KPU.route))==='home' && (await p.locator('.wgrid.editing').count())===1,'customise page opens home edit mode');
 await p.click('[data-act="wd_done"]');
 // overflow
 for(const w of [360,390,412]){ await p.setViewportSize({width:w,height:1400}); for(const ed of [false,true]){ await p.evaluate(e=>{window.KPU.S.homeEdit=e;},ed); await home(); const o=await p.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth); const o2=await p.evaluate(()=>{const m=document.querySelector('#main');return m.scrollWidth-m.clientWidth;}); ok(o<=1&&o2<=1,'no overflow '+w+(ed?' edit':'')+' ('+o+','+o2+')'); } }
 await p.evaluate(()=>{window.KPU.S.homeEdit=false;}); await home(); await p.screenshot({path:SH+'/w_home360.png'});
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
