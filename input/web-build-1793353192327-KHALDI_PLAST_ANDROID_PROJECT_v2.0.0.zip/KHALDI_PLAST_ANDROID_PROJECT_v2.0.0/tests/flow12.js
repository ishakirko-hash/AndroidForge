// v1.2 dark mode: toggle, settings, follow-device, persistence, invoice stays light, no overflow.
const L=require('./lib.js'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 await p.setViewportSize({width:390,height:844});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D))), th=()=>p.evaluate(()=>document.documentElement.getAttribute('data-theme'));
 const go=async(r,a)=>{ await p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.route=r;window.KPU.arg=a||null;window.KPU.render();},[r,a||null]); await p.waitForTimeout(100); };
 const lum=c=>{ const m=c.match(/\d+(\.\d+)?/g).map(Number); return (0.2126*m[0]+0.7152*m[1]+0.0722*m[2])/255; };
 const bg=()=>p.evaluate(()=>getComputedStyle(document.body).backgroundColor);
 await go('home'); ok(await th()==='light' && lum(await bg())>0.9,'default theme is light (white background)');
 await p.click('[data-act="theme_toggle"]'); await p.waitForTimeout(80);
 ok(await th()==='dark' && lum(await bg())<0.15 && (await D()).settings.theme==='dark','home moon button switches to dark and saves it: '+await bg());
 const tx=await p.evaluate(()=>getComputedStyle(document.querySelector('.hwel')).color); ok(lum(tx)>0.7,'heading text is light on dark: '+tx);
 await p.reload(); await p.waitForSelector('#splash.hidden',{state:'attached'}); await p.waitForTimeout(100); ok(await th()==='dark','dark theme persists after restart');
 // settings chips
 await go('settings'); ok((await p.locator('[data-act="setheme"]').count())===3,'settings has light / dark / follow-device');
 await p.click('[data-act="setheme"][data-id="light"]'); ok(await th()==='light','settings: light');
 await p.emulateMedia({colorScheme:'dark'}); await p.click('[data-act="setheme"][data-id="auto"]'); ok(await th()==='dark' && (await D()).settings.theme==='auto','follow device: device dark → dark');
 await p.emulateMedia({colorScheme:'light'}); await p.waitForTimeout(150); ok(await th()==='light','follow device: switching the phone to light updates the app live');
 await p.click('[data-act="setheme"][data-id="dark"]'); ok(await th()==='dark','settings: dark');
 // data untouched
 const d=await D(); ok(d.customers.length===0 && d.settings.lang==='ar' && d.schema===2,'theme changes never touch the data');
 // invoice stays light in dark mode
 await p.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(dd=>{ const c=K.addCustomer(dd,{name:'Zed'}); K.recordProduction(dd,{date:K.today(),productId:dd.products[0].id,good:100,defective:0}); K.recordSale(dd,{date:K.today(),customerId:c.id,items:[{productId:dd.products[0].id,qty:10,unitPrice:30000,weightG:0}],paid:0,method:'cash'}); }); });
 const sid=(await D()).sales[0].id; await go('invoice',sid);
 const pb=await p.evaluate(()=>{ const e=document.querySelector('.paper'); return [getComputedStyle(e).backgroundImage+getComputedStyle(e).backgroundColor, getComputedStyle(e.querySelector('.iv-info .v, .iv-info b, .iv-info span')||e).color]; });
 const first=(pb[0].match(/rgba?\([^)]*\)/)||['rgb(0,0,0)'])[0]; ok(lum(first)>0.85,'invoice sheet background stays light: '+first);
 const ink=await p.evaluate(()=>{ const e=document.querySelector('.paper .iv-info b, .paper .iv-info .v, .paper h2, .paper .iv-title')||document.querySelector('.paper'); return getComputedStyle(e).color; }); ok(lum(ink)<0.45,'invoice text stays dark on its light sheet: '+ink);
 await p.emulateMedia({media:'print'}); ok(lum(await bg())>0.95,'printing is always white even in dark mode'); await p.emulateMedia({media:'screen'});
 // overflow in dark on the main screens
 for(const w of [360,412]){ await p.setViewportSize({width:w,height:844}); for(const r of ['home','sales','stock','production','settings','more','workers']){ await go(r); const ov=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,m:document.getElementById('main').scrollWidth,mc:document.getElementById('main').clientWidth})); if(!(ov.sw<=ov.cw+1&&ov.m<=ov.mc+1)) ok(false,'overflow in dark '+r+' '+w); } ok(true,'dark screens fit at '+w); }
 await p.setViewportSize({width:390,height:844}); await go('home'); await p.screenshot({path:SH+'/home_dark.png'});
 console.log('errors:',s.errors.length?s.errors:'none'); console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail||s.errors.length?1:0); })();
