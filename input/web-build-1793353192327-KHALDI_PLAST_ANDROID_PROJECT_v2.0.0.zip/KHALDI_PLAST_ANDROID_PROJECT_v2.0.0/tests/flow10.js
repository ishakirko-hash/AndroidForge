// v1.1: white background, compact + tappable home cards, built-in QR scanner flow (native bridge simulated).
const L=require('./lib.js'); const SH=process.env.SHOTS||'/tmp';
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 await p.setViewportSize({width:390,height:844});
 const route=()=>p.evaluate(()=>window.KPU.route);
 const home=async()=>{ await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.render();}); await p.waitForTimeout(80); };
 const ids=await p.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(),r={};
  U.commit(d=>{ const sp=K.addSupplier(d,{name:'S'}), c=K.addCustomer(d,{name:'Zed'});
   K.recordPurchase(d,{date:td,supplierId:sp.id,materialId:d.materials[0].id,qty:1000,unitCost:15000,paid:15000000,method:'cash'});
   const g={}; g[d.materials[0].id]=800; K.recordProduction(d,{date:td,productId:d.products[0].id,good:100,defective:5,grams:g});
   const sale=K.recordSale(d,{date:td,customerId:c.id,items:[{productId:d.products[0].id,qty:10,unitPrice:30000}],paid:100000,method:'cash'}); r.sale=sale.id; r.no=sale.no; r.date=sale.date; });
  return r; });
 await L.legacyHome(p); await home();
 // --- white background
 const bg=await p.evaluate(()=>[getComputedStyle(document.body).backgroundColor,getComputedStyle(document.documentElement).backgroundColor,getComputedStyle(document.body,'::before').content,getComputedStyle(document.body,'::after').content,getComputedStyle(document.body,'::before').display]);
 ok(bg[0]==='rgb(255, 255, 255)' && bg[1]==='rgb(255, 255, 255)' && (bg[4]==='none' || bg[2]==='none'),'background is plain white, photo layers removed '+JSON.stringify(bg));
 // --- compact
 const kh=await p.evaluate(()=>Math.round(document.querySelector('.kpi').getBoundingClientRect().height)); ok(kh<=92,'KPI card is compact ('+kh+'px)');

 const seen=await p.evaluate(()=>{ const r=[...document.querySelectorAll('.wd')].map(e=>e.getBoundingClientRect()); return r.filter(b=>b.top<window.innerHeight-70).length; }); ok(seen>=3,'at least 4 home widgets visible without scrolling ('+seen+')');
 await p.screenshot({path:SH+'/home_v11.png'});
 // --- tappable cards
 await p.click('.kpi[data-id="prodmonth"]'); ok(await route()==='prodtable','month production card opens the production table');
 ok((await p.evaluate(()=>window.KPU.S.ym))===(await p.evaluate(()=>window.KPU.K.today().slice(0,7))) && (await p.locator('#main').innerText()).includes('100'),'… on the current month and shows the 100 produced');
 await home(); await p.click('.kpi[data-id="salesmonth"]'); ok(await route()==='sales','month sales card opens Sales');
 await home(); await p.click('.kpi[data-id="stock"]'); ok(await route()==='stock','stock card opens Stock');
 await home(); await p.click('.kpi[data-id="expmonth"]'); ok(await route()==='expenses','expenses card opens Expenses');
 await home(); await p.click('.pcard.tap'); ok(await route()==='prodtable','today-production cards open the production table');
 await home(); await p.click('.panel.tap[data-id="reports"]'); ok(await route()==='reports','sales chart opens Reports');
 // other month selected before: cards always jump to the current month
 await p.evaluate(()=>{ window.KPU.S.ym='2024-01'; }); await home(); await p.click('.kpi[data-id="prodmonth"]'); ok((await p.evaluate(()=>window.KPU.S.ym))===(await p.evaluate(()=>window.KPU.K.today().slice(0,7))),'cards reset the month to the current one');
 // edit mode must not trigger navigation
 await home(); await p.click('[data-act="wd_edit"]'); const r0=await route(); await p.locator('.wd[data-k="kpis"] .kpi').first().click({force:true}).catch(()=>{}); ok(await route()===r0 && r0==='home','tapping a card in edit mode does not navigate'); await p.click('[data-act="wd_done"]');
 // --- scanner: header button + tile
 ok((await p.locator('.hsearch [data-act="scan_qr"]').count())===1,'header has the scan button on Home');
 // browser (no native scanner): manual entry dialog
 await p.click('.hsearch [data-act="scan_qr"]'); ok((await p.locator('#scanin').count())===1,'without the native scanner a manual entry dialog opens');
 await p.fill('#scanin',String(ids.no)); await p.click('[data-act="scan_manual"]'); await p.waitForTimeout(100); ok(await route()==='invoice' && (await p.evaluate(()=>window.KPU.arg))===ids.sale,'typing the invoice number opens the invoice');
 await home();
 // native path: the bridge is called, the result comes back through KPScanResult
 await p.evaluate(()=>{ window.KPU.AND=Object.assign({},window.KPU.AND||{},{scanQR(){window.__scan=(window.__scan||0)+1;}}); });
 await p.click('.hsearch [data-act="scan_qr"]'); ok((await p.evaluate(()=>window.__scan))===1 && (await p.locator('#scanin').count())===0,'with the native scanner the bridge is called (no dialog)');
 const qrText=await p.evaluate(i=>{const U=window.KPU,K=U.K,s=K.byId(U.D.sales,i),paid=K.salePaid(U.D,i);return ['KHALDI PLAST',U.invFull(s),s.date,'TOTAL '+(s.total/100).toFixed(2)+' DZD','PAID '+(paid/100).toFixed(2)+' DZD','DUE '+((s.total-paid)/100).toFixed(2)+' DZD',U.D.settings.phone].join('\n');},ids.sale);
 await p.evaluate(t=>window.KPScanResult(t),qrText); await p.waitForTimeout(100); ok(await route()==='invoice' && (await p.evaluate(()=>window.KPU.arg))===ids.sale,'a scanned QR opens the matching invoice inside the app');
 ok((await p.locator('.paper').innerText()).includes('FV-'),'the invoice is shown');
 // date edited after printing: the number still matches
 await p.evaluate(i=>{ window.KPU.commit(d=>{ d.sales.find(x=>x.id===i).date='2025-12-31'; }); },ids.sale); await home();
 await p.evaluate(t=>window.KPScanResult(t),qrText); await p.waitForTimeout(100); ok(await route()==='invoice','invoice still found after its date was edited (matched by number)');
 // unknown invoice
 await home(); await p.evaluate(()=>window.KPScanResult('KHALDI PLAST\nFV-2026-000999\n2026-10-01\nTOTAL 1300.00 DZD\nPAID 300.00 DZD\nDUE 1000.00 DZD\n0798587564')); await p.waitForTimeout(80);
 const mt=await p.locator('#sheet').innerText(); ok(mt.includes('غير موجودة') && mt.includes('FV-2026-000999') && mt.includes('1,300'),'an unknown invoice is reported with the data read from the code');
 ok((await p.locator('#sheet [data-act="scan_qr"]').count())===1,'dialog offers to scan again'); await p.click('#sheet [data-act="close"]');
 // foreign code
 await p.evaluate(()=>window.KPScanResult('https://example.com/x?a=1')); await p.waitForTimeout(60); const ft=await p.locator('#sheet').innerText(); ok(ft.includes('ليس من فواتير') && ft.includes('example.com'),'a foreign QR is refused and shown as text only'); await p.click('#sheet [data-act="close"]');
 await p.evaluate(()=>window.KPScanResult('<img src=x onerror=window.__xss=1>')); await p.waitForTimeout(60); ok(!(await p.evaluate(()=>window.__xss)) && (await p.locator('#sheet img').count())===0,'scanned text is escaped (no HTML injection)'); await p.click('#sheet [data-act="close"]');
 // tile in More + shortcut
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='more';window.KPU.render();}); ok((await p.locator('.tilebtn[data-id="scan"]').count())===1,'More has the scanner tile');
 await p.evaluate(()=>{ window.__scan=0; }); await p.click('.tilebtn[data-id="scan"]'); ok((await p.evaluate(()=>window.__scan))===1,'the tile starts the scanner');
 // overflow
 for(const w of [360,390,412]){ await p.setViewportSize({width:w,height:844}); await home(); const o=await p.evaluate(()=>[document.documentElement.scrollWidth-document.documentElement.clientWidth,document.querySelector('#main').scrollWidth-document.querySelector('#main').clientWidth,document.querySelector('.hdr').scrollWidth-document.querySelector('.hdr').clientWidth]); ok(o.every(x=>x<=1),'home no overflow @'+w+' '+o); }
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
