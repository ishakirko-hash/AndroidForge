// v0.8 gestures: swipe between tabs, swipe back, swipe-down to close a sheet, guards, off switch.
const L=require('./lib.js');
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const route=()=>p.evaluate(()=>window.KPU.route);
 const swipe=(sel,dx,dy,ms)=>p.evaluate(([sel,dx,dy,ms])=>new Promise(res=>{ const el=document.querySelector(sel); const r=el.getBoundingClientRect(); const x=r.x+r.width/2, y=r.y+Math.min(r.height/2,200);
   const mk=(t,px,py)=>new Touch({identifier:1,target:el,clientX:px,clientY:py});
   const fire=(type,px,py)=>el.dispatchEvent(new TouchEvent(type,{bubbles:true,cancelable:true,touches:type==='touchend'?[]:[mk(0,px,py)],changedTouches:[mk(0,px,py)]}));
   fire('touchstart',x,y); fire('touchmove',x+dx/2,y+dy/2); setTimeout(()=>{ fire('touchend',x+dx,y+dy); res(); },ms||60); }),[sel,dx,dy,ms]);
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.render();});
 // Arabic = RTL: finger moving right goes to the next tab
 await swipe('#main',150,0); await p.waitForTimeout(80); ok(await route()==='sales','RTL: swipe right → next tab (sales)');
 await swipe('#main',150,0); ok(await route()==='stock','swipe right again → stock');
 await swipe('#main',-150,0); ok(await route()==='sales','swipe left → previous tab (sales)');
 await swipe('#main',-150,0); await swipe('#main',-150,0); ok(await route()==='home','no tab before home (stays home)');
 await swipe('#main',60,0); ok(await route()==='home','short swipe ignored');
 await swipe('#main',150,160); ok(await route()==='home','diagonal/vertical swipe ignored');
 await swipe('#main',150,0,900); ok(await route()==='home','slow drag ignored');
 // inner page: swipe back
 await p.evaluate(()=>window.KPU.go('customers')); await swipe('#main',150,0); ok(await route()==='customers','inner page: wrong direction does nothing');
 await swipe('#main',-150,0); ok(await route()==='home','inner page: back swipe returns');
 // sheet: swipe down closes
 await p.evaluate(()=>window.KPU.showModal('<h3>x</h3><p>y</p>')); await swipe('#sheet',0,140); ok(!(await p.evaluate(()=>window.KPU.modalOpen)),'swipe down closes the bottom sheet');
 // guards
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='assistant';window.KPU.render();}); await swipe('#chatq',-150,0); ok(await route()==='assistant','swipe starting on an input is ignored');
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.S.homeEdit=true;window.KPU.render();}); await swipe('#main',150,0); ok(await route()==='home','no tab swipe in home edit mode'); await p.evaluate(()=>{window.KPU.S.homeEdit=false;window.KPU.render();});
 // off switch
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='customize';window.KPU.render();}); await p.click('[data-act="cz_gest"]'); ok((await p.evaluate(()=>window.KPU.D.settings.gestures))===false,'switch turns gestures off');
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.render();}); await swipe('#main',150,0); ok(await route()==='home','gestures off: swipe does nothing');
 await p.evaluate(()=>{window.KPU.stack=[];window.KPU.route='customize';window.KPU.render();}); await p.click('[data-act="cz_gest"]'); ok((await p.evaluate(()=>window.KPU.D.settings.gestures))===true,'switch turns them on again');
 // LTR
 await p.evaluate(()=>{window.KPU.commit(d=>{d.settings.lang='en';}); window.KPU.stack=[];window.KPU.route='home';window.KPU.render();}); await swipe('#main',-150,0); ok(await route()==='sales','LTR: swipe left → next tab');
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
