# usage: python3 qr_decode.py image.png  -> prints decoded text (uses OpenCV's independent QR reader)
import sys, cv2
img = cv2.imread(sys.argv[1], cv2.IMREAD_GRAYSCALE)
img = cv2.copyMakeBorder(img, 30, 30, 30, 30, cv2.BORDER_CONSTANT, value=255)
val, _, _ = cv2.QRCodeDetector().detectAndDecode(img)
sys.stdout.write(val)
