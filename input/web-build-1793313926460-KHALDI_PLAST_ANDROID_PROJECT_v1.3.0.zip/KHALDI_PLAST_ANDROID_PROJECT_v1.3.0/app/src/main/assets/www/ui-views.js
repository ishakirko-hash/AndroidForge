/* KHALDI PLAST - screens. Each view returns an HTML string; actions are wired in ui-main.js. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views = {};
  var KIND = {
    sale: { icon: 'note', cls: 'green' }, purchase: { icon: 'truck', cls: 'amber' }, expense: { icon: 'wallet', cls: 'red' },
    payment: { icon: 'download', cls: '' }, spayment: { icon: 'upload', cls: 'amber' }, production: { icon: 'box', cls: 'purple' }
  };

  /* ---------- transaction rows (shared by home, transactions, lists) ---------- */
  function txInfo(f) {
    var r = f.rec, D = U.D, o = { title: '', sub: '', amt: '', sign: 0, badge: '', text: '' };
    if (f.kind === 'sale') {
      var out = K.saleOutstanding(D, r.id);
      o.title = t('sale_invoice') + ' ' + U.invNo(r.no); o.sub = U.custName(r.customerId) + ' · ' + r.items.map(function (i) { return U.prodName(i.productId) + ' ×' + i.qty; }).join(', ');
      o.amt = U.money(r.total); o.sign = 1; o.badge = r.voided ? U.badge(t('voided'), 'red') : out > 0 ? U.badge(t('remaining') + ' ' + U.moneyTxt(out), 'amber') : U.badge(t('paid'), 'green');
      o.text = o.title + ' ' + o.sub + ' ' + r.notes;
    } else if (f.kind === 'purchase') {
      var po = K.purchaseOutstanding(D, r.id);
      o.title = t('purchase') + ' - ' + U.matName(r.materialId); o.sub = U.supName(r.supplierId) + ' · ' + K.fmtQty(r.qty) + ' ' + t('kg');
      o.amt = U.money(r.total); o.sign = -1; o.badge = r.voided ? U.badge(t('voided'), 'red') : po > 0 ? U.badge(t('remaining') + ' ' + U.moneyTxt(po), 'amber') : U.badge(t('paid'), 'green');
      o.text = o.title + ' ' + o.sub + ' ' + r.notes;
    } else if (f.kind === 'expense') {
      o.title = U.catName(r.categoryId); o.sub = r.description || U.methodLabel(r.method); o.amt = U.money(r.amount); o.sign = -1; o.badge = r.voided ? U.badge(t('voided'), 'red') : '';
      o.text = o.title + ' ' + r.description + ' ' + r.notes;
    } else if (f.kind === 'payment') {
      var s = K.byId(D.sales, r.saleId);
      o.title = t('payment_from') + ' ' + U.custName(r.customerId); o.sub = (s ? U.invNo(s.no) + ' · ' : '') + U.methodLabel(r.method); o.amt = U.money(r.amount); o.sign = 1; o.badge = r.voided ? U.badge(t('voided'), 'red') : '';
      o.text = o.title + ' ' + o.sub;
    } else if (f.kind === 'spayment') {
      o.title = t('payment_to') + ' ' + U.supName(r.supplierId); o.sub = U.methodLabel(r.method); o.amt = U.money(r.amount); o.sign = -1; o.badge = r.voided ? U.badge(t('voided'), 'red') : '';
      o.text = o.title + ' ' + o.sub;
    } else {
      o.title = t('production') + ' - ' + U.prodName(r.productId); o.sub = t('good_short') + ' ' + r.good + ' · ' + t('defective_short') + ' ' + r.defective; o.amt = U.qty(r.good + r.defective) + ' ' + t('pcs'); o.badge = r.voided ? U.badge(t('voided'), 'red') : '';
      o.text = o.title + ' ' + r.notes;
    }
    o.text = (o.text + ' ' + K.fmtDate(r.date) + ' ' + (r.total || r.amount || '')).toLowerCase();
    return o;
  }
  U.txInfo = txInfo;
  U.txRow = function (f) { return txRow(f); };
  function txRow(f) {
    var o = txInfo(f), k = KIND[f.kind];
    return '<div class="row tap' + (f.voided ? ' void' : '') + '" data-act="tx" data-kind="' + f.kind + '" data-id="' + f.id + '"><div class="ibox ' + k.cls + '">' + V.icon(k.icon, 22) + '</div>' +
      '<div class="main"><div class="t">' + esc(o.title) + '</div><div class="s">' + U.dt(f.date) + ' · ' + esc(o.sub) + '</div>' + (o.badge ? '<div style="margin-top:3px">' + o.badge + '</div>' : '') + '</div>' +
      '<div class="r ' + (o.sign > 0 ? 'up' : o.sign < 0 ? 'down' : '') + '">' + o.amt + '</div></div>';
  }
  function feedFor(period, kind, q) {
    var td = K.today(), from = '', f = K.feed(U.D);
    if (period === 'today') from = td; else if (period === 'week') from = K.addDays(td, -6); else if (period === 'month') from = td.slice(0, 7) + '-01';
    return f.filter(function (x) {
      if (from && x.date < from) return false;
      if (kind === 'payments') { if (x.kind !== 'payment' && x.kind !== 'spayment') return false; } else if (kind !== 'all' && x.kind !== kind) return false;
      if (q && txInfo(x).text.indexOf(q.toLowerCase()) < 0) return false;
      return true;
    });
  }

  /* ---------- transactions ---------- */
  W.transactions = function () {
    var S = U.S, list = feedFor(S.txPeriod, S.txKind, S.txQ);
    var h = U.searchbox('txq', S.txQ, t('search'));
    h += U.chips([['all', t('all')], ['sale', t('sales')], ['purchase', t('purchases')], ['production', t('production')], ['expense', t('expenses')], ['payments', t('payments')]], S.txKind, 'txkind');
    h += U.chips([['all', t('p_all')], ['today', t('p_today')], ['week', t('p_week')], ['month', t('p_month')]], S.txPeriod, 'txperiod');
    if (!list.length) return h + '<div class="card">' + U.empty(t('no_results'), 'search') + '</div>';
    var rows = U.limit(list, 'tx', 40);
    return h + '<div class="card">' + rows.map(txRow).join('') + '</div>' + U.moreBtn('tx', 40, list.length);
  };

  function monthDoc(arr, ym) { return K.live(arr).filter(function (x) { return x.date.slice(0, 7) === ym; }); }
  /* ---------- invoices list + invoice paper ---------- */
  W.invoices = function () {
    var q = U.S.invQ.toLowerCase(), list = U.newest(U.D.sales).filter(function (s) { return !q || (U.invNo(s.no) + ' ' + U.custName(s.customerId) + ' ' + K.fmtDate(s.date)).toLowerCase().indexOf(q) >= 0; });
    var h = U.searchbox('invq', U.S.invQ, t('search_invoice'));
    if (!list.length) return h + '<div class="card">' + U.empty(t('no_results'), 'search') + '</div>' + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_sale">+ ' + t('new_invoice') + '</button></div>';
    var rows = U.limit(list, 'inv', 40);
    h += '<div class="card">' + rows.map(function (s) { return txRow({ kind: 'sale', id: s.id, date: s.date, rec: s, voided: s.voided }); }).join('') + '</div>' + U.moreBtn('inv', 40, list.length);
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_sale">+ ' + t('new_invoice') + '</button></div>';
  };
  U.invFull = function (s) { return 'FV-' + String(s.date).slice(0, 4) + '-' + ('000000' + s.no).slice(-6); };
  U.invoiceHtml = function (s) {
    var D = U.D, st = D.settings, c = s.customerId ? K.byId(D.customers, s.customerId) : null, paid = K.salePaid(D, s.id), method = K.saleMethod(D, s.id), dv = s.delivery || {};
    var rem = s.voided ? 0 : s.total - paid, stKey = s.voided ? 'void' : (s.total - paid <= 0 ? 'paid' : paid > 0 ? 'partial' : 'unpaid');
    var stCls = { paid: 'ok', partial: 'warn', unpaid: 'warn', 'void': 'bad' }[stKey];
    function ico(n) { return V.icon(n, 15); }
    function kv(label, val) { return '<div><span>' + label + ' :</span><b>' + (val || '—') + '</b></div>'; }
    var notes = (st.invoiceNotes == null ? t('inv_default_notes') : st.invoiceNotes).split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean);
    if (s.notes) notes.unshift(s.notes);
    var qrTxt = ['KHALDI PLAST', U.invFull(s) + (s.voided ? ' (VOID)' : ''), s.date, 'TOTAL ' + (s.total / 100).toFixed(2) + ' DZD', 'PAID ' + (paid / 100).toFixed(2) + ' DZD', 'DUE ' + (rem / 100).toFixed(2) + ' DZD', st.phone].join('\n'), qr = '';
    try { qr = window.KPQR ? window.KPQR.svg(qrTxt, { level: 'M' }) : ''; } catch (e) { qr = ''; }
    var h = '<div class="paper"><div class="iv-hero"></div>';
    h += '<div class="iv-top"><img class="logo" src="img/logo_full.png" alt="KHALDI PLAST - SHAPING TOMORROW"><div class="iv-co"><div>' + ico('pin') + '<span>' + esc(st.address) + '</span></div><div>' + ico('phone') + '<bdi class="num">' + esc(st.phone) + '</bdi></div><div>' + ico('mail') + '<bdi>' + esc(st.email) + '</bdi></div></div></div>';
    h += '<div class="iv-title"><div class="tt"><b>' + t('sale_invoice') + '</b><span>FACTURE DE VENTE</span></div>' +
      '<div class="iv-meta"><div class="no"><small dir="ltr">N°</small><bdi class="num">' + U.invFull(s) + '</bdi></div>' +
      '<div class="mr"><span>' + t('date') + ' :</span><bdi class="num">' + esc(K.fmtDate(s.date)) + '</bdi><i class="mi">' + ico('calendar') + '</i></div>' +
      '<div class="mr"><span>' + t('pay_method') + ' :</span><b>' + (method ? U.methodLabel(method) : t('on_credit')) + '</b><i class="mi">' + ico('wallet') + '</i></div>' +
      '<div class="mr"><span>' + t('inv_status') + ' :</span><em class="pill ' + stCls + '">' + t('inv_st_' + stKey) + '</em><i class="mi ok">' + ico('check') + '</i></div></div></div>';
    h += '<div class="iv-info"><div class="iv-card cu"><div class="ch"><span class="ci">' + V.icon('user', 18) + '</span><b>' + t('inv_customer_info') + '</b></div><div class="kvs">' +
      kv(t('customer_name'), esc(U.custName(s.customerId))) + kv(t('phone_number'), c && c.phone ? '<bdi class="num">' + esc(c.phone) + '</bdi>' : '') + kv(t('place_address'), c && c.address ? esc(c.address) : '') + '</div></div>' +
      '<div class="iv-card dv"><div class="ch"><span class="ci">' + V.icon('truck', 18) + '</span><b>' + t('inv_delivery_info') + '</b></div><div class="kvs">' +
      kv(t('delivery_date'), dv.date ? '<bdi class="num">' + esc(K.fmtDate(dv.date)) + '</bdi>' : '') + kv(t('delivery_method'), esc(dv.method || '')) + kv(t('notes'), esc(dv.notes || '')) + '</div></div></div>';
    h += '<div class="iv-tw"><table class="iv-t"><thead><tr><th>#</th><th class="l">' + t('product') + '</th><th class="c-x">' + t('inv_ref') + '</th><th class="c-x">' + t('specs') + '</th><th>' + t('quantity') + '</th><th>' + t('unit_price') + '</th><th>' + t('line_total') + '</th></tr></thead><tbody>' +
      s.items.map(function (i, k) {
        var p = K.byId(D.products, i.productId), wg = i.weightG || (p && p.weightG) || 0, spec = p && p.spec ? esc(p.spec) : (wg ? '<bdi class="num">' + wg + '</bdi> ' + t('gram') : '');
        return '<tr><td>' + (k + 1) + '</td><td class="l"><span class="pt"><span class="pn">' + esc(U.prodName(i.productId)) + (spec || (p && p.code) ? '<small class="sp-m">' + [p && p.code ? esc(p.code) : '', spec].filter(Boolean).join(' · ') + '</small>' : '') + '</span>' + (p ? V.crate(p.color, 40) : '') + '</span></td><td class="c-x">' + (p && p.code ? esc(p.code) : '—') + '</td><td class="c-x">' + (spec || '—') + '</td>' +
          '<td><b><bdi class="num">' + K.fmtQty(i.qty) + '</bdi></b><small>' + t('pcs') + '</small></td><td>' + U.money(i.unitPrice) + '</td><td><b>' + U.money(Math.round(i.qty * i.unitPrice)) + '</b></td></tr>';
      }).join('') + '</tbody></table></div>';
    h += '<div class="iv-two"><div class="iv-card nt"><div class="ch"><span class="ci">' + V.icon('note', 18) + '</span><b>' + t('inv_notes') + '</b></div><ul>' + notes.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>' +
      '<div class="iv-card tt2"><div class="tr"><span>' + t('inv_subtotal') + '</span><b>' + U.money(s.subtotal) + '</b></div>' + (s.discount ? '<div class="tr"><span>' + t('discount') + '</span><b>' + U.money(s.discount) + '</b></div>' : '') + '<div class="grand"><span>' + t('inv_grand') + '</span><b>' + U.money(s.total) + '</b></div></div></div>';
    h += '<div class="iv-two b2"><div class="iv-card pay"><div class="ch"><span class="ci">' + V.icon('wallet', 18) + '</span><b>' + t('pay_method') + '</b><i class="pill ok">' + (method ? U.methodLabel(method) : t('on_credit')) + '</i></div>' +
      '<div class="tr"><span>' + t('paid') + ' :</span><b>' + U.money(paid) + '</b></div><div class="tr"><span>' + t('remaining') + ' :</span><b>' + U.money(rem) + '</b></div></div>' +
      '<div class="iv-card sg2"><div class="sbox"><span class="lab">' + t('inv_signature') + '</span><div class="sline"></div></div><div class="sbox"><span class="lab">' + t('inv_stamp') + '</span><div class="stamp"><div class="st1"><img src="img/logo_mark.png" alt=""><span><b>KHALDI PLAST</b><small>SHAPING TOMORROW</small></span></div><em>' + esc(st.address) + '</em><small><bdi class="num">' + esc(st.phone) + '</bdi> - ' + esc(st.email) + '</small></div></div></div></div>';
    if (qr) h += '<div class="iv-card qrc"><div class="qrbox">' + qr + '</div><div class="qrt"><b>' + t('qr_title') + '</b><span>' + t('qr_help') + '</span><small dir="ltr">' + U.invFull(s) + '</small></div></div>';
    h += '<div class="iv-foot"><div class="fi"><span>' + V.icon('pin', 15) + esc(st.address) + '</span><span>' + V.icon('phone', 15) + '<bdi class="num">' + esc(st.phone) + '</bdi></span><span>' + V.icon('mail', 15) + '<bdi>' + esc(st.email) + '</bdi></span></div><div class="sl">SHAPING TOMORROW</div></div></div>';
    return h;
  };
  W.invoice = function (id) {
    var s = K.byId(U.D.sales, id); if (!s) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    return U.invoiceHtml(s) + '<div class="btns noprint"><button class="btn" data-act="tx" data-kind="sale" data-id="' + id + '">' + V.icon('note', 18) + ' ' + t('tx_details') + '</button><button class="btn primary" data-act="print_invoice" data-id="' + id + '">' + V.icon('print', 18) + ' ' + t('print_pdf') + '</button></div>';
  };

  /* ---------- purchases ---------- */
  W.purchases = function () {
    var ym = U.S.ym, m = K.monthlyReport(U.D, ym), n = Number(K.monthRange(ym).to.slice(8)), daily = [], i;
    for (i = 0; i < n; i++) daily.push(0);
    monthDoc(U.D.purchases, ym).forEach(function (p) { daily[Number(p.date.slice(8)) - 1] += p.total; });
    var h = U.monthbar();
    h += '<div class="grid2">' + U.stat(t('total_purchases'), U.money(m.purchases), 'red') + U.stat(t('purchase_count'), '<bdi class="num">' + monthDoc(U.D.purchases, ym).length + '</bdi>') + '</div>';
    h += '<div class="card"><h3>' + t('daily_purchases') + '</h3>' + V.bars(daily.map(function (x) { return x / 100; }), daily.map(function (x, k) { return String(k + 1); }), '#E5493A') + '</div>';
    var list = U.newest(U.D.purchases.filter(function (p) { return p.date.slice(0, 7) === ym; }));
    h += U.sec(t('latest_purchases'));
    h += list.length ? '<div class="card">' + U.limit(list, 'pur', 8).map(function (p) { return txRow({ kind: 'purchase', id: p.id, date: p.date, rec: p, voided: p.voided }); }).join('') + '</div>' + U.moreBtn('pur', 8, list.length) : '<div class="card">' + U.empty(t('no_records')) + '</div>';
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_purchase">+ ' + t('new_purchase') + '</button></div>';
  };

  /* ---------- production ---------- */
  /* ---------- debts & collections ---------- */
  W.debts = function () {
    var D = U.D, tab = U.S.debtTab || 'customers', isC = tab === 'customers', list = U.act(isC ? D.customers : D.suppliers), h = '';
    h += '<div class="grid2">' + U.stat(t('customer_debts'), U.money(K.totalCustomerDebt(D)), 'red') + U.stat(t('supplier_debts'), U.money(K.totalSupplierDebt(D)), 'amber') + '</div>';
    h += U.seg([['customers', t('customers')], ['suppliers', t('suppliers')]], tab, 'debttab');
    if (!list.length) h += '<div class="card">' + U.empty(t('no_records'), 'users') + '</div>';
    else {
      var rows = list.map(function (p) { return { p: p, b: isC ? K.customerBalance(D, p.id) : K.supplierBalance(D, p.id) }; }).sort(function (a, b) { return b.b - a.b; });
      h += '<div class="card">' + rows.map(function (x) {
        return '<div class="row tap" data-act="party" data-kind="' + (isC ? 'customer' : 'supplier') + '" data-id="' + x.p.id + '"><div class="ibox ' + (x.b > 0 ? 'red' : 'green') + '">' + V.icon('user', 22) + '</div><div class="main"><div class="t">' + esc(x.p.name) + '</div>' + (x.p.phone ? '<div class="s"><bdi class="num">' + esc(x.p.phone) + '</bdi></div>' : '') + '</div><div class="r ' + (x.b > 0 ? 'down' : 'up') + '">' + U.money(x.b) + '</div></div>';
      }).join('') + '</div>';
    }
    var pays = U.newest((isC ? D.payments : D.supplierPayments)).slice(0, 8);
    if (pays.length) {
      h += U.sec(t('previous_payments'));
      h += '<div class="card">' + pays.map(function (p) { return payRow(isC ? 'customer' : 'supplier', p); }).join('') + '</div>';
    }
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_party" data-kind="' + (isC ? 'customer' : 'supplier') + '">+ ' + t(isC ? 'new_customer' : 'new_supplier') + '</button></div>';
  };
  function payRow(kind, p) {
    var isC = kind === 'customer', doc = K.byId(isC ? U.D.sales : U.D.purchases, isC ? p.saleId : p.purchaseId);
    return '<div class="row tap' + (p.voided ? ' void' : '') + '" data-act="edit_payment" data-kind="' + kind + '" data-id="' + p.id + '"><div class="ibox ' + (isC ? '' : 'amber') + '">' + V.icon(isC ? 'download' : 'upload', 22) + '</div><div class="main"><div class="t">' + esc(isC ? U.custName(p.customerId) : U.supName(p.supplierId)) + '</div>' +
      '<div class="s">' + U.dt(p.date) + ' · ' + U.methodLabel(p.method) + (doc && isC ? ' · ' + U.invNo(doc.no) : '') + (p.history ? ' · ' + t('edited') : '') + '</div></div><div class="r">' + U.money(p.amount) + '</div>' + (p.voided ? '' : '<span class="muted">' + V.icon('edit', 18) + '</span>') + '</div>';
  }
  U.payRow = payRow;

  /* ---------- expenses ---------- */
  W.expenses = function () {
    var D = U.D, ym = U.S.ym, r = K.monthRange(ym), cats = K.expensesByCategory(D, r.from, r.to), total = K.sum(cats, function (c) { return c.amount; });
    var h = U.monthbar();
    h += U.stat(t('total_expenses_month'), U.money(total), 'red');
    h += '<div class="card" style="margin-top:10px">';
    if (!total) h += U.empty(t('no_records'), 'wallet');
    else {
      h += '<div class="donutrow">' + V.donut(cats.map(function (c, i) { return { value: c.amount, color: V.palette[i % V.palette.length] }; }), V.compact(total / 100), t('dzd')) + '<div class="legend">' +
        cats.map(function (c, i) { return '<div class="li"><span class="sw" style="background:' + V.palette[i % V.palette.length] + '"></span><span class="nm">' + esc(U.catName(c.categoryId)) + '</span><span class="pc"><bdi class="num">' + Math.round(c.amount * 100 / total) + '%</bdi></span></div>'; }).join('') + '</div></div>';
    }
    h += '</div>';
    if (total) h += U.sec(t('expense_details')) + '<div class="card">' + cats.map(function (c, i) { return '<div class="row"><div class="ibox" style="background:' + V.palette[i % V.palette.length] + '22;color:' + V.palette[i % V.palette.length] + '">' + V.icon('wallet', 20) + '</div><div class="main"><div class="t">' + esc(U.catName(c.categoryId)) + '</div></div><div class="r">' + U.money(c.amount) + '</div></div>'; }).join('') + '</div>';
    var list = U.newest(D.expenses.filter(function (e) { return e.date.slice(0, 7) === ym; }));
    if (list.length) h += U.sec(t('expense_log')) + '<div class="card">' + U.limit(list, 'exp', 10).map(function (e) { return txRow({ kind: 'expense', id: e.id, date: e.date, rec: e, voided: e.voided }); }).join('') + '</div>' + U.moreBtn('exp', 10, list.length);
    return h + '<div class="fixedbtn"><button class="btn primary" style="width:100%" data-act="new_expense">+ ' + t('new_expense') + '</button></div>';
  };

  /* ---------- workers & weekly shifts ---------- */
  /* ---------- reports ---------- */
  function warnings(m) {
    var o = '';
    if (m.warnings.indexOf('missing_cost') >= 0) o += '<div class="alert">' + t('cost_missing') + ': <b>' + esc(m.missing.join(', ')) + '</b></div>';
    if (m.warnings.indexOf('no_grams') >= 0) o += '<div class="alert">' + t('warn_no_grams') + ' (' + m.noGrams + ')</div>';
    if (m.warnings.indexOf('no_production') >= 0) o += '<div class="alert">' + t('warn_no_production') + '</div>';
    return o;
  }
  function reportTable(m) {
    function row(l, v, strong) { return '<tr' + (strong ? ' class="total"' : '') + '><td>' + l + '</td><td class="n">' + v + '</td></tr>'; }
    function mo(v) { return v == null ? '-' : U.money(v); }
    var h = '<div class="tablewrap"><table>';
    h += row(t('total_sales'), mo(m.sales)) + row(t('crates_sold'), U.qty(m.cratesSold)) + row(t('amount_collected'), mo(m.collected));
    h += row(t('total_purchases') + ' <span class="muted">(' + t('not_consumption') + ')</span>', mo(m.purchases));
    h += row(t('materials_consumed') + ' <span class="muted">(' + t('estimate') + ')</span>', mo(m.materialsCost));
    h += row(t('gross_margin') + ' <span class="muted">(' + t('estimate') + ')</span>', mo(m.grossMargin));
    h += row(t('total_expenses_month'), mo(m.expenses));
    h += row(t('est_profit'), mo(m.operatingProfit), true);
    h += row(t('good_crates'), U.qty(m.good)) + row(t('defective_crates'), U.qty(m.defective)) + row(t('defect_loss'), m.materialsCost == null ? '-' : mo(m.defectCost));
    h += row(t('unpaid_customers'), mo(m.customerDebt)) + row(t('unpaid_suppliers'), mo(m.supplierDebt));
    return h + '</table></div>';
  }
  W.reports = function () {
    var D = U.D, tab = U.S.repTab || 'month', h = U.seg([['month', t('monthly')], ['year', t('yearly')], ['custom', t('custom')]], tab, 'reptab');
    if (tab === 'month') {
      var ym = U.S.ym, m = K.monthlyReport(D, ym), pv = K.monthlyReport(D, K.addMonths(ym, -1)), c = K.compareMonths(m, pv);
      h += U.monthbar();
      h += '<div class="grid2">' + U.stat(t('total_sales'), U.money(m.sales), 'green', U.delta(c.sales)) + U.stat(t('total_purchases'), U.money(m.purchases), 'red', U.delta(c.purchases, true)) +
        U.stat(t('total_expenses_month'), U.money(m.expenses), 'amber', U.delta(c.expenses, true)) + U.stat(t('est_profit'), m.operatingProfit == null ? '-' : U.money(m.operatingProfit), m.operatingProfit == null ? '' : m.operatingProfit >= 0 ? 'green' : 'red', U.delta(c.profit)) + '</div>';
      h += '<div class="muted" style="margin:-4px 2px 10px">' + t('vs_prev_month') + ': ' + esc(U.monthLabel(K.addMonths(ym, -1))) + '</div>';
      var ser = K.monthSeries(D, ym, 6), lb = ser.map(function (x) { return x.ym.slice(5); });
      h += '<div class="card"><h3>' + t('monthly_comparison') + '</h3>' + V.lines([{ color: '#2F6FDB', values: ser.map(function (x) { return x.sales / 100; }) }, { color: '#E5493A', values: ser.map(function (x) { return x.purchases / 100; }) }, { color: '#F5A524', values: ser.map(function (x) { return x.expenses / 100; }) }, { color: '#34A853', values: ser.map(function (x) { return x.profit == null ? null : x.profit / 100; }) }], lb) +
        '<div class="legendline"><span><i class="sw" style="background:#2F6FDB"></i>' + t('sales') + '</span><span><i class="sw" style="background:#E5493A"></i>' + t('purchases') + '</span><span><i class="sw" style="background:#F5A524"></i>' + t('expenses') + '</span><span><i class="sw" style="background:#34A853"></i>' + t('est_profit') + '</span></div></div>';
      h += warnings(m) + U.sec(t('report_details')) + reportTable(m);
      if (m.expensesByCat.length) h += U.sec(t('expenses_by_cat')) + '<div class="tablewrap"><table>' + m.expensesByCat.map(function (x) { return '<tr><td>' + esc(U.catName(x.categoryId)) + '</td><td class="n">' + U.money(x.amount) + '</td></tr>'; }).join('') + '</table></div>';
      h += '<div class="alert blue">' + t('profit_method') + '</div><button class="btn block" data-act="export_report">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button>';
    } else if (tab === 'year') {
      var y = U.S.year || K.today().slice(0, 4), months = []; for (var i = 1; i <= 12; i++) months.push(y + '-' + K.pad2(i));
      var rs = months.map(function (x) { return K.monthlyReport(D, x); });
      h += '<div class="monthbar"><button class="arrow" data-act="year_prev">' + V.icon(U.lang() === 'ar' ? 'chevR' : 'chevL', 20) + '</button><div class="pill">' + V.icon('calendar', 18) + '<span><bdi class="num">' + y + '</bdi></span></div><button class="arrow" data-act="year_next">' + V.icon(U.lang() === 'ar' ? 'chevL' : 'chevR', 20) + '</button></div>';
      h += '<div class="card">' + V.lines([{ color: '#2F6FDB', values: rs.map(function (x) { return x.sales / 100; }) }, { color: '#E5493A', values: rs.map(function (x) { return x.purchases / 100; }) }, { color: '#F5A524', values: rs.map(function (x) { return x.expenses / 100; }) }], months.map(function (x) { return x.slice(5); })) + '</div>';
      h += '<div class="tablewrap"><table><tr><th>' + t('month') + '</th><th class="n">' + t('sales') + '</th><th class="n">' + t('purchases') + '</th><th class="n">' + t('expenses') + '</th><th class="n">' + t('est_profit') + '</th></tr>' +
        rs.map(function (x) { return '<tr><td><bdi class="num">' + x.ym.slice(5) + '</bdi></td><td class="n"><bdi class="num">' + K.fmtMoney(x.sales) + '</bdi></td><td class="n"><bdi class="num">' + K.fmtMoney(x.purchases) + '</bdi></td><td class="n"><bdi class="num">' + K.fmtMoney(x.expenses) + '</bdi></td><td class="n">' + (x.operatingProfit == null ? '-' : '<bdi class="num">' + K.fmtMoney(x.operatingProfit) + '</bdi>') + '</td></tr>'; }).join('') +
        '<tr class="total"><td>' + t('totals') + '</td><td class="n"><bdi class="num">' + K.fmtMoney(K.sum(rs, function (x) { return x.sales; })) + '</bdi></td><td class="n"><bdi class="num">' + K.fmtMoney(K.sum(rs, function (x) { return x.purchases; })) + '</bdi></td><td class="n"><bdi class="num">' + K.fmtMoney(K.sum(rs, function (x) { return x.expenses; })) + '</bdi></td><td class="n"></td></tr></table></div>';
      h += '<div class="alert blue">' + t('profit_method') + '</div>';
    } else {
      var from = U.S.repFrom || K.today().slice(0, 7) + '-01', to = U.S.repTo || K.today();
      h += '<div class="card"><div class="two"><div><label style="margin-top:0">' + t('from') + '</label><input type="date" id="rfrom" value="' + from + '"></div><div><label style="margin-top:0">' + t('to') + '</label><input type="date" id="rto" value="' + to + '"></div></div></div>';
      if (!K.validDate(from) || !K.validDate(to) || from > to) h += '<div class="alert red">' + t('err_bad_range') + '</div>';
      else { var pr = K.periodReport(D, from, to); h += warnings(pr) + reportTable(pr) + '<div class="alert blue">' + t('profit_method') + '</div><button class="btn block" data-act="export_report">' + V.icon('download', 18) + ' ' + t('export_csv') + '</button>'; }
    }
    return h + '<button class="btn block noprint" data-act="goto" data-id="profit" style="margin-top:8px">' + V.icon('bars', 18) + ' ' + t('tile_profit') + '</button>';
  };
  U.reportRows = function () {
    var D = U.D, S = U.S, m = S.repTab === 'custom' ? K.periodReport(D, S.repFrom || K.today().slice(0, 7) + '-01', S.repTo || K.today()) : K.monthlyReport(D, S.ym);
    function c(v) { return v == null ? '' : (v / 100).toFixed(2); }
    return { name: S.repTab === 'custom' ? 'custom' : S.ym, rows: [[t('period'), m.from + ' → ' + m.to], [t('total_sales'), c(m.sales)], [t('crates_sold'), m.cratesSold], [t('amount_collected'), c(m.collected)], [t('total_purchases'), c(m.purchases)],
      [t('materials_consumed') + ' (' + t('estimate') + ')', c(m.materialsCost)], [t('gross_margin') + ' (' + t('estimate') + ')', c(m.grossMargin)], [t('total_expenses_month'), c(m.expenses)], [t('est_profit'), c(m.operatingProfit)],
      [t('good_crates'), m.good], [t('defective_crates'), m.defective], [t('unpaid_customers'), c(m.customerDebt)], [t('unpaid_suppliers'), c(m.supplierDebt)]].concat(m.expensesByCat.map(function (x) { return [t('category') + ': ' + U.catName(x.categoryId), c(x.amount)]; })) };
  };

  /* ---------- transaction details (+ edit / delete) ---------- */
  function histBlock(rec) {
    if (!rec.history || !rec.history.length) return '';
    return U.sec(t('edit_history')) + '<div class="card">' + rec.history.map(function (hh) {
      var b = hh.before, v = b.total != null ? U.money(b.total) : b.amount != null ? U.money(b.amount) : b.good != null ? U.qty(b.good) : '';
      return '<div class="row"><div class="ibox">' + V.icon('undo', 20) + '</div><div class="main"><div class="t">' + t('before_edit') + '</div><div class="s">' + U.dt(hh.ts.slice(0, 10)) + ' · ' + U.dt(b.date) + '</div></div><div class="r">' + v + '</div></div>';
    }).join('') + '</div>';
  }
  W.tx = function (arg) {
    var D = U.D, k = arg.kind, id = arg.id, h = '', rec;
    var arr = { sale: D.sales, purchase: D.purchases, expense: D.expenses, payment: D.payments, spayment: D.supplierPayments, production: D.production }[k];
    rec = K.byId(arr, id); if (!rec) return '<div class="card">' + U.empty(t('err_no_item')) + '</div>';
    var o = txInfo({ kind: k, rec: rec });
    h += '<div class="titlecard"><div class="ibox ' + KIND[k].cls + '">' + V.icon(KIND[k].icon, 28) + '</div><div><div class="big">' + esc(o.title) + '</div>' + (rec.voided ? U.badge(t('voided'), 'red') : '') + '</div></div>';
    h += '<div class="card">' + U.kv('calendar', t('date'), U.dt(rec.date));
    if (k === 'sale') {
      var paid = K.salePaid(D, id), met = K.saleMethod(D, id);
      h += U.kv('user', t('customer'), esc(U.custName(rec.customerId))) + U.kv('wallet', t('pay_method'), met ? U.methodLabel(met) : t('on_credit')) + U.kv('tag', t('subtotal'), U.money(rec.subtotal)) + U.kv('tag', t('discount'), U.money(rec.discount)) +
        U.kv('tag', t('grand_total'), U.money(rec.total)) + U.kv('check', t('paid'), U.money(paid)) + U.kv('clock', t('remaining'), U.money(rec.voided ? 0 : rec.total - paid)) + U.kv('note', t('notes'), esc(rec.notes) || '-') + '</div>';
      h += U.sec(t('item_details')) + '<div class="tablewrap"><table><tr><th>' + t('product') + '</th><th class="n">' + t('quantity') + '</th><th class="n">' + t('unit_price') + '</th><th class="n">' + t('line_total') + '</th></tr>' +
        rec.items.map(function (i) { return '<tr><td>' + esc(U.prodName(i.productId)) + '</td><td class="n">' + U.qty(i.qty) + '</td><td class="n"><bdi class="num">' + K.fmtMoney(i.unitPrice) + '</bdi></td><td class="n"><bdi class="num">' + K.fmtMoney(i.qty * i.unitPrice) + '</bdi></td></tr>'; }).join('') + '</table></div>';
      var pays = D.payments.filter(function (p) { return p.saleId === id; });
      h += U.sec(t('payments')) + (pays.length ? '<div class="card">' + pays.map(function (p) { return payRow('customer', p); }).join('') + '</div>' : '<div class="card">' + U.empty(t('none')) + '</div>');
      if (!rec.voided && rec.total - paid > 0 && rec.customerId) h += '<button class="btn primary block" data-act="pay_sale" data-id="' + id + '">' + t('receive_payment') + '</button>';
      h += '<button class="btn block" data-act="goto" data-id="invoice" data-arg="' + id + '">' + V.icon('print', 18) + ' ' + t('view_invoice') + '</button>';
    } else if (k === 'purchase') {
      var pp = K.sum(D.supplierPayments.filter(function (p) { return p.purchaseId === id && !p.voided; }), function (p) { return p.amount; });
      h += U.kv('truck', t('supplier'), esc(U.supName(rec.supplierId))) + U.kv('box', t('material'), esc(U.matName(rec.materialId))) + U.kv('scale', t('quantity'), U.qty(rec.qty) + ' ' + t('kg')) + U.kv('tag', t('unit_cost_per_kg'), U.money(rec.unitCost)) +
        U.kv('tag', t('total'), U.money(rec.total)) + U.kv('check', t('paid'), U.money(pp)) + U.kv('clock', t('remaining'), U.money(rec.voided ? 0 : rec.total - pp)) + U.kv('note', t('notes'), esc(rec.notes) || '-') + '</div>';
      var sp = D.supplierPayments.filter(function (p) { return p.purchaseId === id; });
      h += U.sec(t('payments')) + (sp.length ? '<div class="card">' + sp.map(function (p) { return payRow('supplier', p); }).join('') + '</div>' : '<div class="card">' + U.empty(t('none')) + '</div>');
    } else if (k === 'expense') {
      h += U.kv('tag', t('category'), esc(U.catName(rec.categoryId))) + U.kv('note', t('description'), esc(rec.description) || '-') + U.kv('wallet', t('pay_method'), U.methodLabel(rec.method)) + U.kv('tag', t('amount'), U.money(rec.amount)) + U.kv('note', t('notes'), esc(rec.notes) || '-') + '</div>';
    } else if (k === 'payment' || k === 'spayment') {
      var isC = k === 'payment', doc = K.byId(isC ? D.sales : D.purchases, isC ? rec.saleId : rec.purchaseId);
      h += U.kv('user', t(isC ? 'customer' : 'supplier'), esc(isC ? U.custName(rec.customerId) : U.supName(rec.supplierId))) + (doc ? U.kv('note', t('invoice'), isC ? U.invNo(doc.no) : esc(U.matName(doc.materialId))) : '') + U.kv('wallet', t('pay_method'), U.methodLabel(rec.method)) + U.kv('tag', t('amount'), U.money(rec.amount)) + U.kv('note', t('notes'), esc(rec.notes) || '-') + '</div>';
    } else {
      var cst = K.productionCost(D, rec);
      h += U.kv('box', t('product'), esc(U.prodName(rec.productId))) + U.kv('check', t('good_crates'), U.qty(rec.good)) + U.kv('alert', t('defective_crates'), U.qty(rec.defective)) +
        Object.keys(rec.grams || {}).map(function (mid) { return U.kv('scale', U.matName(mid), '<bdi class="num">' + rec.grams[mid] + '</bdi> ' + t('gram') + ' / ' + t('crate')); }).join('') +
        rec.consumption.map(function (l) { return U.kv('scale', t('consumed') + ' ' + U.matName(l.materialId), U.qty(l.qty) + ' ' + t('kg')); }).join('') +
        U.kv('tag', t('est_cost'), cst.complete ? U.money(cst.total) : '<span class="muted">' + (cst.noConsumption ? t('cost_unknown_noconsumption') : t('cost_missing') + ': ' + esc(cst.missing.join(', '))) + '</span>') +
        (cst.complete && rec.good ? U.kv('tag', t('cost_per_good'), U.money(cst.perGood)) : '') + U.kv('note', t('notes'), esc(rec.notes) || '-') + '</div>';
    }
    h += histBlock(rec);
    if (!rec.voided) h += '<button class="btn danger block" data-act="void_tx" data-kind="' + k + '" data-id="' + id + '">' + V.icon('trash', 18) + ' ' + t('delete_tx') + '</button>';
    else h += '<div class="alert red" style="margin-top:10px">' + t('voided') + (rec.voidReason ? ': ' + esc(rec.voidReason) : '') + '</div>';
    return h;
  };

  /* ---------- more, settings, backup ---------- */
  W.settings = function () {
    var s = U.D.settings, h = '';
    h += '<div class="card"><h3>' + t('language') + '</h3>' + U.chips([['ar', 'العربية'], ['fr', 'Français'], ['en', 'English']], s.lang, 'setlang') + '</div>';
    h += '<div class="card"><h3>' + t('theme') + '</h3><div class="muted" style="margin-bottom:10px">' + t('theme_help') + '</div>' + U.chips([['light', t('theme_light')], ['dark', t('theme_dark')], ['auto', t('theme_auto')]], s.theme || 'light', 'setheme') + '</div>';
    h += '<div class="card"><h3>' + t('currency') + ' - ' + t('dzd_full') + '</h3><div class="muted" style="margin-bottom:10px">' + t('currency_help') + '</div>' + U.chips([['dzd', t('mode_dzd')], ['centimes', t('mode_centimes')]], s.inputMode === 'centimes' ? 'centimes' : 'dzd', 'setmode') + '<div class="alert green">' + (U.mode() === 'dzd' ? t('example_dzd') : t('example_centimes')) + '</div></div>';
    h += '<div class="card"><h3>' + t('company_info') + '</h3>' + U.kv('tag', t('address'), esc(s.address)) + U.kv('phone', t('phone'), '<bdi class="num">' + esc(s.phone) + '</bdi>') + U.kv('note', t('email'), '<bdi>' + esc(s.email) + '</bdi>') + '<button class="btn sm block" data-act="edit_company">' + t('edit') + '</button></div>';
    h += '<div class="card"><h3>' + t('expense_categories') + '</h3><div>' + U.act(U.D.expenseCats).map(function (c) { return '<button class="chipbtn" data-act="edit_category" data-id="' + c.id + '">' + esc(U.catName(c.id)) + ' ' + V.icon('edit', 14) + '</button> '; }).join('') + '</div><button class="btn sm block" data-act="new_category">+ ' + t('new_category') + '</button></div>';
    h += '<div class="card"><h3>' + t('about') + '</h3><div class="row"><div class="main">KHALDI PLAST</div><div class="r">v1.3.0</div></div><div class="muted">' + t('about_text') + '</div></div>';
    return h;
  };
  W.backup = function () {
    var lb = U.D.settings.lastBackup, h = '';
    if (U.locked) h += '<div class="alert red">' + t('warn_data_damaged') + '</div>' + (U.rawDamaged ? '<button class="btn soft-danger block" data-act="export_damaged">' + t('export_damaged') + '</button>' : '');
    h += '<div class="card"><h3>' + t('backup') + '</h3><div class="muted">' + t('backup_help') + '</div><div style="margin:10px 0">' + t('last_backup') + ': <b>' + (lb ? '<bdi class="num">' + K.fmtDate(lb.slice(0, 10)) + ' ' + lb.slice(11, 16) + '</bdi>' : t('never')) + '</b></div><button class="btn primary block" data-act="export_backup">' + V.icon('download', 18) + ' ' + t('export_backup') + '</button></div>';
    h += '<div class="card"><h3>' + t('restore') + '</h3><div class="alert">' + t('restore_warn') + '</div><button class="btn block" data-act="import_backup">' + V.icon('upload', 18) + ' ' + t('import_backup') + '</button></div>';
    if (U.sideLoad('premigration_v1.json')) h += '<div class="card"><h3>' + t('premigration') + '</h3><div class="muted">' + t('premigration_help') + '</div><button class="btn sm block" data-act="export_premigration">' + t('export_premigration') + '</button></div>';
    var n = U.D.sales.length + U.D.payments.length + U.D.purchases.length + U.D.production.length + U.D.expenses.length;
    return h + '<div class="card muted">' + t('records_count', { n: n }) + '</div>';
  };
})();
