/* KHALDI PLAST - shell: routing, header, bottom navigation, actions, splash, backup/restore, start-up. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, $ = U.$, W = U.views, F = U.forms, S = U.S;
  U.route = 'home'; U.arg = null; U.stack = [];
  var TITLE = { transactions: 'v_transactions', sales: 'tile_sales', purchases: 'tile_purchases', production: 'tile_production', stock: 'tile_stock', debts: 'tile_debts', expenses: 'tile_expenses', workers: 'tile_workers', notes: 'v_notes', payroll: 'tile_payroll', profit: 'tile_profit',
    invoices: 'tile_invoices', invoice: 'sale_invoice', customers: 'tile_customers', suppliers: 'tile_suppliers', worker: 'tile_workers', prodtable: 'tile_prodtable', assistant: 'tile_assistant', customize: 'tile_customize', tx: 'tx_details', reports: 'tile_reports', more: 'v_more', settings: 'v_settings', backup: 'v_backup' };
  var TABOF = { home: 'home', sales: 'sales', invoices: 'sales', invoice: 'sales', stock: 'stock', production: 'production', more: 'more' };
  var PAGE = { sales: ['bars', 'sub_sales'], invoices: ['note', 'sub_invoices'], stock: ['box', 'sub_stock'], production: ['machine', 'sub_production'], workers: ['users', 'sub_workers'], notes: ['note', 'sub_notes'], payroll: ['wallet', 'sub_payroll'], profit: ['bars', 'sub_profit'],
    purchases: ['truck', 'sub_purchases'], expenses: ['wallet', 'sub_expenses'], debts: ['wallet', 'sub_debts'], reports: ['bars', 'sub_reports'], transactions: ['list', 'sub_transactions'], more: ['menu', 'sub_more'],
    settings: ['settings', 'sub_settings'], customers: ['users', 'sub_customers'], suppliers: ['truck', 'sub_suppliers'], worker: ['user', 'sub_worker'], prodtable: ['table', 'sub_prodtable'], assistant: ['chat', 'sub_assistant'], customize: ['sliders', 'sub_customize'], backup: ['save', 'sub_backup'], invoice: ['note', 'sale_invoice'], tx: ['list', 'tx_details'] };
  var EDITABLE = function (k, id) {
    return { sale: function () { F.sale(id); }, purchase: function () { F.purchase(id); }, expense: function () { F.expense(id); }, payment: function () { F.editPayment('customer', id); }, spayment: function () { F.editPayment('supplier', id); }, production: function () { F.production(id); } }[k];
  };

  /* ---------- navigation ---------- */
  U.go = function (route, arg, replace) {
    if (!replace) U.stack.push({ route: U.route, arg: U.arg });
    U.route = route; U.arg = arg == null ? null : arg; U.render(); $('#main').scrollTop = 0;
  };
  U.back = function () { var p = U.stack.pop(); if (p) { U.route = p.route; U.arg = p.arg; } else { U.route = 'home'; U.arg = null; } U.render(); };

  /* ---------- render ---------- */
  function alerts() {
    var D = U.D, a = [], i;
    D.products.concat(D.materials).forEach(function (x) { if (x.minStock > 0 && x.stock <= x.minStock) a.push({ icon: 'alert', cls: 'red', text: t('low_stock') + ': ' + x.name + ' (' + K.fmtQty(x.stock) + ')' }); });
    D.customers.map(function (c) { return { c: c, b: K.customerBalance(D, c.id) }; }).filter(function (x) { return x.b > 0; }).sort(function (x, y) { return y.b - x.b; }).slice(0, 5).forEach(function (x) { a.push({ icon: 'wallet', cls: 'amber', text: x.c.name + ': ' + U.moneyTxt(x.b) }); });
    var lb = D.settings.lastBackup;
    if (!lb || (Date.now() - new Date(lb).getTime()) > 7 * 86400000) a.push({ icon: 'save', cls: 'amber', text: lb ? t('backup_old') : t('backup_never') });
    return a;
  }
  U.alerts = alerts;
  U.render = function (keep) {
    var D = U.D, l = D.settings.lang, main = $('#main'), st = main.scrollTop, R = U.route, home = R === 'home';
    document.documentElement.lang = l; document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
    var app = $('#app'); app.classList.toggle('lightmode', home);
    var hdr = $('#hdr'), left, right = '', title;
    var canBack = U.stack.length > 0 && !home;
    var BACKI = l === 'ar' ? 'chevR' : 'chevL';   // header grid is LTR: "back" points to the start side of the reading direction
    left = canBack ? '<button class="hbtn l" data-act="back" aria-label="' + esc(t('back')) + '">' + V.icon('back', 24) + '</button>' : '<button class="hbtn l" data-act="quick" aria-label="' + esc(t('quick_add')) + '">' + V.icon('menu', 24) + '</button>';
    var chip = '<button class="hbtn chip r" data-act="cyclelang" aria-label="' + esc(t('language')) + '">' + { ar: 'ع', fr: 'FR', en: 'EN' }[l] + '</button>';
    hdr.className = 'hdr' + (home ? '' : ' inner');
    if (home) right = '<button class="hbtn r" data-act="bell" aria-label="' + esc(t('alerts')) + '">' + V.icon('bell', 24) + (alerts().length ? '<span class="dot"></span>' : '') + '</button>';
    else {
      right = chip;
      if (R === 'tx') {
        var arg = U.arg, rec = null;
        var arr = { sale: U.D.sales, purchase: U.D.purchases, expense: U.D.expenses, payment: U.D.payments, spayment: U.D.supplierPayments, production: U.D.production }[arg.kind];
        rec = K.byId(arr, arg.id);
        if (rec && !rec.voided) right = '<button class="hbtn edit r" data-act="edit_tx">' + V.icon('edit', 18) + t('edit') + '</button>';
      } else if (R === 'invoice') right = '<div class="hgroup"><button class="hbtn" data-act="share_invoice" aria-label="' + esc(t('share')) + '">' + V.icon('share', 22) + '</button><button class="hbtn" data-act="print_invoice" data-id="' + U.arg + '" aria-label="' + esc(t('print_pdf')) + '">' + V.icon('print', 22) + '</button></div>';
    }
    title = '<div class="brand"><img src="img/logo_full.png" alt="KHALDI PLAST - SHAPING TOMORROW"></div>';
    hdr.innerHTML = left + title + right;
    var ph = '';
    if (!home && R !== 'invoice') {
      var pm = PAGE[R] || ['list', ''], nm = R === 'party' ? (K.byId(U.arg.kind === 'customer' ? D.customers : D.suppliers, U.arg.id) || { name: '' }).name : R === 'worker' ? (K.byId(D.workers, U.arg) || { name: '' }).name : t(TITLE[R]);
      ph = '<div class="pagehead"><div class="pi">' + V.icon(R === 'party' || R === 'worker' ? 'user' : pm[0], 26) + '</div><div class="pt"><b>' + esc(nm) + '</b>' + (pm[1] ? '<span>' + esc(t(pm[1])) + '</span>' : '') + '</div></div>';
    }
    main.innerHTML = ph + W[R](U.arg);
    if (keep) main.scrollTop = st;
    var tab = TABOF[R] || (U.stack.length ? TABOF[(U.stack[0] || {}).route] : null) || 'more';
    function nb(id, ic, label) { return '<button class="nb ' + (tab === id ? 'on' : '') + '" data-act="tab" data-id="' + id + '"' + (tab === id ? ' aria-current="page"' : '') + '>' + V.icon(ic, 24) + '<span>' + label + '</span></button>'; }
    $('#nav').innerHTML = nb('home', 'home', t('v_home')) + nb('sales', 'bars', t('tile_sales')) + nb('stock', 'box', t('tile_stock')) + nb('production', 'machine', t('tile_production')) + nb('more', 'menu', t('v_more'));
    // wire inputs created by the view
    [['txq', 'txQ'], ['invq', 'invQ'], ['noteq', 'noteQ']].forEach(function (p) { var el = $('#' + p[0]); if (el) el.oninput = function () { S[p[1]] = el.value; U.render(true); var e2 = $('#' + p[0]); e2.focus(); e2.setSelectionRange(e2.value.length, e2.value.length); }; });
    [].forEach.call(main.querySelectorAll('input[data-bind]'), function (el) {
      el.oninput = function () { var key = el.getAttribute('data-bind'); S[key] = el.value; U.render(true); var e2 = main.querySelector('input[data-bind="' + key + '"]'); if (e2) { e2.focus(); e2.setSelectionRange(e2.value.length, e2.value.length); } };
    });
    if (U.afterRender) U.afterRender(R);
    var rf = $('#rfrom'), rt = $('#rto');
    if (rf) rf.onchange = function () { S.repFrom = rf.value; U.render(true); };
    if (rt) rt.onchange = function () { S.repTo = rt.value; U.render(true); };
  };

  /* ---------- files, printing, sharing ---------- */
  var exportKind = '';
  window.KPExportDone = function (ok, cancelled) {
    if (ok) { U.toast(t('export_ok'), 'ok'); if (exportKind === 'backup') { try { U.commit(function (d) { d.settings.lastBackup = new Date().toISOString(); }); } catch (e) {} if (U.route === 'backup') U.render(true); } }
    else if (!cancelled) U.toast(t('export_fail'), 'bad');
    exportKind = '';
  };
  window.KPFlush = function () { return 0; };
  window.KPBack = function () {
    if ($('#splash') && !$('#splash').classList.contains('hidden')) return false;
    if (U.modalOpen) { U.closeModal(); return true; }
    if (U.stack.length) { U.back(); return true; }
    if (U.route !== 'home') { U.route = 'home'; U.arg = null; U.render(); return true; }
    return false;
  };
  function invoiceText(s) {
    var D = U.D, st = D.settings, paid = K.salePaid(D, s.id);
    return 'KHALDI PLAST\n' + t('sale_invoice') + ' ' + U.invNo(s.no) + '\n' + t('date') + ': ' + K.fmtDate(s.date) + '\n' + t('customer') + ': ' + U.custName(s.customerId) + '\n' +
      s.items.map(function (i) { return '- ' + U.prodName(i.productId) + ' x' + i.qty + ' @ ' + K.fmtMoney(i.unitPrice) + ' = ' + K.fmtMoney(i.qty * i.unitPrice); }).join('\n') + '\n' +
      t('discount') + ': ' + U.moneyTxt(s.discount) + '\n' + t('grand_total') + ': ' + U.moneyTxt(s.total) + '\n' + t('paid') + ': ' + U.moneyTxt(paid) + '\n' + t('remaining') + ': ' + U.moneyTxt(s.total - paid) + '\n' + st.address + ' - ' + st.phone + ' - ' + st.email;
  }
  function printInvoice(id) {
    var s = K.byId(U.D.sales, id); if (!s) return;
    if (U.route !== 'invoice') { U.go('invoice', id); }
    setTimeout(function () { if (U.AND && U.AND.printPage) U.AND.printPage('KHALDI_PLAST_' + U.invNo(s.no)); else window.print(); }, 150);
  }

  /* ---------- actions ---------- */
  function monthShift(n) { S.ym = K.addMonths(S.ym, n); U.render(true); }
  var A = {
    close: function () { U.closeModal(); },
    back: function () { U.back(); },
    tab: function (el) { U.closeModal(); U.stack = []; U.route = el.dataset.id; U.arg = null; U.render(); $('#main').scrollTop = 0; },
    goto: function (el) { var id = el.dataset.id; var arg = el.dataset.arg || null; if (id === 'more' || id === 'sales' || id === 'stock' || id === 'production') { U.stack = []; U.route = id; U.arg = null; U.render(); $('#main').scrollTop = 0; } else U.go(id, arg); },
    showall: function (el) { S.showAll[el.dataset.id] = true; U.render(true); },
    month_prev: function () { monthShift(-1); }, month_next: function () { monthShift(1); },
    year_prev: function () { S.year = String(Number(S.year || K.today().slice(0, 4)) - 1); U.render(true); }, year_next: function () { S.year = String(Number(S.year || K.today().slice(0, 4)) + 1); U.render(true); },
    week_prev: function () { S.week = K.addDays(S.week, -7); U.render(true); }, week_next: function () { S.week = K.addDays(S.week, 7); U.render(true); },
    txkind: function (el) { S.txKind = el.dataset.id; S.showAll.tx = false; U.render(true); }, txperiod: function (el) { S.txPeriod = el.dataset.id; S.showAll.tx = false; U.render(true); },
    stocktab: function (el) { S.stockTab = el.dataset.id; U.render(true); }, debttab: function (el) { S.debtTab = el.dataset.id; U.render(true); },
    worktab: function (el) { S.workTab = el.dataset.id; U.render(true); }, reptab: function (el) { S.repTab = el.dataset.id; U.render(true); },
    tx: function (el) { U.go('tx', { kind: el.dataset.kind, id: el.dataset.id }); },
    party: function (el) { U.go('party', { kind: el.dataset.kind, id: el.dataset.id }); },
    edit_tx: function () { var f = EDITABLE(U.arg.kind, U.arg.id); if (f) f(); },
    void_tx: function (el) { F.void(el.dataset.kind, el.dataset.id); },
    new_sale: function () { U.closeModal(); F.sale(); }, new_production: function () { U.closeModal(); F.production(); }, new_purchase: function () { U.closeModal(); F.purchase(); }, new_expense: function () { U.closeModal(); F.expense(); },
    edit_machine: function (el) { F.machine(el.dataset.id); }, edit_category: function (el) { F.category(el.dataset.id); }, new_note: function () { F.note(); }, edit_note: function (el) { F.note(el.dataset.id); },
    new_party: function (el) { F.party(el.dataset.kind); }, edit_party: function (el) { F.party(el.dataset.kind, el.dataset.id); },
    new_item: function (el) { F.item(el.dataset.kind); }, edit_item: function (el) { F.item(el.dataset.kind, el.dataset.id); }, adjust: function (el) { F.adjust(el.dataset.kind, el.dataset.id); },
    pay_party: function (el) { F.payment(el.dataset.kind, el.dataset.id); },
    pay_sale: function (el) { var s = K.byId(U.D.sales, el.dataset.id); F.payment('customer', s.customerId); },
    pay_customer_pick: function () { U.closeModal(); F.pickParty('customer'); }, pay_supplier_pick: function () { U.closeModal(); F.pickParty('supplier'); },
    edit_payment: function (el) { F.editPayment(el.dataset.kind, el.dataset.id); },
    roster: function (el) { F.roster(el.dataset.date, Number(el.dataset.shift)); },
    new_worker: function () { F.worker(); }, edit_worker: function (el) { F.worker(el.dataset.id); }, new_machine: function () { F.machine(); },
    edit_company: function () { F.company(); }, new_category: function () { F.category(); },
    setlang: function (el) { U.commit(function (d) { d.settings.lang = el.dataset.id; }); U.render(true); },
    cyclelang: function () { var n = U.LANGS[(U.li() + 1) % 3]; U.commit(function (d) { d.settings.lang = n; }); U.render(true); },
    setmode: function (el) { U.commit(function (d) { d.settings.inputMode = el.dataset.id; }); U.render(true); },
    print_invoice: function (el) { printInvoice(el.dataset.id || U.arg); },
    share_invoice: function () {
      var s = K.byId(U.D.sales, U.arg); if (!s) return; var txt = invoiceText(s);
      if (U.AND && U.AND.shareText) U.AND.shareText(txt);
      else if (navigator.share) navigator.share({ text: txt }).catch(function () {});
      else if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { U.toast(t('copied'), 'ok'); });
    },
    export_report: function () {
      var r = U.reportRows(); exportKind = 'report';
      U.saveFile('khaldi_report_' + r.name + '.csv', 'text/csv', '﻿' + r.rows.map(function (x) { return x.map(U.csvEscape).join(','); }).join('\r\n'));
    },
    export_backup: function () { exportKind = 'backup'; U.saveFile('khaldi_plast_backup_' + K.today() + '.json', 'application/json', JSON.stringify(K.makeBackup(U.D), null, 1)); },
    export_premigration: function () { exportKind = 'pre'; U.saveFile('khaldi_plast_before_upgrade.json', 'application/json', U.sideLoad('premigration_v1.json')); },
    export_damaged: function () { exportKind = 'raw'; U.saveFile('khaldi_plast_damaged_data.json', 'application/json', U.rawDamaged); },
    import_backup: function () { var f = $('#importfile'); f.value = ''; f.click(); },
    quick: function () {
      var b = [['new_sale', 'note', 'new_sale'], ['new_production', 'box', 'new_production'], ['new_purchase', 'truck', 'new_purchase'], ['new_expense', 'wallet', 'new_expense'], ['pay_customer_pick', 'download', 'receive_payment'], ['pay_supplier_pick', 'upload', 'pay_supplier']];
      U.showModal('<h3>' + t('quick_add') + '</h3><div class="quick">' + b.map(function (x) { return '<button class="qb" data-act="' + x[0] + '">' + V.icon(x[1], 28) + '<span>' + t(x[2]) + '</span></button>'; }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
    },
    bell: function () {
      var a = alerts();
      U.showModal('<h3>' + t('alerts') + '</h3>' + (a.length ? '<div class="card flush" style="box-shadow:none">' + a.map(function (x) { return '<div class="row"><div class="ibox ' + x.cls + '">' + V.icon(x.icon, 22) + '</div><div class="main"><div class="t" style="font-weight:600">' + esc(x.text) + '</div></div></div>'; }).join('') + '</div>' : U.empty(t('no_alerts'), 'check')) +
        '<div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>');
    }
  };
  document.addEventListener('click', function (e) {
    if (e.target.id === 'modal') { U.closeModal(); return; }
    var el = e.target.closest('[data-act]'); if (!el) return;
    var fn = A[el.dataset.act] || (U.extraActions || {})[el.dataset.act]; if (!fn) return;
    e.stopPropagation(); U.run(function () { fn(el); });
  });

  /* ---------- restore: read -> validate (and migrate) -> confirm -> replace. Nothing changes unless every step passes. ---------- */
  $('#importfile').addEventListener('change', function () {
    var file = this.files && this.files[0]; if (!file) return;
    var rd = new FileReader();
    rd.onerror = function () { U.toast(t('import_unreadable'), 'bad'); };
    rd.onload = function () {
      var obj;
      try { obj = JSON.parse(String(rd.result).replace(/^﻿/, '')); } catch (e) { U.toast(t('import_unreadable'), 'bad'); return; }
      var v = K.validateBackup(obj);
      if (!v.ok) { U.showModal('<h3>' + t('import_invalid') + '</h3><div class="alert red">' + t('import_invalid_text') + '<br><span class="muted">' + esc(v.errors.join(' | ')) + '</span></div><div class="btns"><button class="btn ghost" data-act="close">' + t('close') + '</button></div>'); return; }
      var nb = v.data, cur = U.D;
      function cnt(d) { return d.sales.length + ' / ' + d.purchases.length + ' / ' + d.expenses.length + ' / ' + d.production.length; }
      U.openForm({
        title: t('import_confirm_title'), submit: t('import_replace'), danger: true,
        intro: '<div class="alert red">' + t('import_confirm_text') + '</div>' + (v.migrated ? '<div class="alert blue">' + t('import_old_format') + '</div>' : '') +
          '<div class="row"><div class="main">' + t('current_data') + '</div><div class="r"><bdi class="num">' + cnt(cur) + '</bdi></div></div><div class="row"><div class="main">' + t('backup_data') + '</div><div class="r"><bdi class="num">' + cnt(nb) + '</bdi></div></div><div class="muted">' + t('import_counts_legend') + '</div>',
        fields: [{ name: 'ok', label: t('import_type_yes'), type: 'text', ph: t('yes_word') }],
        onSubmit: function (vals) {
          if (vals.ok.trim().toLowerCase() !== t('yes_word').toLowerCase()) throw K.E('import_not_confirmed');
          U.sideSave('before_import.json', JSON.stringify(K.makeBackup(cur)));       // automatic safety copy of what is being replaced
          U.persist(nb);                                                              // throws if it cannot be written -> current data stays
          U.D = nb; U.locked = false; U.loadWarning = null; U.rawDamaged = '';
          U.closeModal(); U.stack = []; U.route = 'home'; U.render(); U.toast(t('import_ok'), 'ok');
        }
      });
    };
    rd.readAsText(file);
  });

  /* ---------- start-up: the splash stays only while the app really initialises ---------- */
  function leaveSplash() {
    var sp = $('#splash'); if (!sp || sp.classList.contains('hidden')) return;
    sp.classList.add('leaving'); setTimeout(function () { sp.classList.add('hidden'); }, 240);
  }
  function waitAssets(done) {
    var pending = 0, fired = false;
    function fin() { if (!fired) { fired = true; done(); } }
    function one() { pending++; return function () { if (--pending <= 0) fin(); }; }
    ['img/logo_full.png', 'img/bg_glass.jpg'].forEach(function (src) { var im = new Image(), cb = one(); im.onload = im.onerror = cb; im.src = src; });
    if (document.fonts && document.fonts.ready) { var cb2 = one(); document.fonts.ready.then(cb2, cb2); }
    setTimeout(fin, 4000);   // safety net only: never block on a missing asset
  }
  function start() {
    var err = $('#sperr'), rt = $('#spretry'), sp = $('.sp-spin');
    err.classList.add('hidden'); rt.classList.add('hidden'); sp.classList.remove('hidden');
    try {
      U.D = U.loadData();
      U.route = U.locked ? 'backup' : 'home'; U.stack = [];
      U.render();
      waitAssets(leaveSplash);
    } catch (e) {
      var L = (window.I18N || {}), pick = function (k) { var x = L[k]; return x ? x[0] : k; };
      sp.classList.add('hidden'); err.textContent = pick('start_failed'); rt.textContent = pick('retry'); err.classList.remove('hidden'); rt.classList.remove('hidden');
    }
  }
  $('#spretry').addEventListener('click', start);
  start();
})();
