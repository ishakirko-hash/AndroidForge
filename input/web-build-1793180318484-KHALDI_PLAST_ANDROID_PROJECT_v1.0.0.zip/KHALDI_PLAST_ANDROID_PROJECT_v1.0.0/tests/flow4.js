// v0.7 features through the real UI: shifts in production, party/worker forms, worker payments, order->invoice, customise, assistant.
const L=require('./lib.js');
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2]); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const go=async(r,a)=>{ await p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.route=r;window.KPU.arg=a||null;window.KPU.render();},[r,a]); await p.waitForTimeout(60); };
 const submit=async()=>{ await p.click('#f button[type="submit"]'); await p.waitForTimeout(120); };
 const txt=async()=>(await p.locator('#main').innerText());
 // stock: material + production with shift
 await p.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(d=>{ K.adjustStock(d,{date:K.today(),kind:'material',itemId:d.materials[0].id,newStock:500,note:'t'}); }); });
 let d=await D(); const m0=d.materials[0].id;
 await go('production'); await p.click('[data-act="new_production"]'); await p.selectOption('#f_shift','2'); await p.fill('#f_good','120'); await p.fill('#f_bad','5'); await p.fill('[name="g_'+m0+'"]','300'); await submit();
 d=await D(); ok(d.production[0].shift===2 && d.production[0].good===120,'production saved with shift 2');
 await go('prodtable'); let t=await txt(); ok(t.includes('120') && t.includes('جدول'),'production table shows the day total 120');
 const row=await p.locator('table.ptable tbody tr').first().innerText(); ok(/120/.test(row) && /5/.test(row),'table row has good 120 and defective 5');
 await p.click('table.ptable tbody tr.tap'); ok((await p.locator('#sheet').innerText()).includes('120'),'tap on a day opens its records'); await p.click('[data-act="close"]');
 // customer with extra fields
 await go('customers'); await p.click('[data-act="new_party"]'); await p.fill('#f_name','Zed Market'); await p.fill('#f_phone','0555 01 02 03'); await p.fill('#f_address','Oran'); await p.fill('#f_email','z@x.dz'); await p.fill('#f_activity','Retail'); await submit();
 d=await D(); const c=d.customers.find(x=>x.name==='Zed Market'); ok(c && c.address==='Oran' && c.email==='z@x.dz' && c.activity==='Retail','customer extra info saved');
 ok((await txt()).includes('Oran') && (await txt()).includes('0555 01 02 03'),'customers directory shows phone and place');
 await p.fill('input[data-bind="custQ"]','retail'); ok((await p.locator('.row.tap').count())===1,'customer search by activity works');
 await p.click('.row.tap'); ok((await txt()).includes('z@x.dz'),'customer file shows email');
 // supplier
 await go('suppliers'); await p.click('[data-act="new_party"]'); await p.fill('#f_name','Sup Z'); await p.fill('#f_address','Alger'); await submit(); d=await D(); ok(d.suppliers.some(x=>x.name==='Sup Z'&&x.address==='Alger'),'supplier with address saved');
 // worker
 await p.evaluate(()=>{window.KPU.S.workTab='list';}); await go('workers'); await p.click('[data-act="new_worker"]');
 await p.fill('#f_name','Hamid'); await p.fill('#f_role','Operator'); await p.selectOption('#f_status','leave'); await p.fill('#f_rate','2000'); await p.fill('#f_hireDate','2026-01-05'); await p.fill('#f_address','Blida'); await submit();
 d=await D(); const w=d.workers.find(x=>x.name==='Hamid'); ok(w && w.role==='Operator' && w.status==='leave' && w.rate===200000 && w.active===false,'worker status/role/rate saved');
 await p.evaluate(([id])=>{ const U=window.KPU,K=U.K; U.commit(dd=>{ K.setShiftRoster(dd,{date:K.today(),shift:1,entries:[{workerId:id,worked:true}]}); K.setShiftRoster(dd,{date:K.addDays(K.today(),-1),shift:1,entries:[{workerId:id,worked:true}]}); }); },[w.id]);
 await go('worker',w.id); t=await txt(); ok(t.includes('Operator')&&t.includes('4,000'),'worker file: role + earned 4,000 (2 shifts x 2,000)');
 await p.click('[data-act="pay_worker"]'); await p.fill('#f_amount','1500'); await submit();
 d=await D(); ok(d.workerPayments.length===1 && d.expenses.some(e=>e.amount===150000),'advance recorded and counted once as expense');
 t=await txt(); ok(t.includes('2,500'),'balance now 2,500');
 await p.click('[data-act="edit_wpay"]'); await p.fill('#f_amount','1000'); await submit(); d=await D(); ok(d.workerPayments.length===1 && d.workerPayments[0].amount===100000 && d.expenses.filter(e=>!e.voided).reduce((a,e)=>a+e.amount,0)===100000,'edit payment updates linked expense (no duplicate)');
 await p.click('[data-act="edit_wpay"]'); await p.click('[data-del]'); await p.click('#f button[type="submit"]'); await p.waitForTimeout(120); d=await D(); ok(d.workerPayments[0].voided===true && d.expenses.every(e=>e.voided||e.amount!==100000),'delete payment voids it and its expense');
 // order note -> invoice
 await p.evaluate(()=>{ const U=window.KPU,K=U.K; U.commit(dd=>{ K.adjustStock(dd,{date:K.today(),kind:'product',itemId:dd.products[0].id,newStock:200,note:'t'}); }); });
 await go('notes'); await p.click('[data-act="new_note"]'); await p.fill('#f_customerName','Zed Market'); await p.fill('#f_phone','0555'); await p.selectOption('#f_product',d.products[0].id); await p.fill('#f_qty','25'); await p.fill('#f_expectedDate','2026-12-31'); await p.selectOption('#f_status','confirmed'); await submit();
 d=await D(); const note=d.notes[0]; ok(note.isOrder && note.qty===25 && note.status==='confirmed','order note saved');
 await p.click('[data-act="note_invoice"]'); ok((await p.locator('.itrow [data-k="qty"]').first().inputValue())==='25' && (await p.locator('#f_customer').inputValue())===d.customers.find(x=>x.name==='Zed Market').id,'conversion opens an invoice prefilled with qty 25 and the customer');
 await p.locator('.itrow [data-k="price"]').first().fill('320'); await p.fill('#f_paid','0'); await submit(); d=await D(); ok(d.sales.length===1 && d.notes[0].saleId===d.sales[0].id && d.notes[0].status==='completed','invoice saved, note linked and completed');
 await go('notes'); ok((await p.locator('[data-act="note_invoice"]').count())===0 && (await p.locator('[data-act="note_view_invoice"]').count())===1,'no second conversion possible; "view invoice" shown');
 const dup=await p.evaluate(()=>{ try{ window.KPU.commit(dd=>window.KPU.K.linkNoteToSale(dd,dd.notes[0].id,dd.sales[0].id)); return 'no error'; }catch(e){ return e.code||e.message; } }); ok(dup==='note_already_invoiced','core refuses duplicate link');
 // customise
 await go('customize'); await p.click('[data-act="cz_toggle"][data-id="sales"]'); await p.click('[data-act="cz_up"][data-id="stock"]');
 await p.click('[data-act="cz_icon"][data-id="reports"]'); await p.click('[data-act="cz_seticon"][data-icon="assistant"]');
 await p.click('[data-act="cz_sec_toggle"][data-id="chart"]');
 await go('home'); const tiles=await p.locator('.wgrid .tilebtn').evaluateAll(b=>b.map(x=>x.dataset.id));
 ok(!tiles.includes('sales') && tiles.includes('stock'),'hidden shortcut removed from home, others kept: '+tiles.join(','));
 ok(!(await txt()).includes('آخر 6 أشهر'),'hidden home section (chart) not shown');
 const secs=await p.evaluate(()=>window.KPU.D.settings.layout); ok(secs.v===1 && secs.icons.reports==='assistant' && secs.secHidden.includes('chart'),'layout saved in settings: '+JSON.stringify(secs.secHidden));
 await go('more'); ok((await p.locator('.tiles .tilebtn').count())===21,'More still lists every section (21)');
 await p.reload(); await p.waitForSelector('#splash.hidden',{state:'attached'}); d=await D(); ok(d.settings.layout.v===1 && d.settings.layout.hidden.includes('sales'),'layout persists after reload');
 await go('customize'); await p.click('[data-act="cz_reset"]'); await p.click('#f button[type="submit"]'); await p.waitForTimeout(100); d=await D(); ok(!d.settings.layout.v && d.sales.length===1,'reset layout leaves data untouched');
 // assistant: numbers must match the data
 await go('assistant'); const ask=async(q)=>{ await p.fill('#chatq',q); await p.click('[data-act="chat_send"]'); await p.waitForTimeout(80); return (await p.locator('.chatbubble.a').last().innerText()); };
 let a=await ask('ملخص شامل'); ok(/المبيعات/.test(a)&&/ديون الزبائن/.test(a),'assistant summary has sales and debts');
 d=await D(); const debt=d.sales[0].total/100; a=await ask('Zed Market'); ok(a.includes(String(debt).replace(/\B(?=(\d{3})+(?!\d))/g,','))||a.includes(String(debt)),'assistant customer answer shows the real balance '+debt);
 a=await ask('Hamid'); ok(a.includes('Operator'),'assistant worker answer has role');
 a=await ask('الإنتاج هذا الشهر'); ok(a.includes('120'),'assistant production answer has 120');
 a=await ask('asdfgh'); ok(/لم أفهم/.test(a),'unknown question handled honestly');
 // overflow on narrow phones
 for(const w of [360,412]){ await p.setViewportSize({width:w,height:800}); for(const r of ['home','sales','stock','production','prodtable','workers','customers','notes','assistant','customize','more']){ await go(r); const o=await p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth+1||document.getElementById('main').scrollWidth>document.getElementById('main').clientWidth+1); if(o){ ok(false,'overflow '+r+' @'+w); } } }
 ok(true,'overflow scan 360/412 done');
 console.log('errors:',s.errors.length?s.errors:'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
