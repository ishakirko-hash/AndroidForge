/* KHALDI PLAST - v3 dashboard engine: registry, layouts, grid renderer, drag & drop, resize, library, persistence.
   Replaces the old home widget engine. Data comes only from the real ERP data (K / U.D). */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, t = U.t, esc = U.esc, W = U.views, S = U.S, X = U.extraActions, DX = U._dx, MM = U._mm, HOME = DX.HOME;
  function T(ar, fr, en) { var l = U.lang(); return l === 'fr' ? fr : l === 'en' ? en : ar; }
  function B(n) { return '<bdi class="num" dir="ltr">' + n + '</bdi>'; }
  function rtl() { return U.lang() === 'ar'; }
  function noData() { return '<div class="muted dnd">' + T('لا توجد بيانات', 'Aucune donnée', 'No data') + '</div>'; }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  /* ---------------- sizes ---------------- */
  var SZO = ['xs', 's', 'm', 'w', 'l'], SZN = { xs: [1, 1], s: [2, 1], m: [2, 2], w: [4, 1], l: [4, 2] };
  function szName(z) { return { xs: T('مصغّر', 'Mini', 'Mini'), s: T('صغير', 'Petit', 'Small'), m: T('متوسط', 'Moyen', 'Medium'), w: T('عريض (كامل العرض)', 'Large (pleine largeur)', 'Wide (full width)'), l: T('كبير', 'Grand', 'Large') }[z]; }
  function rz(z) { return z === 'xs' || z === 's' ? 's' : z === 'l' ? 'l' : 'm'; }
  var SCZ = { xs: 's', s: 'm', m: 'l', w: 'm', l: 'l' };
  function sizeFrom(c, h) { return c === 1 ? 'xs' : c === 2 ? (h > 1 ? 'm' : 's') : (h > 1 ? 'l' : 'w'); }

  /* ---------------- registry ---------------- */
  var CATS = [['prod', T('الإنتاج', 'Production', 'Production'), 'factory'], ['mach', T('الآلات', 'Machines', 'Machines'), 'machine'], ['stock', T('المخزون', 'Stock', 'Stock'), 'box'],
    ['sales', T('المبيعات والطلبات', 'Ventes', 'Sales & orders'), 'cart'], ['dist', T('التوزيع والشحن', 'Distribution', 'Distribution'), 'truck'], ['team', T('العمال والورديات', 'Équipe', 'Workers & shifts'), 'users'],
    ['qual', T('الجودة والتنبيهات', 'Qualité', 'Quality & alerts'), 'check'], ['fin', T('المالية', 'Finance', 'Finance'), 'wallet'], ['sc', T('الاختصارات', 'Raccourcis', 'Shortcuts'), 'menu']];
  var REG = {};
  function reg(k, cat, ic, z, de, r, cfg) { REG[k] = { k: k, cat: cat, ic: ic, z: z, de: de, r: r, cfg: cfg || [] }; }
  var OLD = {
    today: ['prod', 'calendar', 'w', T('مبيعات وإنتاج وطلبات اليوم مع المقارنة بالأمس', 'Ventes, production et commandes du jour', 'Today sales, production and orders')],
    quick: ['sc', 'menu', 'w', T('اختصارات سريعة لأكثر العمليات استعمالاً', 'Accès rapide', 'Quick access to common actions')],
    perf: ['prod', 'bars', 'w', T('اتجاه المبيعات والهدف', 'Tendance et objectif', 'Trend and target')],
    lines: ['mach', 'factory', 'w', T('خطوط الإنتاج وحالتها', 'Lignes de production', 'Production lines status')],
    kpis: ['fin', 'wallet', 'w', T('مؤشرات المبيعات والمصاريف والربح', 'Indicateurs clés', 'Sales, expenses and profit KPIs')],
    alerts: ['qual', 'alert', 'w', T('تنبيهات المخزون والديون', 'Alertes stock et dettes', 'Stock and debt alerts')],
    chart: ['sales', 'bars', 'w', T('رسم المبيعات الأسبوعي', 'Courbe des ventes', 'Weekly sales chart')],
    products: ['stock', 'box', 'w', T('مخزون المنتجات الجاهزة', 'Stock produits finis', 'Finished goods stock')],
    recent: ['sales', 'list', 'w', T('آخر العمليات', 'Dernières opérations', 'Latest transactions')],
    qadd: ['sc', 'plus', 's', T('إضافة سريعة', 'Ajout rapide', 'Quick add')],
    debts: ['sales', 'wallet', 's', T('ديون العملاء والموردين', 'Dettes clients/fournisseurs', 'Customer and supplier debts')],
    collected: ['sales', 'download', 's', T('المحصَّل اليوم', 'Encaissé aujourd\'hui', 'Collected today')],
    expenses: ['fin', 'wallet', 's', T('مصاريف الشهر مقارنة بالسابق', 'Dépenses du mois', 'Month expenses vs previous')],
    profit: ['fin', 'bars', 's', T('الربح التشغيلي للشهر', 'Bénéfice du mois', 'Operating profit')],
    rawstock: ['stock', 'scale', 's', T('مخزون المواد الخام', 'Stock matières premières', 'Raw material stock')],
    lowstock: ['stock', 'alert', 's', T('المواد والمنتجات التي قاربت على النفاد', 'Stock bas', 'Items running low')],
    orders: ['sales', 'note', 'w', T('الطلبات قيد الانتظار', 'Commandes en attente', 'Pending orders')],
    workers: ['team', 'users', 's', T('عدد العمال الحاضرين اليوم', 'Ouvriers présents', 'Workers present today')],
    shiftnow: ['team', 'clock', 's', T('الشفت الحالي وفريقه', 'Poste actuel', 'Current shift and team')],
    topdebt: ['sales', 'user', 'w', T('أكبر المدينين', 'Plus gros débiteurs', 'Top debtors')],
    topprod: ['sales', 'tag', 'w', T('أكثر المنتجات مبيعًا', 'Produits les plus vendus', 'Best-selling products')],
    backup: ['qual', 'save', 's', T('حالة النسخ الاحتياطي', 'État de la sauvegarde', 'Backup status')],
    insightsw: ['fin', 'bulb', 'w', T('ملاحظات ذكية من بياناتك', 'Analyses', 'Smart insights')],
    ageing: ['sales', 'clock', 's', T('أعمار الديون', 'Ancienneté des dettes', 'Debt ageing')],
    followw: ['sales', 'phone', 'w', T('متابعات العملاء', 'Suivi clients', 'Customer follow-ups')],
    healthw: ['fin', 'check', 's', T('صحة النشاط المالية', 'Santé financière', 'Business health')],
    tgtw: ['prod', 'bars', 's', T('نسبة تحقيق هدف الإنتاج', 'Objectif de production', 'Production target')],
    dayperf: ['prod', 'bars', 's', T('أداء الإنتاج خلال الأسبوع', 'Performance du jour', 'Production performance')],
    machst: ['mach', 'factory', 's', T('حالة الخطوط والآلات', 'État des machines', 'Machine status')],
    rawtot: ['stock', 'scale', 's', T('مخزون المواد الخام بالطن', 'Matières premières (t)', 'Raw materials (tons)')],
    prodrank: ['prod', 'tag', 's', T('ترتيب المنتجات إنتاجًا', 'Classement production', 'Production ranking')],
    ordstat: ['sales', 'note', 's', T('حالة الطلبات', 'État des commandes', 'Orders status')],
    sales30: ['sales', 'bars', 's', T('مبيعات آخر 30 يومًا', 'Ventes 30 jours', 'Sales last 30 days')],
    alertsw: ['qual', 'alert', 's', T('تنبيهات مهمة', 'Alertes', 'Important alerts')],
    qualw: ['qual', 'check', 's', T('نسبة جودة الإنتاج', 'Taux de qualité', 'Quality rate')],
    bestcust: ['sales', 'user', 's', T('أفضل العملاء', 'Meilleurs clients', 'Best customers')]
  };
  Object.keys(OLD).forEach(function (k) {
    if (!HOME[k]) return; var o = OLD[k];
    reg(k, o[0], o[1], o[2], o[3], function (d, z) { return HOME[k](d, z); });
  });
  function lbl(k) { if (k.indexOf('sc:') === 0) { try { return t(DX.LBL[k.slice(3)]); } catch (e) { return k; } } if (REG[k] && REG[k].ti) return REG[k].ti; try { return DX.wLabel(k); } catch (e) { return k; } }
  function regOf(k) {
    if (REG[k]) return REG[k];
    if (k.indexOf('sc:') === 0 && DX.CAT.indexOf(k.slice(3)) >= 0) return { k: k, cat: 'sc', ic: DX.iconOf(k.slice(3)), z: 'xs', de: T('اختصار إلى الصفحة', 'Raccourci', 'Shortcut'), cfg: [] };
    return null;
  }

  /* ---- shared helpers for the new widgets ---- */
  var W2 = DX.w2;
  function dgo(act) { return act; }
  function card(color, icon, title, body, route) { return '<div class="w2 dw tap" style="--wc:' + color + '" data-act="dgo" data-id="' + route + '" role="button"><div class="w2h"><h3>' + esc(title) + '</h3><span class="w2i">' + V.icon(icon, 18) + '</span></div>' + body + '</div>'; }
  function big(v, u) { return '<div class="dbig">' + v + (u ? ' <small>' + esc(u) + '</small>' : '') + '</div>'; }
  function bars(vals, color, labels) {
    var mx = Math.max.apply(null, vals.concat([1]));
    return '<div class="dbars" dir="ltr">' + vals.map(function (v, i) { return '<i style="height:' + Math.max(4, Math.round(v * 100 / mx)) + '%;background:' + color + '" title="' + (labels ? esc(labels[i]) : '') + '"></i>'; }).join('') + '</div>';
  }
  function hbar(p, color) { return '<div class="dhb"><i style="width:' + clamp(p, 0, 100) + '%;background:' + color + '"></i></div>'; }
  function chg(a, b) { if (!b) return ''; var d = Math.round((a - b) * 1000 / Math.abs(b)) / 10; return '<span class="ds-dl ' + (d >= 0 ? 'up' : 'dn') + '">' + (d >= 0 ? '↑' : '↓') + ' ' + B((d >= 0 ? '+' : '') + d + '%') + '</span>'; }
  function day(o) { return K.addDays(K.today(), o); }
  function range(per) {
    var td = K.today();
    if (per === 'week') return { from: day(-6), to: td, pf: day(-13), pt: day(-7) };
    if (per === 'month') { var ym = td.slice(0, 7), r = K.monthRange(ym), pr = K.monthRange(K.addMonths(ym, -1)); return { from: r.from, to: r.to, pf: pr.from, pt: pr.to }; }
    if (per === 'year') { var y = td.slice(0, 4); return { from: y + '-01-01', to: y + '-12-31', pf: (y - 1) + '-01-01', pt: (y - 1) + '-12-31' }; }
    return { from: td, to: td, pf: day(-1), pt: day(-1) };
  }
  function perName(p) { return { today: T('اليوم', 'Aujourd\'hui', 'Today'), day: T('اليوم', 'Aujourd\'hui', 'Today'), week: T('الأسبوع', 'Semaine', 'Week'), month: T('الشهر', 'Mois', 'Month'), year: T('السنة', 'Année', 'Year') }[p] || p; }
  var PER = [['today', perName('today')], ['week', perName('week')], ['month', perName('month')]];
  function inR(x, a, b) { return x.date >= a && x.date <= b; }
  function prodOpts() { return [['all', T('كل المنتجات', 'Tous', 'All products')]].concat(U.act(U.D.products).map(function (p) { return [p.id, p.name]; })); }
  function prodName(id) { var p = U.D.products.filter(function (x) { return x.id === id; })[0]; return p ? p.name : ''; }
  function pcsT() { return T('صندوق', 'caisses', 'crates'); }

  /* ---- production (configurable: period / product / shift) ---- */
  reg('prodx', 'prod', 'factory', 's', T('إنتاج الفترة مع اختيار المنتج والشفت', 'Production avec filtres', 'Production with period/product/shift filters'), function (d, z, o) {
    o = o || {}; var per = o.per || 'today', R = range(per === 'today' ? 'day' : per), pid = o.prod || 'all', sh = o.shift || '0';
    function sel(a, b) { return K.live(U.D.production).filter(function (x) { return inR(x, a, b) && (pid === 'all' || x.productId === pid) && (sh === '0' || String(x.shift) === sh); }); }
    var cur = sel(R.from, R.to), prev = sel(R.pf, R.pt), g = cur.reduce(function (a, x) { return a + (x.good || 0); }, 0), df = cur.reduce(function (a, x) { return a + (x.defective || 0); }, 0), pg = prev.reduce(function (a, x) { return a + (x.good || 0); }, 0);
    if (!cur.length && !prev.length) return card('#1E6FE8', 'factory', T('الإنتاج', 'Production', 'Production') + ' · ' + perName(per), noData(), 'production');
    var sub = (pid !== 'all' ? esc(prodName(pid)) + ' · ' : '') + (sh !== '0' ? T('الشفت ', 'Poste ', 'Shift ') + sh : T('كل الورديات', 'Tous postes', 'All shifts'));
    var body = big(B(K.groupInt(g)), pcsT()) + '<div class="dsub">' + sub + '</div><div class="drow">' + chg(g, pg) + '<span class="dtag r">' + T('مرفوض', 'Rebut', 'Rejected') + ' ' + B(K.groupInt(df)) + '</span></div>';
    if (z !== 's') { var v = [], i; for (i = 6; i >= 0; i--) { var dd = day(-i); v.push(sel(dd, dd).reduce(function (a, x) { return a + (x.good || 0); }, 0)); } body += bars(v, '#1E6FE8'); }
    return card('#1E6FE8', 'factory', T('الإنتاج', 'Production', 'Production') + ' · ' + perName(per), body, 'production');
  }, [{ n: 'per', l: T('الفترة', 'Période', 'Period'), o: PER, d: 'today' }, { n: 'prod', l: T('المنتج', 'Produit', 'Product'), o: 'prod', d: 'all' }, { n: 'shift', l: T('الشفت', 'Poste', 'Shift'), o: [['0', T('كل الورديات', 'Tous', 'All')], ['1', '1'], ['2', '2'], ['3', '3']], d: '0' }]);
  REG.prodx.ti = T('إنتاج (قابل للتصفية)', 'Production (filtres)', 'Production (filters)');

  reg('shiftprod', 'team', 'clock', 's', T('إنتاج كل وردية اليوم', 'Production par poste', 'Production per shift today'), function (d, z) {
    var td = K.today(), v = [1, 2, 3].map(function (n) { return K.live(U.D.production).filter(function (x) { return x.date === td && String(x.shift) === String(n); }).reduce(function (a, x) { return a + (x.good || 0); }, 0); });
    if (!v[0] && !v[1] && !v[2]) return card('#12907F', 'clock', T('إنتاج الورديات', 'Production/poste', 'Production by shift'), noData(), 'production');
    var mx = Math.max.apply(null, v);
    return card('#12907F', 'clock', T('إنتاج الورديات', 'Production/poste', 'Production by shift'), v.map(function (x, i) { return '<div class="drw"><span>' + T('الشفت ', 'Poste ', 'Shift ') + (i + 1) + '</span>' + hbar(mx ? x * 100 / mx : 0, '#12907F') + B(K.groupInt(x)) + '</div>'; }).join(''), 'production');
  });
  reg('rejected', 'qual', 'alert', 's', T('الصناديق المرفوضة ونسبة العيوب', 'Rebuts et taux de défauts', 'Rejected crates and defect rate'), function (d, z) {
    var td = K.today(), mr = K.monthRange(td.slice(0, 7)), P = K.live(U.D.production), sum = function (a, b, f) { return P.filter(function (x) { return inR(x, a, b); }).reduce(function (s, x) { return s + (x[f] || 0); }, 0); };
    var dd = sum(td, td, 'defective'), md = sum(mr.from, mr.to, 'defective'), mg = sum(mr.from, mr.to, 'good');
    if (!P.length) return card('#E5384C', 'alert', T('المرفوض', 'Rebuts', 'Rejected'), noData(), 'production');
    var rate = mg + md ? Math.round(md * 1000 / (mg + md)) / 10 : 0;
    return card('#E5384C', 'alert', T('المرفوض', 'Rebuts', 'Rejected'), big(B(K.groupInt(dd)), T('اليوم', 'aujourd\'hui', 'today')) + '<div class="dsub">' + T('الشهر', 'Mois', 'Month') + ': ' + B(K.groupInt(md)) + '</div><div class="drow"><span class="dtag r">' + T('نسبة العيوب', 'Défauts', 'Defects') + ' ' + B(rate + '%') + '</span></div>', 'production');
  });

  /* ---- sales (period selectable) ---- */
  reg('salesx', 'sales', 'cart', 's', T('المبيعات: يوم / أسبوع / شهر / سنة', 'Ventes par période', 'Sales by period'), function (d, z, o) {
    o = o || {}; var per = o.per || 'month', R = range(per), S0 = K.live(U.D.sales), f = function (a, b) { return S0.filter(function (x) { return inR(x, a, b); }); };
    var cur = f(R.from, R.to), prev = f(R.pf, R.pt), tot = cur.reduce(function (a, x) { return a + x.total; }, 0), ptot = prev.reduce(function (a, x) { return a + x.total; }, 0);
    if (!S0.length) return card('#12907F', 'cart', T('المبيعات', 'Ventes', 'Sales') + ' · ' + perName(per), noData(), 'sales');
    var body = big(U.money(tot)) + '<div class="drow">' + chg(tot, ptot) + '<span class="dtag">' + B(cur.length) + ' ' + T('فاتورة', 'fact.', 'inv.') + '</span></div>';
    if (z !== 's') { var v = [], i, n = per === 'year' ? 12 : 7; for (i = n - 1; i >= 0; i--) { if (per === 'year') { var ym = K.addMonths(K.today().slice(0, 7), -i), mr = K.monthRange(ym); v.push(f(mr.from, mr.to).reduce(function (a, x) { return a + x.total; }, 0)); } else { var dd = day(-i); v.push(f(dd, dd).reduce(function (a, x) { return a + x.total; }, 0)); } } body += bars(v, '#12907F'); }
    return card('#12907F', 'cart', T('المبيعات', 'Ventes', 'Sales') + ' · ' + perName(per), body, 'sales');
  }, [{ n: 'per', l: T('الفترة', 'Période', 'Period'), o: [['day', perName('day')], ['week', perName('week')], ['month', perName('month')], ['year', perName('year')]], d: 'month' }]);
  REG.salesx.ti = T('المبيعات (قابلة للتصفية)', 'Ventes (période)', 'Sales (period)');

  /* ---- stock ---- */
  function stockOpts() { var D = U.D; return [['raw', T('كل المواد الخام', 'Toutes matières', 'All raw materials')]].concat(U.act(D.materials).map(function (m) { return ['m:' + m.id, m.name]; })).concat(U.act(D.products).map(function (p) { return ['p:' + p.id, p.name]; })); }
  reg('stockx', 'stock', 'scale', 's', T('مخزون مادة أو منتج محدد', 'Stock d\'une matière/produit', 'Stock of a chosen item'), function (d, z, o) {
    var D = U.D, it = (o && o.item) || 'raw', list = U.act(D.materials);
    if (it === 'raw') {
      if (!list.length) return card('#7B4FD0', 'scale', T('المواد الخام', 'Matières', 'Raw materials'), noData(), 'stock');
      var mx = Math.max.apply(null, list.map(function (m) { return m.stock; }).concat([1]));
      return card('#7B4FD0', 'scale', T('المواد الخام', 'Matières', 'Raw materials'), list.slice(0, z === 's' ? 3 : 6).map(function (m) { var low = m.minStock > 0 && m.stock <= m.minStock; return '<div class="drw"><span>' + esc(m.name) + '</span>' + hbar(m.stock * 100 / mx, low ? '#E5384C' : '#7B4FD0') + B(K.groupInt(Math.round(m.stock))) + '</div>'; }).join(''), 'stock');
    }
    var isP = it.indexOf('p:') === 0, id = it.slice(2), x = (isP ? D.products : D.materials).filter(function (y) { return y.id === id; })[0];
    if (!x) return card('#7B4FD0', 'scale', T('المخزون', 'Stock', 'Stock'), noData(), 'stock');
    var low = x.minStock > 0 && x.stock <= x.minStock, p = x.minStock > 0 ? Math.min(100, x.stock * 100 / (x.minStock * 2)) : 100;
    return card(low ? '#E5384C' : '#7B4FD0', 'scale', x.name, big(B(K.groupInt(Math.round(x.stock * 10) / 10)), isP ? pcsT() : T('كغ', 'kg', 'kg')) + hbar(p, low ? '#E5384C' : '#7B4FD0') + '<div class="dsub">' + (x.minStock > 0 ? T('الحد الأدنى', 'Minimum', 'Minimum') + ': ' + B(K.groupInt(x.minStock)) : '') + (low ? ' · <b class="dred">' + T('قارب على النفاد', 'Bas', 'Low') + '</b>' : '') + '</div>', 'stock');
  }, [{ n: 'item', l: T('المادة / المنتج', 'Article', 'Item'), o: 'stock', d: 'raw' }]);
  REG.stockx.ti = T('مخزون (قابل للاختيار)', 'Stock (choix)', 'Stock (choose item)');
  reg('stfin', 'stock', 'box', 'w', T('المنتجات الجاهزة حسب النوع', 'Produits finis par type', 'Finished goods by type'), function (d, z) {
    var l = U.act(U.D.products); if (!l.length) return card('#1E6FE8', 'box', T('المنتجات الجاهزة', 'Produits finis', 'Finished goods'), noData(), 'stock');
    var mx = Math.max.apply(null, l.map(function (p) { return p.stock; }).concat([1]));
    return card('#1E6FE8', 'box', T('المنتجات الجاهزة', 'Produits finis', 'Finished goods'), l.slice(0, 6).map(function (p) { var low = p.minStock > 0 && p.stock <= p.minStock; return '<div class="drw"><span>' + esc(p.name) + '</span>' + hbar(p.stock * 100 / mx, low ? '#E5384C' : '#1E6FE8') + B(K.groupInt(p.stock)) + '</div>'; }).join(''), 'stock');
  });

  /* ---- machines monitor (settings.mon) ---- */
  function monMachines() { return U.act(U.D.machines); }
  function openStop(mid) { return (MM.MON().stops || []).filter(function (x) { return x.m === mid && x.to == null; })[0]; }
  reg('mmstatus', 'mach', 'machine', 's', T('الآلات العاملة والمتوقفة الآن', 'Machines en marche/arrêtées', 'Machines running / stopped now'), function (d, z) {
    var ms = monMachines(); if (!ms.length) return card('#2DB35A', 'machine', T('حالة الآلات', 'État machines', 'Machine status'), noData(), 'machmon');
    var st = ms.filter(function (m) { return openStop(m.id); }), run = ms.length - st.length;
    var body = '<div class="dtri"><div class="g"><b>' + B(run) + '</b><small>' + T('تعمل', 'Marche', 'Running') + '</small></div><div class="r"><b>' + B(st.length) + '</b><small>' + T('متوقفة', 'Arrêt', 'Stopped') + '</small></div></div>';
    if (z !== 's') body += ms.slice(0, 6).map(function (m) { var o = openStop(m.id); return '<div class="drw"><span>' + esc(m.name) + '</span><i class="ddot ' + (o ? 'r' : 'g') + '"></i><small>' + (o ? T(o.kind === 'j' ? 'توقف مبرر' : 'توقف غير مبرر', 'Arrêt', 'Stopped') : T('تعمل', 'Marche', 'Running')) + '</small></div>'; }).join('');
    return card('#2DB35A', 'machine', T('حالة الآلات', 'État machines', 'Machine status'), body, 'machmon');
  });
  function shiftFigs() {
    var ms = monMachines(), n = MM.curShift(), now = Date.now(), A = 0, E = 0, run = 0, el = 0, cfgd = 0;
    ms.forEach(function (m) { var f = MM.figures(m.id, n, now); if (f.cf.cycle) { cfgd++; A += f.actual; E += f.exp; } run += f.run; el += f.c.el; });
    return { A: A, E: E, run: run, el: el, cfgd: cfgd, n: n, count: ms.length };
  }
  reg('mmprod', 'mach', 'bars', 's', T('الإنتاج الفعلي مقابل المتوقع للشفت الحالي', 'Réel vs attendu (poste actuel)', 'Actual vs expected (current shift)'), function (d, z) {
    var f = shiftFigs(), ttl = T('الفعلي / المتوقع', 'Réel / attendu', 'Actual / expected');
    if (!f.cfgd) return card('#1E6FE8', 'bars', ttl, '<div class="muted dnd">' + T('حدّد زمن الصندوق للآلات في صفحة المراقبة', 'Définissez le temps par caisse', 'Set the time per crate in the monitor page') + '</div>', 'machmon');
    var p = f.E ? Math.round(f.A * 1000 / f.E) / 10 : 0;
    return card('#1E6FE8', 'bars', ttl, DX.donut([{ v: Math.min(f.A, f.E) || 0, color: '#2DB35A' }, { v: Math.max(0, f.E - f.A), color: '#E5384C' }], B(p + '%'), 78) + '<div class="dsub">' + B(K.groupInt(f.A)) + ' / ' + B(K.groupInt(f.E)) + ' · ' + T('الشفت ', 'Poste ', 'Shift ') + f.n + '</div>', 'machmon');
  });
  reg('mmavail', 'mach', 'clock', 's', T('نسبة التشغيل الفعلي للآلات في الشفت', 'Disponibilité des machines', 'Machine availability this shift'), function (d, z) {
    var f = shiftFigs(), ttl = T('جاهزية الآلات', 'Disponibilité', 'Availability');
    if (!f.count || !f.el) return card('#12907F', 'clock', ttl, noData(), 'machmon');
    var p = Math.round(f.run * 1000 / f.el) / 10;
    return card(p >= 90 ? '#2DB35A' : p >= 70 ? '#F59E2C' : '#E5384C', 'clock', ttl, big(B(p + '%')) + hbar(p, p >= 90 ? '#2DB35A' : p >= 70 ? '#F59E2C' : '#E5384C') + '<div class="dsub">' + T('وقت التشغيل ', 'Marche ', 'Run ') + B(p2(Math.floor(f.run / 3600)) + ':' + p2(Math.floor(f.run % 3600 / 60))) + '</div>', 'machmon');
  });
  reg('mmstops', 'mach', 'alert', 'w', T('آخر توقفات الآلات اليوم', 'Derniers arrêts', 'Latest machine stops today'), function (d, z) {
    var ms = monMachines(), st = new Date(); st.setHours(0, 0, 0, 0);
    var l = (MM.MON().stops || []).filter(function (x) { return x.from >= st.getTime() && ms.some(function (m) { return m.id === x.m; }); }).sort(function (a, b) { return b.from - a.from; }).slice(0, 5);
    if (!l.length) return card('#E5384C', 'alert', T('سجل التوقفات', 'Journal des arrêts', 'Stop log'), '<div class="muted dnd">' + T('لا توجد توقفات اليوم', 'Aucun arrêt aujourd\'hui', 'No stops today') + '</div>', 'machmon');
    return card('#E5384C', 'alert', T('سجل التوقفات', 'Journal des arrêts', 'Stop log'), l.map(function (x) { var m = ms.filter(function (y) { return y.id === x.m; })[0], mins = Math.round(((x.to == null ? Date.now() : x.to) - x.from) / 60000); return '<div class="drw"><span>' + esc(m ? m.name : '') + (x.reason ? ' · ' + esc(x.reason) : '') + '</span><i class="ddot ' + (x.kind === 'j' ? 'y' : 'r') + '"></i><small>' + B(mins + ' ' + T('د', 'min', 'min')) + '</small></div>'; }).join(''), 'machmon');
  });

  /* ---- distribution (settings.dist) ---- */
  function DS() { return U.D.settings.dist || { trucks: [], trips: [] }; }
  function trucksOf() { return DS().trucks.filter(function (x) { return !x.archived; }); }
  function tState(tk) { if (tk.state === 'maint' || tk.state === 'stopped') return tk.state; return DS().trips.some(function (x) { return x.truckId === tk.id && x.status === 'go'; }) ? 'go' : 'ready'; }
  reg('dsstatus', 'dist', 'truck', 's', T('الشاحنات: جاهزة / قيد التوزيع / متوقفة / صيانة', 'Camions par état', 'Trucks by status'), function (d, z) {
    var tk = trucksOf(), ttl = T('الشاحنات', 'Camions', 'Trucks'); if (!tk.length) return card('#12907F', 'truck', ttl, noData(), 'distribution');
    var c = { ready: 0, go: 0, stopped: 0, maint: 0 }; tk.forEach(function (x) { c[tState(x)]++; });
    return card('#12907F', 'truck', ttl, '<div class="dtri q"><div class="g"><b>' + B(c.ready) + '</b><small>' + T('جاهزة', 'Prêts', 'Ready') + '</small></div><div class="b"><b>' + B(c.go) + '</b><small>' + T('توزيع', 'En route', 'On route') + '</small></div><div class="o"><b>' + B(c.stopped) + '</b><small>' + T('متوقفة', 'Arrêt', 'Stopped') + '</small></div><div class="r"><b>' + B(c.maint) + '</b><small>' + T('صيانة', 'Maint.', 'Maint.') + '</small></div></div>', 'distribution');
  });
  reg('dseff', 'dist', 'truck', 's', T('كفاءة التوزيع اليوم', 'Efficacité de distribution', 'Distribution efficiency today'), function (d, z) {
    var l = DS().trips.filter(function (x) { return x.date === K.today(); }), ttl = T('كفاءة التوزيع', 'Efficacité', 'Efficiency'); if (!l.length) return card('#2DB35A', 'truck', ttl, noData(), 'distribution');
    var done = l.filter(function (x) { return x.status === 'done'; }).length, p = Math.round(done * 100 / l.length);
    return card('#2DB35A', 'truck', ttl, DX.donut([{ v: done, color: '#2DB35A' }, { v: l.length - done, color: '#cfd8e6' }], B(p + '%'), 78) + '<div class="dsub">' + B(done) + ' / ' + B(l.length) + ' ' + T('رحلة', 'trajets', 'trips') + '</div>', 'distribution');
  });
  reg('dsrecent', 'dist', 'list', 'w', T('آخر عمليات التسليم والرحلات', 'Derniers trajets', 'Latest trips'), function (d, z) {
    var l = DS().trips.slice().sort(function (a, b) { return (b.t || 0) - (a.t || 0); }).slice(0, 4), ttl = T('آخر عمليات التوزيع', 'Derniers trajets', 'Latest trips'); if (!l.length) return card('#12907F', 'list', ttl, noData(), 'distribution');
    var nm = { plan: T('مبرمجة', 'Prévu', 'Planned'), go: T('جاري', 'En cours', 'Ongoing'), done: T('تم التسليم', 'Livré', 'Delivered'), late: T('مؤجلة', 'Reporté', 'Postponed') };
    return card('#12907F', 'list', ttl, l.map(function (x) { return '<div class="drw"><span>' + esc(x.dest || '—') + '</span><i class="ddot ' + (x.status === 'done' ? 'g' : x.status === 'late' ? 'r' : x.status === 'go' ? 'b' : 'y') + '"></i><small>' + nm[x.status] + '</small></div>'; }).join(''), 'distribution');
  });
  reg('dskm', 'dist', 'truck', 's', T('المسافة وتكلفة الوقود اليوم', 'Distance et carburant', 'Distance and fuel today'), function (d, z) {
    var l = DS().trips.filter(function (x) { return x.date === K.today() && (x.status === 'done' || x.status === 'go'); }), ttl = T('المسافة والوقود', 'Distance/carburant', 'Distance & fuel'); if (!DS().trips.length) return card('#F59E2C', 'truck', ttl, noData(), 'distribution');
    var km = l.reduce(function (a, x) { return a + (x.km || 0); }, 0), fu = l.filter(function (x) { return x.status === 'done'; }).reduce(function (a, x) { return a + (x.fuel || 0); }, 0);
    return card('#F59E2C', 'truck', ttl, big(B(K.groupInt(km)), T('كم', 'km', 'km')) + '<div class="dsub">' + T('الوقود', 'Carburant', 'Fuel') + ': ' + U.money(fu) + '</div>', 'distribution');
  });

  /* ---- team / finance ---- */
  reg('attend', 'team', 'users', 's', T('الحاضرون والغائبون في الشفت الحالي', 'Présents / absents', 'Present / absent this shift'), function (d, z) {
    var n = MM.curShift(), r = K.rosterFor(U.D, K.today(), n), ttl = T('الحضور', 'Présence', 'Attendance'); if (!r.length) return card('#1E6FE8', 'users', ttl, noData(), 'shifts');
    var w = r.filter(function (a) { return a.worked; }).length;
    return card('#1E6FE8', 'users', ttl, '<div class="dtri"><div class="g"><b>' + B(w) + '</b><small>' + T('حاضر', 'Présents', 'Present') + '</small></div><div class="r"><b>' + B(r.length - w) + '</b><small>' + T('غائب', 'Absents', 'Absent') + '</small></div></div><div class="dsub">' + T('الشفت ', 'Poste ', 'Shift ') + n + '</div>', 'shifts');
  });
  reg('flow', 'fin', 'wallet', 'w', T('الإيرادات والمصاريف وصافي الربح للشهر', 'Revenus / dépenses / bénéfice', 'Revenue, expenses and net profit'), function (d, z) {
    var m = K.monthlyReport(U.D, K.today().slice(0, 7)), ttl = T('الإيرادات والمصاريف', 'Revenus et dépenses', 'Revenue & expenses'); if (!m.sales && !m.expenses) return card('#12907F', 'wallet', ttl, noData(), 'reports');
    var mx = Math.max(m.sales, m.expenses, Math.abs(m.operatingProfit), 1);
    function r(l, v, c) { return '<div class="drw"><span>' + l + '</span>' + hbar(Math.abs(v) * 100 / mx, c) + '<small>' + U.money(v) + '</small></div>'; }
    return card('#12907F', 'wallet', ttl, r(T('الإيرادات', 'Revenus', 'Revenue'), m.sales, '#2DB35A') + r(T('المصاريف', 'Dépenses', 'Expenses'), m.expenses, '#E5384C') + r(T('الصافي', 'Net', 'Net'), m.operatingProfit, m.operatingProfit >= 0 ? '#1E6FE8' : '#E5384C'), 'reports');
  });
  X.dgo = function (el) { var r = el.dataset.id; if (r === 'sales' || r === 'stock' || r === 'production') { X.wgo({ dataset: { id: r } }); return; } U.go(r); };
  REG.flow.ti = T('الإيرادات والمصاريف', 'Revenus et dépenses', 'Revenue & expenses');
  ['prodx', 'shiftprod', 'rejected', 'salesx', 'stockx', 'stfin', 'mmstatus', 'mmprod', 'mmavail', 'mmstops', 'dsstatus', 'dseff', 'dsrecent', 'dskm', 'attend', 'flow'].forEach(function (k) {
    var R = REG[k]; if (!R.ti) R.ti = { shiftprod: T('إنتاج الورديات', 'Production/poste', 'Production by shift'), rejected: T('المرفوض ونسبة العيوب', 'Rebuts', 'Rejected & defects'), stfin: T('المنتجات الجاهزة', 'Produits finis', 'Finished goods'), mmstatus: T('حالة الآلات الآن', 'État machines', 'Machines now'), mmprod: T('الفعلي مقابل المتوقع', 'Réel vs attendu', 'Actual vs expected'), mmavail: T('جاهزية الآلات', 'Disponibilité', 'Availability'), mmstops: T('سجل التوقفات', 'Journal des arrêts', 'Stop log'), dsstatus: T('حالة الشاحنات', 'Camions', 'Trucks'), dseff: T('كفاءة التوزيع', 'Efficacité', 'Efficiency'), dsrecent: T('آخر الرحلات', 'Derniers trajets', 'Latest trips'), dskm: T('المسافة والوقود', 'Distance/carburant', 'Distance & fuel'), attend: T('الحضور والغياب', 'Présence', 'Attendance') }[k]; });

  /* ---------------- layouts & persistence ---------------- */
  var MINW = { today: 1, quick: 1, kpis: 1, qadd: 1, debts: 1 };
  function allowedSizes(k) { if (k.indexOf('sc:') === 0) return SZO.slice(); if (MINW[k]) return ['w', 'l']; return ['s', 'm', 'w', 'l']; }
  function fit(k, z) { var a = allowedSizes(k); return a.indexOf(z) >= 0 ? z : a[0]; }
  function sizeOf(it) { return fit(it.k, SZN[it.z] ? it.z : (regOf(it.k) || { z: 's' }).z); }
  function mk(list) { return list.map(function (s) { var p = s.split(':'), k = p[0] === 'sc' ? 'sc:' + p[1] : p[0], z = p[0] === 'sc' ? p[2] : p[1]; return { k: k, z: z }; }).filter(function (i) { return regOf(i.k); }); }
  var TPL = {
    manager: { n: T('تخطيط المدير', 'Directeur', 'Manager'), l: ['today:w', 'tgtw:s', 'mmprod:s', 'dayperf:s', 'mmstatus:s', 'dsstatus:s', 'dseff:s', 'rawtot:s', 'ordstat:s', 'sales30:s', 'alertsw:s', 'qualw:s'] },
    production: { n: T('تخطيط الإنتاج', 'Production', 'Production'), l: ['mmprod:s', 'prodx:s', 'mmstatus:s', 'mmavail:s', 'mmstops:w', 'shiftprod:s', 'rejected:s', 'tgtw:s', 'prodrank:s'] },
    inventory: { n: T('تخطيط المخزون', 'Stock', 'Inventory'), l: ['rawtot:s', 'lowstock:s', 'stockx:s', 'rawstock:s', 'stfin:w', 'products:w', 'alertsw:s'] },
    sales: { n: T('تخطيط المبيعات', 'Ventes', 'Sales'), l: ['today:w', 'salesx:s', 'sales30:s', 'ordstat:s', 'collected:s', 'topprod:w', 'bestcust:s', 'debts:s', 'orders:w'] },
    accounting: { n: T('تخطيط المحاسبة', 'Comptabilité', 'Accounting'), l: ['kpis:w', 'flow:w', 'profit:s', 'expenses:s', 'debts:s', 'collected:s', 'ageing:s', 'healthw:s'] }
  };
  function uid() { return 'ly' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36); }
  function fromOld() {
    var items = [], L = DX.L();
    DX.wOrdered().forEach(function (k) {
      if (DX.wHidden(k)) return; var sc = k.indexOf('sc:') === 0; if (!regOf(k)) return; var z = DX.wSize(k);
      var it = { k: k, z: sc ? { s: 'xs', m: 's', l: 'm' }[z] || 'xs' : { s: 's', m: 'w', l: 'l' }[z] || 's' };
      if (L.colors[k]) it.c = L.colors[k]; if (L.titles[k]) it.t = L.titles[k]; items.push(it);
    });
    return items;
  }
  function ensure() {
    var st = U.D.settings; if (st.dash && st.dash.layouts && st.dash.layouts.length) return st.dash;
    var items = fromOld(); if (!items.length) items = mk(TPL.manager.l);
    var ds = { v: 1, active: 'main', layouts: [{ id: 'main', name: T('تخطيط المدير', 'Directeur', 'Manager'), items: items }] };
    try { U.commit(function (d) { d.settings.dash = ds; }); } catch (e) { st.dash = ds; }
    return U.D.settings.dash || ds;
  }
  function active() { var ds = ensure(); return ds.layouts.filter(function (l) { return l.id === ds.active; })[0] || ds.layouts[0]; }
  function mutate(fn, noUndo) {
    var ds = ensure(); if (!noUndo) { S.dundo = (S.dundo || []).slice(-24); S.dundo.push(JSON.stringify(ds)); }
    U.commit(function (d) { var x = d.settings.dash, l = x.layouts.filter(function (y) { return y.id === x.active; })[0] || x.layouts[0]; fn(l, x); });
  }
  function itemOf(k) { return active().items.filter(function (i) { return i.k === k; })[0]; }
  U.migrateLayout6 = function () { try { ensure(); } catch (e) { } };

  /* ---------------- rendering ---------------- */
  function cfgOf(it) { return it.o || {}; }
  function cardHtml(it, d, ed) {
    var R = regOf(it.k); if (!R) return '';
    var z = sizeOf(it), sc = it.k.indexOf('sc:') === 0, inner = '';
    try { inner = sc ? DX.scWidget(it.k.slice(3), SCZ[z], d) : R.r(d, rz(z), cfgOf(it)); } catch (e) { inner = '<div class="panel muted">' + esc(lbl(it.k)) + '<br><small>' + T('تعذّر عرض البطاقة', 'Erreur', 'Card error') + '</small></div>'; }
    if (!inner) { if (!ed) return ''; inner = '<div class="panel wempty">' + esc(lbl(it.k)) + '<br><small>' + T('لا توجد بيانات', 'Aucune donnée', 'No data') + '</small></div>'; }
    if (it.t && !sc) inner = inner.replace(/(<h3>(?:<span[^>]*>[\s\S]*?<\/span>)?)([^<]*)(<\/h3>)/, function (m, a, b, c) { return a + esc(it.t) + c; }).replace(/(<span class="swl">)([^<]*)(<\/span>)/, function (m, a, b, c) { return a + esc(it.t) + c; });
    var st = it.c ? ' style="--acc:' + it.c + ';--acc2:' + it.c + '22;--wc:' + it.c + '"' : '';
    var sel = ed && S.dsel === it.k;
    return '<div class="dc dz-' + z + ' sz-' + rz(z) + (it.c ? ' acc' : '') + (it.h ? ' hid' : '') + (sel ? ' sel' : '') + '" data-k="' + esc(it.k) + '"' + st + (ed ? ' data-act="dc_sel"' : '') + '><div class="dc-in">' + inner + '</div>' +
      (ed ? '<button class="dc-x" data-act="dc_del" data-k="' + esc(it.k) + '" aria-label="' + T('حذف', 'Supprimer', 'Remove') + '">' + V.icon('x', 14) + '</button><span class="dc-dh" data-dh="1" aria-label="drag">' + V.icon('move', 16) + '</span><span class="dc-rh" data-rh="1" aria-label="resize">' + V.icon('resize', 14) + '</span>' + (it.h ? '<span class="dc-hid">' + T('مخفية', 'Masqué', 'Hidden') + '</span>' : '') : '') + '</div>';
  }
  function layoutChips(ed) {
    var ds = ensure(); if (ds.layouts.length < 2 && !ed) return '';
    return '<div class="dl-chips">' + ds.layouts.map(function (l) { return '<button class="dl-c' + (l.id === ds.active ? ' on' : '') + '" data-act="dm_use" data-id="' + l.id + '">' + esc(l.name) + '</button>'; }).join('') + (ed ? '<button class="dl-c add" data-act="go_dashmgr">' + V.icon('settings', 14) + ' ' + T('إدارة', 'Gérer', 'Manage') + '</button>' : '') + '</div>';
  }
  function editTop() {
    var un = (S.dundo || []).length;
    return '<div class="de-top"><h2>' + T('تخصيص الصفحة الرئيسية', 'Personnaliser l\'accueil', 'Customize home') + '</h2><p class="muted">' + T('اسحب المقبض لإعادة الترتيب • اضغط البطاقة لتحديدها • كل تعديل يُحفظ تلقائيًا', 'Glissez pour réorganiser • tout est enregistré automatiquement', 'Drag the handle to reorder • every change is saved automatically') + '</p>' +
      '<div class="de-btns"><button class="btn primary" data-act="dash_done">' + V.icon('check', 18) + ' ' + T('حفظ', 'Enregistrer', 'Save') + '</button><button class="btn" data-act="dash_prev">' + V.icon('eye', 18) + ' ' + T('معاينة', 'Aperçu', 'Preview') + '</button>' +
      '<button class="btn"' + (un ? '' : ' disabled') + ' data-act="dash_undo">' + V.icon('undo', 18) + ' ' + T('تراجع', 'Annuler', 'Undo') + '</button><button class="btn" data-act="dash_reset">' + V.icon('sliders', 18) + ' ' + T('إعادة ضبط', 'Réinit.', 'Reset') + '</button></div>' + layoutChips(true) + '</div>';
  }
  function dockHtml() {
    var has = !!S.dsel, dis = has ? '' : ' off';
    function b(a, ic, l, c) { return '<button class="dk-b' + (c || '') + '" data-act="' + a + '">' + V.icon(ic, 20) + '<span>' + l + '</span></button>'; }
    return '<div class="wd-dock dk5">' + b('dk_add', 'plus', T('إضافة', 'Ajouter', 'Add')) + b('dk_prev', rtl() ? 'chevR' : 'chevL', T('قبل', 'Avant', 'Earlier'), dis) + b('dk_next', rtl() ? 'chevL' : 'chevR', T('بعد', 'Après', 'Later'), dis) + b('dk_size', 'resize', T('الحجم', 'Taille', 'Size'), dis) + b('dk_cfg', 'settings', T('إعدادات', 'Réglages', 'Settings'), dis) + '</div>';
  }
  function homeView() {
    var D = U.D, d = K.dashboard(D, K.today()), h = '', ed = !!S.dEdit && !S.dPrev, lay = active();
    if (U.loadWarning) h += '<div class="alert red">' + t('warn_' + U.loadWarning) + '</div>';
    if (U.migratedNow) h += '<div class="alert blue">' + t('migrated_note') + '</div>';
    if (ed) h += editTop(); else h += DX.hero(false) + DX.searchResults(S.homeQ || '') + layoutChips(false);
    if (S.dPrev) h += '<button class="dprev-back" data-act="dash_prev">' + V.icon('edit', 16) + ' ' + T('العودة للتعديل', 'Retour à l\'édition', 'Back to editing') + '</button>';
    var cards = lay.items.filter(function (it) { return ed || !it.h; }).map(function (it) { return cardHtml(it, d, ed); }).join('');
    h += '<div class="dgrid' + (ed ? ' ed' : '') + '" id="dgrid">' + cards + '</div>';
    if (!cards) h += '<div class="card" style="text-align:center"><div class="muted" style="margin-bottom:10px">' + T('لا توجد بطاقات في هذا التخطيط', 'Aucune carte', 'No cards in this layout') + '</div><button class="btn primary" data-act="dk_add">+ ' + T('إضافة من المكتبة', 'Ajouter', 'Add from library') + '</button></div>';
    if (ed) h += dockHtml();
    return h;
  }
  W.home = function () {
    var real = K.today(); U.realToday = real; var d = S.homeDay;
    if (!d || d === real) { S.homeDay = null; return homeView(); }
    var o = K.today; K.today = function () { return d; };
    try { return homeView(); } finally { K.today = o; }
  };
  document.addEventListener('change', function (e) { var el = e.target; if (!el || el.id !== 'homeday') return; if (/^\d{4}-\d{2}-\d{2}$/.test(el.value)) { S.homeDay = el.value; U.render(true); } });
  X.home_today = function () { S.homeDay = null; U.render(true); };

  /* ---------------- edit actions ---------------- */
  function goHome() { U.stack = []; U.route = 'home'; U.arg = null; }
  X.dash_edit = X.wd_edit = X.wd_edit_go = function () { S.dEdit = true; S.dPrev = false; S.dsel = null; goHome(); U.render(); var m = U.$('#main'); if (m) m.scrollTop = 0; };
  X.dash_done = X.wd_done = function () { S.dEdit = false; S.dPrev = false; S.dsel = null; U.render(true); U.toast(T('تم حفظ التخصيص', 'Enregistré', 'Saved'), 'ok'); };
  X.dash_prev = function () { S.dPrev = !S.dPrev; U.render(true); };
  X.dash_undo = function () {
    var s = (S.dundo || []).pop(); if (!s) return; var o = JSON.parse(s);
    U.commit(function (d) { d.settings.dash = o; }); U.render(true);
  };
  X.dash_reset = function () {
    U.confirmBox(T('استعادة التخطيط الافتراضي', 'Rétablir', 'Restore default layout'), T('سيُستبدل ترتيب هذا التخطيط بالترتيب الافتراضي. يمكنك التراجع بعده.', 'La disposition sera remplacée. Vous pouvez annuler.', 'This layout will be replaced by the default arrangement. You can undo it.'), T('استعادة', 'Rétablir', 'Restore'), function () { mutate(function (l) { l.items = mk(TPL.manager.l); }); S.dsel = null; U.render(true); });
  };
  X.dc_sel = function (el) { if (S.lastDrag && Date.now() - S.lastDrag < 450) return; var k = el.dataset.k; S.dsel = S.dsel === k ? null : k; U.render(true); };
  X.dc_del = function (el) { var k = el.dataset.k; mutate(function (l) { l.items = l.items.filter(function (i) { return i.k !== k; }); }); if (S.dsel === k) S.dsel = null; U.render(true); U.toast(T('تم حذف البطاقة (يمكن التراجع)', 'Supprimée (annulable)', 'Removed (you can undo)'), 'ok'); };
  X.dk_add = function () { U.go('widgets'); };
  function needSel() { if (S.dsel) return false; U.toast(T('اضغط على بطاقة لتحديدها أولًا', 'Sélectionnez une carte', 'Tap a card to select it first'), 'bad'); return true; }
  function shift(dir) { if (needSel()) return; var k = S.dsel; mutate(function (l) { var a = l.items, i = a.map(function (x) { return x.k; }).indexOf(k), j = i + dir; if (i < 0 || j < 0 || j >= a.length) return; var x = a[i]; a[i] = a[j]; a[j] = x; }); U.render(true); }
  X.dk_prev = function () { shift(-1); }; X.dk_next = function () { shift(1); };
  X.dk_size = function () {
    if (needSel()) return; var it = itemOf(S.dsel); if (!it) return; var cur = sizeOf(it), sc = it.k.indexOf('sc:') === 0;
    U.showModal('<h3>' + T('حجم البطاقة', 'Taille', 'Card size') + '</h3><div class="dsz">' + allowedSizes(it.k).map(function (z) { var c = SZN[z]; return '<button class="dsz-b' + (z === cur ? ' on' : '') + '" data-act="dk_setsize" data-s="' + z + '"><span class="dsz-g" style="--c:' + c[0] + ';--r:' + c[1] + '"><i></i></span><b>' + szName(z) + '</b></button>'; }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">' + T('إغلاق', 'Fermer', 'Close') + '</button></div>');
  };
  X.dk_setsize = function (el) { var k = S.dsel, z = fit(k, el.dataset.s); mutate(function (l) { l.items.forEach(function (i) { if (i.k === k) i.z = z; }); }); U.closeModal(); U.render(true); };
  var COLORS = [['', T('افتراضي', 'Défaut', 'Default')], ['#1E6FE8', T('أزرق', 'Bleu', 'Blue')], ['#00A3C4', T('سماوي', 'Cyan', 'Cyan')], ['#2DB35A', T('أخضر', 'Vert', 'Green')], ['#F59E2C', T('برتقالي', 'Orange', 'Orange')], ['#E5384C', T('أحمر', 'Rouge', 'Red')], ['#7B4FD0', T('بنفسجي', 'Violet', 'Purple')], ['#1F2D49', T('كحلي', 'Marine', 'Navy')]];
  X.dk_cfg = function () {
    if (needSel()) return; var it = itemOf(S.dsel); if (!it) return; var R = regOf(it.k), o = cfgOf(it);
    var f = [{ name: 'title', label: T('عنوان البطاقة', 'Titre', 'Title'), type: 'text', optional: true, value: it.t || '' },
      { name: 'color', label: T('لون البطاقة', 'Couleur', 'Color'), type: 'select', value: it.c || '', options: COLORS.map(function (c) { return { v: c[0], l: c[1] }; }) },
      { name: 'size', label: T('الحجم', 'Taille', 'Size'), type: 'select', value: sizeOf(it), options: allowedSizes(it.k).map(function (z) { return { v: z, l: szName(z) }; }) }];
    (R.cfg || []).forEach(function (c) { var opts = c.o === 'prod' ? prodOpts() : c.o === 'stock' ? stockOpts() : c.o; f.push({ name: 'o_' + c.n, label: c.l, type: 'select', value: o[c.n] != null ? o[c.n] : c.d, options: opts.map(function (x) { return { v: x[0], l: x[1] }; }) }); });
    f.push({ name: 'hid', label: T('الحالة', 'État', 'State'), type: 'select', value: it.h ? '1' : '0', options: [{ v: '0', l: T('ظاهرة', 'Visible', 'Visible') }, { v: '1', l: T('مخفية (دون حذف)', 'Masquée', 'Hidden (kept)') }] });
    var k = it.k;
    U.openForm({
      title: lbl(k), submit: T('حفظ', 'Enregistrer', 'Save'), fields: f,
      onDelete: function () { X.dc_del({ dataset: { k: k } }); U.closeModal(); },
      onSubmit: function (v) {
        mutate(function (l) { l.items.forEach(function (i) { if (i.k !== k) return; i.t = (v.title || '').trim() || undefined; i.c = v.color || undefined; i.z = v.size; i.h = v.hid === '1' ? 1 : undefined; (R.cfg || []).forEach(function (c) { i.o = i.o || {}; i.o[c.n] = v['o_' + c.n]; }); }); });
        U.closeModal(); U.render(true);
      }
    });
  };

  /* ---------------- drag & drop (handle-based, so scrolling never conflicts) ---------------- */
  var main = function () { return document.getElementById('main'); };
  function flip(grid, card, fn) {
    var cs = [].slice.call(grid.children), first = cs.map(function (c) { return c.getBoundingClientRect(); }); fn();
    cs.forEach(function (c, i) {
      if (c === card) return; var l = c.getBoundingClientRect(), dx = first[i].left - l.left, dy = first[i].top - l.top; if (!dx && !dy) return;
      c.style.transition = 'none'; c.style.transform = 'translate(' + dx + 'px,' + dy + 'px)'; void c.offsetWidth; c.style.transition = 'transform .22s ease'; c.style.transform = '';
    });
  }
  function startDrag(e, card) {
    var grid = card.parentNode, r = card.getBoundingClientRect(), ox = e.clientX - r.left, oy = e.clientY - r.top, ghost = card.cloneNode(true), raf = 0, py = e.clientY;
    ghost.className += ' dc-ghost'; ghost.removeAttribute('data-act'); ghost.style.cssText = 'position:fixed;left:0;top:0;width:' + r.width + 'px;height:' + r.height + 'px;transform:translate(' + r.left + 'px,' + r.top + 'px);z-index:9999;pointer-events:none';
    document.body.appendChild(ghost); card.classList.add('dc-ph'); S.dragging = true;
    function loop() { var m = main(), y = py; if (m) { if (y < 140) m.scrollTop -= 14; else if (y > window.innerHeight - 170) m.scrollTop += 14; } raf = requestAnimationFrame(loop); }
    raf = requestAnimationFrame(loop);
    function mv(ev) {
      ev.preventDefault(); py = ev.clientY; ghost.style.transform = 'translate(' + (ev.clientX - ox) + 'px,' + (ev.clientY - oy) + 'px) scale(1.03)';
      var el = document.elementFromPoint(ev.clientX, ev.clientY), tg = el && el.closest ? el.closest('.dc') : null;
      if (!tg || tg === card || tg.parentNode !== grid) return;
      var b = tg.getBoundingClientRect(), cx = b.left + b.width / 2, cy = b.top + b.height / 2, before;
      if (Math.abs(ev.clientY - cy) < b.height * 0.35) before = rtl() ? ev.clientX > cx : ev.clientX < cx; else before = ev.clientY < cy;
      if (before && card.nextSibling === tg) return; if (!before && tg.nextSibling === card) return;
      flip(grid, card, function () { grid.insertBefore(card, before ? tg : tg.nextSibling); });
    }
    function up() {
      document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up); cancelAnimationFrame(raf);
      ghost.remove(); card.classList.remove('dc-ph'); S.dragging = false; S.lastDrag = Date.now();
      var keys = [].map.call(grid.children, function (c) { return c.dataset.k; });
      mutate(function (l) { var m = {}; l.items.forEach(function (i) { m[i.k] = i; }); l.items = keys.map(function (k) { return m[k]; }).filter(Boolean); });
      U.render(true);
    }
    document.addEventListener('pointermove', mv, { passive: false }); document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up);
  }
  function startResize(e, card) {
    var k = card.dataset.k, it = itemOf(k); if (!it) return; var z0 = sizeOf(it), x0 = e.clientX, y0 = e.clientY, cols = [1, 2, 4], ci0 = cols.indexOf(SZN[z0][0]), h0 = SZN[z0][1], cur = z0; S.dragging = true;
    function mv(ev) {
      ev.preventDefault(); var g = rtl() ? x0 - ev.clientX : ev.clientX - x0, ci = clamp(ci0 + Math.round(g / 70), 0, 2), hh = clamp(h0 + Math.round((ev.clientY - y0) / 70), 1, 2), z = fit(k, sizeFrom(cols[ci], hh));
      if (z === cur) return; cur = z; var grid = card.parentNode; flip(grid, card, function () { card.className = card.className.replace(/dz-\w+/, 'dz-' + z); });
    }
    function up() {
      document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up); S.dragging = false; S.lastDrag = Date.now();
      if (cur !== z0) mutate(function (l) { l.items.forEach(function (i) { if (i.k === k) i.z = cur; }); }); U.render(true);
    }
    document.addEventListener('pointermove', mv, { passive: false }); document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up);
  }
  document.addEventListener('pointerdown', function (e) {
    if (!S.dEdit || S.dPrev || U.route !== 'home' || !e.target.closest) return;
    var dh = e.target.closest('[data-dh]'), rh = e.target.closest('[data-rh]');
    if (dh) { e.preventDefault(); startDrag(e, dh.closest('.dc')); } else if (rh) { e.preventDefault(); startResize(e, rh.closest('.dc')); }
  }, { passive: false });

  /* ---------------- widget library page ---------------- */
  function allKeys() { var l = Object.keys(REG); DX.CAT.forEach(function (id) { l.push('sc:' + id); }); return l; }
  W.widgets = function () {
    var q = (S.libQ || '').toLowerCase(), c = S.libCat || 'all', lay = active(), h = '';
    h += '<div class="lib-s"><span>' + V.icon('search', 20) + '</span><input type="search" data-bind="libQ" value="' + esc(S.libQ || '') + '" placeholder="' + T('ابحث عن مؤشر...', 'Rechercher...', 'Search widgets...') + '" autocomplete="off"></div>';
    h += '<div class="lib-c"><button class="' + (c === 'all' ? 'on' : '') + '" data-act="lib_cat" data-id="all">' + T('الكل', 'Tous', 'All') + '</button>' + CATS.map(function (x) { return '<button class="' + (c === x[0] ? 'on' : '') + '" data-act="lib_cat" data-id="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>';
    var keys = allKeys().filter(function (k) { var R = regOf(k); return R && (c === 'all' || R.cat === c) && (!q || (lbl(k) + ' ' + R.de).toLowerCase().indexOf(q) >= 0); });
    if (!keys.length) h += '<div class="card muted" style="text-align:center">' + noData() + '</div>';
    h += '<div class="lib-g">' + keys.map(function (k) {
      var R = regOf(k), it = lay.items.filter(function (i) { return i.k === k; })[0], btn;
      if (!it) btn = '<button class="lib-add" data-act="lib_add" data-k="' + esc(k) + '">' + T('إضافة', 'Ajouter', 'Add') + ' +</button>';
      else if (it.h) btn = '<button class="lib-add show" data-act="lib_show" data-k="' + esc(k) + '">' + T('إظهار', 'Afficher', 'Show') + '</button>';
      else btn = '<button class="lib-add done" data-act="lib_rm" data-k="' + esc(k) + '">✓ ' + T('مضافة', 'Ajoutée', 'Added') + '</button>';
      return '<div class="lib-i"><span class="lib-ic">' + V.icon(R.ic || 'menu', 28) + '</span><b>' + esc(lbl(k)) + '</b><small>' + esc(R.de || '') + '</small>' + btn + '</div>';
    }).join('') + '</div>';
    return h;
  };
  X.lib_cat = function (el) { S.libCat = el.dataset.id; U.render(true); };
  X.lib_add = function (el) { var k = el.dataset.k, R = regOf(k); mutate(function (l) { if (!l.items.some(function (i) { return i.k === k; })) l.items.push({ k: k, z: fit(k, R.z) }); }); U.render(true); U.toast(T('تمت الإضافة إلى الصفحة الرئيسية', 'Ajouté', 'Added to home'), 'ok'); };
  X.lib_show = function (el) { var k = el.dataset.k; mutate(function (l) { l.items.forEach(function (i) { if (i.k === k) delete i.h; }); }); U.render(true); };
  X.lib_rm = function (el) { var k = el.dataset.k; mutate(function (l) { l.items = l.items.filter(function (i) { return i.k !== k; }); }); U.render(true); };

  /* ---------------- layouts management page ---------------- */
  W.dashmgr = function () {
    var ds = ensure(), h = '';
    h += '<div class="alert blue">' + T('أنشئ أكثر من تخطيط للصفحة الرئيسية (مدير، إنتاج، مخزون، مبيعات، محاسبة) وبدّل بينها بضغطة. كل شيء يُحفظ محليًا على الجهاز.', 'Créez plusieurs dispositions et passez de l\'une à l\'autre.', 'Create several home layouts and switch between them. Everything is stored on this device.') + '</div>';
    h += '<div class="btns" style="flex-wrap:wrap;margin-bottom:10px"><button class="btn primary" data-act="wd_edit">' + V.icon('edit', 18) + ' ' + T('تخصيص الصفحة الرئيسية', 'Personnaliser', 'Customize home') + '</button><button class="btn" data-act="dk_add">' + V.icon('plus', 18) + ' ' + T('مكتبة Widgets', 'Bibliothèque', 'Widget library') + '</button></div>';
    h += U.sec(T('التخطيطات', 'Dispositions', 'Layouts'));
    h += ds.layouts.map(function (l) {
      var on = l.id === ds.active;
      return '<div class="card dm-r' + (on ? ' on' : '') + '"><div class="dm-n"><b>' + esc(l.name) + '</b><small>' + B(l.items.filter(function (i) { return !i.h; }).length) + ' ' + T('بطاقة', 'cartes', 'cards') + (on ? ' · ' + T('نشط', 'actif', 'active') : '') + '</small></div><div class="dm-b">' +
        (on ? '' : '<button class="btn sm primary" data-act="dm_use" data-id="' + l.id + '">' + T('تفعيل', 'Activer', 'Use') + '</button>') + '<button class="btn sm" data-act="dm_ren" data-id="' + l.id + '">' + T('إعادة تسمية', 'Renommer', 'Rename') + '</button><button class="btn sm" data-act="dm_dup" data-id="' + l.id + '">' + T('نسخ', 'Copier', 'Copy') + '</button>' +
        (ds.layouts.length > 1 ? '<button class="btn sm soft-danger" data-act="dm_del" data-id="' + l.id + '">' + T('حذف', 'Suppr.', 'Delete') + '</button>' : '') + '</div></div>';
    }).join('');
    h += U.sec(T('إنشاء تخطيط جديد', 'Nouvelle disposition', 'New layout')) + '<div class="dm-t">' + Object.keys(TPL).map(function (k) { return '<button class="btn" data-act="dm_new" data-id="' + k + '">' + esc(TPL[k].n) + '</button>'; }).join('') + '<button class="btn" data-act="dm_new" data-id="blank">' + T('فارغ', 'Vide', 'Blank') + '</button></div>';
    var gon = !(U.D.settings.gestures === false);
    h += U.sec(T('خيارات الصفحة', 'Options', 'Options')) + '<div class="cz-row' + (gon ? '' : ' off') + '"><button class="tl" data-act="cz_gest" aria-label="' + t('gestures') + '">' + V.icon(gon ? 'eye' : 'eyeoff', 20) + '</button><div class="nm">' + esc(t('gestures')) + '<div class="muted" style="font-size:12px;font-weight:400">' + t('gestures_help') + '</div></div></div>';
    h += '<button class="btn block" data-act="home_cfg" style="margin:8px 0">' + V.icon('edit', 18) + ' ' + t('home_cfg') + '</button>';
    h += U.sec(t('shortcuts_title')) + '<div class="muted" style="margin:0 2px 8px;font-size:12.5px">' + T('غيّر أيقونة أي اختصار (تظهر في بطاقات الاختصارات).', 'Changez l\'icône d\'un raccourci.', 'Change the icon of any shortcut tile.') + '</div><div class="dm-ic">' + DX.CAT.map(function (id) { return '<button data-act="cz_icon" data-id="' + id + '" aria-label="' + esc(t(DX.LBL[id])) + '">' + V.tile(DX.iconOf(id), 34) + '<small>' + esc(t(DX.LBL[id])) + '</small></button>'; }).join('') + '</div>';
    h += U.sec(T('نسخ احتياطي للتخطيطات', 'Sauvegarde', 'Backup')) + '<div class="btns"><button class="btn" data-act="dm_export">' + T('تصدير', 'Exporter', 'Export') + '</button><button class="btn" data-act="dm_import">' + T('استيراد', 'Importer', 'Import') + '</button></div>';
    h += '<div class="muted" style="margin-top:10px;font-size:12.5px">' + T('ملاحظة: التطبيق يعمل بمستخدم واحد على الجهاز، لذلك تُستعمل التخطيطات للأدوار (مدير/إنتاج/...) وليست مرتبطة بصلاحيات حسابات منفصلة.', 'Application mono-utilisateur : les dispositions servent de profils.', 'The app has a single user per device, so layouts act as role profiles, not separate accounts.') + '</div>';
    return h;
  };
  W.customize = W.dashmgr;
  X.go_dashmgr = function () { U.go('dashmgr'); };
  X.dm_use = function (el) { var id = el.dataset.id; U.commit(function (d) { d.settings.dash.active = id; }); S.dsel = null; U.render(true); };
  X.dm_ren = function (el) {
    var id = el.dataset.id, l = ensure().layouts.filter(function (x) { return x.id === id; })[0];
    U.openForm({ title: T('إعادة تسمية التخطيط', 'Renommer', 'Rename layout'), submit: T('حفظ', 'Enregistrer', 'Save'), fields: [{ name: 'n', label: T('الاسم', 'Nom', 'Name'), type: 'text', value: l.name }], onSubmit: function (v) { if (!v.n.trim()) throw new Error(T('أدخل اسمًا', 'Nom requis', 'Enter a name')); U.commit(function (d) { d.settings.dash.layouts.forEach(function (x) { if (x.id === id) x.name = v.n.trim(); }); }); U.closeModal(); U.render(true); } });
  };
  X.dm_dup = function (el) { var id = el.dataset.id; U.commit(function (d) { var ls = d.settings.dash.layouts, s = ls.filter(function (x) { return x.id === id; })[0]; ls.push({ id: uid(), name: s.name + ' ' + T('(نسخة)', '(copie)', '(copy)'), items: JSON.parse(JSON.stringify(s.items)) }); }); U.render(true); };
  X.dm_del = function (el) { var id = el.dataset.id; U.confirmBox(T('حذف التخطيط', 'Supprimer', 'Delete layout'), T('سيُحذف هذا التخطيط فقط، ولا تتأثر بياناتك.', 'Seule la disposition est supprimée.', 'Only the layout is deleted, never your data.'), T('حذف', 'Supprimer', 'Delete'), function () { U.commit(function (d) { var x = d.settings.dash; x.layouts = x.layouts.filter(function (l) { return l.id !== id; }); if (x.active === id) x.active = x.layouts[0].id; }); U.render(true); }, true); };
  X.dm_new = function (el) {
    var k = el.dataset.id, tp = TPL[k], name = tp ? tp.n : T('تخطيط جديد', 'Nouvelle disposition', 'New layout'), id = uid();
    U.commit(function (d) { var x = d.settings.dash; x.layouts.push({ id: id, name: name, items: tp ? mk(tp.l) : [] }); x.active = id; }); U.toast(T('تم إنشاء التخطيط وتفعيله', 'Créé et activé', 'Created and activated'), 'ok'); U.render(true);
  };
  X.dm_export = function () {
    var txt = JSON.stringify({ app: 'KHALDI_PLAST_DASH', v: 1, layouts: ensure().layouts }, null, 1);
    try { U.saveFile('khaldi_dashboard_layouts.json', 'application/json', txt); } catch (e) { }
    U.showModal('<h3>' + T('تصدير التخطيطات', 'Export', 'Export layouts') + '</h3><textarea readonly rows="8" style="width:100%;direction:ltr;font-size:11px">' + esc(txt) + '</textarea><div class="btns"><button class="btn ghost" data-act="close">' + T('إغلاق', 'Fermer', 'Close') + '</button></div>');
  };
  X.dm_import = function () {
    U.openForm({ title: T('استيراد التخطيطات', 'Import', 'Import layouts'), intro: T('الصق نص التصدير هنا. ستُضاف التخطيطات دون حذف الموجودة.', 'Collez le texte exporté.', 'Paste exported text. Layouts are added, existing ones are kept.'), submit: T('استيراد', 'Importer', 'Import'), fields: [{ name: 'j', label: 'JSON', type: 'textarea', value: '' }],
      onSubmit: function (v) {
        var o; try { o = JSON.parse(v.j); } catch (e) { throw new Error(T('نص غير صالح', 'Texte invalide', 'Invalid text')); }
        if (!o || o.app !== 'KHALDI_PLAST_DASH' || !Array.isArray(o.layouts)) throw new Error(T('ملف غير صالح', 'Fichier invalide', 'Invalid file'));
        var n = 0; U.commit(function (d) { o.layouts.forEach(function (l) { if (!l || !Array.isArray(l.items)) return; var items = l.items.filter(function (i) { return i && regOf(i.k); }).map(function (i) { return { k: i.k, z: SZN[i.z] ? i.z : regOf(i.k).z, c: i.c, t: i.t, h: i.h, o: i.o }; }); d.settings.dash.layouts.push({ id: uid(), name: String(l.name || 'Layout').slice(0, 40), items: items }); n++; }); });
        U.closeModal(); U.toast(T('تم استيراد ', 'Importé: ', 'Imported ') + n, 'ok'); U.render(true);
      } });
  };
  U._dash = { REG: REG, regOf: regOf, active: active, lbl: lbl, TPL: TPL, allKeys: allKeys };
})();
