Khaldi Plast app
Start file: index.html (root of the zip).
Icon: icon.png (512x512).
Data is stored on the phone (localStorage). Use More > Backup regularly.
