package com.khaldiplast.edaret;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context c) { super(c, "khaldi_factory.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE production(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, product TEXT, qty REAL, machine TEXT, worker TEXT, notes TEXT)");
        db.execSQL("CREATE TABLE stock(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, unit TEXT, qty REAL, min_qty REAL, price REAL)");
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, customer TEXT, product TEXT, qty REAL, unit_price REAL, discount REAL, paid REAL)");
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, category TEXT, amount REAL, party TEXT, notes TEXT)");
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, body TEXT)");
        db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, action TEXT, details TEXT)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, dimensions TEXT, weight REAL, price REAL)");
        db.execSQL("INSERT INTO products(name,dimensions,weight,price) VALUES('CP9','90×300×500 مم',250,0)");
        db.execSQL("INSERT INTO products(name,dimensions,weight,price) VALUES('CP14','140×300×500 مم',350,0)");
        db.execSQL("INSERT INTO products(name,dimensions,weight,price) VALUES('Sipora 14','140×300×400 مم',NULL,0)");
        db.execSQL("INSERT INTO products(name,dimensions,weight,price) VALUES('Sipora 20','200×300×400 مم',NULL,0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {}

    public long addProduction(String date, String product, double qty, String machine, String worker, String notes) {
        ContentValues v=new ContentValues(); v.put("created_at",date); v.put("product",product); v.put("qty",qty);
        v.put("machine",machine); v.put("worker",worker); v.put("notes",notes);
        long id=getWritableDatabase().insert("production",null,v);
        audit("إضافة دفعة إنتاج", product+" — "+qty+" قطعة");
        return id;
    }
    public long addExpense(String date,String category,double amount,String party,String notes) {
        ContentValues v=new ContentValues(); v.put("created_at",date); v.put("category",category);
        v.put("amount",amount); v.put("party",party); v.put("notes",notes);
        long id=getWritableDatabase().insert("expenses",null,v); audit("إضافة مصروف",category+" — "+amount+" دج"); return id;
    }
    public long addSale(String date,String customer,String product,double qty,double price,double discount,double paid) {
        ContentValues v=new ContentValues(); v.put("created_at",date); v.put("customer",customer); v.put("product",product);
        v.put("qty",qty); v.put("unit_price",price); v.put("discount",discount); v.put("paid",paid);
        long id=getWritableDatabase().insert("sales",null,v); audit("إضافة عملية بيع",customer+" — "+product); return id;
    }
    public long addStock(String name,String unit,double qty,double min,double price) {
        ContentValues v=new ContentValues(); v.put("name",name); v.put("unit",unit); v.put("qty",qty); v.put("min_qty",min); v.put("price",price);
        long id=getWritableDatabase().insert("stock",null,v); audit("إضافة مادة للمخزون",name); return id;
    }
    public long addNote(String date,String body) {
        ContentValues v=new ContentValues(); v.put("created_at",date); v.put("body",body);
        long id=getWritableDatabase().insert("notes",null,v); audit("إضافة ملاحظة",body); return id;
    }
    public void audit(String action,String details) {
        ContentValues v=new ContentValues(); v.put("created_at",java.text.DateFormat.getDateTimeInstance().format(new Date()));
        v.put("action",action); v.put("details",details); getWritableDatabase().insert("audit",null,v);
    }
    public double sum(String table,String column) {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM("+column+"),0) FROM "+table,null);
        double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n;
    }
    public int count(String table) {
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null); int n=0;
        if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;
    }
    public List<String> rows(String table) {
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM "+table+" ORDER BY id DESC LIMIT 100",null);
        while(c.moveToNext()) {
            StringBuilder b=new StringBuilder();
            for(int i=0;i<c.getColumnCount();i++) {
                if(i>0)b.append("  •  ");
                b.append(c.getColumnName(i)).append(": ").append(c.isNull(i)?"—":c.getString(i));
            }
            out.add(b.toString());
        }
        c.close(); return out;
    }
}
