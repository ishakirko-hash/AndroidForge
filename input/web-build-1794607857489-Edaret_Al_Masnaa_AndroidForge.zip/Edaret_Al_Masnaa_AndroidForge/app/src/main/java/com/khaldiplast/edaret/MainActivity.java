package com.khaldiplast.edaret;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int navy=Color.rgb(7,26,43), panel=Color.rgb(17,48,72), cyan=Color.rgb(27,177,235), white=Color.WHITE, muted=Color.rgb(174,202,220);
    DatabaseHelper db; LinearLayout root, content; String current="الرئيسية";

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(navy); db=new DatabaseHelper(this); showHome();}
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); t.setGravity(Gravity.RIGHT); t.setPadding(4,6,4,6); return t; }
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;}
    void base(String title){
        root=column(); root.setBackgroundColor(navy);
        TextView header=text("إدارة المصنع  |  "+title,21,white,true); header.setPadding(20,22,20,18); header.setBackgroundColor(panel); root.addView(header);
        ScrollView scroll=new ScrollView(this); content=column(); content.setPadding(14,12,14,20); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row(); nav.setBackgroundColor(panel);
        String[] names={"الرئيسية","الإنتاج","المخزون","المبيعات","المزيد"};
        for(String n:names){Button b=button(n); b.setTextSize(11); b.setPadding(3,12,3,12); b.setOnClickListener(v->open(n)); nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav); setContentView(root);
    }
    Button button(String s){Button b=new Button(this); b.setText(s); b.setTextColor(white); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan)); return b;}
    void card(String label,String value,String hint,Runnable action){
        LinearLayout c=column(); c.setPadding(16,12,16,12); c.setBackground(bg(panel,24));
        TextView a=text(label,14,muted,false), v=text(value,25,white,true), h=text(hint,11,muted,false);
        c.addView(a); c.addView(v); c.addView(h); c.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,10); content.addView(c,p);
    }
    String money(double n){return String.format(Locale.US,"%,.0f دج",n);}
    void showHome(){
        base("لوحة التحكم");
        content.addView(text("ملخص المصنع",20,white,true));
        card("إجمالي الإنتاج المسجل",String.format(Locale.US,"%.0f قطعة",db.sum("production","qty")),"اضغط لعرض دفعات الإنتاج",()->open("الإنتاج"));
        card("المبيعات المسجلة",money(db.sum("sales","qty*unit_price-discount")),"إجمالي قيمة عمليات البيع",()->open("المبيعات"));
        card("المصاريف",money(db.sum("expenses","amount")),"المصاريف المسجلة",()->listPage("expenses","سجل المصاريف"));
        card("المبالغ المتبقية للعملاء",money(db.sum("sales","qty*unit_price-discount-paid")),"المبيعات ناقص المدفوع",()->open("المبيعات"));
        card("صافي نقدي تقديري",money(db.sum("sales","paid")-db.sum("expenses","amount")),"المدفوعات المقبوضة ناقص المصاريف المسجلة؛ ليس ربحاً محاسبياً",()->listPage("expenses","تفاصيل المصاريف"));
        card("دفعات الإنتاج",String.valueOf(db.count("production")),"عدد السجلات",()->open("الإنتاج"));
        card("تنبيهات المخزون","افتح المخزون","تظهر المواد تحت الحد الأدنى في قسم المخزون",()->open("المخزون"));
        content.addView(text("المنتجات الأساسية",17,white,true));
        for(String p:new String[]{"CP9 — 90×300×500 مم — 250غ تقريباً","CP14 — 140×300×500 مم — 350غ تقريباً","Sipora 14 — 140×300×400 مم","Sipora 20 — 200×300×400 مم"}) content.addView(text("• "+p,13,muted,false));
    }
    EditText field(String hint,boolean numeric){
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(white); e.setHintTextColor(muted);
        e.setPadding(14,10,14,10); e.setBackground(bg(panel,14));
        if(numeric)e.setInputType(8194|4096); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,8); content.addView(e,p); return e;
    }
    String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}
    double num(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception ex){return 0;}}
    void addFormTitle(String s){content.addView(text(s,19,white,true));}
    void open(String section){
        current=section;
        switch(section){
            case "الرئيسية": showHome(); break;
            case "الإنتاج": productionPage(); break;
            case "المخزون": stockPage(); break;
            case "المبيعات": salesPage(); break;
            default: morePage();
        }
    }
    void productionPage(){
        base("الإنتاج"); addFormTitle("تسجيل دفعة إنتاج");
        EditText product=field("نوع الصندوق (مثلاً CP9)",false), qty=field("عدد القطع",true), machine=field("الآلة أو خط الإنتاج",false), worker=field("العامل المسؤول",false), notes=field("ملاحظات",false);
        TextView total=text("الوزن الكلي: —",14,cyan,true); content.addView(total);
        qty.addTextChangedListener(watcher(()->total.setText("أدخل وزن القطعة في شاشة المنتجات لحساب الوزن الكلي")));
        Button save=button("حفظ دفعة الإنتاج"); content.addView(save); save.setOnClickListener(v->{
            if(product.getText().toString().trim().isEmpty()||num(qty)<=0){toast("أدخل نوع الصندوق وعدداً صحيحاً أكبر من صفر");return;}
            db.addProduction(now(),product.getText().toString(),num(qty),machine.getText().toString(),worker.getText().toString(),notes.getText().toString());
            toast("تم حفظ دفعة الإنتاج"); productionPage();
        });
        content.addView(text("آخر دفعات الإنتاج",17,white,true)); addRows("production");
    }
    TextWatcher watcher(Runnable r){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){r.run();} public void afterTextChanged(Editable e){}};}
    void stockPage(){
        base("المواد والمخزون"); addFormTitle("إضافة مادة أولية");
        EditText name=field("اسم المادة",false), unit=field("الوحدة (كغ، غ، قطعة...)",false), qty=field("الكمية الحالية",true), min=field("حد التنبيه",true), price=field("سعر الوحدة بالدج",true);
        Button save=button("حفظ المادة"); content.addView(save); save.setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty()){toast("أدخل اسم المادة");return;}
            db.addStock(name.getText().toString(),unit.getText().toString(),num(qty),num(min),num(price)); toast("تم حفظ المادة"); stockPage();
        });
        content.addView(text("سجل المواد",17,white,true)); addRows("stock");
    }
    void salesPage(){
        base("المبيعات"); addFormTitle("تسجيل عملية بيع");
        EditText customer=field("اسم العميل",false), product=field("نوع الصندوق",false), qty=field("الكمية",true), price=field("سعر القطعة بالدج",true), discount=field("الخصم بالدج",true), paid=field("المبلغ المدفوع بالدج",true);
        TextView calc=text("الإجمالي: 0 دج  |  المتبقي: 0 دج",15,cyan,true); content.addView(calc);
        Runnable update=()->{double total=Math.max(0,num(qty)*num(price)-num(discount)); calc.setText("الإجمالي: "+money(total)+"  |  المتبقي: "+money(Math.max(0,total-num(paid))));};
        for(EditText e:new EditText[]{qty,price,discount,paid})e.addTextChangedListener(watcher(update));
        Button save=button("حفظ عملية البيع"); content.addView(save); save.setOnClickListener(v->{
            if(customer.getText().toString().trim().isEmpty()||product.getText().toString().trim().isEmpty()||num(qty)<=0||num(price)<0){toast("تحقق من بيانات العميل والمنتج والكمية والسعر");return;}
            db.addSale(now(),customer.getText().toString(),product.getText().toString(),num(qty),num(price),num(discount),num(paid)); toast("تم حفظ البيع"); salesPage();
        });
        content.addView(text("آخر عمليات البيع",17,white,true)); addRows("sales");
    }
    void morePage(){
        base("المزيد");
        String[][] items={{"المصاريف","expenses"},{"الملاحظات","notes"},{"سجل التعديلات","audit"},{"تقارير مختصرة","reports"}};
        for(String[] it:items){Button b=button(it[0]); content.addView(b); b.setOnClickListener(v->{if(it[1].equals("reports"))reportPage(); else if(it[1].equals("notes"))notesPage(); else listPage(it[1],it[0]);});}
    }
    void notesPage(){
        base("الملاحظات"); addFormTitle("ملاحظة جديدة"); EditText e=field("اكتب الملاحظة",false); Button b=button("حفظ الملاحظة"); content.addView(b);
        b.setOnClickListener(v->{if(e.getText().toString().trim().isEmpty()){toast("اكتب نص الملاحظة");return;} db.addNote(now(),e.getText().toString());toast("تم حفظ الملاحظة");notesPage();});
        addRows("notes");
    }
    void listPage(String table,String title){base(title); addRows(table);}
    void reportPage(){
        base("التقارير");
        card("إنتاج المصنع",String.format(Locale.US,"%.0f قطعة",db.sum("production","qty")),"إجمالي الكميات المسجلة",()->listPage("production","دفعات الإنتاج"));
        card("المبيعات",money(db.sum("sales","qty*unit_price-discount")),"قيمة البيع قبل طرح التكاليف",()->listPage("sales","المبيعات"));
        card("المصاريف",money(db.sum("expenses","amount")),"المصاريف المسجلة",()->listPage("expenses","المصاريف"));
        card("المقبوضات",money(db.sum("sales","paid")),"المدفوع من العملاء",()->listPage("sales","المدفوعات"));
        content.addView(text("ملاحظة: الربح الصافي يحتاج إدخال تكلفة المواد والاستهلاك وبقية التكاليف؛ لا يتم اعتباره مساوياً للمبيعات.",13,muted,false));
    }
    void addRows(String table){
        List<String> rows=db.rows(table);
        if(rows.isEmpty()){content.addView(text("لا توجد سجلات بعد.",14,muted,false));return;}
        for(String s:rows){TextView t=text(s,12,white,false); t.setPadding(12,12,12,12); t.setBackground(bg(panel,14)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,7);content.addView(t,p);}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
