# بناء وتثبيت KHALDI PLAST ERP Fresh على Android

## الخيار الأول: Android Studio على الكمبيوتر

1. ثبّت Android Studio من الموقع الرسمي.
2. افتح SDK Manager وثبّت `Android SDK Platform 35` و`Android SDK Build-Tools 35.0.0` و`Platform-Tools`.
3. ثبّت JDK 17 أو استخدم JBR المرفق مع Android Studio.
4. فك ضغط المشروع وافتح مجلد `KHALDI_PLAST_ERP_FRESH_1.0.0` نفسه، وليس مجلد `app` فقط.
5. نفّذ من Terminal داخل جذر المشروع:

```bash
./gradlew assembleDebug
```

على Windows:

```powershell
.\gradlew.bat assembleDebug
```

6. بعد اكتمال البناء، يوجد APK في:

`app/build/outputs/apk/debug/app-debug.apk`

انسخه إلى الهاتف وثبّته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

## الخيار الثاني: GitHub Actions

1. أنشئ مستودع GitHub جديداً وارفع محتويات المشروع.
2. افتح تبويب Actions.
3. شغّل Workflow باسم `Build Fresh KHALDI PLAST ERP APK` يدوياً.
4. بعد انتهاء المهمة بنجاح، نزّل Artifact باسم `KHALDI-PLAST-ERP-FRESH-debug-apk`.

## ملاحظات التثبيت

- الحزمة الجديدة مستقلة بمعرّف `dz.khaldiplast.erp`، لذلك لا تستبدل تطبيق WebView السابق مباشرة.
- قاعدة بيانات هذا التطبيق جديدة ومستقلة؛ لا تستورد تلقائياً بيانات التطبيق القديم.
- ابدأ بتعديل رصيد أصناف المنتجات النهائية، أو سجّل الإنتاج، قبل إصدار أول فاتورة.
- لا تحذف التطبيق بعد إدخال بيانات حقيقية قبل توفير آلية نسخ احتياطي معتمدة.
- APK الناتج من نوع debug للتجربة الداخلية؛ قبل التوزيع المؤسسي يجب إعداد توقيع release وحماية النسخ الاحتياطية.
