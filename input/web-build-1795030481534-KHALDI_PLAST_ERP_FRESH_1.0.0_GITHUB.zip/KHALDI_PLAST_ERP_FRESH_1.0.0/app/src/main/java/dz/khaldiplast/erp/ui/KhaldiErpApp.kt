package dz.khaldiplast.erp.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import dz.khaldiplast.erp.R
import dz.khaldiplast.erp.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

private enum class AppTab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Home("الرئيسية", Icons.Filled.Home),
    Sales("المبيعات", Icons.Filled.BarChart),
    Stock("المخزون", Icons.Filled.Inventory2),
    Production("الإنتاج", Icons.Filled.Settings),
    More("المزيد", Icons.Filled.Person)
}
private enum class FormKind { INVOICE, PRODUCTION, STOCK, NOTE, EXPENSE, EMPLOYEE }

@Composable
fun KhaldiErpApp() {
    val context = LocalContext.current
    val db = remember { ErpDatabase(context) }
    var tab by rememberSaveable { mutableStateOf(AppTab.Home) }
    var morePage by rememberSaveable { mutableStateOf("menu") }
    var refresh by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<FormKind?>(null) }
    var notificationsOpen by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val totals = remember(refresh) { db.totals() }
    val products = remember(refresh) { db.products() }
    val invoices = remember(refresh) { db.invoices() }
    val monthlySales = remember(refresh) { db.monthlySales() }
    val production = remember(refresh) { db.production() }
    val notes = remember(refresh) { db.notes() }
    val employees = remember(refresh) { db.employees() }

    BackHandler(enabled = tab != AppTab.Home || morePage != "menu") {
        if (tab == AppTab.More && morePage != "menu") morePage = "menu" else { tab = AppTab.Home; morePage = "menu" }
    }

    fun perform(block: () -> Unit) {
        try {
            block()
            refresh++
            dialog = null
            scope.launch { snackbar.showSnackbar("تم حفظ العملية بنجاح") }
        } catch (e: Exception) {
            scope.launch { snackbar.showSnackbar(e.message ?: "تعذر تنفيذ العملية") }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.factory_background),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x4D006BCB), Color(0x66D8F1FF), Color(0x661064A5)))))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            BrandHeader(tab = tab, onMenuClick = { tab = AppTab.More; morePage = "menu" }, onNotificationsClick = { notificationsOpen = true })
            var horizontalDrag by remember { mutableFloatStateOf(0f) }
            Box(Modifier.weight(1f).fillMaxWidth().pointerInput(tab) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { change, amount -> change.consume(); horizontalDrag += amount },
                    onDragEnd = {
                        val order = AppTab.values()
                        val currentIndex = order.indexOf(tab)
                        if (horizontalDrag < -85f && currentIndex < order.lastIndex) tab = order[currentIndex + 1]
                        else if (horizontalDrag > 85f && currentIndex > 0) tab = order[currentIndex - 1]
                        horizontalDrag = 0f
                    },
                    onDragCancel = { horizontalDrag = 0f }
                )
            }) {
                AnimatedContent(targetState = tab, label = "primaryPage") { currentTab ->
                    key(currentTab) {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 7.dp),
                        verticalArrangement = Arrangement.spacedBy(11.dp)
                    ) {
                        when (currentTab) {
                            AppTab.Home -> HomeScreen(totals, products, monthlySales, invoices, production, onNavigate = { tab = it }, onOpenMore = { page -> tab = AppTab.More; morePage = page }, onNewInvoice = { dialog = FormKind.INVOICE }, onNewProduction = { dialog = FormKind.PRODUCTION }, onAddExpense = { dialog = FormKind.EXPENSE })
                            AppTab.Sales -> SalesScreen(totals, monthlySales, invoices, products, onNewInvoice = { dialog = FormKind.INVOICE })
                            AppTab.Stock -> StockScreen(totals, products, onAdjust = { dialog = FormKind.STOCK })
                            AppTab.Production -> ProductionScreen(totals, products, production, onNew = { dialog = FormKind.PRODUCTION })
                            AppTab.More -> MoreScreen(selectedPage = morePage, totals = totals, products = products, invoices = invoices, notes = notes, onOpenPage = { morePage = it }, onBack = { morePage = "menu" }, onNavigate = { tab = it; morePage = "menu" }, onNewNote = { dialog = FormKind.NOTE }, onAddExpense = { dialog = FormKind.EXPENSE }, onMarkNote = { id, status -> db.markNote(id, status); refresh++ }, employees = employees, onAddEmployee = { dialog = FormKind.EMPLOYEE }, onAttendance = { id, status -> db.setEmployeeStatus(id, status); refresh++ })
                        }
                    }
                    }
                }
            }
            BottomNavigation(selected = tab, onSelect = { tab = it; if (it != AppTab.More) morePage = "menu" })
        }
        SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 94.dp)) { data ->
            Snackbar(containerColor = Color(0xF20B4E8D), contentColor = Color.White, snackbarData = data)
        }
    }

    if (notificationsOpen) {
        AlertDialog(
            onDismissRequest = { notificationsOpen = false },
            title = { Text("الإشعارات", color = Ink, fontWeight = FontWeight.ExtraBold) },
            text = { Text(if (totals.lowStock > 0) "يوجد ${totals.lowStock} أصناف تحتاج إلى مراجعة الرصيد. لا توجد تنبيهات تشغيل للآلات حتى يتم ربط الحساسات." else "لا توجد إشعارات جديدة حالياً.", color = SoftBlue) },
            confirmButton = { TextButton(onClick = { notificationsOpen = false }) { Text("حسناً") } },
            containerColor = Color(0xFFF0F8FF)
        )
    }
    dialog?.let { kind ->
        ErpFormDialog(kind = kind, database = db, products = products, onDismiss = { dialog = null }, onSave = { action -> perform(action) })
    }
}

@Composable
private fun BrandHeader(tab: AppTab, onMenuClick: () -> Unit, onNotificationsClick: () -> Unit) {
    val home = tab == AppTab.Home
    Box(Modifier.fillMaxWidth().height(if (home) 178.dp else 145.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            HeaderIcon(Icons.Filled.NotificationsNone, "الإشعارات", badge = true, onClick = onNotificationsClick)
            HeaderIcon(Icons.Filled.Menu, "القائمة", onClick = onMenuClick)
        }
        Column(
            Modifier.align(Alignment.Center).padding(top = if (home) 7.dp else 13.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(painterResource(R.drawable.kp_mark), contentDescription = "KHALDI PLAST", modifier = Modifier.height(if (home) 73.dp else 56.dp).width(if (home) 106.dp else 84.dp), contentScale = ContentScale.Fit)
            Text("KHALDI PLAST", fontSize = if (home) 22.sp else 18.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = 1.2.sp, lineHeight = 23.sp)
            Text("S H A P I N G   T O M O R R O W", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = Color(0xFF245F9C), letterSpacing = 1.2.sp)
        }
    }
}

@Composable
private fun HeaderIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, badge: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).shadow(9.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xDDFBFFFF), Color(0x91C6E8FF)))).border(1.dp, Color.White.copy(.78f), RoundedCornerShape(18.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(26.dp))
        if (badge) Box(Modifier.align(Alignment.TopEnd).padding(7.dp).size(9.dp).background(Red, CircleShape).border(1.dp, Color.White, CircleShape))
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, radius: Int = 25, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(radius.dp)
    Column(
        modifier.shadow(12.dp, shape).clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xE8F7FCFF), Color(0xC9D9EEFF), Color(0xDDF4FBFF))))
            .border(1.2.dp, Color.White.copy(alpha = .92f), shape)
            .padding(13.dp),
        content = content
    )
}

@Composable
private fun PageHeading(title: String, subtitle: String? = null, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            if (subtitle != null) Text(subtitle, color = Color(0xFF3F6E9E), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (action != null) SmallGlassButton(action, Icons.Filled.CalendarMonth, onClick = { onAction?.invoke() })
    }
}

@Composable
private fun GreetingCard() {
    GlassPanel(Modifier.fillMaxWidth(), radius = 23) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                IconBadge(Icons.Filled.BarChart, Blue, 47)
                Column {
                    Text("مرحباً بك", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                    Text("لوحة التحكم الرئيسية", fontSize = 12.sp, color = SoftBlue)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("اليوم", fontSize = 11.sp, color = SoftBlue)
                    Text("متابعة أداء المصنع", fontSize = 12.sp, color = Ink, fontWeight = FontWeight.Bold)
                }
                IconBadge(Icons.Filled.CalendarMonth, Blue, 42)
            }
        }
    }
}

@Composable
private fun IconBadge(icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, size: Int = 48) {
    Box(Modifier.size(size.dp).shadow(8.dp, RoundedCornerShape(15.dp)).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(color.copy(alpha = .93f), color.copy(alpha = .72f)))).border(1.dp, Color.White.copy(.7f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size((size * .52f).dp))
    }
}

@Composable
private fun MetricCard(title: String, value: String, unit: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, trend: String? = null, modifier: Modifier = Modifier) {
    Row(modifier.shadow(8.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xEFFFFFFF), Color(0xCBE4F3FF)))).border(1.dp, Color.White, RoundedCornerShape(22.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        IconBadge(icon, color, 50)
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = SoftBlue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(value, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(unit, color = SoftBlue, fontSize = 10.sp)
                if (trend != null) Text(trend, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MetricGrid(items: List<Triple<String, String, Pair<androidx.compose.ui.graphics.vector.ImageVector, Color>>>, unit: String = "") {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items.chunked(2).forEach { line ->
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                line.forEach { item ->
                    MetricCard(item.first, item.second, unit, item.third.first, item.third.second, modifier = Modifier.weight(1f))
                }
                if (line.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

private fun monthName(yyyyMm: String): String {
    val names = listOf("جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
    val m = yyyyMm.substringAfter("-", "01").toIntOrNull()?.coerceIn(1, 12) ?: 1
    return names[m - 1]
}
private fun defaultDueDate(): String = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, 7) }.time)
private fun fmt(value: Long): String = NumberFormat.getNumberInstance(Locale("fr", "DZ")).format(value)
private fun fmtInt(value: Int): String = NumberFormat.getIntegerInstance(Locale("fr", "DZ")).format(value)

@Composable
private fun SectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconBadge(icon, Blue, 35)
            Text(title, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        }
        if (action != null) SmallGlassButton(action, Icons.Filled.ExpandMore) { onAction?.invoke() }
    }
}

@Composable
private fun SmallGlassButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector? = null, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(30.dp)).background(Color(0xBFFFFFFF)).border(1.dp, Color.White, RoundedCornerShape(30.dp)).clickable { onClick() }.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(text, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        if (icon != null) Icon(icon, null, tint = Blue, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun HomeScreen(totals: DashboardTotals, products: List<Product>, monthlySales: List<SalesPoint>, invoices: List<Invoice>, production: List<ProductionEntry>, onNavigate: (AppTab) -> Unit, onOpenMore: (String) -> Unit, onNewInvoice: () -> Unit, onNewProduction: () -> Unit, onAddExpense: () -> Unit) {
    GreetingCard()
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        MetricCard("الإنتاج", fmtInt(totals.production), "قطعة", Icons.Filled.BarChart, Blue, null, Modifier.weight(1f))
        MetricCard("المبيعات", fmt(totals.sales), "دج", Icons.Filled.Inventory2, Green, if (totals.invoiceCount > 0) "${totals.invoiceCount} فاتورة" else null, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        MetricCard("المصاريف", fmt(totals.expenses), "دج", Icons.Filled.AccountBalanceWallet, Red, null, Modifier.weight(1f))
        MetricCard("المخزون", fmtInt(totals.stock), "قطعة", Icons.Filled.Inventory, Orange, "${products.size} أصناف", Modifier.weight(1f))
    }
    GlassPanel(Modifier.fillMaxWidth()) {
        SectionTitle("المبيعات الشهرية", Icons.Filled.BarChart, "آخر 6 أشهر") { }
        Spacer(Modifier.height(7.dp))
        SalesLineChart(monthlySales, Modifier.fillMaxWidth().height(145.dp))
    }
    SectionTitle("إنتاج الصناديق", Icons.Filled.Inventory2)
    val firstProduct = products.getOrNull(0)
    val secondProduct = products.getOrNull(1)
    val firstQty = production.filter { it.product == firstProduct?.name }.sumOf { it.quantity }
    val secondQty = production.filter { it.product == secondProduct?.name }.sumOf { it.quantity }
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        ProductProductionCard(firstProduct?.name ?: "الصندوق الأول", firstProduct?.image ?: "crate_blue", firstQty, Blue, Modifier.weight(1f))
        ProductProductionCard(secondProduct?.name ?: "الصندوق الثاني", secondProduct?.image ?: "crate_green", secondQty, Green, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        QuickAction("التقارير", Icons.Filled.Assessment, Orange) { onOpenMore("التقارير") }
        QuickAction("الآلات", Icons.Filled.Settings, Color(0xFF0C9EAD)) { onOpenMore("الآلات") }
        QuickAction("المنتجات", Icons.Filled.Inventory2, Blue) { onNavigate(AppTab.Stock) }
        QuickAction("العملاء", Icons.Filled.Groups, Purple) { onOpenMore("العملاء") }
    }
    SectionTitle("إجراءات سريعة", Icons.Filled.Bolt)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PrimaryAction("تسجيل إنتاج", Icons.Filled.Add, Modifier.weight(1f), onNewProduction)
        SecondaryAction("فاتورة جديدة", Icons.Filled.ReceiptLong, Modifier.weight(1f), onNewInvoice)
        SecondaryAction("مصروف", Icons.Filled.Payments, Modifier.weight(1f), onAddExpense)
    }
}

@Composable
private fun ProductProductionCard(title: String, image: String, quantity: Int, color: Color, modifier: Modifier = Modifier) {
    GlassPanel(modifier, radius = 22) {
        Text(title, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            ProductImage(image, Modifier.size(86.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text("إنتاج اليوم", color = SoftBlue, fontSize = 10.sp)
                Text(fmtInt(quantity), color = Ink, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                Text("قطعة", color = SoftBlue, fontSize = 10.sp)
            }
            RingProgress(0f, color, "—", 48)
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    Column(Modifier.weight(1f).shadow(7.dp, RoundedCornerShape(21.dp)).clip(RoundedCornerShape(21.dp)).background(Brush.verticalGradient(listOf(Color(0xEFFFFFFF), Color(0xCBE2F2FF)))).border(1.dp, Color.White, RoundedCornerShape(21.dp)).clickable { onClick() }.padding(vertical = 13.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
        IconBadge(icon, color, 52)
        Text(label, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun SalesScreen(totals: DashboardTotals, monthlySales: List<SalesPoint>, invoices: List<Invoice>, products: List<Product>, onNewInvoice: () -> Unit) {
    var search by remember { mutableStateOf("") }
    val filteredInvoices = invoices.filter { it.customer.contains(search, true) || it.number.contains(search, true) || it.productName.contains(search, true) }
    PageHeading("المبيعات", "إدارة الفواتير والعملاء والتحصيل", "الفترة الحالية")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("إجمالي المبيعات", fmt(totals.sales), "دج", Icons.Filled.Payments, Green, null, Modifier.weight(1f))
        MetricCard("عدد الفواتير", fmtInt(totals.invoiceCount), "فاتورة", Icons.Filled.ReceiptLong, Blue, null, Modifier.weight(1f))
    }
    GlassPanel(Modifier.fillMaxWidth()) {
        SectionTitle("تحليل المبيعات", Icons.Filled.BarChart, "يومي") { }
        Spacer(Modifier.height(8.dp))
        SalesLineChart(monthlySales, Modifier.fillMaxWidth().height(165.dp))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        GlassPanel(Modifier.weight(1f)) {
            Text("حسب المنتج", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            MiniDonut(invoices.groupBy { it.productName }.values.map { rows -> rows.sumOf { it.total }.toFloat() }, if (invoices.isEmpty()) "0" else fmtInt(invoices.size))
            Text(if (invoices.isEmpty()) "لا توجد مبيعات بعد" else "${invoices.map { it.productName }.distinct().size} أصناف مباعة", color = SoftBlue, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        GlassPanel(Modifier.weight(1f)) {
            Text("حالة الدفع", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            MiniDonut(listOf(invoices.filter { it.status == "مدفوعة" }.sumOf { it.total }.toFloat(), invoices.filter { it.status != "مدفوعة" }.sumOf { it.total }.toFloat()), if (invoices.isEmpty()) "0" else fmtInt(invoices.size))
            Text(if (invoices.isEmpty()) "لا توجد دفعات بعد" else "${invoices.count { it.status == "مدفوعة" }} مدفوعة · ${invoices.count { it.status != "مدفوعة" }} آجلة", color = SoftBlue, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
    GlassPanel(Modifier.fillMaxWidth()) {
        SectionTitle("آخر الفواتير", Icons.Filled.ReceiptLong, "${filteredInvoices.size} سجل") { }
        OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("بحث برقم الفاتورة أو اسم العميل", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Filled.Search, null, tint = Blue) }, shape = RoundedCornerShape(15.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White.copy(.65f), focusedContainerColor = Color.White.copy(.8f), focusedBorderColor = Blue, unfocusedBorderColor = Color.White))
        Spacer(Modifier.height(8.dp))
        if (filteredInvoices.isEmpty()) EmptyState("لا توجد فواتير مطابقة", "أنشئ فاتورة جديدة أو غيّر عبارة البحث", Icons.Filled.ReceiptLong)
        else filteredInvoices.take(12).forEach { InvoiceRow(it) }
    }
    PrimaryAction("فاتورة جديدة", Icons.Filled.Add, Modifier.fillMaxWidth(), onNewInvoice)
}

@Composable
private fun InvoiceRow(invoice: Invoice) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBadge(Icons.Filled.ReceiptLong, Blue, 37)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(invoice.customer, color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("${invoice.number} · ${invoice.productName} · ${invoice.quantity} قطعة", color = SoftBlue, fontSize = 10.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("${fmt(invoice.total)} دج", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            StatusPill(invoice.status)
        }
    }
    Divider(color = Color.White.copy(.8f))
}

@Composable
private fun StockScreen(totals: DashboardTotals, products: List<Product>, onAdjust: () -> Unit) {
    var search by remember { mutableStateOf("") }
    val filteredProducts = products.filter { it.name.contains(search, true) || it.code.contains(search, true) }
    PageHeading("المخزون", "متابعة المنتجات والمواد الخام")
    GlassPanel(Modifier.fillMaxWidth(), radius = 20) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Search, null, tint = Blue)
            OutlinedTextField(search, { search = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("ابحث عن منتج أو رمز الصنف", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Filled.Search, null, tint = Blue) }, shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White.copy(.55f), focusedContainerColor = Color.White.copy(.75f), focusedBorderColor = Blue, unfocusedBorderColor = Color.Transparent))
            Icon(Icons.Filled.FilterList, null, tint = Blue)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("إجمالي الأصناف", fmtInt(products.size), "صنف", Icons.Filled.Inventory2, Blue, null, Modifier.weight(1f))
        MetricCard("المنتجات الجاهزة", fmtInt(totals.stock), "قطعة", Icons.Filled.Inventory, Green, null, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("المواد الخام", fmtInt(totals.rawStock), "كغ", Icons.Filled.Category, Orange, null, Modifier.weight(1f))
        MetricCard("أصناف منخفضة", fmtInt(totals.lowStock), "صنف", Icons.Filled.WarningAmber, Red, null, Modifier.weight(1f))
    }
    GlassPanel(Modifier.fillMaxWidth()) {
        SectionTitle("توزيع المخزون", Icons.Filled.PieChart)
        if (totals.stock == 0 && totals.rawStock == 0) EmptyState("المخزون فارغ حالياً", "ابدأ بتسجيل الإنتاج أو إضافة رصيد افتتاحي", Icons.Filled.Inventory2)
        else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
            MiniDonut(products.filter { it.category == "صناديق" }.map { it.stock.toFloat() }, fmtInt(totals.stock))
            Column(horizontalAlignment = Alignment.End) {
                Text("منتجات جاهزة: ${fmtInt(totals.stock)} قطعة", color = Ink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("مواد خام: ${fmtInt(totals.rawStock)} كغ", color = SoftBlue, fontSize = 10.sp)
            }
        }
    }
    GlassPanel(Modifier.fillMaxWidth()) {
        SectionTitle("قائمة المنتجات", Icons.Filled.Inventory2, "${filteredProducts.size} منتجات")
        filteredProducts.forEach { p -> ProductStockRow(p) }
        if (filteredProducts.isEmpty()) EmptyState("لا توجد نتائج", "جرّب البحث برمز أو اسم آخر", Icons.Filled.Search)
    }
    PrimaryAction("تعديل رصيد المخزون", Icons.Filled.Add, Modifier.fillMaxWidth(), onAdjust)
}

@Composable
private fun ProductStockRow(product: Product) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ProductImage(product.image, Modifier.size(82.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(product.name, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            Text(product.code, color = SoftBlue, fontSize = 10.sp)
            Text(product.size, color = SoftBlue, fontSize = 9.sp)
            Text("${product.color} · ${product.category}", color = SoftBlue, fontSize = 9.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("الكمية المتوفرة", color = SoftBlue, fontSize = 9.sp)
            Text(fmtInt(product.stock), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Text(product.unit, color = SoftBlue, fontSize = 9.sp)
        }
    }
    Divider(color = Color.White.copy(.8f))
}

@Composable
private fun ProductionScreen(totals: DashboardTotals, products: List<Product>, production: List<ProductionEntry>, onNew: () -> Unit) {
    PageHeading("الإنتاج", "متابعة عمليات الإنتاج والآلات والطلبيات")
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        MetricCard("إجمالي الإنتاج", fmtInt(totals.production), "قطعة", Icons.Filled.Inventory2, Green, null, Modifier.weight(1f))
        MetricCard("الطلبات الجارية", "${production.size}", "عملية", Icons.Filled.ReceiptLong, Blue, null, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        MetricCard("وقت التشغيل", "—", "غير متاح", Icons.Filled.AccessTime, Purple, null, Modifier.weight(1f))
        MetricCard("التوقفات", "—", "غير متاح", Icons.Filled.WarningAmber, Red, null, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassPanel(Modifier.weight(1.2f)) {
            SectionTitle("مخطط الإنتاج", Icons.Filled.BarChart)
            BarChart(production.map { it.quantity.toFloat() }.takeLast(7), Modifier.fillMaxWidth().height(142.dp))
        }
        GlassPanel(Modifier.weight(.8f)) {
            SectionTitle("توزيع اليوم", Icons.Filled.PieChart)
            MiniDonut(production.groupBy { it.product }.values.map { rows -> rows.sumOf { it.quantity }.toFloat() }, fmtInt(totals.production))
            Text("${fmtInt(totals.production)} قطعة", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    GlassPanel(Modifier.fillMaxWidth()) {
        SectionTitle("حالة الآلات", Icons.Filled.Settings)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..4).forEach { index ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    ProductImage("machine", Modifier.fillMaxWidth().height(78.dp))
                    Text("الآلة $index", color = Ink, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("غير متصلة", color = SoftBlue, fontSize = 9.sp)
                    RingProgress(0f, SoftBlue, "—", 42)
                }
            }
        }
        Text("تظهر بيانات التشغيل الفعلية بعد ربط حساسات الآلات", color = SoftBlue, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
    GlassPanel(Modifier.fillMaxWidth()) {
        SectionTitle("سجل الإنتاج الأخير", Icons.Filled.History)
        if (production.isEmpty()) EmptyState("لا توجد عمليات إنتاج مسجلة", "ابدأ بتسجيل أول دورة إنتاج", Icons.Filled.Settings)
        else production.take(12).forEach { entry ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                ProductImage(products.firstOrNull { it.name == entry.product }?.image ?: "crate_blue", Modifier.size(62.dp))
                Column(Modifier.weight(1f)) {
                    Text(entry.product, color = Ink, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("${entry.machine} · ${entry.date}", color = SoftBlue, fontSize = 9.sp)
                }
                Text(fmtInt(entry.quantity), color = Ink, fontWeight = FontWeight.ExtraBold)
            }
            Divider(color = Color.White.copy(.8f))
        }
    }
    PrimaryAction("تسجيل إنتاج جديد", Icons.Filled.Add, Modifier.fillMaxWidth(), onNew)
}

@Composable
private fun MoreScreen(
    selectedPage: String,
    totals: DashboardTotals,
    products: List<Product>,
    invoices: List<Invoice>,
    notes: List<NoteEntry>,
    onOpenPage: (String) -> Unit,
    onBack: () -> Unit,
    onNavigate: (AppTab) -> Unit,
    onNewNote: () -> Unit,
    onAddExpense: () -> Unit,
    onMarkNote: (Long, String) -> Unit,
    employees: List<Employee>,
    onAddEmployee: () -> Unit,
    onAttendance: (Long, String) -> Unit
) {
    if (selectedPage == "menu") {
        PageHeading("المزيد", "إدارة أقسام الشركة وأدوات النظام")
        val items = listOf(
            Triple("المنتجات", Icons.Filled.Inventory2, Blue), Triple("الآلات", Icons.Filled.Settings, Color(0xFF1499A8)),
            Triple("العملاء", Icons.Filled.Groups, Purple), Triple("الموردون", Icons.Filled.LocalShipping, Orange),
            Triple("الشفتات", Icons.Filled.CalendarMonth, Green), Triple("الملاحظات", Icons.Filled.Note, Blue),
            Triple("المصاريف", Icons.Filled.Payments, Red), Triple("التقارير", Icons.Filled.Assessment, Orange),
            Triple("الإعدادات", Icons.Filled.Tune, SoftBlue), Triple("النسخ الاحتياطي", Icons.Filled.CloudUpload, Purple)
        )
        items.chunked(2).forEach { line ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                line.forEach { item ->
                    QuickAction(item.first, item.second, item.third) {
                        when (item.first) {
                            "المصاريف" -> onAddExpense()
                            else -> onOpenPage(item.first)
                        }
                    }
                }
                if (line.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        GlassPanel(Modifier.fillMaxWidth()) {
            SectionTitle("مساحة العمل", Icons.Filled.Business)
            Text("KHALDI PLAST ERP · Fresh 1.0.0", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("البيانات محفوظة محلياً على هذا الجهاز. أنشئ نسخاً احتياطية بانتظام قبل تغيير الهاتف.", color = SoftBlue, fontSize = 11.sp)
        }
    } else {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            SmallGlassButton("رجوع", Icons.Filled.ArrowForward, onBack)
            Spacer(Modifier.width(10.dp))
            Text(selectedPage, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
        }
        when (selectedPage) {
            "الملاحظات" -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("إجمالي الطلبيات", fmtInt(notes.size), "طلب", Icons.Filled.ReceiptLong, Blue, null, Modifier.weight(1f))
                    MetricCard("بانتظار التنفيذ", fmtInt(notes.count { it.status == "بانتظار التنفيذ" }), "طلب", Icons.Filled.AccessTime, Orange, null, Modifier.weight(1f))
                }
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("قائمة الطلبيات والملاحظات", Icons.Filled.Note)
                    if (notes.isEmpty()) EmptyState("لا توجد ملاحظات بعد", "أضف طلبية عميل أو تذكيراً للتنفيذ", Icons.Filled.Note)
                    notes.forEach { n ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(n.customer, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                                    Text("${n.product} · ${fmtInt(n.quantity)} قطعة", color = SoftBlue, fontSize = 10.sp)
                                }
                                StatusPill(n.status)
                            }
                            if (n.details.isNotBlank()) Text(n.details, color = SoftBlue, fontSize = 10.sp)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("التسليم: ${n.dueDate}", color = SoftBlue, fontSize = 9.sp)
                                SmallGlassButton(if (n.status == "مكتملة") "إعادة فتح" else "إكمال الطلب", Icons.Filled.Check) { onMarkNote(n.id, if (n.status == "مكتملة") "بانتظار التنفيذ" else "مكتملة") }
                            }
                        }
                        Divider(color = Color.White.copy(.8f))
                    }
                }
                PrimaryAction("إضافة ملاحظة جديدة", Icons.Filled.Add, Modifier.fillMaxWidth(), onNewNote)
            }
            "الشفتات" -> {
                val shifts = listOf(Triple("الصباحية", "06:00 – 14:00", Orange), Triple("المسائية", "14:00 – 22:00", Blue), Triple("الليلية", "22:00 – 06:00", Purple))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    shifts.forEach { sh ->
                        val count = employees.count { it.shift == sh.first }
                        val present = employees.count { it.shift == sh.first && it.status == "حاضر" }
                        GlassPanel(Modifier.weight(1f), radius = 18) {
                            IconBadge(Icons.Filled.Schedule, sh.third, 34)
                            Text(sh.first, color = Ink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(sh.second, color = SoftBlue, fontSize = 8.sp)
                            Text("$present / $count", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                            Text("عامل حاضر", color = SoftBlue, fontSize = 8.sp)
                        }
                    }
                }
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("العمال والحضور", Icons.Filled.Groups, "${employees.size} عامل")
                    if (employees.isEmpty()) EmptyState("لا توجد ملفات عمال", "أضف العمال ثم حدّد الشفت وحالة الحضور", Icons.Filled.PersonAdd)
                    employees.forEach { worker ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(Icons.Filled.Person, Blue, 38)
                            Column(Modifier.weight(1f)) {
                                Text(worker.name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("${worker.role} · ${worker.shift}", color = SoftBlue, fontSize = 9.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                StatusPill(worker.status)
                                SmallGlassButton("تغيير الحالة", Icons.Filled.Edit) { onAttendance(worker.id, when (worker.status) { "حاضر" -> "غائب"; "غائب" -> "راحة"; else -> "حاضر" }) }
                            }
                        }
                        Divider(color = Color.White.copy(.8f))
                    }
                }
                PrimaryAction("إضافة عامل", Icons.Filled.PersonAdd, Modifier.fillMaxWidth(), onAddEmployee)
            }
            "المنتجات" -> {
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("كتالوج منتجات الشركة", Icons.Filled.Inventory2)
                    products.forEach { ProductStockRow(it) }
                }
            }
            "الآلات" -> {
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("معدات الإنتاج", Icons.Filled.Settings)
                    (1..4).forEach { index ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            ProductImage("machine", Modifier.size(100.dp))
                            Column(Modifier.weight(1f)) {
                                Text("آلة الحقن $index", color = Ink, fontWeight = FontWeight.Bold)
                                Text("بانتظار تسجيل بيانات الآلة", color = SoftBlue, fontSize = 10.sp)
                            }
                            StatusPill("غير متصلة")
                        }
                    }
                    Text("لا توجد قراءات حساسات حتى الآن. هذه الشاشة جاهزة لعرض حالة الآلات بعد ربط وحدات القياس.", color = SoftBlue, fontSize = 10.sp)
                }
            }
            "العملاء" -> {
                val names = invoices.map { it.customer }.distinct()
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("سجل العملاء", Icons.Filled.Groups)
                    if (names.isEmpty()) EmptyState("لا توجد ملفات عملاء مسجلة", "ستظهر أسماء العملاء بعد إدخال أول فاتورة", Icons.Filled.Groups)
                    names.forEach { name -> Text(name, color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp)); Divider(color = Color.White) }
                }
            }
            "الموردون" -> GlassPanel(Modifier.fillMaxWidth()) { SectionTitle("سجل الموردين", Icons.Filled.LocalShipping); EmptyState("لا يوجد موردون مسجلون", "أضف ملفات الموردين عند تفعيل إدارة المشتريات", Icons.Filled.LocalShipping) }
            "التقارير" -> {
                MetricGrid(listOf(
                    Triple("المبيعات", fmt(totals.sales), Icons.Filled.Payments to Green),
                    Triple("الإنتاج", fmtInt(totals.production), Icons.Filled.BarChart to Blue),
                    Triple("المخزون", fmtInt(totals.stock), Icons.Filled.Inventory2 to Orange),
                    Triple("الفواتير", fmtInt(totals.invoiceCount), Icons.Filled.ReceiptLong to Purple)
                ))
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("ملخص أداء الشركة", Icons.Filled.Assessment)
                    Text("تُحتسب المؤشرات من السجلات الفعلية في قاعدة البيانات المحلية.", color = SoftBlue, fontSize = 11.sp)
                }
            }
            "الإعدادات" -> {
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("إعدادات التطبيق", Icons.Filled.Tune)
                    Text("اللغة: العربية", color = Ink, fontWeight = FontWeight.Bold)
                    Text("العملة: الدينار الجزائري (دج)", color = Ink, fontWeight = FontWeight.Bold)
                    Text("التخزين: قاعدة بيانات SQLite محلية", color = Ink, fontWeight = FontWeight.Bold)
                    Text("النسخة: 1.0.0 مستقلة", color = SoftBlue, fontSize = 10.sp)
                }
            }
            "النسخ الاحتياطي" -> {
                GlassPanel(Modifier.fillMaxWidth()) {
                    SectionTitle("النسخ الاحتياطي", Icons.Filled.CloudUpload)
                    EmptyState("النسخ والاستعادة قيد الإعداد", "لا تعتمد على هذه النسخة وحدها لحماية بيانات المصنع. احتفظ بنسخة من بيانات الجهاز.", Icons.Filled.Info)
                }
            }
        }
    }
}

@Composable
private fun ProductImage(key: String, modifier: Modifier = Modifier) {
    val id = when (key) {
        "crate_blue" -> R.drawable.crate_blue
        "crate_green" -> R.drawable.crate_green
        "crate_black" -> R.drawable.crate_black
        "machine", "machine_injection" -> R.drawable.machine_injection
        "pellets_blue" -> R.drawable.pellets_blue
        "regrind_white" -> R.drawable.regrind_white
        else -> R.drawable.crate_blue
    }
    Image(painterResource(id), contentDescription = key, contentScale = ContentScale.Fit, modifier = modifier)
}

@Composable
private fun RingProgress(progress: Float, color: Color, label: String, size: Int) {
    val animated by animateFloatAsState(progress.coerceIn(0f, 1f), tween(650, easing = FastOutSlowInEasing), label = "ring")
    Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(Color(0xFFD8E9F6), -90f, 360f, false, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round))
            if (animated > 0f) drawArc(color, -90f, animated * 360f, false, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round))
        }
        Text(label, color = Ink, fontSize = if (size < 50) 9.sp else 11.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun SalesLineChart(points: List<SalesPoint>, modifier: Modifier = Modifier) {
    val values = points.map { it.amount }
    Column(modifier) {
        if (values.isEmpty() || values.all { it <= 0f }) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.BarChart, null, tint = Color(0xFF8BB9DD), modifier = Modifier.size(38.dp))
                    Text("لا توجد بيانات كافية للرسم البياني", color = SoftBlue, fontSize = 11.sp)
                    Text("ستظهر حركة المبيعات بعد تسجيل الفواتير", color = SoftBlue.copy(.8f), fontSize = 9.sp)
                }
            }
        } else {
            Canvas(Modifier.fillMaxWidth().weight(1f)) {
                val left = 30.dp.toPx(); val right = size.width - 6.dp.toPx(); val top = 9.dp.toPx(); val bottom = size.height - 21.dp.toPx()
                val grid = android.graphics.Paint().apply { color = android.graphics.Color.argb(70, 255, 255, 255); strokeWidth = 1.dp.toPx(); pathEffect = android.graphics.DashPathEffect(floatArrayOf(5f, 7f), 0f) }
                repeat(4) { i -> val y = top + (bottom - top) * i / 3f; drawContext.canvas.nativeCanvas.drawLine(left, y, right, y, grid) }
                val maxV = max(1f, values.maxOrNull() ?: 1f)
                val path = Path(); val fill = Path()
                values.forEachIndexed { i, v ->
                    val x = left + (right - left) * (if (values.size == 1) .5f else i.toFloat() / (values.size - 1))
                    val y = bottom - (v / maxV) * (bottom - top) * .82f
                    if (i == 0) { path.moveTo(x, y); fill.moveTo(x, bottom); fill.lineTo(x, y) } else { path.lineTo(x, y); fill.lineTo(x, y) }
                }
                fill.lineTo(right, bottom); fill.close()
                drawPath(fill, Brush.verticalGradient(listOf(Color(0x6677BFFF), Color(0x0877BFFF))))
                drawPath(path, Blue, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                val lastIndex = values.lastIndex; val last = values.last(); val x = left + (right - left) * (if (values.size == 1) .5f else lastIndex.toFloat() / lastIndex); val y = bottom - (last / maxV) * (bottom - top) * .82f
                drawCircle(Color.White, 7.dp.toPx(), Offset(x, y)); drawCircle(Blue, 4.dp.toPx(), Offset(x, y))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                points.forEach { point -> Text(monthName(point.month), color = SoftBlue, fontSize = 9.sp) }
            }
        }
    }
}

@Composable
private fun BarChart(values: List<Float>, modifier: Modifier = Modifier) {
    if (values.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) { Text("لا توجد عمليات إنتاج مسجلة", color = SoftBlue, fontSize = 10.sp) }
    } else Canvas(modifier) {
        val maxV = max(1f, values.maxOrNull() ?: 1f)
        val gap = 9.dp.toPx(); val barWidth = (size.width - gap * (values.size + 1)) / values.size
        repeat(4) { i ->
            val y = size.height * (i + 1) / 5f
            drawLine(Color.White.copy(.6f), Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
        }
        values.forEachIndexed { i, v ->
            val h = (v / maxV) * size.height * .78f
            val x = gap + i * (barWidth + gap)
            drawRoundRect(Brush.verticalGradient(listOf(Cyan, Blue)), Offset(x, size.height - h), Size(barWidth, h), androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()))
        }
    }
}

@Composable
private fun MiniDonut(values: List<Float>, center: String = "") {
    val positive = values.filter { it > 0f }
    val total = positive.sum()
    val palette = listOf(Blue, Green, Orange, Purple, Cyan, Red)
    Box(Modifier.fillMaxWidth().height(88.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(76.dp)) {
            val stroke = 10.dp.toPx()
            if (total <= 0f) drawArc(Color(0xFFD0E4F3), -90f, 360f, false, style = Stroke(stroke))
            else {
                var start = -90f
                positive.forEachIndexed { index, value ->
                    val sweep = (value / total) * 360f
                    drawArc(palette[index % palette.size], start, sweep, false, style = Stroke(stroke, cap = StrokeCap.Butt))
                    start += sweep
                }
            }
        }
        Text(center.ifBlank { if (total <= 0f) "0" else fmtInt(total.toInt()) }, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
private fun EmptyState(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxWidth().padding(vertical = 17.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Icon(icon, null, tint = Color(0xFF78A9D4), modifier = Modifier.size(32.dp))
        Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(detail, color = SoftBlue, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun StatusPill(status: String) {
    val color = when (status) { "مدفوعة", "مكتمل", "مؤكد" -> Green; "متأخر", "متوقف" -> Red; else -> Orange }
    Text(status, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(30.dp)).background(color.copy(.13f)).padding(horizontal = 8.dp, vertical = 3.dp))
}

@Composable
private fun PrimaryAction(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.shadow(9.dp, RoundedCornerShape(19.dp)).clip(RoundedCornerShape(19.dp)).background(Brush.linearGradient(listOf(Color(0xFF13B7FF), Color(0xFF087BEF)))).border(1.dp, Color.White.copy(.75f), RoundedCornerShape(19.dp)).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 13.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White)
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
    }
}

@Composable
private fun SecondaryAction(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(17.dp)).background(Color(0xC9F7FCFF)).border(1.dp, Color.White, RoundedCornerShape(17.dp)).clickable { onClick() }.padding(horizontal = 8.dp, vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text(text, color = Ink, fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun BottomNavigation(selected: AppTab, onSelect: (AppTab) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp).shadow(15.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp)).background(Brush.verticalGradient(listOf(Color(0xC3E9F6FF), Color(0xC409559D)))).border(1.dp, Color.White.copy(.75f), RoundedCornerShape(30.dp)).padding(5.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        AppTab.values().reversed().forEach { item ->
            val active = item == selected
            Column(Modifier.weight(1f).clip(RoundedCornerShape(23.dp)).background(if (active) Brush.linearGradient(listOf(Color(0xFF13BFFF), Color(0xFF067BED))) else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))).border(if (active) 1.dp else 0.dp, if (active) Color(0xFFB7F5FF) else Color.Transparent, RoundedCornerShape(23.dp)).clickable { onSelect(item) }.padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(item.icon, null, tint = if (active) Color.White else Color(0xFFE6F5FF), modifier = Modifier.size(25.dp))
                Text(item.label, color = if (active) Color.White else Color(0xFFE3F2FF), fontWeight = if (active) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ErpFormDialog(kind: FormKind, database: ErpDatabase, products: List<Product>, onDismiss: () -> Unit, onSave: (() -> Unit) -> Unit) {
    var customer by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    var price by remember { mutableStateOf("0") }
    var details by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf(defaultDueDate()) }
    var machine by remember { mutableStateOf("الآلة 1") }
    var status by remember { mutableStateOf("مدفوعة") }
    var delta by remember { mutableStateOf("0") }
    val selectableProducts = if (kind == FormKind.INVOICE || kind == FormKind.PRODUCTION || kind == FormKind.NOTE) products.filter { it.category == "صناديق" } else products
    var selectedProductId by remember { mutableLongStateOf(selectableProducts.firstOrNull()?.id ?: -1L) }
    val product = selectableProducts.firstOrNull { it.id == selectedProductId } ?: selectableProducts.firstOrNull()
    val title = when (kind) { FormKind.INVOICE -> "إنشاء فاتورة جديدة"; FormKind.PRODUCTION -> "تسجيل عملية إنتاج"; FormKind.STOCK -> "تعديل رصيد المخزون"; FormKind.NOTE -> "إضافة ملاحظة / طلبية"; FormKind.EXPENSE -> "تسجيل مصروف"; FormKind.EMPLOYEE -> "إضافة عامل جديد" }
    var expenseTitle by remember { mutableStateOf("") }
    var shiftChoice by remember { mutableStateOf("الصباحية") }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(.92f).clip(RoundedCornerShape(28.dp)).background(Color(0xFFF0F8FF)).border(1.dp, Color.White, RoundedCornerShape(28.dp)).padding(17.dp).heightIn(max = 650.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, null, tint = Ink) }
            }
            if (kind == FormKind.INVOICE || kind == FormKind.NOTE || kind == FormKind.EMPLOYEE) {
                KpField(when (kind) { FormKind.INVOICE -> "اسم العميل"; FormKind.EMPLOYEE -> "اسم العامل"; else -> "اسم العميل / الجهة" }, customer, { customer = it })
            }
            if (kind in listOf(FormKind.INVOICE, FormKind.PRODUCTION, FormKind.STOCK, FormKind.NOTE)) {
                Text("المنتج", color = SoftBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    selectableProducts.forEach { p ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (p.id == selectedProductId) Color(0xFFD3EDFF) else Color.White).border(1.dp, if (p.id == selectedProductId) Blue else Color(0xFFDCEAF5), RoundedCornerShape(14.dp)).clickable { selectedProductId = p.id }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                            ProductImage(p.image, Modifier.size(48.dp))
                            Column(Modifier.weight(1f)) { Text(p.name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text("${p.code} · متوفر ${fmtInt(p.stock)}", color = SoftBlue, fontSize = 9.sp) }
                            if (p.id == selectedProductId) Icon(Icons.Filled.CheckCircle, null, tint = Blue)
                        }
                    }
                }
            }
            when (kind) {
                FormKind.INVOICE -> {
                    KpField("الكمية", quantity, { quantity = it }, KeyboardType.Number)
                    KpField("سعر الوحدة (دج)", price, { price = it }, KeyboardType.Number)
                    Text("الإجمالي: ${fmt((quantity.toLongOrNull() ?: 0) * (price.toLongOrNull() ?: 0))} دج", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("مدفوعة", "آجلة").forEach { ChoiceChip(it, status == it) { status = it } } }
                }
                FormKind.PRODUCTION -> {
                    KpField("الكمية المنتجة", quantity, { quantity = it }, KeyboardType.Number)
                    KpField("الآلة", machine, { machine = it })
                }
                FormKind.STOCK -> {
                    Text("الرصيد الحالي: ${product?.stock ?: 0} ${product?.unit ?: ""}", color = Ink, fontWeight = FontWeight.Bold)
                    KpField("الكمية المضافة أو المسحوبة (+ / -)", delta, { delta = it }, KeyboardType.Number)
                }
                FormKind.NOTE -> {
                    KpField("الكمية المطلوبة", quantity, { quantity = it }, KeyboardType.Number)
                    KpField("تاريخ التسليم (YYYY-MM-DD)", dueDate, { dueDate = it })
                    KpField("تفاصيل الطلبية", details, { details = it })
                }
                FormKind.EMPLOYEE -> {
                    KpField("المنصب / المهمة", details, { details = it })
                    Text("الشفت", color = SoftBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("الصباحية", "المسائية", "الليلية").forEach { ChoiceChip(it, shiftChoice == it) { shiftChoice = it } } }
                }
                FormKind.EXPENSE -> {
                    KpField("بيان المصروف", expenseTitle, { expenseTitle = it })
                    KpField("المبلغ (دج)", price, { price = it }, KeyboardType.Number)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                PrimaryAction("حفظ", Icons.Filled.Check, Modifier.weight(1f)) {
                    when (kind) {
                        FormKind.INVOICE -> onSave { requireNotNull(product); database.addInvoice(customer, product.id, quantity.toInt(), price.toLong(), status) }
                        FormKind.PRODUCTION -> onSave { requireNotNull(product); database.addProduction(product.id, quantity.toInt(), machine, "صباحية") }
                        FormKind.STOCK -> onSave { requireNotNull(product); database.adjustStock(product.id, delta.toInt()) }
                        FormKind.NOTE -> onSave { requireNotNull(product); database.addNote(customer, product.id, quantity.toInt(), dueDate, details) }
                        FormKind.EXPENSE -> onSave { database.addExpense(expenseTitle, price.toLong()) }
                        FormKind.EMPLOYEE -> onSave { database.addEmployee(customer, details, shiftChoice) }
                    }
                }
                SecondaryAction("إلغاء", Icons.Filled.Close, Modifier.weight(1f), onDismiss)
            }
        }
    }
}


@Composable
private fun KpField(label: String, value: String, onChange: (String) -> Unit, keyboard: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label, fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(15.dp), keyboardOptions = KeyboardOptions(keyboardType = keyboard), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFFB8D4EA), focusedLabelColor = Blue, unfocusedLabelColor = SoftBlue, focusedTextColor = Ink, unfocusedTextColor = Ink, cursorColor = Blue))
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(label, modifier = Modifier.clip(RoundedCornerShape(25.dp)).background(if (selected) Blue else Color.White).border(1.dp, if (selected) Blue else Color(0xFFD8E7F3), RoundedCornerShape(25.dp)).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 8.dp), color = if (selected) Color.White else Ink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
}
