plugins {
    id("com.android.application")
}
android {
    namespace = "dz.khaldiplast.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "dz.khaldiplast.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
dependencies { implementation("androidx.appcompat:appcompat:1.6.1") }
