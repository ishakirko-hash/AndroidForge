/* KHALDI PLAST ERP 5.0 — Reference-matched interface layer.
   The supplied six screen references define the visual system. Business logic,
   storage, validation, forms and record actions remain in the existing ERP core. */
(function () {
  'use strict';
  var U = window.KPU, K = U.K, V = U.V, S = U.S, W = U.views, X = U.extraActions || (U.extraActions = {});
  var esc = U.esc;
  var rawIcon = V.icon;
  var ICON_ALIAS = { grid: 'table', 'file-text': 'note', 'file-plus': 'note', store: 'building', package: 'box', layers: 'box', printer: 'print', filter: 'sliders', play: 'check', refresh: 'undo', 'user-plus': 'users' };
  V.icon = function (name, size, cls) { return rawIcon(ICON_ALIAS[name] || name, size, cls); };
  var PALETTE = { blue: '#087FE8', cyan: '#19B8EA', green: '#15B981', amber: '#F59E0B', red: '#F0445B', purple: '#8359EC', teal: '#12A6B4', slate: '#6D8CA9' };
  var ROUTE_TITLE = {
    home: 'لوحة التحكم الرئيسية', sales: 'المبيعات', stock: 'المخزون', production: 'الإنتاج',
    workers: 'الشفتات والعمال', notes: 'الملاحظات والطلبات', invoices: 'الفواتير', customers: 'العملاء',
    suppliers: 'الموردون', purchases: 'المشتريات', expenses: 'المصاريف', reports: 'التقارير',
    payroll: 'الأجور والرواتب', maintenance: 'صيانة الآلات', settings: 'الإعدادات', customize: 'تخصيص الواجهة',
    assistant: 'المساعد الذكي', backup: 'النسخ الاحتياطي', more: 'جميع الأقسام', transactions: 'سجل العمليات',
    prodtable: 'جدول الإنتاج', cashbook: 'دفتر الصندوق', debts: 'الديون', profit: 'الأرباح', quotes: 'عروض الأسعار',
    crm: 'إدارة العملاء المحتملين', stocktake: 'الجرد', insights: 'التحليلات', analysis: 'التحليل المالي'
  };

  function n(v) { return Number(v || 0); }
  function fmt(v) { return K.groupInt(Math.round(n(v))); }
  function qty(v) { return K.fmtQty(n(v)); }
  function money(v) { return U.money(v || 0); }
  function moneyText(v) { return U.moneyTxt(v || 0); }
  function live(arr) { return K.live(arr || []); }
  function cardIcon(name, tone) {
    return '<span class="kp-iconbox ' + (tone || 'blue') + '">' + V.icon(name || 'box', 25) + '</span>';
  }
  function sectionHead(title, icon, side) {
    return '<div class="kp-section-head"><div class="kp-section-title">' + cardIcon(icon || 'bars', 'blue') + '<h3>' + esc(title) + '</h3></div>' + (side || '') + '</div>';
  }
  function glass(title, icon, body, extra) {
    return '<section class="kp-glass">' + sectionHead(title, icon, extra) + body + '</section>';
  }
  function dateText(date) {
    var p = String(date).split('-').map(Number), locale = { ar: 'ar-u-nu-latn', fr: 'fr-FR', en: 'en-GB' }[U.lang()] || 'ar-u-nu-latn';
    try { return new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(p[0], p[1] - 1, p[2])); }
    catch (e) { return K.fmtDate(date); }
  }
  function dateChip(date) {
    return '<div class="kp-date-chip">' + cardIcon('calendar', 'blue') + '<span><small>' + esc(U.dayName(date)) + '</small><bdi>' + esc(dateText(date)) + '</bdi></span><span class="kp-chevron">⌄</span></div>';
  }
  function rangeChip(from, to) {
    var end = to > K.today() ? K.today() : to;
    return '<div class="kp-date-chip">' + cardIcon('calendar', 'blue') + '<span><small>الفترة المحددة</small><bdi>' + esc(K.fmtDate(from)) + ' – ' + esc(K.fmtDate(end)) + '</bdi></span><span class="kp-chevron">⌄</span></div>';
  }
  function pageTitle(title, sub, icon, right) {
    return '<div class="kp-page-title"><div class="kp-title-left">' + cardIcon(icon || 'box', 'blue') + '<div><h1>' + esc(title) + '</h1>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</div></div>' + (right || '') + '</div>';
  }
  function kpi(label, value, tone, icon, foot, act, id) {
    return '<button class="kp-kpi ' + (tone || 'blue') + '" ' + (act ? 'data-act="' + act + '" data-id="' + (id || '') + '"' : 'type="button"') + '>' +
      cardIcon(icon || 'bars', tone || 'blue') + '<span class="kp-kpi-label">' + esc(label) + '</span><b class="kp-kpi-value">' + value + '</b>' +
      '<span class="kp-kpi-foot">' + (foot || '') + '</span><span class="kp-mini-bars">' + V.icon('bars', 17) + '</span></button>';
  }
  function delta(cur, prev) {
    if (prev == null || !prev) return '<span class="kp-delta neutral">—</span>';
    var p = Math.round((cur - prev) * 100 / Math.abs(prev));
    return '<span class="kp-delta ' + (p >= 0 ? 'positive' : 'negative') + '">' + (p >= 0 ? '▲ +' : '▼ ') + Math.abs(p) + '%</span>';
  }
  function ring(pct, color) {
    var p = Math.max(0, Math.min(100, n(pct)));
    return '<div class="kp-ring" style="--ring-p:' + p + '%;--ring-color:' + (color || PALETTE.blue) + '"><b>' + Math.round(p) + '%</b></div>';
  }
  function monthChart(ym, mode) {
    var ms = K.monthSeries(U.D, ym, 6);
    var vals = ms.map(function (x) { return mode === 'production' ? K.monthlyReport(U.D, x.ym).good : x.sales / 100; });
    var labs = ms.map(function (x) { return U.monthLabel(x.ym).split(' ')[0].slice(0, 5); });
    return V.area([{ values: vals, color: '#087FE8' }], labs, 108);
  }
  function daysProdChart() {
    var td = K.today(), labels = [], products = U.act(U.D.products).slice(0, 2), series = products.map(function (p) { return { p: p, values: [] }; });
    for (var i = 6; i >= 0; i--) {
      var d = K.addDays(td, -i), rows = live(U.D.production).filter(function (x) { return x.date === d; });
      labels.push(d.slice(8) + '/' + d.slice(5, 7));
      series.forEach(function (s) { s.values.push(K.sum(rows.filter(function (x) { return x.productId === s.p.id; }), function (x) { return x.good; })); });
    }
    var Wd = 320, Hd = 110, L = 34, B = 22, T = 8, max = 1, bw = (Wd - L - 5) / Math.max(1, labels.length);
    series.forEach(function (s) { s.values.forEach(function (v) { if (v > max) max = v; }); });
    function nice(x) { var p = Math.pow(10, Math.floor(Math.log(x || 1) / Math.LN10)), f = x / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; }
    max = nice(max); var ih = Hd - T - B, svg = '';
    for (var g = 0; g <= 3; g++) { var y = T + ih - ih * g / 3; svg += '<line x1="' + L + '" x2="' + Wd + '" y1="' + y + '" y2="' + y + '" class="grid"/><text x="' + (L - 4) + '" y="' + (y + 3) + '" class="axis" text-anchor="end">' + K.groupInt(max * g / 3) + '</text>'; }
    series.forEach(function (s, si) { s.values.forEach(function (v, j) { var gap = products.length > 1 ? 3 : 0, w = products.length > 1 ? bw * .30 : bw * .62, x = L + j * bw + bw * .18 + si * (w + gap), h = v / max * ih, y = T + ih - h; if (v > 0) svg += '<rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + Math.max(1.5, h).toFixed(1) + '" rx="2.8" fill="' + (si ? '#24B6E9' : '#087FE8') + '"/>'; }); });
    labels.forEach(function (lb, j) { var x = L + j * bw + bw / 2; svg += '<text x="' + x.toFixed(1) + '" y="' + (Hd - 5) + '" class="axis" text-anchor="middle">' + lb + '</text>'; });
    var legend = series.map(function (s, i) { return '<span><i class="' + (i ? 'cyan' : 'blue') + '"></i>' + esc(s.p.name) + '</span>'; }).join('');
    return '<svg class="chart" viewBox="0 0 ' + Wd + ' ' + Hd + '" role="img">' + svg + '</svg><div class="kp-chart-legend">' + (legend || '<span>الإنتاج حسب السجل</span>') + '</div>';
  }
  function crateAsset(color) {
    var c = String(color || 'blue').toLowerCase();
    if (c.indexOf('green') >= 0 || c.indexOf('vert') >= 0 || c.indexOf('أخضر') >= 0) return 'img/3d/crate-green.png';
    if (c.indexOf('black') >= 0 || c.indexOf('noir') >= 0 || c.indexOf('أسود') >= 0) return 'img/3d/crate-black.png';
    if (c.indexOf('red') >= 0 || c.indexOf('rouge') >= 0 || c.indexOf('أحمر') >= 0) return '';
    return 'img/3d/crate-blue.png';
  }
  function productImage(p, size) {
    var src = p ? crateAsset(p.color) : '';
    return src ? '<img class="kp-product-art" style="width:' + (size || 100) + '%" src="' + src + '" alt="' + esc(p.name) + '">' : V.crate(p ? p.color : 'blue', 72);
  }
  function materialImage(m) {
    var s = (m && m.name || '').toLowerCase();
    var src = (s.indexOf('broy') >= 0 || s.indexOf('مكسر') >= 0) ? 'img/3d/regrind-white.png' : 'img/3d/pellets-blue.png';
    return '<img class="kp-material-art" src="' + src + '" alt="' + esc(m ? m.name : 'مادة خام') + '">';
  }
  function machineImage() { return '<img class="kp-machine-art" src="img/3d/machine-injection.png" alt="آلة حقن البلاستيك">'; }
  function navAction(icon, label, act, id, cls) {
    var attr = act === 'new_item' ? 'data-kind' : 'data-id';
    return '<button class="kp-action ' + (cls || '') + '" data-act="' + act + '"' + (id ? ' ' + attr + '="' + id + '"' : '') + '>' + V.icon(icon, 21) + '<span>' + esc(label) + '</span></button>';
  }
  function periodButtons(type, value, pairs) {
    return '<div class="kp-segment">' + pairs.map(function (x) { return '<button class="' + (x[0] === value ? 'on' : '') + '" data-act="' + type + '" data-id="' + x[0] + '">' + esc(x[1]) + '</button>'; }).join('') + '</div>';
  }
  function percentRing(v, tone) { return ring(v, PALETTE[tone] || PALETTE.blue); }
  function lowBadge(low) { return low ? '<span class="kp-status danger">مخزون منخفض</span>' : '<span class="kp-status success">متوفر</span>'; }
  function rangeFor(p) {
    var td = K.today();
    if (p === 'today') return { from: td, to: td };
    if (p === 'week') return { from: K.addDays(td, -6), to: td };
    if (p === 'year') return { from: td.slice(0, 4) + '-01-01', to: td.slice(0, 4) + '-12-31' };
    return K.monthRange(S.ym || td.slice(0, 7));
  }
  function logo() {
    return '<div class="kp-brand-lockup"><img class="kp-mark" src="img/logo_mark.png" alt="KP"><img class="kp-wordmark" src="img/logo_wordmark.png" alt="KHALDI PLAST — SHAPING TOMORROW"></div>';
  }

  /* ---------- HOME: matches the first reference composition ---------- */
  W.home = function () {
    var D = U.D, td = K.today(), ym = td.slice(0, 7), cur = K.monthlyReport(D, ym), prev = K.monthlyReport(D, K.addMonths(ym, -1));
    var productionToday = K.dashboard(D, td).todayProduction;
    var totalStock = K.sum(D.products, function (p) { return p.stock; });
    var sales = cur.sales, expenses = cur.expenses;
    var prodBy = {}, prodRows = live(D.production).filter(function (x) { return x.date === td; });
    prodRows.forEach(function (x) { prodBy[x.productId] = (prodBy[x.productId] || 0) + x.good; });
    if (!productionToday) live(D.production).filter(function (x) { return x.date.slice(0, 7) === ym; }).forEach(function (x) { prodBy[x.productId] = (prodBy[x.productId] || 0) + x.good; });
    var topProducts = U.act(D.products).slice(0, 2), totalProduced = K.sum(Object.keys(prodBy), function (id) { return prodBy[id]; });
    var h = '<div class="kp-page kp-home">';
    h += '<div class="kp-welcome"><div class="kp-welcome-copy">' + cardIcon('bars', 'blue') + '<div><b>مرحباً بك</b><span>لوحة التحكم الرئيسية</span></div></div>' + dateChip(td) + '</div>';
    h += '<div class="kp-kpi-grid kp-two">' +
      kpi('المبيعات', money(sales), 'green', 'box', delta(sales, prev.sales), 'kpi_go', 'salesmonth') +
      kpi('الإنتاج', fmt(productionToday || cur.good) + ' <small>قطعة</small>', 'blue', 'factory', '<span class="kp-delta positive">' + (productionToday ? 'إنتاج اليوم' : 'هذا الشهر') + '</span>', 'kpi_go', 'prodtoday') +
      kpi('المخزون', fmt(totalStock) + ' <small>قطعة</small>', 'amber', 'box', '<span class="kp-delta neutral">منتجات جاهزة</span>', 'kpi_go', 'stock') +
      kpi('المصاريف', money(expenses), 'red', 'wallet', delta(expenses, prev.expenses), 'kpi_go', 'expmonth') + '</div>';
    h += glass('المبيعات الشهرية', 'bars', '<div class="kp-chart-wrap">' + monthChart(ym) + '</div>', '<span class="kp-dropdown">آخر 6 أشهر　⌄</span>');
    h += '<div class="kp-product-pair">' + topProducts.map(function (p, i) {
      var q = prodBy[p.id] || 0, pct = totalProduced ? Math.round(q * 100 / totalProduced) : 0;
      return '<button class="kp-product-card" data-act="kpi_go" data-id="prodmonth"><div class="kp-product-visual">' + productImage(p, 100) + '</div><div class="kp-product-meta"><b>' + esc(p.name) + '</b><small>إنتاج اليوم</small><strong>' + fmt(q) + '</strong><small>قطعة</small></div>' + ring(pct, i === 0 ? PALETTE.blue : PALETTE.green) + '</button>';
    }).join('') + '</div>';
    h += '<div class="kp-shortcuts">' +
      navAction('users', 'العملاء', 'goto', 'customers') +
      navAction('box', 'المنتجات', 'goto', 'stock') +
      navAction('machine', 'الآلات', 'goto', 'maintenance') +
      navAction('note', 'التقارير', 'goto', 'reports') + '</div>';
    var low = K.dashboard(D, td).lowProducts.length + K.dashboard(D, td).lowMaterials.length;
    if (low) h += '<button class="kp-inline-alert" data-act="goto" data-id="stock">' + cardIcon('alert', 'red') + '<span>يوجد ' + low + ' أصناف تحتاج إلى مراجعة المخزون</span>' + V.icon('chevL', 18) + '</button>';
    h += '</div>';
    return h;
  };

  /* ---------- SALES: chart, donut mix, invoice register ---------- */
  W.sales = function () {
    var D = U.D, p = S.salesP || 'month', r = rangeFor(p), rep = K.periodReport(D, r.from, r.to), priorRange, prior;
    if (p === 'today') { var y = K.addDays(r.from, -1); priorRange = { from: y, to: y }; }
    else if (p === 'week') priorRange = { from: K.addDays(r.from, -7), to: K.addDays(r.to, -7) };
    else if (p === 'year') priorRange = { from: (Number(r.from.slice(0, 4)) - 1) + '-01-01', to: (Number(r.from.slice(0, 4)) - 1) + '-12-31' };
    else priorRange = K.monthRange(K.addMonths(S.ym || K.today().slice(0, 7), -1));
    prior = K.periodReport(D, priorRange.from, priorRange.to);
    var list = live(D.sales).filter(function (x) { return x.date >= r.from && x.date <= r.to; });
    var h = '<div class="kp-page kp-sales">' + pageTitle('المبيعات', 'إدارة الفواتير والعملاء والتحصيلات', 'bars', '');
    h += '<div class="kp-period-row">' + rangeChip(r.from, r.to) + periodButtons('salesp', p, [['today', 'يومي'], ['week', 'أسبوعي'], ['month', 'شهري'], ['year', 'سنوي']]) + '</div>';
    h += '<div class="kp-kpi-grid kp-three">' +
      kpi('إجمالي المبيعات', money(rep.sales), 'green', 'wallet', delta(rep.sales, prior.sales)) +
      kpi('عدد الفواتير', fmt(rep.salesCount), 'blue', 'note', delta(rep.salesCount, prior.salesCount)) +
      kpi('الكمية المباعة', fmt(rep.cratesSold) + ' <small>قطعة</small>', 'purple', 'box', delta(rep.cratesSold, prior.cratesSold)) + '</div>';
    var labs = [], vals = [];
    if (p === 'year') {
      for (var m = 1; m <= 12; m++) { var ym = r.from.slice(0, 4) + '-' + K.pad2(m), mr = K.monthRange(ym); labs.push(String(m)); vals.push(K.sum(list.filter(function (x) { return x.date >= mr.from && x.date <= mr.to; }), function (x) { return x.total / 100; })); }
    } else {
      var d = r.from, safety = 0; while (d <= r.to && safety++ < 40) { labs.push(d.slice(8) + '/' + d.slice(5, 7)); vals.push(K.sum(list.filter(function (x) { return x.date === d; }), function (x) { return x.total / 100; })); d = K.addDays(d, 1); }
    }
    h += glass('تحليل المبيعات', 'bars', '<div class="kp-chart-wrap">' + V.area([{ values: vals, color: '#087FE8' }], labs, 112) + '</div><div class="kp-chart-foot"><span>المبالغ المحصلة</span><b>' + money(rep.collected) + '</b></div>', '<span class="kp-dropdown">' + (p === 'today' ? 'اليوم' : p === 'week' ? 'أسبوع' : p === 'year' ? 'سنوي' : 'شهري') + '　⌄</span>');
    var byP = {}, byM = {};
    list.forEach(function (s) { s.items.forEach(function (it) { byP[it.productId] = (byP[it.productId] || 0) + it.qty * it.unitPrice; }); });
    live(D.payments).filter(function (x) { return x.date >= r.from && x.date <= r.to; }).forEach(function (x) { var k = x.method || 'cash'; byM[k] = (byM[k] || 0) + x.amount; });
    function donutBlock(map, type) {
      var keys = Object.keys(map), parts = keys.map(function (k, i) { var obj = type === 'product' ? K.byId(D.products, k) : null; return { name: obj ? obj.name : type === 'method' ? U.methodLabel(k) : k, value: map[k], color: [PALETTE.blue, PALETTE.green, PALETTE.amber, PALETTE.purple][i % 4], val: Math.round(map[k] * 100 / (K.sum(keys, function (x) { return map[x]; }) || 1)) + '%' }; });
      var tot = K.sum(keys, function (k) { return map[k]; });
      return keys.length ? '<div class="kp-donut-layout">' + V.donut(parts, type === 'product' ? (tot / 100 >= 1e6 ? (tot / 1e8).toFixed(2) + 'M' : K.fmtMoney(tot)) : fmt(tot / 100), 'دج') + '<div class="kp-legend">' + parts.map(function (x) { return '<div><i style="background:' + x.color + '"></i><span>' + esc(x.name) + '</span><b>' + x.val + '</b></div>'; }).join('') + '</div></div>' : '<div class="kp-empty-mini">لا توجد بيانات في الفترة المحددة</div>';
    }
    h += '<div class="kp-two-panels">' + glass('المبيعات حسب المنتج', 'box', donutBlock(byP, 'product')) + glass('طرق الدفع', 'wallet', donutBlock(byM, 'method')) + '</div>';
    h += '<div class="kp-search-filter"><label class="kp-search"><span>' + V.icon('search', 19) + '</span><input id="salesq" data-bind="salesQ" type="search" value="' + esc(S.salesQ || '') + '" placeholder="بحث في الفواتير (رقم، اسم الزبون...)" autocomplete="off"></label>' +
      '<div class="kp-filter-select"><select id="kp-sales-filter" aria-label="تصفية الفواتير"><option value="all">كل الفواتير</option><option value="paid" ' + (S.salesF === 'paid' ? 'selected' : '') + '>مدفوعة</option><option value="unpaid" ' + (S.salesF === 'unpaid' ? 'selected' : '') + '>غير مدفوعة</option></select>' + V.icon('filter', 18) + '</div></div>';
    var q = (S.salesQ || '').toLowerCase();
    var invoices = U.newest(D.sales.filter(function (x) { var out = K.saleOutstanding(D, x.id); if (S.salesF === 'paid' && (x.voided || out > 0)) return false; if (S.salesF === 'unpaid' && (x.voided || out <= 0)) return false; return x.date >= r.from && x.date <= r.to && (!q || (U.invFull(x) + ' ' + U.custName(x.customerId)).toLowerCase().indexOf(q) >= 0); }));
    h += glass('آخر الفواتير', 'note', '<div class="kp-table-wrap"><table class="kp-table"><thead><tr><th>رقم الفاتورة</th><th>الزبون</th><th>التاريخ</th><th>الكمية</th><th>المبلغ</th><th>الحالة</th></tr></thead><tbody>' + (invoices.length ? invoices.slice(0, 8).map(function (x) {
      var out = K.saleOutstanding(D, x.id), status = x.voided ? ['ملغاة', 'danger'] : out <= 0 ? ['مدفوعة', 'success'] : K.salePaid(D, x.id) ? ['جزئية', 'warning'] : ['آجل', 'warning'];
      return '<tr class="kp-row-tap" data-act="tx" data-kind="sale" data-id="' + x.id + '"><td><bdi>#' + ('00000' + x.no).slice(-4) + '</bdi></td><td>' + esc(U.custName(x.customerId)) + '</td><td><bdi>' + esc(K.fmtDate(x.date)) + '</bdi></td><td>' + fmt(K.sum(x.items, function (i) { return i.qty; })) + '</td><td>' + K.fmtMoney(x.total) + '</td><td><span class="kp-status ' + status[1] + '">' + status[0] + '</span></td></tr>';
    }).join('') : '<tr><td colspan="6" class="kp-no-data">لا توجد فواتير في الفترة المحددة</td></tr>') + '</tbody></table></div>');
    h += '<div class="kp-bottom-actions">' + navAction('plus', 'فاتورة جديدة', 'new_sale', '', 'primary') + navAction('download', 'تصدير', 'export_sales') + navAction('printer', 'طباعة', 'print_sales') + navAction('share', 'مشاركة', 'kp_share_sales') + '</div></div>';
    return h;
  };

  /* Filter select is wired separately because the legacy delegate uses buttons. */
  function wireSalesFilter() {
    var el = U.$('#kp-sales-filter'); if (!el) return;
    el.onchange = function () { S.salesF = el.value; U.render(true); };
  }

  /* ---------- INVENTORY: stock overview, movement chart, product & material cards ---------- */
  W.stock = function () {
    var D = U.D, tab = S.stockTab || 'all', td = K.today(); S.stockTab = tab;
    var fin = K.sum(D.products, function (p) { return p.stock; }), raw = K.sum(D.materials, function (m) { return m.stock; });
    var showProducts = tab === 'all' || tab === 'finished', showMaterials = tab === 'all' || tab === 'raw';
    var items = [];
    if (showProducts) U.act(D.products).forEach(function (x) { var z = Object.assign({}, x); z._kind = 'product'; items.push(z); });
    if (showMaterials) U.act(D.materials).forEach(function (x) { var z = Object.assign({}, x); z._kind = 'material'; items.push(z); });
    var low = D.products.concat(D.materials).filter(function (x) { return !x.archived && x.minStock > 0 && x.stock <= x.minStock; });
    var h = '<div class="kp-page kp-stock">' + pageTitle('المخزون', 'متابعة جميع المواد الخام والمنتجات في المخزن', 'box', '<button class="kp-round-plus" data-act="new_item" data-kind="product">＋</button>');
    h += '<div class="kp-stock-head-tools"><label class="kp-search"><span>' + V.icon('search', 19) + '</span><input id="stockq" data-bind="stockQ" value="' + esc(S.stockQ || '') + '" type="search" placeholder="بحث عن منتج أو مادة..." autocomplete="off"></label><button class="kp-filter-button" data-act="stockf" data-id="all">' + V.icon('filter', 20) + '</button></div>';
    h += '<div class="kp-kpi-grid kp-four">' +
      kpi('إجمالي الأصناف', fmt(U.act(D.products).length + U.act(D.materials).length), 'blue', 'box', 'صنف') +
      kpi('المنتجات الجاهزة', fmt(fin) + ' <small>قطعة</small>', 'green', 'package', 'في المخزن') +
      kpi('المواد الخام', qty(raw) + ' <small>كجم</small>', 'amber', 'layers', 'متاحة') +
      kpi('أصناف منخفضة', fmt(low.length), 'red', 'alert', 'تحتاج مراجعة') + '</div>';
    var labs = [], inn = [], out = [];
    for (var i = 5; i >= 0; i--) {
      var ym = K.addMonths(td.slice(0, 7), -i), from = K.monthRange(ym), mm = D.movements.filter(function (m) {
        var kindOk = tab === 'all' ? (m.kind === 'product' || m.kind === 'material') : tab === 'raw' ? m.kind === 'material' : m.kind === 'product';
        return kindOk && m.date >= from.from && m.date <= from.to;
      });
      labs.push(U.monthLabel(ym).slice(0, 5)); inn.push(K.sum(mm.filter(function (m) { return m.qty > 0; }), function (m) { return m.qty; })); out.push(K.sum(mm.filter(function (m) { return m.qty < 0; }), function (m) { return -m.qty; }));
    }
    var distItems = tab === 'all' ? U.act(D.products).concat(U.act(D.materials)) : (tab === 'raw' ? U.act(D.materials) : U.act(D.products));
    var parts = distItems.filter(function (x) { return x.stock > 0; }).map(function (x, ix) { return { value: x.stock, color: [PALETTE.blue, PALETTE.green, PALETTE.amber, PALETTE.purple][ix % 4], name: x.name, val: Math.round(x.stock * 100 / (K.sum(distItems, function (a) { return a.stock; }) || 1)) + '%' }; });
    var dist = parts.length ? '<div class="kp-donut-layout">' + V.donut(parts, tab === 'all' ? fmt(fin + raw) : qty(tab === 'raw' ? raw : fin), tab === 'raw' ? 'كجم' : tab === 'all' ? 'إجمالي' : 'قطعة') + '<div class="kp-legend">' + parts.slice(0, 4).map(function (p) { return '<div><i style="background:' + p.color + '"></i><span>' + esc(p.name) + '</span><b>' + p.val + '</b></div>'; }).join('') + '</div></div>' : '<div class="kp-empty-mini">لا توجد كميات مسجلة بعد</div>';
    h += '<div class="kp-two-panels">' + glass('حركة المخزون', 'bars', '<div class="kp-chart-wrap">' + V.area([{ values: inn, color: '#087FE8' }, { values: out, color: '#16B981' }], labs, 104) + '</div><div class="kp-chart-legend"><span><i class="blue"></i>دخول</span><span><i class="green"></i>خروج</span></div>') + glass('توزيع المخزون', 'box', dist) + '</div>';
    h += periodButtons('stocktab', tab, [['all', 'الكل'], ['finished', 'منتجات جاهزة'], ['raw', 'مواد خام'], ['moves', 'الحركة']]);
    if (tab !== 'moves') {
      var q = (S.stockQ || '').toLowerCase();
      if (S.stockF === 'low') items = items.filter(function (x) { return x.minStock > 0 && x.stock <= x.minStock; });
      if (S.stockF === 'ok') items = items.filter(function (x) { return !(x.minStock > 0 && x.stock <= x.minStock); });
      items = items.filter(function (x) { return !q || (x.name + ' ' + (x.code || '')).toLowerCase().indexOf(q) >= 0; });
      h += '<div class="kp-stock-list">' + (items.length ? items.map(function (x) {
        var isProduct = x._kind === 'product', lo = x.minStock > 0 && x.stock <= x.minStock, art = isProduct ? productImage(x, 100) : materialImage(x), unit = isProduct ? 'قطعة' : 'كجم';
        var code = x.code || (isProduct ? 'PRD' : 'MAT');
        var avgCost = isProduct ? null : K.avgMaterialCost(D, x.id);
        return '<article class="kp-stock-item"><div class="kp-stock-art">' + art + '</div><div class="kp-stock-name"><b>' + esc(x.name) + '</b><small>' + esc(code) + (isProduct ? '' : ' · مادة خام') + '</small><span class="kp-dimensions">' + (isProduct ? (x.weightG ? x.weightG + ' غرام / صندوق' : 'منتج بلاستيكي') : 'متوسط سعر الشراء: ' + (avgCost == null ? 'غير مسجل' : moneyText(Math.round(avgCost)) + ' / كجم')) + '</span></div><div class="kp-stock-qty"><small>الكمية المتوفرة</small><b>' + qty(x.stock) + '</b><small>' + unit + '</small>' + lowBadge(lo) + '</div><div class="kp-stock-tools"><button data-act="adjust" data-kind="' + (isProduct ? 'product' : 'material') + '" data-id="' + x.id + '" aria-label="تعديل الكمية">' + V.icon('bars', 17) + '</button><button data-act="edit_item" data-kind="' + (isProduct ? 'product' : 'material') + '" data-id="' + x.id + '" aria-label="تعديل الصنف">' + V.icon('edit', 17) + '</button>' + (!isProduct ? '<button data-act="buy_mat" data-id="' + x.id + '" aria-label="شراء مادة">' + V.icon('cart', 17) + '</button>' : '') + '</div></article>';
      }).join('') : '<div class="kp-empty"><div>▧</div><b>لا توجد أصناف مطابقة</b><span>غيّر البحث أو أضف صنفاً جديداً</span></div>') + '</div>';
      h += '<div class="kp-bottom-actions">' + (tab === 'raw' ? navAction('cart', 'شراء مواد خام', 'buy_mat', '') : '') + navAction('plus', tab === 'raw' ? 'إضافة مادة' : 'إضافة منتج', 'new_item', tab === 'raw' ? 'material' : 'product', 'primary') + (tab === 'all' ? navAction('layers', 'إضافة مادة خام', 'new_item', 'material') : '') + '</div>';
    } else {
      var moves = D.movements.slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; }).slice(0, 35);
      h += '<div class="kp-stock-list">' + (moves.length ? moves.map(function (m) { var ob = K.byId(m.kind === 'product' ? D.products : D.materials, m.itemId); return '<div class="kp-movement-row"><div>' + cardIcon(m.qty >= 0 ? 'download' : 'upload', m.qty >= 0 ? 'green' : 'red') + '</div><div><b>' + esc(ob ? ob.name : 'صنف محذوف') + '</b><small>' + esc(K.fmtDate(m.date)) + ' · ' + esc(m.type || '') + '</small></div><strong class="' + (m.qty >= 0 ? 'positive' : 'negative') + '">' + (m.qty > 0 ? '+' : '') + qty(m.qty) + '</strong></div>'; }).join('') : '<div class="kp-empty">لا توجد حركات مخزون مسجلة</div>') + '</div>';
    }
    return h + '</div>';
  };

  /* ---------- PRODUCTION: live overview, shift/line status, pending orders, log ---------- */
  W.production = function () {
    var D = U.D, td = K.today(), ym = td.slice(0, 7), r = K.monthRange(ym), rep = K.periodReport(D, r.from, r.to);
    var todayRows = live(D.production).filter(function (x) { return x.date === td; }), todayGood = K.sum(todayRows, function (x) { return x.good; });
    var pending = D.notes.filter(function (x) { return x.isOrder && (x.status === 'pending' || x.status === 'confirmed'); });
    var stops = live(D.production).filter(function (x) { return x.date === td && x.defective > 0; }).length;
    var h = '<div class="kp-page kp-production">' + pageTitle('الإنتاج', 'متابعة عمليات الإنتاج والآلات والطلبيات', 'settings', dateChip(td));
    h += '<div class="kp-kpi-grid kp-four">' +
      kpi('إجمالي الإنتاج', fmt(todayGood || rep.good) + ' <small>قطعة</small>', 'green', 'box', todayGood ? 'اليوم' : 'هذا الشهر', 'kpi_go', 'prodtoday') +
      kpi('الطلبيات الجارية', fmt(pending.length), 'blue', 'note', 'طلبات قيد التنفيذ', 'goto', 'notes') +
      kpi('سجلات الإنتاج', fmt(todayRows.length), 'purple', 'clock', 'سجل اليوم') +
      kpi('سجلات بها معيب', fmt(stops), 'red', 'alert', 'تحتاج مراجعة') + '</div>';
    h += '<div class="kp-prod-layout"><div class="kp-prod-chart">' + glass('مخطط الإنتاج اليومي', 'bars', '<div class="kp-chart-wrap">' + daysProdChart() + '</div>', '<span class="kp-dropdown">آخر 7 أيام　⌄</span>') + '</div>';
    var mix = U.act(D.products).map(function (p, i) { var g = K.sum(todayRows.filter(function (x) { return x.productId === p.id; }), function (x) { return x.good; }); return { p: p, q: g, c: [PALETTE.blue, PALETTE.green, PALETTE.amber, PALETTE.purple][i % 4] }; }).filter(function (x) { return x.q > 0; });
    var tot = K.sum(mix, function (x) { return x.q; });
    var donutParts = mix.map(function (x) { return { name: x.p.name, value: x.q, color: x.c, val: (tot ? Math.round(x.q * 100 / tot) : 0) + '%' }; });
    h += '<div class="kp-prod-donut">' + glass('توزيع إنتاج اليوم', 'box', (donutParts.length ? '<div class="kp-donut-layout">' + V.donut(donutParts, fmt(tot), 'قطعة') + '<div class="kp-legend">' + donutParts.map(function (x) { return '<div><i style="background:' + x.color + '"></i><span>' + esc(x.name) + '</span><b>' + x.val + '</b></div>'; }).join('') + '</div></div>' : '<div class="kp-empty-mini">لا توجد سجلات إنتاج اليوم</div>')) + '</div></div>';
    var machines = U.act(D.machines);
    h += '<div class="kp-two-panels"><section class="kp-glass">' + sectionHead('حالة الآلات', 'machine', '<button class="kp-text-link" data-act="goto" data-id="workers">عرض الكل</button>') + '<div class="kp-machine-grid">' + (machines.length ? machines.slice(0, 4).map(function (m) {
      var used = D.attendance.filter(function (a) { return a.date === td && a.machineId === m.id && a.worked; }).length;
      return '<button class="kp-machine-card" data-act="edit_machine" data-id="' + m.id + '">' + machineImage() + '<b>' + esc(m.name) + '</b><span class="kp-machine-state"><i class="' + (used ? 'on' : 'idle') + '"></i>' + (used ? 'موزعة على ' + used + ' عامل' : 'غير موزعة اليوم') + '</span></button>';
    }).join('') : '<div class="kp-empty-mini">لم تتم إضافة آلات بعد <button data-act="new_machine">إضافة آلة</button></div>') + '</div></section>';
    h += '<section class="kp-glass">' + sectionHead('الطلبات الجارية', 'note', '<button class="kp-text-link" data-act="goto" data-id="notes">عرض الكل</button>') + '<div class="kp-order-list">' + (pending.length ? pending.slice(0, 4).map(function (x) { var p = K.byId(D.products, x.productId); return '<button class="kp-order-row" data-act="edit_note" data-id="' + x.id + '"><span class="kp-order-art">' + (p ? productImage(p, 100) : V.icon('box', 30)) + '</span><span><b>' + esc(x.title || U.prodName(x.productId)) + '</b><small>' + esc(x.customerName || '') + ' · ' + fmt(x.qty) + ' قطعة</small><i class="kp-progress"><em style="width:' + (x.status === 'confirmed' ? '60%' : '30%') + '"></em></i></span><bdi>' + (x.status === 'confirmed' ? '60%' : '30%') + '</bdi></button>'; }).join('') : '<div class="kp-empty-mini">لا توجد طلبيات قيد التنفيذ</div>') + '</div></section></div>';
    var recs = U.newest(live(D.production).filter(function (x) { return x.date >= r.from && x.date <= r.to; })).slice(0, 6);
    h += glass('سجل الإنتاج الأخير', 'box', '<div class="kp-table-wrap"><table class="kp-table"><thead><tr><th>التاريخ</th><th>المنتج</th><th>الكمية</th><th>الآلة / الشفت</th><th>الحالة</th></tr></thead><tbody>' + (recs.length ? recs.map(function (x) { return '<tr class="kp-row-tap" data-act="tx" data-kind="production" data-id="' + x.id + '"><td>' + esc(K.fmtDate(x.date)) + '</td><td>' + esc(U.prodName(x.productId)) + '</td><td>' + fmt(x.good) + '</td><td>' + (x.shift ? 'الشفت ' + x.shift : '—') + '</td><td><span class="kp-status ' + (x.defective ? 'warning' : 'success') + '">' + (x.defective ? fmt(x.defective) + ' معيب' : 'مكتمل') + '</span></td></tr>'; }).join('') : '<tr><td colspan="5" class="kp-no-data">لا توجد سجلات إنتاج</td></tr>') + '</tbody></table></div>') +
      '<div class="kp-bottom-actions">' + navAction('plus', 'تسجيل إنتاج', 'new_production', '', 'primary') + navAction('calendar', 'جدول الإنتاج', 'goto', 'prodtable') + navAction('users', 'الشفتات', 'kp_open_shifts') + '</div></div>';
    return h;
  };

  /* ---------- SHIFTS / WORKERS ---------- */
  function shiftTiming(s) {
    var h = new Date().getHours(), start = Number(s.start.slice(0, 2)), end = Number(s.end.slice(0, 2));
    if (end === 0) end = 24;
    if (start > end) return h >= start || h < end ? 'current' : 'upcoming';
    return h >= start && h < end ? 'current' : h < start ? 'upcoming' : 'ended';
  }
  function staffStatus(w) { return w.status || (w.active === false ? 'stopped' : 'active'); }
  function shiftInfo(day, s) {
    var D = U.D, roster = K.rosterFor(D, day, s.n), worked = roster.filter(function (x) { return x.worked; });
    var records = live(D.production).filter(function (x) { return x.date === day && x.shift === s.n; });
    return { shift: s, roster: roster, worked: worked, good: K.sum(records, function (x) { return x.good; }), recs: records.length, state: shiftTiming(s) };
  }
  function shiftsView() {
    var D = U.D, day = K.today(), workers = U.act(D.workers), active = workers.filter(function (w) { return staffStatus(w) === 'active'; }), inNow = {}, away = workers.filter(function (w) { return staffStatus(w) === 'leave'; }).length, off = workers.filter(function (w) { return staffStatus(w) === 'stopped'; }).length;
    K.SHIFTS.forEach(function (s) { K.rosterFor(D, day, s.n).forEach(function (a) { if (a.worked) inNow[a.workerId] = true; }); });
    var infos = K.SHIFTS.map(function (s) { return shiftInfo(day, s); });
    var h = '<div class="kp-kpi-grid kp-four">' + kpi('إجمالي العمال', fmt(workers.length), 'blue', 'users', 'عامل') + kpi('في العمل اليوم', fmt(Object.keys(inNow).length), 'green', 'play', 'عامل') + kpi('في إجازة', fmt(away), 'amber', 'clock', 'عامل') + kpi('غير نشطين', fmt(off), 'red', 'alert', 'عامل') + '</div>';
    h += glass('الشفتات اليومية', 'clock', '<div class="kp-shift-cards">' + infos.map(function (x) {
      var pct = active.length ? x.worked.length * 100 / active.length : 0, state = x.state === 'current' ? ['قيد العمل', 'current'] : x.state === 'upcoming' ? ['لم يبدأ بعد', 'pending'] : ['منتهي', 'done'];
      return '<button class="kp-shift-card" data-act="roster" data-date="' + day + '" data-shift="' + x.shift.n + '"><div class="kp-shift-head"><span class="kp-shift-symbol ' + (x.shift.n === 1 ? 'morning' : x.shift.n === 2 ? 'evening' : 'night') + '">' + (x.shift.n === 1 ? '☀' : x.shift.n === 2 ? '◉' : '☾') + '</span><span><b>الشفت ' + x.shift.n + '</b><small dir="ltr">' + x.shift.start + ' – ' + x.shift.end + '</small></span></div>' + ring(pct, x.shift.n === 1 ? PALETTE.green : x.shift.n === 2 ? PALETTE.blue : PALETTE.slate) + '<strong>' + x.worked.length + ' / ' + active.length + '</strong><small>عامل</small><span class="kp-status ' + (state[1] === 'current' ? 'success' : state[1] === 'pending' ? 'warning' : 'neutral') + '">' + state[0] + '</span></button>';
    }).join('') + '</div>');
    h += periodButtons('worktab', S.workTab || 'today', [['today', 'تفاصيل الشفتات'], ['list', 'العمال'], ['week', 'الإنتاج']]);
    if ((S.workTab || 'today') === 'today') {
      h += '<div class="kp-shift-detail-list">' + infos.map(function (x) {
        var state = x.state === 'current' ? ['قيد العمل', 'success'] : x.state === 'upcoming' ? ['لم يبدأ بعد', 'neutral'] : ['مكتمل', 'success'];
        return '<section class="kp-shift-detail"><div class="kp-shift-detail-title"><span class="kp-shift-symbol ' + (x.shift.n === 1 ? 'morning' : x.shift.n === 2 ? 'evening' : 'night') + '">' + (x.shift.n === 1 ? '☀' : x.shift.n === 2 ? '◉' : '☾') + '</span><div><b>الشفت ' + x.shift.n + '</b><small>' + x.shift.start + ' – ' + x.shift.end + '</small></div><span class="kp-status ' + state[1] + '">' + state[0] + '</span></div>' +
          '<div class="kp-shift-metrics"><div><small>العمال</small><b>' + x.worked.length + '</b><small>عامل</small></div><div><small>إنتاج الصناديق</small><b>' + fmt(x.good) + '</b><small>قطعة</small></div><div><small>سجلات الإنتاج</small><b>' + x.recs + '</b><small>سجل</small></div><div><small>الآلات الموزعة</small><b>' + x.worked.filter(function (a) { return !!a.machineId; }).length + '</b><small>توزيع</small></div></div>' +
          '<div class="kp-shift-foot">' + (x.worked.length ? x.worked.map(function (a) { return '<button class="kp-worker-chip" data-act="open_worker" data-id="' + a.workerId + '">' + esc(U.workerName(a.workerId)) + '</button>'; }).join('') : '<span class="kp-muted">لم يتم تسجيل عمال في هذا الشفت</span>') + '<button class="kp-edit-shift" data-act="roster" data-date="' + day + '" data-shift="' + x.shift.n + '">' + V.icon('edit', 16) + ' تعديل التوزيع</button></div></section>';
      }).join('') + '</div>';
    } else if (S.workTab === 'list') {
      h += '<div class="kp-people-list">' + (workers.length ? workers.map(function (w) { var st = staffStatus(w); return '<button class="kp-person-row" data-act="open_worker" data-id="' + w.id + '">' + cardIcon('user', st === 'active' ? 'blue' : 'red') + '<span><b>' + esc(w.name) + '</b><small>' + esc(w.role || 'عامل') + ' · ' + esc(w.phone || 'بدون هاتف') + '</small></span><span class="kp-status ' + (st === 'active' ? 'success' : 'neutral') + '">' + (st === 'active' ? 'نشط' : st === 'leave' ? 'استراحة' : 'موقوف') + '</span>' + V.icon('chevL', 16) + '</button>'; }).join('') : '<div class="kp-empty">لا يوجد عمال مسجلون بعد</div>') + '</div><button class="kp-primary-wide" data-act="new_worker">＋ إضافة عامل جديد</button>';
    } else {
      var prods = U.newest(live(D.production).filter(function (x) { return x.date === day; }));
      h += '<div class="kp-production-shift-list">' + (prods.length ? prods.map(function (x) { return '<button class="kp-shift-production-row" data-act="tx" data-kind="production" data-id="' + x.id + '"><span>' + productImage(K.byId(D.products, x.productId), 88) + '</span><div><b>' + esc(U.prodName(x.productId)) + '</b><small>' + (x.shift ? 'الشفت ' + x.shift : 'غير محدد') + ' · ' + esc(K.fmtDate(x.date)) + '</small></div><strong>' + fmt(x.good) + '<small>قطعة</small></strong></button>'; }).join('') : '<div class="kp-empty">لا توجد سجلات إنتاج اليوم</div>') + '</div>';
    }
    h += '<div class="kp-bottom-actions">' + navAction('refresh', 'تعديل الشفتات', 'kp_edit_today_roster', '', 'primary') + navAction('user-plus', 'إضافة عامل', 'new_worker') + navAction('calendar', 'جدول الأسبوع', 'worktab', 'week') + navAction('file-text', 'تقرير الشفتات', 'goto', 'reports') + '</div>';
    return h;
  }
  W.workers = function () {
    var tab = S.workTab || 'today';
    var h = '<div class="kp-page kp-workers">' + pageTitle('الشفتات', 'إدارة الشفتات والعمال', 'users', dateChip(K.today()));
    return h + shiftsView() + '</div>';
  };
  X.kp_open_shifts = function () { U.closeModal(); S.workTab = 'today'; U.stack = []; U.route = 'workers'; U.arg = null; U.render(); };
  X.kp_edit_today_roster = function () { var d = K.today(); U.showModal('<h3>اختيار الشفت لتعديل توزيع العمال</h3><div class="kp-drawer-grid">' + K.SHIFTS.map(function (sh) { return '<button data-act="roster" data-date="' + d + '" data-shift="' + sh.n + '">' + cardIcon('clock', 'blue') + '<b>الشفت ' + sh.n + '</b><small dir="ltr">' + sh.start + ' – ' + sh.end + '</small></button>'; }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">إغلاق</button></div>'); };
  X.kp_share_sales = function () { var r = rangeFor(S.salesP || 'month'), rep = K.periodReport(U.D, r.from, r.to), txt = 'KHALDI PLAST — ملخص المبيعات\nالفترة: ' + r.from + ' — ' + r.to + '\nالمبيعات: ' + moneyText(rep.sales) + '\nالفواتير: ' + rep.salesCount + '\nالكمية: ' + fmt(rep.cratesSold) + ' قطعة'; if (U.AND && U.AND.shareText) U.AND.shareText(txt); else if (navigator.share) navigator.share({ text: txt }).catch(function () {}); else if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { U.toast('تم نسخ الملخص', 'ok'); }); };

  /* ---------- NOTES: customer requests / future orders ---------- */
  W.notes = function () {
    var D = U.D, td = K.today(), q = (S.noteQ || '').trim().toLowerCase();
    var noteFilter = S.noteF || 'all'; S.noteF = noteFilter;
    var list0 = D.notes.filter(function (n) { return noteFilter === 'all' || (noteFilter === 'plain' ? !n.isOrder : n.status === noteFilter && n.isOrder); });
    var list = list0.filter(function (x) { var p = x.productId ? U.prodName(x.productId) : ''; return !q || ((x.title || '') + ' ' + (x.text || '') + ' ' + (x.customerName || '') + ' ' + (x.phone || '') + ' ' + p).toLowerCase().indexOf(q) >= 0; });
    list.sort(function (a, b) { return S.noteSort === 'expected' ? ((a.expectedDate || '9999') > (b.expectedDate || '9999') ? 1 : -1) : (a.date < b.date ? 1 : -1); });
    var orders = D.notes.filter(function (n) { return n.isOrder; }), pending = orders.filter(function (n) { return n.status === 'pending'; }).length, confirmed = orders.filter(function (n) { return n.status === 'confirmed'; }).length;
    var overdue = orders.filter(function (n) { return (n.status === 'pending' || n.status === 'confirmed') && n.expectedDate && n.expectedDate < td; }).length;
    var h = '<div class="kp-page kp-notes">' + pageTitle('الملاحظات', 'تدوين الطلبات القادمة وأية ملاحظات إضافية', 'note', '');
    h += '<div class="kp-kpi-grid kp-four">' + kpi('إجمالي الطلبات', fmt(orders.length), 'blue', 'note', 'طلب') + kpi('بانتظار التنفيذ', fmt(pending), 'amber', 'clock', 'طلب') + kpi('مؤكدة', fmt(confirmed), 'green', 'check', 'طلب') + kpi('متأخرة', fmt(overdue), 'red', 'calendar', 'طلب') + '</div>';
    h += '<div class="kp-note-filters">' + periodButtons('notef', S.noteF || 'all', [['all', 'الكل'], ['confirmed', 'مؤكدة'], ['pending', 'بانتظار التنفيذ'], ['completed', 'مكتملة'], ['plain', 'ملاحظات']]) + '</div>';
    h += '<div class="kp-search-filter"><label class="kp-search"><span>' + V.icon('search', 19) + '</span><input id="noteq" data-bind="noteQ" value="' + esc(S.noteQ || '') + '" placeholder="بحث في الملاحظات..." autocomplete="off"></label><button class="kp-filter-button" data-act="notesort" data-id="' + (S.noteSort === 'expected' ? 'added' : 'expected') + '">' + V.icon('filter', 18) + '</button></div>';
    h += '<div class="kp-note-list">' + (list.length ? list.map(function (x, ix) {
      var p = x.productId ? K.byId(D.products, x.productId) : null, late = (x.status === 'pending' || x.status === 'confirmed') && x.expectedDate && x.expectedDate < td;
      var status = { pending: ['بانتظار التنفيذ', 'warning'], confirmed: ['مؤكدة', 'success'], completed: ['مكتملة', 'info'], cancelled: ['ملغاة', 'neutral'] }[x.status] || ['ملاحظة', 'neutral'];
      var customerIcon = ['blue', 'purple', 'green', 'amber', 'red', 'teal'][ix % 6];
      return '<article class="kp-note-card"><div class="kp-note-client">' + cardIcon(x.customerName ? 'store' : 'user', customerIcon) + '<div><b>' + esc(x.customerName || x.title || 'ملاحظة جديدة') + '</b><small>' + esc(x.phone || 'لا يوجد رقم هاتف') + '</small></div></div><div class="kp-note-order">' + (p ? '<div class="kp-note-product-img">' + productImage(p, 100) + '</div>' : '<div class="kp-note-product-img">' + V.icon('file-text', 32) + '</div>') + '<div class="kp-note-product"><b>' + esc(p ? p.name : (x.title || 'ملاحظة')) + '</b><small>' + (p ? esc(p.code || '') + ' · الكمية: ' + fmt(x.qty) + ' قطعة' : esc((x.text || '').slice(0, 68))) + '</small>' + (x.expectedDate ? '<small>التسليم المتوقع: ' + esc(K.fmtDate(x.expectedDate)) + '</small>' : '') + '</div><div class="kp-note-date"><bdi>' + esc(K.fmtDate(x.date)) + '</bdi><span class="kp-status ' + status[1] + '">' + status[0] + '</span>' + (late ? '<span class="kp-status danger">متأخرة</span>' : '') + '</div></div>' + (x.text && p ? '<p class="kp-note-text">' + esc(x.text) + '</p>' : '') + '<div class="kp-note-footer"><div>' + V.icon('file-text', 15) + '<span>' + esc(x.text || 'لا توجد تفاصيل إضافية') + '</span></div><div class="kp-note-buttons"><button data-act="edit_note" data-id="' + x.id + '" aria-label="تعديل">' + V.icon('edit', 18) + '</button><button data-act="del_note" data-id="' + x.id + '" aria-label="حذف">' + V.icon('trash', 18) + '</button>' + (p && x.qty && !x.saleId && x.status !== 'cancelled' ? '<button data-act="note_invoice" data-id="' + x.id + '" aria-label="تحويل إلى فاتورة">' + V.icon('file-plus', 18) + '</button>' : '') + '</div></div></article>';
    }).join('') : '<div class="kp-empty"><div>' + V.icon('note', 34) + '</div><b>لا توجد ملاحظات مطابقة</b><span>أضف طلباً جديداً أو غيّر خيارات البحث</span></div>') + '</div>';
    h += '<div class="kp-bottom-actions">' + navAction('plus', 'إضافة ملاحظة جديدة', 'new_note', '', 'primary') + navAction('download', 'تصدير', 'export_notes') + navAction('printer', 'طباعة', 'print_sales') + '</div></div>';
    return h;
  };

  /* ---------- MORE: consistent module launcher ---------- */
  W.more = function () {
    var tiles = [
      ['sales', 'bars', 'المبيعات', 'blue'], ['invoices', 'file-text', 'الفواتير', 'cyan'], ['stock', 'box', 'المخزون', 'amber'],
      ['production', 'factory', 'الإنتاج', 'green'], ['purchases', 'truck', 'المشتريات', 'orange'], ['customers', 'users', 'العملاء', 'purple'],
      ['suppliers', 'store', 'الموردون', 'teal'], ['workers', 'users', 'الشفتات والعمال', 'purple'], ['notes', 'note', 'الملاحظات', 'blue'],
      ['expenses', 'wallet', 'المصاريف', 'red'], ['reports', 'bars', 'التقارير', 'orange'], ['maintenance', 'machine', 'صيانة الآلات', 'slate'],
      ['payroll', 'wallet', 'الأجور', 'green'], ['assistant', 'chat', 'المساعد الذكي', 'purple'], ['settings', 'settings', 'الإعدادات', 'slate'], ['backup', 'save', 'النسخ الاحتياطي', 'blue']
    ];
    return '<div class="kp-page kp-more">' + pageTitle('جميع الأقسام', 'كل أدوات إدارة KHALDI PLAST في مكان واحد', 'grid', '') + '<div class="kp-module-grid">' + tiles.map(function (x) { return '<button class="kp-module" data-act="' + (x[0] === 'workers' ? 'kp_open_shifts' : 'goto') + '" ' + (x[0] === 'workers' ? '' : 'data-id="' + x[0] + '"') + '>' + cardIcon(x[1], x[3]) + '<b>' + esc(x[2]) + '</b><span>' + V.icon('chevL', 15) + '</span></button>'; }).join('') + '</div><div class="kp-glass kp-more-settings">' + sectionHead('إعدادات ومساحة العمل', 'settings') + '<button class="kp-more-row" data-act="goto" data-id="customize">' + V.icon('sliders', 20) + '<b>تخصيص الواجهة</b>' + V.icon('chevL', 17) + '</button><button class="kp-more-row" data-act="goto" data-id="settings">' + V.icon('settings', 20) + '<b>إعدادات النظام</b>' + V.icon('chevL', 17) + '</button></div></div>';
  };

  /* ---------- Top-level drawer ---------- */
  X.kp_drawer = function () {
    var list = [['home','الرئيسية','home'], ['sales','المبيعات','bars'], ['stock','المخزون','box'], ['production','الإنتاج','factory'], ['workers','الشفتات','users'], ['notes','الملاحظات','note'], ['customers','العملاء','users'], ['reports','التقارير','bars'], ['settings','الإعدادات','settings']];
    U.showModal('<div class="kp-drawer-head">' + logo() + '<b>مساحة عمل KHALDI PLAST</b></div><div class="kp-drawer-grid">' + list.map(function (x) { return '<button data-act="' + (x[0] === 'workers' ? 'kp_open_shifts' : 'tab') + '" data-id="' + x[0] + '">' + cardIcon(x[2], 'blue') + '<b>' + esc(x[1]) + '</b></button>'; }).join('') + '</div><div class="btns"><button class="btn ghost" data-act="close">إغلاق</button></div>');
  };

  /* ---------- Add semantic route styles and replace the old shell after rendering ---------- */
  var baseRender = U.render;
  function activeTab(route) {
    if (route === 'home') return 'home';
    if (['sales','invoices','invoice','quotes','quote'].indexOf(route) >= 0) return 'sales';
    if (route === 'stock' || route === 'stocktake') return 'stock';
    if (['production','prodtable','maintenance'].indexOf(route) >= 0) return 'production';
    return 'more';
  }
  function appHeader() {
    var route = U.route, sectionBack = ['sales', 'notes', 'workers'].indexOf(route) >= 0;
    var canBack = (U.stack.length > 0 && route !== 'home') || sectionBack;
    var left = sectionBack && !U.stack.length ? '<button class="kp-top-button" data-act="tab" data-id="home" aria-label="الرئيسية">' + V.icon('back', 22) + '</button>' : canBack ? '<button class="kp-top-button" data-act="back" aria-label="رجوع">' + V.icon('back', 22) + '</button>' : '<button class="kp-top-button" data-act="kp_drawer" aria-label="القائمة">' + V.icon('menu', 22) + '</button>';
    var hasAlerts = U.alerts && U.alerts().length;
    var addAction = route === 'sales' ? 'new_sale' : route === 'notes' ? 'new_note' : route === 'workers' ? 'new_worker' : '';
    var right = addAction ? '<button class="kp-top-button kp-addtop" data-act="' + addAction + '" aria-label="إضافة">' + V.icon('plus', 24) + '</button>' : '<button class="kp-top-button kp-bell" data-act="bell" aria-label="التنبيهات">' + V.icon('bell', 22) + (hasAlerts ? '<i></i>' : '') + '</button>';
    return '<div class="kp-topline">' + left + logo() + right + '</div>';
  }
  function appNav() {
    var tab = activeTab(U.route), items = [['home','home','الرئيسية'],['sales','bars','المبيعات'],['stock','box','المخزون'],['production','factory','الإنتاج'],['more','user','المزيد']];
    return '<div class="kp-tabbar">' + items.map(function (x) { return '<button class="kp-tab ' + (tab === x[0] ? 'active' : '') + '" data-act="tab" data-id="' + x[0] + '"' + (tab === x[0] ? ' aria-current="page"' : '') + '><span>' + V.icon(x[1], 24) + '</span><b>' + x[2] + '</b></button>'; }).join('') + '</div>';
  }
  U.render = function (keep) {
    baseRender(keep);
    var app = U.$('#app'), hdr = U.$('#hdr'), nav = U.$('#nav'), main = U.$('#main');
    if (!app || !hdr || !nav || !main) return;
    app.classList.add('kp-reference-app');
    app.classList.toggle('kp-is-home', U.route === 'home');
    app.classList.toggle('kp-is-inner', U.route !== 'home');
    hdr.className = 'hdr kp-header'; hdr.innerHTML = appHeader();
    nav.className = 'kp-navigation'; nav.innerHTML = appNav();
    var ph = main.querySelector('.pagehead'); if (ph) ph.remove();
    if (!main.querySelector('.kp-page')) {
      main.insertAdjacentHTML('afterbegin', '<div class="kp-page kp-legacy-page">' + pageTitle(ROUTE_TITLE[U.route] || U.route, 'إدارة ومتابعة ' + (ROUTE_TITLE[U.route] || 'العمليات'), 'grid') + '</div>');
    }
    if (U.route === 'sales') wireSalesFilter();
    main.classList.toggle('kp-no-page', false);
  };

  /* ---------- Filter and search bindings which survive re-render ---------- */
  document.addEventListener('change', function (e) {
    if (e.target && e.target.id === 'kp-sales-filter') { S.salesF = e.target.value; U.render(true); }
  });
  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'salesq') { S.salesQ = e.target.value; }
  });

  /* ---------- Make existing non-core routes inherit the same visual shell ---------- */
  window.addEventListener('load', function () { setTimeout(function () { U.render(true); }, 20); });
  U.render(true);
})();
