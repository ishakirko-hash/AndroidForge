// v2.2: customers & leads (CRM), purchases table, smart analysis (UI)
const L=require('./lib.js');
let pass=0, fail=0; const ok=(c,n)=>{ c?pass++:fail++; console.log((c?'PASS ':'FAIL ')+n); };
(async()=>{ const s=await L.start(process.argv[2],360); const p=s.page; await p.waitForSelector('#splash.hidden',{state:'attached'});
 const D=()=>p.evaluate(()=>JSON.parse(JSON.stringify(window.KPU.D)));
 const go=async(r,a)=>{ await p.evaluate(([r,a])=>{window.KPU.stack=[];window.KPU.route='home';window.KPU.go(r,a);},[r,a||null]); await p.waitForTimeout(100); };
 const main=()=>p.locator('#main').innerText();
 const ovf=()=>p.evaluate(()=>{const m=document.getElementById('main'); return [m.scrollWidth-m.clientWidth, document.documentElement.scrollWidth-window.innerWidth];});
 await p.evaluate(()=>{ window.__shared=[]; window.__files=[]; window.__printed=0; window.KPU.AND=null; navigator.share=(o)=>{window.__shared.push(o.text);return Promise.resolve();}; window.print=()=>{window.__printed++;}; const sf=window.KPU.saveFile; window.KPU.saveFile=function(n,m,c){window.__files.push({n,c});}; });
 const submit=async()=>{ await p.click('#f button[type=submit]'); await p.waitForTimeout(150); };
 // ---- seed
 const ids=await p.evaluate(()=>{ const U=window.KPU,K=U.K,td=K.today(),o={};
  U.commit(d=>{ const P=d.products[0].id,M=d.materials[0].id; o.P=P;
   const s1=K.addSupplier(d,{name:'Sup One'}).id,s2=K.addSupplier(d,{name:'Sup Two'}).id; o.s1=s1;o.s2=s2;
   const a=K.addCustomer(d,{name:'Ahmed Benali',phone:'0550 11 22 33'}).id; o.a=a;
   K.recordPurchase(d,{date:K.addDays(td,-3),supplierId:s1,materialId:M,qty:1000,unitCost:20000,paid:5000000,method:'cash'});
   K.recordPurchase(d,{date:K.addDays(td,-2),supplierId:s2,materialId:M,qty:500,unitCost:24000,paid:0,method:'cash'});
   const g={}; g[M]=300; for(let i=0;i<10;i++) K.recordProduction(d,{date:K.addDays(td,-i),shift:1,productId:P,good:100,defective:i<2?10:1,grams:g});
   [[-70,40],[-40,40],[-12,50],[-3,60]].forEach(([dd,q])=>K.recordSale(d,{date:K.addDays(td,dd),customerId:a,items:[{productId:P,qty:q,unitPrice:10000,weightG:0}],paid:q*5000,method:'cash'}));
  }); U.render(); return o; });
 // ---- tiles + migration
 await go('more'); const lbl=await p.locator('.tiles .tilebtn').allInnerTexts(); ok(['العملاء والمحتملون','جدول المشتريات','التحليل الذكي'].every(x=>lbl.some(l=>l.includes(x))),'More lists the 3 new tiles');
 await p.evaluate(()=>{ const U=window.KPU; U.commit(d=>{ d.settings.layout={v:1,hv:2,v2:1,hidden:['x'],order:[],icons:{},secOrder:[],secHidden:[],wOrder:[],sizes:{},shown:[]}; }); U.migrateLayout2(); });
 let d=await D(); ok(d.settings.layout.v22===1 && ['crm','purchtable','analysis'].every(k=>d.settings.layout.hidden.includes(k)),'old layouts: new tiles hidden from home once');
 await p.evaluate(()=>{ window.KPU.commit(dd=>{ dd.settings.layout=undefined; }); window.KPU.render(); });
 // ---- add a lead
 await go('crm'); ok((await main()).includes('لا يوجد عملاء محتملون'),'empty leads state');
 await p.click('[data-act="lead_new"]'); await p.waitForSelector('#f');
 await p.fill('#f_name','Fruits Sud'); await p.fill('#f_phone','0555 12 34 56'); await p.selectOption('#f_source','referral'); await p.selectOption('#f_product',ids.P); await p.fill('#f_qty','500'); await p.fill('#f_value','50000'); await submit();
 d=await D(); const L1=d.leads[0]; ok(d.leads.length===1 && L1.name==='Fruits Sud' && L1.value===5000000 && L1.qty===500 && L1.source==='referral' && L1.stage==='new','lead saved (value in centimes)');
 ok((await p.evaluate(()=>window.KPU.route))==='lead' && (await main()).includes('Fruits Sud'),'opens the lead page after saving');
 // live duplicate warning (same phone as the customer) + blocking + force
 await go('crm'); await p.click('[data-act="lead_new"]'); await p.waitForSelector('#f'); await p.fill('#f_name','Someone'); await p.fill('#f_phone','+213 550 11 22 33'); await p.waitForTimeout(80);
 ok((await p.locator('.crm-dup').count())===1 && (await p.locator('.crm-dup').innerText()).includes('Ahmed Benali'),'live duplicate warning names the existing customer');
 await submit(); ok((await p.locator('#ferr').innerText()).includes('Ahmed Benali') && (await D()).leads.length===1,'strong duplicate blocks saving with a clear message');
 await p.check('input[name=force]'); await submit(); ok((await D()).leads.length===2,'"add anyway" overrides'); 
 // new customer form has the same smart check
 await go('crm'); await p.click('[data-act="new_party"][data-kind="customer"]'); await p.waitForSelector('#f'); await p.fill('#f_name','ahmed benali'); await p.waitForTimeout(80);
 ok((await p.locator('.crm-dup').count())===1,'customer form: duplicate warning'); await submit(); ok((await D()).customers.length===1 && (await p.locator('#ferr').innerText()).length>5,'customer form: duplicate blocked');
 await p.fill('#f_name','Brand New'); await p.waitForTimeout(60); ok((await p.locator('.crm-dup').count())===0,'warning disappears for a new name'); await submit(); ok((await D()).customers.length===2,'new customer saved');
 // ---- lead workflow
 await go('lead',L1.id); await p.click('[data-act="lead_note"]'); await p.waitForSelector('#f'); await p.fill('#f_text','called, wants 500 crates'); await submit();
 d=await D(); const l1=d.leads.find(x=>x.id===L1.id); ok(l1.stage==='contacted' && l1.log.length===2 && l1.log[1].text.includes('wants 500'),'logging a contact moves new -> contacted and keeps history');
 await p.click('[data-act="lead_stage"][data-id="negotiation"]'); d=await D(); ok(d.leads.find(x=>x.id===L1.id).stage==='negotiation','stage chip changes the stage');
 await p.click('[data-act="lead_quote"]'); await p.waitForSelector('#f'); ok((await p.inputValue('#f_cname'))==='Fruits Sud' && (await p.inputValue('.itrow [data-k=qty]'))==='500','quote form is pre-filled from the lead');
 await p.fill('.itrow [data-k=price]','250'); await submit(); d=await D(); ok(d.quotes.length===1 && d.quotes[0].customerName==='Fruits Sud' && d.leads.find(x=>x.id===L1.id).stage==='negotiation','quote created for the lead (stage not moved backwards)');
 await go('lead',L1.id); await p.click('[data-act="lead_won"]'); await p.waitForSelector('#modal [data-act="confirm_ok"], #modal .btn.primary'); await p.click('#modal [data-act="confirm_ok"], #modal .btn.primary'); await p.waitForTimeout(150);
 d=await D(); const w=d.leads.find(x=>x.id===L1.id); ok(w.stage==='won' && w.customerId && d.customers.some(c=>c.id===w.customerId && c.name==='Fruits Sud'),'convert: customer created, lead won');
 ok((await main()).includes('Fruits Sud') && (await p.locator('[data-act="lead_won"]').count())===0,'won lead has no convert button');
 const L2=d.leads[1].id; await go('lead',L2); await p.click('[data-act="lead_lost"]'); await p.waitForSelector('#f'); await p.selectOption('#f_reason','price'); await submit(); d=await D(); ok(d.leads.find(x=>x.id===L2).stage==='lost' && d.leads.find(x=>x.id===L2).lostReason.length>0,'lost with a reason');
 await p.click('[data-act="lead_reopen"]'); d=await D(); ok(d.leads.find(x=>x.id===L2).stage==='contacted','reopen a lost lead');
 // ---- crm tabs
 await go('crm'); await p.click('[data-act="crm_tab"][data-id="customers"]'); await p.waitForTimeout(80); let m=await main(); ok(m.includes('Ahmed Benali') && m.includes('Brand New'),'customers tab lists customers');
 await p.click('[data-act="cust_seg"][data-id="prospect"]'); m=await main(); ok(m.includes('Brand New') && !m.includes('Ahmed Benali'),'segment filter: "no purchases" shows only the never-invoiced customer');
 await p.click('[data-act="crm_tab"][data-id="funnel"]'); await p.waitForTimeout(80); m=await main(); ok(m.includes('%') && (await p.locator('.crm-fr').count())===6,'funnel tab: 6 stages');
 await p.click('[data-act="crm_tab"][data-id="leads"]'); await p.fill('#crmq','zzzz'); await p.waitForTimeout(80); ok((await p.locator('.crm-dup').count())===0,'search works'); await p.fill('#crmq','');
 // ---- purchases table
 await go('purchtable'); m=await main(); ok(m.includes('Sup One') && m.includes('Sup Two'),'table lists both purchases');
 const tt=await p.evaluate(()=>{const U=window.KPU,K=U.K; const t=K.purchaseTable(U.D,{from:K.addDays(K.today(),-5)}); return t.totals;}); ok(tt.total===(20000*1000+24000*500) && tt.remaining===tt.total-5000000,'table totals match the data');
 await p.selectOption('#ptSup',ids.s2); await p.waitForTimeout(80); m=await main(); ok(m.includes('Sup Two') && !/Sup One\s*\n?[^\n]*Granul/.test(m) && (await p.locator('.pt-tb tbody tr').count())===1,'supplier filter');
 await p.selectOption('#ptSup',''); await p.click('[data-act="pt_csv"]'); const fl=await p.evaluate(()=>window.__files.slice(-1)[0]); ok(fl && /purchases/.test(fl.n) && fl.c.split('\r\n').length>=4 && fl.c.includes('Sup One'),'CSV export has header, rows and total');
 await p.click('[data-act="pt_print"]'); await p.waitForTimeout(400); ok((await p.evaluate(()=>window.__printed))===1,'print button');
 await p.click('.pt-tb tbody tr.tap'); ok((await p.evaluate(()=>window.KPU.route))==='tx','row opens the purchase details');
 await go('purchtable'); await p.click('[data-act="pt_range"][data-id="all"]'); ok((await p.locator('.pt-tb tbody tr').count())===2,'range: all');
 const pid=ids; await p.evaluate(()=>{ const U=window.KPU; U.commit(dd=>U.K.voidPurchase(dd,dd.purchases[1].id)); U.render(true); }); ok((await p.locator('.pt-tb tbody tr').count())===1,'voided purchase hidden');
 await p.check('#ptVoid'); await p.waitForTimeout(80); ok((await p.locator('.pt-tb tbody tr.pt-void').count())===1,'voided purchase can be shown (struck through)');
 // ---- analysis
 await go('analysis'); m=await main(); ok((await p.locator('.an-ring').count())===1 && m.includes('/100'),'health ring shown');
 ok((await p.locator('.an-comp').count())===6,'six health components with weights'); ok((await p.locator('.an-chart').count())===1,'6-month chart');
 ok(m.includes('Ahmed Benali'),'top customer listed'); const recs=await p.locator('.an-health').count(); ok(recs===1,'health card');
 await p.click('[data-act="an_days"][data-id="7"]'); ok((await p.evaluate(()=>window.KPU.S.anDays))===7,'period chip 7 days');
 await p.click('[data-act="an_days"][data-id="90"]'); await p.waitForTimeout(80);
 await p.click('[data-act="an_share"]'); await p.waitForTimeout(150); const sh=await p.evaluate(()=>window.__shared.slice(-1)[0]||''); ok(sh.includes('KHALDI PLAST') && /\d+\/100/.test(sh),'share text has the score');
 await p.click('[data-act="an_print"]'); await p.waitForTimeout(400); ok((await p.evaluate(()=>window.__printed))===2,'print analysis');
 await p.click('[data-act="an_seg"][data-id="active"]'); ok((await p.evaluate(()=>window.KPU.route))==='crm' && (await p.evaluate(()=>window.KPU.S.crmTab))==='customers','segment tile opens the CRM filtered');
 // ---- home widgets
 await p.evaluate(()=>{ window.KPU.commit(dd=>{ dd.settings.layout={v:1,hv:2,v2:1,v22:1,hidden:[],order:[],icons:{},secOrder:[],secHidden:[],wOrder:['healthw','followw'],sizes:{},shown:['healthw','followw']}; }); window.KPU.stack=[];window.KPU.route='home';window.KPU.render(); });
 await p.waitForTimeout(100); m=await main(); ok((await p.locator('.wgrid .wd[data-k="healthw"]').count())===1 && (await p.locator('.wgrid .wd[data-k="followw"]').count())===1,'home widgets: health + follow-ups'); ok(/\/100|—/.test(m),'health widget shows the score');
 // ---- overflow / themes / languages
 for(const th of ['light','dark']) for(const r of ['crm','purchtable','analysis']){ await p.evaluate(t=>window.KPU.commit(dd=>{dd.settings.theme=t}),th); await go(r); const o=await ovf(); ok(o[0]<=0&&o[1]<=0,'no overflow '+r+' '+th+' '+o); }
 for(const lg of ['fr','en']){ await p.evaluate(l=>window.KPU.commit(dd=>{dd.settings.lang=l}),lg); for(const r of ['crm','purchtable','analysis']){ await go(r); const txt=await main(); ok(!/\b(crm_|an_|pt_|tile_)\w+/.test(txt),'no raw i18n keys '+r+' '+lg); } }
 console.log('errors:',s.errors.join('|')||'none'); ok(s.errors.length===0,'no JS errors');
 console.log('pass',pass,'fail',fail); await s.close(); process.exit(fail?1:0); })();
